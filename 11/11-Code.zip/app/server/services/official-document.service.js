import * as docx from 'docx';
import {
  parseContentToAST,
  buildDocxElementsFromAST,
  parseInlineRuns,
  sanitizeHtmlContent
} from '../../src/lib/document-docx-parser.js';

const {
  AlignmentType,
  BorderStyle,
  Document,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  WidthType
} = docx;

const FONT = 'Times New Roman';
const BODY_SIZE = 26; // 13pt half-points (NĐ 30/2020 standard)

export const ND30_PRINTABLE_WIDTH_DXA = 9355; // 210mm (11906 DXA) - 30mm left (1701 DXA) - 15mm right (850 DXA)
const HEADER_COL1_WIDTH = 3742; // 40% of 9355 DXA
const HEADER_COL2_WIDTH = 5613; // 60% of 9355 DXA
const FOOTER_COL1_WIDTH = 3742; // 40% of 9355 DXA
const FOOTER_COL2_WIDTH = 5613; // 60% of 9355 DXA

const DOCUMENT_TITLES = {
  corrective_notice: 'THÔNG BÁO YÊU CẦU KHẮC PHỤC',
  tmpl_thong_bao_khac_phuc: 'THÔNG BÁO YÊU CẦU KHẮC PHỤC',
  inspection_minutes: 'BIÊN BẢN KIỂM TRA HIỆN TRẠNG',
  inspection_record: 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH',
  tmpl_bien_ban_kiem_tra: 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH',
  'bien-ban-kiem-tra': 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH',
  'bien-ban-vphc': 'BIÊN BẢN VI PHẠM HÀNH CHÍNH',
  violation_notice: 'BIÊN BẢN VI PHẠM HÀNH CHÍNH',
  tmpl_bien_ban_vphc: 'BIÊN BẢN VI PHẠM HÀNH CHÍNH',
  'quyet-dinh-kiem-tra': 'QUYẾT ĐỊNH KIỂM TRA',
  inspection_decision: 'QUYẾT ĐỊNH KIỂM TRA MÔI TRƯỜNG CÔNG TRÌNH',
  tmpl_quyet_dinh_kiem_tra: 'QUYẾT ĐỊNH KIỂM TRA MÔI TRƯỜNG CÔNG TRÌNH',
  'quyet-dinh-xu-phat': 'QUYẾT ĐỊNH XỬ PHẠT VI PHẠM HÀNH CHÍNH',
  penalty_decision: 'QUYẾT ĐỊNH XỬ PHẠT VI PHẠM HÀNH CHÍNH',
  tmpl_quyet_dinh_xu_phat: 'QUYẾT ĐỊNH XỬ PHẠT VI PHẠM HÀNH CHÍNH',
  penalty_submission: 'TỜ TRÌNH ĐỀ NGHỊ BAN HÀNH QUYẾT ĐỊNH XỬ PHẠT',
  tmpl_to_trinh_xu_phat: 'TỜ TRÌNH ĐỀ NGHỊ BAN HÀNH QUYẾT ĐỊNH XỬ PHẠT',
  tmpl_to_trinh_ubnd_quan: 'TỜ TRÌNH ỦY BAN NHÂN DÂN QUẬN',
  to_trinh_ubnd: 'TỜ TRÌNH ỦY BAN NHÂN DÂN QUẬN',
  to_trinh_xu_phat: 'TỜ TRÌNH ĐỀ NGHỊ BAN HÀNH QUYẾT ĐỊNH XỬ PHẠT',
  remediation_request: 'BÁO CÁO KẾT QUẢ KHẮC PHỤC HẬU QUẢ VI PHẠM MÔI TRƯỜNG',
  tmpl_bao_cao_khac_phuc: 'BÁO CÁO KẾT QUẢ KHẮC PHỤC HẬU QUẢ VI PHẠM MÔI TRƯỜNG',
  verification_record: 'BIÊN BẢN XÁC MINH PHẢN ÁNH Ô NHIỄM BỤI',
  tmpl_bien_ban_xac_minh: 'BIÊN BẢN XÁC MINH PHẢN ÁNH Ô NHIỄM BỤI',
  inter_agency_transfer: 'PHIẾU CHUYỂN HỒ SƠ VI PHẠM MÔI TRƯỜNG',
  tmpl_phieu_chuyen_ho_so: 'PHIẾU CHUYỂN HỒ SƠ VI PHẠM MÔI TRƯỜNG',
  suspension_record: 'BIÊN BẢN TẠM ĐÌNH CHỈ HOẠT ĐỘNG PHÁT TÁN BỤI',
  tmpl_bien_ban_tam_dinh_chi: 'BIÊN BẢN TẠM ĐÌNH CHỈ HOẠT ĐỘNG PHÁT TÁN BỤI',
  evidence_handover: 'BIÊN BẢN BÀN GIAO DỮ LIỆU CHỨNG CỨ QUAN TRẮC',
  tmpl_bien_ban_ban_giao_tang_vat: 'BIÊN BẢN BÀN GIAO DỮ LIỆU CHỨNG CỨ QUAN TRẮC',
  acceptance_record: 'BIÊN BẢN NGHIỆM THU KẾT QUẢ KHẮC PHỤC MÔI TRƯỜNG',
  tmpl_bien_ban_nghiem_thu: 'BIÊN BẢN NGHIỆM THU KẾT QUẢ KHẮC PHỤC MÔI TRƯỜNG',
  BIEN_BAN_KIEM_TRA_HIEN_TRUONG: 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH',
  BIEN_BAN_XAC_MINH_PHAN_ANH: 'BIÊN BẢN XÁC MINH PHẢN ÁNH',
  BIEN_BAN_VI_PHAM_HANH_CHINH: 'BIÊN BẢN VI PHẠM HÀNH CHÍNH',
  BIEN_BAN_VI_PHAM_HÀNH_CHÍNH: 'BIÊN BẢN VI PHẠM HÀNH CHÍNH',
  case_summary: 'BÁO CÁO TÓM TẮT VỤ VIỆC',
  summary_report: 'BÁO CÁO TÓM TẮT VỤ VIỆC',
  executive_brief: 'BÁO CÁO NHANH PHỤC VỤ ĐIỀU HÀNH'
};

function stripUnsafeMarkup(value) {
  return sanitizeHtmlContent(value).replace(/<[^>]+>/g, '');
}

function safeText(value, fallback = '') {
  if (value === null || value === undefined) return fallback;
  if (typeof value === 'object') return fallback;

  const cleaned = stripUnsafeMarkup(value)
    .replace(/\b(undefined|null|NaN)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  return cleaned || fallback;
}

function firstText(...values) {
  for (const value of values) {
    const cleaned = safeText(value);
    if (cleaned) return cleaned;
  }
  return '';
}

function normalizeList(value, fallback) {
  if (!Array.isArray(value)) return fallback;
  const items = value.map(item => safeText(item)).filter(Boolean);
  return items.length ? items : fallback;
}

function formatVietnameseDate(value) {
  if (value) {
    const isoMatch = String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (isoMatch) {
      const [, year, month, day] = isoMatch;
      return `ngày ${Number(day)} tháng ${Number(month)} năm ${Number(year)}`;
    }

    const dateValue = new Date(value);
    if (!Number.isNaN(dateValue.getTime())) {
      return `ngày ${dateValue.getDate()} tháng ${dateValue.getMonth() + 1} năm ${dateValue.getFullYear()}`;
    }
  }

  const now = new Date();
  return `ngày ${now.getDate()} tháng ${now.getMonth() + 1} năm ${now.getFullYear()}`;
}

/**
 * Parses raw content (HTML/Markdown) into AST block nodes using document-docx-parser
 */
export function parseDraftContent(content) {
  const sanitized = sanitizeHtmlContent(content || '');
  const ast = parseContentToAST(sanitized);

  if (!ast || !ast.length) {
    return [{
      type: 'paragraph',
      text: 'Nội dung dự thảo chưa có dữ liệu. Cán bộ phụ trách cần bổ sung và rà soát trước khi sử dụng.'
    }];
  }

  return ast;
}

/**
 * Builds a structured model for official DOCX generation.
 */
export function buildOfficialDocumentModel(input = {}) {
  const { mode, draft_document = {}, organization = {}, officer = {}, metadata = {} } = input;
  const template = firstText(mode, draft_document.document_type, 'corrective_notice');
  const receivingPlaces = normalizeList(
    metadata.recipients || metadata.receiving_places,
    ['Như trên', 'Tổ kiểm tra môi trường', 'Lưu: VT']
  );

  const rawContent = draft_document.content || draft_document.body_markdown || '';

  return {
    organization_name: safeText(
      firstText(organization.parent, organization.organization_name, 'ỦY BAN NHÂN DÂN QUẬN/HUYỆN')
    ),
    department_name: safeText(
      firstText(organization.name, organization.department_name, 'ỦY BAN NHÂN DÂN PHƯỜNG/XÃ')
    ),
    document_number: safeText(
      firstText(metadata.document_number, organization.document_number, 'Số: .../TB-DG')
    ),
    location: safeText(firstText(metadata.location, organization.location, 'Hà Nội')),
    date: formatVietnameseDate(metadata.issue_date),
    title: DOCUMENT_TITLES[template] || DOCUMENT_TITLES.corrective_notice,
    recipient: safeText(firstText(metadata.recipient, 'Đơn vị thi công/chủ đầu tư công trình')),
    review_note: ['APPROVED', 'EXPORTED', 'SIGNED'].includes(draft_document.status)
      ? ''
      : 'Văn bản này là bản dự thảo hỗ trợ nghiệp vụ; cán bộ có thẩm quyền cần rà soát, chỉnh sửa và xác nhận trước khi ban hành hoặc sử dụng chính thức.',
    body_sections: parseDraftContent(rawContent),
    receiving_places: receivingPlaces,
    signer_title: safeText(
      firstText(officer.signer_title, metadata.signer_title, officer.title, 'NGƯỜI KÝ')
    ),
    signer_name: safeText(
      firstText(officer.signer, metadata.signer_name, officer.name, '')
    )
  };
}

function noBorder() {
  return { style: BorderStyle.NONE, size: 0, color: 'auto' };
}

function borderlessTableBorders() {
  return {
    top: noBorder(),
    bottom: noBorder(),
    left: noBorder(),
    right: noBorder(),
    insideHorizontal: noBorder(),
    insideVertical: noBorder()
  };
}

function textRun(text, options = {}) {
  return new TextRun({
    text: safeText(text),
    font: FONT,
    size: options.size || BODY_SIZE,
    bold: options.bold,
    italics: options.italics
  });
}

function createHeaderTable(model) {
  return new Table({
    width: { size: ND30_PRINTABLE_WIDTH_DXA, type: WidthType.DXA },
    columnWidths: [HEADER_COL1_WIDTH, HEADER_COL2_WIDTH],
    layout: TableLayoutType.FIXED,
    borders: borderlessTableBorders(),
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: HEADER_COL1_WIDTH, type: WidthType.DXA },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40, line: 240 },
                children: [textRun(model.organization_name, { size: 24 })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40, line: 240 },
                children: [textRun(model.department_name, { size: 24, bold: true })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40, line: 240 },
                children: [textRun('-------', { size: 24 })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 40, after: 0, line: 240 },
                children: [textRun(model.document_number, { size: 24 })]
              })
            ]
          }),
          new TableCell({
            width: { size: HEADER_COL2_WIDTH, type: WidthType.DXA },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40, line: 240 },
                children: [textRun('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM', { size: 24, bold: true })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40, line: 240 },
                children: [textRun('Độc lập - Tự do - Hạnh phúc', { size: 26, bold: true })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 80, line: 240 },
                children: [textRun('-----------------------', { size: 26 })]
              }),
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                spacing: { before: 80, after: 0, line: 240 },
                children: [textRun(`${model.location}, ${model.date}`, { italics: true })]
              })
            ]
          })
        ]
      })
    ]
  });
}

function createFooterTable(model) {
  return new Table({
    width: { size: ND30_PRINTABLE_WIDTH_DXA, type: WidthType.DXA },
    columnWidths: [FOOTER_COL1_WIDTH, FOOTER_COL2_WIDTH],
    layout: TableLayoutType.FIXED,
    borders: borderlessTableBorders(),
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: FOOTER_COL1_WIDTH, type: WidthType.DXA },
            children: [
              new Paragraph({
                spacing: { before: 0, after: 40 },
                children: [textRun('Nơi nhận:', { size: 24, bold: true, italics: true })]
              }),
              ...model.receiving_places.map(place => new Paragraph({
                spacing: { before: 0, after: 20 },
                children: [textRun(`- ${place}`, { size: 22 })]
              }))
            ]
          }),
          new TableCell({
            width: { size: FOOTER_COL2_WIDTH, type: WidthType.DXA },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 40 },
                children: [textRun(model.signer_title, { bold: true })]
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 120 },
                children: [textRun('(Ký, ghi rõ họ tên và đóng dấu)', { size: 24, italics: true })]
              }),
              ...(!model.review_note ? [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 80, after: 40 },
                  children: [
                    new TextRun({
                      text: '[ĐÃ KÝ SỐ CA - DUSTGUARD VN]',
                      font: FONT,
                      size: 20,
                      bold: true,
                      color: '0052CC'
                    })
                  ]
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 80 },
                  children: [
                    new TextRun({
                      text: `Ký bởi: ${model.signer_name} | ${model.date}`,
                      font: FONT,
                      size: 18,
                      italics: true,
                      color: '0052CC'
                    })
                  ]
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 40, after: 200 },
                  children: [
                    new TextRun({
                      text: '[🔴 ĐÃ ĐÓNG DẤU ĐỎ - SỞ TÀI NGUYÊN & MÔI TRƯỜNG]',
                      font: FONT,
                      size: 20,
                      bold: true,
                      color: '9F241F'
                    })
                  ]
                })
              ] : [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 500 },
                  children: [textRun('', { size: 24 })]
                })
              ]),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 0 },
                children: [textRun(model.signer_name, { bold: true })]
              })
            ]
          })
        ]
      })
    ]
  });
}

/**
 * Generates a formal Vietnamese administrative document using docx.
 */
export async function generateOfficialDocx(rawModel) {
  const model = rawModel && Array.isArray(rawModel.receiving_places) ? rawModel : buildOfficialDocumentModel(rawModel);
  const children = [
    createHeaderTable(model),
    new Paragraph({ text: '', spacing: { after: 200 } }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [textRun(model.title, { size: 30, bold: true })],
      spacing: { before: 120, after: 200 }
    }),
    new Paragraph({ text: '', spacing: { after: 120 } })
  ];

  if (model.recipient) {
    children.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        textRun('Kính gửi: ', { italics: true }),
        textRun(model.recipient, { bold: true })
      ],
      spacing: { after: 200 }
    }));
  }

  if (model.review_note) {
    children.push(new Paragraph({
      children: [textRun(model.review_note, { size: 24, italics: true })],
      alignment: AlignmentType.JUSTIFIED,
      indent: { firstLine: 708 },
      spacing: { after: 200 }
    }));
  }

  // Build body elements natively using document-docx-parser
  const bodyElements = buildDocxElementsFromAST(model.body_sections || [], docx);
  children.push(...bodyElements);

  children.push(new Paragraph({ text: '', spacing: { after: 400 } }));
  children.push(createFooterTable(model));

  const doc = new Document({
    sections: [{
      properties: {
        page: {
          margin: {
            top: 1134,    // 20mm in dxa
            bottom: 1134, // 20mm
            left: 1701,   // 30mm
            right: 850,   // 15mm
          }
        }
      },
      children
    }]
  });

  return Packer.toBuffer(doc);
}

export const generateOfficialDocxBuffer = generateOfficialDocx;
