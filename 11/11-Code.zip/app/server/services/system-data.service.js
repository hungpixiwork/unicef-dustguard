import { previewResetCounts, purgeOperationalData, getSystemDataStats } from '../repositories/system.repository.js';
import { createSite } from '../repositories/site.repository.js';
import { createComplaint } from '../repositories/complaint.repository.js';
import { createCase } from '../repositories/case.repository.js';
import { createEvidence } from '../repositories/evidence.repository.js';
import { createAuditLog } from '../repositories/audit.repository.js';
import { calculatePriorityScore } from '../../src/lib/priority/priorityScoreEngine.js';

const REQUIRED_RESET_CONFIRMATION = 'RESET DUSTGUARD DATA';

/**
 * Validates reset authorization and confirmation safeguards
 */
export function validateResetGuard(body = {}, actor = {}) {
  const confirmation = (body.confirmation || '').trim();
  if (confirmation !== REQUIRED_RESET_CONFIRMATION) {
    return {
      allowed: false,
      statusCode: 400,
      code: 'INVALID_CONFIRMATION',
      message: `Chuỗi xác nhận không hợp lệ. Vui lòng nhập chính xác "${REQUIRED_RESET_CONFIRMATION}" để tiếp tục.`
    };
  }

  // Actor authorization check
  const role = actor.role || 'citizen';
  if (role !== 'admin' && role !== 'staff' && role !== 'executive') {
    return {
      allowed: false,
      statusCode: 403,
      code: 'UNAUTHORIZED_RESET',
      message: 'Bạn không có quyền thực hiện thao tác xóa và thiết lập lại dữ liệu hệ thống.'
    };
  }

  return { allowed: true };
}

/**
 * Service to execute guarded system reset
 */
export async function executeSystemReset({ mode = 'EMPTY', deleteStoredFiles = false, confirmation, actor = {}, env = null }) {
  const guard = validateResetGuard({ confirmation }, actor);
  if (!guard.allowed) {
    const err = new Error(guard.message);
    err.statusCode = guard.statusCode;
    err.code = guard.code;
    throw err;
  }

  // 1. Delete R2 Storage Objects if requested and environment supports it
  let purgedFilesCount = 0;
  if (deleteStoredFiles && env) {
    const bucket = env.STORAGE || env.EVIDENCE_BUCKET;
    if (bucket && typeof bucket.list === 'function' && typeof bucket.delete === 'function') {
      try {
        const listed = await bucket.list({ limit: 500 });
        if (listed && Array.isArray(listed.objects)) {
          for (const obj of listed.objects) {
            await bucket.delete(obj.key);
            purgedFilesCount++;
          }
        }
      } catch (e) {
        console.warn('R2 Purge warning:', e.message);
      }
    }
  }

  // 2. Purge Operational Data in strict FK order
  const purgeResult = await purgeOperationalData({ mode, deleteStoredFiles, actor }, env);

  // 3. If mode is RESET_AND_SEED, populate canonical dataset
  let seedSummary = null;
  if (mode === 'RESET_AND_SEED') {
    seedSummary = await seedCanonicalData({ actor, env });
  }

  return {
    success: true,
    mode,
    deletedCounts: purgeResult.deletedCounts,
    purgedFilesCount,
    seedSummary,
    timestamp: new Date().toISOString()
  };
}

/**
 * Seeds Canonical Demo Dataset with real domain priority calculation
 */
export async function seedCanonicalData({ actor = {}, env = null }) {
  // 1. Create Core Sites
  const siteA = await createSite({
    name: 'Khu phức hợp Căn hộ Cao cấp Emerald Prime',
    code: 'BD-0420',
    address: 'Đại lộ Bình Dương, Phường Phú Hòa, TP. Thủ Dầu Một',
    ward: 'Phường Phú Hòa',
    province: 'Bình Dương',
    coordinates: '10.9785,106.6698',
    status: 'ACTIVE',
    investorName: 'Tập đoàn Phát triển Đô thị Emerald',
    contractorName: 'Tổng Công ty Xây dựng Tân Á',
    managerName: 'Trần Văn Mạnh',
    managerPhone: '0912345678'
  }, actor, env);

  const siteB = await createSite({
    name: 'Dự án Cải tạo Thoát nước & Đường ĐT743',
    code: 'BD-0237',
    address: 'Đường ĐT743, Phường An Phú, TP. Thuận An',
    ward: 'Phường An Phú',
    province: 'Bình Dương',
    coordinates: '10.9124,106.7211',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Dự án Giao thông Tỉnh',
    contractorName: 'Công ty CP Cầu đường Đại Việt',
    managerName: 'Lê Hoàng Nam',
    managerPhone: '0987654321'
  }, actor, env);

  const siteC = await createSite({
    name: 'Cụm Công trình Nhà xưởng KCN Sóng Thần 2',
    code: 'BD-0891',
    address: 'Đường số 6, KCN Sóng Thần 2, Phường Dĩ An, TP. Dĩ An',
    ward: 'Phường Dĩ An',
    province: 'Bình Dương',
    coordinates: '10.8932,106.7456',
    status: 'ACTIVE',
    investorName: 'Công ty TNHH Tiếp vận Sóng Thần',
    contractorName: 'Công ty Xây dựng Miền Đông',
    managerName: 'Vũ Quốc Bảo',
    managerPhone: '0903112233'
  }, actor, env);

  const siteVD1 = await createSite({
    id: 'site-vd1-001',
    name: 'Công trường Dự án Đường Vành đai 3 trên cao',
    code: 'site-vd1',
    address: 'Đường Vành đai 3, Phường Mai Dịch, Cầu Giấy, Hà Nội',
    ward: 'Mai Dịch',
    province: 'Hà Nội',
    coordinates: '21.0385,105.7782',
    dustRiskScore: 92,
    riskLevel: 'CRITICAL',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Dự án Đầu tư Xây dựng Công trình Giao thông TP Hà Nội',
    contractorName: 'Tổng Công ty Xây dựng Công trình Giao thông 1 (Cienco 1)',
    licenseNumber: 'GPXD-2024/0089/SXD',
    managerName: 'Nguyễn Văn Cương',
    managerPhone: '0912345678',
    managerEmail: 'cuongnv.site@hanoi-transport.gov.vn'
  }, actor, env);

  // 2. Create Complaints with Evidences
  const complaint1 = await createComplaint({
    siteId: siteA.id,
    ward: 'Phường Phú Hòa',
    address: 'Số 124 Đại lộ Bình Dương (đối diện công trình)',
    description: 'Bụi phát tán mù mịt từ sáng đến trưa, công trình không che chắn bạt phía tiếp giáp trường Mầm non Hoa Mai. Trẻ em xung quanh ho nhiều.',
    reporterName: 'Nguyễn Thị Thu Hà',
    reporterPhone: '0934112233',
    status: 'PROCESSING',
    priority: 'HIGH'
  }, actor, env);

  await createEvidence({
    url: '/uploads/evidence-seed-1.jpg',
    type: 'IMAGE',
    filename: 'bui_cong_trinh_emerald_1.jpg',
    sha256: '9f99e2550f20bb4b3210aa887766554433221100aabbccddeeff001122334455',
    complaintId: complaint1.id
  }, actor, env);

  const complaint2 = await createComplaint({
    siteId: siteB.id,
    ward: 'Phường An Phú',
    address: 'Ngã tư Miếu Ông Cù - ĐT743',
    description: 'Xe chở đất đá không phủ bạt làm rơi vãi đầy mặt đường gây bụi mờ tầm nhìn, không có xe bồn tưới nước dập bụi.',
    reporterName: 'Trần Đình Trọng',
    reporterPhone: '0918776655',
    status: 'PENDING',
    priority: 'CRITICAL'
  }, actor, env);

  const complaint3 = await createComplaint({
    siteId: siteVD1.id,
    ward: 'Mai Dịch',
    address: 'Số 18 Phạm Hùng (đối diện công trình Vành đai 3)',
    description: 'Xe tải chở đất đá rơi vãi mù mịt, công trường thi công giờ trưa gây rung lắc và bụi mịn phơi nhiễm vào khu dân cư.',
    reporterName: 'Nguyễn Thị Thu Hà',
    reporterPhone: '0934112233',
    status: 'PROCESSING',
    priority: 'CRITICAL'
  }, actor, env);

  const complaint4 = await createComplaint({
    siteId: siteC.id,
    ward: 'Phường Dĩ An',
    address: 'Đường số 6, KCN Sóng Thần 2',
    description: 'Phát tán bụi và khói hàn kim loại nồng nặc ra đường dân sinh ngoài cổng nhà xưởng, không có hệ thống hút lọc.',
    reporterName: 'Lê Văn Bình',
    reporterPhone: '0908889900',
    status: 'PROCESSING',
    priority: 'CRITICAL'
  }, actor, env);

  const complaint5 = await createComplaint({
    siteId: siteVD1.id,
    ward: 'Mai Dịch',
    address: 'Đường Hồ Tùng Mậu giao Vành đai 3',
    description: 'Cát xây dựng rơi vãi gây trơn trượt và bụi mù mịt khi xe chạy qua.',
    reporterName: 'Trần Minh Tâm',
    reporterPhone: '0977223344',
    status: 'RESOLVED',
    priority: 'MEDIUM'
  }, actor, env);

  // 3. Create Canonical Cases with 7-step Status Flow & Real Diversity
  const now = new Date();
  const plus44h = new Date(now.getTime() + 44 * 3600 * 1000).toISOString();
  const minus18h = new Date(now.getTime() - 18 * 3600 * 1000).toISOString();
  const plus20h = new Date(now.getTime() + 20 * 3600 * 1000).toISOString();
  const minus3d = new Date(now.getTime() - 72 * 3600 * 1000).toISOString();

  // Case 1: Đang thẩm tra vi phạm hiện trường (VIOLATED / SURVEY)
  const case1 = await createCase({
    siteId: siteA.id,
    complaintId: complaint1.id,
    code: 'CASE-2026-0042',
    title: 'Xử lý vi phạm bụi mù mịt công trình Emerald Prime tiếp giáp trường mầm non',
    description: 'Báo cáo cộng đồng về phát tán bụi vượt ngưỡng, thiếu lưới chắn bụi QCVN 18:2021',
    status: 'VIOLATED',
    priority: 'HIGH',
    assignedTo: 'usr-staff-01',
    slaDeadline: plus44h,
    sourceType: 'COMPLAINT',
    sourceId: complaint1.id
  }, actor, env);

  // Case 2: Cán bộ đang ở hiện trường kiểm tra (ON_SITE / INSPECTION)
  const case2 = await createCase({
    siteId: siteVD1.id,
    complaintId: complaint3.id,
    code: 'DG-CASE-2026-001',
    title: 'Kiểm tra hiện trường vi phạm bụi công trình Đường Vành đai 3 trên cao',
    description: 'Cảm biến SEN-VD1-01 ghi nhận PM10 liên tục > 185 µg/m³. Tiếp nhận phản ánh công dân DG-2026-F54A.',
    status: 'ON_SITE',
    priority: 'CRITICAL',
    assignedTo: 'usr-staff-01',
    slaDeadline: plus20h,
    sourceType: 'COMPLAINT',
    sourceId: complaint3.id
  }, actor, env);

  // Case 3: Vụ việc MỚI tiếp nhận - Chưa phân công cán bộ (NEW / OPEN) - Dành cho Admin điều phối
  const case3 = await createCase({
    siteId: siteB.id,
    complaintId: complaint2.id,
    code: 'CASE-2026-0101',
    title: 'Vụ việc mới: Bụi đất đá rơi vãi mù mịt thi công đường ĐT743',
    description: 'Phản ánh người dân về xe chở vật liệu không phủ bạt, mặt đường bụi mờ tầm nhìn.',
    status: 'OPEN',
    priority: 'HIGH',
    assignedTo: null,
    slaDeadline: plus44h,
    sourceType: 'COMPLAINT',
    sourceId: complaint2.id
  }, actor, env);

  // Case 4: Vụ việc QUÁ HẠN SLA (OVERDUE) - Cảnh báo khẩn cấp trên Dashboard
  const case4 = await createCase({
    siteId: siteC.id,
    complaintId: complaint4.id,
    code: 'CASE-2026-0089',
    title: 'Cảnh báo quá hạn: Phát tán bụi và hạt kim loại tại KCN Sóng Thần 2',
    description: 'Quá thời hạn SLA khắc phục 24 giờ. Nhà xưởng chưa gửi phương án xử lý bụi và khói hàn.',
    status: 'IN_PROGRESS',
    priority: 'CRITICAL',
    assignedTo: 'usr-staff-01',
    slaDeadline: minus18h,
    sourceType: 'COMPLAINT',
    sourceId: complaint4.id
  }, actor, env);

  // Case 5: Vụ việc ĐANG YÊU CẦU NHÀ THẦU KHẮC PHỤC (RECTIFYING / EXPLAINING)
  const case5 = await createCase({
    siteId: siteA.id,
    complaintId: complaint1.id,
    code: 'CASE-2026-0055',
    title: 'Nhà thầu Tân Á đang khắc phục: Lắp đặt trạm rửa lốp xe và phun sương',
    description: 'Đã lập biên bản kiểm tra, nhà thầu đang bố trí bạt phủ và xe bồn tưới ẩm theo cam kết.',
    status: 'RECTIFYING',
    priority: 'MEDIUM',
    assignedTo: 'usr-staff-01',
    slaDeadline: plus20h,
    sourceType: 'COMPLAINT',
    sourceId: complaint1.id
  }, actor, env);

  // Case 6: Vụ việc ĐÃ HOÀN TẤT & ĐÓNG (CLOSED) - Có đầy đủ ảnh Before/After và đánh giá của dân
  const case6 = await createCase({
    siteId: siteVD1.id,
    complaintId: complaint5.id,
    code: 'CASE-2026-0030',
    title: 'Đã giải quyết: Thu dọn cát tràn và quét rửa mặt đường Mai Dịch',
    description: 'Nhà thầu Cienco 1 đã quét dọn toàn bộ cát rơi vãi và tưới nước dập bụi. Cán bộ đã phúc tra đạt yêu cầu.',
    status: 'CLOSED',
    priority: 'MEDIUM',
    assignedTo: 'usr-staff-01',
    slaDeadline: minus3d,
    sourceType: 'COMPLAINT',
    sourceId: complaint5.id
  }, actor, env);

  // 4. Calculate real Priority Score using CPS v1 Engine and update Site
  const scoreResult = calculatePriorityScore({
    reports: [complaint1],
    evidences: [{ type: 'IMAGE', hasGps: true, hasHmac: true }],
    sensitiveZone: { type: 'school', distance: 120, name: 'Trường Mầm non Hoa Mai' },
    checklist: { barrier: 'fail', spray: 'fail', washStation: 'pass' },
    history: { violationCount: 2, repeatOffender: true }
  });

  // Persist computed score to Site
  const client = (env && env.site) ? env : (env ? (await import('../shared/db.js')).getDbClient(env) : (await import('../shared/db.js')).prisma);
  await client.site.update({
    where: { id: siteA.id },
    data: {
      dustRiskScore: scoreResult.priorityScore,
      riskLevel: scoreResult.priorityLevel
    }
  });

  // 5. Seed Sensors & Sensor Readings & Evidences
  try {
    const rawDb = (await import('../shared/db.js')).getD1OrSqlite(env);
    if (rawDb && typeof rawDb.prepare === 'function') {
      const nowIso = new Date().toISOString();

      // Seed Users if not exist
      await rawDb.prepare(`
        INSERT OR IGNORE INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt)
        VALUES 
          ('usr-admin-01', 'Nguyễn Quản Trị', 'admin@dustguard.vn', 1, 'admin', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('usr-staff-01', 'Lê Thanh Tra', 'staff@dustguard.vn', 1, 'staff', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('usr-contractor-01', 'Trần Chỉ Huy (Tân Á)', 'contractor@tana.vn', 1, 'contractor', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('usr-executive-01', 'Phạm Lãnh Đạo', 'executive@dustguard.vn', 1, 'executive', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('usr-citizen-01', 'Nguyễn Thị Thu Hà', 'citizen@gmail.com', 1, 'citizen', 'ACTIVE', '${nowIso}', '${nowIso}')
      `).run().catch(() => {});

      // Insert sensors if not exist
      await rawDb.prepare(`
        INSERT OR IGNORE INTO sensors (id, name, code, siteId, status, createdAt, updatedAt)
        VALUES 
          ('sen-01', 'Cảm biến Quang học Vành Đai - Trạm Bắc', 'SEN-VD1-01', '${siteVD1.id}', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('sen-02', 'Cảm biến PM10 Vành Đai - Trạm Nam', 'SEN-VD1-02', '${siteVD1.id}', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('sen-03', 'Cảm biến Cổng Chính Emerald Prime', 'SEN-EP-01', '${siteA.id}', 'ACTIVE', '${nowIso}', '${nowIso}'),
          ('sen-04', 'Cảm biến Đường ĐT743', 'SEN-DT-01', '${siteB.id}', 'ACTIVE', '${nowIso}', '${nowIso}')
      `).run().catch(() => {});

      // Insert sensor readings
      await rawDb.prepare(`
        INSERT OR IGNORE INTO sensor_readings (id, sensorId, pm10, pm25, timestamp)
        VALUES 
          ('rd-01', 'sen-01', 185.5, 92.4, '${nowIso}'),
          ('rd-02', 'sen-01', 178.2, 88.6, datetime('${nowIso}', '-10 minutes')),
          ('rd-03', 'sen-01', 190.0, 95.1, datetime('${nowIso}', '-20 minutes')),
          ('rd-04', 'sen-02', 162.0, 78.0, '${nowIso}'),
          ('rd-05', 'sen-03', 45.0, 22.0, '${nowIso}'),
          ('rd-06', 'sen-04', 110.0, 55.0, '${nowIso}')
      `).run().catch(() => {});

      // Insert sample Alert
      await rawDb.prepare(`
        INSERT OR IGNORE INTO alerts (id, siteId, sensorId, pm10Value, triggeredAt, slaDeadline, status, createdAt, updatedAt)
        VALUES 
          ('alt-vd1-01', '${siteVD1.id}', 'sen-01', 185.5, '${nowIso}', datetime('${nowIso}', '+24 hours'), 'PENDING', '${nowIso}', '${nowIso}')
      `).run().catch(() => {});

      // Insert sample Inspection with Checklist findings
      const sampleChecklist = {
        barrier: 'fail',
        spray: 'fail',
        cover: 'fail',
        wheel: 'pass',
        spill: 'fail',
        demo: 'fail',
        hours: 'pass',
        gate: 'pass',
        height: 'pass',
        signage: 'pass'
      };
      await rawDb.prepare(`
        INSERT OR IGNORE INTO inspections (id, siteId, inspectorId, findings, actionTaken, scoreDelta, createdAt, updatedAt)
        VALUES 
          ('ins-vd1-01', '${siteVD1.id}', 'usr-staff-01', '${JSON.stringify(sampleChecklist)}', 'Lập biên bản vi phạm và yêu cầu tạm dừng hạng mục phát tán bụi', 15, '${nowIso}', '${nowIso}')
      `).run().catch(() => {});

      // Insert sample Actions
      await rawDb.prepare(`
        INSERT OR IGNORE INTO actions (id, title, description, status, siteId, caseId, inspectionId, assignee, dueDate, createdAt, updatedAt)
        VALUES 
          ('act-vd1-01', 'Khắc phục vi phạm: Che chắn công trình và phun nước giảm bụi', 'Yêu cầu lắp đặt lưới chắn bụi tầng cao và bố trí 2 xe bồn tưới ẩm liên tục', 'IN_PROGRESS', '${siteVD1.id}', '${case2.id}', 'ins-vd1-01', 'Cienco 1', datetime('${nowIso}', '+48 hours'), '${nowIso}', '${nowIso}'),
          ('act-ep-02', 'Lắp đặt hệ thống rửa lốp xe tự động tại cổng số 1', 'Đảm bảo 100% xe tải trước khi ra khỏi công trình phải được rửa sạch lốp', 'PENDING', '${siteA.id}', '${case5.id}', null, 'Tổng Công ty Xây dựng Tân Á', datetime('${nowIso}', '+24 hours'), '${nowIso}', '${nowIso}')
      `).run().catch(() => {});

      // Insert Evidences (Before & After) for Case 6 (Closed) and Case 1
      await rawDb.prepare(`
        INSERT OR IGNORE INTO evidences (id, url, type, filename, sha256, complaintId, caseId, createdAt)
        VALUES 
          ('evi-vd1-before', '/images/evidence/before-dust.jpg', 'IMAGE', 'hien_trang_vi_pham_cat_bui.jpg', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', '${complaint5.id}', '${case6.id}', datetime('${nowIso}', '-3 days')),
          ('evi-vd1-after', '/images/evidence/after-cleaned.jpg', 'IMAGE', 'da_quet_rua_sach_se.jpg', 'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e', '${complaint5.id}', '${case6.id}', datetime('${nowIso}', '-1 day'))
      `).run().catch(() => {});
    }
  } catch (iotSeedErr) {
    console.warn('Sensor seed warning:', iotSeedErr.message);
  }

  await createAuditLog({
    action: 'SYSTEM_SEEDED',
    entityType: 'SYSTEM',
    entityId: 'CANONICAL_DATASET',
    actorId: actor.id || 'system_seed_runner',
    actorName: 'Seed Engine',
    actorRole: 'system',
    details: {
      sites: [siteA.id, siteB.id, siteC.id, siteVD1.id],
      complaints: [complaint1.id, complaint2.id, complaint3.id, complaint4.id, complaint5.id],
      cases: [case1.id, case2.id, case3.id, case4.id, case5.id, case6.id],
      computedScore: scoreResult.priorityScore
    }
  }, env);

  return {
    sitesCreated: 4,
    complaintsCreated: 5,
    casesCreated: 6,
    priorityScoreCalculated: scoreResult.priorityScore
  };
}

export { previewResetCounts, getSystemDataStats };
