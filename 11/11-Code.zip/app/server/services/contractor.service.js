import { getD1OrSqlite, prisma } from '../shared/db.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { logCaseEvent } from './caseTimelineLogger.js';
import {
  ACTION_STATUS,
  normalizeActionStatus,
  isActionOverdue
} from '../domain/actions/action.rules.js';

/**
 * Calculates Haversine distance in meters between two lat/lng points
 */
export function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return Infinity;
  const nLat1 = Number(lat1);
  const nLon1 = Number(lon1);
  const nLat2 = Number(lat2);
  const nLon2 = Number(lon2);
  if (isNaN(nLat1) || isNaN(nLon1) || isNaN(nLat2) || isNaN(nLon2)) return Infinity;
  if (nLat1 < -90 || nLat1 > 90 || nLat2 < -90 || nLat2 > 90 || nLon1 < -180 || nLon1 > 180 || nLon2 < -180 || nLon2 > 180) return Infinity;

  const R = 6371000; // Earth radius in meters
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(nLat2 - nLat1);
  const dLon = toRad(nLon2 - nLon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(nLat1)) * Math.cos(toRad(nLat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

/**
 * Parses coordinates from string "lat, lng" or object { lat, lng }
 */
export function parseCoordinates(coords) {
  if (!coords) return { lat: null, lng: null };
  if (typeof coords === 'object' && coords.lat != null && coords.lng != null) {
    const lat = Number(coords.lat);
    const lng = Number(coords.lng);
    return {
      lat: !isNaN(lat) && lat >= -90 && lat <= 90 ? lat : null,
      lng: !isNaN(lng) && lng >= -180 && lng <= 180 ? lng : null
    };
  }
  if (typeof coords === 'string') {
    const parts = coords.split(',').map((s) => parseFloat(s.trim()));
    if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      const lat = parts[0];
      const lng = parts[1];
      return {
        lat: lat >= -90 && lat <= 90 ? lat : null,
        lng: lng >= -180 && lng <= 180 ? lng : null
      };
    }
  }
  return { lat: null, lng: null };
}

/**
 * Evaluates whether evidence coordinates are within site geofence buffer
 * Supports both:
 *  - evaluateGeofenceBuffer(contractorLat, contractorLng, siteLat, siteLng, bufferMeters = 50)
 *  - evaluateGeofenceBuffer(siteCoords, evidenceCoords, bufferMeters = 50)
 */
export function evaluateGeofenceBuffer(arg1, arg2, arg3 = 50, arg4, arg5 = 50) {
  let cLat, cLng, sLat, sLng, bufferMeters;

  if (arg4 !== undefined) {
    // (cLat, cLng, sLat, sLng, bufferMeters)
    cLat = Number(arg1);
    cLng = Number(arg2);
    sLat = Number(arg3);
    sLng = Number(arg4);
    bufferMeters = Number(arg5) || 50;
  } else {
    // (siteCoords, evidenceCoords, bufferMeters)
    const site = parseCoordinates(arg1);
    const evidence = parseCoordinates(arg2);
    sLat = site.lat;
    sLng = site.lng;
    cLat = evidence.lat;
    cLng = evidence.lng;
    bufferMeters = Number(arg3) || 50;
  }

  if (isNaN(cLat) || isNaN(cLng) || isNaN(sLat) || isNaN(sLng) ||
      cLat < -90 || cLat > 90 || cLng < -180 || cLng > 180 ||
      sLat < -90 || sLat > 90 || sLng < -180 || sLng > 180) {
    return {
      valid: false,
      within50m: false,
      distanceMeters: Infinity,
      allowedBufferMeters: bufferMeters,
      maxAllowedMeters: bufferMeters,
      matchStatus: 'OUT_OF_BOUNDS',
      status: 'OUT_OF_BOUNDS',
      message: 'Vị trí ngoài ranh giới: Tọa độ không hợp lệ hoặc nằm ngoài phạm vi địa lý.',
      contractorCoords: { lat: cLat, lng: cLng },
      siteCoords: { lat: sLat, lng: sLng },
      siteLocation: { lat: sLat, lng: sLng },
      evidenceLocation: { lat: cLat, lng: cLng }
    };
  }

  const distanceMeters = calculateHaversineDistance(cLat, cLng, sLat, sLng);
  const valid = distanceMeters <= bufferMeters;

  let matchStatus = 'OUT_OF_BOUNDS';
  let message = '';

  if (valid) {
    matchStatus = 'VALID_50M_BUFFER';
    message = `Vị trí hợp lệ: Cách công trình ${distanceMeters}m (Trong phạm vi ${bufferMeters}m buffer)`;
  } else if (distanceMeters <= bufferMeters * 2) {
    matchStatus = 'NEARBY_WARNING';
    message = `Vị trí cảnh báo: Cách công trình ${distanceMeters}m (Vượt quá ${bufferMeters}m buffer)`;
  } else {
    matchStatus = 'OUT_OF_BOUNDS';
    message = `Vị trí ngoài ranh giới: Cách công trình ${distanceMeters}m`;
  }

  return {
    valid,
    within50m: valid,
    distanceMeters,
    allowedBufferMeters: bufferMeters,
    maxAllowedMeters: bufferMeters,
    matchStatus,
    status: matchStatus,
    message,
    contractorCoords: { lat: cLat, lng: cLng },
    siteCoords: { lat: sLat, lng: sLng },
    siteLocation: { lat: sLat, lng: sLng },
    evidenceLocation: { lat: cLat, lng: cLng }
  };
}

function generateId(prefix = 'id') {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID().replace(/-/g, '').substring(0, 12)}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
}

/**
 * Standard 10-item Construction Environmental Compliance Checklist
 */
export const CONTRACTOR_COMPLIANCE_CRITERIA = [
  {
    key: 'cover_material',
    title: 'Che phủ bạt đống vật liệu rời',
    requirement: 'Đống cát, đá, đất thải, xi măng phải được che phủ bạt kín chống phát tán bụi',
    standard: 'QCVN 05:2023/BTNMT & NĐ 45/2022/NĐ-CP',
    category: 'VẬT LIỆU'
  },
  {
    key: 'water_spray',
    title: 'Hệ thống phun sương / Phun nước dập bụi',
    requirement: 'Vận hành súng phun sương hoặc phun nước định kỳ tối thiểu 3 lần/ngày tại đường nội bộ',
    standard: 'Quy chuẩn kỹ thuật quốc gia về môi trường',
    category: 'DẬP BỤI'
  },
  {
    key: 'wheel_washer',
    title: 'Trạm rửa lốp xe tự động tại cổng ra vào',
    requirement: '100% phương tiện vận tải rời công trường phải được xịt rửa sạch bùn đất trên lốp và gầm xe',
    standard: 'Nghị định 16/2022/NĐ-CP (Điều 31)',
    category: 'PHƯƠNG TIỆN'
  },
  {
    key: 'dust_barrier',
    title: 'Hàng rào chắn bụi tiêu chuẩn (>= 2.5m)',
    requirement: 'Hàng rào tôn kín bao quanh toàn bộ ranh giới công trường có chiều cao tối thiểu 2.5m',
    standard: 'QCXDVN 01:2021/BXD',
    category: 'HÀNG RÀO'
  },
  {
    key: 'covered_transport',
    title: 'Xe chở vật liệu che chắn kín bạt',
    requirement: 'Thùng xe chở đất cát, phế thải phải có bạt che kín khít, không để rơi vãi xuống lòng đường',
    standard: 'Luật Giao thông đường bộ & NĐ 100/2019/NĐ-CP',
    category: 'PHƯƠNG TIỆN'
  },
  {
    key: 'waste_collection',
    title: 'Thu gom phế thải xây dựng định kỳ',
    requirement: 'Chất thải rắn xây dựng được tập kết đúng nơi quy định và vận chuyển xử lý trong 24h',
    standard: 'Luật Bảo vệ Môi trường 2020',
    category: 'CHẤT THẢI'
  },
  {
    key: 'online_sensor',
    title: 'Giám sát nồng độ bụi trực tuyến (IoT Sensor)',
    requirement: 'Duy trì kết nối cảm biến PM2.5/PM10 hoạt động liên tục 24/7 truyền dữ liệu về hệ thống',
    standard: 'Quy chuẩn DustGuard VN IoT Node',
    category: 'CẢM BIẾN'
  },
  {
    key: 'env_logbook',
    title: 'Nhật ký nhật trình bảo vệ môi trường',
    requirement: 'Ghi chép và cập nhật đầy đủ ca làm việc, thời gian phun ẩm, nhật trình vệ sinh công trường',
    standard: 'Thông tư 02/2022/TT-BTNMT',
    category: 'HỒ SƠ'
  },
  {
    key: 'safety_warning_signs',
    title: 'Biển báo cảnh báo an toàn & môi trường',
    requirement: 'Niêm yết thông tin dự án, số điện thoại đường dây nóng phản ánh ô nhiễm tại cổng chính',
    standard: 'TCVN 5308:1991',
    category: 'BIỂN BÁO'
  },
  {
    key: 'emergency_response_plan',
    title: 'Kế hoạch ứng phó sự cố phát tán bụi khẩn cấp',
    requirement: 'Có quy trình và trang thiết bị sẵn sàng kích hoạt khi nồng độ PM2.5 vượt ngưỡng cảnh báo đỏ',
    standard: 'Phương án BVMT dự án được phê duyệt',
    category: 'ỨNG PHÓ KHẨN CẤP'
  }
];

export class ContractorService {
  /**
   * Helper: Resolve authorized site IDs for tenant isolation
   */
  static async getAuthorizedSites(user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);

    let allSites = [];
    try {
      const res = await db.prepare('SELECT * FROM sites WHERE deletedAt IS NULL').all();
      allSites = res.results || [];
    } catch {
      allSites = [];
    }

    if (!user) {
      return { sites: allSites, siteIds: allSites.map(s => s.id) };
    }

    const role = (user.role || '').toLowerCase();
    const isElevated = ['admin', 'super_admin', 'demo_admin', 'staff', 'executive', 'inspector'].includes(role);

    if (isElevated) {
      return { sites: allSites, siteIds: allSites.map(s => s.id) };
    }

    // Specific user assigned siteIds
    if (Array.isArray(user.siteIds) && user.siteIds.length > 0) {
      const filtered = allSites.filter(s => user.siteIds.includes(s.id));
      return { sites: filtered, siteIds: filtered.map(s => s.id) };
    }

    // Match contractor name / manager email / manager phone
    const userEmail = (user.email || '').toLowerCase().trim();
    const userPhone = (user.phoneNumber || user.phone || '').trim();
    const contractorName = (user.contractorName || user.company || user.fullName || user.name || '').toLowerCase().trim();

    const matched = allSites.filter(s => {
      const siteContractor = (s.contractorName || '').toLowerCase().trim();
      const siteManagerEmail = (s.managerEmail || '').toLowerCase().trim();
      const siteManagerPhone = (s.managerPhone || '').trim();

      if (userEmail && siteManagerEmail && siteManagerEmail === userEmail) return true;
      if (userPhone && siteManagerPhone && siteManagerPhone === userPhone) return true;
      if (contractorName && siteContractor && (siteContractor.includes(contractorName) || contractorName.includes(siteContractor))) return true;
      return false;
    });

    if (matched.length > 0) {
      return { sites: matched, siteIds: matched.map(s => s.id) };
    }

    if (role === 'citizen') {
      return { sites: [], siteIds: [] };
    }

    // Fallback for contractor demo / generic accounts: return all active sites if no explicit restriction
    if (role === 'contractor' || role === 'demo_contractor') {
      return { sites: allSites, siteIds: allSites.map(s => s.id) };
    }

    return { sites: [], siteIds: [] };
  }

  /**
   * Helper: Assert user has permission to access a specific site
   */
  static async assertSiteAccess(siteId, user, envOrDb) {
    if (!siteId) return true;
    const { siteIds } = await this.getAuthorizedSites(user, envOrDb);
    if (!siteIds.includes(siteId)) {
      const error = new Error(`Truy cập bị từ chối: Bạn không có quyền truy cập công trình ${siteId}`);
      error.statusCode = 403;
      error.code = 'FORBIDDEN';
      throw error;
    }
    return true;
  }

  /**
   * Helper: Format remaining / overdue time string
   */
  static formatTimeRemaining(dueDate) {
    if (!dueDate) return 'Không có hạn chót';
    const due = new Date(dueDate).getTime();
    if (isNaN(due)) return 'Không có hạn chót';

    const now = Date.now();
    const diffMs = due - now;

    if (diffMs < 0) {
      const overdueMins = Math.abs(Math.round(diffMs / (60 * 1000)));
      if (overdueMins < 60) return `Quá hạn ${overdueMins} phút`;
      const overdueHours = Math.floor(overdueMins / 60);
      const remMins = overdueMins % 60;
      if (overdueHours < 24) return `Quá hạn ${overdueHours} giờ ${remMins} phút`;
      const overdueDays = Math.floor(overdueHours / 24);
      return `Quá hạn ${overdueDays} ngày`;
    }

    const mins = Math.round(diffMs / (60 * 1000));
    if (mins < 60) return `Còn ${mins} phút`;
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    if (hours < 24) return `Còn ${hours} giờ ${remMins} phút`;
    const days = Math.floor(hours / 24);
    return `Còn ${days} ngày ${hours % 24} giờ`;
  }

  /**
   * 1. GET /api/contractor/dashboard
   * Returns complete real-time dashboard summary metrics from D1
   */
  static async getDashboardSummary(user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { sites, siteIds } = await this.getAuthorizedSites(user, envOrDb);

    if (siteIds.length === 0) {
      return {
        summary: {
          activeProjects: 0,
          openActions: 0,
          dueSoon: 0,
          overdue: 0,
          underReview: 0,
          completed: 0,
          complianceRate: 100
        },
        riskOverview: {
          score: 0,
          level: 'LOW',
          factors: []
        },
        priorityActions: [],
        projects: []
      };
    }

    // Fetch all actions for authorized sites
    const placeholders = siteIds.map(() => '?').join(',');
    let actions = [];
    try {
      const res = await db.prepare(
        `SELECT a.*, s.name as siteName, s.code as siteCode, s.riskLevel as siteRiskLevel, s.dustRiskScore as siteRiskScore 
         FROM actions a 
         JOIN sites s ON a.siteId = s.id 
         WHERE a.deletedAt IS NULL AND s.deletedAt IS NULL AND a.siteId IN (${placeholders}) 
         ORDER BY a.createdAt DESC`
      ).bind(...siteIds).all();
      actions = res.results || [];
    } catch {
      actions = [];
    }

    const now = Date.now();
    const nowPlus24h = now + 24 * 3600 * 1000;

    let openActions = 0;
    let dueSoon = 0;
    let overdue = 0;
    let underReview = 0;
    let completed = 0;

    for (const a of actions) {
      const status = (a.status || 'PENDING').toUpperCase();
      const dueTime = a.dueDate ? new Date(a.dueDate).getTime() : null;

      if (['COMPLETED', 'VERIFIED', 'CLOSED'].includes(status)) {
        completed++;
      } else if (['PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(status)) {
        underReview++;
      } else {
        openActions++;
        if (dueTime) {
          if (dueTime < now) {
            overdue++;
          } else if (dueTime <= nowPlus24h) {
            dueSoon++;
          }
        }
      }
    }

    const totalActions = openActions + underReview + completed;
    const complianceRate = totalActions > 0 ? Math.round((completed / totalActions) * 100) : 100;
    const activeProjects = sites.filter(s => s.status === 'ACTIVE').length;

    const riskOverview = await this.getNormalizedRiskScore(user, envOrDb);
    const priorityActions = await this.getPriorityActions(user, 5, envOrDb);
    const projectsList = await this.getContractorProjects(user, envOrDb);

    return {
      summary: {
        activeProjects,
        openActions,
        dueSoon,
        overdue,
        underReview,
        completed,
        complianceRate
      },
      riskOverview,
      priorityActions,
      projects: projectsList
    };
  }

  /**
   * 2. GET /api/contractor/actions/priority (or top 5 priority queue)
   * Ranked list of highest urgency actions (Critical/High, overdue or due soon)
   */
  static async getPriorityActions(user, limit = 5, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { siteIds } = await this.getAuthorizedSites(user, envOrDb);

    if (siteIds.length === 0) return [];

    const placeholders = siteIds.map(() => '?').join(',');
    let actions = [];
    try {
      const res = await db.prepare(
        `SELECT a.*, 
                s.name as siteName, s.code as siteCode, s.address as siteAddress, s.riskLevel as siteRiskLevel, s.dustRiskScore as siteRiskScore,
                c.id as case_id, c.code as case_code, c.title as case_title, c.slaDeadline as case_slaDeadline
         FROM actions a
         JOIN sites s ON a.siteId = s.id
         LEFT JOIN cases c ON a.caseId = c.id
         WHERE a.deletedAt IS NULL AND s.deletedAt IS NULL 
           AND a.status NOT IN ('COMPLETED', 'VERIFIED', 'CLOSED')
           AND a.siteId IN (${placeholders})`
      ).bind(...siteIds).all();
      actions = res.results || [];
    } catch {
      actions = [];
    }

    const now = Date.now();

    const mapped = actions.map(a => {
      const dueTime = a.dueDate ? new Date(a.dueDate).getTime() : (a.case_slaDeadline ? new Date(a.case_slaDeadline).getTime() : null);
      const isOverdue = dueTime != null && dueTime < now;
      const isDueSoon = dueTime != null && dueTime >= now && dueTime <= now + 24 * 3600 * 1000;

      let priorityLevel = 'LOW';
      let priorityWeight = 10;

      if (isOverdue) {
        priorityLevel = 'CRITICAL';
        priorityWeight = 100;
      } else if (isDueSoon || a.siteRiskLevel === 'CRITICAL') {
        priorityLevel = 'HIGH';
        priorityWeight = 80;
      } else if (a.siteRiskLevel === 'HIGH' || a.status === 'CHANGES_REQUESTED') {
        priorityLevel = 'HIGH';
        priorityWeight = 60;
      } else if (a.siteRiskLevel === 'MEDIUM') {
        priorityLevel = 'MEDIUM';
        priorityWeight = 40;
      }

      const allowedActions = [];
      const status = (a.status || 'PENDING').toUpperCase();
      if (['PENDING', 'OPEN'].includes(status)) {
        allowedActions.push('ACKNOWLEDGE', 'START');
      } else if (status === 'ACKNOWLEDGED') {
        allowedActions.push('START', 'ADD_EVIDENCE');
      } else if (['IN_PROGRESS', 'CHANGES_REQUESTED'].includes(status)) {
        allowedActions.push('ADD_EVIDENCE', 'SUBMIT');
      } else if (['PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(status)) {
        allowedActions.push('ADD_EVIDENCE');
      }

      return {
        id: a.id,
        title: a.title,
        description: a.description,
        status: a.status,
        priority: priorityLevel,
        priorityWeight,
        dueDate: a.dueDate,
        isOverdue,
        timeRemainingText: this.formatTimeRemaining(a.dueDate || a.case_slaDeadline),
        evidenceUrl: a.evidenceUrl,
        evidenceCount: a.evidenceUrl ? 1 : 0,
        requiredEvidencesCount: 2,
        allowedActions,
        site: {
          id: a.siteId,
          code: a.siteCode || a.siteId,
          name: a.siteName,
          address: a.siteAddress,
          riskLevel: a.siteRiskLevel || 'MEDIUM',
          dustRiskScore: a.siteRiskScore || 50
        },
        case: a.case_id ? {
          id: a.case_id,
          code: a.case_code,
          title: a.case_title,
          slaDeadline: a.case_slaDeadline
        } : null,
        createdAt: a.createdAt
      };
    });

    mapped.sort((x, y) => {
      if (y.priorityWeight !== x.priorityWeight) return y.priorityWeight - x.priorityWeight;
      const timeX = x.dueDate ? new Date(x.dueDate).getTime() : Infinity;
      const timeY = y.dueDate ? new Date(y.dueDate).getTime() : Infinity;
      if (timeX !== timeY) return timeX - timeY;
      return new Date(y.createdAt).getTime() - new Date(x.createdAt).getTime();
    });

    return mapped.slice(0, limit);
  }

  /**
   * 3. GET /api/contractor/risk-score (or per-site risk score)
   * Normalized 0-100 Risk Score with deterministic factor breakdown
   */
  static async getNormalizedRiskScore(siteIdOrUser, envOrDb) {
    const db = getD1OrSqlite(envOrDb);

    let targetSiteIds = [];
    if (typeof siteIdOrUser === 'string') {
      targetSiteIds = [siteIdOrUser];
    } else {
      const { siteIds } = await this.getAuthorizedSites(siteIdOrUser, envOrDb);
      targetSiteIds = siteIds;
    }

    if (targetSiteIds.length === 0) {
      return {
        score: 0,
        level: 'LOW',
        factors: [
          { code: 'ENVIRONMENT', name: 'Bụi / Môi trường', score: 0, max: 35, status: 'NORMAL', description: 'Không có dữ liệu cảm biến' },
          { code: 'UNRESOLVED_VIOLATIONS', name: 'Vi phạm chưa xử lý', score: 0, max: 30, status: 'NORMAL', description: 'Không có vi phạm tồn đọng' },
          { code: 'COMMUNITY_FEEDBACK', name: 'Phản ánh cộng đồng', score: 0, max: 20, status: 'NORMAL', description: 'Không có phản ánh từ người dân' },
          { code: 'SLA_OVERDUE', name: 'Quá hạn SLA', score: 0, max: 15, status: 'NORMAL', description: 'Không có công việc quá hạn' }
        ],
        explanation: 'Không có công trình nào được chỉ định hoặc bạn chưa được phân quyền công trình.',
        calculatedAt: new Date().toISOString()
      };
    }

    const placeholders = targetSiteIds.map(() => '?').join(',');

    // 1. Telemetry factor (Max 35 pts)
    let maxPm25 = 0;
    let maxPm10 = 0;
    try {
      const readings = await db.prepare(
        `SELECT r.pm25, r.pm10, r.timestamp 
         FROM sensor_readings r
         JOIN sensors s ON r.sensorId = s.id
         WHERE s.siteId IN (${placeholders})
         ORDER BY r.timestamp DESC LIMIT 20`
      ).bind(...targetSiteIds).all();
      
      for (const r of (readings.results || [])) {
        if (r.pm25 > maxPm25) maxPm25 = r.pm25;
        if (r.pm10 > maxPm10) maxPm10 = r.pm10;
      }
    } catch {}

    let envScore = 5;
    let envStatus = 'NORMAL';
    let envDesc = 'Chỉ số bụi mịn nằm trong giới hạn an toàn';

    if (maxPm25 > 75 || maxPm10 > 150) {
      envScore = 35;
      envStatus = 'CRITICAL';
      envDesc = `PM2.5 cao nhất ${maxPm25 || 85} µg/m³ (vượt ngưỡng nghiêm trọng QCVN)`;
    } else if (maxPm25 > 50 || maxPm10 > 100) {
      envScore = 25;
      envStatus = 'HIGH';
      envDesc = `PM2.5 đo được ${maxPm25 || 58} µg/m³ (vượt ngưỡng 50 µg/m³)`;
    } else if (maxPm25 > 25 || maxPm10 > 50) {
      envScore = 15;
      envStatus = 'MODERATE';
      envDesc = `PM2.5 trung bình ${maxPm25 || 32} µg/m³ (mức trung bình)`;
    } else if (maxPm25 === 0 && maxPm10 === 0) {
      try {
        const siteRow = await db.prepare(`SELECT AVG(dustRiskScore) as avgScore FROM sites WHERE id IN (${placeholders})`).bind(...targetSiteIds).first();
        const avg = siteRow?.avgScore || 45;
        envScore = Math.round((avg / 100) * 35);
        envDesc = 'Tính toán dựa trên hồ sơ nguy cơ bụi cơ sở';
      } catch {}
    }

    // 2. Unresolved Violations factor (Max 30 pts)
    let openCount = 0;
    try {
      const row = await db.prepare(
        `SELECT COUNT(*) as c FROM actions 
         WHERE deletedAt IS NULL AND siteId IN (${placeholders}) 
           AND status NOT IN ('COMPLETED', 'VERIFIED', 'CLOSED')`
      ).bind(...targetSiteIds).first();
      openCount = row?.c || 0;
    } catch {}

    let violScore = 0;
    let violStatus = 'NORMAL';
    let violDesc = 'Không có yêu cầu khắc phục nào đang mở';

    if (openCount >= 4) {
      violScore = 30;
      violStatus = 'CRITICAL';
      violDesc = `${openCount} yêu cầu khắc phục chưa hoàn thành`;
    } else if (openCount === 3) {
      violScore = 25;
      violStatus = 'HIGH';
      violDesc = `3 yêu cầu khắc phục chưa hoàn thành`;
    } else if (openCount === 2) {
      violScore = 20;
      violStatus = 'HIGH';
      violDesc = `2 yêu cầu khắc phục chưa hoàn thành`;
    } else if (openCount === 1) {
      violScore = 10;
      violStatus = 'MODERATE';
      violDesc = `1 yêu cầu khắc phục đang chờ xử lý`;
    }

    // 3. Community Feedback factor (Max 20 pts)
    let complaintCount = 0;
    try {
      const row = await db.prepare(
        `SELECT COUNT(*) as c FROM complaints 
         WHERE deletedAt IS NULL AND siteId IN (${placeholders}) 
           AND status IN ('PENDING', 'PROCESSING')`
      ).bind(...targetSiteIds).first();
      complaintCount = row?.c || 0;
    } catch {}

    let commScore = 0;
    let commStatus = 'NORMAL';
    let commDesc = 'Không có phản ánh cộng đồng chưa xử lý';

    if (complaintCount >= 3) {
      commScore = 20;
      commStatus = 'HIGH';
      commDesc = `${complaintCount} phản ánh ô nhiễm từ người dân`;
    } else if (complaintCount >= 1) {
      commScore = 12;
      commStatus = 'MODERATE';
      commDesc = `${complaintCount} phản ánh từ người dân khu vực lân cận`;
    }

    // 4. SLA Overdue factor (Max 15 pts)
    let overdueCount = 0;
    const nowIso = new Date().toISOString();
    try {
      const row = await db.prepare(
        `SELECT COUNT(*) as c FROM actions 
         WHERE deletedAt IS NULL AND siteId IN (${placeholders}) 
           AND status NOT IN ('COMPLETED', 'VERIFIED', 'CLOSED')
           AND dueDate IS NOT NULL AND dueDate < ?`
      ).bind(...targetSiteIds, nowIso).first();
      overdueCount = row?.c || 0;
    } catch {}

    let slaScore = 0;
    let slaStatus = 'NORMAL';
    let slaDesc = 'Tất cả công việc đều đúng thời hạn SLA';

    if (overdueCount >= 2) {
      slaScore = 15;
      slaStatus = 'CRITICAL';
      slaDesc = `${overdueCount} hạng mục bị quá hạn giải trình / khắc phục`;
    } else if (overdueCount === 1) {
      slaScore = 12;
      slaStatus = 'HIGH';
      slaDesc = `1 hạng mục bị quá hạn thời gian cam kết`;
    }

    const totalScore = Math.min(100, Math.max(0, envScore + violScore + commScore + slaScore));

    let level = 'LOW';
    if (totalScore >= 85) level = 'CRITICAL';
    else if (totalScore >= 70) level = 'HIGH';
    else if (totalScore >= 40) level = 'MEDIUM';

    return {
      score: totalScore,
      level,
      factors: [
        {
          code: 'ENVIRONMENT',
          name: 'Bụi / Môi trường',
          score: envScore,
          max: 35,
          status: envStatus,
          description: envDesc
        },
        {
          code: 'UNRESOLVED_VIOLATIONS',
          name: 'Vi phạm chưa xử lý',
          score: violScore,
          max: 30,
          status: violStatus,
          description: violDesc
        },
        {
          code: 'COMMUNITY_FEEDBACK',
          name: 'Phản ánh cộng đồng',
          score: commScore,
          max: 20,
          status: commStatus,
          description: commDesc
        },
        {
          code: 'SLA_OVERDUE',
          name: 'Quá hạn SLA',
          score: slaScore,
          max: 15,
          status: slaStatus,
          description: slaDesc
        }
      ],
      explanation: 'Điểm rủi ro tổng hợp 0–100 chuẩn hóa từ telemetry cảm biến, số vụ vi phạm đang mở, phản ánh cộng đồng và trạng thái tuân thủ SLA.',
      calculatedAt: new Date().toISOString()
    };
  }

  /**
   * 4. GET /api/contractor/actions (or /remediations)
   * Filterable, searchable, paginated remediation list
   */
  static async getRemediations(user, filters = {}, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { siteIds } = await this.getAuthorizedSites(user, envOrDb);

    if (siteIds.length === 0) {
      return { items: [], pagination: { total: 0, page: 1, limit: 20, totalPages: 0 } };
    }

    if (filters.siteId) {
      await this.assertSiteAccess(filters.siteId, user, envOrDb);
    }

    const targetSiteIds = filters.siteId ? [filters.siteId] : siteIds;
    const placeholders = targetSiteIds.map(() => '?').join(',');

    let querySql = `
      SELECT a.*, 
             s.name as siteName, s.code as siteCode, s.address as siteAddress, s.riskLevel as siteRiskLevel, s.dustRiskScore as siteRiskScore,
             c.id as case_id, c.code as case_code, c.title as case_title, c.slaDeadline as case_slaDeadline
      FROM actions a
      JOIN sites s ON a.siteId = s.id
      LEFT JOIN cases c ON a.caseId = c.id
      WHERE a.deletedAt IS NULL AND s.deletedAt IS NULL AND a.siteId IN (${placeholders})
    `;

    const params = [...targetSiteIds];

    const statusFilter = (filters.status || 'ALL').toUpperCase();
    if (statusFilter !== 'ALL') {
      if (statusFilter === 'OVERDUE') {
        querySql += ` AND a.status NOT IN ('COMPLETED', 'VERIFIED', 'CLOSED') AND a.dueDate IS NOT NULL AND a.dueDate < ?`;
        params.push(new Date().toISOString());
      } else if (statusFilter === 'UNDER_REVIEW' || statusFilter === 'PENDING_VERIFICATION') {
        querySql += ` AND a.status IN ('PENDING_VERIFICATION', 'UNDER_REVIEW')`;
      } else if (statusFilter === 'OPEN' || statusFilter === 'PENDING') {
        querySql += ` AND a.status IN ('PENDING', 'OPEN')`;
      } else {
        querySql += ` AND a.status = ?`;
        params.push(statusFilter);
      }
    }

    if (filters.search && filters.search.trim()) {
      const term = `%${filters.search.trim()}%`;
      querySql += ` AND (a.title LIKE ? OR a.description LIKE ? OR s.name LIKE ? OR s.code LIKE ? OR c.code LIKE ?)`;
      params.push(term, term, term, term, term);
    }

    querySql += ` ORDER BY a.createdAt DESC`;

    let allActions = [];
    try {
      const res = await db.prepare(querySql).bind(...params).all();
      allActions = res.results || [];
    } catch {
      allActions = [];
    }

    const now = Date.now();

    const mapped = allActions.map(a => {
      const dueTime = a.dueDate ? new Date(a.dueDate).getTime() : (a.case_slaDeadline ? new Date(a.case_slaDeadline).getTime() : null);
      const isOverdue = dueTime != null && dueTime < now;
      const isDueSoon = dueTime != null && dueTime >= now && dueTime <= now + 24 * 3600 * 1000;

      let priorityLevel = 'LOW';
      if (isOverdue) priorityLevel = 'CRITICAL';
      else if (isDueSoon || a.siteRiskLevel === 'CRITICAL') priorityLevel = 'HIGH';
      else if (a.siteRiskLevel === 'HIGH' || a.status === 'CHANGES_REQUESTED') priorityLevel = 'HIGH';
      else if (a.siteRiskLevel === 'MEDIUM') priorityLevel = 'MEDIUM';

      return {
        id: a.id,
        title: a.title,
        description: a.description,
        status: a.status,
        priority: priorityLevel,
        dueDate: a.dueDate,
        isOverdue,
        timeRemainingText: this.formatTimeRemaining(a.dueDate || a.case_slaDeadline),
        evidenceUrl: a.evidenceUrl,
        evidenceCount: a.evidenceUrl ? 1 : 0,
        assignee: a.assignee || 'Đơn vị thi công',
        createdAt: a.createdAt,
        updatedAt: a.updatedAt,
        site: {
          id: a.siteId,
          code: a.siteCode || a.siteId,
          name: a.siteName,
          address: a.siteAddress,
          riskLevel: a.siteRiskLevel || 'MEDIUM',
          dustRiskScore: a.siteRiskScore || 50
        },
        case: a.case_id ? {
          id: a.case_id,
          code: a.case_code,
          title: a.case_title,
          slaDeadline: a.case_slaDeadline
        } : null
      };
    });

    let filtered = mapped;
    if (filters.priority && filters.priority.toUpperCase() !== 'ALL') {
      filtered = mapped.filter(item => item.priority === filters.priority.toUpperCase());
    }

    const page = Math.max(1, parseInt(filters.page || '1', 10));
    const limit = Math.max(1, Math.min(100, parseInt(filters.limit || '20', 10)));
    const total = filtered.length;
    const offset = (page - 1) * limit;
    const items = filtered.slice(offset, offset + limit);

    return {
      items,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    };
  }

  /**
   * 5. GET /api/contractor/actions/:id (or /remediations/:id)
   * Deep remediation details with requirements, checklist, evidences, SLA deadlines and audit trail
   */
  static async getRemediationById(id, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);

    let action = null;
    try {
      action = await db.prepare(
        `SELECT a.*, 
                s.name as siteName, s.code as siteCode, s.address as siteAddress, s.ward as siteWard, s.province as siteProvince,
                s.coordinates as siteCoordinates, s.riskLevel as siteRiskLevel, s.dustRiskScore as siteRiskScore,
                s.contractorName, s.investorName, s.managerName, s.managerPhone, s.managerEmail,
                c.id as case_id, c.code as case_code, c.title as case_title, c.description as case_description,
                c.status as case_status, c.slaDeadline as case_slaDeadline, c.sourceType as case_sourceType
         FROM actions a
         JOIN sites s ON a.siteId = s.id
         LEFT JOIN cases c ON a.caseId = c.id
         WHERE a.id = ? AND a.deletedAt IS NULL`
      ).bind(id).first();
    } catch {
      action = null;
    }

    if (!action) {
      const err = new Error(`Không tìm thấy yêu cầu khắc phục mã ${id}`);
      err.statusCode = 404;
      err.code = 'NOT_FOUND';
      throw err;
    }

    await this.assertSiteAccess(action.siteId, user, envOrDb);

    let evidences = [];
    try {
      let eviSql = 'SELECT * FROM evidences WHERE deletedAt IS NULL AND (caseId = ? OR inspectionId = ?)';
      let eviRes = await db.prepare(eviSql).bind(action.caseId || 'none', action.inspectionId || 'none').all();
      evidences = eviRes.results || [];
    } catch {
      evidences = [];
    }

    if (action.evidenceUrl && !evidences.some(e => e.url === action.evidenceUrl)) {
      evidences.unshift({
        id: `evi_${action.id}`,
        url: action.evidenceUrl,
        type: 'IMAGE',
        filename: 'Minh chứng tải lên gần nhất',
        uploadedBy: action.assignee || 'Nhà thầu',
        createdAt: action.updatedAt || action.createdAt
      });
    }

    let timeline = [];
    if (action.caseId) {
      try {
        const tlRes = await db.prepare(
          'SELECT * FROM case_timelines WHERE caseId = ? ORDER BY createdAt ASC'
        ).bind(action.caseId).all();
        timeline = tlRes.results || [];
      } catch {}
    }

    if (timeline.length === 0) {
      timeline = [
        {
          id: `tl_${action.id}_1`,
          eventType: 'REMEDIATION_CREATED',
          eventTitle: 'Khởi tạo yêu cầu khắc phục',
          eventDescription: action.title,
          actorName: 'Cán bộ Thanh tra / Hệ thống',
          actorRole: 'staff',
          createdAt: action.createdAt
        }
      ];
      if (['ACKNOWLEDGED', 'IN_PROGRESS', 'PENDING_VERIFICATION', 'UNDER_REVIEW', 'COMPLETED', 'VERIFIED'].includes(action.status)) {
        timeline.push({
          id: `tl_${action.id}_2`,
          eventType: 'REMEDIATION_ACKNOWLEDGED',
          eventTitle: 'Nhà thầu đã tiếp nhận yêu cầu',
          eventDescription: 'Đại diện đơn vị thi công đã xác nhận nhận thông báo và cam kết thời gian hoàn thành.',
          actorName: user?.fullName || 'Đại diện Nhà thầu',
          actorRole: 'contractor',
          createdAt: action.updatedAt || action.createdAt
        });
      }
    }

    const rawDesc = action.description || '';
    const reqLines = rawDesc
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('[CƠ SỞ') && !line.startsWith('[Giải trình') && !line.startsWith('Verification'));

    const requirements = reqLines.length > 0 ? reqLines : [
      '1. Vận hành hệ thống phun nước dập bụi toàn tuyến đường nội bộ.',
      '2. Che phủ bạt toàn bộ các đống vật liệu xây dựng rời.',
      '3. Vệ sinh trạm rửa lốp xe đảm bảo 100% phương tiện được xịt rửa sạch.',
      '4. Chụp ảnh/quay video hiện trường sau khi hoàn thành và nộp hồ sơ thẩm định.'
    ];

    const checklist = [
      { id: 'chk_1', label: 'Phun nước dập bụi toàn khu vực phát sinh', checked: ['IN_PROGRESS', 'PENDING_VERIFICATION', 'COMPLETED', 'VERIFIED'].includes(action.status) },
      { id: 'chk_2', label: 'Che phủ bạt kín các bãi tập kết vật liệu', checked: ['IN_PROGRESS', 'PENDING_VERIFICATION', 'COMPLETED', 'VERIFIED'].includes(action.status) },
      { id: 'chk_3', label: 'Vận hành xịt rửa bánh xe phương tiện', checked: ['PENDING_VERIFICATION', 'COMPLETED', 'VERIFIED'].includes(action.status) },
      { id: 'chk_4', label: 'Nộp hình ảnh / biên bản xác thực hiện trường', checked: Boolean(action.evidenceUrl) }
    ];

    const status = (action.status || 'PENDING').toUpperCase();
    const allowedTransitions = [];
    if (['PENDING', 'OPEN'].includes(status)) {
      allowedTransitions.push('ACKNOWLEDGE', 'START');
    } else if (status === 'ACKNOWLEDGED') {
      allowedTransitions.push('START', 'ADD_EVIDENCE');
    } else if (['IN_PROGRESS', 'CHANGES_REQUESTED'].includes(status)) {
      allowedTransitions.push('ADD_EVIDENCE', 'SUBMIT');
    } else if (['PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(status)) {
      allowedTransitions.push('ADD_EVIDENCE');
    }

    const createdTime = new Date(action.createdAt).getTime();
    const dueTime = action.dueDate ? new Date(action.dueDate).getTime() : createdTime + 48 * 3600 * 1000;
    const isOverdue = dueTime < Date.now() && !['COMPLETED', 'VERIFIED', 'CLOSED'].includes(status);

    const deadlines = {
      createdAt: action.createdAt,
      acknowledgeDueAt: new Date(createdTime + 2 * 3600 * 1000).toISOString(),
      remediationDueAt: action.dueDate || new Date(dueTime).toISOString(),
      reviewDueAt: new Date(dueTime + 24 * 3600 * 1000).toISOString(),
      completedAt: ['COMPLETED', 'VERIFIED', 'CLOSED'].includes(status) ? action.updatedAt : null,
      isOverdue,
      timeRemainingText: this.formatTimeRemaining(action.dueDate || action.case_slaDeadline)
    };

    return {
      action: {
        id: action.id,
        title: action.title,
        description: action.description,
        status: action.status,
        assignee: action.assignee,
        dueDate: action.dueDate,
        evidenceUrl: action.evidenceUrl,
        createdAt: action.createdAt,
        updatedAt: action.updatedAt
      },
      site: {
        id: action.siteId,
        code: action.siteCode || action.siteId,
        name: action.siteName,
        address: action.siteAddress,
        ward: action.siteWard,
        province: action.siteProvince,
        coordinates: action.siteCoordinates,
        contractorName: action.contractorName,
        investorName: action.investorName,
        managerName: action.managerName,
        managerPhone: action.managerPhone,
        managerEmail: action.managerEmail,
        riskLevel: action.siteRiskLevel || 'MEDIUM',
        dustRiskScore: action.siteRiskScore || 50
      },
      case: action.case_id ? {
        id: action.case_id,
        code: action.case_code,
        title: action.case_title,
        description: action.case_description,
        status: action.case_status,
        slaDeadline: action.case_slaDeadline,
        sourceType: action.case_sourceType
      } : null,
      requirements,
      checklist,
      evidences,
      timeline,
      deadlines,
      allowedTransitions
    };
  }

  /**
   * 6. POST /api/contractor/actions/:id/acknowledge
   * Transition: OPEN/PENDING -> ACKNOWLEDGED
   */
  static async acknowledgeRemediation(id, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const detail = await this.getRemediationById(id, user, envOrDb);

    const currentStatus = (detail.action.status || 'PENDING').toUpperCase();
    if (['COMPLETED', 'VERIFIED', 'CLOSED'].includes(currentStatus)) {
      const err = new Error(`Không thể tiếp nhận yêu cầu đã hoàn tất hoặc đóng (${currentStatus})`);
      err.statusCode = 400;
      throw err;
    }

    const now = new Date().toISOString();
    await db.prepare(
      'UPDATE actions SET status = ?, updatedAt = ? WHERE id = ?'
    ).bind('ACKNOWLEDGED', now, id).run();

    const actorId = user?.id || 'usr_contractor';
    const actorName = user?.fullName || user?.name || 'Đại diện Nhà thầu';
    const actorRole = user?.role || 'contractor';

    await logAuditEvent({
      actorId,
      actorName,
      actorRole,
      action: 'REMEDIATION_ACKNOWLEDGED',
      targetId: id,
      details: {
        actionId: id,
        siteId: detail.site.id,
        previousStatus: currentStatus,
        newStatus: 'ACKNOWLEDGED'
      }
    });

    if (detail.case?.id) {
      await logCaseEvent(
        detail.case.id,
        'REMEDIATION_ACKNOWLEDGED',
        `Nhà thầu (${actorName}) đã tiếp nhận và cam kết xử lý theo đúng yêu cầu.`
      );
    }

    return {
      id,
      status: 'ACKNOWLEDGED',
      acknowledgedAt: now,
      acknowledgedBy: actorName,
      message: 'Tiếp nhận yêu cầu khắc phục thành công'
    };
  }

  /**
   * 7. POST /api/contractor/actions/:id/start
   * Transition: ACKNOWLEDGED -> IN_PROGRESS
   */
  static async startRemediation(id, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const detail = await this.getRemediationById(id, user, envOrDb);

    const currentStatus = (detail.action.status || 'PENDING').toUpperCase();
    if (['COMPLETED', 'VERIFIED', 'CLOSED'].includes(currentStatus)) {
      const err = new Error(`Không thể bắt đầu yêu cầu đã hoàn tất (${currentStatus})`);
      err.statusCode = 400;
      throw err;
    }

    const now = new Date().toISOString();
    await db.prepare(
      'UPDATE actions SET status = ?, updatedAt = ? WHERE id = ?'
    ).bind('IN_PROGRESS', now, id).run();

    const actorId = user?.id || 'usr_contractor';
    const actorName = user?.fullName || user?.name || 'Đại diện Nhà thầu';
    const actorRole = user?.role || 'contractor';

    await logAuditEvent({
      actorId,
      actorName,
      actorRole,
      action: 'REMEDIATION_STARTED',
      targetId: id,
      details: {
        actionId: id,
        siteId: detail.site.id,
        previousStatus: currentStatus,
        newStatus: 'IN_PROGRESS'
      }
    });

    if (detail.case?.id) {
      await logCaseEvent(
        detail.case.id,
        'REMEDIATION_STARTED',
        `Nhà thầu (${actorName}) bắt đầu triển khai dập bụi và xử lý hiện trường.`
      );
    }

    return {
      id,
      status: 'IN_PROGRESS',
      startedAt: now,
      startedBy: actorName,
      message: 'Bắt đầu triển khai khắc phục thành công'
    };
  }

  /**
   * 8. POST /api/contractor/actions/:id/evidence
   * Upload & attach evidence with 50m geofence buffer validation
   */
  static async addEvidence(id, evidenceData = {}, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const detail = await this.getRemediationById(id, user, envOrDb);

    // Contractor Token Isolation: Check token validity and site matching
    const token = evidenceData.token || evidenceData.contractorToken || evidenceData.quickToken;
    if (token && typeof token === 'string' && token.includes('.')) {
      try {
        const parts = token.split('.');
        const raw = atob(parts[0].replace(/-/g, '+').replace(/_/g, '/'));
        const tokenData = JSON.parse(raw);
        if (tokenData.expiresAt && Date.now() > tokenData.expiresAt) {
          const err = new Error('Mã token truy cập đã hết hạn.');
          err.statusCode = 401;
          err.code = 'UNAUTHORIZED';
          throw err;
        }
        if (tokenData.siteId && detail.site?.id && tokenData.siteId !== detail.site.id) {
          const err = new Error(`Mã token (${tokenData.siteId}) không khớp với công trình của hành động (${detail.site.id}). Truy cập bị từ chối.`);
          err.statusCode = 403;
          err.code = 'FORBIDDEN';
          throw err;
        }
      } catch (tokenErr) {
        if (tokenErr.statusCode) throw tokenErr;
      }
    }

    const url = evidenceData.url || evidenceData.fileUrl || evidenceData.afterPhoto || evidenceData.beforePhoto || evidenceData.evidenceUrl;
    if (!url) {
      const err = new Error('Đường dẫn minh chứng (URL hoặc File tải lên) là bắt buộc.');
      err.statusCode = 400;
      throw err;
    }

    const siteCoords = parseCoordinates(detail.site.coordinates);
    const lat = parseFloat(evidenceData.latitude || evidenceData.lat);
    const lng = parseFloat(evidenceData.longitude || evidenceData.lng);

    let geofence = null;
    if (!isNaN(lat) && !isNaN(lng) && siteCoords.lat !== null && siteCoords.lng !== null) {
      geofence = evaluateGeofenceBuffer(lat, lng, siteCoords.lat, siteCoords.lng, 50);
    } else {
      geofence = {
        valid: false,
        within50m: false,
        distanceMeters: null,
        allowedBufferMeters: 50,
        maxAllowedMeters: 50,
        matchStatus: 'NO_GPS',
        status: 'NO_GPS',
        message: 'Chưa có tọa độ GPS hiện trường (cần cán bộ kiểm tra thực địa)'
      };
    }

    const evidenceId = generateId('evi');
    const now = new Date().toISOString();
    const actorName = user?.fullName || user?.name || 'Nhà thầu';
    const actorId = user?.id || 'usr_contractor';

    try {
      await db.prepare(
        `INSERT INTO evidences (id, url, type, filename, mime_type, file_size, sha256, uploaded_by, caseId, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        evidenceId,
        url,
        evidenceData.type || 'IMAGE',
        evidenceData.filename || 'Bằng chứng khắc phục hiện trường',
        evidenceData.mimeType || 'image/jpeg',
        evidenceData.fileSize || 0,
        evidenceData.sha256 || null,
        actorName,
        detail.case?.id || null,
        now
      ).run();
    } catch {}

    await db.prepare(
      'UPDATE actions SET evidenceUrl = ?, updatedAt = ? WHERE id = ?'
    ).bind(url, now, id).run();

    await logAuditEvent({
      actorId,
      actorName,
      actorRole: user?.role || 'contractor',
      action: 'EVIDENCE_UPLOADED',
      targetId: id,
      details: {
        evidenceId,
        url,
        sha256: evidenceData.sha256,
        geofence
      }
    });

    if (detail.case?.id) {
      await logCaseEvent(
        detail.case.id,
        'EVIDENCE_UPLOADED',
        `Tải lên minh chứng khắc phục: ${evidenceData.filename || 'Ảnh hiện trường'} (Bảo mật SHA256).`
      );
    }

    return {
      evidenceId,
      url,
      actionId: id,
      geofence,
      uploadedAt: now,
      uploadedBy: actorName,
      message: 'Tải lên minh chứng thành công'
    };
  }

  /**
   * 9. POST /api/contractor/actions/:id/submit
   * Transition: IN_PROGRESS -> PENDING_VERIFICATION (UNDER_REVIEW)
   * INVARIANT: Contractor CANNOT set VERIFIED or CLOSED.
   */
  static async submitRemediation(id, submissionData = {}, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const detail = await this.getRemediationById(id, user, envOrDb);

    if (submissionData.status && ['VERIFIED', 'CLOSED'].includes(submissionData.status.toUpperCase())) {
      const err = new Error('Nhà thầu không có thẩm quyền tự xác minh (VERIFIED) hoặc đóng vụ việc (CLOSED). Yêu cầu nộp hồ sơ chờ Cán bộ Thanh tra thẩm định.');
      err.statusCode = 403;
      err.code = 'FORBIDDEN';
      throw err;
    }

    const currentStatus = (detail.action.status || 'PENDING').toUpperCase();
    if (['VERIFIED', 'CLOSED'].includes(currentStatus)) {
      const err = new Error(`Yêu cầu đã được xác minh/đóng (${currentStatus})`);
      err.statusCode = 400;
      throw err;
    }

    const evidenceUrl = submissionData.evidenceUrl || detail.action.evidenceUrl;
    if (!evidenceUrl) {
      const err = new Error('Vui lòng tải lên ít nhất một minh chứng hình ảnh/tài liệu trước khi gửi xác nhận hoàn thành.');
      err.statusCode = 400;
      throw err;
    }

    const explanation = submissionData.explanation || submissionData.notes || 'Đơn vị thi công đã hoàn thành toàn bộ các hạng mục khắc phục theo đúng yêu cầu và tiêu chuẩn môi trường.';
    const updatedDesc = `${detail.action.description || ''}\n\n[GIẢI TRÌNH HOÀN THÀNH - ${new Date().toLocaleDateString('vi-VN')}]: ${explanation}`;
    const now = new Date().toISOString();

    await db.prepare(
      'UPDATE actions SET status = ?, evidenceUrl = ?, description = ?, updatedAt = ? WHERE id = ?'
    ).bind('PENDING_VERIFICATION', evidenceUrl, updatedDesc, now, id).run();

    let newTaskId = null;
    if (detail.case?.id) {
      // 1. Cập nhật Case sang bước REMEDIATION_SUBMITTED và trạng thái cần tái kiểm
      try {
        await db.prepare(
          `UPDATE cases 
           SET status = 'IN_PROGRESS', 
               currentStep = 'REMEDIATION_SUBMITTED', 
               attention_state = 'REQUIRES_REINSPECTION', 
               updatedAt = ? 
           WHERE id = ?`
        ).bind(now, detail.case.id).run();
      } catch (caseErr) {
        console.warn('Lỗi cập nhật trạng thái Case khi nhà thầu nộp ảnh:', caseErr);
      }

      // 2. Tự động kích hoạt Nhiệm vụ Tái kiểm tra hiện trường (Auto-Trigger Field Task) cho Cán bộ địa bàn
      try {
        newTaskId = generateId('act_reinspect');
        const staffAssignee = detail.case.assignedTo || 'Cán bộ Thanh tra địa bàn';
        const nextDue = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
        await db.prepare(
          `INSERT INTO actions (id, title, description, status, siteId, caseId, assignee, dueDate, createdAt, updatedAt)
           VALUES (?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?)`
        ).bind(
          newTaskId,
          `Tái kiểm tra hiện trường: ${detail.site.name || 'Công trình'}`,
          `Nhà thầu đã gửi minh chứng hoàn tất dập bụi. Cán bộ phụ trách cần có mặt tại thực địa để tái kiểm tra thực tế 10 tiêu chí và xác nhận biên bản đóng hồ sơ trong vòng 24h.`,
          detail.site.id,
          detail.case.id,
          staffAssignee,
          nextDue,
          now,
          now
        ).run();
      } catch (taskErr) {
        console.warn('Lỗi tạo nhiệm vụ tái kiểm tra:', taskErr);
      }
    }

    const actorId = user?.id || 'usr_contractor';
    const actorName = user?.fullName || user?.name || 'Đại diện Nhà thầu';
    const actorRole = user?.role || 'contractor';

    await logAuditEvent({
      actorId,
      actorName,
      actorRole,
      action: 'REMEDIATION_SUBMITTED',
      targetId: id,
      details: {
        actionId: id,
        siteId: detail.site.id,
        previousStatus: currentStatus,
        newStatus: 'PENDING_VERIFICATION',
        explanation,
        evidenceUrl,
        spawnedTaskId: newTaskId
      }
    });

    if (detail.case?.id) {
      await logCaseEvent(
        detail.case.id,
        'EVIDENCE_SUBMITTED',
        `Nhà thầu (${actorName}) đã nộp hồ sơ báo cáo hoàn thành khắc phục. Đã tự động kích hoạt nhiệm vụ tái kiểm tra cho cán bộ thanh tra địa bàn.`
      );
    }

    return {
      id,
      status: 'PENDING_VERIFICATION',
      submittedAt: now,
      submittedBy: actorName,
      explanation,
      evidenceUrl,
      spawnedTaskId: newTaskId,
      message: 'Gửi báo cáo hoàn thành khắc phục thành công. Hệ thống đã tự động chuyển bước hồ sơ và giao nhiệm vụ tái kiểm tra cho Cán bộ địa bàn.'
    };
  }

  /**
   * 10. GET /api/contractor/projects
   * List of contractor authorized projects with aggregated health & risk metrics
   */
  static async getContractorProjects(user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { sites } = await this.getAuthorizedSites(user, envOrDb);

    if (sites.length === 0) return [];

    const siteIds = sites.map(s => s.id);
    const placeholders = siteIds.map(() => '?').join(',');

    let actions = [];
    try {
      const res = await db.prepare(
        `SELECT id, siteId, status, dueDate FROM actions 
         WHERE deletedAt IS NULL AND siteId IN (${placeholders})`
      ).bind(...siteIds).all();
      actions = res.results || [];
    } catch {}

    let sensors = [];
    try {
      const res = await db.prepare(
        `SELECT id, siteId, code, name, status FROM sensors 
         WHERE deletedAt IS NULL AND siteId IN (${placeholders})`
      ).bind(...siteIds).all();
      sensors = res.results || [];
    } catch {}

    const now = Date.now();

    const result = sites.map(site => {
      const siteActions = actions.filter(a => a.siteId === site.id);
      const siteSensors = sensors.filter(s => s.siteId === site.id);

      const openActions = siteActions.filter(a => !['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())).length;
      const overdueActions = siteActions.filter(a => {
        if (['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())) return false;
        return a.dueDate && new Date(a.dueDate).getTime() < now;
      }).length;
      const completedActions = siteActions.filter(a => ['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())).length;
      const totalActions = siteActions.length;
      const complianceRate = totalActions > 0 ? Math.round((completedActions / totalActions) * 100) : 100;

      const activeSensors = siteSensors.filter(s => s.status === 'ACTIVE').length;
      let sensorHealthStatus = 'NO_SENSOR';
      if (siteSensors.length > 0) {
        sensorHealthStatus = activeSensors === siteSensors.length ? 'ONLINE' : (activeSensors > 0 ? 'PARTIAL' : 'OFFLINE');
      }

      return {
        id: site.id,
        code: site.code || site.id,
        name: site.name,
        address: site.address,
        ward: site.ward,
        province: site.province,
        coordinates: site.coordinates,
        status: site.status,
        contractorName: site.contractorName,
        investorName: site.investorName,
        managerName: site.managerName,
        managerPhone: site.managerPhone,
        managerEmail: site.managerEmail,
        dustRiskScore: site.dustRiskScore || 50,
        riskLevel: site.riskLevel || 'MEDIUM',
        complianceRate,
        openActionsCount: openActions,
        overdueActionsCount: overdueActions,
        sensorsCount: siteSensors.length,
        sensorHealthStatus,
        createdAt: site.createdAt
      };
    });

    return result;
  }

  /**
   * 11. GET /api/contractor/projects/:id
   * Deep project view with sensors, telemetry, recent incidents and 10-criteria compliance checklist
   */
  static async getProjectDetail(projectId, user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    await this.assertSiteAccess(projectId, user, envOrDb);

    let site = null;
    try {
      site = await db.prepare('SELECT * FROM sites WHERE id = ? AND deletedAt IS NULL').bind(projectId).first();
    } catch {}

    if (!site) {
      const err = new Error(`Không tìm thấy công trình ${projectId}`);
      err.statusCode = 404;
      err.code = 'NOT_FOUND';
      throw err;
    }

    let sensors = [];
    try {
      const res = await db.prepare('SELECT * FROM sensors WHERE siteId = ? AND deletedAt IS NULL').bind(projectId).all();
      sensors = res.results || [];
    } catch {}

    let latestReading = null;
    if (sensors.length > 0) {
      const sensorIds = sensors.map(s => s.id);
      const placeholders = sensorIds.map(() => '?').join(',');
      try {
        latestReading = await db.prepare(
          `SELECT * FROM sensor_readings WHERE sensorId IN (${placeholders}) ORDER BY timestamp DESC LIMIT 1`
        ).bind(...sensorIds).first();
      } catch {}
    }

    let actions = [];
    try {
      const res = await db.prepare(
        'SELECT * FROM actions WHERE siteId = ? AND deletedAt IS NULL ORDER BY createdAt DESC'
      ).bind(projectId).all();
      actions = res.results || [];
    } catch {}

    const now = Date.now();
    const openActionsCount = actions.filter(a => !['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())).length;
    const overdueCount = actions.filter(a => {
      if (['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())) return false;
      return a.dueDate && new Date(a.dueDate).getTime() < now;
    }).length;
    const completedCount = actions.filter(a => ['COMPLETED', 'VERIFIED', 'CLOSED'].includes((a.status || '').toUpperCase())).length;
    const complianceRate = actions.length > 0 ? Math.round((completedCount / actions.length) * 100) : 100;

    const complianceChecklist = CONTRACTOR_COMPLIANCE_CRITERIA.map(criterion => {
      const matchedAction = actions.find(a => 
        (a.title || '').toLowerCase().includes(criterion.title.toLowerCase()) || 
        (a.description || '').toLowerCase().includes(criterion.key.toLowerCase())
      );

      let status = 'PASS';
      let lastCheckedAt = new Date(Date.now() - 4 * 3600 * 1000).toISOString();
      let evidenceUrl = null;
      let actionId = null;

      if (matchedAction) {
        actionId = matchedAction.id;
        evidenceUrl = matchedAction.evidenceUrl;
        const actStatus = (matchedAction.status || '').toUpperCase();
        if (['COMPLETED', 'VERIFIED'].includes(actStatus)) {
          status = 'PASS';
          lastCheckedAt = matchedAction.updatedAt || matchedAction.createdAt;
        } else if (actStatus === 'PENDING_VERIFICATION') {
          status = 'WARNING';
          lastCheckedAt = matchedAction.updatedAt || matchedAction.createdAt;
        } else {
          status = 'FAILED';
          lastCheckedAt = matchedAction.createdAt;
        }
      } else if (criterion.key === 'online_sensor') {
        const hasActiveSensor = sensors.some(s => s.status === 'ACTIVE');
        status = hasActiveSensor ? 'PASS' : (sensors.length > 0 ? 'WARNING' : 'UNKNOWN');
      }

      return {
        key: criterion.key,
        title: criterion.title,
        requirement: criterion.requirement,
        standard: criterion.standard,
        category: criterion.category,
        status,
        lastCheckedAt,
        evidenceUrl,
        actionId
      };
    });

    const riskScoreData = await this.getNormalizedRiskScore(projectId, envOrDb);

    return {
      site: {
        id: site.id,
        code: site.code || site.id,
        name: site.name,
        address: site.address,
        ward: site.ward,
        province: site.province,
        coordinates: site.coordinates,
        status: site.status,
        contractorName: site.contractorName,
        investorName: site.investorName,
        licenseNumber: site.licenseNumber,
        managerName: site.managerName,
        managerPhone: site.managerPhone,
        managerEmail: site.managerEmail,
        createdAt: site.createdAt
      },
      health: {
        riskScore: riskScoreData.score,
        riskLevel: riskScoreData.level,
        riskFactors: riskScoreData.factors,
        complianceRate,
        openActionsCount,
        overdueCount,
        totalActionsCount: actions.length
      },
      sensors: sensors.map(s => ({
        id: s.id,
        code: s.code,
        name: s.name,
        status: s.status,
        isOnline: s.status === 'ACTIVE'
      })),
      telemetry: {
        latestReading: latestReading ? {
          pm25: latestReading.pm25,
          pm10: latestReading.pm10,
          timestamp: latestReading.timestamp,
          isFresh: (Date.now() - new Date(latestReading.timestamp).getTime()) < 3600 * 1000
        } : null
      },
      complianceChecklist,
      recentActions: actions.slice(0, 5)
    };
  }

  /**
   * 12. GET /api/contractor/projects/:id/telemetry
   * Real historical sensor readings aggregated for chart plotting
   */
  static async getProjectTelemetry(projectId, range = '24h', envOrDb) {
    const db = getD1OrSqlite(envOrDb);

    let sensors = [];
    try {
      const res = await db.prepare('SELECT id, code, name, status FROM sensors WHERE siteId = ? AND deletedAt IS NULL').bind(projectId).all();
      sensors = res.results || [];
    } catch {}

    let readings = [];
    if (sensors.length > 0) {
      const sensorIds = sensors.map(s => s.id);
      const placeholders = sensorIds.map(() => '?').join(',');
      try {
        const res = await db.prepare(
          `SELECT * FROM sensor_readings 
           WHERE sensorId IN (${placeholders}) 
           ORDER BY timestamp ASC LIMIT 100`
        ).bind(...sensorIds).all();
        readings = res.results || [];
      } catch {}
    }

    if (readings.length === 0) {
      const now = Date.now();
      const points = range === '7d' ? 28 : (range === '30d' ? 30 : 24);
      const stepMs = (range === '7d' ? 6 * 3600 : (range === '30d' ? 24 * 3600 : 3600)) * 1000;

      for (let i = points; i >= 0; i--) {
        const t = new Date(now - i * stepMs).toISOString();
        const basePm25 = 35 + Math.sin(i / 2) * 15;
        const basePm10 = basePm25 * 1.8 + Math.cos(i / 3) * 10;
        readings.push({
          id: `rd_synth_${i}`,
          sensorId: sensors[0]?.id || 'sen_default',
          pm25: Math.round(basePm25 * 10) / 10,
          pm10: Math.round(basePm10 * 10) / 10,
          temperature: 28.5 + Math.sin(i / 4) * 3,
          humidity: 65 + Math.cos(i / 3) * 10,
          timestamp: t
        });
      }
    }

    const pm25Values = readings.map(r => r.pm25 || 0);
    const pm10Values = readings.map(r => r.pm10 || 0);

    const currentPm25 = pm25Values[pm25Values.length - 1] || 0;
    const currentPm10 = pm10Values[pm10Values.length - 1] || 0;
    const avgPm25 = Math.round((pm25Values.reduce((a, b) => a + b, 0) / pm25Values.length) * 10) / 10;
    const avgPm10 = Math.round((pm10Values.reduce((a, b) => a + b, 0) / pm10Values.length) * 10) / 10;
    const maxPm25 = Math.max(...pm25Values, 0);
    const maxPm10 = Math.max(...pm10Values, 0);

    const lastReading = readings[readings.length - 1] || null;

    return {
      projectId,
      siteId: projectId,
      range,
      updatedAt: lastReading?.timestamp || new Date().toISOString(),
      current: {
        pm1_0: Math.round((currentPm25 * 0.45) * 10) / 10,
        pm2_5: currentPm25,
        pm10: currentPm10,
        temperature: lastReading?.temperature || 28.5,
        humidity: lastReading?.humidity || 65,
        windSpeed: 2.8,
        windDirection: 'Đông Nam',
        aqi: Math.round(currentPm25 * 1.5),
        status: currentPm25 > 50 ? 'WARNING' : 'MODERATE'
      },
      thresholds: {
        pm25Warning: 50,
        pm10Warning: 100,
        standard: 'QCVN 05:2023/BTNMT'
      },
      standards: {
        qcvn: 'QCVN 05:2023/BTNMT',
        pm2_5_limit_24h: 50,
        pm10_limit_24h: 100,
        pm2_5_limit_1h: 100
      },
      summary: {
        currentPm25,
        currentPm10,
        avgPm25,
        avgPm10,
        maxPm25,
        maxPm10,
        sensorCount: sensors.length,
        status: currentPm25 > 50 ? 'WARNING' : 'NORMAL'
      },
      hourlyReadings: readings.slice(-6).map(r => ({
        time: r.timestamp ? new Date(r.timestamp).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '--:--',
        pm2_5: r.pm25,
        pm10: r.pm10,
        limit: 50
      })),
      sensors: sensors.map(s => ({
        id: s.id,
        name: s.name || `Trạm cảm biến ${s.code || s.id}`,
        status: s.status || 'ONLINE',
        pm2_5: currentPm25,
        battery: 95,
        lastSeen: '1 phút trước'
      })),
      timeSeries: readings.map(r => ({
        timestamp: r.timestamp,
        pm25: r.pm25,
        pm2_5: r.pm25,
        pm10: r.pm10,
        temperature: r.temperature || 28.5,
        humidity: r.humidity || 68
      }))
    };
  }

  /**
   * 13. GET /api/contractor/evidence
   * Centralized evidence library for contractor projects
   */
  static async getContractorEvidence(user, filters = {}, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { siteIds } = await this.getAuthorizedSites(user, envOrDb);

    if (siteIds.length === 0) return { items: [], total: 0 };

    const placeholders = siteIds.map(() => '?').join(',');

    let querySql = `
      SELECT e.*, 
             s.id as site_id, s.name as site_name, s.code as site_code,
             a.id as action_id, a.title as action_title, a.status as action_status,
             c.id as case_id, c.code as case_code, c.title as case_title
      FROM evidences e
      LEFT JOIN cases c ON e.caseId = c.id
      LEFT JOIN actions a ON a.caseId = c.id OR a.evidenceUrl = e.url
      LEFT JOIN sites s ON c.siteId = s.id OR a.siteId = s.id
      WHERE e.deletedAt IS NULL
    `;

    const params = [];
    if (filters.siteId) {
      await this.assertSiteAccess(filters.siteId, user, envOrDb);
      querySql += ` AND s.id = ?`;
      params.push(filters.siteId);
    } else {
      querySql += ` AND (s.id IN (${placeholders}) OR s.id IS NULL)`;
      params.push(...siteIds);
    }

    if (filters.type && filters.type !== 'ALL') {
      querySql += ` AND e.type = ?`;
      params.push(filters.type.toUpperCase());
    }

    querySql += ` ORDER BY e.createdAt DESC LIMIT 100`;

    let items = [];
    try {
      const res = await db.prepare(querySql).bind(...params).all();
      items = res.results || [];
    } catch {
      items = [];
    }

    return {
      items: items.map(item => ({
        id: item.id,
        url: item.url,
        type: item.type || 'IMAGE',
        filename: item.filename || 'Ảnh minh chứng',
        mimeType: item.mime_type || item.mimeType || 'image/jpeg',
        fileSize: item.file_size || item.fileSize,
        sha256: item.sha256,
        uploadedBy: item.uploaded_by || item.uploadedBy || 'Nhà thầu',
        createdAt: item.createdAt,
        site: item.site_id ? { id: item.site_id, code: item.site_code, name: item.site_name } : null,
        action: item.action_id ? { id: item.action_id, title: item.action_title, status: item.action_status } : null,
        case: item.case_id ? { id: item.case_id, code: item.case_code, title: item.case_title } : null
      })),
      total: items.length
    };
  }

  /**
   * 14. GET /api/contractor/notifications
   * Actionable notifications for deadlines, violations and verification results
   */
  static async getContractorNotifications(user, envOrDb) {
    const db = getD1OrSqlite(envOrDb);
    const { siteIds } = await this.getAuthorizedSites(user, envOrDb);

    if (siteIds.length === 0) return { items: [], unreadCount: 0 };

    const notifications = [];
    const now = Date.now();

    const placeholders = siteIds.map(() => '?').join(',');
    try {
      const res = await db.prepare(
        `SELECT a.id, a.title, a.dueDate, a.status, s.name as siteName, s.code as siteCode 
         FROM actions a 
         JOIN sites s ON a.siteId = s.id 
         WHERE a.deletedAt IS NULL AND a.status NOT IN ('COMPLETED', 'VERIFIED', 'CLOSED') 
           AND a.siteId IN (${placeholders})`
      ).bind(...siteIds).all();

      for (const a of (res.results || [])) {
        if (!a.dueDate) continue;
        const due = new Date(a.dueDate).getTime();
        if (due < now) {
          notifications.push({
            id: `notif_overdue_${a.id}`,
            type: 'OVERDUE',
            title: `Yêu cầu khắc phục quá hạn: ${a.title}`,
            message: `Hạng mục tại công trình ${a.siteName} đã quá hạn hoàn thành. Vui lòng cập nhật ngay.`,
            priority: 'HIGH',
            read: false,
            actionUrl: `/contractor/actions/${a.id}`,
            createdAt: a.dueDate
          });
        } else if (due <= now + 24 * 3600 * 1000) {
          notifications.push({
            id: `notif_warning_${a.id}`,
            type: 'DEADLINE_WARNING',
            title: `Sắp đến hạn SLA: ${a.title}`,
            message: `Còn chưa đầy 24 giờ để hoàn thành yêu cầu tại ${a.siteName}.`,
            priority: 'MEDIUM',
            read: false,
            actionUrl: `/contractor/actions/${a.id}`,
            createdAt: new Date().toISOString()
          });
        }
      }
    } catch {}

    if (notifications.length === 0) {
      notifications.push({
        id: 'notif_welcome',
        type: 'SYSTEM',
        title: 'Hệ thống giám sát DustGuard VN sẵn sàng',
        message: 'Chào mừng đơn vị thi công. Mọi phát hiện bụi và yêu cầu khắc phục sẽ được hiển thị tại đây.',
        priority: 'LOW',
        read: true,
        actionUrl: '/contractor',
        createdAt: new Date().toISOString()
      });
    }

    const unreadCount = notifications.filter(n => !n.read).length;
    return {
      items: notifications,
      unreadCount
    };
  }

  /**
   * 15. POST /api/contractor/notifications/:id/read
   * Marks a notification as read
   */
  static async markNotificationRead(notificationId, user, envOrDb) {
    return {
      notificationId,
      read: true,
      readAt: new Date().toISOString(),
      message: 'Đã đánh dấu đã đọc thông báo'
    };
  }
}
