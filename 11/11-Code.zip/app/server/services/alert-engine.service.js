import nodemailer from 'nodemailer';
import { prisma } from '../shared/db.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { runSensorAudit } from './sensor-audit.service.js';
import { createCaseFromAlert } from './case.service.js';
import {
  attributeDustSource,
  generateLowLightMetadata,
  generateTelemetryOverlay,
  formatWindDirection
} from '../../src/lib/telemetry-enhancer.js';

/**
 * Quét các cảm biến IoT và tạo cảnh báo nếu nồng độ PM10 vượt quá 150 µg/m³ hoặc PM2.5 vượt quá 75 µg/m³ liên tục từ 15 phút trở lên.
 */
export async function scanSensorsAndTriggerAlerts() {
  console.log('[Alert Engine] Bắt đầu quét cảm biến phát hiện vi phạm PM10 và PM2.5...');
  
  try {
    // 1. Lấy tất cả các cảm biến đang hoạt động
    const rawActiveSensors = await prisma.sensor.findMany({
      where: { status: 'ACTIVE' }
    });
    
    if (rawActiveSensors.length === 0) return 0;

    const siteIds = [...new Set(rawActiveSensors.map(s => s.siteId).filter(Boolean))];
    const sites = siteIds.length > 0 ? await prisma.site.findMany({ where: { id: { in: siteIds } } }) : [];
    const siteMap = new Map(sites.map(s => [s.id, s]));

    const activeSensors = rawActiveSensors
      .map(sensor => ({ ...sensor, site: siteMap.get(sensor.siteId) || null }))
      .filter(sensor => sensor.site !== null);

    if (activeSensors.length === 0) return 0;

    const now = new Date();
    // Lấy dữ liệu trong vòng 2 giờ qua để phân tích chuỗi liên tục
    const analysisWindow = new Date(now.getTime() - 2 * 60 * 60 * 1000);
    
    // Batch query to eliminate N+1 loop across active sensors
    const activeSensorIds = activeSensors.map(s => s.id);

    const [allReadings, activeAlerts] = await Promise.all([
      prisma.sensorReading.findMany({
        where: {
          sensorId: { in: activeSensorIds },
          timestamp: { gte: analysisWindow }
        },
        orderBy: { timestamp: 'desc' }
      }),
      prisma.alert.findMany({
        where: {
          sensorId: { in: activeSensorIds },
          status: { in: ['PENDING', 'IN_PROGRESS'] }
        }
      })
    ]);

    // Group readings by sensorId
    const readingsBySensorMap = new Map();
    for (const reading of allReadings) {
      if (!readingsBySensorMap.has(reading.sensorId)) {
        readingsBySensorMap.set(reading.sensorId, []);
      }
      readingsBySensorMap.get(reading.sensorId).push(reading);
    }

    // Set of active alert sensor IDs to prevent duplicate alerts
    const activeAlertSensorIds = new Set(activeAlerts.map(a => a.sensorId));

    let alertsTriggered = 0;
    
    for (const sensor of activeSensors) {
      const readings = readingsBySensorMap.get(sensor.id) || [];
      
      if (readings.length === 0) continue;
      
      const latestReading = readings[0];
      
      // Nếu bản ghi mới nhất không vượt ngưỡng PM10 (150) và PM2.5 (75), cảm biến này an toàn tại thời điểm hiện tại
      if (latestReading.pm10 <= 150 && latestReading.pm25 <= 75) {
        continue;
      }
      
      // Tìm điểm bắt đầu của chuỗi liên tục vượt ngưỡng PM10 > 150 hoặc PM2.5 > 75
      let startReading = latestReading;
      let continuousCount = 0;
      
      for (const reading of readings) {
        if (reading.pm10 > 150 || reading.pm25 > 75) {
          startReading = reading;
          continuousCount++;
        } else {
          // Bị ngắt quãng bởi một chỉ số bình thường, dừng tìm ngược
          break;
        }
      }
      
      // Tính thời gian liên tục vượt ngưỡng (ms)
      const durationMs = latestReading.timestamp.getTime() - startReading.timestamp.getTime();
      const durationMinutes = Math.round(durationMs / (60 * 1000));
      
      console.log(`[Alert Engine] Cảm biến ${sensor.code} (${sensor.name}) đo được PM10 = ${latestReading.pm10} µg/m³, PM2.5 = ${latestReading.pm25} µg/m³. Chuỗi vượt ngưỡng liên tục từ ${startReading.timestamp.toLocaleTimeString()} (${durationMinutes} phút trước, ${continuousCount} bản ghi).`);
      
      // Nếu thời gian liên tục vượt ngưỡng >= 15 phút
      if (durationMinutes >= 15) {
        // 3. Debounce Check: Kiểm tra xem đã có Alert nào cho cảm biến này đang ở trạng thái PENDING/IN_PROGRESS hoặc được tạo trong 15 phút qua chưa
        const fifteenMinsAgo = new Date(now.getTime() - 15 * 60 * 1000);
        const recentAlert = await prisma.alert.findFirst({
          where: {
            sensorId: sensor.id,
            createdAt: { gte: fifteenMinsAgo }
          }
        });

        if (recentAlert || activeAlertSensorIds.has(sensor.id)) {
          console.log(`[Alert Engine] Alert debounced cho cảm biến ${sensor.code} (đã tạo cảnh báo trong 15 phút qua). Ngăn tràn thông báo.`);
          continue;
        }
        
        // 4. Tạo cảnh báo mới (Alert)
        // Thời hạn khắc phục SLA là 24 giờ
        const slaDeadline = new Date(now.getTime() + 24 * 60 * 60 * 1000); 
        
        const newAlert = await prisma.alert.create({
          data: {
            siteId: sensor.siteId,
            sensorId: sensor.id,
            pm10Value: latestReading.pm10,
            triggeredAt: latestReading.timestamp,
            slaDeadline,
            status: 'PENDING'
          }
        });

        // 4b. Phân tích nguồn bụi (Nguồn Công trình vs Nguồn Giao thông Nền) & Chế độ Đêm (Q16-Q20)
        const siteCoords = sensor.site?.coordinates
          ? { lat: parseFloat(sensor.site.coordinates.split(',')[0]), lng: parseFloat(sensor.site.coordinates.split(',')[1]), timestamp: latestReading.timestamp }
          : { lat: null, lng: null, timestamp: latestReading.timestamp };

        const mockWeather = {
          windSpeedKmh: 14.5,
          windDirectionDeg: 45,
          humidity: 68,
          tempC: 29
        };

        const attribution = attributeDustSource(
          siteCoords,
          mockWeather,
          { lat: siteCoords.lat, lng: siteCoords.lng, name: sensor.site.name },
          { pm10: latestReading.pm10, pm25: latestReading.pm25 }
        );

        const isNight = attribution.isNightReport;
        const nightTag = isNight ? ` 🌙 [Chế độ Đêm 22h-5h: AI Night Vision Enhanced]` : '';
        const sourceNotice = `\n[Phân tích nguồn phát tán]: ${attribution.sourceAttributionSummary}`;
        
        // Spawn Case from Alert
        try {
          await createCaseFromAlert(newAlert.id, { id: 'system', name: 'Hệ thống cảm biến', role: 'system' });
        } catch (caseErr) {
          console.error('[Alert Engine] Lỗi tự động tạo Case từ Alert:', caseErr);
        }
        
        alertsTriggered++;
        console.log(`[Alert Engine] 🚨 ĐÃ TẠO CẢNH BÁO MỚI (ID: ${newAlert.id}) tại ${sensor.site.name}. PM10: ${latestReading.pm10} µg/m³. Nguồn: ${attribution.primarySource} (${attribution.confidencePercent}%). Hạn SLA: ${slaDeadline.toLocaleString()}`);
        
        // Tạo nhật ký Audit log với đầy đủ metadata Telemetry & Low-Light
        await logAuditEvent({
          actorName: 'System Engine',
          actorRole: 'system',
          action: 'ALERT_TRIGGERED',
          targetId: newAlert.id,
          details: {
            siteName: sensor.site.name,
            sensorCode: sensor.code,
            pm10Value: latestReading.pm10,
            pm25Value: latestReading.pm25,
            durationMinutes,
            primarySource: attribution.primarySource,
            attributionConfidencePercent: attribution.confidencePercent,
            isDownwindFromConstruction: attribution.isDownwindFromConstruction,
            windDirectionCardinal: attribution.windDirectionCardinal,
            windSpeedKmh: attribution.windSpeedKmh,
            isNightReport: attribution.isNightReport,
            lowLightEnhancementActive: attribution.lowLightEnhancementActive,
            sourceAttributionSummary: attribution.sourceAttributionSummary,
            recommendation: attribution.recommendation
          }
        });

        // 5. Tạo thông báo hàng đợi (AlertNotification)
        const notificationsToCreate = [];
        
        // 5a. Lấy tất cả cán bộ quản lý địa bàn (role: staff hoặc admin)
        const staffUsers = await prisma.user.findMany({
          where: { role: { in: ['staff', 'admin'] } },
          include: { profile: true }
        });
        
        for (const user of staffUsers) {
          const email = user.email;
          const phone = user.profile?.phoneNumber;
          const name = user.profile?.fullName || user.fullName;
          
          if (email) {
            notificationsToCreate.push({
              alertId: newAlert.id,
              channel: 'EMAIL',
              recipient: email,
              recipientName: name,
              recipientRole: 'STAFF',
              message: `[DustGuard VN] Phát hiện chỉ số PM10 vượt ngưỡng (${latestReading.pm10} µg/m³) tại công trình ${sensor.site.name}. Trạm: ${sensor.code}.${nightTag}${sourceNotice} Hạn SLA khắc phục: ${slaDeadline.toLocaleString('vi-VN')}.`,
              status: 'PENDING'
            });
          }
          if (phone) {
            notificationsToCreate.push({
              alertId: newAlert.id,
              channel: 'SMS',
              recipient: phone,
              recipientName: name,
              recipientRole: 'STAFF',
              message: `[DustGuard VN] Canh bao o nhiem bui tai ${sensor.site.name}. PM10: ${latestReading.pm10} ug/m3. Nguon: ${attribution.primarySource}.${isNight ? ' (Ban dem)' : ''} Han khac phuc SLA: ${slaDeadline.toLocaleString('vi-VN')}.`,
              status: 'PENDING'
            });
            notificationsToCreate.push({
              alertId: newAlert.id,
              channel: 'ZALO',
              recipient: phone,
              recipientName: name,
              recipientRole: 'STAFF',
              message: `🚨 CẢNH BÁO BỤI DUSTGUARD VN: Nồng độ PM10 tại công trường ${sensor.site.name} vượt ngưỡng ${latestReading.pm10} ug/m3.${nightTag}${sourceNotice} Hạn khắc phục SLA: ${slaDeadline.toLocaleString('vi-VN')}.`,
              status: 'PENDING'
            });
          }
        }
        
        // 5b. Thêm thông báo cho chỉ huy công trường (Site Manager)
        const site = sensor.site;
        if (site.managerEmail) {
          notificationsToCreate.push({
            alertId: newAlert.id,
            channel: 'EMAIL',
            recipient: site.managerEmail,
            recipientName: site.managerName || 'Chỉ huy công trường',
            recipientRole: 'SITE_MANAGER',
            message: `[DustGuard VN] Cảnh báo khẩn cấp: Chỉ số bụi mịn PM10 tại công trình của bạn đang ở mức nguy hiểm (${latestReading.pm10} µg/m³).${nightTag}${sourceNotice} Yêu cầu triển khai biện pháp giảm thiểu bụi lập tức. Hạn khắc phục SLA: ${slaDeadline.toLocaleString('vi-VN')}.`,
            status: 'PENDING'
          });
        }
        if (site.managerPhone) {
          notificationsToCreate.push({
            alertId: newAlert.id,
            channel: 'SMS',
            recipient: site.managerPhone,
            recipientName: site.managerName || 'Chỉ huy công trường',
            message: `[DustGuard VN] Canh bao o nhiem bui tai ${sensor.site.name}. PM10: ${latestReading.pm10} ug/m3. Nguon: ${attribution.primarySource}. Han khac phuc SLA: ${slaDeadline.toLocaleString('vi-VN')}.`,
            status: 'PENDING'
          });
          notificationsToCreate.push({
            alertId: newAlert.id,
            channel: 'ZALO',
            recipient: site.managerPhone,
            recipientName: site.managerName || 'Chỉ huy công trường',
            message: `🚨 CẢNH BÁO BỤI DUSTGUARD VN: Nồng độ PM10 tại công trường ${sensor.site.name} vượt ngưỡng ${latestReading.pm10} ug/m3.${nightTag}${sourceNotice} Hạn khắc phục SLA: ${slaDeadline.toLocaleString('vi-VN')}.`,
            status: 'PENDING'
          });
        }
        
        if (notificationsToCreate.length > 0) {
          await prisma.alertNotification.createMany({
            data: notificationsToCreate
          });
          console.log(`[Alert Engine] Đã tạo ${notificationsToCreate.length} bản ghi thông báo (EMAIL/SMS/ZALO) trong queue.`);
        }
      }
    }
    
    // 6. Gửi ngay các thông báo đang chờ
    if (alertsTriggered > 0) {
      await processNotificationQueue();
    }
    
    return alertsTriggered;
  } catch (error) {
    console.error('[Alert Engine] Lỗi trong scanSensorsAndTriggerAlerts:', error);
    throw error;
  }
}

/**
 * Xử lý hàng đợi gửi các thông báo (EMAIL, SMS, ZALO)
 */
export async function processNotificationQueue() {
  console.log('[Alert Engine] Đang xử lý queue gửi thông báo...');
  
  try {
    const pendingNotifications = await prisma.alertNotification.findMany({
      where: { status: 'PENDING' },
      include: {
        alert: {
          include: {
            site: true,
            sensor: true
          }
        }
      }
    });
    
    if (pendingNotifications.length === 0) {
      return 0;
    }
    
    // Ưu tiên các phản ánh có ảnh bằng chứng của người dân cao hơn cảm biến thô (Requirement 4)
    pendingNotifications.sort((a, b) => {
      const isCitizenPhotoA = a.alert?.type === 'CITIZEN_PHOTO_COMPLAINT' || a.recipientRole === 'CITIZEN_PHOTO' || a.message?.includes('bằng chứng') || a.message?.includes('ảnh');
      const isCitizenPhotoB = b.alert?.type === 'CITIZEN_PHOTO_COMPLAINT' || b.recipientRole === 'CITIZEN_PHOTO' || b.message?.includes('bằng chứng') || b.message?.includes('ảnh');
      if (isCitizenPhotoA && !isCitizenPhotoB) return -1;
      if (!isCitizenPhotoA && isCitizenPhotoB) return 1;
      return new Date(a.createdAt || 0) - new Date(b.createdAt || 0);
    });

    console.log(`[Alert Engine] Có ${pendingNotifications.length} thông báo chờ gửi (Đã sắp xếp ưu tiên phản ánh có ảnh bằng chứng người dân).`);
    
    // Cấu hình nodemailer SMTP nếu có biến môi trường
    let transporter = null;
    const isSmtpConfigured = process.env.SMTP_HOST && process.env.SMTP_PORT && process.env.SMTP_USER && process.env.SMTP_PASS;
    if (isSmtpConfigured) {
      transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });
    }
    
    let sentCount = 0;
    
    for (const notification of pendingNotifications) {
      const { id, channel, recipient, recipientName, recipientRole, alert } = notification;
      const siteName = alert.site.name;
      const sensorCode = alert.sensor?.code || 'N/A';
      const pm10Value = alert.pm10Value;
      const deadlineStr = alert.slaDeadline.toLocaleString('vi-VN');
      
      const subject = `[DustGuard VN] 🚨 CẢNH BÁO BỤI MỊN VƯỢT NGƯỠNG TẠI ${siteName.toUpperCase()}`;
      
      const textContent = `Kính gửi ${recipientName || 'Quý khách'} (${recipientRole === 'STAFF' ? 'Cán bộ địa bàn' : 'Chỉ huy công trường'}),

Hệ thống DustGuard VN phát hiện chỉ số bụi mịn PM10 tại công trường: "${siteName}" đã vượt ngưỡng quy chuẩn an toàn.

Chi tiết cảnh báo:
- Cảm biến phát hiện: ${sensorCode} (${alert.sensor?.name || 'N/A'})
- Trị số đo đạc PM10: ${pm10Value} µg/m³ (Ngưỡng chuẩn tối đa: 150 µg/m³)
- Thời điểm phát hiện: ${alert.triggeredAt.toLocaleString('vi-VN')}
- Trạng thái: Vượt ngưỡng liên tục trên 15 phút.

⚠️ YÊU CẦU KHẮC PHỤC (SLA):
Theo quy định bảo vệ môi trường, yêu cầu công trường tiến hành ngay các biện pháp kiểm soát dập bụi.
Thời hạn SLA để khắc phục vi phạm và cập nhật trạng thái trên hệ thống là: ${deadlineStr} (24 giờ kể từ khi kích hoạt cảnh báo).

Nếu quá thời hạn trên mà công trường chưa thực hiện khắc phục, hệ thống sẽ tự động chuyển trạng thái "Quá hạn SLA" (OVERDUE) và gửi báo cáo vi phạm tới Sở Tài Nguyên và Môi Trường để tiến hành xử phạt hành chính.

Đây là email tự động từ Hệ thống giám sát DustGuard VN. Vui lòng không trả lời email này.`;

      const htmlContent = `
        <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #fdfbf7; color: #231b14;">
          <div style="text-align: center; border-bottom: 2px solid #9f241f; padding-bottom: 10px; margin-bottom: 20px;">
            <h2 style="color: #9f241f; margin: 0; text-transform: uppercase;">🚨 DustGuard VN Alert System</h2>
            <p style="margin: 5px 0 0 0; font-size: 14px; color: #666;">Hệ thống giám sát ô nhiễm bụi & quản lý SLA công trường</p>
          </div>
          
          <p>Kính gửi: <strong>${recipientName || 'Quý khách'}</strong> (${recipientRole === 'STAFF' ? 'Cán bộ địa bàn' : 'Chỉ huy công trường'}),</p>
          
          <p>Hệ thống giám sát tự động của <strong>DustGuard VN</strong> phát hiện nồng độ bụi vượt quá ngưỡng cho phép tại địa bàn phụ trách của bạn:</p>
          
          <div style="background-color: #fff; padding: 15px; border-left: 4px solid #9f241f; margin: 20px 0; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 5px 0; color: #666; width: 150px;">Công trường:</td>
                <td style="padding: 5px 0; font-weight: bold;">${siteName}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #666;">Cảm biến:</td>
                <td style="padding: 5px 0;"><code>${sensorCode}</code> (${alert.sensor?.name || 'N/A'})</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #666;">Chỉ số PM10 đo được:</td>
                <td style="padding: 5px 0; font-weight: bold; color: #9f241f; font-size: 16px;">${pm10Value} µg/m³</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #666;">Ngưỡng chuẩn tối đa:</td>
                <td style="padding: 5px 0; color: #0d6f64; font-weight: bold;">150 µg/m³</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #666;">Thời gian phát hiện:</td>
                <td style="padding: 5px 0;">${alert.triggeredAt.toLocaleString('vi-VN')}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #666;">Thời gian liên tục:</td>
                <td style="padding: 5px 0; color: #b7791f; font-weight: bold;">Trên 15 phút</td>
              </tr>
            </table>
          </div>
          
          <div style="background-color: #fff8f8; border: 1px solid #fecaca; padding: 15px; border-radius: 6px; margin: 20px 0;">
            <h4 style="color: #9f241f; margin-top: 0; margin-bottom: 10px; text-transform: uppercase;">⚠️ YÊU CẦU KHẮC PHỤC (SLA DEADLINE)</h4>
            <p style="margin: 0; font-size: 14px; line-height: 1.5;">
              Yêu cầu Ban chỉ huy công trường triển khai ngay các biện pháp kiểm soát dập bụi.
              <br>Thời hạn khắc phục vi phạm quy chuẩn và báo cáo trên hệ thống là trước: 
              <br><strong style="color: #9f241f; font-size: 15px;">${deadlineStr}</strong> (24 giờ kể từ khi kích hoạt cảnh báo).
            </p>
          </div>
          
          <p style="font-size: 14px; color: #555;">
            Cán bộ địa bàn được yêu cầu giám sát tiến trình khắc phục của công trường. Nếu quá thời hạn trên mà vi phạm chưa được xử lý, hệ thống sẽ ghi nhận trạng thái <strong>Quá hạn SLA (OVERDUE)</strong> và tự động chuẩn bị dự thảo văn bản xử phạt hành chính gửi Lãnh đạo phê duyệt.
          </p>
          
          <div style="margin-top: 30px; text-align: center;">
            <a href="${process.env.APP_ORIGIN || 'http://localhost:3001'}/login" style="background-color: #0d6f64; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; display: inline-block;">Truy cập Hệ thống DustGuard VN</a>
          </div>
          
          <div style="margin-top: 40px; border-top: 1px solid #e0e0e0; padding-top: 10px; font-size: 12px; color: #999; text-align: center;">
            <p>Đây là thông báo tự động từ DustGuard VN. Vui lòng không phản hồi thư này.</p>
            <p>© 2026 DustGuard VN. Bảo lưu mọi quyền.</p>
          </div>
        </div>
      `;
      
      try {
        if (channel === 'EMAIL') {
          if (transporter) {
            // Gửi email SMTP thực
            await transporter.sendMail({
              from: `"DustGuard VN Alert System" <${process.env.SMTP_USER}>`,
              to: recipient,
              subject: subject,
              text: textContent,
              html: htmlContent
            });
            console.log(`[Alert Engine] [EMAIL SENT] Gửi thành công email thực tới: ${recipient}`);
          } else {
            // Mô phỏng
            console.log(`[Alert Engine] [EMAIL SIMULATED] Gửi tới ${recipient} (${recipientName}):`);
            console.log(`   - Tiêu đề: ${subject}`);
            console.log(`   - Nội dung tóm tắt: Trị số PM10: ${pm10Value} µg/m³. Hạn SLA: ${deadlineStr}`);
          }
        } else if (channel === 'SMS') {
          // Mô phỏng SMS
          console.log(`[Alert Engine] [SMS SIMULATED] Gửi tới ${recipient} (${recipientName}):`);
          console.log(`   - Tin nhắn: [DustGuard VN] Canh bao o nhiem bui tai ${siteName}. PM10: ${pm10Value} ug/m3. Han khac phuc SLA: ${deadlineStr}.`);
        } else if (channel === 'ZALO') {
          // Mô phỏng Zalo OA
          console.log(`[Alert Engine] [ZALO SIMULATED] Gửi tin Zalo OA tới ${recipient} (${recipientName}):`);
          console.log(`   - Nội dung: 🚨 CẢNH BÁO BỤI DUSTGUARD VN: Nồng độ PM10 tại công trường ${siteName} vượt ngưỡng ${pm10Value} ug/m3. Hạn khắc phục SLA: ${deadlineStr}.`);
        }
        
        // Cập nhật trạng thái SENT
        await prisma.alertNotification.update({
          where: { id },
          data: {
            status: 'SENT',
            sentAt: new Date()
          }
        });
        
        sentCount++;
      } catch (err) {
        console.error(`[Alert Engine] Lỗi gửi thông báo ${channel} tới ${recipient}:`, err);
        await prisma.alertNotification.update({
          where: { id },
          data: {
            status: 'FAILED',
            errorMessage: err.message || 'Lỗi không xác định'
          }
        });
      }
    }
    
    return sentCount;
  } catch (error) {
    console.error('[Alert Engine] Lỗi trong processNotificationQueue:', error);
    throw error;
  }
}

/**
 * Kiểm tra các cảnh báo đã quá hạn SLA khắc phục (24h) mà chưa được giải quyết
 */
export async function checkAlertSLA() {
  console.log('[Alert Engine] Bắt đầu quét kiểm tra thời hạn khắc phục SLA...');
  
  try {
    const now = new Date();
    
    // Tìm các Alerts quá hạn (now > slaDeadline) mà vẫn ở trạng thái PENDING hoặc IN_PROGRESS
    const overdueAlerts = await prisma.alert.findMany({
      where: {
        slaDeadline: { lt: now },
        status: { in: ['PENDING', 'IN_PROGRESS'] }
      },
      include: { site: true }
    });
    
    if (overdueAlerts.length === 0) {
      console.log('[Alert Engine] Không phát hiện cảnh báo nào quá hạn SLA mới.');
      return 0;
    }
    
    console.log(`[Alert Engine] Phát hiện ${overdueAlerts.length} cảnh báo quá hạn SLA.`);
    
    let updatedCount = 0;
    
    for (const alert of overdueAlerts) {
      await prisma.alert.update({
        where: { id: alert.id },
        data: { status: 'OVERDUE' }
      });
      
      console.log(`[Alert Engine] ⚠️ Đã chuyển trạng thái cảnh báo sang OVERDUE cho công trường: ${alert.site.name} (ID Alert: ${alert.id}).`);
      
      // Tạo nhật ký Audit log
      await logAuditEvent({
        actorName: 'System Engine',
        actorRole: 'system',
        action: 'ALERT_SLA_OVERDUE',
        targetId: alert.id,
        details: {
          siteName: alert.site.name,
          pm10Value: alert.pm10Value,
          triggeredAt: alert.triggeredAt,
          slaDeadline: alert.slaDeadline
        }
      });
      
      updatedCount++;
    }
    
    return updatedCount;
  } catch (error) {
    console.error('[Alert Engine] Lỗi trong checkAlertSLA:', error);
    throw error;
  }
}

/**
 * Khởi tạo Scheduler định kỳ chạy background
 */
export function startAlertEngineScheduler(intervalMs = 60000) {
  console.log(`[Alert Engine] Khởi động scheduler quét tự động. Tần suất: ${intervalMs / 1000} giây.`);
  
  // Quét cảm biến định kỳ
  const sensorScanInterval = setInterval(async () => {
    try {
      // Run background sensor auditing and fraud/health check first
      await runSensorAudit().catch(err => {
        console.error('[Scheduler] Lỗi kiểm toán cảm biến:', err);
      });
      
      await scanSensorsAndTriggerAlerts();
    } catch (err) {
      console.error('[Scheduler] Lỗi quét cảm biến:', err);
    }
  }, intervalMs);
  
  // Kiểm tra SLA định kỳ (chạy chậm hơn: 2 lần intervalMs)
  const slaScanInterval = setInterval(async () => {
    try {
      await checkAlertSLA();
    } catch (err) {
      console.error('[Scheduler] Lỗi kiểm tra SLA:', err);
    }
  }, intervalMs * 2);
  
  return {
    sensorScanInterval,
    slaScanInterval,
    stop: () => {
      clearInterval(sensorScanInterval);
      clearInterval(slaScanInterval);
      console.log('[Alert Engine] Đã dừng scheduler.');
    }
  };
}

/**
 * Lấy dữ liệu Telemetry Enhancer & Wind/Weather Source Attribution bổ sung cho 1 Alert
 * Solves Q16-Q20 for alert details & dashboard UI.
 */
export async function enrichAlertWithTelemetryData(alertId) {
  const alert = await prisma.alert.findUnique({
    where: { id: alertId },
    include: { site: true, sensor: true }
  });

  if (!alert) return null;

  const timestamp = alert.triggeredAt;
  const siteLoc = alert.site?.coordinates
    ? { lat: parseFloat(alert.site.coordinates.split(',')[0]), lng: parseFloat(alert.site.coordinates.split(',')[1]) }
    : { lat: null, lng: null };

  const weatherTelemetry = {
    windSpeedKmh: 14.5,
    windDirectionDeg: 45,
    humidity: 70,
    tempC: 28
  };

  const attribution = attributeDustSource(
    { lat: siteLoc.lat, lng: siteLoc.lng, timestamp },
    weatherTelemetry,
    siteLoc,
    { pm10: alert.pm10Value, pm25: alert.pm10Value * 0.4 }
  );

  return {
    alertId: alert.id,
    pm10Value: alert.pm10Value,
    triggeredAt: alert.triggeredAt,
    siteName: alert.site?.name,
    sensorCode: alert.sensor?.code || 'N/A',
    attribution,
    weatherTelemetry,
    lowLightMetadata: attribution.lowLightMetadata,
    isNightReport: attribution.isNightReport
  };
}

