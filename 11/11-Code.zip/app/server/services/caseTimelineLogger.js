import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';

const EVENT_TITLES = {
  // English/Machine codes
  'CREATION': 'Khởi tạo vụ việc',
  'ASSIGNMENT': 'Phân công cán bộ',
  'EXPLANATION_REQUESTED': 'Yêu cầu giải trình',
  'EXPLANATION_SUBMITTED': 'Nộp giải trình',
  'DECISION_ISSUED': 'Ban hành quyết định thanh tra',
  'CLOSED': 'Đóng hồ sơ vụ việc',
  'DOCUMENT_SUBMITTED': 'Nộp tài liệu/biên bản',
  'DOCUMENT_APPROVED': 'Phê duyệt tài liệu',
  // 7-step process
  'PREPARING': 'Chuẩn bị thanh tra',
  'ON_SITE': 'Đến cơ sở kiểm tra',
  'REPORTING': 'Lập báo cáo & dự thảo kết quả',
  'APPRAISING': 'Thẩm định hồ sơ',
  'COMPLETED': 'Ban hành kết quả công khai xử lý',
  'STATUS_PREPARING': 'Chuẩn bị thanh tra',
  'STATUS_DECISION_ISSUED': 'Ban hành quyết định thanh tra',
  'STATUS_ON_SITE': 'Đến cơ sở kiểm tra',
  'STATUS_REPORTING': 'Lập báo cáo & dự thảo kết quả',
  'STATUS_APPRAISING': 'Thẩm định hồ sơ',
  'STATUS_COMPLETED': 'Ban hành kết quả công khai xử lý',
};

/**
 * Helper to log an event in a Case's timeline.
 * Every major change in a Case's state, inspector assignment, or document submittal should write here.
 * 
 * @param {string} caseId - The ID of the Case
 * @param {string} action - The action key / event type (e.g. 'CREATION', 'EXPLANATION_REQUESTED')
 * @param {string} [notes] - Optional detail/description notes
 * @param {Object} [req] - Optional Express Request object to extract actor details
 * @returns {Promise<Object>} The created CaseTimeline entry
 */
export async function logCaseEvent(caseId, action, notes = '', req = null) {
  let actorId = null;
  let actorName = 'System';
  let actorRole = 'system';

  if (req && req.user) {
    actorId = req.user.id || 'anonymous';
    actorName = req.user.fullName || req.user.full_name || req.user.name || 'anonymous';
    actorRole = req.user.role || 'anonymous';
  } else if (req) {
    actorId = 'anonymous';
    actorName = 'Anonymous';
    actorRole = 'anonymous';
  }

  const eventType = action ? action.toUpperCase() : 'UNKNOWN';
  const eventTitle = EVENT_TITLES[eventType] || action || 'Hoạt động vụ việc';

  try {
    const timelineEntry = await prisma.caseTimeline.create({
      data: {
        caseId,
        eventType,
        eventTitle,
        eventDescription: notes || null,
        actorId,
        actorName,
        actorRole,
      },
    });

    logger.info(`Case Timeline Event logged: ${eventType} for case ${caseId}`, {
      caseId,
      eventType,
      eventTitle,
      actorName,
      actorRole,
    });

    return timelineEntry;
  } catch (error) {
    logger.error('Failed to log Case Timeline Event', {
      error: error.message,
      caseId,
      eventType,
      actorName,
    });
    return null;
  }
}
