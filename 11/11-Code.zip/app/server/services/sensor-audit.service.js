import { prisma } from '../shared/db.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { DataQualityEngine } from '../domain/sensors/data-quality.engine.js';

/**
 * Runs a background health check and data quality audit on all sensors in the system.
 * 1. Flatline detection: If the last 5 readings are identical and cover a timespan >= 10 mins,
 *    mark the sensor status as 'FAULTY' and log audit event 'SENSOR_TAMPER_SUSPECTED'.
 * 2. Liveness timeout: If the latest reading is older than 15 mins, mark the sensor status as 'INACTIVE'.
 *    If the sensor receives a new reading later (older reading becomes fresh), it recovers back to 'ACTIVE'.
 * 3. Sudden jump / Anomaly check: Flags unrealistic rate-of-change spikes.
 * 
 * @returns {Promise<{
 *   flatlinesDetected: number,
 *   timeoutsDetected: number,
 *   anomaliesDetected: number,
 *   totalSensorsAudited: number,
 *   averageQualityScore: number
 * }>}
 */
export async function runSensorAudit() {
  console.log('[Sensor Audit] Starting background sensor health and tamper audit...');
  
  try {
    const rawSensors = await prisma.sensor.findMany();
    
    if (rawSensors.length === 0) {
      return {
        flatlinesDetected: 0,
        timeoutsDetected: 0,
        anomaliesDetected: 0,
        totalSensorsAudited: 0,
        averageQualityScore: 100
      };
    }

    const siteIds = [...new Set(rawSensors.map(s => s.siteId).filter(Boolean))];
    const sites = siteIds.length > 0 ? await prisma.site.findMany({ where: { id: { in: siteIds } } }) : [];
    const siteMap = new Map(sites.map(s => [s.id, s]));

    const sensors = rawSensors.map(sensor => ({
      ...sensor,
      site: siteMap.get(sensor.siteId) || null
    }));

    const sensorIds = sensors.map(s => s.id);

    // Batch query to eliminate N+1 query loop across sensors
    const allReadings = await prisma.sensorReading.findMany({
      where: { sensorId: { in: sensorIds } },
      orderBy: { timestamp: 'desc' }
    });

    // Map up to top 10 latest readings per sensorId
    const lastReadingsBySensorMap = new Map();
    for (const reading of allReadings) {
      let list = lastReadingsBySensorMap.get(reading.sensorId);
      if (!list) {
        list = [];
        lastReadingsBySensorMap.set(reading.sensorId, list);
      }
      if (list.length < 10) {
        list.push(reading);
      }
    }

    const now = new Date();
    let flatlinesDetected = 0;
    let timeoutsDetected = 0;
    let anomaliesDetected = 0;
    let totalQualityScoreSum = 0;
    
    for (const sensor of sensors) {
      // Get the latest readings for this sensor from pre-fetched map
      const lastReadings = lastReadingsBySensorMap.get(sensor.id) || [];
      const latestReading = lastReadings[0] || null;

      // Evaluate comprehensive Data Quality Engine score
      const qualityReport = latestReading
        ? DataQualityEngine.evaluateTelemetryQuality({
            reading: latestReading,
            recentReadings: lastReadings.slice(1),
            hardwareProfile: sensor.model || 'DUSTGUARD_SOLAR_V1',
            calibrationStatus: 'CALIBRATED'
          })
        : { score: 50, flags: ['NO_READINGS'], diagnostics: { flatline: { isFlatline: false } } };

      totalQualityScoreSum += qualityReport.score;

      // 1. Flatline Check: Detect identical readings
      if (qualityReport.diagnostics?.flatline?.isFlatline || lastReadings.length >= 5) {
        const flatlineCheck = DataQualityEngine.detectFlatline(lastReadings);
        if (flatlineCheck.isFlatline) {
          const firstReading = lastReadings[0];
          
          if (sensor.status !== 'FAULTY') {
            await prisma.sensor.update({
              where: { id: sensor.id },
              data: { status: 'FAULTY' }
            });
            
            await logAuditEvent({
              actorName: 'System Audit',
              actorRole: 'system',
              action: 'SENSOR_TAMPER_SUSPECTED',
              targetId: sensor.id,
              details: {
                sensorCode: sensor.code,
                sensorName: sensor.name,
                siteName: sensor.site?.name,
                flatlinePM10: firstReading.pm10,
                flatlinePM25: firstReading.pm25,
                timeSpanMins: flatlineCheck.timeSpanMins,
                readingsCount: flatlineCheck.consecutiveCount
              }
            });
            
            flatlinesDetected++;
            console.log(`[Sensor Audit] Sensor ${sensor.code} flagged as FAULTY due to flatline detection (PM10: ${firstReading.pm10}, PM25: ${firstReading.pm25}).`);
          }
          // Skip liveness timeout check if already faulty
          continue;
        }
      }

      // Check Sudden Jump anomalies
      if (qualityReport.diagnostics?.suddenJump?.hasSuddenJump) {
        anomaliesDetected++;
      }
      
      // 2. Liveness Timeout Check: Latest reading older than 15 mins
      if (latestReading) {
        const ageMs = now.getTime() - latestReading.timestamp.getTime();
        const ageMins = ageMs / (60 * 1000);
        
        if (ageMins > 15) {
          if (sensor.status !== 'INACTIVE' && sensor.status !== 'FAULTY') {
            await prisma.sensor.update({
              where: { id: sensor.id },
              data: { status: 'INACTIVE' }
            });
            
            await logAuditEvent({
              actorName: 'System Audit',
              actorRole: 'system',
              action: 'SENSOR_LIVENESS_TIMEOUT',
              targetId: sensor.id,
              details: {
                sensorCode: sensor.code,
                sensorName: sensor.name,
                siteName: sensor.site?.name,
                lastReadingTimestamp: latestReading.timestamp,
                ageMins: Math.round(ageMins)
              }
            });
            
            timeoutsDetected++;
            console.log(`[Sensor Audit] Sensor ${sensor.code} flagged as INACTIVE due to liveness timeout (${Math.round(ageMins)} mins).`);
          }
        } else {
          // Auto-recover back to ACTIVE if we have a fresh reading and the status was INACTIVE
          if (sensor.status === 'INACTIVE') {
            await prisma.sensor.update({
              where: { id: sensor.id },
              data: { status: 'ACTIVE' }
            });
            
            await logAuditEvent({
              actorName: 'System Audit',
              actorRole: 'system',
              action: 'SENSOR_RECOVERED',
              targetId: sensor.id,
              details: {
                sensorCode: sensor.code,
                sensorName: sensor.name,
                siteName: sensor.site?.name
              }
            });
            console.log(`[Sensor Audit] Sensor ${sensor.code} recovered to ACTIVE (received fresh reading).`);
          }
        }
      } else {
        // No readings at all. Check if the sensor itself was created > 15 mins ago
        const ageMs = now.getTime() - sensor.createdAt.getTime();
        const ageMins = ageMs / (60 * 1000);
        
        if (ageMins > 15 && sensor.status !== 'INACTIVE' && sensor.status !== 'FAULTY') {
          await prisma.sensor.update({
            where: { id: sensor.id },
            data: { status: 'INACTIVE' }
          });
          
          await logAuditEvent({
            actorName: 'System Audit',
            actorRole: 'system',
            action: 'SENSOR_LIVENESS_TIMEOUT',
            targetId: sensor.id,
            details: {
              sensorCode: sensor.code,
              sensorName: sensor.name,
              siteName: sensor.site?.name,
              reason: 'No readings received since creation (>15 mins)'
            }
          });
          
          timeoutsDetected++;
          console.log(`[Sensor Audit] Sensor ${sensor.code} flagged as INACTIVE due to no readings received since creation.`);
        }
      }
    }

    const averageQualityScore = sensors.length > 0 ? Math.round(totalQualityScoreSum / sensors.length) : 100;
    
    return {
      flatlinesDetected,
      timeoutsDetected,
      anomaliesDetected,
      totalSensorsAudited: sensors.length,
      averageQualityScore
    };
  } catch (error) {
    console.error('[Sensor Audit] Error running sensor health and tamper audit:', error);
    throw error;
  }
}
