import { prisma } from '../shared/db.js';
import { checkSlaViolations } from './case.service.js';
import { sendContractorNotification } from './case.service.js';

/**
 * Runs an immediate check on all active cases for SLA violations.
 * Updates case status, updates SanctionDecision status to OVERDUE if needed,
 * logs events in CaseTimeline, and triggers notifications.
 */
export async function runSlaCheckNow() {
  console.log('[SLA Checker] Running background scan on active cases...');
  try {
    const activeCases = await prisma.case.findMany({
      where: {
        status: { notIn: ['COMPLETED', 'CLOSED'] }
      },
      include: {
        sanctionDecisions: { orderBy: { createdAt: 'desc' } },
        timeline: true
      }
    });

    for (const caseObj of activeCases) {
      const slaResult = await checkSlaViolations(caseObj);
      if (!slaResult.isViolated) continue;

      for (const violation of slaResult.violations) {
        // 1. Check if this specific violation event was already logged to prevent duplicates
        const alreadyLogged = caseObj.timeline.some(
          t => t.eventType === `SLA_VIOLATION_${violation}`
        );

        if (!alreadyLogged) {
          console.warn(`[SLA Checker] Violation detected: ${violation} on Case: ${caseObj.code}`);
          
          let eventTitle = '';
          let eventDescription = '';

          if (violation === 'VERIFICATION_OVERDUE') {
            eventTitle = 'Quá hạn xác minh vụ việc';
            eventDescription = `Vụ việc đã quá hạn 2 ngày kể từ lúc tạo nhưng chưa được cán bộ xác minh (Hạn chót: ${slaResult.deadlines.verificationDeadline.toLocaleString('vi-VN')}).`;
          } else if (violation === 'EXPLANATION_OVERDUE') {
            eventTitle = 'Quá hạn nộp giải trình';
            eventDescription = `Nhà thầu đã quá hạn 5 ngày để gửi giải trình cho vụ việc (Hạn chót: ${slaResult.deadlines.explanationDeadline?.toLocaleString('vi-VN')}).`;
          } else if (violation === 'RECTIFICATION_OVERDUE') {
            eventTitle = 'Quá hạn khắc phục hiện trường';
            eventDescription = `Công trường đã quá hạn 7 ngày để thực hiện các biện pháp khắc phục kỹ thuật dập bụi (Hạn chót: ${slaResult.deadlines.rectificationDeadline?.toLocaleString('vi-VN')}).`;
          } else if (violation === 'FINE_OVERDUE') {
            eventTitle = 'Quá hạn nộp phạt hành chính';
            eventDescription = `Nhà thầu đã quá hạn 10 ngày để nộp phạt vi phạm hành chính (Hạn chót: ${slaResult.deadlines.fineDeadline?.toLocaleString('vi-VN')}).`;

            // If fine is overdue, update the active SanctionDecision status to OVERDUE
            const activeDecision = caseObj.sanctionDecisions?.[0];
            if (activeDecision && activeDecision.status !== 'PAID') {
              await prisma.sanctionDecision.update({
                where: { id: activeDecision.id },
                data: { status: 'OVERDUE' }
              });
            }
          }

          // Create SLA violation event in timeline
          await prisma.caseTimeline.create({
            data: {
              caseId: caseObj.id,
              eventType: `SLA_VIOLATION_${violation}`,
              eventTitle,
              eventDescription,
              actorId: null,
              actorName: 'SLA Guard Engine',
              actorRole: 'system'
            }
          });

          // Trigger warning notification to contractor
          await sendContractorNotification(caseObj.id, `SLA_ALERT_${violation}`);
        }
      }
    }
    console.log('[SLA Checker] SLA scan completed successfully.');
  } catch (error) {
    console.error('[SLA Checker] Error running SLA check:', error);
  }
}

/**
 * Starts a recurring background scheduler to check Case SLAs.
 * Defaults to checking every 30 minutes in production, but runs a check immediately.
 * @param {number} [intervalMs=1800000] Interval in milliseconds (default 30 minutes)
 */
export function startSlaScheduler(intervalMs = 1800000) {
  // Run an initial check on startup
  runSlaCheckNow();

  // Schedule recurring checks
  const timer = setInterval(() => {
    runSlaCheckNow();
  }, intervalMs);

  return timer;
}
