import { randomUUID } from 'node:crypto';
import { query, withTransaction } from '../db/pg-query.js';
import { safeJsonParse } from '../lib/jsonHelper.js';

function getNow() {
    return new Date().toISOString();
}

function normalizeRequirementRow(row) {
    if (!row) return null;
    return {
        ...row,
        legal_basis: safeJsonParse(row.legal_basis, {}),
        evidence_required: safeJsonParse(row.evidence_required, []),
    };
}

function createReviewLockedError() {
    const error = new Error('Tài liệu đã có yêu cầu được duyệt. Không thể chạy lại pipeline.');
    error.code = 'REVIEW_LOCKED';
    return error;
}

async function ensureNoReviewedRequirements(docId, client = { query }) {
    const result = await client.query(
        "SELECT id FROM procurement_requirements WHERE \"docId\" = $1 AND status IN ('approved', 'rejected') LIMIT 1",
        [docId],
    );
    if (result.rows[0]) throw createReviewLockedError();
}

export async function createProcurementDocument(text, sourceType = 'text') {
    const id = `pdoc_${randomUUID()}`;
    await query(
        `INSERT INTO procurement_documents (id, text, source_type, status, "createdAt", "updatedAt")
         VALUES ($1, $2, $3, 'pending', $4, $5)`,
        [id, text, sourceType, getNow(), getNow()],
    );
    return getProcurementDocument(id);
}

export async function getProcurementDocument(id) {
    const result = await query('SELECT * FROM procurement_documents WHERE id = $1', [id]);
    return result.rows[0] || null;
}

export async function updateProcurementDocumentStatus(id, status) {
    await query('UPDATE procurement_documents SET status = $1, "updatedAt" = $2 WHERE id = $3', [status, getNow(), id]);
}

export async function saveProcurementRequirements(docId, requirements) {
    await withTransaction(async client => {
        await ensureNoReviewedRequirements(docId, client);
        await client.query('DELETE FROM procurement_requirements WHERE "docId" = $1', [docId]);

        for (const req of requirements) {
            const id = `preq_${randomUUID()}`;
            await client.query(
                `INSERT INTO procurement_requirements (
                  id, "docId", requirement_id, category, requirement_text, condition, legal_basis,
                  evidence_required, risk_level, checklist_item, recommended_action, confidence_score,
                  status, "createdAt"
                ) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb, $9, $10, $11, $12, 'pending', $13)`,
                [
                    id,
                    docId,
                    req.requirement_id || id,
                    req.category || null,
                    req.requirement_text || req.action || 'Yêu cầu tuân thủ mua sắm',
                    req.condition || null,
                    JSON.stringify(req.legal_basis || {}),
                    JSON.stringify(req.evidence_required || []),
                    req.risk_level || 'medium',
                    req.checklist_item || null,
                    req.recommended_action || null,
                    req.confidence_score || 0,
                    getNow(),
                ],
            );
        }
    });
}

export async function getProcurementRequirements(docId) {
    const result = await query('SELECT * FROM procurement_requirements WHERE "docId" = $1', [docId]);
    return result.rows.map(normalizeRequirementRow);
}

export async function hasReviewedProcurementRequirements(docId) {
    const result = await query(
        "SELECT id FROM procurement_requirements WHERE \"docId\" = $1 AND status IN ('approved', 'rejected') LIMIT 1",
        [docId],
    );
    return Boolean(result.rows[0]);
}

export async function updateProcurementRequirementStatus(id, status) {
    const current = await query('SELECT * FROM procurement_requirements WHERE id = $1', [id]);
    if (!current.rows[0]) return null;
    if ((current.rows[0].status === 'approved' || current.rows[0].status === 'rejected') && status === 'pending') return null;

    const result = await query('UPDATE procurement_requirements SET status = $1 WHERE id = $2 RETURNING *', [status, id]);
    return normalizeRequirementRow(result.rows[0]);
}
