import { randomUUID } from 'node:crypto';
import { getD1OrSqlite } from '../shared/db.js';

/**
 * ==============================================================================
 * DUSTGUARD VN — FREE-FIRST, D1-NATIVE AUTOMATION & SWEEP ENGINE
 * ==============================================================================
 * Architecture:
 * - 100% Free-tier compatible: Cloudflare Workers Scheduled Event + Cloudflare D1
 * - Zero Durable Objects, Zero Queues, Zero Redis, Zero paid infrastructure
 * - Soft SLA & Attention State SSOT decoupled from Workflow Status
 * - Paused Clock Support (Waiting on Contractor/Citizen/External)
 * - Bounded Batching (scale-to-zero safety, max 3 batches x 100 per sweep)
 * - Fully Idempotent with Minimal Audit Trail (automation_runs)
 * - Independent Sub-task Failure Isolation (Resilient execution)
 * ==============================================================================
 */

// 1. Attention States (Decoupled from workflow status)
export const ATTENTION_STATES = {
  NORMAL: 'NORMAL',
  DUE_SOON: 'DUE_SOON',
  NEEDS_ATTENTION: 'NEEDS_ATTENTION',
  OVERDUE: 'OVERDUE',
  CRITICAL: 'CRITICAL'
};

// 1.1. Automation Engine Operational Modes
export const AUTOMATION_MODES = {
  ACTIVE: 'ACTIVE',       // Full automated mode: scan, transition, prune, audit log
  DRY_RUN: 'DRY_RUN',     // Safety test mode: compute all metrics & diagnostics without DB write/delete
  DISABLED: 'DISABLED'    // Master Kill Switch: skip immediately in < 0.1ms with 0 CPU & 0 D1 reads
};

// Runtime In-Memory Configuration (Overridable via API or Environment Variables)
let runtimeAutomationConfig = {
  enabled: false,
  mode: AUTOMATION_MODES.DISABLED,
  enableCaseSweep: true,
  enableSensorSweep: true,
  enableFollowUpSweep: true,
  enableMaintenance: true,
  lastRunAt: null,
  lastStatus: 'DISABLED'
};

/**
 * Checks whether the automation engine / cron is enabled.
 * Supports Cloudflare Environment Variable kill switches (ENABLE_AUTOMATION, ENABLE_CRON, CRON_ENABLED)
 * as well as runtime in-memory toggle.
 */
export function isAutomationEnabled(env = {}) {
  const envVal = env?.ENABLE_AUTOMATION ?? env?.ENABLE_CRON ?? env?.CRON_ENABLED ??
                 process?.env?.ENABLE_AUTOMATION ?? process?.env?.ENABLE_CRON ?? process?.env?.CRON_ENABLED;
  if (envVal !== undefined && envVal !== null) {
    if (envVal === true || envVal === 'true' || envVal === '1') {
      return true;
    }
    if (envVal === false || envVal === 'false' || envVal === '0') {
      return false;
    }
  }
  return runtimeAutomationConfig.enabled && runtimeAutomationConfig.mode !== AUTOMATION_MODES.DISABLED;
}

/**
 * Returns the current automation engine configuration and status.
 */
export function getAutomationConfig(env = {}) {
  const envEnabled = isAutomationEnabled(env);
  return {
    ...runtimeAutomationConfig,
    enabled: envEnabled,
    mode: envEnabled ? runtimeAutomationConfig.mode : AUTOMATION_MODES.DISABLED
  };
}

/**
 * Updates the runtime automation engine configuration (toggle on/off, change mode).
 */
export function setAutomationConfig(newConfig = {}) {
  runtimeAutomationConfig = {
    ...runtimeAutomationConfig,
    ...newConfig
  };
  if (newConfig.enabled === false) {
    runtimeAutomationConfig.mode = AUTOMATION_MODES.DISABLED;
  } else if (newConfig.enabled === true && runtimeAutomationConfig.mode === AUTOMATION_MODES.DISABLED) {
    runtimeAutomationConfig.mode = AUTOMATION_MODES.ACTIVE;
  }
  if (newConfig.mode) {
    runtimeAutomationConfig.mode = newConfig.mode;
    runtimeAutomationConfig.enabled = newConfig.mode !== AUTOMATION_MODES.DISABLED;
  }
  return getAutomationConfig();
}

// 2. Default SLA Policy Configuration (Fully Configurable)
export const DEFAULT_SLA_POLICY = {
  acknowledgeTargetHours: 8,
  firstActionTargetHours: 24,
  resolutionTargetHours: 72,
  gracePeriodHours: 24,
  dueSoonThresholdHours: 6,
  staleSensorThresholdMinutes: 30,
  escalationMode: 'SOFT', // 'SOFT' | 'STRICT'
  batchSize: 100,
  maxBatches: 3
};

// 3. Priority-Specific Policies
export const PRIORITY_SLA_POLICIES = {
  CRITICAL: {
    acknowledgeTargetHours: 2,
    firstActionTargetHours: 8,
    resolutionTargetHours: 24,
    gracePeriodHours: 8,
    dueSoonThresholdHours: 2
  },
  P1: {
    acknowledgeTargetHours: 2,
    firstActionTargetHours: 8,
    resolutionTargetHours: 24,
    gracePeriodHours: 8,
    dueSoonThresholdHours: 2
  },
  HIGH: {
    acknowledgeTargetHours: 4,
    firstActionTargetHours: 16,
    resolutionTargetHours: 48,
    gracePeriodHours: 16,
    dueSoonThresholdHours: 4
  },
  P2: {
    acknowledgeTargetHours: 4,
    firstActionTargetHours: 16,
    resolutionTargetHours: 48,
    gracePeriodHours: 16,
    dueSoonThresholdHours: 4
  },
  MEDIUM: {
    acknowledgeTargetHours: 8,
    firstActionTargetHours: 24,
    resolutionTargetHours: 72,
    gracePeriodHours: 24,
    dueSoonThresholdHours: 6
  },
  P3: {
    acknowledgeTargetHours: 8,
    firstActionTargetHours: 24,
    resolutionTargetHours: 72,
    gracePeriodHours: 24,
    dueSoonThresholdHours: 6
  },
  LOW: {
    acknowledgeTargetHours: 24,
    firstActionTargetHours: 48,
    resolutionTargetHours: 120,
    gracePeriodHours: 48,
    dueSoonThresholdHours: 12
  },
  P4: {
    acknowledgeTargetHours: 24,
    firstActionTargetHours: 48,
    resolutionTargetHours: 120,
    gracePeriodHours: 48,
    dueSoonThresholdHours: 12
  }
};

/**
 * Returns merged SLA Policy for a case based on its priority and custom overrides.
 */
export function getSlaPolicyForCase(caseObj = {}, customPolicy = {}) {
  const priorityKey = (caseObj.priority || caseObj.riskLevel || 'MEDIUM').toUpperCase();
  const priorityDefaults = PRIORITY_SLA_POLICIES[priorityKey] || PRIORITY_SLA_POLICIES.MEDIUM;
  return {
    ...DEFAULT_SLA_POLICY,
    ...priorityDefaults,
    ...customPolicy
  };
}

/**
 * Evaluates soft attention state for a given entity without mutating workflow status.
 *
 * @param {Object} params
 * @param {Date|string|number} [params.createdAt] - Creation timestamp
 * @param {Date|string|number} [params.targetDeadline] - Target resolution / action deadline
 * @param {number} [params.gracePeriodHours=24] - Grace period in hours
 * @param {number} [params.dueSoonThresholdHours=6] - Threshold in hours before deadline to trigger DUE_SOON
 * @param {Date} [params.now=new Date()] - Reference point in time
 * @param {boolean} [params.isClockPaused=false] - Whether the active staff clock is paused (e.g. WAITING_CONTRACTOR)
 * @param {string} [params.status='OPEN'] - Current workflow status
 * @param {string} [params.priority='MEDIUM'] - Priority level
 * @returns {Object} Soft attention evaluation result
 */
export function evaluateAttentionState({
  createdAt,
  targetDeadline,
  gracePeriodHours = 24,
  dueSoonThresholdHours = 6,
  now = new Date(),
  isClockPaused = false,
  status = 'OPEN',
  priority = 'MEDIUM'
} = {}) {
  const nowTime = now instanceof Date ? now.getTime() : new Date(now).getTime();
  
  let targetTime;
  if (targetDeadline) {
    targetTime = targetDeadline instanceof Date ? targetDeadline.getTime() : new Date(targetDeadline).getTime();
  } else if (createdAt) {
    const createdTime = createdAt instanceof Date ? createdAt.getTime() : new Date(createdAt).getTime();
    targetTime = createdTime + 24 * 3600 * 1000;
  } else {
    targetTime = nowTime + 24 * 3600 * 1000;
  }

  const graceMs = (gracePeriodHours || 24) * 3600 * 1000;
  const graceDeadline = new Date(targetTime + graceMs);
  const remainingMs = targetTime - nowTime;
  const graceRemainingMs = graceDeadline.getTime() - nowTime;
  const dueSoonThresholdMs = (dueSoonThresholdHours || 6) * 3600 * 1000;

  // Identify waiting status (paused staff clock)
  const normalizedStatus = String(status || '').toUpperCase();
  const isWaiting = isClockPaused ||
    normalizedStatus.includes('WAITING_CONTRACTOR') ||
    normalizedStatus.includes('WAITING_CITIZEN') ||
    normalizedStatus.includes('WAITING_EXTERNAL');

  let waitingOn = null;
  if (isWaiting) {
    if (normalizedStatus.includes('CONTRACTOR')) waitingOn = 'CONTRACTOR';
    else if (normalizedStatus.includes('CITIZEN')) waitingOn = 'CITIZEN';
    else waitingOn = 'EXTERNAL';
  }

  let attentionState = ATTENTION_STATES.NORMAL;
  const isPastTarget = remainingMs <= 0;
  const isPastGrace = graceRemainingMs <= 0;
  const isDueSoon = remainingMs > 0 && remainingMs <= dueSoonThresholdMs;

  if (isWaiting) {
    // When staff clock is paused, staff cannot be faulted.
    // Attention state reflects external waiting progress softly.
    if (isPastGrace) {
      attentionState = ATTENTION_STATES.OVERDUE;
    } else if (isPastTarget) {
      attentionState = ATTENTION_STATES.NEEDS_ATTENTION;
    } else if (isDueSoon) {
      attentionState = ATTENTION_STATES.DUE_SOON;
    } else {
      attentionState = ATTENTION_STATES.NORMAL;
    }
  } else {
    // Normal Active Staff Clock
    if (isPastGrace) {
      const isCriticalPriority = String(priority).toUpperCase() === 'CRITICAL' || String(priority).toUpperCase() === 'P1';
      const isSeverelyOverdue = graceRemainingMs < -1 * graceMs; // Passed 2x grace period
      if (isCriticalPriority || isSeverelyOverdue) {
        attentionState = ATTENTION_STATES.CRITICAL;
      } else {
        attentionState = ATTENTION_STATES.OVERDUE;
      }
    } else if (isPastTarget) {
      attentionState = ATTENTION_STATES.NEEDS_ATTENTION;
    } else if (isDueSoon) {
      attentionState = ATTENTION_STATES.DUE_SOON;
    } else {
      attentionState = ATTENTION_STATES.NORMAL;
    }
  }

  return {
    attentionState,
    remainingHours: Math.round((remainingMs / 3600000) * 10) / 10,
    remainingMs,
    targetDeadline: new Date(targetTime).toISOString(),
    graceDeadline: graceDeadline.toISOString(),
    isPastTarget,
    isPastGrace,
    isDueSoon,
    isClockPaused: isWaiting,
    staffClockPaused: isWaiting,
    waitingOn,
    workflowStatus: status
  };
}

/**
 * Sub-task A: Sweep Case Attention & Soft Reminders (Bounded & Idempotent)
 * Evaluates active cases and emits soft reminders/timelines without hard-mutating status.
 * Optimized: Single batch query for existing timelines to eliminate N+1 subrequests on Cloudflare Workers.
 */
export async function sweepCaseAttention(envOrDb, options = {}) {
  const db = getD1OrSqlite(envOrDb);
  const now = options.now instanceof Date ? options.now : new Date();
  const batchSize = options.batchSize || DEFAULT_SLA_POLICY.batchSize;
  const maxBatches = options.maxBatches || DEFAULT_SLA_POLICY.maxBatches;

  let totalScanned = 0;
  let totalTransitions = 0;
  let totalRemindersSent = 0;
  const results = [];

  for (let batchIdx = 0; batchIdx < maxBatches; batchIdx++) {
    const offset = batchIdx * batchSize;
    const query = `
      SELECT id, code, title, status, slaDeadline, siteId, createdAt, updatedAt
      FROM cases
      WHERE status NOT IN ('COMPLETED', 'CLOSED')
        AND (deletedAt IS NULL)
      ORDER BY createdAt ASC
      LIMIT ? OFFSET ?
    `;

    const res = await db.prepare(query).bind(batchSize, offset).all();
    const cases = res?.results || [];

    if (cases.length === 0) break;
    totalScanned += cases.length;

    // Batch fetch existing attention timeline events for all cases in this batch to avoid N+1 queries
    const caseIds = cases.map(c => c.id);
    const existingEventsSet = new Set();
    if (caseIds.length > 0) {
      const placeholders = caseIds.map(() => '?').join(',');
      try {
        const eventsRes = await db.prepare(`
          SELECT caseId, eventType FROM case_timelines
          WHERE caseId IN (${placeholders}) AND eventType LIKE 'ATTENTION_%'
        `).bind(...caseIds).all();
        for (const ev of (eventsRes?.results || [])) {
          existingEventsSet.add(`${ev.caseId}:${ev.eventType}`);
        }
      } catch (e) {}
    }

    const timelinesToInsert = [];

    for (const caseItem of cases) {
      const policy = getSlaPolicyForCase(caseItem, options.policy);
      const evalResult = evaluateAttentionState({
        createdAt: caseItem.createdAt,
        targetDeadline: caseItem.slaDeadline,
        gracePeriodHours: policy.gracePeriodHours,
        dueSoonThresholdHours: policy.dueSoonThresholdHours,
        now,
        status: caseItem.status,
        priority: caseItem.priority
      });

      results.push({
        caseId: caseItem.id,
        code: caseItem.code,
        workflowStatus: caseItem.status,
        attentionState: evalResult.attentionState,
        remainingHours: evalResult.remainingHours,
        isClockPaused: evalResult.isClockPaused
      });

      // If state is not NORMAL, check idempotency before logging timeline reminder
      if (evalResult.attentionState !== ATTENTION_STATES.NORMAL) {
        const eventType = `ATTENTION_${evalResult.attentionState}`;
        const eventKey = `${caseItem.id}:${eventType}`;

        if (!existingEventsSet.has(eventKey)) {
          totalTransitions++;
          totalRemindersSent++;
          existingEventsSet.add(eventKey);

          if (!options.dryRun && options.mode !== 'DRY_RUN') {
            const timelineId = `tl-${randomUUID()}`;
            let eventTitle = `Cập nhật trạng thái theo dõi: ${evalResult.attentionState}`;
            let eventDescription = `Hệ thống ghi nhận hồ sơ đang ở mức: ${evalResult.attentionState}. Thời hạn còn lại: ${evalResult.remainingHours}h.`;

            if (evalResult.attentionState === ATTENTION_STATES.DUE_SOON) {
              eventTitle = 'Sắp đến hạn xử lý (DUE SOON)';
              eventDescription = `Hồ sơ còn ${evalResult.remainingHours}h để hoàn thành theo mục tiêu đề ra.`;
            } else if (evalResult.attentionState === ATTENTION_STATES.NEEDS_ATTENTION) {
              eventTitle = 'Hồ sơ cần chú ý (NEEDS ATTENTION)';
              eventDescription = `Hồ sơ đã qua hạn mục tiêu nhưng đang trong thời gian ân hạn (${policy.gracePeriodHours}h).`;
            } else if (evalResult.attentionState === ATTENTION_STATES.OVERDUE) {
              eventTitle = 'Hồ sơ quá hạn mục tiêu (OVERDUE)';
              eventDescription = `Hồ sơ đã vượt quá thời gian ân hạn. Cần kiểm tra tiến độ giải quyết.`;
            } else if (evalResult.attentionState === ATTENTION_STATES.CRITICAL) {
              eventTitle = 'Cảnh báo mức khẩn cấp (CRITICAL)';
              eventDescription = `Hồ sơ nghiêm trọng vượt quá hạn định kéo dài. Yêu cầu lãnh đạo can thiệp.`;
            }

            if (evalResult.isClockPaused) {
              eventDescription += ` (Đang tạm dừng tính thời gian cán bộ do chờ bên ngoài: ${evalResult.waitingOn})`;
            }

            timelinesToInsert.push({
              id: timelineId,
              caseId: caseItem.id,
              eventTitle,
              eventDescription,
              eventType,
              createdAt: now.toISOString()
            });
          }
        }
      }
    }

    // Batch insert timeline records
    if (timelinesToInsert.length > 0 && !options.dryRun && options.mode !== 'DRY_RUN') {
      if (typeof db.batch === 'function') {
        const stmts = timelinesToInsert.map(t =>
          db.prepare(`
            INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt)
            VALUES (?, ?, ?, ?, ?, 'Automation Engine', 'system', ?)
          `).bind(t.id, t.caseId, t.eventTitle, t.eventDescription, t.eventType, t.createdAt)
        );
        await db.batch(stmts).catch(() => {});
      } else {
        for (const t of timelinesToInsert) {
          await db.prepare(`
            INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt)
            VALUES (?, ?, ?, ?, ?, 'Automation Engine', 'system', ?)
          `).bind(t.id, t.caseId, t.eventTitle, t.eventDescription, t.eventType, t.createdAt).run().catch(() => ({ changes: 0 }));
        }
      }
    }

    if (cases.length < batchSize) break;
  }

  return {
    scanned: totalScanned,
    transitions: totalTransitions,
    remindersSent: totalRemindersSent,
    cases: results
  };
}

/**
 * Sub-task B: Sweep Sensor Health (Stale / Inactive & Flatline Detection)
 * Level 4 automated action: Reversible INACTIVE tagging on stale telemetry.
 * Optimized: Single batch query for readings and batch status updates to eliminate N+1 subrequests.
 */
export async function sweepSensorHealth(envOrDb, options = {}) {
  const db = getD1OrSqlite(envOrDb);
  const now = options.now instanceof Date ? options.now : new Date();
  const thresholdMins = options.staleSensorThresholdMinutes || DEFAULT_SLA_POLICY.staleSensorThresholdMinutes;
  const staleThresholdMs = thresholdMins * 60 * 1000;
  const nowTime = now.getTime();

  let scanned = 0;
  let markedInactive = 0;
  let markedFaulty = 0;
  let recoveredActive = 0;

  // Bounded batch fetch active and inactive sensors
  const res = await db.prepare(`
    SELECT id, code, name, siteId, status, createdAt, updatedAt
    FROM sensors
    WHERE (deletedAt IS NULL)
    LIMIT 100
  `).all();

  const sensors = res?.results || [];
  scanned = sensors.length;

  // Batch query latest readings for all sensors to prevent N+1 subrequests
  const sensorIds = sensors.map(s => s.id);
  const readingsBySensor = new Map();
  if (sensorIds.length > 0) {
    const placeholders = sensorIds.map(() => '?').join(',');
    let allReadings = [];
    try {
      const readingsRes = await db.prepare(`
        SELECT sensorId, pm10, pm25, timestamp
        FROM (
          SELECT sensorId, pm10, pm25, timestamp,
                 ROW_NUMBER() OVER (PARTITION BY sensorId ORDER BY timestamp DESC) as rn
          FROM sensor_readings
          WHERE sensorId IN (${placeholders})
        )
        WHERE rn <= 5
        ORDER BY sensorId, timestamp DESC
      `).bind(...sensorIds).all();
      allReadings = readingsRes?.results || [];
    } catch (windowErr) {
      try {
        const fallbackRes = await db.prepare(`
          SELECT sensorId, pm10, pm25, timestamp
          FROM sensor_readings
          WHERE sensorId IN (${placeholders})
          ORDER BY sensorId, timestamp DESC
        `).bind(...sensorIds).all();
        allReadings = fallbackRes?.results || [];
      } catch (e) {}
    }

    for (const r of allReadings) {
      if (!readingsBySensor.has(r.sensorId)) {
        readingsBySensor.set(r.sensorId, []);
      }
      const list = readingsBySensor.get(r.sensorId);
      if (list.length < 5) {
        list.push(r);
      }
    }
  }

  const toFaultyIds = [];
  const toInactiveIds = [];
  const toActiveIds = [];

  for (const sensor of sensors) {
    const readings = readingsBySensor.get(sensor.id) || [];

    // 1. Flatline Check (5 identical readings over >= 30 mins)
    if (readings.length === 5) {
      const first = readings[0];
      const allIdentical = readings.every(r => r.pm10 === first.pm10 && r.pm25 === first.pm25);
      if (allIdentical) {
        const oldest = readings[4];
        const spanMs = Math.abs(new Date(first.timestamp).getTime() - new Date(oldest.timestamp).getTime());
        if (spanMs >= 30 * 60 * 1000 && sensor.status !== 'FAULTY') {
          markedFaulty++;
          toFaultyIds.push(sensor.id);
          continue;
        }
      }
    }

    if (sensor.status === 'FAULTY') continue;

    // 2. Liveness Timeout Check
    if (readings.length > 0) {
      const latest = readings[0];
      const latestTime = new Date(latest.timestamp).getTime();
      const ageMs = nowTime - latestTime;

      if (ageMs > staleThresholdMs) {
        if (sensor.status === 'ACTIVE') {
          markedInactive++;
          toInactiveIds.push(sensor.id);
        }
      } else {
        // Auto-recover back to ACTIVE if fresh reading exists
        if (sensor.status === 'INACTIVE') {
          recoveredActive++;
          toActiveIds.push(sensor.id);
        }
      }
    } else {
      // No readings: check sensor creation age
      const createdTime = new Date(sensor.createdAt).getTime();
      if (nowTime - createdTime > staleThresholdMs && sensor.status === 'ACTIVE') {
        markedInactive++;
        toInactiveIds.push(sensor.id);
      }
    }
  }

  // Batch execute status updates
  if (!options.dryRun && options.mode !== 'DRY_RUN') {
    if (toFaultyIds.length > 0) {
      const ph = toFaultyIds.map(() => '?').join(',');
      await db.prepare(`UPDATE sensors SET status = 'FAULTY', updatedAt = ? WHERE id IN (${ph})`)
        .bind(now.toISOString(), ...toFaultyIds).run().catch(() => {});
    }
    if (toInactiveIds.length > 0) {
      const ph = toInactiveIds.map(() => '?').join(',');
      await db.prepare(`UPDATE sensors SET status = 'INACTIVE', updatedAt = ? WHERE id IN (${ph})`)
        .bind(now.toISOString(), ...toInactiveIds).run().catch(() => {});
    }
    if (toActiveIds.length > 0) {
      const ph = toActiveIds.map(() => '?').join(',');
      await db.prepare(`UPDATE sensors SET status = 'ACTIVE', updatedAt = ? WHERE id IN (${ph})`)
        .bind(now.toISOString(), ...toActiveIds).run().catch(() => {});
    }
  }

  return {
    scanned,
    markedInactive,
    markedFaulty,
    recoveredActive
  };
}

/**
 * Sub-task C: Sweep Follow-up & Community Action Due Queue
 */
export async function sweepFollowUpQueue(envOrDb, options = {}) {
  const db = getD1OrSqlite(envOrDb);
  const now = options.now instanceof Date ? options.now : new Date();
  const nowIso = now.toISOString();

  let pendingFollowUps = 0;
  let pendingObservations = 0;

  try {
    const followUpsRes = await db.prepare(`
      SELECT id, observation_id, case_id, outcome_status, created_at
      FROM follow_ups
      WHERE outcome_status = 'PENDING' OR verified_at IS NULL
      LIMIT 100
    `).all().catch(() => ({ results: [] }));
    pendingFollowUps = (followUpsRes?.results || []).length;
  } catch (e) {}

  try {
    const obsRes = await db.prepare(`
      SELECT id, code, status, created_at
      FROM observations
      WHERE status IN ('NEW', 'PENDING_VERIFICATION')
      LIMIT 100
    `).all().catch(() => ({ results: [] }));
    pendingObservations = (obsRes?.results || []).length;
  } catch (e) {}

  return {
    pendingFollowUps,
    pendingObservations,
    totalDue: pendingFollowUps + pendingObservations
  };
}

/**
 * Sub-task D: Sweep Maintenance (Better Auth Sessions & Idempotency Keys Pruning)
 * Bounded batch pruning: Max 3 batches x 100 records per sweep.
 * Ensures active Better Auth sessions are NEVER deleted.
 */
export async function sweepMaintenance(envOrDb, options = {}) {
  const db = getD1OrSqlite(envOrDb);
  const now = options.now instanceof Date ? options.now : new Date();
  const nowIso = now.toISOString();
  const batchSize = options.batchSize || DEFAULT_SLA_POLICY.batchSize;
  const maxBatches = options.maxBatches || DEFAULT_SLA_POLICY.maxBatches;

  let expiredSessionsPruned = 0;
  let expiredIdempotencyPruned = 0;

  // If dry-run, count candidate records without deleting
  if (options.dryRun || options.mode === 'DRY_RUN') {
    const sessCount = (await db.prepare('SELECT count(*) as count FROM session WHERE expiresAt < ?').bind(nowIso).first().catch(() => ({ count: 0 })))?.count || 0;
    const idemCount = (await db.prepare('SELECT count(*) as count FROM idempotency_keys WHERE expires_at < ?').bind(nowIso).first().catch(() => ({ count: 0 })))?.count || 0;
    return {
      dryRun: true,
      expiredSessionsPruned: sessCount,
      expiredIdempotencyPruned: idemCount,
      totalPruned: sessCount + idemCount
    };
  }

  // 1. Prune expired Better Auth sessions in bounded batches
  for (let i = 0; i < maxBatches; i++) {
    const res = await db.prepare(`
      DELETE FROM session
      WHERE id IN (
        SELECT id FROM session
        WHERE expiresAt < ?
        LIMIT ?
      )
    `).bind(nowIso, batchSize).run().catch(() => ({ meta: { changes: 0 } }));

    const count = res?.meta?.changes || res?.changes || 0;
    expiredSessionsPruned += count;
    if (count < batchSize) break;
  }

  // 2. Prune expired idempotency keys in bounded batches
  for (let i = 0; i < maxBatches; i++) {
    const res = await db.prepare(`
      DELETE FROM idempotency_keys
      WHERE key IN (
        SELECT key FROM idempotency_keys
        WHERE expires_at < ?
        LIMIT ?
      )
    `).bind(nowIso, batchSize).run().catch(() => ({ meta: { changes: 0 } }));

    const count = res?.meta?.changes || res?.changes || 0;
    expiredIdempotencyPruned += count;
    if (count < batchSize) break;
  }

  return {
    expiredSessionsPruned,
    expiredIdempotencyPruned,
    totalPruned: expiredSessionsPruned + expiredIdempotencyPruned
  };
}

/**
 * Main Operational Sweep Engine Orchestrator
 * Invoked by Cloudflare Scheduled Worker, REST API endpoint, or Node CLI test runner.
 *
 * @param {Object} envOrDb - Worker environment binding or Database handle
 * @param {Object} [options] - Options (now, runMaintenance, policy overrides)
 * @returns {Promise<Object>} Execution report with minimal audit logging
 */
export async function runOperationalSweep(envOrDb, options = {}) {
  const startedAt = new Date();
  const db = getD1OrSqlite(envOrDb);

  // 1. Check Master Kill Switch / Enabled Flag / Dry Run
  const isDryRun = options.mode === AUTOMATION_MODES.DRY_RUN ||
                   options.dryRun === true ||
                   runtimeAutomationConfig.mode === AUTOMATION_MODES.DRY_RUN;

  const isEnabled = options.enabled ?? (isDryRun || options.force ? true : isAutomationEnabled(envOrDb));
  if (!isEnabled) {
    const finishedAt = new Date();
    return {
      runId: `run-skipped-${randomUUID()}`,
      jobName: 'operational_sweep',
      status: 'SKIPPED',
      mode: AUTOMATION_MODES.DISABLED,
      enabled: false,
      message: 'Tác vụ tự động đã tạm tắt (Automation disabled via config or kill switch)',
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: finishedAt.getTime() - startedAt.getTime(),
      scannedCount: 0,
      changedCount: 0,
      errorCount: 0,
      tasks: {
        caseAttention: { status: 'SKIPPED' },
        sensorHealth: { status: 'SKIPPED' },
        followUpQueue: { status: 'SKIPPED' },
        maintenance: { status: 'SKIPPED' }
      }
    };
  }

  const sweepOptions = { ...options, dryRun: isDryRun };

  const runId = `run-${randomUUID()}`;
  const jobName = isDryRun ? 'operational_sweep_dryrun' : 'operational_sweep';

  // Log initial record into automation_runs
  await db.prepare(`
    INSERT INTO automation_runs (id, job_name, started_at, status)
    VALUES (?, ?, ?, 'RUNNING')
  `).bind(runId, jobName, startedAt.toISOString()).run().catch(() => ({ changes: 0 }));

  const report = {
    runId,
    jobName,
    mode: isDryRun ? AUTOMATION_MODES.DRY_RUN : AUTOMATION_MODES.ACTIVE,
    dryRun: isDryRun,
    startedAt: startedAt.toISOString(),
    tasks: {},
    errors: [],
    scannedCount: 0,
    changedCount: 0,
    errorCount: 0
  };

  // Task 1: Case Attention Soft Sweep (Isolated Try/Catch)
  if (sweepOptions.enableCaseSweep !== false && runtimeAutomationConfig.enableCaseSweep !== false) {
    try {
      const caseResult = await sweepCaseAttention(db, sweepOptions);
      report.tasks.caseAttention = { status: 'SUCCESS', ...caseResult };
      report.scannedCount += caseResult.scanned;
      report.changedCount += caseResult.transitions;
    } catch (err) {
      report.tasks.caseAttention = { status: 'FAILED', error: err.message };
      report.errors.push(`CaseAttentionError: ${err.message}`);
      report.errorCount++;
    }
  } else {
    report.tasks.caseAttention = { status: 'SKIPPED', message: 'Tác vụ quét hồ sơ đã tắt theo cấu hình' };
  }

  // Task 2: Sensor Health Sweep (Isolated Try/Catch)
  if (sweepOptions.enableSensorSweep !== false && runtimeAutomationConfig.enableSensorSweep !== false) {
    try {
      const sensorResult = await sweepSensorHealth(db, sweepOptions);
      report.tasks.sensorHealth = { status: 'SUCCESS', ...sensorResult };
      report.scannedCount += sensorResult.scanned;
      report.changedCount += (sensorResult.markedInactive + sensorResult.markedFaulty + sensorResult.recoveredActive);
    } catch (err) {
      report.tasks.sensorHealth = { status: 'FAILED', error: err.message };
      report.errors.push(`SensorHealthError: ${err.message}`);
      report.errorCount++;
    }
  } else {
    report.tasks.sensorHealth = { status: 'SKIPPED', message: 'Tác vụ quét cảm biến đã tắt theo cấu hình' };
  }

  // Task 3: Follow-Up & Action Due Queue Sweep (Isolated Try/Catch)
  if (sweepOptions.enableFollowUpSweep !== false && runtimeAutomationConfig.enableFollowUpSweep !== false) {
    try {
      const followUpResult = await sweepFollowUpQueue(db, sweepOptions);
      report.tasks.followUpQueue = { status: 'SUCCESS', ...followUpResult };
    } catch (err) {
      report.tasks.followUpQueue = { status: 'FAILED', error: err.message };
      report.errors.push(`FollowUpError: ${err.message}`);
      report.errorCount++;
    }
  } else {
    report.tasks.followUpQueue = { status: 'SKIPPED', message: 'Tác vụ quét hàng chờ xác minh đã tắt theo cấu hình' };
  }

  // Task 4: Maintenance Sweep (Idempotency & Session Pruning) (Isolated Try/Catch)
  if (sweepOptions.enableMaintenance !== false && runtimeAutomationConfig.enableMaintenance !== false) {
    try {
      const maintenanceResult = await sweepMaintenance(db, sweepOptions);
      report.tasks.maintenance = { status: 'SUCCESS', ...maintenanceResult };
      report.changedCount += maintenanceResult.totalPruned;
    } catch (err) {
      report.tasks.maintenance = { status: 'FAILED', error: err.message };
      report.errors.push(`MaintenanceError: ${err.message}`);
      report.errorCount++;
    }
  } else {
    report.tasks.maintenance = { status: 'SKIPPED', message: 'Tác vụ dọn dẹp phiên đăng nhập đã tắt theo cấu hình' };
  }

  const finishedAt = new Date();
  report.finishedAt = finishedAt.toISOString();
  report.durationMs = finishedAt.getTime() - startedAt.getTime();

  let finalStatus = 'SUCCESS';
  if (report.errorCount > 0) {
    finalStatus = report.errorCount === Object.keys(report.tasks).length ? 'FAILED' : 'PARTIAL';
  }
  report.status = finalStatus;

  runtimeAutomationConfig.lastRunAt = finishedAt.toISOString();
  runtimeAutomationConfig.lastStatus = finalStatus;

  // Persist final execution outcome into automation_runs
  await db.prepare(`
    UPDATE automation_runs
    SET finished_at = ?,
        status = ?,
        scanned_count = ?,
        changed_count = ?,
        error_count = ?,
        error_message = ?,
        details_json = ?
    WHERE id = ?
  `).bind(
    report.finishedAt,
    finalStatus,
    report.scannedCount,
    report.changedCount,
    report.errorCount,
    report.errors.length > 0 ? report.errors.join('; ') : null,
    JSON.stringify(report.tasks),
    runId
  ).run().catch(() => ({ changes: 0 }));

  return report;
}

/**
 * Queries recent automation execution history from automation_runs table
 */
export async function getRecentAutomationRuns(envOrDb, limit = 20) {
  const db = getD1OrSqlite(envOrDb);
  const boundedLimit = Math.min(Math.max(1, limit), 100);
  const res = await db.prepare(`
    SELECT id, job_name, started_at, finished_at, status, scanned_count, changed_count, error_count, error_message, details_json, created_at
    FROM automation_runs
    ORDER BY started_at DESC
    LIMIT ?
  `).bind(boundedLimit).all();

  return res?.results || [];
}
