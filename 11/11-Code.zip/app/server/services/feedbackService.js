import fs from 'fs';
import path from 'path';
import crypto from 'node:crypto';
import logger from '../lib/logger.js';

function getNow() {
  return new Date().toISOString();
}

function generateFeedbackId() {
  const randomHex = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `FB-${randomHex}`;
}

export async function createFeedbackAndSendEmail(input, meta = {}) {
  const id = generateFeedbackId();
  const feedback = {
    id,
    name: input.name || null,
    email: input.email || null,
    message: input.message,
    page: input.page || '/',
    language: input.language || 'vi-en',
    targetTeam: 'contest-dev',
    status: 'sent',
    meta,
    createdAt: getNow(),
    updatedAt: getNow(),
  };

  logger.info('New feedback received', { feedbackId: id, name: feedback.name, email: feedback.email, page: feedback.page });

  // Persist feedback to a local scratch JSON file
  const filePath = path.resolve(process.cwd(), 'scratch', 'feedbacks.json');
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    let existing = [];
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8').trim();
      existing = content ? JSON.parse(content) : [];
    }
    existing.push(feedback);
    fs.writeFileSync(filePath, JSON.stringify(existing, null, 2), 'utf-8');
  } catch (err) {
    logger.error('Failed to write feedback to file', { error: err.message });
  }

  // Simulate successful delivery
  return feedback;
}
