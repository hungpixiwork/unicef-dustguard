import { randomBytes } from 'crypto';
import { prisma } from '../shared/db.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import {
  computeImageHash,
  verifyPhotoIntegrity,
  verifyImageIntegrity,
  INTEGRITY_LABELS,
  isAntiDefamationProtected,
  canBeUsedAsEvidence
} from '../../src/lib/image-integrity.js';
import {
  CASE_STATUS,
  normalizeStatus,
  isValidTransition,
  validateCaseTransition
} from '../domain/cases/case.rules.js';

export { CASE_STATUS, normalizeStatus, isValidTransition, validateCaseTransition };

/**
 * Sends a simulated notification (Email/SMS) to the contractor about a case event.
 * @param {string} caseId - The ID of the Case
 * @param {string} eventType - The type of event (e.g. CASE_CREATED, VIOLATED)
 */
export async function sendContractorNotification(caseId, eventType) {
  try {
    const caseObj = await prisma.case.findFirst({
      where: { id: caseId, deletedAt: null },
      include: { site: true }
    });
    if (!caseObj || !caseObj.site) return;

    const contractorEmail = caseObj.site.managerEmail || 'contractor@dustguard.vn';
    const contractorName = caseObj.site.contractorName || 'Đại diện Nhà thầu';

    // Log the notification sending event to the CaseTimeline
    await prisma.caseTimeline.create({
      data: {
        caseId,
        eventType: 'NOTIFICATION_SENT',
        eventTitle: 'Thông báo tự động tới Nhà thầu',
        eventDescription: `Đã gửi cảnh báo tự động qua Email/SMS tới nhà thầu (${contractorName} - ${contractorEmail}). Chủ đề: ${eventType}.`,
        actorId: null,
        actorName: 'System Notification Hub',
        actorRole: 'system'
      }
    });

    console.log(`[Notification Hub] Email sent to ${contractorEmail} regarding Case ${caseObj.code} (${eventType})`);
  } catch (error) {
    console.error("Failed to send contractor notification:", error);
  }
}

/**
 * Creates a new case manually.
 * @param {Object} params
 * @param {string} params.siteId - The ID of the construction site
 * @param {string} params.title - Title of the case
 * @param {string} [params.description] - Description/details of the case
 * @param {string} [params.complaintId] - Associated citizen complaint ID
 * @param {string} [params.inspectionId] - Associated officer inspection ID
 * @param {Object} [params.actor] - The actor triggering the creation { id, name, role }
 * @returns {Promise<Object>} Created case object
 */
export async function createCase({ siteId, title, description, complaintId, inspectionId, actor, sourceType, sourceId, priority }) {
  if (!siteId) {
    throw new Error('Site ID is required to create a case');
  }
  if (!title) {
    throw new Error('Title is required to create a case');
  }

  // Entity Integrity Guard: verify site exists before creating case
  const site = await prisma.site.findFirst({
    where: {
      OR: [{ id: siteId }, { code: siteId }],
      deletedAt: null
    }
  });
  if (!site) {
    throw new Error(`Site with ID ${siteId} not found`);
  }

  // Generate unique code with retry on collision (6-char hex = 16M possibilities)
  const year = new Date().getFullYear();
  let newCase;
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = `CASE-${year}-${randomBytes(3).toString('hex').toUpperCase()}`;
    try {
      newCase = await prisma.case.create({
        data: {
          code,
          title,
          description: description || null,
          siteId: site.id,
          complaintId: complaintId || null,
          inspectionId: inspectionId || null,
          sourceType: sourceType || null,
          sourceId: sourceId || null,
          status: 'SCREENING',
          priority: priority || undefined
        }
      });
      break; // success
    } catch (err) {
      if (err.code === 'P2002' && attempt < 4) continue; // retry on unique collision
      throw err;
    }
  }

  // Log the initial state transition timeline event
  await prisma.caseTimeline.create({
    data: {
      caseId: newCase.id,
      eventType: 'STATUS_SCREENING',
      eventTitle: 'Khởi tạo vụ việc',
      eventDescription: 'Vụ việc được tạo mới với trạng thái SCREENING (Tiếp nhận sàng lọc). Thời hạn xác minh là 2 ngày.',
      actorId: actor?.id || null,
      actorName: actor?.name || 'System',
      actorRole: actor?.role || 'system'
    }
  });

  // Track initial status in CaseStatusHistory
  if (prisma.caseStatusHistory) {
    try {
      await prisma.caseStatusHistory.create({
        data: {
          caseId: newCase.id,
          fromStatus: 'NONE',
          toStatus: 'SCREENING',
          changedBy: actor?.id || null,
          actorName: actor?.name || 'System',
          actorRole: actor?.role || 'system',
          note: 'Khởi tạo vụ việc mới (SCREENING)'
        }
      });
    } catch (cshErr) {
      console.warn('[CaseStatusHistory] Failed to log initial status:', cshErr.message);
    }
  }

  // Log audit log
  await logAuditEvent({
    actorId: actor?.id,
    actorName: actor?.name,
    actorRole: actor?.role,
    action: 'CASE_CREATE',
    targetId: newCase.id,
    details: {
      code: newCase.code,
      title,
      siteId,
      complaintId,
      inspectionId
    }
  });

  // Trigger automatic contractor notification
  await sendContractorNotification(newCase.id, 'CASE_CREATED');

  return newCase;
}

/**
 * Creates a case automatically from a citizen complaint.
 * @param {string} complaintId - The ID of the Complaint
 * @param {Object} [actor] - The actor triggering this action
 * @param {string} [title] - Custom case title (optional)
 * @param {string} [description] - Custom case description (optional)
 * @param {Object} [options] - Additional options { priority }
 * @returns {Promise<Object>} Created case object
 */
export async function createCaseFromComplaint(complaintId, actor, title = null, description = null, options = {}) {
  const complaint = await prisma.complaint.findUnique({
    where: { id: complaintId }
  });

  if (!complaint) {
    throw new Error(`Citizen Complaint with ID ${complaintId} not found`);
  }

  if (!complaint.siteId) {
    throw new Error(`Cannot create case from complaint ${complaint.code} because it is not associated with a construction site.`);
  }

  // Guard against duplicate cases for the same complaint
  const existing = await prisma.case.findFirst({ where: { complaintId, deletedAt: null } });
  if (existing) return existing;

  const caseTitle = title || `Vụ việc phản ánh ${complaint.code}`;
  const caseDescription = description || complaint.description;

  const newCase = await createCase({
    siteId: complaint.siteId,
    complaintId: complaint.id,
    title: caseTitle,
    description: caseDescription,
    actor,
    priority: options.priority || complaint.priority || undefined
  });

  // Automatically update the source complaint status to PROCESSING
  await prisma.complaint.update({
    where: { id: complaintId },
    data: { status: 'PROCESSING' }
  });

  return newCase;
}

/**
 * Creates a case automatically from an IoT Sensor Alert.
 * @param {string} alertId - The ID of the Alert
 * @param {Object} [actor] - The actor triggering this action
 * @param {string} [title] - Custom case title (optional)
 * @param {string} [description] - Custom case description (optional)
 * @returns {Promise<Object>} Created case object
 */
export async function createCaseFromAlert(alertId, actor, title = null, description = null) {
  const alert = await prisma.alert.findUnique({
    where: { id: alertId },
    include: { site: true }
  });

  if (!alert) {
    throw new Error(`IoT Sensor Alert with ID ${alertId} not found`);
  }

  // Guard against duplicate cases for the same alert (check via sourceId in timeline or sourceType)
  const existing = await prisma.case.findFirst({
    where: { sourceType: 'SENSOR', sourceId: alertId, deletedAt: null }
  });
  if (existing) return existing;

  const siteName = alert.site?.name ?? 'Không xác định';
  const caseTitle = title || `Vụ việc cảnh báo cảm biến tại ${siteName}`;
  const caseDescription = description || `Cảnh báo nồng độ bụi PM10 vượt ngưỡng quy chuẩn đo được ${alert.pm10Value} µg/m³ vào lúc ${alert.triggeredAt.toLocaleString('vi-VN')}.`;

  const newCase = await createCase({
    siteId: alert.siteId,
    title: caseTitle,
    description: caseDescription,
    actor,
    sourceType: 'SENSOR',
    sourceId: alertId
  });

  // Link Alert context to the Case timeline
  await prisma.caseTimeline.create({
    data: {
      caseId: newCase.id,
      eventType: 'ALERT_LINKED',
      eventTitle: 'Liên kết cảnh báo cảm biến',
      eventDescription: `Vụ việc được liên kết tự động từ cảnh báo cảm biến (Alert ID: ${alertId}). Trị số PM10: ${alert.pm10Value} µg/m³.`,
      actorId: actor?.id || null,
      actorName: actor?.name || 'System',
      actorRole: actor?.role || 'system'
    }
  });

  // Automatically update alert status to IN_PROGRESS
  await prisma.alert.update({
    where: { id: alertId },
    data: { status: 'IN_PROGRESS' }
  });

  return newCase;
}

/**
 * Checks Legal Shield compliance for a Case (Q1-Q5 & Q20 Anti-Defamation Shield)
 * Verifies if the case contains VERIFIED_EVIDENCE or staff inspector verification before sanctioning.
 * @param {string} caseId - ID of the case
 * @returns {Promise<Object>} Legal shield compliance evaluation result
 */
export async function checkLegalShieldCompliance(caseId) {
  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null },
    include: {
      complaint: {
        include: { evidences: true }
      },
      inspection: true,
      site: true,
      timeline: true
    }
  });

  if (!caseRecord) {
    throw new Error(`Case with ID ${caseId} not found`);
  }

  // 1. Inspector on-site verification check
  const hasOnSiteInspection = caseRecord.inspectionId !== null ||
    caseRecord.timeline?.some(t => ['STATUS_ON_SITE', 'EVIDENCE_PROMOTED', 'EVIDENCE_LABELLED_VERIFIED'].includes(t.eventType)) ||
    ['ON_SITE', 'REPORTING', 'APPRAISING', 'COMPLETED'].includes(normalizeStatus(caseRecord.status));

  // 2. Evidence status count
  const evidences = caseRecord.complaint?.evidences || [];
  const verifiedTimelineEvents = caseRecord.timeline?.filter(t => t.eventType === 'EVIDENCE_PROMOTED' || t.eventType === 'EVIDENCE_LABELLED_VERIFIED') || [];

  let verifiedCount = verifiedTimelineEvents.length;
  let unverifiedCount = 0;

  for (const ev of evidences) {
    if (ev.url && ev.url.includes('VERIFIED_EVIDENCE')) {
      verifiedCount++;
    } else {
      unverifiedCount++;
    }
  }

  const isComplaintSource = caseRecord.complaintId !== null || caseRecord.sourceType === 'COMPLAINT';

  // Compliant if:
  // - Not a raw unverified citizen complaint OR
  // - Has inspector on-site verification OR
  // - Has at least 1 VERIFIED_EVIDENCE item
  const compliant = !isComplaintSource || hasOnSiteInspection || verifiedCount > 0;

  return {
    compliant,
    verifiedEvidenceCount: verifiedCount,
    unverifiedSignalCount: unverifiedCount,
    hasInspectorVerification: hasOnSiteInspection,
    isComplaintSource,
    legalShieldVerdict: compliant
      ? 'Hồ sơ đạt tiêu chuẩn pháp lý (VERIFIED_EVIDENCE / Inspector Verified)'
      : 'Hồ sơ đang ở trạng thái Tín hiệu chưa xác minh (UNVERIFIED_SIGNAL - Cần thanh tra hiện trường trước khi ra Quyết định xử phạt)',
    antiDefamationNotice: compliant
      ? 'Đủ căn cứ pháp lý để thực hiện các bước lập báo cáo xử phạt.'
      : 'Kích hoạt Khiên Pháp Lý (Anti-Defamation Shield): Chặn tự động ra quyết định xử phạt nhằm bảo vệ uy tín nhà thầu trước phản ánh chưa kiểm chứng.'
  };
}

/**
 * Transitions Case status while validating rules, enforcing Legal Shield guards, and logging to CaseTimeline & AuditLog.
 * @param {string} caseId - ID of the case
 * @param {string} nextStatus - The target status (e.g. PREPARING, ON_SITE, REPORTING, APPRAISING, COMPLETED)
 * @param {Object} actor - Actor triggering the change { id, name, role }
 * @param {Object} [details] - Additional notes or data { note: string, ... }
 * @returns {Promise<Object>} Updated case object
 */
export async function transitionCaseStatus(caseId, nextStatus, actor, details = {}) {
  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null }
  });

  if (!caseRecord) {
    throw new Error(`Case with ID ${caseId} not found`);
  }

  const normalizedCurrent = normalizeStatus(caseRecord.status);
  const normalizedNext = normalizeStatus(nextStatus);

  // Self-transition: no-op, avoid unnecessary DB writes and audit noise
  if (normalizedCurrent === normalizedNext) return caseRecord;

  // Enforce Domain State Machine Validation
  validateCaseTransition(caseRecord.status, nextStatus, {
    role: actor?.role,
    reason: details?.note,
    context: details
  });

  // Legal Shield & Anti-Defamation Guard (Q1-Q5, Q20):
  // Before advancing to REPORTING or APPRAISING (formal sanctioning steps),
  // enforce that the case has passed inspector verification or contains VERIFIED_EVIDENCE.
  if (['REPORTING', 'APPRAISING'].includes(normalizedNext)) {
    const shieldCompliance = await checkLegalShieldCompliance(caseRecord.id);
    if (!shieldCompliance.compliant) {
      throw new Error(`[Legal Shield Guard] Cannot advance case ${caseRecord.code} to ${normalizedNext} based solely on UNVERIFIED_SIGNAL. Inspector verification or VERIFIED_EVIDENCE is required to protect against false accusations and defamation (Q1-Q5, Q20).`);
    }
  }

  // Update Case Status
  const updatedCase = await prisma.case.update({
    where: { id: caseId },
    data: {
      status: normalizedNext,
      updatedAt: new Date()
    }
  });

  // Append context regarding SLA deadlines for the new states
  const now = new Date();
  let slaInfo = '';
  if (normalizedNext === 'SCREENING') {
    const deadline = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000);
    slaInfo = ` Hạn sàng lọc và xác minh (SLA): 2 ngày (đến ngày ${deadline.toLocaleDateString('vi-VN')}).`;
  } else if (normalizedNext === 'PREPARING' || normalizedNext === 'DECISION_ISSUED') {
    const deadline = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
    slaInfo = ` Hạn chuẩn bị và ban hành quyết định (SLA): 3 ngày (đến ngày ${deadline.toLocaleDateString('vi-VN')}).`;
  } else if (normalizedNext === 'ON_SITE') {
    const deadline = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
    slaInfo = ` Hạn giải trình và lập biên bản hiện trường (SLA): 5 ngày (đến ngày ${deadline.toLocaleDateString('vi-VN')}).`;
  } else if (normalizedNext === 'REPORTING') {
    const deadline = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
    slaInfo = ` Hạn báo cáo kết quả (SLA): 5 ngày (đến ngày ${deadline.toLocaleDateString('vi-VN')}).`;
  } else if (normalizedNext === 'APPRAISING') {
    const deadline = new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000);
    slaInfo = ` Hạn nộp phạt và khắc phục (SLA): 10 ngày (đến ngày ${deadline.toLocaleDateString('vi-VN')}).`;
  }

  // Record transition event to CaseTimeline
  await prisma.caseTimeline.create({
    data: {
      caseId,
      eventType: `STATUS_${normalizedNext}`,
      eventTitle: `Chuyển trạng thái sang ${normalizedNext}`,
      eventDescription: `Vụ việc thay đổi trạng thái từ ${caseRecord.status} sang ${normalizedNext}.${slaInfo} ${details.note || ''}`.trim(),
      actorId: actor?.id || null,
      actorName: actor?.name || 'System',
      actorRole: actor?.role || 'system'
    }
  });

  // Track status change in CaseStatusHistory
  if (prisma.caseStatusHistory) {
    try {
      await prisma.caseStatusHistory.create({
        data: {
          caseId,
          fromStatus: caseRecord.status,
          toStatus: normalizedNext,
          changedBy: actor?.id || null,
          actorName: actor?.name || 'System',
          actorRole: actor?.role || 'staff',
          note: details.note || `Chuyển trạng thái sang ${normalizedNext}`
        }
      });
    } catch (cshErr) {
      console.warn('[CaseStatusHistory] Failed to log status transition:', cshErr.message);
    }
  }

  // Write audit log
  await logAuditEvent({
    actorId: actor?.id,
    actorName: actor?.name,
    actorRole: actor?.role,
    action: `CASE_STATUS_${normalizedNext}`,
    targetId: caseId,
    details: {
      previousStatus: caseRecord.status,
      newStatus: normalizedNext,
      note: details.note
    }
  });

  // Automatically trigger contractor notification on major status transitions
  if (['ON_SITE', 'REPORTING', 'APPRAISING'].includes(normalizedNext)) {
    await sendContractorNotification(caseId, `CASE_STATUS_${normalizedNext}`);
  }

  // Synchronize linked complaint status when case is completed
  if (normalizedNext === 'COMPLETED' && caseRecord.complaintId) {
    try {
      await prisma.complaint.update({
        where: { id: caseRecord.complaintId },
        data: { status: 'RESOLVED' }
      });
    } catch (compErr) {
      console.warn('[ComplaintSync] Failed to update complaint status to RESOLVED:', compErr.message);
    }
  }

  // Automatically create DraftDocument based on the new status
  try {
    await autoCreateDraftDocumentForCase(updatedCase.id, normalizedNext, actor);
  } catch (draftErr) {
    console.warn(`[AutoDraft] Failed to automatically create draft document for Case ${caseId}:`, draftErr.message);
  }

  return updatedCase;
}

/**
 * Automatically creates a DraftDocument for a Case if not already existing, based on 7-step process.
 * @param {string} caseId - ID of the case
 * @param {string} status - The new status of the case
 * @param {Object} actor - The actor executing the change
 */
async function autoCreateDraftDocumentForCase(caseId, status, actor) {
  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null },
    include: { site: true }
  });

  if (!caseRecord || !caseRecord.site) return;

  const site = caseRecord.site;
  const actorName = actor?.name || 'Cán bộ';
  const docDate = new Date().toLocaleDateString('vi-VN');

  let docType = null;
  let title = '';
  let content = '';

  if (status === 'DECISION_ISSUED') {
    docType = 'quyet-dinh-kiem-tra';
    title = `Quyết định kiểm tra - ${site.name}`;
    content = `# QUYẾT ĐỊNH KIỂM TRA
## Về việc kiểm tra việc chấp hành pháp luật về bảo vệ môi trường

Căn cứ Luật Bảo vệ môi trường ngày 17 tháng 11 năm 2020;
Căn cứ Nghị định 08/2022/NĐ-CP ngày 10 tháng 01 năm 2022 của Chính phủ quy định chi tiết một số điều của Luật Bảo vệ môi trường;
Theo đề nghị của Trưởng phòng Thanh tra Môi trường.

**QUYẾT ĐỊNH:**

**Điều 1. Kiểm tra việc chấp hành pháp luật về bảo vệ môi trường tại:**
- Công trình: ${site.name}
- Địa chỉ: ${site.address}
- Thời hạn kiểm tra: 03 ngày làm việc kể từ ngày công bố quyết định.

**Điều 2. Thành lập Đoàn kiểm tra gồm các ông (bà) có tên sau:**
1. Ông/Bà ${actorName} - Chức vụ: Trưởng đoàn.
2. Ông/Bà Nguyễn Văn B - Chức vụ: Thành viên.

**Điều 3. Quyết định này có hiệu lực kể từ ngày ký.**`;
  } else if (status === 'ON_SITE') {
    docType = 'bien-ban-vphc';
    title = `Biên bản vi phạm hành chính - ${site.name}`;
    content = `# BIÊN BẢN VI PHẠM HÀNH CHÍNH
## Về lĩnh vực bảo vệ môi trường tại công trình xây dựng

Hôm nay, ngày ${docDate}, tại công trình: ${site.name} (${site.address}).
Chúng tôi gồm:
1. Ông/Bà ${actorName} - Chức vụ: Trưởng đoàn kiểm tra.

Tiến hành lập biên bản vi phạm hành chính đối với:
- Đơn vị thi công/chủ đầu tư: ${site.investorName || site.contractorName || 'Đơn vị thi công/chủ đầu tư công trình'}

**I. HÀNH VI VI PHẠM ĐƯỢC GHI NHẬN:**
Không đảm bảo quy định về kiểm soát bụi và khí thải tại công trường xây dựng theo quy định.
- Hiện trạng: Phát tán bụi ra khu vực dân cư xung quanh do thiếu lưới che chắn và hệ thống phun nước dập bụi.

**II. CĂN CỨ PHÁP LÝ:**
- Vi phạm Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP.

**III. Ý KIẾN CỦA ĐẠI DIỆN CƠ SỞ:**
Đại diện cơ sở thừa nhận hành vi thiếu sót và cam kết khắc phục ngay.`;
  } else if (status === 'REPORTING' || status === 'APPRAISING') {
    docType = 'quyet-dinh-xu-phat';
    title = `Quyết định xử phạt vi phạm hành chính - ${site.name}`;
    content = `# QUYẾT ĐỊNH XỬ PHẠT VI PHẠM HÀNH CHÍNH
## Về lĩnh vực bảo vệ môi trường

Căn cứ Luật Xử lý vi phạm hành chính ngày 20 tháng 6 năm 2012;
Căn cứ Nghị định 45/2022/NĐ-CP ngày 07 tháng 7 năm 2022 của Chính phủ quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường.

**QUYẾT ĐỊNH:**

**Điều 1. Xử phạt vi phạm hành chính đối với:**
- Đơn vị/Cá nhân: ${site.investorName || site.contractorName || 'Đơn vị thi công/chủ đầu tư công trình'}
- Đại diện công trình: ${site.name}

**Điều 2. Hình thức xử phạt và biện pháp khắc phục:**
1. Hình thức xử phạt chính: Phạt tiền. Số tiền phạt đề xuất: 15,000,000 VNĐ.
2. Biện pháp khắc phục hậu quả: Buộc thực hiện các biện pháp dập bụi và che chắn công trình theo đúng quy chuẩn kỹ thuật.

**Điều 3. Quyết định này có hiệu lực kể từ ngày ký.**`;
  }

  if (!docType) return;

  // Check if draft already exists for this case & docType
  const existingDoc = await prisma.draftDocument.findFirst({
    where: {
      caseId,
      documentType: docType
    }
  });

  if (existingDoc) {
    console.log(`[AutoDraft] Draft document of type ${docType} already exists for Case ${caseId}. Skipping creation.`);
    return;
  }

  // Create new DraftDocument
  const newDraft = await prisma.draftDocument.create({
    data: {
      siteId: site.id,
      caseId: caseId,
      documentType: docType,
      title: title,
      content: content,
      status: 'DRAFT',
      metadata: JSON.stringify({
        organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
        officer: { name: actorName, title: actor?.role === 'staff' ? 'Thanh tra viên môi trường' : 'Cán bộ xử lý' },
        location: 'Hà Nội',
        recipient: site.investorName || site.contractorName || 'Đơn vị thi công/chủ đầu tư công trình',
        date: docDate
      })
    }
  });

  // Log case timeline event
  await prisma.caseTimeline.create({
    data: {
      caseId: caseId,
      eventType: 'DOCUMENT_DRAFTED',
      eventTitle: `Tự động tạo dự thảo ${newDraft.documentType === 'quyet-dinh-kiem-tra' ? 'Quyết định kiểm tra' : newDraft.documentType === 'bien-ban-vphc' ? 'Biên bản vi phạm' : 'Quyết định xử phạt'}`,
      eventDescription: `Hệ thống tự động tạo bản nháp văn bản "${newDraft.title}" ở trạng thái DRAFT khi vụ việc chuyển sang bước ${status}.`,
      actorId: actor?.id || null,
      actorName: actorName,
      actorRole: actor?.role || 'system'
    }
  });

  console.log(`[AutoDraft] Created automatic draft document (ID: ${newDraft.id}) for Case ${caseId} under status ${status}`);
}

/**
 * Calculates dynamic SLA deadlines based on Case creation and status transition timestamps.
 * @param {string|Object} caseIdOrObj - Case database ID or loaded case object
 * @returns {Promise<Object>} Calculated deadlines { verificationDeadline, explanationDeadline, rectificationDeadline, fineDeadline }
 */
export async function calculateDeadlines(caseIdOrObj) {
  let caseObj;
  if (typeof caseIdOrObj === 'string') {
    caseObj = await prisma.case.findFirst({
      where: { id: caseIdOrObj, deletedAt: null },
      include: { timeline: true }
    });
  } else {
    caseObj = caseIdOrObj;
  }

  if (!caseObj) {
    throw new Error('Case object not found');
  }

  const createdAt = caseObj.createdAt instanceof Date ? caseObj.createdAt : new Date(caseObj.createdAt);

  // Helper to find transition event time
  const getEventTime = async (eventType) => {
    let event = caseObj.timeline?.find(e => e.eventType === eventType);
    if (!event && (typeof caseIdOrObj === 'string' || !caseObj.timeline)) {
      event = await prisma.caseTimeline.findFirst({
        where: { caseId: caseObj.id, eventType },
        orderBy: { createdAt: 'desc' }
      });
    }
    return event ? new Date(event.createdAt) : null;
  };

  // 1. SCREENING: 2 days from creation
  const screeningDeadline = new Date(createdAt.getTime() + 2 * 24 * 60 * 60 * 1000);

  // 2. PREPARING: 3 days from transition to PREPARING status
  let preparingDeadline = null;
  const preparingTime = await getEventTime('STATUS_PREPARING');
  if (preparingTime) {
    preparingDeadline = new Date(preparingTime.getTime() + 3 * 24 * 60 * 60 * 1000);
  }

  // 3. DECISION_ISSUED: 3 days from transition to DECISION_ISSUED status
  let decisionIssuedDeadline = null;
  const decisionIssuedTime = await getEventTime('STATUS_DECISION_ISSUED');
  if (decisionIssuedTime) {
    decisionIssuedDeadline = new Date(decisionIssuedTime.getTime() + 3 * 24 * 60 * 60 * 1000);
  }

  // 4. ON_SITE: 5 days from transition to ON_SITE status
  let onSiteDeadline = null;
  const onSiteTime = await getEventTime('STATUS_ON_SITE');
  if (onSiteTime) {
    onSiteDeadline = new Date(onSiteTime.getTime() + 5 * 24 * 60 * 60 * 1000);
  }

  // 5. REPORTING: 5 days from transition to REPORTING status
  let reportingDeadline = null;
  const reportingTime = await getEventTime('STATUS_REPORTING');
  if (reportingTime) {
    reportingDeadline = new Date(reportingTime.getTime() + 5 * 24 * 60 * 60 * 1000);
  }

  // 6. APPRAISING: 10 days from transition to APPRAISING status
  let appraisingDeadline = null;
  const appraisingTime = await getEventTime('STATUS_APPRAISING');
  if (appraisingTime) {
    appraisingDeadline = new Date(appraisingTime.getTime() + 10 * 24 * 60 * 60 * 1000);
  }

  return {
    screeningDeadline,
    preparingDeadline,
    decisionIssuedDeadline,
    onSiteDeadline,
    reportingDeadline,
    appraisingDeadline,
    
    // Backward compatibility with legacy deadlines
    verificationDeadline: screeningDeadline,
    explanationDeadline: onSiteDeadline,
    rectificationDeadline: reportingDeadline,
    fineDeadline: appraisingDeadline
  };
}

/**
 * Checks if a case has violated any SLA deadlines based on its current status and time.
 * @param {string|Object} caseIdOrObj - Case database ID or loaded case object
 * @returns {Promise<Object>} SLA check results { isViolated, violations: string[], deadlines }
 */
export async function checkSlaViolations(caseIdOrObj) {
  let caseObj;
  if (typeof caseIdOrObj === 'string') {
    caseObj = await prisma.case.findFirst({
      where: { id: caseIdOrObj, deletedAt: null },
      include: { timeline: true }
    });
  } else {
    caseObj = caseIdOrObj;
  }

  if (!caseObj) {
    throw new Error('Case object not found');
  }

  const deadlines = await calculateDeadlines(caseObj);
  const now = new Date();
  const violations = [];
  const status = normalizeStatus(caseObj.status);

  // 1. SCREENING SLA: 2 days (formerly PENDING / PROCESSING verification)
  if (status === 'SCREENING' && now > deadlines.screeningDeadline) {
    violations.push('SCREENING_OVERDUE');
    violations.push('VERIFICATION_OVERDUE');
  }

  // 2. PREPARING SLA: 3 days
  if (status === 'PREPARING' && deadlines.preparingDeadline && now > deadlines.preparingDeadline) {
    violations.push('PREPARING_OVERDUE');
  }

  // 3. DECISION_ISSUED SLA: 3 days
  if (status === 'DECISION_ISSUED' && deadlines.decisionIssuedDeadline && now > deadlines.decisionIssuedDeadline) {
    violations.push('DECISION_ISSUED_OVERDUE');
  }

  // 4. ON_SITE SLA: 5 days (formerly VIOLATED / EXPLAINING explanation)
  if (status === 'ON_SITE' && deadlines.onSiteDeadline && now > deadlines.onSiteDeadline) {
    violations.push('ON_SITE_OVERDUE');
    violations.push('EXPLANATION_OVERDUE');
  }

  // 5. REPORTING SLA: 5 days (formerly SANCTIONED rectification)
  if (status === 'REPORTING' && deadlines.reportingDeadline && now > deadlines.reportingDeadline) {
    violations.push('REPORTING_OVERDUE');
    violations.push('RECTIFICATION_OVERDUE');
  }

  // 6. APPRAISING SLA: 5 days (formerly SANCTIONED / RECTIFYING fine)
  if (status === 'APPRAISING' && deadlines.appraisingDeadline && now > deadlines.appraisingDeadline) {
    violations.push('APPRAISING_OVERDUE');
    violations.push('FINE_OVERDUE');
  }

  return {
    isViolated: violations.length > 0,
    violations: Array.from(new Set(violations)), // Deduplicate
    deadlines
  };
}

/**
 * Verifies and labels an evidence file for a case using Legal Shield Engine
 * @param {string} caseId - Case ID
 * @param {string|Object} evidenceInput - Evidence URL, Base64, or Buffer
 * @param {Object} options - { metadata, isInspectorVerified, actor }
 * @returns {Promise<Object>} Verification report
 */
export async function verifyCaseEvidenceIntegrity(caseId, evidenceInput, options = {}) {
  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null },
    include: { site: true }
  });

  if (!caseRecord) {
    throw new Error(`Case with ID ${caseId} not found`);
  }

  const siteLocation = caseRecord.site ? {
    latitude: caseRecord.site.latitude,
    longitude: caseRecord.site.longitude
  } : null;

  const result = await verifyImageIntegrity(evidenceInput, {
    siteLocation,
    submittedAt: caseRecord.createdAt,
    isInspectorVerified: options.isInspectorVerified || options.actor?.role === 'staff' || options.actor?.role === 'admin',
    metadata: options.metadata
  });

  // Log evidence integrity status to CaseTimeline
  await prisma.caseTimeline.create({
    data: {
      caseId,
      eventType: result.statusLabel === INTEGRITY_LABELS.VERIFIED_EVIDENCE ? 'EVIDENCE_LABELLED_VERIFIED' : 'EVIDENCE_LABELLED_SIGNAL',
      eventTitle: `Gán nhãn bằng chứng: ${result.statusLabel}`,
      eventDescription: `Mã băm SHA-256: ${result.sha256.substring(0, 16)}... Điểm toàn vẹn: ${result.integrityScore}/100. ${result.legalShield.legalClassification}`,
      actorId: options.actor?.id || null,
      actorName: options.actor?.name || 'Legal Shield Engine',
      actorRole: options.actor?.role || 'system'
    }
  });

  // Log audit event
  await logAuditEvent({
    actorId: options.actor?.id,
    actorName: options.actor?.name,
    actorRole: options.actor?.role,
    action: 'LEGAL_SHIELD_EVIDENCE_VERIFY',
    targetId: caseId,
    details: {
      sha256: result.sha256,
      statusLabel: result.statusLabel,
      integrityScore: result.integrityScore,
      isAntiDefamationProtected: result.legalShield.isAntiDefamationProtected
    }
  });

  return result;
}

/**
 * Promotes an UNVERIFIED_SIGNAL to VERIFIED_EVIDENCE after staff inspection
 * @param {string} caseId - Case ID
 * @param {string} evidenceId - Evidence or Complaint ID
 * @param {Object} actor - Inspector/Staff actor { id, name, role }
 * @param {string} [verificationNotes] - Notes from inspector
 * @returns {Promise<Object>} Promotion result
 */
export async function promoteSignalToVerifiedEvidence(caseId, evidenceId, actor, verificationNotes = '') {
  if (!actor || (actor.role !== 'staff' && actor.role !== 'admin' && actor.role !== 'executive')) {
    throw new Error('Chỉ cán bộ thanh tra hoặc quản trị viên mới có quyền đối soát và nâng cấp VERIFIED_EVIDENCE');
  }

  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null }
  });

  if (!caseRecord) {
    throw new Error(`Case with ID ${caseId} not found`);
  }

  // Create timeline record for promotion
  await prisma.caseTimeline.create({
    data: {
      caseId,
      eventType: 'EVIDENCE_PROMOTED',
      eventTitle: 'Nâng cấp trạng thái VERIFIED_EVIDENCE',
      eventDescription: `Cán bộ ${actor.name} (${actor.role}) đã đối soát thực địa và chuyển tín hiệu sang VERIFIED_EVIDENCE. Ghi chú: ${verificationNotes || 'Đã xác minh hiện trường'}.`,
      actorId: actor.id,
      actorName: actor.name,
      actorRole: actor.role
    }
  });

  await logAuditEvent({
    actorId: actor.id,
    actorName: actor.name,
    actorRole: actor.role,
    action: 'LEGAL_SHIELD_SIGNAL_PROMOTED',
    targetId: caseId,
    details: {
      evidenceId,
      newStatusLabel: INTEGRITY_LABELS.VERIFIED_EVIDENCE,
      notes: verificationNotes
    }
  });

  return {
    success: true,
    caseId,
    evidenceId,
    statusLabel: INTEGRITY_LABELS.VERIFIED_EVIDENCE,
    promotedBy: actor.name,
    promotedAt: new Date()
  };
}

/**
 * Generates full Legal Shield & Anti-Defamation report for a Case
 * @param {string} caseId 
 * @returns {Promise<Object>} Report object
 */
export async function getCaseLegalShieldReport(caseId) {
  const compliance = await checkLegalShieldCompliance(caseId);
  const caseRecord = await prisma.case.findFirst({
    where: { id: caseId, deletedAt: null },
    include: { site: true, timeline: true }
  });

  if (!caseRecord) {
    throw new Error(`Case with ID ${caseId} not found`);
  }

  return {
    caseId: caseRecord.id,
    caseCode: caseRecord.code,
    siteId: caseRecord.siteId,
    siteName: caseRecord.site?.name || 'Công trình',
    contractorName: caseRecord.site?.contractorName || 'Nhà thầu',
    currentStatus: caseRecord.status,
    legalShieldCompliance: compliance,
    antiDefamationStatus: compliance.compliant ? 'VERIFIED_EVIDENCE' : 'UNVERIFIED_SIGNAL_PROTECTED',
    canIssueSanction: compliance.compliant,
    summaryNotice: compliance.compliant
      ? 'Hồ sơ đã có bằng chứng hoặc xác minh thanh tra. Đủ điều kiện ban hành văn bản xử lý vi phạm.'
      : 'Khiên Pháp Lý (Anti-Defamation Shield) đang bảo vệ nhà thầu: Tín hiệu phản ánh chưa qua xác minh, không được ra quyết định xử phạt tự động.'
  };
}
