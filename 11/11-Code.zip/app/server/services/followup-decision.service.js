/**
 * FollowUp Decision Service (DustGuard VN SSOT)
 * Evaluates follow-up outcomes, evidence sufficiency, and historical re-visitations
 * to deterministically recommend the next observation lifecycle state.
 */

export class FollowUpDecisionService {
  /**
   * Evaluates the outcome and historical context of an observation to determine next state.
   * @param {Object} params
   * @param {string} params.outcome BETTER | UNCHANGED | WORSE | NOT_ACCESSIBLE | INSUFFICIENT_EVIDENCE
   * @param {string} params.currentStatus
   * @param {Array} params.previousFollowUps
   * @param {boolean} params.hasEvidence
   * @param {Object} [params.categoryMeta]
   */
  static evaluate({ outcome, currentStatus = 'RECORDED', previousFollowUps = [], hasEvidence = false, categoryMeta = null }) {
    const sequenceNo = (previousFollowUps?.length || 0) + 1;
    const reasonCodes = [];
    let recommendedStatus = 'FOLLOWING_UP';
    let nextAction = 'CONTINUE_MONITORING';
    let nextFollowUpAt = null;

    const now = Date.now();
    const dueIn24h = new Date(now + 24 * 60 * 60 * 1000).toISOString();
    const dueIn48h = new Date(now + 48 * 60 * 60 * 1000).toISOString();

    switch (outcome) {
      case 'BETTER':
        if (hasEvidence) {
          recommendedStatus = 'RESOLVED';
          nextAction = 'CLOSE_CASE_RESOLVED';
          reasonCodes.push('VERIFIED_IMPROVEMENT_WITH_EVIDENCE');
        } else {
          recommendedStatus = 'NEEDS_FOLLOWUP';
          nextAction = 'REQUIRE_PHOTO_EVIDENCE_REVERIFY';
          nextFollowUpAt = dueIn24h;
          reasonCodes.push('REPORTED_BETTER_BUT_INSUFFICIENT_EVIDENCE');
        }
        break;

      case 'WORSE':
        recommendedStatus = 'READY_FOR_HANDOFF';
        nextAction = 'DISPATCH_IMMEDIATE_HANDOFF';
        reasonCodes.push('ENVIRONMENTAL_CONDITION_DETERIORATED');
        break;

      case 'UNCHANGED':
        // If unchanged on multiple follow-ups, escalate to ready for handoff
        const priorUnchangedCount = previousFollowUps.filter(f => f.outcome_status === 'UNCHANGED' || f.outcome === 'UNCHANGED').length;
        if (priorUnchangedCount >= 1 || sequenceNo >= 2) {
          recommendedStatus = 'READY_FOR_HANDOFF';
          nextAction = 'ESCALATE_TO_RESPONSIBLE_AUTHORITY';
          reasonCodes.push('PERSISTENT_NON_COMPLIANCE_AFTER_MULTIPLE_VISITS');
        } else {
          recommendedStatus = 'NEEDS_FOLLOWUP';
          nextAction = 'SCHEDULE_48H_REVISIT';
          nextFollowUpAt = dueIn48h;
          reasonCodes.push('FIRST_REVISIT_UNCHANGED_PENDING_FURTHER_OBSERVATION');
        }
        break;

      case 'NOT_ACCESSIBLE':
        recommendedStatus = 'NEEDS_FOLLOWUP';
        nextAction = 'RETRY_ACCESS_NEXT_DAY';
        nextFollowUpAt = dueIn24h;
        reasonCodes.push('SITE_TEMPORARILY_INACCESSIBLE');
        break;

      case 'INSUFFICIENT_EVIDENCE':
      default:
        recommendedStatus = 'NEEDS_FOLLOWUP';
        nextAction = 'SUPPLEMENT_EVIDENCE_AND_RETRY';
        nextFollowUpAt = dueIn24h;
        reasonCodes.push('INSUFFICIENT_EVIDENCE_TO_CONCLUDE');
        break;
    }

    return {
      sequenceNo,
      previousStatus: currentStatus,
      outcome,
      recommendedStatus,
      reasonCodes,
      nextAction,
      nextFollowUpAt
    };
  }

  /**
   * Calculates deadline schedule (24h & 48h) for observation revisits.
   */
  static calculateSchedule(submittedAtIso) {
    const baseTime = submittedAtIso ? new Date(submittedAtIso).getTime() : Date.now();
    return {
      firstFollowUpDueAt: new Date(baseTime + 24 * 60 * 60 * 1000).toISOString(),
      secondFollowUpDueAt: new Date(baseTime + 48 * 60 * 60 * 1000).toISOString()
    };
  }
}
