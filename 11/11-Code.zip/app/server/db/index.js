// app/server/db/index.js
// Central D1 Database Engine SSOT for DustGuard VN

export { getD1OrSqlite, getDbClient, prisma } from '../shared/db.js';
export {
  ensureSchema,
  resetSchemaCheck,
  REQUIRED_TABLE_COLUMNS
} from './schema-healer.js';
export {
  executeBatch,
  buildInsertStatements,
  buildUpsertStatements,
  executeBatchInsert,
  executeBatchUpsert,
  runTransaction
} from './batching.js';
export {
  ensureSystemAuditTable,
  logSystemAudit,
  batchLogAudit,
  queryAuditLogs
} from './audit.js';
export {
  VIETNAM_OFFSET_HOURS,
  VIETNAM_OFFSET_MS,
  getVietnamDate,
  getVietnamDateString,
  getVietnamTimeString,
  getVietnamDateTimeString,
  getVietnamISOString,
  getVietnamMonthString,
  getVNNowStr,
  getVNTodayStr
} from './timezone.js';
export {
  EXPECTED_APP_ID,
  verifyDatabaseIdentity,
  safeJsonParse,
  safeJsonStringify,
  sanitizeParam
} from './guard.js';
