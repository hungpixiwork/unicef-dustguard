// app/server/db/guard.js
// Database Identity Guard & Safe Data Helpers for Cloudflare D1 / SQLite

export const EXPECTED_APP_ID = 'DUSTGUARD_VN';

/**
 * An toàn phân tích chuỗi JSON, không ném ngoại lệ nếu chuỗi không hợp lệ
 * @param {string|any} str 
 * @param {any} fallback 
 * @returns {any}
 */
export function safeJsonParse(str, fallback = {}) {
  if (str === null || str === undefined) return fallback;
  if (typeof str === 'object') return str;
  try {
    return JSON.parse(str);
  } catch {
    return fallback;
  }
}

/**
 * An toàn chuyển đối tượng thành chuỗi JSON
 * @param {any} obj 
 * @param {string} fallback 
 * @returns {string}
 */
export function safeJsonStringify(obj, fallback = '{}') {
  if (obj === null || obj === undefined) return fallback;
  if (typeof obj === 'string') return obj;
  try {
    return JSON.stringify(obj);
  } catch {
    return fallback;
  }
}

/**
 * Làm sạch và chuyển đổi kiểu an toàn cho tham số truy vấn SQLite
 * @param {any} val 
 * @returns {string|number|null}
 */
export function sanitizeParam(val) {
  if (val === undefined || val === null) return null;
  if (typeof val === 'boolean') return val ? 1 : 0;
  if (typeof val === 'number') return Number.isFinite(val) ? val : null;
  if (val instanceof Date) return val.toISOString();
  if (typeof val === 'object') return safeJsonStringify(val);
  return String(val);
}

/**
 * Kiểm tra Identity Guard APP_ID trên bảng system_metadata của D1 Database
 * @param {Object} db - D1 Database Binding
 * @param {string} [expectedAppId=EXPECTED_APP_ID]
 * @returns {Promise<{valid: boolean, appIdInDb?: string, error?: string, message?: string}>}
 */
export async function verifyDatabaseIdentity(db, expectedAppId = EXPECTED_APP_ID) {
  try {
    if (!db || typeof db.prepare !== 'function') {
      return {
        valid: false,
        error: 'MISSING_DATABASE_BINDING',
        message: 'Chưa cấu hình D1 Database Binding hợp lệ cho DustGuard VN.'
      };
    }

    // Tự động đảm bảo bảng system_metadata tồn tại
    await db.prepare(`
      CREATE TABLE IF NOT EXISTS system_metadata (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run().catch(() => {});

    const res = await db.prepare("SELECT value FROM system_metadata WHERE key = 'APP_ID'").first().catch(() => null);
    let appIdInDb = res?.value;

    if (!appIdInDb) {
      // Tự động ghi nhận nếu chưa có
      await db.prepare("INSERT OR REPLACE INTO system_metadata (key, value) VALUES ('APP_ID', ?)").bind(expectedAppId).run().catch(() => {});
      appIdInDb = expectedAppId;
    }

    if (appIdInDb !== expectedAppId) {
      console.error(`[DATABASE_IDENTITY_MISMATCH] Expected APP_ID '${expectedAppId}', but D1 returned '${appIdInDb}'.`);
      return {
        valid: false,
        appIdInDb,
        error: 'DATABASE_CONFIGURATION_ERROR',
        message: `Ứng dụng đang kết nối sai cơ sở dữ liệu (Yêu cầu: '${expectedAppId}', tìm thấy: '${appIdInDb}').`
      };
    }

    return {
      valid: true,
      appIdInDb
    };
  } catch (err) {
    console.error('[DATABASE_IDENTITY_CHECK_FAILED]', err);
    return {
      valid: false,
      error: 'DATABASE_CONFIGURATION_ERROR',
      message: 'Không thể xác thực danh tính cơ sở dữ liệu D1.'
    };
  }
}
