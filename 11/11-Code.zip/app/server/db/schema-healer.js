// app/server/db/schema-healer.js
// Cloudflare D1 Auto-Healing Schema & Column Migration Engine (SSOT Zero-Crash Architecture)
// Pattern reference: lms-saosang ensureSchema(db) with single-flight promise caching

import { verifyDatabaseIdentity, EXPECTED_APP_ID } from './guard.js';

let globalSchemaChecked = false;
let globalSchemaPromise = null;

/**
 * Reset schema cache state (dùng cho testing hoặc ép buộc re-check)
 */
export function resetSchemaCheck() {
  globalSchemaChecked = false;
  globalSchemaPromise = null;
}

/**
 * Định nghĩa cấu trúc bảng chuẩn và danh sách các cột bắt buộc cho từng bảng (Schema SSOT)
 */
export const REQUIRED_TABLE_COLUMNS = {
  users: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'clerk_user_id', type: 'TEXT' },
    { name: 'full_name', type: 'TEXT' },
    { name: 'email', type: 'TEXT' },
    { name: 'email_verified', type: 'INTEGER DEFAULT 0' },
    { name: 'image', type: 'TEXT' },
    { name: 'role', type: "TEXT DEFAULT 'citizen'" },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  profiles: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'userId', type: 'TEXT' },
    { name: 'fullName', type: 'TEXT' },
    { name: 'phoneNumber', type: 'TEXT' },
    { name: 'avatarUrl', type: 'TEXT' },
    { name: 'department', type: 'TEXT' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  sites: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'name', type: 'TEXT' },
    { name: 'address', type: 'TEXT' },
    { name: 'ward', type: 'TEXT' },
    { name: 'province', type: "TEXT DEFAULT 'Đà Nẵng'" },
    { name: 'coordinates', type: 'TEXT' },
    { name: 'dustRiskScore', type: 'INTEGER DEFAULT 0' },
    { name: 'riskLevel', type: "TEXT DEFAULT 'LOW'" },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'investorName', type: 'TEXT' },
    { name: 'contractorName', type: 'TEXT' },
    { name: 'licenseNumber', type: 'TEXT' },
    { name: 'managerName', type: 'TEXT' },
    { name: 'managerPhone', type: 'TEXT' },
    { name: 'managerEmail', type: 'TEXT' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  complaints: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'ward', type: 'TEXT' },
    { name: 'address', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'reporterName', type: 'TEXT' },
    { name: 'reporterPhone', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'PENDING'" },
    { name: 'priority', type: "TEXT DEFAULT 'MEDIUM'" },
    { name: 'dueAt', type: 'DATETIME' },
    { name: 'triageNote', type: 'TEXT' },
    { name: 'assignedTo', type: 'TEXT' },
    { name: 'contactedAt', type: 'DATETIME' },
    { name: 'closedAt', type: 'DATETIME' },
    { name: 'mergedInto', type: 'TEXT' },
    { name: 'feedbackNote', type: 'TEXT' },
    { name: 'photoCount', type: 'INTEGER DEFAULT 0' },
    { name: 'latitude', type: 'REAL' },
    { name: 'longitude', type: 'REAL' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  inspections: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'inspectorId', type: 'TEXT' },
    { name: 'findings', type: 'TEXT' },
    { name: 'actionTaken', type: 'TEXT' },
    { name: 'scoreDelta', type: 'INTEGER DEFAULT 0' },
    { name: 'sourceComplaintId', type: 'TEXT' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  cases: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'title', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'OPEN'" },
    { name: 'sourceType', type: 'TEXT' },
    { name: 'sourceId', type: 'TEXT' },
    { name: 'slaDeadline', type: 'DATETIME' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'complaintId', type: 'TEXT' },
    { name: 'inspectionId', type: 'TEXT' },
    { name: 'priority', type: "TEXT DEFAULT 'MEDIUM'" },
    { name: 'createdBy', type: 'TEXT' },
    { name: 'assignedTo', type: 'TEXT' },
    { name: 'currentStep', type: "TEXT DEFAULT 'INSPECTION'" },
    { name: 'category', type: "TEXT DEFAULT 'CONSTRUCTION_DUST'" },
    { name: 'severity', type: "TEXT DEFAULT 'HIGH'" },
    { name: 'attention_state', type: "TEXT DEFAULT 'NORMAL'" },
    { name: 'is_clock_paused', type: 'BOOLEAN DEFAULT 0' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  evidences: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'url', type: 'TEXT' },
    { name: 'fileUrl', type: 'TEXT' },
    { name: 'type', type: "TEXT DEFAULT 'IMAGE'" },
    { name: 'photoType', type: "TEXT DEFAULT 'BEFORE'" },
    { name: 'filename', type: 'TEXT' },
    { name: 'mime_type', type: 'TEXT' },
    { name: 'file_size', type: 'INTEGER' },
    { name: 'sha256', type: 'TEXT' },
    { name: 'hashSha256', type: 'TEXT' },
    { name: 'uploaded_by', type: 'TEXT' },
    { name: 'complaintId', type: 'TEXT' },
    { name: 'inspectionId', type: 'TEXT' },
    { name: 'caseId', type: 'TEXT' },
    { name: 'taskId', type: 'TEXT' },
    { name: 'actionId', type: 'TEXT' },
    { name: 'isTampered', type: 'BOOLEAN DEFAULT 0' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  actions: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'title', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'PENDING'" },
    { name: 'siteId', type: 'TEXT' },
    { name: 'inspectionId', type: 'TEXT' },
    { name: 'assignee', type: 'TEXT' },
    { name: 'dueDate', type: 'DATETIME' },
    { name: 'evidenceUrl', type: 'TEXT' },
    { name: 'caseId', type: 'TEXT' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  draft_documents: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'inspectionId', type: 'TEXT' },
    { name: 'documentType', type: "TEXT DEFAULT 'corrective_notice'" },
    { name: 'title', type: 'TEXT' },
    { name: 'content', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'DRAFT'" },
    { name: 'metadata', type: 'TEXT' },
    { name: 'signedUrl', type: 'TEXT' },
    { name: 'submittedById', type: 'TEXT' },
    { name: 'approvedById', type: 'TEXT' },
    { name: 'signedAt', type: 'DATETIME' },
    { name: 'hash', type: 'TEXT' },
    { name: 'caseId', type: 'TEXT' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  contractor_explanations: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'caseId', type: 'TEXT' },
    { name: 'contractorId', type: 'TEXT' },
    { name: 'contractorName', type: 'TEXT' },
    { name: 'explanation', type: 'TEXT' },
    { name: 'evidenceUrls', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'PENDING'" },
    { name: 'content', type: 'TEXT' },
    { name: 'submittedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'reviewedBy', type: 'TEXT' },
    { name: 'reviewedAt', type: 'DATETIME' },
    { name: 'reviewNote', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  audit_logs: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'userId', type: 'TEXT' },
    { name: 'actor_id', type: 'TEXT' },
    { name: 'actor_name', type: 'TEXT' },
    { name: 'actor_role', type: 'TEXT' },
    { name: 'action', type: 'TEXT' },
    { name: 'targetId', type: 'TEXT' },
    { name: 'details', type: 'TEXT' },
    { name: 'ipAddress', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  case_status_history: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'case_id', type: 'TEXT' },
    { name: 'from_status', type: 'TEXT' },
    { name: 'to_status', type: 'TEXT' },
    { name: 'changed_by', type: 'TEXT' },
    { name: 'actor_name', type: 'TEXT' },
    { name: 'actor_role', type: 'TEXT' },
    { name: 'note', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  priority_score_history: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'site_id', type: 'TEXT' },
    { name: 'case_id', type: 'TEXT' },
    { name: 'score', type: 'INTEGER' },
    { name: 'score_version', type: "TEXT DEFAULT 'v1.0'" },
    { name: 'components_json', type: "TEXT DEFAULT '{}'" },
    { name: 'reasons_json', type: "TEXT DEFAULT '[]'" },
    { name: 'calculated_by', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  sensors: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'name', type: 'TEXT' },
    { name: 'code', type: 'TEXT' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  sensor_readings: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'sensorId', type: 'TEXT' },
    { name: 'pm10', type: 'REAL DEFAULT 0' },
    { name: 'pm25', type: 'REAL DEFAULT 0' },
    { name: 'timestamp', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  iot_devices: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'device_id', type: 'TEXT UNIQUE' },
    { name: 'name', type: 'TEXT' },
    { name: 'sensor_type', type: "TEXT DEFAULT 'APM2000'" },
    { name: 'device_secret_hash', type: 'TEXT' },
    { name: 'firmware_version', type: "TEXT DEFAULT '1.0.0'" },
    { name: 'status', type: "TEXT DEFAULT 'ONLINE'" },
    { name: 'last_seen_at', type: 'DATETIME' },
    { name: 'site_id', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  iot_readings: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'device_id', type: 'TEXT' },
    { name: 'pm1', type: 'REAL DEFAULT 0' },
    { name: 'pm25', type: 'REAL DEFAULT 0' },
    { name: 'pm10', type: 'REAL DEFAULT 0' },
    { name: 'wifi_rssi', type: 'INTEGER DEFAULT 0' },
    { name: 'uptime', type: 'INTEGER DEFAULT 0' },
    { name: 'captured_at', type: 'DATETIME' },
    { name: 'received_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  alerts: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'title', type: 'TEXT' },
    { name: 'siteId', type: 'TEXT' },
    { name: 'sensorId', type: 'TEXT' },
    { name: 'caseId', type: 'TEXT' },
    { name: 'severity', type: "TEXT DEFAULT 'HIGH'" },
    { name: 'pm10Value', type: 'REAL DEFAULT 0' },
    { name: 'pm25Value', type: 'REAL DEFAULT 0' },
    { name: 'priorityReasons', type: 'TEXT' },
    { name: 'evidenceUrls', type: 'TEXT' },
    { name: 'triggeredAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'slaDeadline', type: 'DATETIME' },
    { name: 'status', type: "TEXT DEFAULT 'PENDING'" },
    { name: 'resolvedAt', type: 'DATETIME' },
    { name: 'deletedAt', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  communities: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'name', type: 'TEXT' },
    { name: 'slug', type: 'TEXT' },
    { name: 'organization_type', type: "TEXT DEFAULT 'UNIVERSITY'" },
    { name: 'school', type: 'TEXT' },
    { name: 'province', type: "TEXT DEFAULT 'Hà Nội'" },
    { name: 'district', type: 'TEXT' },
    { name: 'ward', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'category', type: "TEXT DEFAULT 'COMMUNITY'" },
    { name: 'location', type: 'TEXT' },
    { name: 'leaderId', type: 'TEXT' },
    { name: 'avatarUrl', type: 'TEXT' },
    { name: 'logo_url', type: 'TEXT' },
    { name: 'coverUrl', type: 'TEXT' },
    { name: 'cover_url', type: 'TEXT' },
    { name: 'contact_name', type: 'TEXT' },
    { name: 'contact_email', type: 'TEXT' },
    { name: 'contact_phone', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'visibility', type: "TEXT DEFAULT 'PUBLIC'" },
    { name: 'motto', type: 'TEXT' },
    { name: 'badge_title', type: 'TEXT' },
    { name: 'volunteer_hours', type: 'REAL DEFAULT 0' },
    { name: 'resolved_hotspots', type: 'INTEGER DEFAULT 0' },
    { name: 'memberCount', type: 'INTEGER DEFAULT 0' },
    { name: 'member_count', type: 'INTEGER DEFAULT 0' },
    { name: 'verified', type: 'INTEGER DEFAULT 1' },
    { name: 'created_by', type: 'TEXT' },
    { name: 'deleted_at', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  community_members: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'communityId', type: 'TEXT' },
    { name: 'userId', type: 'TEXT' },
    { name: 'role', type: "TEXT DEFAULT 'MEMBER'" },
    { name: 'joinedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  community_memberships: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'profile_id', type: 'TEXT' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'club_id', type: 'TEXT' },
    { name: 'membership_role', type: "TEXT DEFAULT 'MEMBER'" },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'joined_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'left_at', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  campaigns: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'title', type: 'TEXT' },
    { name: 'slug', type: 'TEXT' },
    { name: 'short_description', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'campaign_type', type: "TEXT DEFAULT 'SCHOOL_ZONE'" },
    { name: 'topic', type: "TEXT DEFAULT 'SCHOOL_ZONE_DUST'" },
    { name: 'communityId', type: 'TEXT' },
    { name: 'location', type: 'TEXT' },
    { name: 'ward', type: 'TEXT' },
    { name: 'district', type: 'TEXT' },
    { name: 'province', type: "TEXT DEFAULT 'Hà Nội'" },
    { name: 'startDate', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'endDate', type: 'DATETIME' },
    { name: 'start_at', type: 'DATETIME' },
    { name: 'end_at', type: 'DATETIME' },
    { name: 'participation_start_at', type: 'DATETIME' },
    { name: 'participation_end_at', type: 'DATETIME' },
    { name: 'targetObservations', type: 'INTEGER DEFAULT 100' },
    { name: 'currentObservations', type: 'INTEGER DEFAULT 0' },
    { name: 'target_observations', type: 'INTEGER DEFAULT 100' },
    { name: 'current_observations', type: 'INTEGER DEFAULT 0' },
    { name: 'status', type: "TEXT DEFAULT 'OPEN'" },
    { name: 'visibility', type: "TEXT DEFAULT 'PUBLIC'" },
    { name: 'coverUrl', type: 'TEXT' },
    { name: 'cover_image', type: 'TEXT' },
    { name: 'organizer', type: 'TEXT' },
    { name: 'max_participants', type: 'INTEGER' },
    { name: 'goals', type: 'TEXT' },
    { name: 'safety_criteria', type: 'TEXT' },
    { name: 'schools_list', type: 'TEXT' },
    { name: 'participant_count', type: 'INTEGER DEFAULT 0' },
    { name: 'observation_count', type: 'INTEGER DEFAULT 0' },
    { name: 'created_by', type: 'TEXT' },
    { name: 'updated_by', type: 'TEXT' },
    { name: 'deleted_at', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  campaign_members: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'campaignId', type: 'TEXT' },
    { name: 'userId', type: 'TEXT' },
    { name: 'joinedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  campaign_participants: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'campaign_id', type: 'TEXT' },
    { name: 'profile_id', type: 'TEXT' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'club_id', type: 'TEXT' },
    { name: 'participation_role', type: "TEXT DEFAULT 'VOLUNTEER'" },
    { name: 'status', type: "TEXT DEFAULT 'APPROVED'" },
    { name: 'full_name', type: 'TEXT' },
    { name: 'email', type: 'TEXT' },
    { name: 'phone', type: 'TEXT' },
    { name: 'organization', type: 'TEXT' },
    { name: 'note', type: 'TEXT' },
    { name: 'commitment_hours', type: 'TEXT' },
    { name: 'joined_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'approved_at', type: 'DATETIME' },
    { name: 'completed_at', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  campaign_clubs: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'campaign_id', type: 'TEXT' },
    { name: 'club_id', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'joined_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  observations: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'title', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'category', type: "TEXT DEFAULT 'CONSTRUCTION_DUST'" },
    { name: 'severity', type: "TEXT DEFAULT 'MEDIUM'" },
    { name: 'status', type: "TEXT DEFAULT 'RECORDED'" },
    { name: 'latitude', type: 'REAL' },
    { name: 'longitude', type: 'REAL' },
    { name: 'address', type: 'TEXT' },
    { name: 'ward', type: 'TEXT' },
    { name: 'province', type: "TEXT DEFAULT 'Đà Nẵng'" },
    { name: 'siteId', type: 'TEXT' },
    { name: 'authorId', type: 'TEXT' },
    { name: 'authorName', type: 'TEXT' },
    { name: 'authorRole', type: "TEXT DEFAULT 'citizen'" },
    { name: 'campaignId', type: 'TEXT' },
    { name: 'verifiedAt', type: 'DATETIME' },
    { name: 'verifiedBy', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  observation_evidence: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'observationId', type: 'TEXT' },
    { name: 'fileUrl', type: 'TEXT' },
    { name: 'fileType', type: "TEXT DEFAULT 'image'" },
    { name: 'sha256Hash', type: 'TEXT' },
    { name: 'caption', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  follow_ups: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'observationId', type: 'TEXT' },
    { name: 'authorId', type: 'TEXT' },
    { name: 'authorName', type: 'TEXT' },
    { name: 'authorRole', type: "TEXT DEFAULT 'citizen'" },
    { name: 'note', type: 'TEXT' },
    { name: 'statusBefore', type: 'TEXT' },
    { name: 'statusAfter', type: 'TEXT' },
    { name: 'outcome_status', type: 'TEXT' },
    { name: 'evidenceUrl', type: 'TEXT' },
    { name: 'verified_at', type: 'DATETIME' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  handoffs: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'observationId', type: 'TEXT' },
    { name: 'targetAgency', type: 'TEXT' },
    { name: 'agencyContact', type: 'TEXT' },
    { name: 'dossierUrl', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'SUBMITTED'" },
    { name: 'officialReference', type: 'TEXT' },
    { name: 'submittedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'acknowledgedAt', type: 'DATETIME' },
    { name: 'resolvedAt', type: 'DATETIME' },
    { name: 'responseNote', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updatedAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  impact_events: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'eventType', type: 'TEXT' },
    { name: 'observationId', type: 'TEXT' },
    { name: 'campaignId', type: 'TEXT' },
    { name: 'userId', type: 'TEXT' },
    { name: 'pointsAwarded', type: 'INTEGER DEFAULT 10' },
    { name: 'details', type: 'TEXT' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  idempotency_keys: [
    { name: 'key', type: 'TEXT PRIMARY KEY' },
    { name: 'request_hash', type: 'TEXT' },
    { name: 'response_json', type: 'TEXT' },
    { name: 'status_code', type: 'INTEGER DEFAULT 200' },
    { name: 'expires_at', type: 'DATETIME' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  audit_events: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'aggregate_type', type: 'TEXT' },
    { name: 'aggregate_id', type: 'TEXT' },
    { name: 'event_type', type: 'TEXT' },
    { name: 'actor_id', type: 'TEXT' },
    { name: 'actor_name', type: 'TEXT' },
    { name: 'actor_role', type: 'TEXT' },
    { name: 'payload_json', type: 'TEXT' },
    { name: 'previous_state', type: 'TEXT' },
    { name: 'new_state', type: 'TEXT' },
    { name: 'request_id', type: 'TEXT' },
    { name: 'integrity_hash', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  environmental_categories: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'name_vi', type: 'TEXT' },
    { name: 'name_en', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'icon', type: 'TEXT' },
    { name: 'default_severity', type: "TEXT DEFAULT 'HIGH'" },
    { name: 'evidence_requirements', type: 'TEXT' },
    { name: 'regulations', type: 'TEXT' },
    { name: 'active', type: 'INTEGER DEFAULT 1' },
    { name: 'version', type: 'INTEGER DEFAULT 1' },
    { name: 'effective_from', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'effective_to', type: 'DATETIME' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  youth_activities: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'activity_type', type: 'TEXT' },
    { name: 'campaign_id', type: 'TEXT' },
    { name: 'observation_id', type: 'TEXT' },
    { name: 'minutes', type: 'INTEGER DEFAULT 30' },
    { name: 'evidence_url', type: 'TEXT' },
    { name: 'validated_by', type: 'TEXT' },
    { name: 'validation_status', type: "TEXT DEFAULT 'VALIDATED'" },
    { name: 'occurred_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  youth_certificates: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'certificate_code', type: 'TEXT' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'student_name', type: 'TEXT' },
    { name: 'university', type: 'TEXT' },
    { name: 'student_id', type: 'TEXT' },
    { name: 'eligible_minutes', type: 'INTEGER DEFAULT 0' },
    { name: 'credit_value', type: 'REAL DEFAULT 0' },
    { name: 'policy_version', type: "TEXT DEFAULT 'v1.0'" },
    { name: 'payload_hash', type: 'TEXT' },
    { name: 'signature', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'ACTIVE'" },
    { name: 'revoked_at', type: 'DATETIME' },
    { name: 'revoked_reason', type: 'TEXT' },
    { name: 'issued_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'issued_by', type: "TEXT DEFAULT 'DustGuard VN System'" }
  ],
  legal_rules: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'jurisdiction', type: "TEXT DEFAULT 'NATIONAL'" },
    { name: 'document_number', type: 'TEXT' },
    { name: 'document_title', type: 'TEXT' },
    { name: 'article', type: 'TEXT' },
    { name: 'clause', type: 'TEXT' },
    { name: 'violation_code', type: 'TEXT' },
    { name: 'checklist_key', type: 'TEXT' },
    { name: 'title', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'subject_type', type: "TEXT DEFAULT 'ORGANIZATION'" },
    { name: 'min_fine', type: 'REAL DEFAULT 0' },
    { name: 'max_fine', type: 'REAL DEFAULT 0' },
    { name: 'effective_from', type: 'TEXT' },
    { name: 'source_url', type: 'TEXT' },
    { name: 'remediation_action', type: 'TEXT' },
    { name: 'citation', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  automation_runs: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'job_name', type: 'TEXT' },
    { name: 'started_at', type: 'DATETIME' },
    { name: 'finished_at', type: 'DATETIME' },
    { name: 'status', type: 'TEXT' },
    { name: 'scanned_count', type: 'INTEGER DEFAULT 0' },
    { name: 'changed_count', type: 'INTEGER DEFAULT 0' },
    { name: 'error_count', type: 'INTEGER DEFAULT 0' },
    { name: 'error_message', type: 'TEXT' },
    { name: 'details_json', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  tasks: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'code', type: 'TEXT' },
    { name: 'title', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'task_type', type: "TEXT DEFAULT 'field_verification'" },
    { name: 'source_type', type: "TEXT DEFAULT 'none'" },
    { name: 'source_id', type: 'TEXT' },
    { name: 'campaign_id', type: 'TEXT' },
    { name: 'case_id', type: 'TEXT' },
    { name: 'site_id', type: 'TEXT' },
    { name: 'observation_id', type: 'TEXT' },
    { name: 'location_text', type: 'TEXT' },
    { name: 'latitude', type: 'REAL' },
    { name: 'longitude', type: 'REAL' },
    { name: 'start_at', type: 'DATETIME' },
    { name: 'due_at', type: 'DATETIME' },
    { name: 'assignment_type', type: "TEXT DEFAULT 'open'" },
    { name: 'assigned_profile_id', type: 'TEXT' },
    { name: 'club_id', type: 'TEXT' },
    { name: 'max_participants', type: 'INTEGER DEFAULT 10' },
    { name: 'status', type: "TEXT DEFAULT 'OPEN'" },
    { name: 'priority', type: "TEXT DEFAULT 'MEDIUM'" },
    { name: 'points', type: 'INTEGER DEFAULT 20' },
    { name: 'contribution_minutes', type: 'INTEGER DEFAULT 30' },
    { name: 'evidence_instructions', type: 'TEXT' },
    { name: 'created_by', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'archived_at', type: 'DATETIME' },
    { name: 'deleted_at', type: 'DATETIME' }
  ],
  task_participants: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'task_id', type: 'TEXT' },
    { name: 'profile_id', type: 'TEXT' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'club_id', type: 'TEXT' },
    { name: 'status', type: "TEXT DEFAULT 'joined'" },
    { name: 'joined_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'started_at', type: 'DATETIME' },
    { name: 'submitted_at', type: 'DATETIME' },
    { name: 'completed_at', type: 'DATETIME' },
    { name: 'revision_notes', type: 'TEXT' }
  ],
  task_submissions: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'task_id', type: 'TEXT' },
    { name: 'participant_id', type: 'TEXT' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'image_url', type: 'TEXT' },
    { name: 'image_hash', type: 'TEXT' },
    { name: 'outcome', type: "TEXT DEFAULT 'BETTER'" },
    { name: 'notes', type: 'TEXT' },
    { name: 'latitude', type: 'REAL' },
    { name: 'longitude', type: 'REAL' },
    { name: 'status', type: "TEXT DEFAULT 'submitted'" },
    { name: 'review_note', type: 'TEXT' },
    { name: 'reviewed_by', type: 'TEXT' },
    { name: 'reviewed_at', type: 'DATETIME' },
    { name: 'submitted_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  task_timelines: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'task_id', type: 'TEXT' },
    { name: 'event_type', type: 'TEXT' },
    { name: 'actor_id', type: 'TEXT' },
    { name: 'actor_name', type: 'TEXT' },
    { name: 'actor_role', type: 'TEXT' },
    { name: 'description', type: 'TEXT' },
    { name: 'metadata_json', type: 'TEXT' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  notifications: [
    { name: 'id', type: 'TEXT PRIMARY KEY' },
    { name: 'user_id', type: 'TEXT' },
    { name: 'case_id', type: 'TEXT' },
    { name: 'type', type: "TEXT DEFAULT 'SYSTEM'" },
    { name: 'title', type: 'TEXT' },
    { name: 'message', type: 'TEXT' },
    { name: 'priority', type: "TEXT DEFAULT 'normal'" },
    { name: 'is_read', type: 'INTEGER DEFAULT 0' },
    { name: 'is_muted', type: 'INTEGER DEFAULT 0' },
    { name: 'created_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' },
    { name: 'createdAt', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ],
  system_audit_logs: [
    { name: 'id', type: 'INTEGER PRIMARY KEY AUTOINCREMENT' },
    { name: 'user_email', type: 'TEXT' },
    { name: 'user_role', type: 'TEXT' },
    { name: 'action', type: 'TEXT' },
    { name: 'module', type: 'TEXT' },
    { name: 'target_id', type: 'TEXT' },
    { name: 'old_values', type: 'TEXT' },
    { name: 'new_values', type: 'TEXT' },
    { name: 'request_id', type: 'TEXT' },
    { name: 'timestamp', type: 'TEXT' }
  ],
  system_metadata: [
    { name: 'key', type: 'TEXT PRIMARY KEY' },
    { name: 'value', type: 'TEXT' },
    { name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP' }
  ]
};

/**
 * Tự động tạo bảng nếu chưa có
 * @param {Object} db 
 * @param {string} tableName 
 * @param {Array<Object>} columns 
 */
async function ensureTableStructure(db, tableName, columns) {
  const colDefs = columns.map(c => `"${c.name}" ${c.type}`).join(', ');
  const sql = `CREATE TABLE IF NOT EXISTS "${tableName}" (${colDefs})`;
  await db.prepare(sql).run().catch(() => {});
}

/**
 * Tự động kiểm tra và thêm các cột còn thiếu (Auto-Healing Columns)
 * @param {Object} db 
 * @param {string} tableName 
 * @param {Array<Object>} requiredCols 
 */
async function healTableColumns(db, tableName, requiredCols) {
  try {
    const res = await db.prepare(`PRAGMA table_info("${tableName}")`).all().catch(() => ({ results: [] }));
    const existingCols = ((res && res.results) || res || []).map(r => r.name);

    if (!existingCols || existingCols.length === 0) {
      // Bảng chưa có hoặc trống -> Tạo bảng mới
      await ensureTableStructure(db, tableName, requiredCols);
      return;
    }

    const alterPromises = [];
    for (const col of requiredCols) {
      if (!existingCols.includes(col.name)) {
        // Loại bỏ PRIMARY KEY, AUTOINCREMENT, DEFAULT CURRENT_TIMESTAMP và NOT NULL khi ALTER TABLE ADD COLUMN
        let sanitizedType = col.type
          .replace(/\bPRIMARY\s+KEY\b/gi, '')
          .replace(/\bAUTOINCREMENT\b/gi, '')
          .replace(/\bDEFAULT\s+CURRENT_TIMESTAMP\b/gi, '')
          .replace(/\bDEFAULT\s+\(datetime\([^)]*\)\)/gi, '')
          .replace(/\bNOT\s+NULL\b/gi, '')
          .trim();
        if (!sanitizedType) sanitizedType = 'TEXT';

        const alterSql = `ALTER TABLE "${tableName}" ADD COLUMN "${col.name}" ${sanitizedType}`;
        alterPromises.push(
          db.prepare(alterSql).run().catch(err => {
            // SQLite sẽ ném lỗi nếu duplicate column, bắt lại an toàn
            if (!String(err?.message || '').includes('duplicate column')) {
              console.warn(`[AutoHealer] ALTER TABLE "${tableName}" ADD COLUMN "${col.name}" notice:`, err?.message);
            }
          })
        );
      }
    }

    if (alterPromises.length > 0) {
      await Promise.all(alterPromises);
    }
  } catch (err) {
    console.error(`[AutoHealer] Error healing table ${tableName}:`, err);
  }
}

/**
 * Đảm bảo các chỉ mục hiệu năng trọng yếu (Performance Indexes)
 * @param {Object} db 
 */
async function ensureEssentialIndexes(db) {
  const indexes = [
    'CREATE INDEX IF NOT EXISTS "idx_cases_priority" ON "cases"("priority")',
    'CREATE INDEX IF NOT EXISTS "idx_cases_attention" ON "cases"("attention_state", "slaDeadline")',
    'CREATE INDEX IF NOT EXISTS "idx_cases_status_slaDeadline" ON "cases"("status", "slaDeadline")',
    'CREATE INDEX IF NOT EXISTS "idx_complaints_siteId" ON "complaints"("siteId")',
    'CREATE INDEX IF NOT EXISTS "idx_complaints_status" ON "complaints"("status", "createdAt" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_evidences_caseId" ON "evidences"("caseId")',
    'CREATE INDEX IF NOT EXISTS "idx_evidences_actionId" ON "evidences"("actionId")',
    'CREATE INDEX IF NOT EXISTS "idx_observations_status_created" ON "observations"("status", "createdAt" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_observations_siteId" ON "observations"("siteId")',
    'CREATE INDEX IF NOT EXISTS "idx_follow_ups_obs" ON "follow_ups"("observationId", "createdAt" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_handoffs_obs" ON "handoffs"("observationId")',
    'CREATE INDEX IF NOT EXISTS "idx_audit_events_agg" ON "audit_events"("aggregate_type", "aggregate_id", "created_at" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_system_audit_timestamp" ON "system_audit_logs"("timestamp" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_system_audit_module" ON "system_audit_logs"("module")',
    'CREATE INDEX IF NOT EXISTS "idx_youth_cert_code" ON "youth_certificates"("certificate_code")',
    'CREATE INDEX IF NOT EXISTS "idx_youth_activities_user" ON "youth_activities"("user_id", "validation_status")',
    'CREATE INDEX IF NOT EXISTS "idx_automation_runs_job" ON "automation_runs"("job_name", "started_at" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_status" ON "tasks"("status")',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_assignment" ON "tasks"("assignment_type", "assigned_profile_id", "club_id")',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_case" ON "tasks"("case_id")',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_campaign" ON "tasks"("campaign_id")',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_site" ON "tasks"("site_id")',
    'CREATE INDEX IF NOT EXISTS "idx_tasks_due" ON "tasks"("due_at")',
    'CREATE INDEX IF NOT EXISTS "idx_task_participants_task" ON "task_participants"("task_id", "status")',
    'CREATE INDEX IF NOT EXISTS "idx_task_participants_user" ON "task_participants"("profile_id", "user_id")',
    'CREATE INDEX IF NOT EXISTS "idx_task_submissions_task" ON "task_submissions"("task_id", "status")',
    'CREATE INDEX IF NOT EXISTS "idx_task_timelines_task" ON "task_timelines"("task_id", "created_at" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_audit_logs_target" ON "audit_logs"("targetId", "createdAt" DESC)',
    'CREATE INDEX IF NOT EXISTS "idx_contractor_explanations_case" ON "contractor_explanations"("caseId")'
  ];

  await Promise.all(indexes.map(sql => db.prepare(sql).run().catch(() => {})));
}

/**
 * Đảm bảo 100% Schema & Cột Cơ Sở Dữ Liệu D1 luôn hoàn thiện và tương thích (SSOT Engine)
 * Chạy tự động tại Worker boot / middleware với Single-Flight Promise Caching.
 * @param {Object} dbOrEnv - D1 Database Binding hoặc Adapter hoặc Env Object
 * @returns {Promise<boolean>}
 */
export async function ensureSchema(dbOrEnv) {
  if (globalSchemaChecked) return true;
  let db = dbOrEnv;
  if (db && typeof db.prepare !== 'function') {
    db = db.DB || db.DATABASE || (typeof db.getD1OrSqlite === 'function' ? db.getD1OrSqlite(db) : null);
  }
  if (!db || typeof db.prepare !== 'function') return false;

  if (!globalSchemaPromise) {
    globalSchemaPromise = (async () => {
      // 1. Xác thực và khởi tạo system_metadata
      await verifyDatabaseIdentity(db, EXPECTED_APP_ID);

      // 2. Chữa lành toàn bộ các bảng SSOT song song
      const tableNames = Object.keys(REQUIRED_TABLE_COLUMNS);
      await Promise.all(
        tableNames.map(tableName => healTableColumns(db, tableName, REQUIRED_TABLE_COLUMNS[tableName]))
      );

      // 3. Đảm bảo toàn bộ performance indexes
      await ensureEssentialIndexes(db);

      globalSchemaChecked = true;
      return true;
    })().catch(err => {
      globalSchemaPromise = null;
      console.error('[SchemaHealer] Fatal error during ensureSchema:', err);
      return false;
    });
  }

  return globalSchemaPromise;
}
