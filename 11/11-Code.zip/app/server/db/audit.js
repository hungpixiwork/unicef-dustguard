// app/server/db/audit.js
// Universal D1 System Audit Logging SSOT with Vietnam GMT+7 Timezone

import { getVNNowStr } from './timezone.js';
import { safeJsonStringify, safeJsonParse } from './guard.js';
import { executeBatch } from './batching.js';

let systemAuditTableChecked = false;

/**
 * Đảm bảo bảng system_audit_logs và các index cần thiết tồn tại
 * @param {Object} db - D1 Database Binding
 */
export async function ensureSystemAuditTable(db) {
  if (systemAuditTableChecked) return;
  try {
    if (!db || typeof db.prepare !== 'function') return;
    await db.prepare(`
      CREATE TABLE IF NOT EXISTS system_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT NOT NULL,
        user_role TEXT,
        action TEXT NOT NULL,
        module TEXT NOT NULL,
        target_id TEXT,
        old_values TEXT,
        new_values TEXT,
        request_id TEXT,
        timestamp TEXT NOT NULL
      )
    `).run().catch(() => {});

    await db.prepare('CREATE INDEX IF NOT EXISTS idx_system_audit_timestamp ON system_audit_logs(timestamp DESC)').run().catch(() => {});
    await db.prepare('CREATE INDEX IF NOT EXISTS idx_system_audit_module ON system_audit_logs(module)').run().catch(() => {});
    await db.prepare('CREATE INDEX IF NOT EXISTS idx_system_audit_user ON system_audit_logs(user_email)').run().catch(() => {});
    await db.prepare('CREATE INDEX IF NOT EXISTS idx_system_audit_target ON system_audit_logs(target_id)').run().catch(() => {});
    systemAuditTableChecked = true;
  } catch (err) {
    console.error('[ensureSystemAuditTable] Error:', err);
  }
}

/**
 * Ghi nhật ký thao tác hệ thống (System Audit Log) chuẩn múi giờ Việt Nam GMT+7
 * @param {Object} db - D1 Database Binding
 * @param {Object} params
 * @param {string|Object} params.user - Email string hoặc đối tượng user { email, role }
 * @param {string} params.action - Tên hành động (CREATE, UPDATE, DELETE, VERIFY, HANDOFF, ESW_RELEASE, etc.)
 * @param {string} params.module - Domain module (CASES, OBSERVATIONS, SITES, COMPLAINTS, CSR, YOUTH, etc.)
 * @param {string} [params.targetId=''] - ID của đối tượng bị thay đổi
 * @param {any} [params.oldVal=null] - Dữ liệu trước khi sửa
 * @param {any} [params.newVal=null] - Dữ liệu sau khi sửa
 * @param {string} [params.requestId=''] - Request ID nếu có
 * @returns {Promise<Object|null>}
 */
export async function logSystemAudit(db, {
  user = 'SYSTEM',
  action,
  module,
  targetId = '',
  oldVal = null,
  newVal = null,
  requestId = ''
}) {
  try {
    if (!db || typeof db.prepare !== 'function') return null;
    await ensureSystemAuditTable(db);

    let userEmail = 'SYSTEM';
    let userRole = '';
    if (typeof user === 'string') {
      userEmail = user;
    } else if (user && typeof user === 'object') {
      userEmail = user.email || user.user_email || user.username || user.id || 'SYSTEM';
      userRole = user.role || user.user_role || '';
    }

    const oldStr = oldVal !== null && oldVal !== undefined ? (typeof oldVal === 'string' ? oldVal : safeJsonStringify(oldVal)) : '';
    const newStr = newVal !== null && newVal !== undefined ? (typeof newVal === 'string' ? newVal : safeJsonStringify(newVal)) : '';
    const timestamp = getVNNowStr();

    const stmt = db.prepare(`
      INSERT INTO system_audit_logs (user_email, user_role, action, module, target_id, old_values, new_values, request_id, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(userEmail, userRole, action, module, String(targetId || ''), oldStr, newStr, String(requestId || ''), timestamp);

    const res = await stmt.run().catch(err => {
      console.error('[logSystemAudit] INSERT error:', err);
      return null;
    });

    return {
      success: true,
      user_email: userEmail,
      user_role: userRole,
      action,
      module,
      target_id: targetId,
      timestamp,
      changes: res?.meta?.changes || 1
    };
  } catch (err) {
    console.error('[logSystemAudit] Unexpected error:', err);
    return null;
  }
}

/**
 * Ghi nhiều bản ghi audit cùng lúc trong 1 Batch Transaction nguyên tử (<20ms)
 * @param {Object} db - D1 Database Binding
 * @param {Array<Object>} auditEntries
 * @returns {Promise<Array<Object>>}
 */
export async function batchLogAudit(db, auditEntries = []) {
  if (!db || !Array.isArray(auditEntries) || auditEntries.length === 0) return [];
  await ensureSystemAuditTable(db);

  const timestamp = getVNNowStr();
  const stmts = auditEntries.map(entry => {
    let userEmail = 'SYSTEM';
    let userRole = '';
    if (typeof entry.user === 'string') {
      userEmail = entry.user;
    } else if (entry.user && typeof entry.user === 'object') {
      userEmail = entry.user.email || entry.user.user_email || entry.user.username || entry.user.id || 'SYSTEM';
      userRole = entry.user.role || entry.user.user_role || '';
    }

    const oldStr = entry.oldVal !== null && entry.oldVal !== undefined ? (typeof entry.oldVal === 'string' ? entry.oldVal : safeJsonStringify(entry.oldVal)) : '';
    const newStr = entry.newVal !== null && entry.newVal !== undefined ? (typeof entry.newVal === 'string' ? entry.newVal : safeJsonStringify(entry.newVal)) : '';

    return db.prepare(`
      INSERT INTO system_audit_logs (user_email, user_role, action, module, target_id, old_values, new_values, request_id, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(userEmail, userRole, entry.action, entry.module, String(entry.targetId || ''), oldStr, newStr, String(entry.requestId || ''), timestamp);
  });

  return executeBatch(db, stmts, 100);
}

/**
 * Truy vấn nhật ký hệ thống phân trang
 * @param {Object} db 
 * @param {Object} filter 
 * @returns {Promise<{items: Array<Object>, total: number, page: number, pageSize: number}>}
 */
export async function queryAuditLogs(db, filter = {}) {
  if (!db || typeof db.prepare !== 'function') return { items: [], total: 0, page: 1, pageSize: 50 };
  await ensureSystemAuditTable(db);

  const { module, action, user_email, target_id, page = 1, pageSize = 50 } = filter;
  const safePage = Math.max(1, Number(page) || 1);
  const safePageSize = Math.min(100, Math.max(1, Number(pageSize) || 50));
  const offset = (safePage - 1) * safePageSize;

  const conditions = [];
  const params = [];

  if (module) {
    conditions.push('module = ?');
    params.push(module);
  }
  if (action) {
    conditions.push('action = ?');
    params.push(action);
  }
  if (user_email) {
    conditions.push('user_email = ?');
    params.push(user_email);
  }
  if (target_id) {
    conditions.push('target_id = ?');
    params.push(target_id);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const countQuery = `SELECT COUNT(*) as total FROM system_audit_logs ${whereClause}`;
  const dataQuery = `SELECT * FROM system_audit_logs ${whereClause} ORDER BY id DESC LIMIT ? OFFSET ?`;

  const [countRes, dataRes] = await Promise.all([
    db.prepare(countQuery).bind(...params).first().catch(() => ({ total: 0 })),
    db.prepare(dataQuery).bind(...params, safePageSize, offset).all().catch(() => ({ results: [] }))
  ]);

  const items = (dataRes?.results || dataRes || []).map(r => ({
    ...r,
    old_values_parsed: safeJsonParse(r.old_values, null),
    new_values_parsed: safeJsonParse(r.new_values, null)
  }));

  const total = countRes?.total || 0;

  return {
    items,
    total,
    page: safePage,
    pageSize: safePageSize,
    totalPages: Math.ceil(total / safePageSize)
  };
}
