// app/server/db/batching.js
// Utility Tối Ưu Hóa Tốc Độ Cloudflare D1 Batching (db.batch()) & Atomic Transactions

import { sanitizeParam } from './guard.js';

/**
 * Thực thi một mảng các D1 PreparedStatement bằng db.batch() chia nhỏ theo Chunk (<20ms/batch)
 * @param {Object} db - D1 Database Binding hoặc SQLite Adapter
 * @param {Array<Object>} statements - Mảng các db.prepare().bind()
 * @param {number} [chunkSize=100] - Kích thước mỗi Batch (mặc định 100)
 * @returns {Promise<Array<Object>>} Kết quả thực thi từ D1
 */
export async function executeBatch(db, statements = [], chunkSize = 100) {
  if (!db || typeof db.batch !== 'function') {
    throw new Error('Chưa cung cấp D1 Database Binding hợp lệ cho executeBatch.');
  }

  if (!statements || statements.length === 0) {
    return [];
  }

  const results = [];
  const size = Math.max(1, Math.min(chunkSize, 500));

  for (let i = 0; i < statements.length; i += size) {
    const chunk = statements.slice(i, i + size);
    const chunkResult = await db.batch(chunk);
    if (Array.isArray(chunkResult)) {
      results.push(...chunkResult);
    } else {
      results.push(chunkResult);
    }
  }

  return results;
}

/**
 * Tạo danh sách D1 PreparedStatements cho INSERT hàng loạt từ mảng Objects
 * @param {Object} db - D1 Database Binding
 * @param {string} tableName - Tên bảng CSDL
 * @param {Array<Object>} records - Mảng các đối tượng dữ liệu
 * @param {Array<string>} [explicitColumns=null] - Danh sách cột cố định
 * @returns {Array<Object>} Mảng PreparedStatements
 */
export function buildInsertStatements(db, tableName, records = [], explicitColumns = null) {
  if (!records || records.length === 0) return [];

  const columns = explicitColumns || Object.keys(records[0]);
  const quotedColumns = columns.map(c => `"${c}"`);
  const placeholders = columns.map(() => '?').join(', ');
  const sql = `INSERT INTO "${tableName}" (${quotedColumns.join(', ')}) VALUES (${placeholders})`;

  return records.map(record => {
    const values = columns.map(col => sanitizeParam(record[col]));
    return db.prepare(sql).bind(...values);
  });
}

/**
 * Tạo danh sách D1 PreparedStatements cho UPSERT (INSERT ... ON CONFLICT DO UPDATE)
 * @param {Object} db - D1 Database Binding
 * @param {string} tableName - Tên bảng CSDL
 * @param {Array<Object>} records - Mảng các đối tượng dữ liệu
 * @param {Array<string>} conflictKeys - Các cột khóa xung đột (ví dụ ['id'] hoặc ['code'])
 * @param {Array<string>} [updateColumns=null] - Các cột cần cập nhật khi có xung đột
 * @returns {Array<Object>} Mảng PreparedStatements
 */
export function buildUpsertStatements(db, tableName, records = [], conflictKeys = [], updateColumns = null) {
  if (!records || records.length === 0) return [];

  const columns = Object.keys(records[0]);
  const quotedColumns = columns.map(c => `"${c}"`);
  const placeholders = columns.map(() => '?').join(', ');

  const targetUpdateCols = updateColumns || columns.filter(c => !conflictKeys.includes(c));
  const updateAssignments = targetUpdateCols.map(c => `"${c}" = excluded."${c}"`).join(', ');

  const quotedConflictKeys = conflictKeys.map(k => `"${k}"`).join(', ');
  const conflictClause = conflictKeys.length > 0
    ? `ON CONFLICT(${quotedConflictKeys}) DO UPDATE SET ${updateAssignments}`
    : `ON CONFLICT DO NOTHING`;

  const sql = `INSERT INTO "${tableName}" (${quotedColumns.join(', ')}) VALUES (${placeholders}) ${conflictClause}`;

  return records.map(record => {
    const values = columns.map(col => sanitizeParam(record[col]));
    return db.prepare(sql).bind(...values);
  });
}

/**
 * Thực thi INSERT hàng loạt mảng đối tượng qua db.batch() siêu tốc
 * @param {Object} db 
 * @param {string} tableName 
 * @param {Array<Object>} records 
 * @param {number} [chunkSize=100] 
 * @returns {Promise<Array<Object>>}
 */
export async function executeBatchInsert(db, tableName, records = [], chunkSize = 100) {
  const statements = buildInsertStatements(db, tableName, records);
  return executeBatch(db, statements, chunkSize);
}

/**
 * Thực thi UPSERT hàng loạt mảng đối tượng qua db.batch() siêu tốc
 * @param {Object} db 
 * @param {string} tableName 
 * @param {Array<Object>} records 
 * @param {Array<string>} conflictKeys 
 * @param {Array<string>} [updateColumns=null] 
 * @param {number} [chunkSize=100] 
 * @returns {Promise<Array<Object>>}
 */
export async function executeBatchUpsert(db, tableName, records = [], conflictKeys = [], updateColumns = null, chunkSize = 100) {
  const statements = buildUpsertStatements(db, tableName, records, conflictKeys, updateColumns);
  return executeBatch(db, statements, chunkSize);
}

/**
 * Thực thi transaction atomic cho nhiều thao tác khác bảng cùng lúc
 * @param {Object} db 
 * @param {Array<Object>} statements 
 * @returns {Promise<Array<Object>>}
 */
export async function runTransaction(db, statements = []) {
  return executeBatch(db, statements, statements.length || 100);
}
