// app/server/db/timezone.js
// Utility xử lý Múi Giờ GMT+7 Việt Nam chuẩn trên Cloudflare Edge Runtime & Node.js

export const VIETNAM_OFFSET_HOURS = 7;
export const VIETNAM_OFFSET_MS = 7 * 3600 * 1000;

/**
 * Lấy đối tượng Date đã được dịch chuyển +7 giờ chuẩn Việt Nam (GMT+7)
 * @param {Date|number|string} [inputDate]
 * @returns {Date}
 */
export function getVietnamDate(inputDate) {
  const d = inputDate ? new Date(inputDate) : new Date();
  const utcTime = d.getTime() + (d.getTimezoneOffset() * 60000);
  return new Date(utcTime + VIETNAM_OFFSET_MS);
}

/**
 * Lấy chuỗi ngày chuẩn YYYY-MM-DD theo giờ Việt Nam
 * @param {Date|number|string} [inputDate]
 * @returns {string} ví dụ "2026-08-27"
 */
export function getVietnamDateString(inputDate) {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' }).format(
      inputDate ? new Date(inputDate) : new Date()
    );
  } catch {
    const d = inputDate ? new Date(inputDate) : new Date();
    const vnTime = new Date(d.getTime() + VIETNAM_OFFSET_MS);
    return vnTime.toISOString().split('T')[0];
  }
}

/**
 * Lấy chuỗi giờ phút giây HH:mm:ss theo giờ Việt Nam
 * @param {Date|number|string} [inputDate]
 * @returns {string} ví dụ "18:45:30"
 */
export function getVietnamTimeString(inputDate) {
  try {
    const options = {
      timeZone: 'Asia/Ho_Chi_Minh',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    };
    const parts = new Intl.DateTimeFormat('en-GB', options).formatToParts(
      inputDate ? new Date(inputDate) : new Date()
    );
    const p = {};
    parts.forEach(item => { p[item.type] = item.value; });
    return `${p.hour || '00'}:${p.minute || '00'}:${p.second || '00'}`;
  } catch {
    const d = inputDate ? new Date(inputDate) : new Date();
    const vnTime = new Date(d.getTime() + VIETNAM_OFFSET_MS);
    return vnTime.toISOString().split('T')[1].substring(0, 8);
  }
}

/**
 * Lấy chuỗi Ngày Giờ đầy đủ YYYY-MM-DD HH:mm:ss theo giờ Việt Nam
 * @param {Date|number|string} [inputDate]
 * @returns {string} ví dụ "2026-08-27 18:45:30"
 */
export function getVietnamDateTimeString(inputDate) {
  const dateStr = getVietnamDateString(inputDate);
  const timeStr = getVietnamTimeString(inputDate);
  return `${dateStr} ${timeStr}`;
}

/**
 * Lấy chuỗi ISO đầy đủ kèm offset +07:00
 * @param {Date|number|string} [inputDate]
 * @returns {string} ví dụ "2026-08-27T18:45:30.000+07:00"
 */
export function getVietnamISOString(inputDate) {
  const d = inputDate ? new Date(inputDate) : new Date();
  const vnTime = new Date(d.getTime() + VIETNAM_OFFSET_MS);
  const iso = vnTime.toISOString();
  return iso.substring(0, 23) + '+07:00';
}

/**
 * Lấy ngày hôm nay dạng YYYY-MM-DD theo GMT+7
 * @returns {string}
 */
export function getVNTodayStr() {
  return getVietnamDateString();
}

/**
 * Lấy thời gian hiện tại YYYY-MM-DD HH:mm:ss theo GMT+7
 * @returns {string}
 */
export function getVNNowStr() {
  return getVietnamDateTimeString();
}

/**
 * Lấy tháng hiện tại dạng YYYY-MM theo GMT+7
 * @param {Date|number|string} [inputDate]
 * @returns {string} ví dụ "2026-08"
 */
export function getVietnamMonthString(inputDate) {
  return getVietnamDateString(inputDate).substring(0, 7);
}
