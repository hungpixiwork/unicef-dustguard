import { prisma, getDbClient } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { createPriorityScoreHistory } from './history.repository.js';
import { parseCoordinates, serializeCoordinates, normalizeEntityCoordinates } from '../domain/spatial/spatial-adapter.js';

export async function createSite(data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  
  let formattedCoords = null;
  if (data.latitude !== undefined && data.longitude !== undefined && data.latitude !== null && data.longitude !== null) {
    formattedCoords = serializeCoordinates({ latitude: data.latitude, longitude: data.longitude });
  } else if (data.coordinates) {
    formattedCoords = serializeCoordinates(data.coordinates) || data.coordinates;
  }

  const siteCode = data.code || `BD-${Math.floor(1000 + Math.random() * 9000)}`;
  const existing = await client.site.findFirst({
    where: {
      OR: [
        ...(data.id ? [{ id: data.id }] : []),
        { code: siteCode }
      ]
    }
  });

  if (existing) {
    const updated = await client.site.update({
      where: { id: existing.id },
      data: {
        name: data.name ?? existing.name,
        address: data.address ?? existing.address,
        ward: data.ward ?? existing.ward,
        province: data.province ?? existing.province,
        coordinates: formattedCoords ?? (data.coordinates ?? existing.coordinates),
        dustRiskScore: data.dustRiskScore !== undefined ? Number(data.dustRiskScore) : existing.dustRiskScore,
        riskLevel: data.riskLevel ?? existing.riskLevel,
        status: data.status ?? existing.status,
        investorName: data.investorName ?? existing.investorName,
        contractorName: data.contractorName ?? existing.contractorName,
        licenseNumber: data.licenseNumber ?? existing.licenseNumber,
        managerName: data.managerName ?? existing.managerName,
        managerPhone: data.managerPhone ?? existing.managerPhone,
        managerEmail: data.managerEmail ?? existing.managerEmail,
        deletedAt: null
      }
    });
    return normalizeEntityCoordinates(updated);
  }

  const site = await client.site.create({
    data: {
      ...(data.id ? { id: data.id } : {}),
      name: data.name,
      code: siteCode,
      address: data.address,
      ward: data.ward,
      province: data.province || 'Bình Dương',
      coordinates: formattedCoords || data.coordinates || null,
      dustRiskScore: Number(data.dustRiskScore) || 0,
      riskLevel: data.riskLevel || 'LOW',
      status: data.status || 'ACTIVE',
      investorName: data.investorName || null,
      contractorName: data.contractorName || null,
      licenseNumber: data.licenseNumber || null,
      managerName: data.managerName || null,
      managerPhone: data.managerPhone || null,
      managerEmail: data.managerEmail || null
    }
  });

  await createAuditLog({
    action: 'SITE_CREATED',
    entityType: 'SITE',
    entityId: site.id,
    actorId: actor.id || actor.userId || null,
    actorName: actor.name || actor.fullName || null,
    actorRole: actor.role || 'staff',
    afterJson: site
  }, envOrDb);

  return normalizeEntityCoordinates(site);
}

export async function getSiteById(id, options = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const where = {
    OR: [
      { id },
      { code: id }
    ]
  };
  if (!options.includeDeleted) {
    where.deletedAt = null;
  }
  const site = await client.site.findFirst({
    where,
    include: {
      sensors: { where: options.includeDeleted ? {} : { deletedAt: null } },
      complaints: { where: options.includeDeleted ? {} : { deletedAt: null }, take: 10 },
      cases: { where: options.includeDeleted ? {} : { deletedAt: null }, take: 10 }
    }
  });
  return site ? normalizeEntityCoordinates(site) : null;
}

export async function getSites(query = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const {
    ward,
    status,
    search,
    page = 1,
    pageSize = 20,
    includeDeleted = false
  } = query;

  const where = {};
  if (!includeDeleted) {
    where.deletedAt = null;
  }
  if (ward && ward !== 'ALL') {
    where.ward = ward;
  }
  if (status && status !== 'ALL') {
    where.status = status;
  }
  if (search) {
    where.OR = [
      { name: { contains: search } },
      { address: { contains: search } },
      { code: { contains: search } }
    ];
  }

  const safePage = Math.max(Number(page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(pageSize) || 20, 1), 100);

  const [total, items] = await Promise.all([
    client.site.count({ where }),
    client.site.findMany({
      where,
      orderBy: { dustRiskScore: 'desc' },
      skip: (safePage - 1) * safePageSize,
      take: safePageSize,
      include: {
        sensors: { where: includeDeleted ? {} : { deletedAt: null } }
      }
    })
  ]);

  return {
    items: items.map(s => normalizeEntityCoordinates(s)),
    pagination: {
      page: safePage,
      pageSize: safePageSize,
      limit: safePageSize,
      offset: (safePage - 1) * safePageSize,
      total,
      totalPages: Math.ceil(total / safePageSize)
    }
  };
}

export async function updateSite(id, data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const current = await client.site.findUnique({ where: { id } });
  if (!current) return null;

  const updateData = {};
  const allowedFields = [
    'name', 'code', 'address', 'ward', 'province', 'coordinates',
    'dustRiskScore', 'riskLevel', 'status', 'investorName',
    'contractorName', 'licenseNumber', 'managerName', 'managerPhone', 'managerEmail'
  ];
  for (const field of allowedFields) {
    if (data[field] !== undefined) {
      updateData[field] = data[field];
    }
  }

  if (data.latitude !== undefined && data.longitude !== undefined && data.latitude !== null && data.longitude !== null) {
    updateData.coordinates = serializeCoordinates({ latitude: data.latitude, longitude: data.longitude });
  } else if (data.coordinates !== undefined) {
    updateData.coordinates = serializeCoordinates(data.coordinates) || data.coordinates;
  }

  const updated = await client.site.update({
    where: { id },
    data: updateData
  });

  await createAuditLog({
    action: 'SITE_UPDATED',
    entityType: 'SITE',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  // If score changed, record in history
  if (data.dustRiskScore !== undefined && data.dustRiskScore !== current.dustRiskScore) {
    await createPriorityScoreHistory({
      siteId: id,
      score: data.dustRiskScore,
      scoreVersion: 'CPS_v1',
      componentsJson: data.components || {},
      reasonsJson: data.reasons || [],
      calculatedBy: actor.name || 'MANUAL_UPDATE'
    }, envOrDb);
  }

  return normalizeEntityCoordinates(updated);
}

export async function softDeleteSite(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const current = await client.site.findUnique({ where: { id } });
  if (!current) return null;

  try {
    const updated = await client.site.update({
      where: { id },
      data: { deletedAt: new Date() }
    });

    await createAuditLog({
      action: 'SITE_DELETED',
      entityType: 'SITE',
      entityId: id,
      actorId: actor.id || null,
      actorName: actor.name || null,
      actorRole: actor.role || 'staff',
      beforeJson: current,
      afterJson: updated
    }, envOrDb);

    return updated;
  } catch (err) {
    if (err.code === 'P2025') return null;
    throw err;
  }
}

export async function restoreSite(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const current = await client.site.findUnique({ where: { id } });
  if (!current) return null;

  try {
    const updated = await client.site.update({
      where: { id },
      data: { deletedAt: null }
    });

    await createAuditLog({
      action: 'SITE_RESTORED',
      entityType: 'SITE',
      entityId: id,
      actorId: actor.id || null,
      actorName: actor.name || null,
      actorRole: actor.role || 'staff',
      beforeJson: current,
      afterJson: updated
    }, envOrDb);

    return updated;
  } catch (err) {
    if (err.code === 'P2025') return null;
    throw err;
  }
}


export async function hardDeleteSite(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const current = await client.site.findUnique({ where: { id } });
  if (!current) return { success: true, id };

  await client.site.delete({ where: { id } }).catch(() => null);

  await createAuditLog({
    action: 'SITE_PERMANENTLY_DELETED',
    entityType: 'SITE',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    beforeJson: current
  }, envOrDb);

  return { success: true, id };
}

