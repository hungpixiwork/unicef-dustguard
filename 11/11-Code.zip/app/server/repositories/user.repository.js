import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { ROLES, isValidRole } from '../auth/roles.js';

/**
 * User & Profile Repository for DustGuard VN (D1 SSOT)
 * Hybrid Auth: Clerk handles human identity; D1 manages profile, domain roles, and access control.
 */

/**
 * Idempotent Clerk User Provisioning
 * Finds existing user by clerk_user_id or email, or automatically provisions a new internal profile.
 * Thread-safe with race condition protection for high-concurrency Cloudflare Edge requests.
 * 
 * @param {Object} params
 * @param {string} params.clerkUserId - External Clerk User ID (e.g. user_2xxx)
 * @param {string} params.email - User email address
 * @param {string} [params.fullName] - Full name / display name
 * @param {string} [params.name] - Alias for fullName
 * @param {string} [params.image] - Avatar URL
 * @param {string} [params.avatarUrl] - Alias for image
 * @param {string} [params.role] - Domain role (defaults to 'citizen')
 * @param {string} [params.status] - 'ACTIVE' | 'DISABLED'
 * @param {string} [params.phoneNumber] - Phone number
 * @param {string} [params.department] - Department for staff/inspectors
 * @param {Object} [params.metadata] - Extra public metadata from Clerk
 * @param {Object} [envOrDb] - Worker env or DB binding
 * @returns {Promise<{ user: Object, profile: Object, isNew: boolean, linked: boolean }>}
 */
export async function provisionClerkUser(params = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const clerkUserId = String(params.clerkUserId || '').trim();
  const email = String(params.email || '').trim().toLowerCase();

  if (!clerkUserId && !email) {
    throw new Error('provisionClerkUser requires at least clerkUserId or email');
  }

  const rawName = params.fullName || params.name || params.metadata?.fullName || params.metadata?.full_name || (email ? email.split('@')[0] : 'Công dân');
  const fullName = String(rawName).trim() || 'Công dân';
  const avatarUrl = params.avatarUrl || params.image || params.metadata?.avatarUrl || params.metadata?.image || null;
  const targetRole = params.role || params.metadata?.role || ROLES.CITIZEN;
  const role = isValidRole(targetRole) ? targetRole : ROLES.CITIZEN;
  const status = params.status || params.metadata?.status || 'ACTIVE';
  const phoneNumber = params.phoneNumber || params.metadata?.phoneNumber || null;
  const department = params.department || params.metadata?.department || null;
  const now = new Date().toISOString();

  // 1. Lookup by clerk_user_id (Highest Priority for Clerk Users)
  if (clerkUserId) {
    const existingByClerk = await db.prepare('SELECT * FROM users WHERE clerk_user_id = ?').bind(clerkUserId).first();
    if (existingByClerk) {
      let profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(existingByClerk.id).first();
      
      // Ensure profile exists
      if (!profile) {
        const profId = `prof_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        await db.prepare(`
          INSERT INTO profiles (id, userId, fullName, phoneNumber, avatarUrl, department, createdAt, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(profId, existingByClerk.id, fullName || existingByClerk.full_name, phoneNumber, avatarUrl, department, now, now).run();
        profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(existingByClerk.id).first();
      }

      return {
        user: existingByClerk,
        profile: profile || null,
        isNew: false,
        linked: false
      };
    }
  }

  // 2. Lookup by email (Account Linking for legacy/seed users)
  if (email) {
    const existingByEmail = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
    if (existingByEmail) {
      // Link clerk_user_id to existing account
      if (clerkUserId && existingByEmail.clerk_user_id !== clerkUserId) {
        await db.prepare(`
          UPDATE users 
          SET clerk_user_id = ?, 
              full_name = CASE WHEN (full_name IS NULL OR full_name = '' OR full_name = ?) THEN ? ELSE full_name END,
              image = COALESCE(?, image),
              updatedAt = ?
          WHERE id = ?
        `).bind(clerkUserId, email.split('@')[0], fullName, avatarUrl, now, existingByEmail.id).run();
      }

      let profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(existingByEmail.id).first();
      if (!profile) {
        const profId = `prof_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        await db.prepare(`
          INSERT INTO profiles (id, userId, fullName, phoneNumber, avatarUrl, department, createdAt, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(profId, existingByEmail.id, fullName || existingByEmail.full_name, phoneNumber, avatarUrl, department, now, now).run();
        profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(existingByEmail.id).first();
      }

      const updatedUser = await db.prepare('SELECT * FROM users WHERE id = ?').bind(existingByEmail.id).first();
      return {
        user: updatedUser,
        profile: profile || null,
        isNew: false,
        linked: true
      };
    }
  }

  // 3. Provision New Internal DustGuard Profile (Idempotent & Race-Condition Safe)
  const userId = params.id || (clerkUserId ? (clerkUserId.startsWith('usr_') ? clerkUserId : `usr_${clerkUserId.replace(/^user_/, '')}`) : `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`);

  try {
    await db.prepare(`
      INSERT INTO users (id, clerk_user_id, full_name, email, email_verified, image, role, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?)
    `).bind(userId, clerkUserId || null, fullName, email, avatarUrl, role, status, now, now).run();

    const profId = `prof_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    await db.prepare(`
      INSERT INTO profiles (id, userId, fullName, phoneNumber, avatarUrl, department, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(profId, userId, fullName, phoneNumber, avatarUrl, department, now, now).run();

    const newUser = await db.prepare('SELECT * FROM users WHERE id = ?').bind(userId).first();
    const newProfile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(userId).first();

    await createAuditLog({
      action: 'USER_PROVISIONED',
      entityType: 'USER',
      entityId: userId,
      actorId: userId,
      actorName: fullName,
      actorRole: role,
      afterJson: { id: userId, clerkUserId, email, role, status }
    }, envOrDb).catch(() => null);

    return {
      user: newUser,
      profile: newProfile || null,
      isNew: true,
      linked: false
    };
  } catch (err) {
    // Race Condition Fallback: Another concurrent edge request created the user
    if (err.message && (err.message.includes('UNIQUE constraint failed') || err.message.includes('SQLITE_CONSTRAINT'))) {
      const concurrentUser = await db.prepare(
        'SELECT * FROM users WHERE clerk_user_id = ? OR email = ?'
      ).bind(clerkUserId || '', email || '').first();

      if (concurrentUser) {
        const concurrentProfile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(concurrentUser.id).first();
        return {
          user: concurrentUser,
          profile: concurrentProfile || null,
          isNew: false,
          linked: false
        };
      }
    }
    throw err;
  }
}

/**
 * Get User by internal ID with Profile
 */
export async function getUserById(id, envOrDb) {
  if (!id) return null;
  const db = getD1OrSqlite(envOrDb);
  const user = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
  if (!user) return null;

  const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
  return {
    ...user,
    profile: profile || null
  };
}

/**
 * Get User by Clerk User ID with Profile
 */
export async function getUserByClerkId(clerkUserId, envOrDb) {
  if (!clerkUserId) return null;
  const db = getD1OrSqlite(envOrDb);
  const user = await db.prepare('SELECT * FROM users WHERE clerk_user_id = ?').bind(clerkUserId).first();
  if (!user) return null;

  const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
  return {
    ...user,
    profile: profile || null
  };
}

/**
 * Get User by Email with Profile
 */
export async function getUserByEmail(email, envOrDb) {
  if (!email) return null;
  const cleanEmail = String(email).trim().toLowerCase();
  const db = getD1OrSqlite(envOrDb);
  const user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(cleanEmail).first();
  if (!user) return null;

  const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
  return {
    ...user,
    profile: profile || null
  };
}

/**
 * Get Paginated List of Users
 */
export async function getUsers(query = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const page = Math.max(Number(query.page) || 1, 1);
  const pageSize = Math.min(Math.max(Number(query.pageSize || query.limit) || 20, 1), 100);
  const offset = query.offset !== undefined ? Math.max(Number(query.offset) || 0, 0) : (page - 1) * pageSize;

  let whereClauses = [];
  let params = [];

  if (query.role && query.role !== 'ALL') {
    whereClauses.push('role = ?');
    params.push(query.role);
  }

  if (query.status && query.status !== 'ALL') {
    whereClauses.push('status = ?');
    params.push(query.status);
  }

  if (query.search) {
    whereClauses.push('(full_name LIKE ? OR email LIKE ?)');
    params.push(`%${query.search}%`, `%${query.search}%`);
  }

  const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
  
  const countRow = await db.prepare(`SELECT COUNT(*) as total FROM users ${whereSql}`).bind(...params).first();
  const total = countRow?.total || 0;

  const rows = await db.prepare(`
    SELECT id, clerk_user_id, full_name, email, email_verified, image, role, status, createdAt, updatedAt
    FROM users 
    ${whereSql}
    ORDER BY createdAt DESC 
    LIMIT ? OFFSET ?
  `).bind(...params, pageSize, offset).all();

  const users = rows?.results || [];

  return {
    items: users,
    pagination: {
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    }
  };
}

/**
 * Update User Profile
 */
export async function updateUserProfile(id, data = {}, actor = {}, envOrDb) {
  if (!id) throw new Error('User ID is required');
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  const user = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
  if (!user) {
    const err = new Error('Không tìm thấy người dùng');
    err.statusCode = 404;
    throw err;
  }

  if (data.fullName || data.name || data.image || data.avatarUrl) {
    const newName = data.fullName || data.name || user.full_name;
    const newImage = data.image || (data.avatarUrl !== undefined ? data.avatarUrl : user.image);
    await db.prepare('UPDATE users SET full_name = ?, image = ?, updatedAt = ? WHERE id = ?')
      .bind(newName, newImage, now, id).run();
  }

  // Profile upsert
  const existingProfile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(id).first();
  if (existingProfile) {
    await db.prepare(`
      UPDATE profiles 
      SET fullName = COALESCE(?, fullName),
          phoneNumber = COALESCE(?, phoneNumber),
          avatarUrl = COALESCE(?, avatarUrl),
          department = COALESCE(?, department),
          updatedAt = ?
      WHERE userId = ?
    `).bind(
      data.fullName || data.name || null,
      data.phoneNumber !== undefined ? data.phoneNumber : null,
      data.avatarUrl || data.image || null,
      data.department !== undefined ? data.department : null,
      now,
      id
    ).run();
  } else {
    const profId = `prof_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    await db.prepare(`
      INSERT INTO profiles (id, userId, fullName, phoneNumber, avatarUrl, department, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      profId,
      id,
      data.fullName || data.name || user.full_name,
      data.phoneNumber || null,
      data.avatarUrl || data.image || user.image,
      data.department || null,
      now,
      now
    ).run();
  }

  const updatedUser = await getUserById(id, envOrDb);

  await createAuditLog({
    action: 'USER_PROFILE_UPDATED',
    entityType: 'USER',
    entityId: id,
    actorId: actor.id || id,
    actorName: actor.name || updatedUser.full_name,
    actorRole: actor.role || updatedUser.role,
    afterJson: updatedUser
  }, envOrDb).catch(() => null);

  return updatedUser;
}

/**
 * Update User Domain Role
 */
export async function updateUserRole(id, role, actor = {}, envOrDb) {
  if (!id) throw new Error('User ID is required');
  if (!isValidRole(role)) throw new Error(`Invalid role: ${role}`);

  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare('UPDATE users SET role = ?, updatedAt = ? WHERE id = ?').bind(role, now, id).run();
  const updatedUser = await getUserById(id, envOrDb);

  await createAuditLog({
    action: 'USER_ROLE_CHANGED',
    entityType: 'USER',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    afterJson: { id, role }
  }, envOrDb).catch(() => null);

  return updatedUser;
}

/**
 * Update User Status (ACTIVE, INACTIVE, DISABLED)
 */
export async function updateUserStatus(id, status, actor = {}, envOrDb) {
  if (!id) throw new Error('User ID is required');
  const validStatuses = ['ACTIVE', 'INACTIVE', 'DISABLED'];
  if (!status || !validStatuses.includes(status)) {
    throw new Error(`Invalid status: ${status}. Must be one of: ${validStatuses.join(', ')}`);
  }

  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare('UPDATE users SET status = ?, updatedAt = ? WHERE id = ?').bind(status, now, id).run();
  const updatedUser = await getUserById(id, envOrDb);

  await createAuditLog({
    action: 'USER_STATUS_CHANGED',
    entityType: 'USER',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    afterJson: { id, status }
  }, envOrDb).catch(() => null);

  return updatedUser;
}

/**
 * Create / Provision a new user manually
 */
export async function createUser(data = {}, actor = {}, envOrDb) {
  const result = await provisionClerkUser({
    email: data.email,
    fullName: data.fullName || data.name,
    role: data.role || ROLES.STAFF,
    phoneNumber: data.phoneNumber || data.profile?.phoneNumber,
    department: data.department || data.profile?.department,
    status: data.status || 'ACTIVE'
  }, envOrDb);

  if (actor.id) {
    await createAuditLog({
      action: 'USER_CREATED_BY_ADMIN',
      entityType: 'USER',
      entityId: result.user.id,
      actorId: actor.id,
      actorName: actor.name,
      actorRole: actor.role || 'admin',
      afterJson: { id: result.user.id, email: data.email, role: data.role }
    }, envOrDb).catch(() => null);
  }

  return result.user;
}

/**
 * Disable User
 */
export async function disableUser(id, actor = {}, envOrDb) {
  if (!id) throw new Error('User ID is required');
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare("UPDATE users SET status = 'DISABLED', updatedAt = ? WHERE id = ?").bind(now, id).run();
  const updatedUser = await getUserById(id, envOrDb);

  await createAuditLog({
    action: 'USER_DISABLED',
    entityType: 'USER',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    afterJson: { id, status: 'DISABLED' }
  }, envOrDb).catch(() => null);

  return updatedUser;
}

/**
 * Link Clerk Account to existing user
 */
export async function linkClerkAccount(userId, clerkUserId, envOrDb) {
  if (!userId || !clerkUserId) throw new Error('userId and clerkUserId are required');
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare('UPDATE users SET clerk_user_id = ?, updatedAt = ? WHERE id = ?').bind(clerkUserId, now, userId).run();
  return getUserById(userId, envOrDb);
}

