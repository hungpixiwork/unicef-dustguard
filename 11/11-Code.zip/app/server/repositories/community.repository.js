import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';

export async function getCommunities(query = {}, envOrDb) {
  let filter = query;
  let dbEnv = envOrDb;
  if (query && (query.DB || query.prepare || query.$queryRaw)) {
    dbEnv = query;
    filter = {};
  }
  const db = getD1OrSqlite(dbEnv);
  const safePage = Math.max(Number(filter.page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(filter.pageSize || filter.limit) || 20, 1), 100);
  const offset = filter.offset !== undefined ? Math.max(Number(filter.offset) || 0, 0) : (safePage - 1) * safePageSize;

  const res = await db.prepare('SELECT * FROM communities ORDER BY member_count DESC LIMIT ? OFFSET ?').bind(safePageSize, offset).all();
  if (res?.results && res.results.length > 0) return res.results;

  // Canonical Seed communities if table empty

  return [
    {
      id: 'comm_green_uit',
      name: 'CLB Môi Trường Xanh - ĐH Bách Khoa & UIT',
      type: 'UNIVERSITY_CLUB',
      ward: 'Phường Dĩ An',
      city: 'Bình Dương',
      description: 'Đội thanh niên xung kích giám sát bụi mịn và bảo vệ chất lượng không khí học đường.',
      member_count: 42
    },
    {
      id: 'comm_youth_caugiay',
      name: 'Đoàn Thanh niên Phường Dịch Vọng Hậu',
      type: 'YOUTH_UNION',
      ward: 'Phường Dịch Vọng Hậu',
      city: 'Hà Nội',
      description: 'Mạng lưới thanh niên tình nguyện giám sát điểm nóng ô nhiễm và đốt rơm rạ đô thị.',
      member_count: 35
    },
    {
      id: 'comm_green_volunteer',
      name: 'Mạng lưới Thanh niên Hành động vì Khí hậu (YCAN VN)',
      type: 'NGO_VOLUNTEER',
      ward: 'Toàn quốc',
      city: 'Việt Nam',
      description: 'Cộng đồng trẻ thu thập bằng chứng môi trường có cấu trúc và thúc đẩy giải trình.',
      member_count: 128
    }
  ];
}

export async function createCommunity(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `comm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  await db.prepare(`
    INSERT INTO communities (id, name, type, ward, city, avatar_url, description, member_count, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    data.name,
    data.type || 'UNIVERSITY_CLUB',
    data.ward || 'Phường Dĩ An',
    data.city || 'Hà Nội',
    data.avatarUrl || null,
    data.description || '',
    data.memberCount || 1,
    now,
    now
  ).run();

  await createAuditLog({
    action: 'COMMUNITY_CREATED',
    entityType: 'COMMUNITY',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'coordinator',
    afterJson: { id, ...data }
  }, envOrDb);

  return db.prepare('SELECT * FROM communities WHERE id = ?').bind(id).first();
}
