import { prisma, getDbClient, getD1OrSqlite } from '../shared/db.js';

/**
 * Append-only Audit Log Repository
 * Strict SSoT rule: Audit logs cannot be mutated or deleted via standard CRUD operations.
 */
export async function createAuditLog(data, envOrDb) {
  const client = (envOrDb && envOrDb.auditLog) ? envOrDb : getDbClient(envOrDb);
  
  const detailsObj = typeof data.details === 'object' ? { ...data.details } : (data.details ? { info: data.details } : {});
  if (data.beforeJson) detailsObj.before = data.beforeJson;
  if (data.afterJson) detailsObj.after = data.afterJson;
  if (data.metadataJson) detailsObj.metadata = data.metadataJson;
  if (data.entityType) detailsObj.entityType = data.entityType;
  if (data.entityId) detailsObj.entityId = data.entityId;
  if (data.requestId) detailsObj.requestId = data.requestId;

  const payload = {
    id: data.id || `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId: data.userId || data.actorId || null,
    actorId: data.actorId || data.userId || null,
    actorName: data.actorName || null,
    actorRole: data.actorRole || 'staff',
    targetId: data.targetId || data.entityId || null,
    action: data.action,
    details: JSON.stringify(detailsObj),
    ipAddress: data.ipAddress || null,
    createdAt: data.createdAt ? new Date(data.createdAt) : new Date()
  };

  if (envOrDb && (envOrDb.prepare || (envOrDb.DB && envOrDb.DB.prepare)) && !envOrDb.auditLog) {
    try {
      const db = getD1OrSqlite(envOrDb);
      await db.prepare(`
        INSERT INTO audit_logs (id, userId, actor_id, actor_name, actor_role, targetId, action, details, ipAddress, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        payload.id, payload.userId, payload.actorId, payload.actorName, payload.actorRole, payload.targetId, payload.action, payload.details, payload.ipAddress, payload.createdAt.toISOString()
      ).run();
    } catch {}
    return payload;
  }

  try {
    return await client.auditLog.create({ data: payload });
  } catch (err) {
    try {
      const db = getD1OrSqlite(envOrDb);
      await db.prepare(`
        INSERT INTO audit_logs (id, userId, actor_id, actor_name, actor_role, targetId, action, details, ipAddress, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        payload.id, payload.userId, payload.actorId, payload.actorName, payload.actorRole, payload.targetId, payload.action, payload.details, payload.ipAddress, payload.createdAt.toISOString()
      ).run();
    } catch {}
    return payload;
  }
}

export async function getAuditLogs(filter = {}, envOrDb) {
  const client = (envOrDb && envOrDb.auditLog) ? envOrDb : getDbClient(envOrDb);
  const {
    entityType,
    entityId,
    actorId,
    action,
    page = 1,
    pageSize = 50
  } = filter;

  const safePage = Math.max(Number(page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(pageSize) || 50, 1), 100);

  const where = {};
  if (actorId) where.actorId = actorId;
  if (action) where.action = action;
  if (entityId) {
    where.OR = [
      { targetId: entityId },
      { details: { contains: entityId } }
    ];
  }

  const [total, items] = await Promise.all([
    client.auditLog.count({ where }),
    client.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (safePage - 1) * safePageSize,
      take: safePageSize
    })
  ]);

  const parsedItems = items.map(item => {
    let details = {};
    try {
      details = typeof item.details === 'string' ? JSON.parse(item.details) : (item.details || {});
    } catch {
      details = { raw: item.details };
    }
    return {
      ...item,
      entityType: details.entityType || null,
      entityId: details.entityId || item.targetId || null,
      beforeJson: details.before || null,
      afterJson: details.after || null,
      metadataJson: details.metadata || null,
      requestId: details.requestId || null
    };
  });

  const filteredItems = (entityType || entityId)
    ? parsedItems.filter(item => (!entityType || item.entityType === entityType) && (!entityId || item.entityId === entityId))
    : parsedItems;

  return {
    items: filteredItems,
    pagination: {
      page: safePage,
      pageSize: safePageSize,
      limit: safePageSize,
      offset: (safePage - 1) * safePageSize,
      total,
      totalPages: Math.ceil(total / safePageSize)
    }
  };
}

