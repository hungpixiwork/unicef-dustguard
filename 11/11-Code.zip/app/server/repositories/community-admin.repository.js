// app/server/repositories/community-admin.repository.js
// Cloudflare D1 & SQLite Repository for Community & Campaign Backoffice Management
// Zero-Mock, Real DB Queries, Dynamic Aggregates & Audit Logging

import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';

// Canonical seed data for fallback / initial population
const SEED_CLUBS = [
  {
    id: 'club_hust_01',
    code: 'CLUB-HUST',
    name: 'Đội Sinh viên Tình nguyện Xung kích HUST',
    slug: 'clb-tinh-nguyen-hust',
    organization_type: 'UNIVERSITY',
    school: 'Đại học Bách Khoa Hà Nội',
    province: 'Hà Nội',
    district: 'Hai Bà Trưng',
    ward: 'Phường Bách Khoa',
    description: 'Tiên phong khảo sát bán kính 300m quanh các trường học, đo kiểm bụi mịn và ghi nhận hiện trường.',
    logo_url: '',
    contact_name: 'Trần Minh Đức',
    contact_email: 'duc.tm@hust.edu.vn',
    contact_phone: '0912345678',
    status: 'ACTIVE',
    visibility: 'PUBLIC',
    motto: 'Tiên phong công nghệ & dữ liệu vì không khí sạch trường học',
    badge_title: 'Lá chắn Xanh Xuất sắc',
    volunteer_hours: 342.5,
    resolved_hotspots: 128,
    member_count: 86
  },
  {
    id: 'club_uit_02',
    code: 'CLUB-UIT',
    name: 'CLB Môi Trường Xanh - ĐH Bách Khoa & UIT',
    slug: 'clb-moi-truong-xanh-uit',
    organization_type: 'UNIVERSITY',
    school: 'ĐHQG TP.HCM & UIT',
    province: 'Bình Dương',
    district: 'Dĩ An',
    ward: 'Phường Dĩ An',
    description: 'Tuần tra giám sát bụi công trường và che chắn vật liệu khu vực Làng Đại học.',
    logo_url: '',
    contact_name: 'Nguyễn Lê Hoàng',
    contact_email: 'hoang.nl@uit.edu.vn',
    contact_phone: '0987654321',
    status: 'ACTIVE',
    visibility: 'PUBLIC',
    motto: 'Bảo vệ bán kính 300m quanh các trường học trọng điểm',
    badge_title: 'Tuần tra Khí hậu 24/7',
    volunteer_hours: 298.0,
    resolved_hotspots: 110,
    member_count: 72
  },
  {
    id: 'club_neu_03',
    code: 'CLUB-NEU',
    name: 'Đội Tình nguyện Xanh Kinh tế NEU',
    slug: 'doi-tinh-nguyen-neu',
    organization_type: 'UNIVERSITY',
    school: 'Đại học Kinh tế Quốc dân',
    province: 'Hà Nội',
    district: 'Hai Bà Trưng',
    ward: 'Phường Đồng Tâm',
    description: 'Khảo sát giao thông và bụi mịn cổng trường giờ cao điểm.',
    logo_url: '',
    contact_name: 'Phạm Thu Trang',
    contact_email: 'trang.pt@neu.edu.vn',
    contact_phone: '0903123456',
    status: 'ACTIVE',
    visibility: 'PUBLIC',
    motto: 'Kết nối truyền thông & vận động giải trình công trường',
    badge_title: 'Hành động Bền vững',
    volunteer_hours: 256.5,
    resolved_hotspots: 94,
    member_count: 65
  }
];

const SEED_CAMPAIGNS = [
  {
    id: 'camp_school_2026',
    code: 'CAMP-SCHOOL-2026',
    title: 'Chiến dịch Lá chắn Bụi Trường học Tháng 9',
    slug: 'la-chan-bui-truong-hoc-thang-9',
    short_description: 'Giám sát che chắn thi công trong bán kính 300m quanh các trường học trọng điểm.',
    description: 'Giám sát và kiểm tra che chắn thi công tại các công trường trong bán kính 300m quanh trường mầm non & tiểu học.',
    campaign_type: 'SCHOOL_ZONE',
    topic: 'SCHOOL_ZONE_DUST',
    location: 'Phường Dĩ An, Bình Dương',
    ward: 'Phường Dĩ An',
    district: 'Dĩ An',
    province: 'Bình Dương',
    start_at: '2026-08-01T00:00:00.000Z',
    end_at: '2026-09-30T23:59:59.000Z',
    status: 'OPEN',
    visibility: 'PUBLIC',
    organizer: 'CLB Môi Trường Xanh UIT & ĐH Bách Khoa',
    max_participants: 100,
    goals: 'Khảo sát 100% công trường có lưới chắn bụi ≥ 3m & rửa xe ra vào',
    safety_criteria: '100% công trường có lưới chắn bụi ≥ 3m & rửa xe ra vào',
    schools_list: JSON.stringify(['Mầm non Hoa Sen', 'Tiểu học Dĩ An', 'THCS Võ Trường Toản', 'Trường Tiểu học Đoàn Thị Điểm'])
  },
  {
    id: 'camp_smoke_2026',
    code: 'CAMP-SMOKE-2026',
    title: 'Giám sát Điểm nóng Đốt rác & Khói bụi Ngoại thành',
    slug: 'giam-sat-diem-nong-dot-rac-khoi-bui',
    short_description: 'Đội tuần tra phát hiện điểm đốt rác và khói bụi tự phát, gửi khuyến nghị dập lửa.',
    description: 'Đội tình nguyện tuần tra phát hiện điểm đốt rơm rạ tự phát, tạo bản đồ nhiệt và gửi khuyến nghị dập lửa bảo vệ khu dân cư.',
    campaign_type: 'HOTSPOT_PATROL',
    topic: 'OPEN_BURNING_WATCH',
    location: 'Huyện Đông Anh & Cầu Giấy, Hà Nội',
    ward: 'Huyện Đông Anh',
    district: 'Đông Anh',
    province: 'Hà Nội',
    start_at: '2026-08-15T00:00:00.000Z',
    end_at: '2026-10-15T23:59:59.000Z',
    status: 'OPEN',
    visibility: 'PUBLIC',
    organizer: 'Đoàn Thanh niên Phường Dịch Vọng Hậu',
    max_participants: 50,
    goals: 'Phát hiện sớm và phối hợp dập tắt điểm cháy trong 60 phút',
    safety_criteria: 'Phát hiện sớm và phối hợp dập tắt điểm cháy trong 60 phút',
    schools_list: JSON.stringify(['Tiểu học Cầu Giấy', 'Trường Mầm non Ánh Sao', 'Tiểu học Kim Chung'])
  },
  {
    id: 'camp_youth_month_2026',
    code: 'CAMP-YOUTH-2026',
    title: 'Tháng Thanh niên Giám sát Khí hậu & Bụi mịn Đô thị',
    slug: 'thang-thanh-nien-giam-sat-khi-hau',
    short_description: 'Chiến dịch liên trường kết nối 5 trường Đại học tham gia 20 giờ tình nguyện.',
    description: 'Chiến dịch liên trường kết nối 5 trường Đại học, huy động sinh viên tham gia 20 giờ giám sát thực địa và tổng hợp hồ sơ minh chứng.',
    campaign_type: 'YOUTH_ACTION',
    topic: 'GREEN_YOUTH_MONTH',
    location: 'Hà Nội & TP. Hồ Chí Minh',
    ward: 'Hà Nội',
    district: 'Cầu Giấy',
    province: 'Hà Nội',
    start_at: '2026-08-01T00:00:00.000Z',
    end_at: '2026-11-30T23:59:59.000Z',
    status: 'OPEN',
    visibility: 'PUBLIC',
    organizer: 'Mạng lưới YCAN VN & Đoàn Khối Đại học',
    max_participants: 200,
    goals: 'Ghi nhận 20h tình nguyện giám sát thực địa có minh chứng xác thực',
    safety_criteria: 'Ghi nhận 20h tình nguyện giám sát thực địa có minh chứng xác thực',
    schools_list: JSON.stringify(['ĐH Bách Khoa Hà Nội', 'ĐH Quốc Gia', 'ĐH Kinh Tế Quốc Dân', 'ĐH Ngoại Thương'])
  }
];

const SEED_PARTICIPANTS = [
  { id: 'part_01', campaign_id: 'camp_school_2026', user_id: 'user_01', full_name: 'Nguyễn Văn An', email: 'an.nv@gmail.com', phone: '0987654321', organization: 'ĐH Bách Khoa', status: 'APPROVED' },
  { id: 'part_02', campaign_id: 'camp_school_2026', user_id: 'user_02', full_name: 'Lê Thị Mai', email: 'mai.lt@gmail.com', phone: '0912345678', organization: 'ĐH Bách Khoa', status: 'APPROVED' },
  { id: 'part_03', campaign_id: 'camp_smoke_2026', user_id: 'user_03', full_name: 'Trần Văn Bình', email: 'binh.tv@gmail.com', phone: '0934567890', organization: 'Đoàn Phường', status: 'APPROVED' },
  { id: 'part_04', campaign_id: 'camp_youth_month_2026', user_id: 'user_04', full_name: 'Hoàng Minh Tuấn', email: 'tuan.hm@gmail.com', phone: '0945678901', organization: 'NEU', status: 'APPROVED' }
];

export async function ensureCommunityDataSeeded(envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  // Seed Clubs
  for (const club of SEED_CLUBS) {
    try {
      await db.prepare(`
        INSERT OR IGNORE INTO communities (
          id, code, name, slug, organization_type, school, province, district, ward,
          description, logo_url, contact_name, contact_email, contact_phone,
          status, visibility, motto, badge_title, volunteer_hours, resolved_hotspots,
          member_count, verified, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        club.id, club.code, club.name, club.slug, club.organization_type, club.school,
        club.province, club.district, club.ward, club.description, club.logo_url,
        club.contact_name, club.contact_email, club.contact_phone, club.status,
        club.visibility, club.motto, club.badge_title, club.volunteer_hours,
        club.resolved_hotspots, club.member_count, 1, now, now
      ).run();
    } catch {}
  }

  // Seed Campaigns
  for (const camp of SEED_CAMPAIGNS) {
    try {
      await db.prepare(`
        INSERT OR IGNORE INTO campaigns (
          id, code, title, slug, short_description, description, campaign_type, topic,
          location, ward, district, province, start_at, end_at, participation_start_at, participation_end_at,
          status, visibility, cover_image, coverUrl, organizer, max_participants, goals,
          safety_criteria, schools_list, created_by, updated_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        camp.id, camp.code, camp.title, camp.slug, camp.short_description, camp.description,
        camp.campaign_type, camp.topic, camp.location, camp.ward, camp.district, camp.province,
        camp.start_at, camp.end_at, null, null,
        camp.status, camp.visibility, '', '', camp.organizer,
        camp.max_participants, camp.goals, camp.safety_criteria, camp.schools_list,
        'system_seed', 'system_seed', now, now
      ).run();
    } catch {}
  }

  // Seed Participants
  for (const p of SEED_PARTICIPANTS) {
    try {
      await db.prepare(`
        INSERT OR IGNORE INTO campaign_participants (
          id, campaign_id, user_id, full_name, email, phone, organization, status, joined_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(p.id, p.campaign_id, p.user_id, p.full_name, p.email, p.phone, p.organization, p.status, now).run();
    } catch {}
  }
}

// =========================================================================
// 1. PUBLIC DISCOVERY QUERIES (Pure DB Aggregates, Zero Hardcode)
// =========================================================================

export async function getPublicDiscoverData(envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  // 1. Query real open/active public campaigns
  const campRes = await db.prepare(`
    SELECT * FROM campaigns 
    WHERE status IN ('OPEN', 'ACTIVE') 
      AND visibility = 'PUBLIC' 
      AND (deleted_at IS NULL)
    ORDER BY created_at DESC
  `).all();
  const rawCampaigns = campRes?.results || [];

  // Enrich each campaign with real counts from participants & observations
  const enrichedCampaigns = await Promise.all(
    rawCampaigns.map(async (c) => {
      const partCountRes = await db.prepare(`
        SELECT count(*) as total FROM campaign_participants 
        WHERE campaign_id = ? AND status IN ('APPROVED', 'ACTIVE', 'COMPLETED')
      `).bind(c.id).first().catch(() => ({ total: 0 }));

      const obsCountRes = await db.prepare(`
        SELECT count(*) as total FROM observations 
        WHERE campaign_id = ? AND (status != 'DELETED' OR status IS NULL)
      `).bind(c.id).first().catch(() => ({ total: 0 }));

      let parsedSchools = [];
      try {
        parsedSchools = c.schools_list ? JSON.parse(c.schools_list) : [];
      } catch {
        parsedSchools = [];
      }

      return {
        ...c,
        participant_count: Number(partCountRes?.total || 0),
        observation_count: Number(obsCountRes?.total || 0),
        schoolsList: parsedSchools,
        schoolsCount: parsedSchools.length
      };
    })
  );

  // 2. Query active public clubs
  const clubRes = await db.prepare(`
    SELECT * FROM communities 
    WHERE status = 'ACTIVE' 
      AND visibility = 'PUBLIC' 
      AND (deleted_at IS NULL)
    ORDER BY volunteer_hours DESC, member_count DESC
  `).all();
  const rawClubs = clubRes?.results || [];

  // Enrich clubs with rank and real active campaigns count
  const enrichedClubs = await Promise.all(
    rawClubs.map(async (club, idx) => {
      const memberCountRes = await db.prepare(`
        SELECT count(*) as total FROM community_memberships 
        WHERE club_id = ? AND status = 'ACTIVE'
      `).bind(club.id).first().catch(() => ({ total: 0 }));

      return {
        ...club,
        rank: idx + 1,
        member_count: Math.max(Number(memberCountRes?.total || 0), Number(club.member_count || 0)),
        volunteer_hours: Number(club.volunteer_hours || 0),
        resolved_hotspots: Number(club.resolved_hotspots || 0)
      };
    })
  );

  // 3. Overall Stats Aggregated directly from database
  const totalOpenCampaigns = enrichedCampaigns.length;

  const totalParticipantsRes = await db.prepare(`
    SELECT count(DISTINCT coalesce(user_id, email, phone, id)) as total 
    FROM campaign_participants 
    WHERE status IN ('APPROVED', 'ACTIVE', 'COMPLETED')
  `).first().catch(() => ({ total: 0 }));

  const totalHotspotsRes = await db.prepare(`
    SELECT count(*) as total FROM observations 
    WHERE (status != 'DELETED' OR status IS NULL)
  `).first().catch(() => ({ total: 0 }));

  // Count unique schools across campaigns
  const uniqueSchools = new Set();
  enrichedCampaigns.forEach(c => {
    if (Array.isArray(c.schoolsList)) {
      c.schoolsList.forEach(s => uniqueSchools.add(s));
    }
  });
  const totalSchoolsGuarded = uniqueSchools.size || (enrichedClubs.length > 0 ? enrichedClubs.length : 0);

  return {
    stats: {
      openCampaigns: totalOpenCampaigns,
      schools: totalSchoolsGuarded,
      participants: Number(totalParticipantsRes?.total || 0),
      hotspots: Number(totalHotspotsRes?.total || 0),
      activeClubs: enrichedClubs.length
    },
    campaigns: enrichedCampaigns,
    clubs: enrichedClubs
  };
}

export async function getPublicCampaignDetail(slugOrId, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  const row = await db.prepare(`
    SELECT * FROM campaigns 
    WHERE (slug = ? OR id = ? OR code = ?) 
      AND (deleted_at IS NULL)
  `).bind(slugOrId, slugOrId, slugOrId).first();

  if (!row) return null;

  const partRes = await db.prepare(`
    SELECT * FROM campaign_participants 
    WHERE campaign_id = ? AND status IN ('APPROVED', 'ACTIVE', 'COMPLETED')
    ORDER BY joined_at DESC LIMIT 50
  `).bind(row.id).all();

  const obsRes = await db.prepare(`
    SELECT id, code, title, category, severity, status, address, ward, latitude, longitude, created_at 
    FROM observations 
    WHERE campaign_id = ?
    ORDER BY created_at DESC LIMIT 20
  `).bind(row.id).all();

  let schoolsList = [];
  try {
    schoolsList = row.schools_list ? JSON.parse(row.schools_list) : [];
  } catch {}

  return {
    ...row,
    schoolsList,
    participant_count: (partRes?.results || []).length,
    participants: partRes?.results || [],
    observations: obsRes?.results || []
  };
}

export async function getPublicClubDetail(slugOrId, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  const row = await db.prepare(`
    SELECT * FROM communities 
    WHERE (slug = ? OR id = ? OR code = ?) 
      AND (deleted_at IS NULL)
  `).bind(slugOrId, slugOrId, slugOrId).first();

  if (!row) return null;

  const membersRes = await db.prepare(`
    SELECT * FROM community_memberships 
    WHERE club_id = ? AND status = 'ACTIVE'
    ORDER BY joined_at DESC LIMIT 50
  `).bind(row.id).all();

  return {
    ...row,
    members: membersRes?.results || []
  };
}

// =========================================================================
// 2. ADMIN & BACKOFFICE DASHBOARD STATS
// =========================================================================

export async function getCommunityDashboardStats(envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  const openCampRes = await db.prepare(`
    SELECT count(*) as total FROM campaigns 
    WHERE status IN ('OPEN', 'ACTIVE') AND (deleted_at IS NULL)
  `).first().catch(() => ({ total: 0 }));

  const activeClubsRes = await db.prepare(`
    SELECT count(*) as total FROM communities 
    WHERE status = 'ACTIVE' AND (deleted_at IS NULL)
  `).first().catch(() => ({ total: 0 }));

  const totalParticipantsRes = await db.prepare(`
    SELECT count(*) as total FROM campaign_participants 
    WHERE status IN ('APPROVED', 'ACTIVE', 'COMPLETED')
  `).first().catch(() => ({ total: 0 }));

  const pendingParticipantsRes = await db.prepare(`
    SELECT count(*) as total FROM campaign_participants 
    WHERE status = 'PENDING'
  `).first().catch(() => ({ total: 0 }));

  const recentCampRes = await db.prepare(`
    SELECT * FROM campaigns 
    WHERE deleted_at IS NULL 
    ORDER BY created_at DESC LIMIT 5
  `).all();

  const recentClubsRes = await db.prepare(`
    SELECT * FROM communities 
    WHERE deleted_at IS NULL 
    ORDER BY created_at DESC LIMIT 5
  `).all();

  const pendingRequestsRes = await db.prepare(`
    SELECT cp.*, c.title as campaign_title 
    FROM campaign_participants cp
    LEFT JOIN campaigns c ON cp.campaign_id = c.id
    WHERE cp.status = 'PENDING'
    ORDER BY cp.joined_at DESC LIMIT 10
  `).all();

  return {
    metrics: {
      openCampaigns: Number(openCampRes?.total || 0),
      activeClubs: Number(activeClubsRes?.total || 0),
      totalParticipants: Number(totalParticipantsRes?.total || 0),
      pendingApplications: Number(pendingParticipantsRes?.total || 0)
    },
    recentCampaigns: recentCampRes?.results || [],
    recentClubs: recentClubsRes?.results || [],
    pendingRequests: pendingRequestsRes?.results || []
  };
}

// =========================================================================
// 3. CAMPAIGN FULL CRUD
// =========================================================================

export async function getAdminCampaigns(filter = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  let sql = 'SELECT * FROM campaigns WHERE (deleted_at IS NULL)';
  const params = [];

  if (filter.status && filter.status !== 'ALL') {
    sql += ' AND status = ?';
    params.push(filter.status);
  }
  if (filter.campaign_type && filter.campaign_type !== 'ALL') {
    sql += ' AND campaign_type = ?';
    params.push(filter.campaign_type);
  }
  if (filter.search) {
    sql += ' AND (title LIKE ? OR code LIKE ? OR organizer LIKE ?)';
    const searchWildcard = `%${filter.search}%`;
    params.push(searchWildcard, searchWildcard, searchWildcard);
  }

  sql += ' ORDER BY created_at DESC';

  const res = await db.prepare(sql).bind(...params).all();
  const rows = res?.results || [];

  // Calculate realtime participant count for each campaign
  const items = await Promise.all(
    rows.map(async (c) => {
      const partCountRes = await db.prepare(`
        SELECT count(*) as total FROM campaign_participants 
        WHERE campaign_id = ?
      `).bind(c.id).first().catch(() => ({ total: 0 }));

      return {
        ...c,
        participant_count: Number(partCountRes?.total || 0)
      };
    })
  );

  return items;
}

export async function getAdminCampaignById(id, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  const camp = await db.prepare('SELECT * FROM campaigns WHERE id = ?').bind(id).first();
  if (!camp) return null;

  const participantsRes = await db.prepare(`
    SELECT * FROM campaign_participants 
    WHERE campaign_id = ? 
    ORDER BY joined_at DESC
  `).bind(id).all();

  const clubsRes = await db.prepare(`
    SELECT c.*, cc.status as link_status, cc.joined_at as linked_at 
    FROM campaign_clubs cc
    JOIN communities c ON cc.club_id = c.id
    WHERE cc.campaign_id = ?
  `).bind(id).all();

  const obsRes = await db.prepare(`
    SELECT * FROM observations 
    WHERE campaign_id = ? 
    ORDER BY created_at DESC
  `).bind(id).all();

  const auditLogsRes = await db.prepare(`
    SELECT * FROM system_audit_logs 
    WHERE module = 'CAMPAIGN' AND target_id = ? 
    ORDER BY timestamp DESC
  `).bind(id).all().catch(() => ({ results: [] }));

  let schoolsList = [];
  try {
    schoolsList = camp.schools_list ? JSON.parse(camp.schools_list) : [];
  } catch {}

  return {
    ...camp,
    schoolsList,
    participants: participantsRes?.results || [],
    participant_count: (participantsRes?.results || []).length,
    clubs: clubsRes?.results || [],
    observations: obsRes?.results || [],
    auditLogs: auditLogsRes?.results || []
  };
}

export async function createAdminCampaign(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `camp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const code = data.code || `CAMP-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const now = new Date().toISOString();

  const title = (data.title || '').trim();
  if (!title) throw new Error('Tiêu đề chiến dịch là bắt buộc');

  const slug = data.slug || title.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

  let schoolsListStr = '[]';
  if (Array.isArray(data.schoolsList)) {
    schoolsListStr = JSON.stringify(data.schoolsList);
  } else if (typeof data.schools_list === 'string') {
    schoolsListStr = data.schools_list;
  }

  await db.prepare(`
    INSERT INTO campaigns (
      id, code, title, slug, short_description, description, campaign_type, topic,
      location, ward, district, province, start_at, end_at, participation_start_at, participation_end_at,
      status, visibility, cover_image, coverUrl, organizer, max_participants, goals,
      safety_criteria, schools_list, created_by, updated_by, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    code,
    title,
    slug,
    data.short_description || data.shortDescription || '',
    data.description || '',
    data.campaign_type || data.campaignType || 'SCHOOL_ZONE',
    data.topic || 'SCHOOL_ZONE_DUST',
    data.location || '',
    data.ward || '',
    data.district || '',
    data.province || 'Hà Nội',
    data.start_at || data.startDate || now,
    data.end_at || data.endDate || new Date(Date.now() + 30 * 86400000).toISOString(),
    data.participation_start_at || null,
    data.participation_end_at || null,
    data.status || 'OPEN',
    data.visibility || 'PUBLIC',
    data.cover_image || data.coverImage || data.coverUrl || '',
    data.coverUrl || data.cover_image || '',
    data.organizer || '',
    data.max_participants ? Number(data.max_participants) : null,
    data.goals || '',
    data.safety_criteria || data.safetyCriteria || '',
    schoolsListStr,
    actor.id || actor.email || 'admin',
    actor.id || actor.email || 'admin',
    now,
    now
  ).run();

  try {
    await createAuditLog({
      action: 'CREATE',
      module: 'CAMPAIGN',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      new_values: JSON.stringify({ id, code, title, status: data.status || 'OPEN' })
    }, envOrDb);
  } catch {}

  return getAdminCampaignById(id, envOrDb);
}

export async function updateAdminCampaign(id, data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  const existing = await db.prepare('SELECT * FROM campaigns WHERE id = ?').bind(id).first();
  if (!existing) throw new Error('Chiến dịch không tồn tại');

  let schoolsListStr = existing.schools_list;
  if (Array.isArray(data.schoolsList)) {
    schoolsListStr = JSON.stringify(data.schoolsList);
  } else if (typeof data.schools_list === 'string') {
    schoolsListStr = data.schools_list;
  }

  await db.prepare(`
    UPDATE campaigns SET
      title = coalesce(?, title),
      code = coalesce(?, code),
      slug = coalesce(?, slug),
      short_description = coalesce(?, short_description),
      description = coalesce(?, description),
      campaign_type = coalesce(?, campaign_type),
      topic = coalesce(?, topic),
      location = coalesce(?, location),
      ward = coalesce(?, ward),
      district = coalesce(?, district),
      province = coalesce(?, province),
      start_at = coalesce(?, start_at),
      end_at = coalesce(?, end_at),
      status = coalesce(?, status),
      visibility = coalesce(?, visibility),
      cover_image = coalesce(?, cover_image),
      coverUrl = coalesce(?, coverUrl),
      organizer = coalesce(?, organizer),
      max_participants = coalesce(?, max_participants),
      goals = coalesce(?, goals),
      safety_criteria = coalesce(?, safety_criteria),
      schools_list = coalesce(?, schools_list),
      updated_by = ?,
      updated_at = ?
    WHERE id = ?
  `).bind(
    data.title || null,
    data.code || null,
    data.slug || null,
    data.short_description || data.shortDescription || null,
    data.description || null,
    data.campaign_type || data.campaignType || null,
    data.topic || null,
    data.location || null,
    data.ward || null,
    data.district || null,
    data.province || null,
    data.start_at || data.startDate || null,
    data.end_at || data.endDate || null,
    data.status || null,
    data.visibility || null,
    data.cover_image || data.coverImage || data.coverUrl || null,
    data.coverUrl || data.cover_image || null,
    data.organizer || null,
    data.max_participants !== undefined ? Number(data.max_participants) : null,
    data.goals || null,
    data.safety_criteria || data.safetyCriteria || null,
    schoolsListStr,
    actor.id || actor.email || 'admin',
    now,
    id
  ).run();

  try {
    await createAuditLog({
      action: 'UPDATE',
      module: 'CAMPAIGN',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      old_values: JSON.stringify(existing),
      new_values: JSON.stringify(data)
    }, envOrDb);
  } catch {}

  return getAdminCampaignById(id, envOrDb);
}

export async function archiveAdminCampaign(id, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare(`
    UPDATE campaigns SET status = 'ARCHIVED', updated_at = ? WHERE id = ?
  `).bind(now, id).run();

  try {
    await createAuditLog({
      action: 'ARCHIVE',
      module: 'CAMPAIGN',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      new_values: JSON.stringify({ status: 'ARCHIVED' })
    }, envOrDb);
  } catch {}

  return { success: true, id, status: 'ARCHIVED' };
}

// =========================================================================
// 4. CLUB FULL CRUD
// =========================================================================

export async function getAdminClubs(filter = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  let sql = 'SELECT * FROM communities WHERE (deleted_at IS NULL)';
  const params = [];

  if (filter.status && filter.status !== 'ALL') {
    sql += ' AND status = ?';
    params.push(filter.status);
  }
  if (filter.organization_type && filter.organization_type !== 'ALL') {
    sql += ' AND organization_type = ?';
    params.push(filter.organization_type);
  }
  if (filter.search) {
    sql += ' AND (name LIKE ? OR code LIKE ? OR school LIKE ? OR contact_name LIKE ?)';
    const searchWildcard = `%${filter.search}%`;
    params.push(searchWildcard, searchWildcard, searchWildcard, searchWildcard);
  }

  sql += ' ORDER BY created_at DESC';

  const res = await db.prepare(sql).bind(...params).all();
  return res?.results || [];
}

export async function getAdminClubById(id, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  const club = await db.prepare('SELECT * FROM communities WHERE id = ?').bind(id).first();
  if (!club) return null;

  const membersRes = await db.prepare(`
    SELECT * FROM community_memberships 
    WHERE club_id = ? 
    ORDER BY joined_at DESC
  `).bind(id).all();

  const campaignsRes = await db.prepare(`
    SELECT c.*, cc.status as participation_status 
    FROM campaign_clubs cc
    JOIN campaigns c ON cc.campaign_id = c.id
    WHERE cc.club_id = ?
  `).bind(id).all();

  return {
    ...club,
    members: membersRes?.results || [],
    member_count: (membersRes?.results || []).length,
    campaigns: campaignsRes?.results || []
  };
}

export async function createAdminClub(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `club_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const code = data.code || `CLUB-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const now = new Date().toISOString();

  const name = (data.name || '').trim();
  if (!name) throw new Error('Tên câu lạc bộ là bắt buộc');

  const slug = data.slug || name.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

  await db.prepare(`
    INSERT INTO communities (
      id, code, name, slug, organization_type, school, province, district, ward,
      description, logo_url, avatarUrl, cover_url, coverUrl, contact_name, contact_email,
      contact_phone, status, visibility, motto, badge_title, created_by, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    code,
    name,
    slug,
    data.organization_type || data.organizationType || 'UNIVERSITY',
    data.school || '',
    data.province || 'Hà Nội',
    data.district || '',
    data.ward || '',
    data.description || '',
    data.logo_url || data.logoUrl || '',
    data.logo_url || data.avatarUrl || '',
    data.cover_url || data.coverUrl || '',
    data.cover_url || data.coverUrl || '',
    data.contact_name || data.contactName || '',
    data.contact_email || data.contactEmail || '',
    data.contact_phone || data.contactPhone || '',
    data.status || 'ACTIVE',
    data.visibility || 'PUBLIC',
    data.motto || '',
    data.badge_title || data.badgeTitle || '',
    actor.id || actor.email || 'admin',
    now,
    now
  ).run();

  try {
    await createAuditLog({
      action: 'CREATE',
      module: 'CLUB',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      new_values: JSON.stringify({ id, code, name })
    }, envOrDb);
  } catch {}

  return getAdminClubById(id, envOrDb);
}

export async function updateAdminClub(id, data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  const existing = await db.prepare('SELECT * FROM communities WHERE id = ?').bind(id).first();
  if (!existing) throw new Error('CLB không tồn tại');

  await db.prepare(`
    UPDATE communities SET
      name = coalesce(?, name),
      code = coalesce(?, code),
      slug = coalesce(?, slug),
      organization_type = coalesce(?, organization_type),
      school = coalesce(?, school),
      province = coalesce(?, province),
      district = coalesce(?, district),
      ward = coalesce(?, ward),
      description = coalesce(?, description),
      logo_url = coalesce(?, logo_url),
      avatarUrl = coalesce(?, avatarUrl),
      cover_url = coalesce(?, cover_url),
      coverUrl = coalesce(?, coverUrl),
      contact_name = coalesce(?, contact_name),
      contact_email = coalesce(?, contact_email),
      contact_phone = coalesce(?, contact_phone),
      status = coalesce(?, status),
      visibility = coalesce(?, visibility),
      motto = coalesce(?, motto),
      badge_title = coalesce(?, badge_title),
      updated_at = ?
    WHERE id = ?
  `).bind(
    data.name || null,
    data.code || null,
    data.slug || null,
    data.organization_type || data.organizationType || null,
    data.school || null,
    data.province || null,
    data.district || null,
    data.ward || null,
    data.description || null,
    data.logo_url || data.logoUrl || null,
    data.logo_url || data.avatarUrl || null,
    data.cover_url || data.coverUrl || null,
    data.cover_url || data.coverUrl || null,
    data.contact_name || data.contactName || null,
    data.contact_email || data.contactEmail || null,
    data.contact_phone || data.contactPhone || null,
    data.status || null,
    data.visibility || null,
    data.motto || null,
    data.badge_title || data.badgeTitle || null,
    now,
    id
  ).run();

  try {
    await createAuditLog({
      action: 'UPDATE',
      module: 'CLUB',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      old_values: JSON.stringify(existing),
      new_values: JSON.stringify(data)
    }, envOrDb);
  } catch {}

  return getAdminClubById(id, envOrDb);
}

// =========================================================================
// 5. PARTICIPANTS MANAGEMENT
// =========================================================================

export async function getCampaignParticipants(filter = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  let sql = `
    SELECT cp.*, c.title as campaign_title, c.code as campaign_code
    FROM campaign_participants cp
    LEFT JOIN campaigns c ON cp.campaign_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (filter.campaign_id && filter.campaign_id !== 'ALL') {
    sql += ' AND cp.campaign_id = ?';
    params.push(filter.campaign_id);
  }
  if (filter.status && filter.status !== 'ALL') {
    sql += ' AND cp.status = ?';
    params.push(filter.status);
  }
  if (filter.search) {
    sql += ' AND (cp.full_name LIKE ? OR cp.email LIKE ? OR cp.phone LIKE ? OR cp.organization LIKE ?)';
    const searchWildcard = `%${filter.search}%`;
    params.push(searchWildcard, searchWildcard, searchWildcard, searchWildcard);
  }

  sql += ' ORDER BY cp.joined_at DESC';

  const res = await db.prepare(sql).bind(...params).all();
  return res?.results || [];
}

export async function updateParticipantStatus(id, status, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  const approvedAt = status === 'APPROVED' ? now : null;
  const completedAt = status === 'COMPLETED' ? now : null;

  await db.prepare(`
    UPDATE campaign_participants SET
      status = ?,
      approved_at = coalesce(?, approved_at),
      completed_at = coalesce(?, completed_at),
      updated_at = ?
    WHERE id = ?
  `).bind(status, approvedAt, completedAt, now, id).run();

  try {
    await createAuditLog({
      action: 'STATUS_CHANGE',
      module: 'PARTICIPANT',
      target_id: id,
      user_email: actor.email || 'admin@dustguard.vn',
      user_role: actor.role || 'admin',
      new_values: JSON.stringify({ status })
    }, envOrDb);
  } catch {}

  return { success: true, id, status };
}

// =========================================================================
// 6. COMMUNITY MEMBERSHIPS
// =========================================================================

export async function getCommunityMembers(filter = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  await ensureCommunityDataSeeded(envOrDb);

  let sql = `
    SELECT cm.*, c.name as club_name, c.school as club_school
    FROM community_memberships cm
    LEFT JOIN communities c ON cm.club_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (filter.club_id && filter.club_id !== 'ALL') {
    sql += ' AND cm.club_id = ?';
    params.push(filter.club_id);
  }
  if (filter.status && filter.status !== 'ALL') {
    sql += ' AND cm.status = ?';
    params.push(filter.status);
  }

  sql += ' ORDER BY cm.joined_at DESC';

  const res = await db.prepare(sql).bind(...params).all();
  return res?.results || [];
}

export async function addCommunityMember(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = `mem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  await db.prepare(`
    INSERT INTO community_memberships (
      id, profile_id, user_id, club_id, membership_role, status, joined_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    data.profile_id || data.userId || null,
    data.user_id || data.userId || null,
    data.club_id || data.clubId,
    data.membership_role || data.role || 'MEMBER',
    data.status || 'ACTIVE',
    now,
    now,
    now
  ).run();

  return { success: true, id };
}
