import { prisma, getDbClient } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { createCaseStatusHistory } from './history.repository.js';

export async function createCase(data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  
  const caseCode = data.code || `CASE-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const existing = await client.case.findFirst({
    where: { code: caseCode }
  });
  if (existing) {
    return existing;
  }

  const caseRecord = await client.case.create({
    data: {
      code: caseCode,
      title: data.title || 'Hồ sơ giám sát bụi công trình',
      description: data.description || null,
      status: data.status || 'OPEN',
      sourceType: data.sourceType || 'COMPLAINT',
      sourceId: data.sourceId || null,
      slaDeadline: data.slaDeadline ? new Date(data.slaDeadline) : null,
      assignedTo: data.assignedTo || null,
      priority: data.priority || 'MEDIUM',
      siteId: data.siteId,
      complaintId: data.complaintId || null,
      inspectionId: data.inspectionId || null
    }
  });

  // 1. Initial Timeline Entry
  await client.caseTimeline.create({
    data: {
      caseId: caseRecord.id,
      eventTitle: 'Tiếp nhận hồ sơ vi phạm',
      eventDescription: data.description || 'Hồ sơ được khởi tạo từ nguồn phản ánh/cảm biến',
      eventType: 'CREATION',
      actorId: actor.id || null,
      actorName: actor.name || 'Hệ thống tự động',
      actorRole: actor.role || 'system'
    }
  });

  // 2. Initial Case Status History
  await createCaseStatusHistory({
    caseId: caseRecord.id,
    fromStatus: 'NONE',
    toStatus: caseRecord.status,
    changedBy: actor.id || null,
    actorName: actor.name || 'System',
    actorRole: actor.role || 'system',
    note: 'Khởi tạo hồ sơ'
  }, envOrDb);

  // 3. Immutable Audit Log
  await createAuditLog({
    action: 'CASE_CREATED',
    entityType: 'CASE',
    entityId: caseRecord.id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    afterJson: caseRecord
  }, envOrDb);

  return caseRecord;
}

export async function getCaseById(id, options = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const where = { id };
  if (!options.includeDeleted) {
    where.deletedAt = null;
  }
  return client.case.findFirst({
    where,
    include: {
      site: true,
      complaint: true,
      inspection: true,
      timeline: { orderBy: { createdAt: 'asc' } },
      statusHistories: { orderBy: { createdAt: 'asc' } },
      contractorExplanations: { orderBy: { createdAt: 'desc' } },
      sanctionDecisions: { orderBy: { createdAt: 'desc' } },
      actions: { where: options.includeDeleted ? {} : { deletedAt: null } },
      draftDocuments: { where: options.includeDeleted ? {} : { deletedAt: null } },
      evidences: { where: options.includeDeleted ? {} : { deletedAt: null } }
    }
  });
}

export async function getCases(query = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const {
    status,
    siteId,
    search,
    page = 1,
    pageSize = 20,
    includeDeleted = false
  } = query;

  const where = {};
  if (!includeDeleted) {
    where.deletedAt = null;
  }
  if (status && status !== 'ALL') {
    where.status = status;
  }
  if (siteId) {
    where.siteId = siteId;
  }
  if (search) {
    where.OR = [
      { code: { contains: search } },
      { title: { contains: search } },
      { description: { contains: search } }
    ];
  }

  const safePage = Math.max(Number(page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(pageSize) || 20, 1), 100);

  const [total, items] = await Promise.all([
    client.case.count({ where }),
    client.case.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (safePage - 1) * safePageSize,
      take: safePageSize,
      include: {
        site: { select: { id: true, name: true, code: true, ward: true, dustRiskScore: true } },
        complaint: { select: { id: true, code: true, reporterName: true } }
      }
    })
  ]);

  return {
    items,
    pagination: {
      page: safePage,
      pageSize: safePageSize,
      limit: safePageSize,
      offset: (safePage - 1) * safePageSize,
      total,
      totalPages: Math.ceil(total / safePageSize)
    }
  };

}

export async function updateCase(id, data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const current = await client.case.findUnique({ where: { id } });
  if (!current) return null;

  const updateData = {};
  const allowedFields = [
    'title', 'description', 'status', 'slaDeadline',
    'sourceType', 'sourceId', 'siteId', 'complaintId', 'inspectionId'
  ];
  for (const field of allowedFields) {
    if (data[field] !== undefined) {
      updateData[field] = data[field];
    }
  }

  const updated = await client.case.update({
    where: { id },
    data: updateData
  });

  // Track status change in CaseStatusHistory and CaseTimeline if status changed
  if (data.status && data.status !== current.status) {
    await createCaseStatusHistory({
      caseId: id,
      fromStatus: current.status,
      toStatus: data.status,
      changedBy: actor.id || null,
      actorName: actor.name || null,
      actorRole: actor.role || 'staff',
      note: data.note || `Chuyển trạng thái từ ${current.status} sang ${data.status}`
    }, envOrDb);

    await client.caseTimeline.create({
      data: {
        caseId: id,
        eventTitle: `Chuyển trạng thái: ${data.status}`,
        eventDescription: data.note || `Cán bộ ${actor.name || 'hệ thống'} chuyển trạng thái hồ sơ`,
        eventType: 'STATUS_CHANGED',
        actorId: actor.id || null,
        actorName: actor.name || null,
        actorRole: actor.role || 'staff'
      }
    });
  }

  await createAuditLog({
    action: 'CASE_UPDATED',
    entityType: 'CASE',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  return updated;
}

export async function softDeleteCase(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const current = await client.case.findUnique({ where: { id } });
  if (!current) return null;

  try {
    const updated = await client.case.update({
      where: { id },
      data: { deletedAt: new Date() }
    });

    await createAuditLog({
      action: 'CASE_DELETED',
      entityType: 'CASE',
      entityId: id,
      actorId: actor.id || null,
      actorName: actor.name || null,
      actorRole: actor.role || 'staff',
      beforeJson: current,
      afterJson: updated
    }, envOrDb);

    return updated;
  } catch (err) {
    if (err.code === 'P2025') return null;
    throw err;
  }
}

export async function restoreCase(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const current = await client.case.findUnique({ where: { id } });
  if (!current) return null;

  try {
    const updated = await client.case.update({
      where: { id },
      data: { deletedAt: null }
    });

    await createAuditLog({
      action: 'CASE_RESTORED',
      entityType: 'CASE',
      entityId: id,
      actorId: actor.id || null,
      actorName: actor.name || null,
      actorRole: actor.role || 'staff',
      beforeJson: current,
      afterJson: updated
    }, envOrDb);

    return updated;
  } catch (err) {
    if (err.code === 'P2025') return null;
    throw err;
  }
}

export async function hardDeleteCase(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.case) ? envOrDb : getDbClient(envOrDb);
  const current = await client.case.findUnique({ where: { id } });
  if (!current) return { success: true, id };

  await client.case.delete({ where: { id } }).catch(() => null);

  await createAuditLog({
    action: 'CASE_PERMANENTLY_DELETED',
    entityType: 'CASE',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    beforeJson: current
  }, envOrDb);

  return { success: true, id };
}

