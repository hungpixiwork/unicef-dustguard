import { getD1OrSqlite } from '../shared/db.js';
import {
  ENVIRONMENTAL_CATEGORIES_DETAIL,
  getEnvironmentalCategory,
  listEnvironmentalCategories
} from '../domain/categories/category.rules.js';

/**
 * Ensures initial environmental categories exist in D1/SQLite table.
 */
export async function syncEnvironmentalCategories(envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  for (const cat of Object.values(ENVIRONMENTAL_CATEGORIES_DETAIL)) {
    try {
      await db.prepare(`
        INSERT OR REPLACE INTO environmental_categories (
          id, code, name_vi, name_en, description, icon, default_severity,
          evidence_requirements, regulations, active, version,
          effective_from, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        cat.id,
        cat.code,
        cat.nameVi,
        cat.nameEn,
        cat.description,
        cat.icon,
        cat.defaultSeverity,
        JSON.stringify(cat.evidenceRequirements || []),
        JSON.stringify(cat.regulations || []),
        cat.active ? 1 : 0,
        cat.version || 1,
        cat.effectiveFrom || now,
        cat.effectiveFrom || now,
        now
      ).run();
    } catch {
      // Table might not exist in simple test scenarios
    }
  }
}

/**
 * Retrieves all environmental categories (from DB with domain fallback).
 */
export async function getCategories(includeInactive = false, envOrDb) {
  try {
    const db = getD1OrSqlite(envOrDb);
    const sql = includeInactive
      ? 'SELECT * FROM environmental_categories ORDER BY code ASC'
      : 'SELECT * FROM environmental_categories WHERE active = 1 ORDER BY code ASC';
    const rows = await db.prepare(sql).all();
    if (rows && rows.results && rows.results.length > 0) {
      return rows.results.map(row => ({
        id: row.id,
        code: row.code,
        nameVi: row.name_vi,
        nameEn: row.name_en,
        description: row.description,
        icon: row.icon,
        defaultSeverity: row.default_severity,
        defaultPriority: row.default_severity,
        standardRef: row.regulations ? JSON.parse(row.regulations)[0]?.code || '' : '',
        evidenceRequirements: row.evidence_requirements ? JSON.parse(row.evidence_requirements) : [],
        regulations: row.regulations ? JSON.parse(row.regulations) : [],
        active: Boolean(row.active),
        version: row.version,
        effectiveFrom: row.effective_from,
        effectiveTo: row.effective_to
      }));
    }
  } catch {
    // Fallback to domain SSOT
  }

  return listEnvironmentalCategories(includeInactive);
}

/**
 * Retrieves a single environmental category by ID or Code.
 */
export async function getCategoryById(idOrCode, envOrDb) {
  if (!idOrCode) return null;

  try {
    const db = getD1OrSqlite(envOrDb);
    const row = await db.prepare('SELECT * FROM environmental_categories WHERE id = ? OR code = ?')
      .bind(idOrCode, idOrCode).first();
    if (row) {
      return {
        id: row.id,
        code: row.code,
        nameVi: row.name_vi,
        nameEn: row.name_en,
        description: row.description,
        icon: row.icon,
        defaultSeverity: row.default_severity,
        defaultPriority: row.default_severity,
        standardRef: row.regulations ? JSON.parse(row.regulations)[0]?.code || '' : '',
        evidenceRequirements: row.evidence_requirements ? JSON.parse(row.evidence_requirements) : [],
        regulations: row.regulations ? JSON.parse(row.regulations) : [],
        active: Boolean(row.active),
        version: row.version,
        effectiveFrom: row.effective_from,
        effectiveTo: row.effective_to
      };
    }
  } catch {
    // Fallback to domain SSOT
  }

  return getEnvironmentalCategory(idOrCode);
}
