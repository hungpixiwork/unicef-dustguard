import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { recordImpactEvent } from './impact.repository.js';
import { getCategoryById } from './category.repository.js';
import { assertObservationTransition } from '../domain/observations/observation.rules.js';
import { canonicalHash } from '../shared/canonical-json.js';
import { parseCoordinates, normalizeEntityCoordinates } from '../domain/spatial/spatial-adapter.js';

function generateRandomHex(len = 4) {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const bytes = new Uint8Array(Math.ceil(len / 2));
    crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('').substring(0, len).toUpperCase();
  }
  return Date.now().toString(16).slice(-len).toUpperCase();
}

/**
 * Generates a collision-resistant unique public code (e.g. OBS-2026-XXXX).
 */
export async function generateUniqueObservationCode(year = new Date().getFullYear(), envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  for (let attempt = 0; attempt < 10; attempt++) {
    const code = `OBS-${year}-${generateRandomHex(4)}`;
    try {
      const existing = await db.prepare('SELECT id FROM observations WHERE code = ?').bind(code).first();
      if (!existing) return code;
    } catch {
      return code;
    }
  }
  return `OBS-${year}-${Date.now().toString(36).toUpperCase().slice(-5)}`;
}

/**
 * Creates a new Environmental Observation and records evidence & impact.
 */
export async function createObservation(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const code = data.code || await generateUniqueObservationCode(new Date().getFullYear(), envOrDb);
  const id = data.id || `obs_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const observedAt = data.observedAt || now;
  const categoryKey = data.category || data.categoryId || 'CONSTRUCTION_DUST';
  const initialStatus = data.status || 'RECORDED';

  const parsedCoords = parseCoordinates(
    data.coordinates || (data.latitude !== undefined && data.longitude !== undefined ? { latitude: data.latitude, longitude: data.longitude } : data),
    { allowNull: true }
  );
  const lat = parsedCoords?.isValid ? parsedCoords.latitude : (data.latitude !== undefined && data.latitude !== null ? Number(data.latitude) : null);
  const lng = parsedCoords?.isValid ? parsedCoords.longitude : (data.longitude !== undefined && data.longitude !== null ? Number(data.longitude) : null);

  await db.prepare(`
    INSERT INTO observations (
      id, code, category, latitude, longitude, address, ward, city,
      description, reporter_type, reporter_name, reporter_phone,
      community_id, campaign_id, site_id, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    code,
    categoryKey,
    lat,
    lng,
    data.address || '',
    data.ward || '',
    data.city || 'Hà Nội',
    data.description || '',
    data.reporterType || 'INDIVIDUAL',
    data.reporterName || 'Cộng đồng',
    data.reporterPhone || null,
    data.communityId || null,
    data.campaignId || null,
    data.siteId || null,
    initialStatus,
    now,
    now
  ).run();

  // Attach evidence if provided
  const evidenceUrls = Array.isArray(data.evidenceUrls) ? data.evidenceUrls : (data.evidenceUrl ? [data.evidenceUrl] : []);
  for (const url of evidenceUrls) {
    const evId = `obsev_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const sha = data.sha256 || await canonicalHash({ url, observationId: id, createdAt: now });
    await db.prepare(`
      INSERT INTO observation_evidence (id, observation_id, url, type, sha256, created_at)
      VALUES (?, ?, ?, 'IMAGE', ?, ?)
    `).bind(evId, id, url, sha, now).run();
  }

  // Also write to youth activities if created by a volunteer
  if (actor.id || data.userId) {
    const userId = actor.id || data.userId;
    try {
      const actId = `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await db.prepare(`
        INSERT INTO youth_activities (id, user_id, activity_type, campaign_id, observation_id, minutes, evidence_url, validation_status, occurred_at, created_at)
        VALUES (?, ?, 'OBSERVATION_REPORT', ?, ?, 30, ?, 'VALIDATED', ?, ?)
      `).bind(actId, userId, data.campaignId || null, id, evidenceUrls[0] || null, observedAt, now).run();
    } catch {
      // Graceful
    }
  }

  // Record impact event for volunteer
  await recordImpactEvent({
    communityId: data.communityId || null,
    userId: actor.id || null,
    eventType: 'OBSERVATION_CREATED',
    pointsEarned: 25,
    volunteerHours: 0.5,
    metadataJson: JSON.stringify({ observationId: id, code })
  }, envOrDb);

  await createAuditLog({
    action: 'OBSERVATION_CREATED',
    entityType: 'OBSERVATION',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || data.reporterName || null,
    actorRole: actor.role || 'citizen',
    afterJson: { id, code, ...data, status: initialStatus }
  }, envOrDb);

  return getObservationById(id, envOrDb);
}

/**
 * Retrieves full aggregate read model for an observation by ID or Code.
 */
export async function getObservationById(idOrCode, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const obs = await db.prepare('SELECT * FROM observations WHERE id = ? OR code = ?').bind(idOrCode, idOrCode).first();
  if (!obs) return null;

  const id = obs.id;
  const evidencesRes = await db.prepare('SELECT * FROM observation_evidence WHERE observation_id = ? ORDER BY created_at ASC').bind(id).all().catch(() => ({ results: [] }));
  const followUpsRes = await db.prepare('SELECT * FROM follow_ups WHERE observation_id = ? ORDER BY verified_at DESC').bind(id).all().catch(() => ({ results: [] }));
  const handoffsRes = await db.prepare('SELECT * FROM handoffs WHERE observation_id = ? ORDER BY created_at DESC').bind(id).all().catch(() => ({ results: [] }));
  const auditsRes = await db.prepare('SELECT * FROM audit_events WHERE aggregate_type = ? AND aggregate_id = ? ORDER BY created_at ASC')
    .bind('OBSERVATION', id).all().catch(() => ({ results: [] }));

  const categoryMeta = await getCategoryById(obs.category, envOrDb);
  const evidences = (evidencesRes?.results || []).map(e => ({
    id: e.id,
    observationId: e.observation_id || e.observationId,
    url: e.url || e.fileUrl,
    type: e.type || e.fileType || 'IMAGE',
    sha256: e.sha256 || e.sha256Hash,
    createdAt: e.created_at || e.createdAt
  }));

  const followUps = (followUpsRes?.results || []).map(row => ({
    id: row.id,
    outcomeStatus: row.outcome_status || row.statusAfter,
    outcome: row.outcome_status || row.statusAfter,
    observationId: row.observation_id || row.observationId,
    caseId: row.case_id || row.caseId,
    performedBy: row.performed_by || row.authorName,
    notes: row.notes || row.note,
    evidenceUrl: row.evidence_url || row.evidenceUrl,
    evidenceSha256: row.evidence_sha256 || row.sha256Hash,
    verifiedAt: row.verified_at || row.createdAt,
    createdAt: row.created_at || row.createdAt
  }));

  const handoffs = (handoffsRes?.results || []).map(h => ({
    id: h.id,
    observationId: h.observation_id || h.observationId,
    caseId: h.case_id || h.caseId,
    recipientUnit: h.recipient_unit || h.recipientUnit,
    recipientContact: h.recipient_contact || h.recipientContact,
    channel: h.channel,
    status: h.status,
    summaryMarkdown: h.summary_markdown || h.summaryMarkdown,
    dossierUrl: h.dossier_url || h.dossierUrl,
    hash: h.hash,
    sentAt: h.sent_at || h.sentAt,
    acknowledgedAt: h.acknowledged_at || h.acknowledgedAt,
    closedAt: h.closed_at || h.closedAt,
    createdAt: h.created_at || h.createdAt,
    updatedAt: h.updated_at || h.updatedAt
  }));

  // Derive timeline from audit logs & followups
  const timeline = [
    {
      type: 'OBSERVATION_CREATED',
      title: 'Ghi nhận hiện trường ban đầu',
      description: obs.description,
      actor: obs.reporter_name || 'Cộng đồng',
      timestamp: obs.created_at
    },
    ...followUps.map(f => ({
      type: 'FOLLOW_UP_CONDUCTED',
      title: `Theo dõi lại: Đánh giá ${f.outcomeStatus}`,
      description: f.notes,
      actor: f.performedBy,
      timestamp: f.verifiedAt || f.createdAt
    })),
    ...handoffs.map(h => ({
      type: 'HANDOFF_ACTION',
      title: `Bàn giao cơ quan: ${h.recipientUnit} (${h.status})`,
      description: h.summaryMarkdown,
      actor: 'Điều phối viên',
      timestamp: h.sentAt || h.createdAt
    }))
  ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  // Evidence integrity evaluation
  const totalEv = evidences.length;
  const verifiedEv = evidences.filter(e => e.sha256 && e.sha256.length >= 32).length;
  const integrity = {
    evidenceCount: totalEv,
    verifiedEvidenceCount: verifiedEv,
    hashesPresent: totalEv > 0 && verifiedEv === totalEv,
    integrityStatus: (totalEv > 0 && verifiedEv === totalEv) ? 'VERIFIED' : (totalEv === 0 ? 'NO_EVIDENCE' : 'PARTIAL'),
    lastVerifiedAt: evidences[evidences.length - 1]?.createdAt || obs.created_at
  };

  // Structured Aggregate Model + Backward-compatible flat fields
  const normalizedObs = normalizeEntityCoordinates(obs);

  return {
    ...normalizedObs,
    evidences,
    followUps,
    handoffs,
    // SSOT sections
    observation: {
      id: obs.id,
      code: obs.code,
      publicCode: obs.code,
      categoryId: obs.category,
      category: obs.category,
      description: obs.description,
      address: obs.address,
      ward: obs.ward,
      city: obs.city,
      latitude: normalizedObs.latitude,
      longitude: normalizedObs.longitude,
      lat: normalizedObs.lat,
      lng: normalizedObs.lng,
      coordinates: normalizedObs.coordinates,
      reporterName: obs.reporter_name,
      reporterType: obs.reporter_type,
      status: obs.status,
      createdAt: obs.created_at,
      updatedAt: obs.updated_at
    },
    category: categoryMeta,
    evidence: evidences,
    timeline,
    integrity
  };
}

/**
 * Retrieves paginated list of observations.
 */
export async function getObservations(query = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const { category, ward, status, communityId, campaignId, page = 1, pageSize = 20 } = query;

  let sql = 'SELECT * FROM observations WHERE 1=1';
  const params = [];

  if (category && category !== 'ALL') {
    sql += ' AND category = ?';
    params.push(category);
  }
  if (ward && ward !== 'ALL') {
    sql += ' AND ward = ?';
    params.push(ward);
  }
  if (status && status !== 'ALL') {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (communityId) {
    sql += ' AND community_id = ?';
    params.push(communityId);
  }
  if (campaignId) {
    sql += ' AND campaign_id = ?';
    params.push(campaignId);
  }

  const safePage = Math.max(Number(page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(pageSize || query.limit) || 20, 1), 100);
  const offset = query.offset !== undefined ? Math.max(Number(query.offset) || 0, 0) : (safePage - 1) * safePageSize;

  const countRes = await db.prepare(`SELECT count(*) as total FROM (${sql})`).bind(...params).first();
  const total = countRes?.total || 0;

  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(safePageSize, offset);

  const rows = await db.prepare(sql).bind(...params).all();
  const rawItems = rows?.results || [];
  const items = rawItems.map(row => normalizeEntityCoordinates(row));

  return {
    items,
    pagination: {
      page: safePage,
      pageSize: safePageSize,
      limit: safePageSize,
      offset,
      total,
      totalPages: Math.ceil(total / safePageSize)
    }
  };
}

/**
 * Updates status of an observation with state-transition validation.
 */
export async function updateObservationStatus(id, newStatus, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const current = await db.prepare('SELECT * FROM observations WHERE id = ?').bind(id).first();
  if (!current) {
    const error = new Error(`Không tìm thấy quan sát với ID: ${id}`);
    error.code = 'NOT_FOUND';
    error.statusCode = 404;
    throw error;
  }

  // Validate state transition policy
  assertObservationTransition(current.status, newStatus);

  const now = new Date().toISOString();
  await db.prepare('UPDATE observations SET status = ?, updated_at = ? WHERE id = ?').bind(newStatus, now, id).run();
  
  await createAuditLog({
    action: 'OBSERVATION_STATUS_UPDATED',
    entityType: 'OBSERVATION',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: { id, status: current.status },
    afterJson: { id, status: newStatus }
  }, envOrDb);

  return getObservationById(id, envOrDb);
}

/**
 * Masks PII (reporter_phone, reporter_name) and fuzzes coordinates (3 decimal places)
 * for public/citizen consumption.
 */
export function maskObservationForPublic(obs) {
  if (!obs) return obs;
  const clone = { ...obs };

  // 1. Mask reporter name
  clone.reporter_name = 'Công dân (ẩn danh)';
  if (clone.reporterName) clone.reporterName = 'Công dân (ẩn danh)';

  // 2. Mask reporter phone
  if (clone.reporter_phone) {
    const s = String(clone.reporter_phone);
    clone.reporter_phone = s.length <= 4 ? '***' : s.slice(0, 3) + '****' + s.slice(-3);
  }
  if (clone.reporterPhone) {
    const s = String(clone.reporterPhone);
    clone.reporterPhone = s.length <= 4 ? '***' : s.slice(0, 3) + '****' + s.slice(-3);
  }

  // 3. Fuzz coordinates to 3 decimal places (~110m precision)
  if (clone.latitude != null && !isNaN(Number(clone.latitude))) {
    clone.latitude = Number(Number(clone.latitude).toFixed(3));
  }
  if (clone.longitude != null && !isNaN(Number(clone.longitude))) {
    clone.longitude = Number(Number(clone.longitude).toFixed(3));
  }
  if (clone.lat != null && !isNaN(Number(clone.lat))) {
    clone.lat = Number(Number(clone.lat).toFixed(3));
  }
  if (clone.lng != null && !isNaN(Number(clone.lng))) {
    clone.lng = Number(Number(clone.lng).toFixed(3));
  }
  if (clone.coordinates && clone.latitude != null && clone.longitude != null) {
    clone.coordinates = `${clone.latitude.toFixed(3)},${clone.longitude.toFixed(3)}`;
  }

  if (clone.observation) {
    clone.observation = {
      ...clone.observation,
      reporterName: 'Công dân (ẩn danh)',
      reporter_phone: clone.reporter_phone,
      reporterPhone: clone.reporterPhone,
      latitude: clone.latitude,
      longitude: clone.longitude,
      lat: clone.lat,
      lng: clone.lng,
      coordinates: clone.coordinates
    };
  }

  return clone;
}

