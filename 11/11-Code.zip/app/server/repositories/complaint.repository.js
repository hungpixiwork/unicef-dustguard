import { prisma, getDbClient } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';

export async function createComplaint(data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  
  const complaint = await client.complaint.create({
    data: {
      code: data.code || `DG-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      siteId: data.siteId || null,
      ward: data.ward || 'Phường Dĩ An',
      address: data.address || '',
      description: data.description || '',
      reporterName: data.reporterName || 'Người dân ẩn danh',
      reporterPhone: data.reporterPhone || null,
      status: data.status || 'PENDING',
      priority: data.priority || 'MEDIUM',
      dueAt: data.dueAt ? new Date(data.dueAt) : null,
      triageNote: data.triageNote || null,
      assignedTo: data.assignedTo || null
    }
  });

  await createAuditLog({
    action: 'COMPLAINT_CREATED',
    entityType: 'COMPLAINT',
    entityId: complaint.id,
    actorId: actor.id || null,
    actorName: actor.name || complaint.reporterName || null,
    actorRole: actor.role || 'citizen',
    afterJson: complaint
  }, envOrDb);

  return complaint;
}

export async function getComplaintById(id, options = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const where = { id };
  if (!options.includeDeleted) {
    where.deletedAt = null;
  }
  return client.complaint.findFirst({
    where,
    include: {
      site: true,
      evidences: { where: options.includeDeleted ? {} : { deletedAt: null } }
    }
  });
}

export async function getComplaints(query = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const {
    ward,
    status,
    siteId,
    search,
    page = 1,
    pageSize = 20,
    includeDeleted = false
  } = query;

  const where = {};
  if (!includeDeleted) {
    where.deletedAt = null;
  }
  if (ward && ward !== 'ALL') {
    where.ward = ward;
  }
  if (status && status !== 'ALL') {
    where.status = status;
  }
  if (siteId) {
    where.siteId = siteId;
  }
  if (search) {
    where.OR = [
      { code: { contains: search } },
      { description: { contains: search } },
      { address: { contains: search } }
    ];
  }

  const safePage = Math.max(Number(page) || 1, 1);
  const safePageSize = Math.min(Math.max(Number(pageSize) || 20, 1), 100);

  const [total, items] = await Promise.all([
    client.complaint.count({ where }),
    client.complaint.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (safePage - 1) * safePageSize,
      take: safePageSize,
      include: {
        site: { select: { id: true, name: true, code: true } },
        evidences: { where: includeDeleted ? {} : { deletedAt: null }, take: 5 }
      }
    })
  ]);

  return {
    items,
    pagination: {
      page: safePage,
      pageSize: safePageSize,
      limit: safePageSize,
      offset: (safePage - 1) * safePageSize,
      total,
      totalPages: Math.ceil(total / safePageSize)
    }
  };
}

export async function updateComplaint(id, data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const current = await client.complaint.findUnique({ where: { id } });
  if (!current) return null;

  const updateData = {};
  const allowedFields = [
    'ward', 'address', 'description', 'reporterName', 'reporterPhone',
    'status', 'priority', 'dueAt', 'triageNote', 'assignedTo',
    'contactedAt', 'closedAt', 'mergedInto', 'siteId'
  ];
  for (const field of allowedFields) {
    if (data[field] !== undefined) {
      updateData[field] = data[field];
    }
  }

  const updated = await client.complaint.update({
    where: { id },
    data: updateData
  });

  await createAuditLog({
    action: 'COMPLAINT_UPDATED',
    entityType: 'COMPLAINT',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  return updated;
}

export async function softDeleteComplaint(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const current = await client.complaint.findUnique({ where: { id } });
  if (!current) return null;

  const updated = await client.complaint.update({
    where: { id },
    data: { deletedAt: new Date() }
  });

  await createAuditLog({
    action: 'COMPLAINT_DELETED',
    entityType: 'COMPLAINT',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  return updated;
}

export async function restoreComplaint(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const current = await client.complaint.findUnique({ where: { id } });
  if (!current) return null;

  const updated = await client.complaint.update({
    where: { id },
    data: { deletedAt: null }
  });

  await createAuditLog({
    action: 'COMPLAINT_RESTORED',
    entityType: 'COMPLAINT',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  return updated;
}

export async function hardDeleteComplaint(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.complaint) ? envOrDb : getDbClient(envOrDb);
  const current = await client.complaint.findUnique({ where: { id } });
  if (!current) return { success: true, id };

  await client.complaint.delete({ where: { id } }).catch(() => null);

  await createAuditLog({
    action: 'COMPLAINT_PERMANENTLY_DELETED',
    entityType: 'COMPLAINT',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'admin',
    beforeJson: current
  }, envOrDb);

  return { success: true, id };
}

