import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { recordImpactEvent } from './impact.repository.js';
import { getObservationById } from './observation.repository.js';
import { buildCanonicalHandoffPacket, assertHandoffTransition } from '../domain/handoffs/handoff.rules.js';

/**
 * Creates a new official handoff record for dispatching environmental dossiers to authorities.
 */
export async function createHandoff(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `hdf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const recipientUnit = data.recipientUnit || data.recipient_unit || 'UBND Phường & Đội Thanh tra Môi trường';
  const obsId = data.observationId || data.observation_id || null;

  let packetHash = data.hash || null;
  let packetPayload = null;

  // Build canonical handoff packet if observation exists
  if (obsId) {
    const obs = await getObservationById(obsId, envOrDb);
    if (obs) {
      const canonical = await buildCanonicalHandoffPacket(obs, obs.followUps || [], data);
      packetHash = canonical.packetHash;
      packetPayload = canonical.serializedJson;
    }
  }

  const initialStatus = data.status || 'PREPARED';

  await db.prepare(`
    INSERT INTO handoffs (
      id, case_id, observation_id, recipient_unit, recipient_contact,
      channel, status, summary_markdown, dossier_url, hash,
      sent_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    data.caseId || data.case_id || null,
    obsId,
    recipientUnit,
    data.recipientContact || data.recipient_contact || null,
    data.channel || 'EMAIL',
    initialStatus,
    data.summaryMarkdown || data.summary_markdown || '',
    data.dossierUrl || data.dossier_url || null,
    packetHash,
    initialStatus === 'SENT' || initialStatus === 'SUBMITTED' ? now : null,
    now,
    now
  ).run();

  // If observation exists, update observation status to READY_FOR_HANDOFF or HANDED_OFF
  if (obsId) {
    const nextObsStatus = initialStatus === 'SENT' || initialStatus === 'SUBMITTED' ? 'HANDED_OFF' : 'READY_FOR_HANDOFF';
    await db.prepare('UPDATE observations SET status = ?, updated_at = ? WHERE id = ?')
      .bind(nextObsStatus, now, obsId).run();
  }

  await recordImpactEvent({
    communityId: data.communityId || null,
    userId: actor.id || null,
    eventType: 'HANDOFF_DISPATCHED',
    pointsEarned: 50,
    volunteerHours: 1.5,
    metadataJson: JSON.stringify({ handoffId: id, recipient: recipientUnit, packetHash })
  }, envOrDb);

  await createAuditLog({
    action: 'HANDOFF_CREATED',
    entityType: 'HANDOFF',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'coordinator',
    afterJson: { id, recipientUnit, status: initialStatus, packetHash }
  }, envOrDb);

  return getHandoffById(id, envOrDb);
}

function extractTicketNumber(contactStr, summaryStr) {
  if (contactStr) {
    const match = contactStr.match(/Ticket:\s*([A-Za-z0-9\-_]+)/i);
    if (match) return match[1];
  }
  if (summaryStr) {
    const match = summaryStr.match(/Ticket:\s*([A-Za-z0-9\-_]+)/i);
    if (match) return match[1];
  }
  return null;
}

export async function getHandoffById(id, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const row = await db.prepare('SELECT * FROM handoffs WHERE id = ?').bind(id).first();
  if (!row) return null;

  return {
    ...row,
    recipientUnit: row.recipient_unit,
    recipientContact: row.recipient_contact,
    summaryMarkdown: row.summary_markdown,
    dossierUrl: row.dossier_url,
    caseId: row.case_id,
    observationId: row.observation_id,
    sentAt: row.sent_at,
    acknowledgedAt: row.acknowledged_at,
    closedAt: row.closed_at,
    ticketNumber: row.ticket_number || extractTicketNumber(row.recipient_contact, row.summary_markdown) || null
  };
}

export async function recordHandoffTicket(id, ticketNumber, channel, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const current = await db.prepare('SELECT * FROM handoffs WHERE id = ?').bind(id).first();
  if (!current) {
    const error = new Error(`Không tìm thấy hồ sơ bàn giao: ${id}`);
    error.code = 'NOT_FOUND';
    error.statusCode = 404;
    throw error;
  }

  const now = new Date().toISOString();
  const cleanTicket = String(ticketNumber || '').trim().toUpperCase();
  const nextChannel = channel || current.channel || 'PORTAL_1022';
  
  // Format recipient_contact for persistent tracking
  const contactText = current.recipient_contact 
    ? (current.recipient_contact.includes('Ticket:') ? current.recipient_contact : `${current.recipient_contact} | Ticket: ${cleanTicket}`)
    : `Ticket: ${cleanTicket}`;

  let nextStatus = current.status;
  if (nextStatus === 'PREPARED') {
    nextStatus = 'SUBMITTED';
  }

  await db.prepare(`
    UPDATE handoffs
    SET recipient_contact = ?,
        channel = ?,
        status = ?,
        sent_at = COALESCE(sent_at, ?),
        updated_at = ?
    WHERE id = ?
  `).bind(contactText, nextChannel, nextStatus, now, now, id).run();

  await createAuditLog({
    action: 'HANDOFF_TICKET_LINKED',
    entityType: 'HANDOFF',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'coordinator',
    beforeJson: { id, status: current.status, channel: current.channel },
    afterJson: { id, ticketNumber: cleanTicket, channel: nextChannel, status: nextStatus, contact: contactText }
  }, envOrDb);

  const updated = await getHandoffById(id, envOrDb);
  return {
    ...updated,
    ticketNumber: cleanTicket
  };
}

export async function updateHandoffStatus(id, newStatus, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const current = await db.prepare('SELECT * FROM handoffs WHERE id = ?').bind(id).first();
  if (!current) {
    const error = new Error(`Không tìm thấy hồ sơ bàn giao: ${id}`);
    error.code = 'NOT_FOUND';
    error.statusCode = 404;
    throw error;
  }

  // Validate state transition policy
  assertHandoffTransition(current.status, newStatus);

  const now = new Date().toISOString();
  let ackDate = current.acknowledged_at;
  let closeDate = current.closed_at;
  let sentDate = current.sent_at;

  if (newStatus === 'SUBMITTED' || newStatus === 'SENT') {
    sentDate = sentDate || now;
  }
  if (newStatus === 'ACKNOWLEDGED') {
    ackDate = ackDate || now;
  }
  if (newStatus === 'CLOSED' || newStatus === 'COMPLETED') {
    closeDate = closeDate || now;
  }

  await db.prepare(`
    UPDATE handoffs
    SET status = ?,
        sent_at = ?,
        acknowledged_at = ?,
        closed_at = ?,
        updated_at = ?
    WHERE id = ?
  `).bind(newStatus, sentDate, ackDate, closeDate, now, id).run();

  // If observation is linked, sync observation state
  if (current.observation_id) {
    let obsStatus = null;
    if (newStatus === 'ACKNOWLEDGED' || newStatus === 'ACTION_IN_PROGRESS') obsStatus = 'HANDED_OFF';
    if (newStatus === 'COMPLETED' || newStatus === 'CLOSED') obsStatus = 'RESOLVED';
    if (obsStatus) {
      await db.prepare('UPDATE observations SET status = ?, updated_at = ? WHERE id = ?')
        .bind(obsStatus, now, current.observation_id).run();
    }
  }

  await createAuditLog({
    action: 'HANDOFF_STATUS_UPDATED',
    entityType: 'HANDOFF',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: { id, status: current.status },
    afterJson: { id, status: newStatus, acknowledgedAt: ackDate, closedAt: closeDate }
  }, envOrDb);

  return getHandoffById(id, envOrDb);
}
