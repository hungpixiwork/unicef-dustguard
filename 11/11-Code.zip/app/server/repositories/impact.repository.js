import { getD1OrSqlite } from '../shared/db.js';

/**
 * Community Impact Metrics SSOT (DustGuard VN)
 * Calculates 100% dynamic, verifiable aggregate metrics from D1 SQLite without hardcoded offsets.
 */

export async function recordImpactEvent(data, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `imp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  await db.prepare(`
    INSERT INTO impact_events (
      id, community_id, user_id, event_type, points_earned, volunteer_hours, metadata_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    data.communityId || null,
    data.userId || null,
    data.eventType || 'CIVIC_ACTION',
    data.pointsEarned !== undefined ? data.pointsEarned : 10,
    data.volunteerHours !== undefined ? data.volunteerHours : 0.5,
    data.metadataJson || '{}',
    now
  ).run();

  return { id, ...data, created_at: now };
}

export async function getCommunityImpactStats(filter = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const { from, to, campaignId, district, ward } = typeof filter === 'object' && filter !== null ? filter : {};

  let obsSql = 'SELECT count(*) as total FROM observations WHERE 1=1';
  let resolvedSql = "SELECT count(*) as total FROM observations WHERE status = 'RESOLVED'";
  let flwSql = 'SELECT count(*) as total FROM follow_ups WHERE 1=1';
  let hdfSql = 'SELECT count(*) as total FROM handoffs WHERE 1=1';
  let evSql = 'SELECT count(*) as total FROM observation_evidence WHERE 1=1';
  let impactSql = `
    SELECT
      COALESCE(SUM(points_earned), 0) as total_points,
      COALESCE(SUM(volunteer_hours), 0) as total_hours,
      count(DISTINCT user_id) as active_volunteers
    FROM impact_events WHERE 1=1
  `;

  const obsParams = [];
  const impactParams = [];

  if (campaignId) {
    obsSql += ' AND campaign_id = ?';
    resolvedSql += ' AND campaign_id = ?';
    impactSql += ' AND community_id = ?';
    obsParams.push(campaignId);
    impactParams.push(campaignId);
  }

  if (ward || district) {
    const loc = ward || district;
    obsSql += ' AND (ward = ? OR city = ?)';
    resolvedSql += ' AND (ward = ? OR city = ?)';
    obsParams.push(loc, loc);
  }

  if (from) {
    obsSql += ' AND created_at >= ?';
    resolvedSql += ' AND created_at >= ?';
    impactSql += ' AND created_at >= ?';
    obsParams.push(from);
    impactParams.push(from);
  }

  if (to) {
    obsSql += ' AND created_at <= ?';
    resolvedSql += ' AND created_at <= ?';
    impactSql += ' AND created_at <= ?';
    obsParams.push(to);
    impactParams.push(to);
  }

  const [obsRes, resObsRes, flwRes, hdfRes, evRes, impRes] = await Promise.all([
    db.prepare(obsSql).bind(...obsParams).first(),
    db.prepare(resolvedSql).bind(...obsParams).first(),
    db.prepare(flwSql).first(),
    db.prepare(hdfSql).first(),
    db.prepare(evSql).first(),
    db.prepare(impactSql).bind(...impactParams).first()
  ]);

  const totalObservations = obsRes?.total || 0;
  const resolvedIssues = resObsRes?.total || 0;
  const totalFollowUps = flwRes?.total || 0;
  const totalHandoffs = hdfRes?.total || 0;
  const totalEvidence = evRes?.total || 0;
  const totalPoints = impRes?.total_points || 0;
  const totalVolunteerHours = Number((impRes?.total_hours || 0).toFixed(1));
  const activeVolunteers = impRes?.active_volunteers || 0;
  const resolutionRate = totalObservations > 0 ? Number((resolvedIssues / totalObservations).toFixed(2)) : 0;

  // School actions query (observations near school zones or related to school dust protection)
  const schoolActionsRes = await db.prepare(
    "SELECT count(*) as total FROM observations WHERE (description LIKE '%trường%' OR ward LIKE '%Dịch Vọng%' OR category = 'CONSTRUCTION_DUST') AND status = 'RESOLVED'"
  ).first().catch(() => ({ total: 0 }));
  const schoolsProtected = schoolActionsRes?.total || 0;

  const metrics = {
    totalObservations,
    totalFollowUps,
    totalEvidence,
    totalHandoffs,
    resolvedIssues,
    resolutionRate,
    totalPoints,
    totalVolunteerHours,
    activeVolunteers,
    schoolsProtected
  };

  const definitions = {
    totalObservations: 'Số lượng phản ánh hiện trường đã gửi và lưu trữ trong D1 SSOT',
    totalFollowUps: 'Số lượt kiểm tra và theo dõi lại hiện trường theo chu kỳ 24h-48h',
    totalEvidence: 'Số lượng tệp minh chứng số có gắn băm mật mã SHA-256',
    totalHandoffs: 'Số bộ hồ sơ đã chuẩn bị hoặc bàn giao sang cơ quan chức năng',
    resolvedIssues: 'Số lượng phản ánh đã giải quyết hoặc cải thiện thành công (RESOLVED)',
    resolutionRate: 'Tỷ lệ giải quyết thành công trên tổng số quan sát ghi nhận',
    totalPoints: 'Tổng điểm hành động thanh niên tích lũy từ hoạt động thực địa',
    totalVolunteerHours: 'Tổng số giờ tình nguyện được xác thực qua hoạt động',
    activeVolunteers: 'Số lượng tình nguyện viên / tài khoản thanh niên tham gia',
    schoolsProtected: 'Số điểm nóng môi trường khu vực trường học/cộng đồng được xử lý'
  };

  return {
    // Backward-compatibility flat fields
    ...metrics,
    // SSOT envelope
    metrics,
    definitions,
    period: { from: from || null, to: to || null },
    generatedAt: new Date().toISOString()
  };
}
