import { prisma, getDbClient } from '../shared/db.js';

/**
 * Domain Histories Repository: Case Status History & Priority Score History
 */

export async function createCaseStatusHistory(data, envOrDb) {
  const client = (envOrDb && envOrDb.caseStatusHistory) ? envOrDb : getDbClient(envOrDb);
  return client.caseStatusHistory.create({
    data: {
      id: data.id || `csh_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      caseId: data.caseId,
      fromStatus: data.fromStatus || 'OPEN',
      toStatus: data.toStatus,
      changedBy: data.changedBy || data.actorId || null,
      actorName: data.actorName || null,
      actorRole: data.actorRole || 'staff',
      note: data.note || null,
      createdAt: data.createdAt ? new Date(data.createdAt) : new Date()
    }
  });
}

export async function getCaseStatusHistories(caseId, envOrDb, options = {}) {
  const client = (envOrDb && envOrDb.caseStatusHistory) ? envOrDb : getDbClient(envOrDb);
  const take = Math.min(Math.max(options.take || options.limit || 50, 1), 100);
  return client.caseStatusHistory.findMany({
    where: { caseId },
    orderBy: { createdAt: 'asc' },
    take
  });
}

export async function createPriorityScoreHistory(data, envOrDb) {
  const client = (envOrDb && envOrDb.priorityScoreHistory) ? envOrDb : getDbClient(envOrDb);
  return client.priorityScoreHistory.create({
    data: {
      id: data.id || `psh_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      siteId: data.siteId,
      caseId: data.caseId || null,
      score: Number(data.score) || 0,
      scoreVersion: data.scoreVersion || 'CPS_v1',
      componentsJson: typeof data.componentsJson === 'object' ? JSON.stringify(data.componentsJson) : (data.componentsJson || '{}'),
      reasonsJson: Array.isArray(data.reasonsJson) ? JSON.stringify(data.reasonsJson) : (data.reasonsJson || '[]'),
      calculatedBy: data.calculatedBy || 'SYSTEM_CPS_ENGINE',
      createdAt: data.createdAt ? new Date(data.createdAt) : new Date()
    }
  });
}

export async function getPriorityScoreHistories(siteId, envOrDb) {
  const client = (envOrDb && envOrDb.priorityScoreHistory) ? envOrDb : getDbClient(envOrDb);
  return client.priorityScoreHistory.findMany({
    where: { siteId },
    orderBy: { createdAt: 'desc' },
    take: 50
  });
}
