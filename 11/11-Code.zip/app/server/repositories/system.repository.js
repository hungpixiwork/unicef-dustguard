import { prisma, getDbClient, getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';

/**
 * System Data Management Repository
 * Responsible for D1 stats inspection, safe dry-run preview, and controlled cascade purge.
 */

export async function getSystemDataStats(envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  if (db && typeof db.prepare === 'function') {
    try {
      const [
        sitesRow,
        complaintsRow,
        inspectionsRow,
        casesRow,
        evidencesRow,
        actionsRow,
        draftDocsRow,
        sensorsRow,
        readingsRow,
        alertsRow,
        auditLogsRow
      ] = await Promise.all([
        db.prepare('SELECT COUNT(*) as c FROM sites WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM complaints WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM inspections WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM cases WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM evidences WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM actions WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM draft_documents WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM sensors').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM sensor_readings').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM alerts WHERE deletedAt IS NULL').first().catch(() => ({ c: 0 })),
        db.prepare('SELECT COUNT(*) as c FROM audit_logs').first().catch(() => ({ c: 0 }))
      ]);

      const sitesCount = sitesRow?.c ?? 0;
      const complaintsCount = complaintsRow?.c ?? 0;
      const inspectionsCount = inspectionsRow?.c ?? 0;
      const casesCount = casesRow?.c ?? 0;
      const evidencesCount = evidencesRow?.c ?? 0;
      const actionsCount = actionsRow?.c ?? 0;
      const draftDocumentsCount = draftDocsRow?.c ?? 0;
      const sensorsCount = sensorsRow?.c ?? 0;
      const readingsCount = readingsRow?.c ?? 0;
      const alertsCount = alertsRow?.c ?? 0;
      const auditLogsCount = auditLogsRow?.c ?? 0;

      return {
        database: {
          provider: 'cloudflare-d1',
          status: 'HEALTHY',
          ssot: true
        },
        counts: {
          sites: sitesCount,
          complaints: complaintsCount,
          inspections: inspectionsCount,
          cases: casesCount,
          evidences: evidencesCount,
          actions: actionsCount,
          draftDocuments: draftDocumentsCount,
          sensors: sensorsCount,
          sensorReadings: readingsCount,
          alerts: alertsCount,
          auditLogs: auditLogsCount,
          caseHistories: 0,
          priorityHistories: 0,
          totalOperationalRecords: (
            sitesCount + complaintsCount + inspectionsCount + casesCount +
            evidencesCount + actionsCount + draftDocumentsCount +
            sensorsCount + readingsCount + alertsCount
          )
        },
        timestamp: new Date().toISOString()
      };
    } catch (e) {}
  }

  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);

  const [
    sitesCount,
    complaintsCount,
    inspectionsCount,
    casesCount,
    evidencesCount,
    actionsCount,
    draftDocumentsCount,
    sensorsCount,
    readingsCount,
    alertsCount,
    auditLogsCount,
    caseHistoriesCount,
    priorityHistoriesCount
  ] = await Promise.all([
    client?.site?.count ? client.site.count().catch(() => 0) : 0,
    client?.complaint?.count ? client.complaint.count().catch(() => 0) : 0,
    client?.inspection?.count ? client.inspection.count().catch(() => 0) : 0,
    client?.case?.count ? client.case.count().catch(() => 0) : 0,
    client?.evidence?.count ? client.evidence.count().catch(() => 0) : 0,
    client?.action?.count ? client.action.count().catch(() => 0) : 0,
    client?.draftDocument?.count ? client.draftDocument.count().catch(() => 0) : 0,
    client?.sensor?.count ? client.sensor.count().catch(() => 0) : 0,
    client?.sensorReading?.count ? client.sensorReading.count().catch(() => 0) : 0,
    client?.alert?.count ? client.alert.count().catch(() => 0) : 0,
    client?.auditLog?.count ? client.auditLog.count().catch(() => 0) : 0,
    client?.caseStatusHistory?.count ? client.caseStatusHistory.count().catch(() => 0) : 0,
    client?.priorityScoreHistory?.count ? client.priorityScoreHistory.count().catch(() => 0) : 0
  ]);

  return {
    database: {
      provider: 'cloudflare-d1',
      status: 'HEALTHY',
      ssot: true
    },
    counts: {
      sites: sitesCount,
      complaints: complaintsCount,
      inspections: inspectionsCount,
      cases: casesCount,
      evidences: evidencesCount,
      actions: actionsCount,
      draftDocuments: draftDocumentsCount,
      sensors: sensorsCount,
      sensorReadings: readingsCount,
      alerts: alertsCount,
      auditLogs: auditLogsCount,
      caseHistories: caseHistoriesCount,
      priorityHistories: priorityHistoriesCount,
      totalOperationalRecords: (
        sitesCount + complaintsCount + inspectionsCount + casesCount +
        evidencesCount + actionsCount + draftDocumentsCount +
        sensorsCount + readingsCount + alertsCount
      )
    },
    timestamp: new Date().toISOString()
  };
}

export async function previewResetCounts(envOrDb) {
  const stats = await getSystemDataStats(envOrDb);
  return {
    resettableEntities: {
      complaints: stats.counts.complaints,
      cases: stats.counts.cases,
      evidences: stats.counts.evidences,
      actions: stats.counts.actions,
      draftDocuments: stats.counts.draftDocuments,
      inspections: stats.counts.inspections,
      sensorReadings: stats.counts.sensorReadings,
      alerts: stats.counts.alerts,
      sites: stats.counts.sites,
      sensors: stats.counts.sensors,
      caseHistories: stats.counts.caseHistories,
      priorityHistories: stats.counts.priorityHistories
    },
    preservedEntities: {
      users: 'PRESERVED (Admin & system identities retained)',
      profiles: 'PRESERVED',
      legalDocuments: 'PRESERVED (Static legal standards & decrees)',
      administrativeRegions: 'PRESERVED (63 provinces & wards GIS boundary)'
    },
    totalToDelete: stats.counts.totalOperationalRecords,
    requiresConfirmation: 'RESET DUSTGUARD DATA',
    timestamp: stats.timestamp
  };
}

/**
 * Executes a controlled purge of all operational data in strict foreign key order.
 * Preserves: users, profiles, legal documents, administrative units.
 */
export async function purgeOperationalData(options = {}, envOrDb) {
  const client = (envOrDb && envOrDb.site) ? envOrDb : getDbClient(envOrDb);
  const deletedCounts = {};

  // Delete in strict reverse dependency order to satisfy FK constraints
  // 1. Histories & Notifications & Details
  if (client.alertNotification) {
    deletedCounts.alertNotifications = (await client.alertNotification.deleteMany({})).count;
  }
  if (client.caseStatusHistory) {
    deletedCounts.caseStatusHistories = (await client.caseStatusHistory.deleteMany({}).catch(() => ({ count: 0 }))).count;
  }
  if (client.priorityScoreHistory) {
    deletedCounts.priorityScoreHistories = (await client.priorityScoreHistory.deleteMany({}).catch(() => ({ count: 0 }))).count;
  }
  if (client.caseTimeline) {
    deletedCounts.caseTimelines = (await client.caseTimeline.deleteMany({})).count;
  }
  if (client.contractorExplanation) {
    deletedCounts.contractorExplanations = (await client.contractorExplanation.deleteMany({})).count;
  }
  if (client.sanctionDecision) {
    deletedCounts.sanctionDecisions = (await client.sanctionDecision.deleteMany({})).count;
  }
  if (client.documentRevision) {
    deletedCounts.documentRevisions = (await client.documentRevision.deleteMany({})).count;
  }

  // Clean up community & child tables in D1 raw SQL if present
  try {
    const db = getD1OrSqlite(envOrDb);
    await db.prepare('DELETE FROM observation_evidence').run().catch(() => {});
    await db.prepare('DELETE FROM follow_ups').run().catch(() => {});
    await db.prepare('DELETE FROM handoffs').run().catch(() => {});
    await db.prepare('DELETE FROM observations').run().catch(() => {});
    await db.prepare('DELETE FROM priority_score_history').run().catch(() => {});
    await db.prepare('DELETE FROM case_status_history').run().catch(() => {});
  } catch {}

  // 2. Operational Children
  deletedCounts.draftDocuments = (await client.draftDocument.deleteMany({})).count;
  deletedCounts.actions = (await client.action.deleteMany({})).count;
  deletedCounts.evidences = (await client.evidence.deleteMany({})).count;
  deletedCounts.alerts = (await client.alert.deleteMany({})).count;
  deletedCounts.sensorReadings = (await client.sensorReading.deleteMany({})).count;
  deletedCounts.inspections = (await client.inspection.deleteMany({})).count;
  deletedCounts.cases = (await client.case.deleteMany({})).count;
  deletedCounts.complaints = (await client.complaint.deleteMany({})).count;
  deletedCounts.sensors = (await client.sensor.deleteMany({})).count;
  deletedCounts.sites = (await client.site.deleteMany({})).count;

  // Record immutable reset event in Audit Logs
  await createAuditLog({
    action: 'SYSTEM_DATA_RESET',
    entityType: 'SYSTEM',
    entityId: 'SYSTEM_SSOT_RESET',
    actorId: options.actor?.id || 'admin_operator',
    actorName: options.actor?.name || 'Administrator',
    actorRole: 'admin',
    details: {
      mode: options.mode || 'EMPTY',
      deleteStoredFiles: !!options.deleteStoredFiles,
      countsDeleted: deletedCounts,
      timestamp: new Date().toISOString()
    }
  }, envOrDb);

  return {
    success: true,
    mode: options.mode || 'EMPTY',
    deletedCounts,
    timestamp: new Date().toISOString()
  };
}
