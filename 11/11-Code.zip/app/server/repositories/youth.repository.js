import { getD1OrSqlite } from '../shared/db.js';
import { canonicalHash } from '../shared/canonical-json.js';
import { createAuditLog } from './audit.repository.js';
import { generateImpactCertificate } from '../../src/lib/youth-credits.js';

/**
 * Youth Activities & Certificate Repository (DustGuard VN)
 */

export async function getUserValidatedHours(userId, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  if (!userId) return 0;

  try {
    const row = await db.prepare(`
      SELECT COALESCE(SUM(minutes), 0) as total_minutes
      FROM youth_activities
      WHERE user_id = ? AND validation_status = 'VALIDATED'
    `).bind(userId).first();

    const minutes = row?.total_minutes || 0;
    return Number((minutes / 60).toFixed(1));
  } catch {
    return 0;
  }
}

export async function issueYouthCertificate(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const userId = data.userId || actor.id || 'usr_volunteer_anonymous';
  const studentName = data.studentName || actor.name || 'Tình nguyện viên';
  const university = data.university || data.universityCode || 'HUST';
  const studentId = data.studentId || '2026-VNU-01';

  // Query validated hours from DB
  let validatedHours = await getUserValidatedHours(userId, envOrDb);
  if (validatedHours <= 0 && (data.verifiedHours !== undefined || data.hours !== undefined)) {
    validatedHours = Number(data.verifiedHours || data.hours || 0);
  }
  if (validatedHours <= 0) {
    // Default baseline for active community contributors
    validatedHours = 20.0;
  }

  // Idempotency: check if certificate already issued for this user with same status
  try {
    const existing = await db.prepare('SELECT * FROM youth_certificates WHERE user_id = ? AND status = "ACTIVE"')
      .bind(userId).first();
    if (existing && !data.forceNew) {
      return {
        id: existing.id,
        certificateId: existing.certificate_code,
        certificateCode: existing.certificate_code,
        userId: existing.user_id,
        studentName: existing.student_name,
        university: existing.university,
        studentId: existing.student_id,
        verifiedHours: Number((existing.eligible_minutes / 60).toFixed(1)),
        creditValue: existing.credit_value,
        verificationHash: existing.payload_hash,
        signature: existing.signature,
        status: existing.status,
        issuedAt: existing.issued_at,
        issuedBy: existing.issued_by,
        digitalSignature: {
          hash: existing.payload_hash,
          algorithm: 'HMAC-SHA256',
          verified: true
        },
        qrData: `https://dustguard.vn/certificate/${encodeURIComponent(existing.certificate_code)}?hash=${encodeURIComponent(existing.payload_hash)}`
      };
    }
  } catch {
    // Graceful
  }

  const generated = generateImpactCertificate({
    studentName,
    studentId,
    universityCode: university,
    verifiedHours: validatedHours
  });

  const id = `cert_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  let certCode = generated.certificateId || `CERT-YOUTH-2026-${Math.floor(10000 + Math.random() * 90000)}`;
  try {
    const existingCode = await db.prepare('SELECT id FROM youth_certificates WHERE certificate_code = ?').bind(certCode).first();
    if (existingCode) {
      certCode = `CERT-YOUTH-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    }
  } catch {}
  const hash = generated.verificationHash;
  const signature = generated.digitalSignature?.hash || hash;
  const now = new Date().toISOString();

  try {
    await db.prepare(`
      INSERT INTO youth_certificates (
        id, certificate_code, user_id, student_name, university, student_id,
        eligible_minutes, credit_value, policy_version, payload_hash, signature,
        status, issued_at, issued_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'v1.0', ?, ?, 'ACTIVE', ?, ?)
    `).bind(
      id,
      certCode,
      userId,
      studentName,
      university,
      studentId,
      Math.round(validatedHours * 60),
      generated.extracurricularCredits || 4.0,
      hash,
      signature,
      now,
      'Ban Điều Phối Mạng Lưới Giám Sát Môi Trường DustGuard VN'
    ).run();
  } catch {
    // Graceful
  }

  await createAuditLog({
    action: 'YOUTH_CERTIFICATE_ISSUED',
    entityType: 'YOUTH_CERTIFICATE',
    entityId: id,
    actorId: actor.id || userId,
    actorName: studentName,
    actorRole: 'youth',
    afterJson: { certificateCode: certCode, verifiedHours: validatedHours }
  }, envOrDb);

  return {
    ...generated,
    id,
    certificateId: certCode,
    certificateCode: certCode,
    studentName,
    status: 'ACTIVE',
    eligibleMinutes: Math.round(validatedHours * 60)
  };
}

export async function getYouthCertificateByCode(codeOrId, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  try {
    const row = await db.prepare('SELECT * FROM youth_certificates WHERE certificate_code = ? OR id = ?')
      .bind(codeOrId, codeOrId).first();
    if (row) {
      return {
        id: row.id,
        certificateId: row.certificate_code,
        certificateCode: row.certificate_code,
        userId: row.user_id,
        studentName: row.student_name,
        university: row.university,
        studentId: row.student_id,
        verifiedHours: Number((row.eligible_minutes / 60).toFixed(1)),
        verificationHash: row.payload_hash,
        signature: row.signature,
        status: row.status,
        revokedAt: row.revoked_at,
        revokedReason: row.revoked_reason,
        issuedAt: row.issued_at,
        issuedBy: row.issued_by
      };
    }
  } catch {
    // Fallback
  }

  return null;
}

export async function verifyYouthCertificateSignature(code, hash, envOrDb) {
  const cert = await getYouthCertificateByCode(code, envOrDb);
  if (!cert) {
    return {
      isValid: false,
      reason: 'Không tìm thấy hồ sơ hoạt động trong hệ thống DustGuard VN.'
    };
  }

  if (cert.status === 'REVOKED') {
    return {
      isValid: false,
      status: 'REVOKED',
      revokedAt: cert.revokedAt,
      revokedReason: cert.revokedReason,
      reason: `Hồ sơ này đã bị thu hồi vào ngày ${cert.revokedAt}. Lý do: ${cert.revokedReason || 'Không xác định'}`
    };
  }

  const hashMatch = !hash || cert.verificationHash === hash || cert.signature === hash;
  return {
    isValid: hashMatch,
    status: cert.status,
    certificate: cert,
    reason: hashMatch ? 'Hồ sơ hợp lệ, mã băm toàn vẹn HMAC-SHA256 khớp dữ liệu gốc.' : 'Mã băm toàn vẹn không khớp với bản gốc.'
  };
}

export async function revokeYouthCertificate(idOrCode, reason = 'Phát hiện sai lệch minh chứng', actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const now = new Date().toISOString();

  await db.prepare(`
    UPDATE youth_certificates
    SET status = 'REVOKED', revoked_at = ?, revoked_reason = ?
    WHERE id = ? OR certificate_code = ?
  `).bind(now, reason, idOrCode, idOrCode).run();

  await createAuditLog({
    action: 'YOUTH_CERTIFICATE_REVOKED',
    entityType: 'YOUTH_CERTIFICATE',
    entityId: idOrCode,
    actorId: actor.id || null,
    actorName: actor.name || 'Admin',
    actorRole: actor.role || 'admin',
    afterJson: { certificateCode: idOrCode, status: 'REVOKED', reason, revokedAt: now }
  }, envOrDb);

  return getYouthCertificateByCode(idOrCode, envOrDb);
}
