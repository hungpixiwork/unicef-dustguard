import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { recordImpactEvent } from './impact.repository.js';
import { FollowUpDecisionService } from '../services/followup-decision.service.js';
import { canonicalHash } from '../shared/canonical-json.js';

/**
 * Creates a new Follow-up inspection entry and atomically transitions observation / case.
 */
export async function createFollowUp(data, actor = {}, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const id = data.id || `flw_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const outcomeStatus = data.outcomeStatus || data.outcome_status || data.outcome || 'UNCHANGED';
  const obsId = data.observationId || data.observation_id || null;
  const hasEvidence = Boolean(data.evidenceUrl || data.evidenceUrls?.length || data.evidence_url);

  let obs = null;
  let previousFollowUps = [];
  if (obsId) {
    obs = await db.prepare('SELECT * FROM observations WHERE id = ?').bind(obsId).first();
    const prevRes = await db.prepare('SELECT * FROM follow_ups WHERE observation_id = ? ORDER BY verified_at ASC')
      .bind(obsId).all();
    previousFollowUps = prevRes?.results || [];
  }

  // Evaluate decision using FollowUpDecisionService SSOT
  const decision = FollowUpDecisionService.evaluate({
    outcome: outcomeStatus,
    currentStatus: obs?.status || 'RECORDED',
    previousFollowUps,
    hasEvidence
  });

  const sha = data.evidenceSha256 || data.evidence_sha256 || (hasEvidence ? await canonicalHash({ url: data.evidenceUrl || data.evidence_url, followUpId: id, createdAt: now }) : null);

  // Execute batch or atomic query execution
  await db.prepare(`
    INSERT INTO follow_ups (
      id, observation_id, case_id, performed_by, outcome_status,
      notes, evidence_url, evidence_sha256, verified_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id,
    obsId,
    data.caseId || data.case_id || null,
    data.performedBy || data.performed_by || actor.name || 'Tình nguyện viên',
    outcomeStatus,
    data.notes || '',
    data.evidenceUrl || data.evidence_url || null,
    sha,
    data.verifiedAt || data.verified_at || now,
    now
  ).run();

  // Atomically update observation status to recommended state
  if (obsId && obs) {
    await db.prepare('UPDATE observations SET status = ?, updated_at = ? WHERE id = ?')
      .bind(decision.recommendedStatus, now, obsId).run();
  }

  // Record youth activity
  if (actor.id || data.userId) {
    const userId = actor.id || data.userId;
    try {
      const actId = `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await db.prepare(`
        INSERT INTO youth_activities (id, user_id, activity_type, campaign_id, observation_id, minutes, evidence_url, validation_status, occurred_at, created_at)
        VALUES (?, ?, 'FOLLOW_UP_REVISIT', ?, ?, 60, ?, 'VALIDATED', ?, ?)
      `).bind(actId, userId, obs?.campaign_id || null, obsId, data.evidenceUrl || null, now, now).run();
    } catch {
      // Graceful
    }
  }

  // Record impact points for re-visiting
  await recordImpactEvent({
    communityId: data.communityId || obs?.community_id || null,
    userId: actor.id || null,
    eventType: 'FOLLOW_UP_RECORDED',
    pointsEarned: 35,
    volunteerHours: 1.0,
    metadataJson: JSON.stringify({ followUpId: id, outcome: outcomeStatus, decision })
  }, envOrDb);

  await createAuditLog({
    action: 'FOLLOW_UP_CREATED',
    entityType: 'FOLLOW_UP',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || data.performedBy || null,
    actorRole: actor.role || 'volunteer',
    beforeJson: { observationStatus: obs?.status || 'RECORDED' },
    afterJson: { id, outcome: outcomeStatus, decision, observationStatus: decision.recommendedStatus }
  }, envOrDb);

  const row = await db.prepare('SELECT * FROM follow_ups WHERE id = ?').bind(id).first();
  return {
    ...row,
    outcomeStatus: row.outcome_status,
    outcome: row.outcome_status,
    observationId: row.observation_id,
    caseId: row.case_id,
    performedBy: row.performed_by,
    evidenceUrl: row.evidence_url,
    evidenceSha256: row.evidence_sha256,
    verifiedAt: row.verified_at,
    decision
  };
}

export async function getFollowUpsByObservationId(observationId, envOrDb) {
  const db = getD1OrSqlite(envOrDb);
  const res = await db.prepare('SELECT * FROM follow_ups WHERE observation_id = ? ORDER BY verified_at DESC')
    .bind(observationId).all();
  return (res?.results || []).map(row => ({
    ...row,
    outcomeStatus: row.outcome_status,
    outcome: row.outcome_status,
    observationId: row.observation_id,
    caseId: row.case_id,
    performedBy: row.performed_by,
    evidenceUrl: row.evidence_url,
    evidenceSha256: row.evidence_sha256,
    verifiedAt: row.verified_at
  }));
}
