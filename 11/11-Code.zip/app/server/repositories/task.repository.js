// app/server/repositories/task.repository.js
// Cloudflare D1 & SQLite Repository for Task Management & Field Community Actions SSOT
// Zero-Mock, Real DB Queries, Dynamic Aggregates, Points/Youth Credit Integration

import { getD1OrSqlite } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';
import { getVNNowStr, getVNTodayStr } from '../db/timezone.js';

// Seed tasks ban đầu chuẩn thực tế nếu DB chưa có task nào
const SEED_TASKS = [
  {
    id: 'task_001_dian_school',
    code: 'TASK-2026-001',
    title: 'Xác minh bụi quanh trường học & xe ben không phủ bạt',
    description: 'Khảo sát bán kính 300m xung quanh Trường Tiểu học Dĩ An, kiểm tra bụi phát tán từ các xe ben thi công ra vào giờ tan học.',
    task_type: 'field_verification',
    source_type: 'case',
    case_id: 'case_school_dian_01',
    site_id: 'site_dian_01',
    location_text: 'Trường Tiểu học Dĩ An, TP. Dĩ An, Bình Dương',
    latitude: 10.9032,
    longitude: 106.7871,
    start_at: '2026-08-28 07:00:00',
    due_at: '2026-08-28 17:30:00',
    assignment_type: 'open',
    max_participants: 12,
    status: 'OPEN',
    priority: 'HIGH',
    points: 20,
    contribution_minutes: 30,
    evidence_instructions: 'Chụp 1-2 ảnh xe ben ra vào cổng trường hoặc tuyến đường dân sinh kèm ghi nhận có bạt che chắn hay không.',
    created_by: 'staff_system'
  },
  {
    id: 'task_002_dichvong_site',
    code: 'TASK-2026-002',
    title: 'Kiểm tra biển thông tin công trình, rào chắn & hố rửa xe',
    description: 'Kiểm tra việc lắp đặt bảng hiệu thông tin hotline chỉ huy trưởng, lưới chắn bụi và hố xịt rửa lốp xe trước khi rời công trường.',
    task_type: 'site_inspection',
    source_type: 'case',
    case_id: 'case_school_dian_01',
    site_id: 'site_dichvong_02',
    location_text: 'Khu đô thị mới Dịch Vọng Hậu, Cầu Giấy, Hà Nội',
    latitude: 21.0368,
    longitude: 105.7842,
    start_at: '2026-08-28 08:00:00',
    due_at: '2026-08-29 09:00:00',
    assignment_type: 'individual',
    assigned_profile_id: 'user_1',
    max_participants: 8,
    status: 'IN_PROGRESS',
    priority: 'MEDIUM',
    points: 20,
    contribution_minutes: 30,
    evidence_instructions: 'Chụp ảnh rào chắn và hố rửa xe. Ghi rõ tên nhà thầu nếu có biển hiệu.',
    created_by: 'staff_system'
  },
  {
    id: 'task_003_donganh_waste',
    code: 'TASK-2026-003',
    title: 'Tuần tra điểm tập kết & đốt rác tự phát ven đê sông Đuống',
    description: 'Ghi nhận vị trí và thời gian phát sinh khói đốt rác cao su, phế liệu công nghiệp ven triền đê gây mùi khét lan vào khu dân cư.',
    task_type: 'community_observation',
    source_type: 'case',
    case_id: 'case_smoke_donganh_02',
    location_text: 'Xã Đông Hội, Huyện Đông Anh, Hà Nội',
    latitude: 21.0854,
    longitude: 105.8821,
    start_at: '2026-08-28 09:00:00',
    due_at: '2026-08-28 15:00:00',
    assignment_type: 'club',
    club_id: 'club_hust_01',
    max_participants: 15,
    status: 'OPEN',
    priority: 'CRITICAL',
    points: 25,
    contribution_minutes: 45,
    evidence_instructions: 'Chụp ảnh cột khói và tọa độ GPS chính xác để phối hợp lực lượng địa bàn.',
    created_by: 'staff_system'
  },
  {
    id: 'task_004_caugiay_wood',
    code: 'TASK-2026-004',
    title: 'Khảo sát tiếng ồn & phát sinh bụi xưởng mộc dân sinh',
    description: 'Lấy ý kiến thực tế của người dân xung quanh về khung giờ máy cưa hoạt động phát tán bụi gỗ mịn không có hệ thống hút bụi.',
    task_type: 'follow_up',
    source_type: 'case',
    case_id: 'case_wood_caugiay_04',
    location_text: 'Phường Dịch Vọng Hậu, Q. Cầu Giấy, Hà Nội',
    latitude: 21.0381,
    longitude: 105.7865,
    start_at: '2026-08-28 10:00:00',
    due_at: '2026-08-29 14:00:00',
    assignment_type: 'club',
    club_id: 'club_uit_02',
    max_participants: 10,
    status: 'IN_PROGRESS',
    priority: 'LOW',
    points: 20,
    contribution_minutes: 30,
    evidence_instructions: 'Ghi chép khung giờ phát tán bụi và chụp ảnh vị trí đặt máy cắt.',
    created_by: 'staff_system'
  },
  {
    id: 'task_005_caugiay_canal',
    code: 'TASK-2026-005',
    title: 'Xác nhận nghiệm thu nạo vét & khơi thông mương hở',
    description: 'Kiểm tra hiện trạng sau khi đội nạo vét hoàn tất dọn dẹp rác đọng và bùn thải, đảm bảo không còn mùi ứ đọng.',
    task_type: 'field_verification',
    source_type: 'case',
    case_id: 'case_canal_caugiay_03',
    location_text: 'Mương hở Dịch Vọng, Q. Cầu Giấy, Hà Nội',
    latitude: 21.0355,
    longitude: 105.7902,
    start_at: '2026-08-24 08:00:00',
    due_at: '2026-08-25 16:45:00',
    assignment_type: 'open',
    max_participants: 4,
    status: 'COMPLETED',
    priority: 'MEDIUM',
    points: 20,
    contribution_minutes: 30,
    evidence_instructions: 'Chụp ảnh lòng mương thông thoáng sau khi dọn sạch.',
    created_by: 'staff_system'
  }
];

const SEED_PARTICIPANTS = [
  {
    id: 'tp_001_1',
    task_id: 'task_001_dian_school',
    profile_id: 'user_1',
    user_id: 'user_1',
    status: 'accepted',
    joined_at: '2026-08-28 08:00:00'
  },
  {
    id: 'tp_002_1',
    task_id: 'task_002_dichvong_site',
    profile_id: 'user_1',
    user_id: 'user_1',
    status: 'in_progress',
    joined_at: '2026-08-28 08:30:00',
    started_at: '2026-08-28 09:00:00'
  },
  {
    id: 'tp_005_1',
    task_id: 'task_005_caugiay_canal',
    profile_id: 'user_1',
    user_id: 'user_1',
    status: 'approved',
    joined_at: '2026-08-25 08:00:00',
    started_at: '2026-08-25 08:30:00',
    submitted_at: '2026-08-25 16:00:00',
    completed_at: '2026-08-25 16:45:00'
  }
];

const SEED_SUBMISSIONS = [
  {
    id: 'sub_005_1',
    task_id: 'task_005_caugiay_canal',
    participant_id: 'tp_005_1',
    user_id: 'user_1',
    image_url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    image_hash: 'SHA256:4C8F92A1E73B9912C889410293021948',
    outcome: 'BETTER',
    notes: 'Dòng mương đã được nạo vét thông thoáng, không còn mùi hôi và rác trôi dạt.',
    latitude: 21.0355,
    longitude: 105.7902,
    status: 'approved',
    review_note: 'Đạt yêu cầu nghiệm thu thực địa',
    reviewed_by: 'staff_1',
    reviewed_at: '2026-08-25 16:45:00',
    submitted_at: '2026-08-25 16:00:00'
  }
];

/**
 * Tự động nạp seed tasks nếu bảng rỗng
 */
export async function ensureSeedTasks(db) {
  try {
    const check = await db.prepare('SELECT COUNT(*) as cnt FROM "tasks"').first().catch(() => ({ cnt: 0 }));
    if (check && check.cnt === 0) {
      for (const t of SEED_TASKS) {
        await db.prepare(`
          INSERT INTO "tasks" (
            "id", "code", "title", "description", "task_type", "source_type",
            "case_id", "site_id", "location_text", "latitude", "longitude",
            "start_at", "due_at", "assignment_type", "assigned_profile_id", "club_id",
            "max_participants", "status", "priority", "points", "contribution_minutes",
            "evidence_instructions", "created_by"
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          t.id, t.code, t.title, t.description, t.task_type, t.source_type,
          t.case_id || null, t.site_id || null, t.location_text, t.latitude, t.longitude,
          t.start_at, t.due_at, t.assignment_type, t.assigned_profile_id || null, t.club_id || null,
          t.max_participants, t.status, t.priority, t.points, t.contribution_minutes,
          t.evidence_instructions, t.created_by
        ).run().catch(() => {});
      }

      for (const p of SEED_PARTICIPANTS) {
        await db.prepare(`
          INSERT INTO "task_participants" ("id", "task_id", "profile_id", "user_id", "status", "joined_at", "started_at", "submitted_at", "completed_at")
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          p.id, p.task_id, p.profile_id, p.user_id, p.status, p.joined_at,
          p.started_at || null, p.submitted_at || null, p.completed_at || null
        ).run().catch(() => {});
      }

      for (const s of SEED_SUBMISSIONS) {
        await db.prepare(`
          INSERT INTO "task_submissions" ("id", "task_id", "participant_id", "user_id", "image_url", "image_hash", "outcome", "notes", "latitude", "longitude", "status", "review_note", "reviewed_by", "reviewed_at", "submitted_at")
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          s.id, s.task_id, s.participant_id, s.user_id, s.image_url, s.image_hash, s.outcome,
          s.notes, s.latitude, s.longitude, s.status, s.review_note, s.reviewed_by, s.reviewed_at, s.submitted_at
        ).run().catch(() => {});
      }
    }
  } catch (err) {
    console.warn('[TaskRepository] ensureSeedTasks notice:', err?.message);
  }
}

/**
 * Lấy danh sách nhiệm vụ với các bộ lọc nghiệp vụ
 */
export async function getTasks(db, {
  status,
  task_type,
  assignment_type,
  campaign_id,
  case_id,
  site_id,
  club_id,
  assigned_profile_id,
  current_user_id,
  current_profile_id,
  current_club_id,
  search,
  include_archived = false,
  limit = 50,
  offset = 0
} = {}) {
  await ensureSeedTasks(db);

  let query = `
    SELECT 
      t.*,
      c.code as case_code,
      c.title as case_title,
      cmp.title as campaign_title,
      cmp.slug as campaign_slug,
      s.name as site_name,
      s.address as site_address,
      clb.name as club_name,
      p.fullName as assigned_name,
      (
        SELECT COUNT(tp.id) 
        FROM "task_participants" tp 
        WHERE tp.task_id = t.id 
          AND tp.status IN ('assigned', 'accepted', 'in_progress', 'submitted', 'revision_requested', 'approved')
      ) as participants_count,
      (
        SELECT COUNT(tp.id) 
        FROM "task_participants" tp 
        WHERE tp.task_id = t.id 
          AND tp.status = 'approved'
      ) as approved_count,
      (
        SELECT COUNT(ts.id)
        FROM "task_submissions" ts
        WHERE ts.task_id = t.id
          AND ts.status = 'submitted'
      ) as pending_submissions_count
  `;

  if (current_profile_id || current_user_id) {
    const pId = current_profile_id || current_user_id;
    query += `,
      (
        SELECT tp.status
        FROM "task_participants" tp
        WHERE tp.task_id = t.id AND (tp.profile_id = '${pId}' OR tp.user_id = '${pId}')
        ORDER BY tp.joined_at DESC LIMIT 1
      ) as my_participation_status,
      (
        SELECT tp.id
        FROM "task_participants" tp
        WHERE tp.task_id = t.id AND (tp.profile_id = '${pId}' OR tp.user_id = '${pId}')
        ORDER BY tp.joined_at DESC LIMIT 1
      ) as my_participant_id
    `;
  }

  query += `
    FROM "tasks" t
    LEFT JOIN "cases" c ON t.case_id = c.id
    LEFT JOIN "campaigns" cmp ON t.campaign_id = cmp.id
    LEFT JOIN "sites" s ON t.site_id = s.id
    LEFT JOIN "communities" clb ON t.club_id = clb.id
    LEFT JOIN "profiles" p ON t.assigned_profile_id = p.id OR t.assigned_profile_id = p.userId
    WHERE (t.deleted_at IS NULL)
  `;

  const params = [];

  if (!include_archived && status !== 'ARCHIVED') {
    query += ` AND (t.status != 'ARCHIVED' OR t.status IS NULL)`;
  }

  if (status) {
    if (status === 'SUBMITTED' || status === 'PENDING_VERIFICATION') {
      query += ` AND (t.status = 'SUBMITTED' OR (
        SELECT COUNT(ts.id) FROM "task_submissions" ts WHERE ts.task_id = t.id AND ts.status = 'submitted'
      ) > 0)`;
    } else {
      query += ` AND t.status = ?`;
      params.push(status);
    }
  }

  if (task_type) {
    query += ` AND t.task_type = ?`;
    params.push(task_type);
  }

  if (assignment_type) {
    query += ` AND t.assignment_type = ?`;
    params.push(assignment_type);
  }

  if (campaign_id) {
    query += ` AND t.campaign_id = ?`;
    params.push(campaign_id);
  }

  if (case_id) {
    query += ` AND t.case_id = ?`;
    params.push(case_id);
  }

  if (site_id) {
    query += ` AND t.site_id = ?`;
    params.push(site_id);
  }

  if (club_id) {
    query += ` AND t.club_id = ?`;
    params.push(club_id);
  }

  if (assigned_profile_id) {
    query += ` AND t.assigned_profile_id = ?`;
    params.push(assigned_profile_id);
  }

  if (search && search.trim()) {
    query += ` AND (
      t.code LIKE ? OR 
      t.title LIKE ? OR 
      t.location_text LIKE ? OR 
      t.description LIKE ?
    )`;
    const term = `%${search.trim()}%`;
    params.push(term, term, term, term);
  }

  query += ` ORDER BY t.created_at DESC LIMIT ? OFFSET ?`;
  params.push(Number(limit), Number(offset));

  const stmt = db.prepare(query);
  const res = params.length > 0 ? await stmt.bind(...params).all() : await stmt.all();
  const items = res?.results || res || [];

  return items;
}

/**
 * Lấy chi tiết một nhiệm vụ kèm nguồn, người tham gia, bằng chứng và timeline
 */
export async function getTaskById(db, id, current_user_id) {
  await ensureSeedTasks(db);

  const query = `
    SELECT 
      t.*,
      c.code as case_code,
      c.title as case_title,
      c.status as case_status,
      cmp.title as campaign_title,
      cmp.slug as campaign_slug,
      s.name as site_name,
      s.address as site_address,
      s.investorName as site_investor,
      clb.name as club_name,
      p.fullName as assigned_name,
      (
        SELECT COUNT(tp.id) 
        FROM "task_participants" tp 
        WHERE tp.task_id = t.id 
          AND tp.status IN ('assigned', 'accepted', 'in_progress', 'submitted', 'revision_requested', 'approved')
      ) as participants_count,
      (
        SELECT COUNT(tp.id) 
        FROM "task_participants" tp 
        WHERE tp.task_id = t.id 
          AND tp.status = 'approved'
      ) as approved_count
    FROM "tasks" t
    LEFT JOIN "cases" c ON t.case_id = c.id
    LEFT JOIN "campaigns" cmp ON t.campaign_id = cmp.id
    LEFT JOIN "sites" s ON t.site_id = s.id
    LEFT JOIN "communities" clb ON t.club_id = clb.id
    LEFT JOIN "profiles" p ON t.assigned_profile_id = p.id OR t.assigned_profile_id = p.userId
    WHERE t.id = ? AND (t.deleted_at IS NULL)
  `;

  const task = await db.prepare(query).bind(id).first();
  if (!task) return null;

  // Lấy danh sách participants
  const participantsQuery = `
    SELECT 
      tp.*,
      COALESCE(p.fullName, u.full_name, 'Tình nguyện viên') as full_name,
      u.email as user_email,
      clb.name as club_name,
      ts.id as latest_submission_id,
      ts.image_url as latest_image_url,
      ts.image_hash as latest_image_hash,
      ts.notes as latest_notes,
      ts.outcome as latest_outcome,
      ts.status as latest_submission_status,
      ts.review_note as latest_review_note,
      ts.submitted_at as latest_submitted_at
    FROM "task_participants" tp
    LEFT JOIN "profiles" p ON tp.profile_id = p.id OR tp.profile_id = p.userId
    LEFT JOIN "users" u ON tp.user_id = u.id OR tp.profile_id = u.id
    LEFT JOIN "communities" clb ON tp.club_id = clb.id
    LEFT JOIN (
      SELECT * FROM "task_submissions" 
      WHERE task_id = ? 
      ORDER BY submitted_at DESC
    ) ts ON ts.participant_id = tp.id
    WHERE tp.task_id = ?
    GROUP BY tp.id
    ORDER BY tp.joined_at ASC
  `;

  const pRes = await db.prepare(participantsQuery).bind(id, id).all();
  task.participants = pRes?.results || pRes || [];

  // Lấy danh sách submissions
  const submissionsQuery = `
    SELECT 
      ts.*,
      COALESCE(p.fullName, u.full_name, 'Tình nguyện viên') as author_name,
      u.email as author_email
    FROM "task_submissions" ts
    LEFT JOIN "profiles" p ON ts.user_id = p.id OR ts.user_id = p.userId
    LEFT JOIN "users" u ON ts.user_id = u.id
    WHERE ts.task_id = ?
    ORDER BY ts.submitted_at DESC
  `;
  const sRes = await db.prepare(submissionsQuery).bind(id).all();
  task.submissions = sRes?.results || sRes || [];

  // Lấy danh sách timeline events
  const timelineQuery = `
    SELECT * FROM "task_timelines"
    WHERE task_id = ?
    ORDER BY created_at DESC
  `;
  const tRes = await db.prepare(timelineQuery).bind(id).all();
  task.timelines = tRes?.results || tRes || [];

  // Xác định trạng thái của user hiện tại
  if (current_user_id) {
    const myP = task.participants.find(p => p.profile_id === current_user_id || p.user_id === current_user_id);
    task.my_participation = myP || null;
  }

  return task;
}

/**
 * Tạo mới một nhiệm vụ thực địa (Staff / Admin)
 */
export async function createTask(db, data, actor = {}) {
  const id = data.id || `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const code = data.code || `TASK-${getVNTodayStr().slice(0, 4)}-${Math.floor(100 + Math.random() * 900)}`;

  const {
    title,
    description = '',
    task_type = 'field_verification',
    source_type = 'none',
    source_id = null,
    campaign_id = null,
    case_id = null,
    site_id = null,
    observation_id = null,
    location_text,
    latitude = null,
    longitude = null,
    start_at = null,
    due_at = null,
    assignment_type = 'open',
    assigned_profile_id = null,
    club_id = null,
    max_participants = 10,
    status = 'OPEN',
    priority = 'MEDIUM',
    points = 20,
    contribution_minutes = 30,
    evidence_instructions = ''
  } = data;

  if (!title || !location_text) {
    throw new Error('Tên nhiệm vụ và Địa bàn thực địa là bắt buộc.');
  }

  const created_by = actor.email || actor.id || 'staff_system';
  const now = getVNNowStr();

  const insertSql = `
    INSERT INTO "tasks" (
      "id", "code", "title", "description", "task_type", "source_type",
      "source_id", "campaign_id", "case_id", "site_id", "observation_id",
      "location_text", "latitude", "longitude", "start_at", "due_at",
      "assignment_type", "assigned_profile_id", "club_id", "max_participants",
      "status", "priority", "points", "contribution_minutes", "evidence_instructions",
      "created_by", "created_at", "updated_at"
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  await db.prepare(insertSql).bind(
    id, code, title, description, task_type, source_type,
    source_id, campaign_id, case_id, site_id, observation_id,
    location_text, latitude, longitude, start_at, due_at,
    assignment_type, assigned_profile_id, club_id, Number(max_participants),
    status, priority, Number(points), Number(contribution_minutes), evidence_instructions,
    created_by, now, now
  ).run();

  // Nếu giao cho cá nhân cụ thể, tạo participant record ban đầu
  if (assignment_type === 'individual' && assigned_profile_id) {
    const tpId = `tp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await db.prepare(`
      INSERT INTO "task_participants" ("id", "task_id", "profile_id", "user_id", "status", "joined_at")
      VALUES (?, ?, ?, ?, 'assigned', ?)
    `).bind(tpId, id, assigned_profile_id, assigned_profile_id, now).run().catch(() => {});
  }

  // Ghi timeline
  await logTaskTimeline(db, {
    task_id: id,
    event_type: 'TASK_CREATED',
    actor_id: actor.id || 'staff_system',
    actor_name: actor.name || actor.email || 'Cán bộ điều phối',
    actor_role: actor.role || 'staff',
    description: `Nhiệm vụ "${title}" đã được tạo thành công với hình thức giao: ${assignment_type.toUpperCase()}.`
  });

  // Ghi audit log
  await createAuditLog(db, {
    user_email: actor.email || 'staff@dustguard.vn',
    user_role: actor.role || 'staff',
    action: 'CREATE_TASK',
    module: 'tasks',
    target_id: id,
    new_values: { id, code, title, assignment_type, points }
  });

  return getTaskById(db, id);
}

/**
 * Cập nhật thông tin nhiệm vụ (Staff / Admin)
 */
export async function updateTask(db, id, data, actor = {}) {
  const existing = await getTaskById(db, id);
  if (!existing) throw new Error('Không tìm thấy nhiệm vụ.');

  const now = getVNNowStr();

  const updateFields = [];
  const params = [];

  const allowedFields = [
    'title', 'description', 'task_type', 'source_type', 'source_id',
    'campaign_id', 'case_id', 'site_id', 'observation_id',
    'location_text', 'latitude', 'longitude', 'start_at', 'due_at',
    'assignment_type', 'assigned_profile_id', 'club_id', 'max_participants',
    'status', 'priority', 'points', 'contribution_minutes', 'evidence_instructions'
  ];

  for (const field of allowedFields) {
    if (data[field] !== undefined) {
      updateFields.push(`"${field}" = ?`);
      params.push(data[field]);
    }
  }

  updateFields.push(`"updated_at" = ?`);
  params.push(now);

  params.push(id);

  const sql = `UPDATE "tasks" SET ${updateFields.join(', ')} WHERE id = ?`;
  await db.prepare(sql).bind(...params).run();

  await logTaskTimeline(db, {
    task_id: id,
    event_type: 'TASK_EDITED',
    actor_id: actor.id || 'staff_system',
    actor_name: actor.name || actor.email || 'Cán bộ điều phối',
    actor_role: actor.role || 'staff',
    description: `Thông tin nhiệm vụ đã được cập nhật.`
  });

  return getTaskById(db, id);
}

/**
 * Lưu trữ nhiệm vụ (Archive)
 */
export async function archiveTask(db, id, actor = {}) {
  const now = getVNNowStr();
  await db.prepare(`
    UPDATE "tasks" 
    SET "status" = 'ARCHIVED', "archived_at" = ?, "updated_at" = ?
    WHERE id = ?
  `).bind(now, now, id).run();

  await logTaskTimeline(db, {
    task_id: id,
    event_type: 'TASK_ARCHIVED',
    actor_id: actor.id || 'staff_system',
    actor_name: actor.name || actor.email || 'Cán bộ điều phối',
    actor_role: actor.role || 'staff',
    description: `Nhiệm vụ đã được lưu trữ (Archived).`
  });

  return { success: true, id, status: 'ARCHIVED' };
}

/**
 * Tình nguyện viên nhận việc (Join Task)
 */
export async function joinTask(db, taskId, { user_id, profile_id, club_id, full_name } = {}) {
  const task = await getTaskById(db, taskId);
  if (!task) throw new Error('Nhiệm vụ không tồn tại.');

  if (task.status === 'ARCHIVED' || task.status === 'COMPLETED' || task.status === 'CANCELLED') {
    throw new Error(`Nhiệm vụ hiện ở trạng thái "${task.status}", không thể nhận việc.`);
  }

  // Kiểm tra hạn chót nếu có
  if (task.due_at) {
    const dueTime = new Date(task.due_at).getTime();
    if (dueTime < Date.now()) {
      throw new Error('Nhiệm vụ đã quá hạn hoàn thành.');
    }
  }

  // Kiểm tra quota số người tối đa
  const countRow = await db.prepare(`
    SELECT COUNT(id) as cnt FROM "task_participants" 
    WHERE task_id = ? AND status IN ('assigned', 'accepted', 'in_progress', 'submitted', 'revision_requested', 'approved')
  `).bind(taskId).first();
  const currentCount = countRow?.cnt || 0;

  if (task.max_participants && currentCount >= task.max_participants) {
    throw new Error('Nhiệm vụ đã đủ số người tham gia.');
  }

  const pId = profile_id || user_id;
  if (!pId) throw new Error('Cần đăng nhập để nhận nhiệm vụ.');

  // Kiểm tra phân quyền giao việc
  if (task.assignment_type === 'individual') {
    if (task.assigned_profile_id && task.assigned_profile_id !== pId) {
      throw new Error('Nhiệm vụ này được giao riêng cho một cá nhân khác.');
    }
  } else if (task.assignment_type === 'club') {
    if (task.club_id) {
      // Kiểm tra xem user có thuộc club này không
      const memberRow = await db.prepare(`
        SELECT COUNT(id) as cnt FROM "community_memberships" 
        WHERE club_id = ? AND (profile_id = ? OR user_id = ?) AND status = 'ACTIVE'
      `).bind(task.club_id, pId, user_id || pId).first().catch(() => ({ cnt: 1 })); // fallback lenient
      
      const isClubMember = (memberRow?.cnt || 0) > 0 || (club_id === task.club_id);
      if (!isClubMember) {
        throw new Error(`Nhiệm vụ này chỉ dành riêng cho thành viên của "${task.club_name || 'CLB phụ trách'}".`);
      }
    }
  }

  // Kiểm tra xem user đã tham gia chưa
  const existingPart = await db.prepare(`
    SELECT * FROM "task_participants" 
    WHERE task_id = ? AND (profile_id = ? OR user_id = ?)
  `).bind(taskId, pId, user_id || pId).first();

  const now = getVNNowStr();

  let participantId;
  if (existingPart) {
    if (existingPart.status !== 'withdrawn' && existingPart.status !== 'assigned') {
      throw new Error('Bạn đã nhận nhiệm vụ này rồi.');
    }
    // Cập nhật lại status
    await db.prepare(`
      UPDATE "task_participants" 
      SET status = 'accepted', joined_at = ?, club_id = ? 
      WHERE id = ?
    `).bind(now, club_id || task.club_id || null, existingPart.id).run();
    participantId = existingPart.id;
  } else {
    participantId = `tp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await db.prepare(`
      INSERT INTO "task_participants" ("id", "task_id", "profile_id", "user_id", "club_id", "status", "joined_at")
      VALUES (?, ?, ?, ?, ?, 'accepted', ?)
    `).bind(participantId, taskId, pId, user_id || pId, club_id || task.club_id || null, now).run();
  }

  await logTaskTimeline(db, {
    task_id: taskId,
    event_type: 'USER_JOINED',
    actor_id: pId,
    actor_name: full_name || 'Tình nguyện viên',
    actor_role: 'volunteer',
    description: `Tình nguyện viên "${full_name || pId}" đã nhận nhiệm vụ.`
  });

  return { success: true, participantId, taskId, status: 'accepted' };
}

/**
 * Tình nguyện viên bắt đầu thực hiện nhiệm vụ (Start Task)
 */
export async function startTask(db, taskId, { user_id, profile_id } = {}) {
  const pId = profile_id || user_id;
  const part = await db.prepare(`
    SELECT * FROM "task_participants" 
    WHERE task_id = ? AND (profile_id = ? OR user_id = ?)
  `).bind(taskId, pId, user_id || pId).first();

  if (!part) {
    throw new Error('Bạn chưa nhận nhiệm vụ này.');
  }

  const now = getVNNowStr();
  await db.prepare(`
    UPDATE "task_participants" 
    SET status = 'in_progress', started_at = ? 
    WHERE id = ?
  `).bind(now, part.id).run();

  await db.prepare(`
    UPDATE "tasks" 
    SET status = 'IN_PROGRESS', updated_at = ? 
    WHERE id = ? AND status = 'OPEN'
  `).bind(now, taskId).run();

  await logTaskTimeline(db, {
    task_id: taskId,
    event_type: 'USER_STARTED',
    actor_id: pId,
    actor_name: 'Tình nguyện viên',
    actor_role: 'volunteer',
    description: `Tình nguyện viên đã bắt đầu thực hiện nhiệm vụ ngoài hiện trường.`
  });

  return { success: true, taskId, participantId: part.id, status: 'in_progress' };
}

/**
 * Nộp kết quả / minh chứng thực địa (Submit Task Proof)
 */
export async function submitTaskProof(db, taskId, {
  user_id,
  profile_id,
  image_url,
  image_hash,
  outcome = 'BETTER',
  notes = '',
  latitude = null,
  longitude = null
} = {}) {
  const pId = profile_id || user_id;
  if (!pId) throw new Error('Cần đăng nhập để nộp minh chứng.');

  let part = await db.prepare(`
    SELECT * FROM "task_participants" 
    WHERE task_id = ? AND (profile_id = ? OR user_id = ?)
  `).bind(taskId, pId, user_id || pId).first();

  const now = getVNNowStr();

  // Nếu chưa join thì tự động join luôn
  if (!part) {
    const tpId = `tp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await db.prepare(`
      INSERT INTO "task_participants" ("id", "task_id", "profile_id", "user_id", "status", "joined_at", "started_at")
      VALUES (?, ?, ?, ?, 'in_progress', ?, ?)
    `).bind(tpId, taskId, pId, user_id || pId, now, now).run();
    part = { id: tpId };
  }

  const subId = `sub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const hash = image_hash || `SHA256:${Math.random().toString(16).slice(2, 10).toUpperCase()}-9F8E-2026`;

  await db.prepare(`
    INSERT INTO "task_submissions" (
      "id", "task_id", "participant_id", "user_id", "image_url", "image_hash",
      "outcome", "notes", "latitude", "longitude", "status", "submitted_at"
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted', ?)
  `).bind(
    subId, taskId, part.id, user_id || pId, image_url || '', hash,
    outcome, notes, latitude, longitude, now
  ).run();

  await db.prepare(`
    UPDATE "task_participants" 
    SET status = 'submitted', submitted_at = ? 
    WHERE id = ?
  `).bind(now, part.id).run();

  await db.prepare(`
    UPDATE "tasks" 
    SET status = 'SUBMITTED', updated_at = ? 
    WHERE id = ? AND status != 'COMPLETED'
  `).bind(now, taskId).run();

  await logTaskTimeline(db, {
    task_id: taskId,
    event_type: 'SUBMISSION_SENT',
    actor_id: pId,
    actor_name: 'Tình nguyện viên',
    actor_role: 'volunteer',
    description: `Đã nộp minh chứng thực địa (Hash: ${hash.slice(0, 16)}...). Trạng thái: Chờ xác minh.`
  });

  return {
    success: true,
    submissionId: subId,
    taskId,
    participantId: part.id,
    status: 'submitted',
    hash
  };
}

/**
 * Cán bộ duyệt nghiệm thu kết quả (Approve Submission)
 * Tự động ghi nhận giờ đóng góp và điểm rèn luyện thật vào DB SSOT!
 */
export async function approveSubmission(db, submissionId, { reviewer_id, reviewer_name, review_note = '' } = {}) {
  const sub = await db.prepare(`
    SELECT ts.*, t.title as task_title, t.points, t.contribution_minutes, t.campaign_id, t.case_id
    FROM "task_submissions" ts
    JOIN "tasks" t ON ts.task_id = t.id
    WHERE ts.id = ?
  `).bind(submissionId).first();

  if (!sub) throw new Error('Không tìm thấy kết quả nộp.');

  const now = getVNNowStr();

  // 1. Cập nhật submission status = 'approved'
  await db.prepare(`
    UPDATE "task_submissions" 
    SET status = 'approved', review_note = ?, reviewed_by = ?, reviewed_at = ? 
    WHERE id = ?
  `).bind(review_note || 'Đạt yêu cầu nghiệm thu', reviewer_id || 'staff_system', now, submissionId).run();

  // 2. Cập nhật participant status = 'approved', completed_at = now
  await db.prepare(`
    UPDATE "task_participants" 
    SET status = 'approved', completed_at = ? 
    WHERE id = ?
  `).bind(now, sub.participant_id).run();

  // 3. Tự động ghi nhận đóng góp thật vào youth_activities
  const actId = `ya_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const minutes = sub.contribution_minutes || 30;
  await db.prepare(`
    INSERT INTO "youth_activities" (
      "id", "user_id", "activity_type", "campaign_id", "minutes",
      "evidence_url", "validated_by", "validation_status", "occurred_at"
    ) VALUES (?, ?, 'FIELD_TASK', ?, ?, ?, ?, 'VALIDATED', ?)
  `).bind(
    actId, sub.user_id, sub.campaign_id || null, minutes,
    sub.image_url || null, reviewer_id || 'staff_system', now
  ).run().catch(err => console.warn('[TaskRepository] youth_activities insert notice:', err?.message));

  // 4. Ghi nhận impact_events
  const impId = `imp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const points = sub.points || 20;
  await db.prepare(`
    INSERT INTO "impact_events" (
      "id", "eventType", "campaignId", "userId", "pointsAwarded", "details"
    ) VALUES (?, 'TASK_APPROVED', ?, ?, ?, ?)
  `).bind(
    impId, sub.campaign_id || null, sub.user_id, points,
    `Hoàn thành nhiệm vụ: ${sub.task_title}`
  ).run().catch(err => console.warn('[TaskRepository] impact_events insert notice:', err?.message));

  // 5. Kiểm tra nếu không còn submission nào pending, chuyển task status = 'COMPLETED'
  const pendingCountRow = await db.prepare(`
    SELECT COUNT(id) as cnt FROM "task_submissions" 
    WHERE task_id = ? AND status = 'submitted'
  `).bind(sub.task_id).first();

  if ((pendingCountRow?.cnt || 0) === 0) {
    await db.prepare(`
      UPDATE "tasks" SET status = 'COMPLETED', updated_at = ? WHERE id = ?
    `).bind(now, sub.task_id).run();
  }

  // 6. Ghi timeline
  await logTaskTimeline(db, {
    task_id: sub.task_id,
    event_type: 'SUBMISSION_APPROVED',
    actor_id: reviewer_id || 'staff_system',
    actor_name: reviewer_name || 'Cán bộ nghiệm thu',
    actor_role: 'staff',
    description: `Minh chứng đã được CHẤP NHẬN NGHIỆM THU. Ghi nhận +${points} pts & ${minutes} phút tình nguyện cho người thực hiện.`
  });

  return {
    success: true,
    submissionId,
    taskId: sub.task_id,
    status: 'approved',
    pointsAwarded: points,
    minutesAwarded: minutes
  };
}

/**
 * Cán bộ yêu cầu làm lại / bổ sung minh chứng (Request Revision)
 */
export async function requestRevision(db, submissionId, { reviewer_id, reviewer_name, review_note } = {}) {
  if (!review_note || !review_note.trim()) {
    throw new Error('Vui lòng nhập lý do yêu cầu bổ sung / làm lại minh chứng.');
  }

  const sub = await db.prepare(`SELECT * FROM "task_submissions" WHERE id = ?`).bind(submissionId).first();
  if (!sub) throw new Error('Không tìm thấy kết quả nộp.');

  const now = getVNNowStr();

  // 1. Cập nhật submission status = 'revision_requested'
  await db.prepare(`
    UPDATE "task_submissions" 
    SET status = 'revision_requested', review_note = ?, reviewed_by = ?, reviewed_at = ? 
    WHERE id = ?
  `).bind(review_note.trim(), reviewer_id || 'staff_system', now, submissionId).run();

  // 2. Cập nhật participant status = 'revision_requested'
  await db.prepare(`
    UPDATE "task_participants" 
    SET status = 'revision_requested', revision_notes = ? 
    WHERE id = ?
  `).bind(review_note.trim(), sub.participant_id).run();

  // 3. Đổi task status về IN_PROGRESS
  await db.prepare(`
    UPDATE "tasks" SET status = 'IN_PROGRESS', updated_at = ? WHERE id = ?
  `).bind(now, sub.task_id).run();

  // 4. Ghi timeline
  await logTaskTimeline(db, {
    task_id: sub.task_id,
    event_type: 'REVISION_REQUESTED',
    actor_id: reviewer_id || 'staff_system',
    actor_name: reviewer_name || 'Cán bộ thẩm định',
    actor_role: 'staff',
    description: `Yêu cầu làm lại minh chứng: "${review_note.trim()}".`
  });

  return {
    success: true,
    submissionId,
    taskId: sub.task_id,
    status: 'revision_requested',
    reviewNote: review_note.trim()
  };
}

/**
 * Lấy các chỉ số Counters cho Header Dashboard Backoffice
 */
export async function getTaskCounters(db) {
  await ensureSeedTasks(db);

  const now = getVNNowStr();

  const counts = await db.prepare(`
    SELECT
      COUNT(CASE WHEN status = 'OPEN' THEN 1 END) as count_open,
      COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as count_in_progress,
      COUNT(CASE WHEN status = 'SUBMITTED' OR (
        SELECT COUNT(ts.id) FROM "task_submissions" ts WHERE ts.task_id = t.id AND ts.status = 'submitted'
      ) > 0 THEN 1 END) as count_pending_verification,
      COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) as count_completed,
      COUNT(CASE WHEN due_at IS NOT NULL AND due_at < ? AND status NOT IN ('COMPLETED', 'ARCHIVED') THEN 1 END) as count_overdue,
      COUNT(id) as count_total
    FROM "tasks" t
    WHERE deleted_at IS NULL AND (status != 'ARCHIVED' OR status IS NULL)
  `).bind(now).first().catch(() => ({
    count_open: 0,
    count_in_progress: 0,
    count_pending_verification: 0,
    count_completed: 0,
    count_overdue: 0,
    count_total: 0
  }));

  return {
    open: counts?.count_open || 0,
    in_progress: counts?.count_in_progress || 0,
    pending_verification: counts?.count_pending_verification || 0,
    completed: counts?.count_completed || 0,
    overdue: counts?.count_overdue || 0,
    total: counts?.count_total || 0
  };
}

/**
 * Helper ghi nhận lịch sử timeline cho Task
 */
async function logTaskTimeline(db, { task_id, event_type, actor_id, actor_name, actor_role, description, metadata_json = null }) {
  const id = `ttl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const now = getVNNowStr();

  await db.prepare(`
    INSERT INTO "task_timelines" ("id", "task_id", "event_type", "actor_id", "actor_name", "actor_role", "description", "metadata_json", "created_at")
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    id, task_id, event_type, actor_id || null, actor_name || null,
    actor_role || null, description || '', metadata_json ? JSON.stringify(metadata_json) : null, now
  ).run().catch(err => console.warn('[TaskRepository] logTaskTimeline notice:', err?.message));
}
