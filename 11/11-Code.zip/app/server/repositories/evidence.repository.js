import { prisma, getDbClient } from '../shared/db.js';
import { createAuditLog } from './audit.repository.js';

export async function createEvidence(data, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.evidence) ? envOrDb : getDbClient(envOrDb);
  
  const evidence = await client.evidence.create({
    data: {
      url: data.url,
      type: data.type || 'IMAGE',
      filename: data.filename || null,
      mimeType: data.mimeType || data.contentType || 'image/jpeg',
      fileSize: data.fileSize || data.size || null,
      sha256: data.sha256 || null,
      uploadedBy: actor.id || actor.name || data.uploadedBy || null,
      complaintId: data.complaintId || null,
      inspectionId: data.inspectionId || null,
      caseId: data.caseId || null
    }
  });

  await createAuditLog({
    action: 'EVIDENCE_ADDED',
    entityType: 'EVIDENCE',
    entityId: evidence.id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'citizen',
    afterJson: evidence
  }, envOrDb);

  return evidence;
}

export async function getEvidenceById(id, envOrDb) {
  const client = (envOrDb && envOrDb.evidence) ? envOrDb : getDbClient(envOrDb);
  return client.evidence.findFirst({
    where: { id, deletedAt: null }
  });
}

export async function getEvidencesByCase(caseId, envOrDb, options = {}) {
  const client = (envOrDb && envOrDb.evidence) ? envOrDb : getDbClient(envOrDb);
  const take = Math.min(Math.max(options.take || options.limit || 50, 1), 100);
  return client.evidence.findMany({
    where: { caseId, deletedAt: null },
    orderBy: { createdAt: 'desc' },
    take
  });
}

export async function softDeleteEvidence(id, actor = {}, envOrDb) {
  const client = (envOrDb && envOrDb.evidence) ? envOrDb : getDbClient(envOrDb);
  const current = await client.evidence.findUnique({ where: { id } });
  if (!current) return null;

  const updated = await client.evidence.update({
    where: { id },
    data: { deletedAt: new Date() }
  });

  await createAuditLog({
    action: 'EVIDENCE_REMOVED',
    entityType: 'EVIDENCE',
    entityId: id,
    actorId: actor.id || null,
    actorName: actor.name || null,
    actorRole: actor.role || 'staff',
    beforeJson: current,
    afterJson: updated
  }, envOrDb);

  return updated;
}
