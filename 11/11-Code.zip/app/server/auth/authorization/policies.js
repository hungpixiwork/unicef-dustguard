/**
 * DustGuard VN - Domain Authorization Policies & Access Control
 * Implements Resource-level ownership, multi-tenancy isolation, and RBAC policies.
 */

import { ROLES } from '../roles.js';

/**
 * Filter records by user organization (Horizontal isolation)
 * @param {import('../human/identity-context.js').IdentityContext | Object} user
 * @param {Array<Object>} records
 * @returns {Array<Object>}
 */
export function scopeByOrganization(user, records) {
  if (!user) return [];
  if (!Array.isArray(records)) return [];
  if (user.role === ROLES.ADMIN || user.role === ROLES.SUPER_ADMIN || user.isAdmin?.()) {
    return records;
  }
  const orgId = user.organizationId || user.orgId;
  if (!orgId) return records;

  return records.filter(r => !r.organizationId || r.organizationId === orgId);
}

/**
 * Check if identity can view a specific site
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} site
 * @returns {boolean}
 */
export function canViewSite(identity, site) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin()) return true;
  if (!site) return false;

  // Public sites or same organization
  if (!site.organizationId) return true;
  if (identity.organizationId && site.organizationId === identity.organizationId) {
    return true;
  }
  // Staff/Inspector from government agencies have city-wide access
  if (identity.isStaff() || identity.isInspector()) {
    return true;
  }
  return false;
}

/**
 * Check if identity can review an observation report
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} observation
 * @returns {boolean}
 */
export function canReviewObservation(identity, observation) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin()) return true;
  if (identity.isStaff() || identity.isInspector() || identity.isExecutive()) return true;

  // Youth members can review community observations in their club
  if (identity.isYouth() && observation?.communityId && identity.metadata?.communityId === observation.communityId) {
    return true;
  }

  return false;
}

/**
 * Check if identity can close an incident / case
 * Only Inspector or Executive or Admin can officially close cases
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} caseRecord
 * @returns {boolean}
 */
export function canCloseIncident(identity, caseRecord) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin()) return true;
  if (identity.isExecutive() || identity.isInspector()) return true;
  return false;
}

/**
 * Check if identity can manage sensor configuration
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} sensor
 * @returns {boolean}
 */
export function canManageSensor(identity, sensor) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin()) return true;
  return false;
}

/**
 * Check if identity can access restricted/private evidence
 * Prevents horizontal privilege escalation (User A viewing User B's private unverified evidence)
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} evidence
 * @returns {boolean}
 */
export function canViewEvidence(identity, evidence) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin() || identity.isStaff() || identity.isInspector()) return true;
  if (!evidence) return false;

  // Public/verified evidence can be viewed by all authenticated users
  if (evidence.isPublic || evidence.status === 'VERIFIED') return true;

  // Owner can view own evidence
  const ownerId = evidence.uploaderId || evidence.userId || evidence.reporterId;
  if (ownerId && (ownerId === identity.userId || ownerId === identity.clerkUserId)) {
    return true;
  }

  return false;
}

/**
 * Check case access permissions
 * @param {import('../human/identity-context.js').IdentityContext} identity
 * @param {Object} caseRecord
 * @returns {boolean}
 */
export function canAccessCase(identity, caseRecord) {
  if (!identity || identity.disabled) return false;
  if (identity.isAdmin() || identity.isStaff() || identity.isInspector() || identity.isExecutive()) {
    return true;
  }
  if (!caseRecord) return false;

  // Contractor assigned to case
  if (identity.isContractor()) {
    return caseRecord.contractorId === identity.userId || caseRecord.siteId === identity.organizationId;
  }

  // Citizen who created the underlying complaint
  if (identity.isCitizen()) {
    return caseRecord.reporterId === identity.userId || caseRecord.reporterId === identity.clerkUserId;
  }

  return false;
}
