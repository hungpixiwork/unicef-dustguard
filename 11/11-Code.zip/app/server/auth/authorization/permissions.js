/**
 * DustGuard VN - Single Source of Truth for Permissions
 */

export const PERMISSIONS = Object.freeze({
  // Observation & Reporting
  OBSERVATION_CREATE: 'observation:create',
  OBSERVATION_VIEW_OWN: 'observation:view_own',
  OBSERVATION_VIEW_PUBLIC: 'observation:view_public',
  OBSERVATION_REVIEW: 'observation:review',
  OBSERVATION_ASSIGN: 'observation:assign',

  // Case & Incident Management
  CASE_VIEW: 'case:view',
  CASE_CREATE: 'case:create',
  CASE_TRANSITION: 'case:transition',
  CASE_INSPECT: 'case:inspect',
  CASE_CLOSE: 'case:close',
  SANCTION_APPROVE: 'sanction:approve',

  // Sites
  SITE_VIEW: 'site:view',
  SITE_CREATE: 'site:create',
  SITE_EDIT: 'site:edit',
  SITE_DELETE: 'site:delete',

  // Sensors & Telemetry
  SENSOR_VIEW: 'sensor:view',
  SENSOR_MANAGE: 'sensor:manage',
  TELEMETRY_INGEST: 'telemetry:ingest',

  // Evidence
  EVIDENCE_UPLOAD: 'evidence:upload',
  EVIDENCE_VIEW_PUBLIC: 'evidence:view_public',
  EVIDENCE_VIEW_RESTRICTED: 'evidence:view_restricted',

  // System & Governance
  SYSTEM_RESET: 'system:reset',
  AUDIT_LOG_VIEW: 'audit_log:view',
  USER_MANAGE: 'user:manage',
});
