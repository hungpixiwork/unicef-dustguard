/**
 * DustGuard VN - IoT Device Authentication & Signature Verification Engine
 * 
 * Invariants:
 * 1. Independent from Human Auth (Clerk / Better Auth). Zero Clerk tokens required.
 * 2. Cryptographic HMAC-SHA256 signature verification matching ESP32 firmware.
 * 3. Physical bounds validation (0 - 2500 µg/m³).
 * 4. Timestamp clock drift validation (+/- 5 minutes).
 * 5. Sliding-window Nonce / Signature Replay Attack Protection.
 * 6. Generates standardized DeviceContext for downstream domain ingestion.
 */

import { verifyTelemetrySignature, verifyTelemetrySignatureAsync } from './hmac.js';
import { defaultReplayProtector, ReplayProtector, validateDeviceReplay } from './replay-protection.js';
import { DataQualityEngine } from '../../domain/sensors/data-quality.engine.js';
import { MEASUREMENT_PHYSICAL_BOUNDS } from '../../domain/sensors/sensor.rules.js';

export class DeviceContext {
  /**
   * @param {Object} params
   * @param {string} params.deviceId - Sensor hardware code (e.g. SENSOR-VD1-01)
   * @param {boolean} [params.authenticated=true]
   * @param {string} [params.authType='device_hmac']
   * @param {string} [params.timestamp]
   * @param {string} [params.firmwareVersion]
   * @param {string} [params.sensorId]
   * @param {string} [params.siteId]
   * @param {boolean} [params.isExperimental=false]
   * @param {string} [params.deviceType='SOLAR_POLE']
   * @param {string} [params.hardwareProfile='DUSTGUARD_SOLAR_V1']
   * @param {string} [params.calibrationStatus='CALIBRATED']
   * @param {number} [params.sequenceNumber=null]
   */
  constructor({
    deviceId,
    authenticated = true,
    authType = 'device_hmac',
    timestamp = new Date().toISOString(),
    firmwareVersion = null,
    sensorId = null,
    siteId = null,
    isExperimental = false,
    deviceType = 'SOLAR_POLE',
    hardwareProfile = 'DUSTGUARD_SOLAR_V1',
    calibrationStatus = 'CALIBRATED',
    sequenceNumber = null
  }) {
    this.deviceId = deviceId;
    this.authenticated = authenticated;
    this.authType = authType;
    this.timestamp = timestamp;
    this.firmwareVersion = firmwareVersion;
    this.sensorId = sensorId;
    this.siteId = siteId;
    this.isExperimental = isExperimental;
    this.deviceType = deviceType;
    this.hardwareProfile = hardwareProfile;
    this.calibrationStatus = calibrationStatus;
    this.sequenceNumber = sequenceNumber;
  }
}

/**
 * Resolves the IoT secret key from options or environment variables.
 * @param {Object} [env]
 * @returns {string}
 */
export function getDeviceSecretKey(env = {}) {
  return (
    env?.IOT_PRE_SHARED_KEY ||
    env?.SIGNATURE_SECRET ||
    process?.env?.IOT_PRE_SHARED_KEY ||
    process?.env?.SIGNATURE_SECRET ||
    ''
  );
}

/**
 * Core device authentication and payload integrity verification function.
 * @param {Object} payload
 * @param {string} payload.sensorCode - Sensor identifier
 * @param {number|string} payload.pm10 - PM10 reading value
 * @param {number|string} payload.pm25 - PM2.5 reading value
 * @param {number|string} [payload.pm1] - Optional PM1.0 reading value
 * @param {number|string} [payload.temp] - Optional Temperature value (°C)
 * @param {number|string} [payload.humidity] - Optional Relative Humidity value (%)
 * @param {string|number} payload.timestamp - ISO timestamp from device RTC
 * @param {string} payload.signature - Cryptographic HMAC-SHA256 signature
 * @param {string} [payload.nonce] - Optional unique transaction nonce
 * @param {number} [payload.seq] - Optional sequence counter
 * @param {number} [payload.sequenceNumber] - Optional sequence counter
 * @param {string} [payload.tag] - Optional tier/tag (EXPERIMENTAL, PRODUCTION)
 * @param {string} [payload.deviceType] - Optional device type
 * @param {Object} [options]
 * @param {string} [options.secretKey] - Custom secret key override
 * @param {ReplayProtector} [options.replayProtector] - Custom replay protector instance
 * @param {number} [options.maxDriftMs=300000] - Clock drift window (5 mins)
 * @param {boolean} [options.skipReplay=false] - For specialized dry-run / audit
 * @returns {{
 *   authenticated: boolean,
 *   statusCode: number,
 *   deviceContext?: DeviceContext,
 *   error?: string,
 *   code?: string,
 *   parsedValues?: {
 *     numPm10: number,
 *     numPm25: number,
 *     numPm1: number|null,
 *     numTemp: number|null,
 *     numHumidity: number|null,
 *     seq: number|null,
 *     isExperimental: boolean,
 *     reqTimeIso: string
 *   }
 * }}
 */
export function verifyDeviceAuth(payload = {}, options = {}) {
  const {
    sensorCode,
    deviceId,
    pm10,
    pm25,
    pm1,
    temp,
    temperature,
    humidity,
    timestamp,
    signature,
    nonce,
    seq,
    sequenceNumber,
    tag,
    tier,
    isExperimental: explicitExp,
    deviceType,
    hardwareProfile
  } = payload;

  const targetCode = sensorCode || deviceId;

  // 1. Check required fields
  if (!targetCode || pm10 === undefined || pm25 === undefined || !timestamp || !signature) {
    return {
      authenticated: false,
      statusCode: 400,
      code: 'MISSING_FIELDS',
      error: 'Missing required fields: sensorCode, pm10, pm25, timestamp, signature'
    };
  }

  // 2. Validate physical sensor bounds across all reported channels
  const numPm25 = parseFloat(pm25);
  const numPm10 = parseFloat(pm10);
  const numPm1 = pm1 !== undefined && pm1 !== null ? parseFloat(pm1) : null;
  const rawTemp = temp !== undefined ? temp : temperature;
  const numTemp = rawTemp !== undefined && rawTemp !== null ? parseFloat(rawTemp) : null;
  const numHumidity = humidity !== undefined && humidity !== null ? parseFloat(humidity) : null;
  const seqNum = seq !== undefined ? Number(seq) : (sequenceNumber !== undefined ? Number(sequenceNumber) : null);

  const boundsCheck = DataQualityEngine.validatePhysicalBounds({
    pm1: numPm1,
    pm25: numPm25,
    pm10: numPm10,
    temp: numTemp,
    humidity: numHumidity
  });

  if (!boundsCheck.passed) {
    return {
      authenticated: false,
      statusCode: 400,
      code: 'OUT_OF_BOUNDS',
      error: `Telemetry reading values are out of physical sensor bounds: ${boundsCheck.violations.map(v => v.reason).join(', ')}`
    };
  }

  // 3. Resolve IoT Pre-Shared Secret
  const secretKey = options.secretKey || getDeviceSecretKey(options.env);
  if (!secretKey) {
    return {
      authenticated: false,
      statusCode: 500,
      code: 'SERVER_CONFIG_ERROR',
      error: 'Server misconfiguration: IOT_PRE_SHARED_KEY not set'
    };
  }

  // 4. Verify Cryptographic HMAC Signature
  const isSigValid = verifyTelemetrySignature(
    {
      sensorCode: targetCode,
      pm10,
      pm25,
      pm1,
      temp: rawTemp,
      humidity,
      timestamp,
      nonce,
      seq: seqNum
    },
    signature,
    secretKey
  );

  if (!isSigValid) {
    return {
      authenticated: false,
      statusCode: 403,
      code: 'INVALID_SIGNATURE',
      error: 'Forbidden: Invalid signature'
    };
  }

  // 5. Check Timestamp Clock Drift, Replay Protection & Sequence Monotonicity
  const protector = options.replayProtector || defaultReplayProtector;
  if (!options.skipReplay) {
    const replayCheck = protector.validateAndRecord({
      sensorCode: targetCode,
      timestamp,
      signature,
      nonce,
      seq: seqNum
    });

    if (!replayCheck.allowed) {
      return {
        authenticated: false,
        statusCode: replayCheck.statusCode,
        code: replayCheck.statusCode === 409 ? 'REPLAY_ATTACK_DETECTED' : 'TIMESTAMP_DRIFT',
        error: replayCheck.reason || 'Replay attack or timestamp drift detected'
      };
    }
  }

  const reqTimeIso = new Date(timestamp).toISOString();
  const isExp = explicitExp === true || tag === 'EXPERIMENTAL' || tier === 'EXPERIMENTAL';

  return {
    authenticated: true,
    statusCode: 200,
    deviceContext: new DeviceContext({
      deviceId: targetCode,
      authenticated: true,
      authType: 'device_hmac',
      timestamp: reqTimeIso,
      firmwareVersion: options.firmwareVersion || null,
      isExperimental: isExp,
      deviceType: deviceType || 'SOLAR_POLE',
      hardwareProfile: hardwareProfile || 'DUSTGUARD_SOLAR_V1',
      sequenceNumber: seqNum
    }),
    parsedValues: {
      numPm10,
      numPm25,
      numPm1,
      numTemp,
      numHumidity,
      seq: seqNum,
      isExperimental: isExp,
      deviceType: deviceType || 'SOLAR_POLE',
      hardwareProfile: hardwareProfile || 'DUSTGUARD_SOLAR_V1',
      reqTimeIso
    }
  };
}

/**
 * Express Middleware for IoT Device Authentication.
 * Attached to telemetry ingestion routes: POST /api/sensors/reading, /api/sensors/telemetry.
 * @param {Object} [middlewareOptions]
 * @returns {import('express').RequestHandler}
 */
export function requireDeviceAuth(middlewareOptions = {}) {
  return (req, res, next) => {
    const body = req.body || {};
    const firmwareVersion = req.headers['x-firmware-version'] || null;

    const result = verifyDeviceAuth(body, {
      ...middlewareOptions,
      firmwareVersion
    });

    if (!result.authenticated) {
      return res.status(result.statusCode).json({
        status: 'error',
        statusCode: result.statusCode,
        code: result.code,
        type: `https://dustguard.vn/errors/${result.code}`,
        title: result.code,
        detail: result.error,
        message: result.error,
        instance: req.originalUrl || req.url,
        timestamp: new Date().toISOString()
      });
    }

    req.deviceContext = result.deviceContext;
    req.isDeviceAuthenticated = true;
    req.telemetryData = result.parsedValues;
    next();
  };
}

/**
 * Cloudflare Worker / Hono Helper for IoT Device Authentication.
 * @param {import('hono').Context} c
 * @param {Object} [options]
 * @returns {Promise<{ authenticated: boolean, deviceContext?: DeviceContext, errorResponse?: Response, parsedValues?: Object }>}
 */
export async function verifyWorkerDeviceAuth(c, options = {}) {
  let body = {};
  try {
    body = await c.req.json();
  } catch {
    body = {};
  }

  const firmwareVersion = c.req.header('x-firmware-version') || null;
  const result = verifyDeviceAuth(body, {
    env: c.env,
    firmwareVersion,
    ...options
  });

  if (!result.authenticated) {
    const errRes = c.json({
      status: 'error',
      statusCode: result.statusCode,
      code: result.code,
      type: `https://dustguard.vn/errors/${result.code}`,
      title: result.code,
      detail: result.error,
      message: result.error,
      instance: c.req.path,
      timestamp: new Date().toISOString()
    }, result.statusCode);

    return {
      authenticated: false,
      errorResponse: errRes
    };
  }

  c.set('deviceContext', result.deviceContext);
  c.set('isDeviceAuthenticated', true);

  return {
    authenticated: true,
    deviceContext: result.deviceContext,
    parsedValues: result.parsedValues,
    body
  };
}

export function validateDeviceTelemetry(payload = {}, secretKey = '') {
  const res = verifyDeviceAuth(payload, { secretKey, skipReplay: true });
  return {
    valid: res.authenticated,
    statusCode: res.statusCode,
    error: res.error,
    code: res.code
  };
}

