/**
 * DustGuard VN - Cryptographic HMAC-SHA256 Utility for IoT Device Authentication
 * 
 * Compliant with:
 * - ESP32 Firmware RequestSigner.cpp (mbedtls HMAC-SHA256)
 * - Node.js crypto module (timing-safe verification)
 * - Cloudflare Worker Web Crypto API (SubtleCrypto)
 */
import crypto from 'node:crypto';

/**
 * Constant-time comparison between two strings or buffers to prevent timing attacks.
 * @param {string|Buffer|Uint8Array} a 
 * @param {string|Buffer|Uint8Array} b 
 * @returns {boolean}
 */
export function timingSafeCompare(a, b) {
  if (a === null || a === undefined || b === null || b === undefined) {
    return false;
  }

  // Convert to Buffer/Uint8Array if strings
  const strA = typeof a === 'string' ? a : null;
  const strB = typeof b === 'string' ? b : null;

  if (strA !== null && strB !== null) {
    // If lengths differ, immediately return false using constant-time simulation
    const bufA = Buffer.from(strA);
    const bufB = Buffer.from(strB);
    if (bufA.length !== bufB.length) {
      return false;
    }
    if (typeof crypto.timingSafeEqual === 'function') {
      return crypto.timingSafeEqual(bufA, bufB);
    }
    // Fallback constant-time XOR loop
    let result = 0;
    for (let i = 0; i < bufA.length; i++) {
      result |= bufA[i] ^ bufB[i];
    }
    return result === 0;
  }

  if (Buffer.isBuffer(a) && Buffer.isBuffer(b)) {
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }

  return false;
}

/**
 * Builds the canonical message format for ESP32 telemetry signing.
 * Primary format: sensorCode:pm10:pm25:timestamp (or with nonce if present)
 * @param {string} sensorCode 
 * @param {number|string} pm10 
 * @param {number|string} pm25 
 * @param {string} timestamp 
 * @param {string} [nonce]
 * @returns {string}
 */
export function buildCanonicalMessage(sensorCode, pm10, pm25, timestamp, nonce) {
  const pm10Fixed = typeof pm10 === 'number' ? pm10.toFixed(1) : String(pm10);
  const pm25Fixed = typeof pm25 === 'number' ? pm25.toFixed(1) : String(pm25);
  
  if (nonce) {
    return `${sensorCode}:${pm10Fixed}:${pm25Fixed}:${timestamp}:${nonce}`;
  }
  return `${sensorCode}:${pm10Fixed}:${pm25Fixed}:${timestamp}`;
}

/**
 * Calculates HMAC-SHA256 signature in Node.js runtime.
 * @param {string} message 
 * @param {string} secret 
 * @param {'hex'|'base64'} [encoding='hex'] 
 * @returns {string}
 */
export function calculateHmacSha256(message, secret, encoding = 'hex') {
  if (!message || !secret) {
    throw new Error('Message and secret are required for HMAC calculation');
  }
  return crypto.createHmac('sha256', secret).update(message).digest(encoding);
}

/**
 * Asynchronously calculates HMAC-SHA256 using Web Crypto API (SubtleCrypto).
 * Works across Cloudflare Workers, Edge runtime, and browser environments.
 * @param {string} message 
 * @param {string} secret 
 * @param {'hex'|'base64'} [encoding='hex'] 
 * @returns {Promise<string>}
 */
export async function calculateHmacSha256Subtle(message, secret, encoding = 'hex') {
  if (!message || !secret) {
    throw new Error('Message and secret are required for HMAC calculation');
  }

  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const msgData = encoder.encode(message);
  const sigBuffer = await crypto.subtle.sign('HMAC', cryptoKey, msgData);
  const uint8 = new Uint8Array(sigBuffer);

  if (encoding === 'base64') {
    let binary = '';
    for (let i = 0; i < uint8.byteLength; i++) {
      binary += String.fromCharCode(uint8[i]);
    }
    return btoa(binary);
  }

  // Hex encoding
  return Array.from(uint8)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Generates all valid canonical representations for a telemetry payload
 * to guarantee 100% interoperability with various firmware serialization modes.
 * @param {Object} params
 * @param {string} params.sensorCode
 * @param {number|string} params.pm10
 * @param {number|string} params.pm25
 * @param {string} params.timestamp
 * @param {string} [params.nonce]
 * @returns {string[]}
 */
export function getCanonicalFormats({ sensorCode, pm10, pm25, timestamp, nonce, seq, sequenceNumber, pm1, temp, humidity }) {
  const pm10Str = Number(pm10).toString();
  const pm25Str = Number(pm25).toString();
  const pm10Fixed = Number(pm10).toFixed(1);
  const pm25Fixed = Number(pm25).toFixed(1);
  const sequence = seq !== undefined ? seq : (sequenceNumber !== undefined ? sequenceNumber : null);

  const list = [
    // 1. ESP32 Standard snprintf("%s:%.1f:%.1f:%s")
    `${sensorCode}:${pm10Fixed}:${pm25Fixed}:${timestamp}`,
    // 2. Exact string / number format
    `${sensorCode}:${pm10}:${pm25}:${timestamp}`,
    `${sensorCode}:${pm10Str}:${pm25Str}:${timestamp}`,
    // 3. Pipe delimited formats
    `${sensorCode}|${pm10Fixed}|${pm25Fixed}|${timestamp}`,
    `${sensorCode}|${pm10}|${pm25}|${timestamp}`,
    `${sensorCode}|${pm10Str}|${pm25Str}:${timestamp}`,
    // 4. JSON formats
    JSON.stringify({ sensorCode, pm10: Number(pm10), pm25: Number(pm25), timestamp }),
    JSON.stringify({ sensorCode, pm10, pm25, timestamp }),
    JSON.stringify({ pm10, pm25, sensorCode, timestamp }),
    // 5. Raw concat (Standard SensorGuide C++ / Arduino format: sensorCode + String(pm10, 1) + String(pm25, 1) + String(timestamp))
    `${sensorCode}${pm10Fixed}${pm25Fixed}${timestamp}`,
    `${sensorCode}${pm10Str}${pm25Str}${timestamp}`,
    `${sensorCode}${pm10}${pm25}${timestamp}`
  ];

  // If sequence number is included
  if (sequence !== null) {
    list.unshift(
      `${sensorCode}:${pm10Fixed}:${pm25Fixed}:${timestamp}:${sequence}`,
      `${sensorCode}:${pm10}:${pm25}:${timestamp}:${sequence}`,
      `${sensorCode}|${pm10Fixed}|${pm25Fixed}|${timestamp}|${sequence}`,
      JSON.stringify({ sensorCode, pm10: Number(pm10), pm25: Number(pm25), timestamp, seq: sequence })
    );
  }

  // If extended environmental metrics (PM1, Temp, Humidity) are present
  if (pm1 !== undefined || temp !== undefined || humidity !== undefined) {
    const pm1Fixed = pm1 !== undefined && pm1 !== null ? Number(pm1).toFixed(1) : 'null';
    const tempFixed = temp !== undefined && temp !== null ? Number(temp).toFixed(1) : 'null';
    const humFixed = humidity !== undefined && humidity !== null ? Number(humidity).toFixed(1) : 'null';

    list.unshift(
      `${sensorCode}:${pm1Fixed}:${pm25Fixed}:${pm10Fixed}:${tempFixed}:${humFixed}:${timestamp}`,
      `${sensorCode}:${pm1 ?? ''}:${pm25}:${pm10}:${temp ?? ''}:${humidity ?? ''}:${timestamp}`
    );
  }

  if (nonce) {
    list.unshift(
      `${sensorCode}:${pm10Fixed}:${pm25Fixed}:${timestamp}:${nonce}`,
      `${sensorCode}:${pm10}:${pm25}:${timestamp}:${nonce}`,
      `${sensorCode}|${timestamp}|${nonce}`,
      JSON.stringify({ sensorCode, pm10: Number(pm10), pm25: Number(pm25), timestamp, nonce })
    );
  }

  return list;
}

/**
 * Verifies a telemetry payload signature against a pre-shared secret key.
 * Supports hex (case-insensitive) and base64 formats with constant-time equality check.
 * @param {Object} payload 
 * @param {string} payload.sensorCode 
 * @param {number|string} payload.pm10 
 * @param {number|string} payload.pm25 
 * @param {string} payload.timestamp 
 * @param {string} [payload.nonce] 
 * @param {string} signature 
 * @param {string} secretKey 
 * @returns {boolean}
 */
export function verifyTelemetrySignature(payload, signature, secretKey) {
  if (!signature || !secretKey || typeof signature !== 'string' || typeof secretKey !== 'string') {
    return false;
  }

  const cleanSig = signature.trim();
  const formats = getCanonicalFormats(payload);

  for (const msg of formats) {
    const hexExpected = calculateHmacSha256(msg, secretKey, 'hex');
    const b64Expected = calculateHmacSha256(msg, secretKey, 'base64');

    // Constant-time checks
    if (timingSafeCompare(hexExpected.toLowerCase(), cleanSig.toLowerCase())) {
      return true;
    }
    if (timingSafeCompare(b64Expected, cleanSig)) {
      return true;
    }
  }

  return false;
}

/**
 * Asynchronous verification for Cloudflare Worker runtime.
 * @param {Object} payload 
 * @param {string} signature 
 * @param {string} secretKey 
 * @returns {Promise<boolean>}
 */
export async function verifyTelemetrySignatureAsync(payload, signature, secretKey) {
  if (!signature || !secretKey || typeof signature !== 'string' || typeof secretKey !== 'string') {
    return false;
  }

  const cleanSig = signature.trim();
  const formats = getCanonicalFormats(payload);

  for (const msg of formats) {
    const hexExpected = await calculateHmacSha256Subtle(msg, secretKey, 'hex');
    const b64Expected = await calculateHmacSha256Subtle(msg, secretKey, 'base64');

    if (timingSafeCompare(hexExpected.toLowerCase(), cleanSig.toLowerCase())) {
      return true;
    }
    if (timingSafeCompare(b64Expected, cleanSig)) {
      return true;
    }
  }

  return false;
}
