/**
 * DustGuard VN - Replay Attack Protection for IoT Telemetry Ingestion
 * 
 * Provides sliding-window memory caching and nonce/timestamp verification
 * to prevent duplicate transmission and replay attacks.
 */

export const DEFAULT_WINDOW_MS = 5 * 60 * 1000; // 5 minutes
export const DEFAULT_MAX_DRIFT_MS = 5 * 60 * 1000; // 5 minutes
export const DEFAULT_MAX_ENTRIES = 20000;

export class ReplayProtector {
  /**
   * @param {Object} [options]
   * @param {number} [options.windowMs=300000] - Cache retention sliding window in ms (5 minutes)
   * @param {number} [options.maxDriftMs=300000] - Allowed clock drift between device & server (5 minutes)
   * @param {number} [options.maxEntries=20000] - Maximum memory entries before aggressive eviction
   */
  constructor({
    windowMs = DEFAULT_WINDOW_MS,
    maxDriftMs = DEFAULT_MAX_DRIFT_MS,
    maxEntries = DEFAULT_MAX_ENTRIES
  } = {}) {
    this.windowMs = windowMs;
    this.maxDriftMs = maxDriftMs;
    this.maxEntries = maxEntries;
    this.cache = new Map();
    this.sequences = new Map(); // sensorCode -> lastSeenSeq
    this.lastCleanup = Date.now();
  }

  /**
   * Creates a deterministic cache key.
   * @param {string} sensorCode 
   * @param {string|number} timestamp 
   * @param {string} signatureOrNonce 
   * @returns {string}
   */
  buildKey(sensorCode, timestamp, signatureOrNonce) {
    const timeEpoch = typeof timestamp === 'number'
      ? timestamp
      : new Date(timestamp).getTime();
    const cleanSig = (signatureOrNonce || '').trim();
    return `${sensorCode}_${timeEpoch}_${cleanSig}`;
  }

  /**
   * Cleans up expired entries in the sliding window.
   */
  cleanup(now = Date.now()) {
    for (const [key, recordTime] of this.cache.entries()) {
      if (now - recordTime > this.windowMs) {
        this.cache.delete(key);
      }
    }
    this.lastCleanup = now;

    // Safety guard against memory exhaustion
    if (this.cache.size > this.maxEntries) {
      // Evict oldest entries
      const entriesToEvict = this.cache.size - this.maxEntries;
      let count = 0;
      for (const key of this.cache.keys()) {
        this.cache.delete(key);
        count++;
        if (count >= entriesToEvict) break;
      }
    }
  }

  /**
   * Validates timestamp clock drift against server time.
   * @param {string|number} timestamp 
   * @param {number} [now=Date.now()]
   * @returns {{ valid: boolean, driftMs: number, reqTime: number, error?: string }}
   */
  checkTimestampDrift(timestamp, now = Date.now()) {
    if (!timestamp) {
      return { valid: false, driftMs: Infinity, reqTime: 0, error: 'Missing timestamp' };
    }

    const reqTime = typeof timestamp === 'number'
      ? timestamp
      : new Date(timestamp).getTime();

    if (isNaN(reqTime)) {
      return { valid: false, driftMs: Infinity, reqTime: 0, error: 'Invalid timestamp format' };
    }

    const driftMs = Math.abs(now - reqTime);
    if (driftMs > this.maxDriftMs) {
      return {
        valid: false,
        driftMs,
        reqTime,
        error: `Timestamp drift (${Math.round(driftMs / 1000)}s) exceeds allowed limit (${Math.round(this.maxDriftMs / 1000)}s)`
      };
    }

    return { valid: true, driftMs, reqTime };
  }

  /**
   * Checks if a request key has already been seen in the active sliding window.
   * @param {string} key 
   * @returns {boolean}
   */
  isReplay(key) {
    return this.cache.has(key);
  }

  /**
   * Records a key into the cache.
   * @param {string} key 
   * @param {number} [timestamp=Date.now()]
   */
  record(key, timestamp = Date.now()) {
    this.cache.set(key, timestamp);
    // Periodically run cleanup every 1 minute
    if (timestamp - this.lastCleanup > 60000) {
      this.cleanup(timestamp);
    }
  }

  /**
   * Atomically verifies timestamp drift, checks replay cache, sequence ordering, and records entry if valid.
   * @param {Object} params
   * @param {string} params.sensorCode
   * @param {string|number} params.timestamp
   * @param {string} [params.signature]
   * @param {string} [params.nonce]
   * @param {number} [params.seq]
   * @param {number} [params.sequenceNumber]
   * @returns {{ allowed: boolean, statusCode: number, reason?: string, key?: string, driftMs?: number, sequenceCheck?: Object }}
   */
  validateAndRecord({ sensorCode, timestamp, signature, nonce, seq, sequenceNumber }) {
    const now = Date.now();

    // 1. Verify Clock Drift
    const driftCheck = this.checkTimestampDrift(timestamp, now);
    if (!driftCheck.valid) {
      return {
        allowed: false,
        statusCode: 400,
        reason: driftCheck.error || 'Timestamp drift exceeds allowed limit (5 minutes)',
        driftMs: driftCheck.driftMs
      };
    }

    // 2. Build deterministic replay key
    const token = nonce || signature || '';
    const replayKey = this.buildKey(sensorCode, driftCheck.reqTime, token);

    // 3. Cleanup on demand
    this.cleanup(now);

    // 4. Check for replay
    if (this.cache.has(replayKey)) {
      return {
        allowed: false,
        statusCode: 409,
        reason: 'Replay attack detected: Telemetry reading with this signature/timestamp has already been processed in sliding window',
        key: replayKey,
        driftMs: driftCheck.driftMs
      };
    }

    // 5. Sequence Check (if provided)
    const sequence = seq !== undefined ? seq : (sequenceNumber !== undefined ? sequenceNumber : null);
    let sequenceCheck = null;
    if (sequence !== null && typeof sequence === 'number' && !isNaN(sequence)) {
      const lastSeq = this.sequences.get(sensorCode);
      if (lastSeq !== undefined && sequence <= lastSeq) {
        return {
          allowed: false,
          statusCode: 409,
          reason: `Replay / sequence rollback detected: Received sequence ${sequence} <= last processed sequence ${lastSeq}`,
          key: replayKey,
          driftMs: driftCheck.driftMs
        };
      }
      this.sequences.set(sensorCode, sequence);
      sequenceCheck = { sequence, previousSequence: lastSeq ?? null };
    }

    // 6. Record entry
    this.cache.set(replayKey, now);

    return {
      allowed: true,
      statusCode: 200,
      key: replayKey,
      driftMs: driftCheck.driftMs,
      sequenceCheck
    };
  }

  /**
   * Resets all cached entries (for tests).
   */
  clear() {
    this.cache.clear();
    this.sequences.clear();
    this.lastCleanup = Date.now();
  }

  /**
   * Returns current cache size.
   * @returns {number}
   */
  size() {
    return this.cache.size;
  }
}

// Global default singleton
export const defaultReplayProtector = new ReplayProtector();

/**
 * Convenience helper for default replay protector.
 */
export function validateDeviceReplay(params) {
  return defaultReplayProtector.validateAndRecord(params);
}

/**
 * Convenience helper to reset default replay protector.
 */
export function clearDeviceReplayCache() {
  defaultReplayProtector.clear();
}
