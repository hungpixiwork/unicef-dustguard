/**
 * DustGuard VN - Single Source of Truth (SSOT) for Roles
 * Hybrid Auth Architecture: Human Identity (Clerk) -> DustGuard Domain Roles
 */

export const ROLES = Object.freeze({
  CITIZEN: 'citizen',
  COMMUNITY: 'community',
  YOUTH_MEMBER: 'youth_member',
  STAFF: 'staff',
  INSPECTOR: 'inspector',
  EXECUTIVE: 'executive',
  CONTRACTOR: 'contractor',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin',
  SYSTEM: 'system',
});

export const ROLE_HIERARCHY = Object.freeze({
  [ROLES.SUPER_ADMIN]: 100,
  [ROLES.ADMIN]: 90,
  [ROLES.EXECUTIVE]: 80,
  [ROLES.INSPECTOR]: 70,
  [ROLES.STAFF]: 60,
  [ROLES.CONTRACTOR]: 30,
  [ROLES.COMMUNITY]: 25,
  [ROLES.YOUTH_MEMBER]: 20,
  [ROLES.CITIZEN]: 10,
  [ROLES.SYSTEM]: 100,
});

export function hasRoleLevel(userRole, requiredRole) {
  const userLevel = ROLE_HIERARCHY[userRole] || 0;
  const reqLevel = ROLE_HIERARCHY[requiredRole] || 0;
  return userLevel >= reqLevel;
}

export function isValidRole(role) {
  return Object.values(ROLES).includes(role);
}
