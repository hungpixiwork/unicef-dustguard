/**
 * DustGuard VN - IdentityContext Abstraction
 * Domain layer consumes IdentityContext ONLY, with ZERO direct dependency on Clerk SDK.
 */

import { ROLES, hasRoleLevel } from '../roles.js';

export class IdentityContext {
  /**
   * @param {Object} params
   * @param {string} params.userId - DustGuard internal User ID
   * @param {string} [params.clerkUserId] - External Clerk User ID (e.g. user_2xxx)
   * @param {string} [params.email] - User primary email
   * @param {string} [params.displayName] - User full name / display name
   * @param {string} [params.name] - Full name alias
   * @param {string} [params.fullName] - Full name alias
   * @param {string[]} [params.roles] - List of domain roles assigned
   * @param {string} [params.primaryRole] - Main active role (default 'citizen')
   * @param {string} [params.role] - Single role alias
   * @param {string|null} [params.organizationId] - Organization / Site affiliation ID
   * @param {string|null} [params.orgId] - Org ID alias
   * @param {string|null} [params.sessionId] - Clerk or Worker Session ID
   * @param {string} [params.status] - 'ACTIVE' | 'DISABLED' | 'INACTIVE'
   * @param {boolean} [params.emailVerified] - Whether email is verified
   * @param {string} [params.authSource] - 'clerk' | 'session' | 'demo'
   * @param {Record<string, any>} [params.metadata] - Extra safe metadata
   */
  constructor({
    userId,
    clerkUserId = null,
    email = '',
    displayName = '',
    name = '',
    fullName = '',
    roles = [ROLES.CITIZEN],
    primaryRole = ROLES.CITIZEN,
    role = '',
    organizationId = null,
    orgId = null,
    sessionId = null,
    status = 'ACTIVE',
    emailVerified = false,
    authSource = 'clerk',
    metadata = {}
  }) {
    if (!userId && !clerkUserId) {
      throw new Error('IdentityContext requires at least userId or clerkUserId');
    }

    this.userId = userId || clerkUserId;
    this.clerkUserId = clerkUserId || (userId?.startsWith('user_') ? userId : null);
    this.email = email || '';
    this.displayName = displayName || fullName || name || email?.split('@')[0] || 'User';
    this.name = this.displayName;
    this.fullName = this.displayName;
    this.full_name = this.displayName;

    const baseRole = role || primaryRole || ROLES.CITIZEN;
    const normalizedRoles = Array.isArray(roles) && roles.length > 0
      ? Array.from(new Set([...roles, baseRole]))
      : [baseRole];

    this.roles = normalizedRoles;
    this.primaryRole = baseRole;
    this.role = this.primaryRole; // Convenience alias for existing legacy codebase

    this.organizationId = organizationId || orgId || metadata?.organizationId || metadata?.orgId || null;
    this.orgId = this.organizationId;
    this.sessionId = sessionId || null;
    this.status = status;
    this.disabled = Boolean(status === 'DISABLED' || status === 'INACTIVE');
    this.emailVerified = Boolean(emailVerified);
    this.authSource = authSource;
    this.metadata = metadata || {};
  }

  hasRole(requiredRole) {
    if (this.roles.includes(ROLES.SUPER_ADMIN) || this.roles.includes(ROLES.ADMIN) || this.roles.includes('demo_admin')) {
      return true;
    }
    return this.roles.includes(requiredRole);
  }

  hasAnyRole(...targetRoles) {
    if (this.roles.includes(ROLES.SUPER_ADMIN) || this.roles.includes(ROLES.ADMIN) || this.roles.includes('demo_admin')) {
      return true;
    }
    const flattened = targetRoles.flat();
    return flattened.some(r => this.roles.includes(r));
  }

  hasExactRole(role) {
    return this.roles.includes(role);
  }

  hasRoleLevel(minRole) {
    return hasRoleLevel(this.primaryRole, minRole);
  }

  isAdmin() {
    return this.roles.includes(ROLES.ADMIN) || this.roles.includes(ROLES.SUPER_ADMIN) || this.roles.includes('demo_admin');
  }

  isStaff() {
    return this.isAdmin() || this.roles.includes(ROLES.STAFF) || this.roles.includes(ROLES.EXECUTIVE);
  }

  isInspector() {
    return this.isAdmin() || this.roles.includes(ROLES.INSPECTOR);
  }

  isExecutive() {
    return this.isAdmin() || this.roles.includes(ROLES.EXECUTIVE);
  }

  isCitizen() {
    return this.roles.includes(ROLES.CITIZEN);
  }

  isYouth() {
    return this.roles.includes(ROLES.YOUTH_MEMBER) || this.roles.includes('youth');
  }

  isContractor() {
    return this.roles.includes(ROLES.CONTRACTOR);
  }

  toNormalizedUser() {
    return {
      id: this.userId,
      clerkUserId: this.clerkUserId,
      email: this.email,
      name: this.displayName,
      fullName: this.displayName,
      full_name: this.displayName,
      role: this.primaryRole,
      roles: this.roles,
      emailVerified: this.emailVerified,
      organizationId: this.organizationId,
      orgId: this.organizationId,
      status: this.status,
      disabled: this.disabled,
      sessionId: this.sessionId,
      profile: {
        fullName: this.displayName,
        phoneNumber: this.metadata?.phoneNumber || '',
        department: this.metadata?.department || (this.isStaff() ? 'Phòng Thanh Tra Môi Trường' : 'Cộng đồng')
      }
    };
  }

  toJSON() {
    return {
      userId: this.userId,
      clerkUserId: this.clerkUserId,
      email: this.email,
      displayName: this.displayName,
      roles: this.roles,
      primaryRole: this.primaryRole,
      role: this.primaryRole,
      organizationId: this.organizationId,
      orgId: this.orgId,
      sessionId: this.sessionId,
      status: this.status,
      disabled: this.disabled,
      emailVerified: this.emailVerified,
      authSource: this.authSource
    };
  }
}

export function createIdentityContext(params) {
  return new IdentityContext(params);
}
