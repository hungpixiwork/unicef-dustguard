/**
 * DustGuard VN - Clerk Human Authentication Adapter
 * Validates Clerk JWT tokens, extracts claims locally/networkless, and maps to IdentityContext.
 * Decouples Clerk SDK from domain & business repositories.
 */

import { verifyToken as clerkVerifyToken, createClerkClient } from '@clerk/backend';
import { createIdentityContext, IdentityContext } from './identity-context.js';
import { ROLES } from '../roles.js';

export { ROLES };

/**
 * Maps Clerk organization roles or metadata to DustGuard domain roles
 * @param {string} rawRole
 * @returns {string} Normalized DustGuard role
 */
export function mapClerkRoleToDustGuard(rawRole) {
  if (!rawRole || typeof rawRole !== 'string') return ROLES.CITIZEN;
  const cleaned = rawRole.replace(/^org:/, '').toLowerCase().trim();

  switch (cleaned) {
    case 'admin':
    case 'super_admin':
      return ROLES.ADMIN;
    case 'staff':
      return ROLES.STAFF;
    case 'inspector':
      return ROLES.INSPECTOR;
    case 'executive':
    case 'leader':
      return ROLES.EXECUTIVE;
    case 'contractor':
      return ROLES.CONTRACTOR;
    case 'community':
    case 'clb':
    case 'clb_member':
    case 'youth':
    case 'youth_member':
    case 'club_member':
    case 'volunteer':
      return ROLES.COMMUNITY;
    default:
      return ROLES.CITIZEN;
  }
}

/**
 * Decode JWT token payload without network call
 * @param {string} token
 * @returns {{ header: Object, payload: Object, signature: string } | null}
 */
export function decodeJwt(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.trim().split('.');
  if (parts.length !== 3) return null;

  try {
    const decodeBase64Url = (str) => {
      let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
      while (base64.length % 4) base64 += '=';
      if (typeof atob === 'function') {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return new TextDecoder().decode(bytes);
      }
      return Buffer.from(base64, 'base64').toString('utf8');
    };

    const header = JSON.parse(decodeBase64Url(parts[0]));
    const payload = JSON.parse(decodeBase64Url(parts[1]));
    return { header, payload, signature: parts[2] };
  } catch {
    return null;
  }
}

export function decodeJwtPayload(token) {
  const decoded = decodeJwt(token);
  return decoded ? decoded.payload : null;
}

/**
 * Verify Clerk Session Token & return IdentityContext
 * @param {string} token - Raw JWT token or session string
 * @param {Object} [options]
 * @param {string} [options.secretKey] - CLERK_SECRET_KEY
 * @param {string} [options.jwtKey] - CLERK_JWT_KEY (PEM or base64 public key)
 * @param {number} [options.clockSkewMs=30000] - Clock skew tolerance in ms (default 30s)
 * @returns {Promise<{ valid: boolean, identity: IdentityContext | null, error?: string, code?: string, claims?: Object, payload?: Object }>}
 */
export async function verifyClerkSessionToken(token, options = {}) {
  if (!token || typeof token !== 'string') {
    return {
      valid: false,
      identity: null,
      code: 'MISSING_TOKEN',
      error: 'Token xác thực không được cung cấp.'
    };
  }

  const cleanToken = token.startsWith('Bearer ') ? token.slice(7).trim() : token.trim();
  if (!cleanToken) {
    return {
      valid: false,
      identity: null,
      code: 'EMPTY_TOKEN',
      error: 'Token xác thực rỗng.'
    };
  }

  // 1. If Clerk secretKey or jwtKey is provided, attempt formal verification via @clerk/backend
  const secretKey = options.secretKey || (typeof process !== 'undefined' ? process.env?.CLERK_SECRET_KEY : '') || options.env?.CLERK_SECRET_KEY;
  const jwtKey = options.jwtKey || (typeof process !== 'undefined' ? process.env?.CLERK_JWT_KEY : '') || options.env?.CLERK_JWT_KEY;
  const isProd = (options.env?.NODE_ENV === 'production') || (typeof process !== 'undefined' && process.env?.NODE_ENV === 'production');

  if (secretKey || jwtKey) {
    try {
      const verifiedPayload = await clerkVerifyToken(cleanToken, {
        secretKey: secretKey || undefined,
        jwtKey: jwtKey || undefined,
        apiUrl: options.apiUrl || (typeof process !== 'undefined' ? process.env?.CLERK_API_URL : '') || options.env?.CLERK_API_URL || undefined
      });

      if (verifiedPayload && verifiedPayload.sub) {
        const identity = buildIdentityFromClaims(verifiedPayload);
        return {
          valid: true,
          identity,
          claims: verifiedPayload,
          payload: verifiedPayload
        };
      }
    } catch (clerkErr) {
      const isExpired = clerkErr.message?.toLowerCase().includes('expired');
      return {
        valid: false,
        identity: null,
        code: isExpired ? 'TOKEN_EXPIRED' : 'INVALID_TOKEN',
        error: isExpired ? 'Phiên làm việc Clerk đã hết hạn.' : (clerkErr.message || 'Token Clerk không hợp lệ.')
      };
    }
  }

  // If in production and secret keys are missing, reject with AUTH_MISCONFIGURED instead of fallback unsigned JWT
  if (isProd && !secretKey && !jwtKey) {
    return {
      valid: false,
      identity: null,
      code: 'AUTH_MISCONFIGURED',
      error: 'Khóa bảo mật Clerk chưa được cấu hình trên môi trường Production.'
    };
  }

  // 2. Fallback: Parse JWT locally (Networkless / Dev / Test Mode)
  const decoded = decodeJwt(cleanToken);
  if (!decoded || !decoded.payload) {
    return {
      valid: false,
      identity: null,
      code: 'MALFORMED_TOKEN',
      error: 'Token không đúng định dạng JWT.'
    };
  }

  const { payload } = decoded;
  const nowSec = Math.floor(Date.now() / 1000);
  const skewSec = Math.floor((options.clockSkewMs || 30000) / 1000);

  // Check expiration (exp)
  if (payload.exp && typeof payload.exp === 'number') {
    if (payload.exp + skewSec < nowSec) {
      return {
        valid: false,
        identity: null,
        code: 'TOKEN_EXPIRED',
        error: 'Phiên làm việc Clerk đã hết hạn.'
      };
    }
  }

  // Check Not Before (nbf)
  if (payload.nbf && typeof payload.nbf === 'number') {
    if (payload.nbf - skewSec > nowSec) {
      return {
        valid: false,
        identity: null,
        code: 'TOKEN_NOT_YET_VALID',
        error: 'Token chưa đến thời điểm hiệu lực.'
      };
    }
  }

  // Check sub (userId)
  const clerkUserId = payload.sub;
  if (!clerkUserId || typeof clerkUserId !== 'string') {
    return {
      valid: false,
      identity: null,
      code: 'INVALID_SUBJECT',
      error: 'Token thiếu thông tin định danh người dùng (sub claim).'
    };
  }

  const identity = buildIdentityFromClaims(payload);
  return {
    valid: true,
    identity,
    claims: payload,
    payload
  };
}

export function buildIdentityFromClaims(payload = {}, d1User = null) {
  const metadata = payload.public_metadata || payload.publicMetadata || payload.metadata || {};
  const claimRoles = metadata.roles || (metadata.role ? [metadata.role] : []) || (payload.role ? [payload.role] : []);
  const rawRole = d1User?.role || metadata.role || payload.role || payload.org_role || payload.orgRole || (claimRoles.length > 0 ? claimRoles[0] : ROLES.CITIZEN);
  const normalizedRole = mapClerkRoleToDustGuard(rawRole);
  const roles = claimRoles.length > 0 ? claimRoles.map(mapClerkRoleToDustGuard) : [normalizedRole];

  const email = d1User?.email || payload.email || payload.email_addresses?.[0]?.email_address || metadata.email || '';
  const displayName = d1User?.full_name || payload.name || metadata.full_name || metadata.fullName || (payload.first_name ? `${payload.first_name || ''} ${payload.last_name || ''}`.trim() : '') || (email ? email.split('@')[0] : 'Người dùng');

  return createIdentityContext({
    userId: d1User?.id || metadata.dustguard_user_id || payload.sub,
    clerkUserId: payload.sub,
    email,
    displayName,
    name: displayName,
    fullName: displayName,
    roles,
    role: normalizedRole,
    primaryRole: normalizedRole,
    organizationId: d1User?.organizationId || payload.org_id || metadata.organization_id || metadata.orgId || null,
    orgId: d1User?.organizationId || payload.org_id || metadata.organization_id || metadata.orgId || null,
    sessionId: payload.sid || null,
    status: d1User?.status || metadata.status || 'ACTIVE',
    emailVerified: Boolean(payload.email_verified || metadata.email_verified || d1User?.email_verified),
    authSource: 'clerk',
    metadata: {
      ...metadata,
      ...(d1User?.profile || {})
    }
  });
}

/**
 * Extract token from Request headers or cookies
 * @param {Object} req
 * @returns {string | null}
 */
export function extractTokenFromRequest(req) {
  if (!req) return null;

  let authHeader = '';
  let cookieHeader = '';

  if (typeof req.header === 'function') {
    authHeader = req.header('authorization') || req.header('Authorization') || '';
    cookieHeader = req.header('cookie') || req.header('Cookie') || '';
  } else if (req.headers) {
    if (typeof req.headers.get === 'function') {
      authHeader = req.headers.get('authorization') || '';
      cookieHeader = req.headers.get('cookie') || '';
    } else {
      authHeader = req.headers['authorization'] || req.headers['Authorization'] || '';
      cookieHeader = req.headers['cookie'] || req.headers['Cookie'] || '';
    }
  }

  if (authHeader && typeof authHeader === 'string' && authHeader.toLowerCase().startsWith('bearer ')) {
    return authHeader.substring(7).trim();
  }

  if (cookieHeader && typeof cookieHeader === 'string') {
    const match = cookieHeader.match(/(?:__session|clerk_session|auth_session|better-auth\.session_token)=([^;]+)/);
    if (match) return decodeURIComponent(match[1].trim());
  }

  return null;
}

export class ClerkAuthAdapter {
  constructor(env = {}) {
    this.env = env;
    this.secretKey = env.CLERK_SECRET_KEY || process.env.CLERK_SECRET_KEY || '';
    this.publishableKey = env.CLERK_PUBLISHABLE_KEY || env.VITE_CLERK_PUBLISHABLE_KEY || process.env.CLERK_PUBLISHABLE_KEY || '';
    this.jwtKey = env.CLERK_JWT_KEY || process.env.CLERK_JWT_KEY || '';
    this.apiUrl = env.CLERK_API_URL || process.env.CLERK_API_URL || undefined;

    this.client = (this.secretKey || this.publishableKey)
      ? createClerkClient({
          secretKey: this.secretKey,
          publishableKey: this.publishableKey,
          apiUrl: this.apiUrl
        })
      : null;
  }

  async verifyToken(token) {
    const res = await verifyClerkSessionToken(token, {
      secretKey: this.secretKey,
      jwtKey: this.jwtKey,
      apiUrl: this.apiUrl,
      env: this.env
    });
    return {
      valid: res.valid,
      identity: res.identity,
      claims: res.claims || res.payload,
      error: res.error,
      code: res.code
    };
  }

  buildIdentity(claims, d1User = null) {
    return buildIdentityFromClaims(claims, d1User);
  }
}
