/**
 * DustGuard VN - Clerk Hybrid Auth Middleware
 * Integrates Clerk JWT verification with local session fallback.
 * Populates `c.set('identity', identity)` and `c.set('user', user)` in Hono,
 * and `req.identity`, `req.user`, `req.authSession` in Express.
 */

import { ClerkAuthAdapter, verifyClerkSessionToken, extractTokenFromRequest } from './clerk.adapter.js';
import { IdentityContext, createIdentityContext } from './identity-context.js';
import { provisionClerkUser } from '../../repositories/user.repository.js';
import { getD1OrSqlite } from '../../shared/db.js';
import { ROLES } from '../roles.js';

// In-memory session cache for local/demo tokens
export const IN_MEMORY_SESSIONS = new Map();

const BASE_DEMO_ACCOUNTS = {
  'admin@dustguard.vn': {
    id: 'usr_demo_admin',
    email: 'admin@dustguard.vn',
    name: 'Ban Giám Khảo Demo',
    full_name: 'Ban Giám Khảo Demo',
    role: 'demo_admin',
    roles: ['demo_admin', 'admin', 'staff', 'executive', 'citizen'],
    allowedModes: ['staff', 'executive', 'citizen', 'contractor'],
    defaultMode: 'staff',
    emailVerified: true,
    profile: { fullName: 'Ban Giám Khảo Demo', department: 'Ban Giám Khảo & Quản Trị' }
  },
  'staff@dustguard.vn': {
    id: 'usr_demo_staff',
    email: 'staff@dustguard.vn',
    name: 'Nguyễn Văn An (Thanh Tra)',
    full_name: 'Nguyễn Văn An',
    role: 'staff',
    roles: ['staff', 'inspector', 'citizen'],
    allowedModes: ['staff', 'citizen'],
    defaultMode: 'staff',
    emailVerified: true,
    profile: { fullName: 'Nguyễn Văn An', department: 'Phòng Thanh Tra Môi Trường' }
  },
  'executive@dustguard.vn': {
    id: 'usr_demo_exec',
    email: 'executive@dustguard.vn',
    name: 'Phạm Phú Hưng (Giám Đốc Sở)',
    full_name: 'Phạm Phú Hưng',
    role: 'executive',
    roles: ['executive', 'staff', 'citizen'],
    allowedModes: ['executive', 'staff', 'citizen'],
    defaultMode: 'executive',
    emailVerified: true,
    profile: { fullName: 'Phạm Phú Hưng', department: 'Ban Giám Đốc Sở TNMT' }
  },
  'contractor@dustguard.vn': {
    id: 'usr_demo_contractor',
    email: 'contractor@dustguard.vn',
    name: 'Nguyễn Văn Cương (Nhà Thầu)',
    full_name: 'Nguyễn Văn Cương',
    role: 'contractor',
    roles: ['contractor', 'citizen'],
    allowedModes: ['contractor', 'citizen'],
    defaultMode: 'contractor',
    emailVerified: true,
    profile: { fullName: 'Nguyễn Văn Cương', department: 'Tổng Công Ty XD Số 1' }
  },
  'community@dustguard.vn': {
    id: 'usr_demo_community',
    email: 'community@dustguard.vn',
    name: 'Trần Minh Tâm (CLB Môi Trường)',
    full_name: 'Trần Minh Tâm',
    role: 'community',
    roles: ['community', 'youth_member', 'citizen'],
    allowedModes: ['citizen'],
    defaultMode: 'citizen',
    emailVerified: true,
    profile: { fullName: 'Trần Minh Tâm', department: 'CLB Giám Sát Môi Trường Trẻ' }
  },
  'citizen@dustguard.vn': {
    id: 'usr_demo_citizen',
    email: 'citizen@dustguard.vn',
    name: 'Nguyễn Thị Lan (Công Dân)',
    full_name: 'Nguyễn Thị Lan',
    role: 'citizen',
    roles: ['citizen'],
    allowedModes: ['citizen'],
    defaultMode: 'citizen',
    emailVerified: true,
    profile: { fullName: 'Nguyễn Thị Lan', department: 'Cộng đồng Cầu Giấy' }
  }
};

export const DEMO_ACCOUNTS = {
  ...BASE_DEMO_ACCOUNTS,
  // Alias mapping for demo-* and demo_* identifiers
  'demo-admin': BASE_DEMO_ACCOUNTS['admin@dustguard.vn'],
  'demo_admin': BASE_DEMO_ACCOUNTS['admin@dustguard.vn'],
  'usr_demo_admin': BASE_DEMO_ACCOUNTS['admin@dustguard.vn'],
  'demo-staff': BASE_DEMO_ACCOUNTS['staff@dustguard.vn'],
  'demo_staff': BASE_DEMO_ACCOUNTS['staff@dustguard.vn'],
  'usr_demo_staff': BASE_DEMO_ACCOUNTS['staff@dustguard.vn'],
  'demo-executive': BASE_DEMO_ACCOUNTS['executive@dustguard.vn'],
  'demo_exec': BASE_DEMO_ACCOUNTS['executive@dustguard.vn'],
  'usr_demo_exec': BASE_DEMO_ACCOUNTS['executive@dustguard.vn'],
  'demo-contractor': BASE_DEMO_ACCOUNTS['contractor@dustguard.vn'],
  'demo_contractor': BASE_DEMO_ACCOUNTS['contractor@dustguard.vn'],
  'usr_demo_contractor': BASE_DEMO_ACCOUNTS['contractor@dustguard.vn'],
  'demo-community': BASE_DEMO_ACCOUNTS['community@dustguard.vn'],
  'demo_community': BASE_DEMO_ACCOUNTS['community@dustguard.vn'],
  'usr_demo_community': BASE_DEMO_ACCOUNTS['community@dustguard.vn'],
  'demo-citizen': BASE_DEMO_ACCOUNTS['citizen@dustguard.vn'],
  'demo_citizen': BASE_DEMO_ACCOUNTS['citizen@dustguard.vn'],
  'usr_demo_citizen': BASE_DEMO_ACCOUNTS['citizen@dustguard.vn'],
};

export function formatRfc7807Error(status, code, title, detail, instance = '/') {
  return {
    status: 'error',
    statusCode: status,
    code,
    type: `https://dustguard.vn/errors/${code}`,
    title,
    detail,
    instance,
    error: detail,
    message: detail,
    timestamp: new Date().toISOString()
  };
}

/**
 * Extracts auth token from Hono context
 */
export function extractTokenFromHono(c) {
  return extractTokenFromRequest(c.req.raw || c.req);
}

/**
 * Extracts auth token from Express request
 */
export function extractTokenFromExpress(req) {
  return extractTokenFromRequest(req);
}

/**
 * Core Resolver: Authenticates token and constructs IdentityContext with D1/Memory fallback
 */
export async function resolveIdentityFromToken(token, env = {}) {
  if (!token) return null;

  const adapter = new ClerkAuthAdapter(env);
  const db = getD1OrSqlite(env);

  // 1. Try Clerk Token Verification
  const isJwt = token.includes('.') && token.split('.').length === 3;
  if (isJwt || token.startsWith('clerk_')) {
    const result = await adapter.verifyToken(token);
    if (result.valid && result.claims) {
      let d1User = null;
      if (db || env?.DB || process.env.DATABASE_URL || process.env.NODE_ENV !== 'production') {
        try {
          const email = result.claims.email || result.claims.email_addresses?.[0]?.email_address || result.claims.metadata?.email || '';
          const fullName = result.claims.name || result.claims.full_name || result.claims.fullName || result.claims.first_name ? `${result.claims.first_name || ''} ${result.claims.last_name || ''}`.trim() : '';
          const role = result.claims.public_metadata?.role || result.claims.role || 'citizen';
          const avatarUrl = result.claims.image_url || result.claims.picture || null;

          const provisionResult = await provisionClerkUser({
            clerkUserId: result.claims.sub,
            email,
            fullName,
            avatarUrl,
            role,
            metadata: result.claims.public_metadata || result.claims.metadata || {}
          }, env);

          d1User = provisionResult?.user || null;
        } catch (provisionErr) {
          try {
            if (db) {
              d1User = await db.prepare(
                'SELECT * FROM users WHERE clerk_user_id = ? OR id = ? OR email = ?'
              ).bind(result.claims.sub, result.claims.sub, result.claims.email || '').first();
            }
          } catch {}
        }
      }
      return adapter.buildIdentity(result.claims, d1User);
    }
  }

  // 2. Primary Database Session: Cloudflare D1 / dev.db as SSOT
  if (db) {
    try {
      const sessionRecord = await db.prepare(
        'SELECT * FROM session WHERE token = ? OR id = ?'
      ).bind(token, token).first();

      if (sessionRecord) {
        const isExpired = sessionRecord.expiresAt && new Date(sessionRecord.expiresAt) < new Date();
        if (!isExpired) {
          const user = await db.prepare('SELECT * FROM users WHERE id = ?').bind(sessionRecord.userId).first();
          if (user && user.status !== 'DISABLED' && !user.disabled) {
            const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
            return createIdentityContext({
              userId: user.id,
              email: user.email,
              name: user.full_name,
              fullName: user.full_name,
              role: user.role || 'citizen',
              roles: [user.role || 'citizen'],
              emailVerified: Boolean(user.email_verified),
              sessionId: sessionRecord.id,
              authSource: 'session',
              metadata: {
                department: profile?.department,
                phoneNumber: profile?.phoneNumber,
                avatarUrl: profile?.avatarUrl
              }
            });
          }
        }
      }
    } catch {}
  }

  // 3. Fallback: In-Memory Sessions (Dev / Testing)
  const mem = IN_MEMORY_SESSIONS.get(token);
  if (mem && (!mem.expiresAt || mem.expiresAt > Date.now())) {
    const user = mem.user;
    if (user && user.status !== 'DISABLED' && !user.disabled) {
      return createIdentityContext({
        userId: user.id,
        email: user.email,
        name: user.name || user.fullName,
        fullName: user.fullName || user.name,
        role: user.role || 'citizen',
        roles: user.roles || [user.role || 'citizen'],
        emailVerified: Boolean(user.emailVerified),
        sessionId: token,
        authSource: 'session',
        metadata: user.profile || {}
      });
    }
  }

  // 4. Fallback: Direct Demo Account matching
  const normalizedToken = token.toLowerCase();
  let demoAccount = DEMO_ACCOUNTS[token] || DEMO_ACCOUNTS[normalizedToken] || Object.values(DEMO_ACCOUNTS).find(u => u.id === token || u.email === token || u.role === token);
  
  if (!demoAccount) {
    if (normalizedToken.includes('admin')) demoAccount = DEMO_ACCOUNTS['admin@dustguard.vn'];
    else if (normalizedToken.includes('staff') || normalizedToken.includes('inspector')) demoAccount = DEMO_ACCOUNTS['staff@dustguard.vn'];
    else if (normalizedToken.includes('exec')) demoAccount = DEMO_ACCOUNTS['executive@dustguard.vn'];
    else if (normalizedToken.includes('contractor')) demoAccount = DEMO_ACCOUNTS['contractor@dustguard.vn'];
    else if (normalizedToken.includes('community') || normalizedToken.includes('clb') || normalizedToken.includes('youth')) demoAccount = DEMO_ACCOUNTS['community@dustguard.vn'];
    else if (normalizedToken.includes('citizen')) demoAccount = DEMO_ACCOUNTS['citizen@dustguard.vn'];
  }

  if (demoAccount) {
    return createIdentityContext({
      userId: demoAccount.id,
      email: demoAccount.email,
      name: demoAccount.name,
      fullName: demoAccount.full_name,
      role: demoAccount.role,
      roles: demoAccount.roles,
      emailVerified: demoAccount.emailVerified,
      sessionId: `demo_${demoAccount.id}`,
      authSource: 'demo',
      metadata: demoAccount.profile
    });
  }

  return null;
}

/**
 * Hono Global / Route Middleware: Populates c.set('identity', identity) and c.set('user', user)
 */
export function clerkAuthMiddleware(options = {}) {
  return async (c, next) => {
    const token = extractTokenFromHono(c);
    if (token) {
      const identity = await resolveIdentityFromToken(token, c.env);
      if (identity) {
        c.set('identity', identity);
        c.set('user', identity.toNormalizedUser());
        c.set('userId', identity.userId);
      }
    }
    await next();
  };
}

export const honoClerkAuthMiddleware = clerkAuthMiddleware;

/**
 * Express Global / Route Middleware: Populates req.identity and req.user
 */
export function clerkExpressMiddleware(options = {}) {
  return async (req, res, next) => {
    try {
      const token = extractTokenFromExpress(req);
      if (token) {
        const identity = await resolveIdentityFromToken(token, process.env);
        if (identity) {
          req.identity = identity;
          req.user = identity.toNormalizedUser();
          req.authSession = { id: identity.sessionId, userId: identity.userId };
        }
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

export const expressClerkAuthMiddleware = clerkExpressMiddleware;

/**
 * Universal requireAuth guard (supports Express, Hono, and direct verification)
 */
export function requireAuth(options = {}) {
  return async (reqOrContext, resOrNext, nextFn) => {
    const isHono = typeof reqOrContext?.json === 'function' && typeof resOrNext === 'function';

    if (isHono) {
      const c = reqOrContext;
      const next = resOrNext;
      let identity = c.get('identity');

      if (!identity) {
        const token = extractTokenFromHono(c);
        if (token) {
          identity = await resolveIdentityFromToken(token, c.env);
          if (identity) c.set('identity', identity);
        }
      }

      if (!identity || identity.disabled) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
      }
      return next();
    }

    // Express mode
    const req = reqOrContext;
    const res = resOrNext;
    const next = nextFn;

    let identity = req.identity || (req.user instanceof IdentityContext ? req.user : (req.user ? createIdentityContext(req.user) : null));
    if (!identity) {
      const token = extractTokenFromExpress(req);
      if (token) {
        identity = await resolveIdentityFromToken(token, process.env);
        if (identity) {
          req.identity = identity;
          req.user = identity;
        }
      }
    }

    if (!identity || identity.disabled) {
      return res.status(401).json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', req.originalUrl || req.url));
    }

    next();
  };
}

/**
 * Require specific role or roles
 */
export function requireRole(...roles) {
  const targetRoles = roles.flat().map(r => r.toLowerCase());
  return async (reqOrContext, resOrNext, nextFn) => {
    const isHono = typeof reqOrContext?.json === 'function' && typeof resOrNext === 'function';

    if (isHono) {
      const c = reqOrContext;
      const next = resOrNext;
      let identity = c.get('identity');

      if (!identity) {
        const token = extractTokenFromHono(c);
        if (token) {
          identity = await resolveIdentityFromToken(token, c.env);
          if (identity && !identity.disabled) {
            c.set('identity', identity);
            c.set('user', identity.toNormalizedUser());
            c.set('userId', identity.userId);
          }
        }
      }

      if (!identity || identity.disabled) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
      }

      const currentRole = (identity.role || identity.primaryRole || 'citizen').toLowerCase();
      const isBypass = currentRole === 'admin' || currentRole === 'super_admin' || currentRole === 'demo_admin' ||
        identity.hasRole?.('admin') || identity.hasRole?.('super_admin') || identity.hasRole?.('demo_admin');

      if (targetRoles.length > 0 && !isBypass && !identity.hasAnyRole(...targetRoles) && !targetRoles.includes(currentRole)) {
        return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền thực hiện thao tác này.', c.req.path), 403);
      }

      return next();
    }

    // Express mode
    const req = reqOrContext;
    const res = resOrNext;
    const next = nextFn;

    let identity = req.identity || (req.user instanceof IdentityContext ? req.user : (req.user ? createIdentityContext(req.user) : null));
    if (!identity) {
      const token = extractTokenFromExpress(req);
      if (token) {
        identity = await resolveIdentityFromToken(token, process.env);
        if (identity && !identity.disabled) {
          req.identity = identity;
          req.user = identity.toNormalizedUser();
        }
      }
    }

    if (!identity || identity.disabled) {
      return res.status(401).json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', req.originalUrl || req.url));
    }

    const currentRole = (identity.role || identity.primaryRole || 'citizen').toLowerCase();
    const isBypass = currentRole === 'admin' || currentRole === 'super_admin' || currentRole === 'demo_admin' ||
      identity.hasRole?.('admin') || identity.hasRole?.('super_admin') || identity.hasRole?.('demo_admin');

    if (targetRoles.length > 0 && !isBypass && !identity.hasAnyRole(...targetRoles) && !targetRoles.includes(currentRole)) {
      return res.status(403).json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền thực hiện thao tác này.', req.originalUrl || req.url));
    }

    next();
  };
}

export const requireAnyRole = requireRole;

/**
 * Fine-grained permission predicate middleware
 */
export function requirePermission(predicate) {
  return async (reqOrContext, resOrNext, nextFn) => {
    const isHono = typeof reqOrContext?.json === 'function' && typeof resOrNext === 'function';

    if (isHono) {
      const c = reqOrContext;
      const next = resOrNext;
      const identity = c.get('identity');
      if (!identity || identity.disabled) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
      }
      const allowed = await predicate(identity, c);
      if (!allowed) {
        return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Không đủ quyền hạn truy cập tài nguyên.', c.req.path), 403);
      }
      return next();
    }

    const req = reqOrContext;
    const res = resOrNext;
    const next = nextFn;
    const identity = req.identity || (req.user instanceof IdentityContext ? req.user : (req.user ? createIdentityContext(req.user) : null));
    if (!identity || identity.disabled) {
      return res.status(401).json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', req.originalUrl || req.url));
    }
    const allowed = await predicate(identity, req);
    if (!allowed) {
      return res.status(403).json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Không đủ quyền hạn truy cập tài nguyên.', req.originalUrl || req.url));
    }
    next();
  };
}
