/**
 * DustGuard VN - Idempotent D1 User Provisioning
 * Automatically & safely provisions/syncs internal profile from Clerk Identity without duplicate account race conditions.
 */

import { ROLES } from '../roles.js';

/**
 * Idempotently provisions or retrieves internal user from Clerk IdentityContext
 * @param {import('./identity-context.js').IdentityContext} identity
 * @param {Object} [db] - Cloudflare D1 or Prisma/SQLite client
 * @returns {Promise<{ user: Object, isNew: boolean }>}
 */
export async function provisionUserFromClerk(identity, db = null) {
  if (!identity || (!identity.clerkUserId && !identity.userId)) {
    throw new Error('Invalid IdentityContext for user provisioning');
  }

  const clerkUserId = identity.clerkUserId || identity.userId;
  const email = identity.email || `${clerkUserId}@dustguard.vn`;
  const fullName = identity.displayName || identity.name || 'Người dùng DustGuard';
  const role = identity.primaryRole || identity.role || ROLES.CITIZEN;
  const orgId = identity.organizationId || null;
  const now = new Date().toISOString();

  // If D1 binding is provided
  if (db && typeof db.prepare === 'function') {
    // 1. Look up existing user by clerk_user_id or id or email
    const existing = await db.prepare(
      'SELECT * FROM users WHERE clerk_user_id = ? OR id = ? OR email = ?'
    ).bind(clerkUserId, clerkUserId, email).first();

    if (existing) {
      // If user exists but clerk_user_id is not yet linked, link it idempotently
      if (!existing.clerk_user_id && clerkUserId) {
        try {
          await db.prepare(
            'UPDATE users SET clerk_user_id = ?, updatedAt = ? WHERE id = ?'
          ).bind(clerkUserId, now, existing.id).run();
        } catch (e) {}
      }

      return {
        user: {
          ...existing,
          role: existing.role || role,
          disabled: Boolean(existing.disabled || existing.status === 'DISABLED')
        },
        isNew: false
      };
    }

    // 2. Insert new user record idempotently
    const internalId = `usr_${clerkUserId.replace(/^user_/, '')}`;
    try {
      await db.prepare(
        `INSERT INTO users (id, clerk_user_id, full_name, email, email_verified, role, status, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?)`
      ).bind(internalId, clerkUserId, fullName, email, identity.emailVerified ? 1 : 0, role, now, now).run();

      // Create initial profile
      const profileId = `prof_${internalId}`;
      await db.prepare(
        `INSERT INTO profiles (id, userId, fullName, department, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).bind(profileId, internalId, fullName, orgId || 'Cộng đồng', now, now).run().catch(() => {});

      return {
        user: {
          id: internalId,
          clerk_user_id: clerkUserId,
          full_name: fullName,
          email,
          role,
          status: 'ACTIVE',
          disabled: false,
          createdAt: now,
          updatedAt: now
        },
        isNew: true
      };
    } catch (insertErr) {
      // In case of concurrent race condition, fetch the one that won the race
      const raceWinner = await db.prepare(
        'SELECT * FROM users WHERE clerk_user_id = ? OR email = ?'
      ).bind(clerkUserId, email).first();

      if (raceWinner) {
        return {
          user: {
            ...raceWinner,
            disabled: Boolean(raceWinner.disabled || raceWinner.status === 'DISABLED')
          },
          isNew: false
        };
      }
      throw insertErr;
    }
  }

  // Fallback in-memory provisioning for pure unit tests / non-DB environments
  return {
    user: {
      id: `usr_${clerkUserId}`,
      clerk_user_id: clerkUserId,
      full_name: fullName,
      email,
      role,
      status: identity.status || 'ACTIVE',
      disabled: identity.disabled || false,
      organizationId: orgId,
      createdAt: now,
      updatedAt: now
    },
    isNew: false
  };
}
