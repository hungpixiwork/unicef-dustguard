/**
 * DustGuard VN - Identity Context & Domain Authorization Contract (SSOT)
 * 
 * Invariants:
 * 1. Domain logic NEVER directly imports Clerk, Better Auth, or low-level auth SDKs.
 * 2. Domain services exclusively receive `IdentityContext` as actor parameter.
 * 3. Keeps human authentication strictly isolated from IoT device credentials.
 */

export const SYSTEM_ROLES = {
  CITIZEN: 'citizen',
  YOUTH_MEMBER: 'youth_member',
  STAFF: 'staff',
  INSPECTOR: 'inspector',
  EXECUTIVE: 'executive',
  CONTRACTOR: 'contractor',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin',
  SYSTEM: 'system'
};

export class IdentityContext {
  /**
   * @param {Object} params
   * @param {string} params.userId - Internal or external unique User ID
   * @param {string} [params.orgId] - Optional Organization/Team ID
   * @param {string} [params.sessionId] - Active session ID
   * @param {string[]|string} [params.roles] - Role list or single role
   * @param {string} [params.email] - User email
   * @param {string} [params.name] - User display name
   * @param {string} [params.authType='human'] - Auth provider type ('clerk', 'better_auth', 'system')
   * @param {Object} [params.metadata] - Additional safe claims
   */
  constructor({
    userId,
    orgId = null,
    sessionId = null,
    roles = ['citizen'],
    email = null,
    name = null,
    authType = 'human',
    metadata = {}
  }) {
    if (!userId) {
      throw new Error('IdentityContext requires a valid userId');
    }
    this.userId = String(userId);
    this.orgId = orgId ? String(orgId) : null;
    this.sessionId = sessionId ? String(sessionId) : null;
    this.roles = Array.isArray(roles)
      ? roles.map(r => String(r).toLowerCase())
      : [String(roles || 'citizen').toLowerCase()];
    this.email = email ? String(email) : null;
    this.name = name ? String(name) : null;
    this.authType = authType;
    this.metadata = metadata || {};
  }

  /**
   * Checks if user has a specific role (Admins always inherit all permissions).
   * @param {string} role 
   * @returns {boolean}
   */
  hasRole(role) {
    if (!role) return false;
    const target = role.toLowerCase();
    return (
      this.roles.includes(target) ||
      this.roles.includes(SYSTEM_ROLES.ADMIN) ||
      this.roles.includes(SYSTEM_ROLES.SUPER_ADMIN)
    );
  }

  /**
   * Checks if user has any of the specified roles.
   * @param {...string} roles 
   * @returns {boolean}
   */
  hasAnyRole(...roles) {
    const flat = roles.flat();
    return flat.some(r => this.hasRole(r));
  }

  /**
   * Convenience helpers
   */
  isAdmin() {
    return this.hasAnyRole(SYSTEM_ROLES.ADMIN, SYSTEM_ROLES.SUPER_ADMIN);
  }

  isStaffOrAbove() {
    return this.hasAnyRole(
      SYSTEM_ROLES.STAFF,
      SYSTEM_ROLES.INSPECTOR,
      SYSTEM_ROLES.EXECUTIVE,
      SYSTEM_ROLES.ADMIN,
      SYSTEM_ROLES.SUPER_ADMIN
    );
  }

  isContractor() {
    return this.hasRole(SYSTEM_ROLES.CONTRACTOR);
  }

  isCitizen() {
    return this.hasRole(SYSTEM_ROLES.CITIZEN) || this.hasRole(SYSTEM_ROLES.YOUTH_MEMBER);
  }
}

/**
 * Creates IdentityContext from generic user object (Clerk / Better Auth / Request user).
 * @param {Object} user 
 * @param {Object} [session] 
 * @returns {IdentityContext|null}
 */
export function createIdentityContext(user, session = null) {
  if (!user || !user.id) return null;
  return new IdentityContext({
    userId: user.id,
    orgId: user.organizationId || user.orgId || null,
    sessionId: session?.id || user.sessionId || null,
    roles: user.role ? [user.role] : (user.roles || ['citizen']),
    email: user.email || null,
    name: user.name || user.full_name || null,
    authType: user.clerkId ? 'clerk' : (user.authType || 'human')
  });
}

/**
 * Creates a System-level identity context for background cron / alert engine tasks.
 * @param {string} [actorName='System Worker'] 
 * @returns {IdentityContext}
 */
export function createSystemIdentityContext(actorName = 'System Engine') {
  return new IdentityContext({
    userId: 'system_actor',
    roles: [SYSTEM_ROLES.SYSTEM, SYSTEM_ROLES.ADMIN],
    name: actorName,
    authType: 'system'
  });
}
