/**
 * DustGuard VN - Comprehensive OpenAPI 3.0.3 Specification
 * Single Source of Truth for all API Contracts, Schemas, and Endpoints (100% Full Coverage)
 */

export const openApiSpec = {
  "openapi": "3.0.3",
  "info": {
    "title": "DustGuard VN API - Civil Environmental Protection Platform",
    "version": "1.0.0",
    "description": "DustGuard VN là Nền tảng Công nghệ Giám sát Bụi Mịn Xây dựng & Pháp Lý Môi trường (Civil Environmental Enforcement Platform) phục vụ Giám sát Công dân, Thanh tra Môi trường, Nhà thầu Xây dựng và Cơ quan Quản lý Nhà nước.\n\n### Kiến trúc Kỹ thuật:\n- **Cloudflare-Native Modular Monolith**: Hono Edge Gateway (`server/worker.js`)\n- **Relational Store**: Cloudflare D1 Native Database (`env.DB`)\n- **Object Storage**: Cloudflare R2 Storage (`env.STORAGE`, `env.EVIDENCE_BUCKET`)\n- **Digital Integrity**: Web Crypto SHA-256 Fingerprinting & HMAC-SHA256\n- **Legal Compliance**: Nghị định 30/2020/NĐ-CP (Thể thức văn bản A4), Nghị định 45/2022/NĐ-CP, Nghị định 16/2022/NĐ-CP",
    "contact": {
      "name": "DustGuard Engineering Team",
      "email": "tech@dustguard.vn",
      "url": "https://dustguard.vn"
    },
    "license": {
      "name": "UNICEF Hackathon 2026 - MIT"
    }
  },
  "servers": [
    {
      "url": "https://dustguard.vn",
      "description": "Cloudflare Production Worker Gateway"
    },
    {
      "url": "http://localhost:5173",
      "description": "Local Development Server (Vite + Edge Proxy)"
    },
    {
      "url": "http://localhost:3000",
      "description": "Local Express / D1 Test Harness"
    }
  ],
  "tags": [
    {
      "name": "System & Health",
      "description": "Kiểm tra trạng thái hệ thống, cấu hình và chẩn đoán nền tảng"
    },
    {
      "name": "Authentication & RBAC",
      "description": "Xác thực người dùng, phiên đăng nhập, cookie HttpOnly và thông tin hồ sơ"
    },
    {
      "name": "Sites & Monitoring",
      "description": "Quản lý công trường xây dựng, chỉ số bụi PM2.5/PM10 và checklist an toàn"
    },
    {
      "name": "Public & GIS",
      "description": "Cơ sở dữ liệu hành chính 63 tỉnh thành, phường xã và định vị GIS không gian"
    },
    {
      "name": "Citizen Reporting",
      "description": "Cổng tiếp nhận phản ánh công dân, hàng chờ offline và tra cứu mã hồ sơ"
    },
    {
      "name": "Case Management (DDD)",
      "description": "Máy trạng thái xử lý vi phạm 7 bước: Tiếp nhận -> Thanh tra -> Giải trình -> Xử phạt -> Đóng"
    },
    {
      "name": "Inspections & Actions",
      "description": "Biên bản kiểm tra hiện trường và danh mục hành động khắc phục"
    },
    {
      "name": "IoT Telemetry",
      "description": "Thu thập chỉ số cảm biến thời gian thực, chống giả mạo chữ ký HMAC và flatline"
    },
    {
      "name": "CSR Escrow & DEMS",
      "description": "Quỹ ký quỹ môi trường CSR, điểm phơi nhiễm DEMS và báo cáo ESG GRI 304/305"
    },
    {
      "name": "Contractor Zero-Login",
      "description": "Truy cập không cần mật khẩu qua Zalo/SMS và kiểm định Geofence 50m"
    },
    {
      "name": "Youth Green Credits",
      "description": "Ghi nhận giờ hoạt động tình nguyện, chống spam và xuất hồ sơ hoạt động có mã băm toàn vẹn"
    },
    {
      "name": "Legal Documents & A4",
      "description": "Trích xuất nghĩa vụ pháp lý, biên tập văn bản A4 và ký số điện tử"
    },
    {
      "name": "Dashboard & Operations",
      "description": "Thống kê tổng hợp điều hành, bản đồ nhiệt GIS và cảnh báo vượt SLA"
    },
    {
      "name": "AI & Policy Intelligence",
      "description": "Trợ lý AI giải thích vi phạm, tra cứu pháp luật và đề xuất chế tài"
    },
    {
      "name": "Youth Community Action",
      "description": "Cổng hành động CLB/Thanh niên: Ghi nhận đa danh mục, Theo dõi lại, Chiến dịch và Handoff"
    },
    {
      "name": "Admin & System Data Management",
      "description": "Quản trị CSDL D1, xem trước và reset dữ liệu an toàn, nạp Canonical Seed"
    },
    {
      "name": "Cloudflare R2 Storage & Uploads",
      "description": "Tải lên minh chứng ảnh/tài liệu, định danh số SHA-256 và phục vụ qua CDN R2"
    },
    {
      "name": "Contractor Compliance Workspace",
      "description": "Không gian làm việc và khắc phục vi phạm dành cho Nhà thầu thi công (SSOT D1)"
    }
  ],
  "components": {
    "securitySchemes": {
      "BearerAuth": {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
        "description": "Nhập token phiên đăng nhập (Session Token)"
      },
      "CookieAuth": {
        "type": "apiKey",
        "in": "cookie",
        "name": "better-auth.session_token",
        "description": "Cookie phiên đăng nhập bảo mật HttpOnly"
      }
    },
    "schemas": {
      "StandardResponse": {
        "type": "object",
        "properties": {
          "status": {
            "type": "string",
            "example": "success"
          },
          "data": {
            "type": "object"
          },
          "message": {
            "type": "string",
            "example": "Thao tác thành công"
          }
        },
        "required": [
          "status"
        ]
      },
      "ProblemDetails": {
        "type": "object",
        "properties": {
          "type": {
            "type": "string",
            "example": "https://dustguard.vn/errors/unauthorized"
          },
          "title": {
            "type": "string",
            "example": "Forbidden"
          },
          "status": {
            "type": "number",
            "example": 403
          },
          "detail": {
            "type": "string",
            "example": "Chỉ lãnh đạo mới có quyền thực hiện thao tác này."
          },
          "code": {
            "type": "string",
            "example": "FORBIDDEN"
          }
        },
        "required": [
          "status",
          "title"
        ]
      },
      "User": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "usr_demo_staff"
          },
          "email": {
            "type": "string",
            "format": "email",
            "example": "staff@dustguard.vn"
          },
          "name": {
            "type": "string",
            "example": "Nguyễn Văn An"
          },
          "role": {
            "type": "string",
            "enum": [
              "citizen",
              "staff",
              "contractor",
              "executive",
              "demo_admin"
            ],
            "example": "staff"
          },
          "emailVerified": {
            "type": "boolean",
            "example": true
          },
          "profile": {
            "type": "object",
            "properties": {
              "fullName": {
                "type": "string",
                "example": "Nguyễn Văn An"
              },
              "department": {
                "type": "string",
                "example": "Phòng Thanh Tra Môi Trường"
              }
            }
          }
        }
      },
      "Site": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "BD-0237"
          },
          "code": {
            "type": "string",
            "example": "BD-0237"
          },
          "name": {
            "type": "string",
            "example": "Dự án Cầu Giấy Complex"
          },
          "address": {
            "type": "string",
            "example": "123 Xuân Thủy, Cầu Giấy, Hà Nội"
          },
          "ward": {
            "type": "string",
            "example": "Mai Dịch"
          },
          "province": {
            "type": "string",
            "example": "Hà Nội"
          },
          "coordinates": {
            "type": "string",
            "example": "21.02851, 105.85420"
          },
          "dustRiskScore": {
            "type": "number",
            "minimum": 0,
            "maximum": 100,
            "example": 85
          },
          "riskLevel": {
            "type": "string",
            "enum": [
              "LOW",
              "MEDIUM",
              "HIGH",
              "CRITICAL"
            ],
            "example": "HIGH"
          },
          "status": {
            "type": "string",
            "enum": [
              "ACTIVE",
              "INACTIVE",
              "SUSPENDED"
            ],
            "example": "ACTIVE"
          },
          "investorName": {
            "type": "string",
            "example": "Tập đoàn Bất động sản Thủ Đô"
          },
          "contractorName": {
            "type": "string",
            "example": "Tổng Công Ty XD Số 1"
          },
          "licenseNumber": {
            "type": "string",
            "example": "GPXD-2026-HN-0092"
          }
        }
      },
      "Complaint": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "cmp_1785213400000"
          },
          "code": {
            "type": "string",
            "example": "DG-2026-F4A1"
          },
          "siteId": {
            "type": "string",
            "nullable": true,
            "example": "BD-0237"
          },
          "ward": {
            "type": "string",
            "example": "Mai Dịch"
          },
          "address": {
            "type": "string",
            "example": "18 Phạm Hùng, Cầu Giấy, Hà Nội"
          },
          "description": {
            "type": "string",
            "example": "Bụi phát tán mù mịt từ xe chở vật liệu không che chắn."
          },
          "reporterName": {
            "type": "string",
            "example": "Nguyễn Văn Nam"
          },
          "reporterPhone": {
            "type": "string",
            "example": "0988123456"
          },
          "status": {
            "type": "string",
            "enum": [
              "PENDING",
              "PROCESSING",
              "VERIFIED",
              "RESOLVED",
              "REJECTED"
            ],
            "example": "PENDING"
          },
          "createdAt": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "Case": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "case_001"
          },
          "code": {
            "type": "string",
            "example": "CASE-2026-001"
          },
          "title": {
            "type": "string",
            "example": "Xử lý vi phạm bụi mịn Dự án Cầu Giấy"
          },
          "status": {
            "type": "string",
            "enum": [
              "OPEN",
              "VERIFICATION",
              "INSPECTION",
              "EXPLAINING",
              "SANCTIONED",
              "RECTIFYING",
              "COMPLETED"
            ],
            "example": "INSPECTION"
          },
          "siteId": {
            "type": "string",
            "example": "BD-0237"
          },
          "site": {
            "$ref": "#/components/schemas/Site"
          },
          "timeline": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "id": {
                  "type": "string"
                },
                "eventTitle": {
                  "type": "string"
                },
                "eventDescription": {
                  "type": "string"
                },
                "actorName": {
                  "type": "string"
                },
                "actorRole": {
                  "type": "string"
                },
                "createdAt": {
                  "type": "string",
                  "format": "date-time"
                }
              }
            }
          }
        }
      },
      "YouthCredits": {
        "type": "object",
        "properties": {
          "userId": {
            "type": "string",
            "example": "usr_volunteer_01"
          },
          "studentName": {
            "type": "string",
            "example": "Nguyễn Thị Lan"
          },
          "university": {
            "type": "string",
            "example": "Đại học Bách Khoa Hà Nội"
          },
          "studentId": {
            "type": "string",
            "example": "2026-HUST-8899"
          },
          "volunteerHours": {
            "type": "number",
            "example": 20
          },
          "extracurricularCredits": {
            "type": "number",
            "example": 4
          },
          "progressPercentage": {
            "type": "number",
            "example": 100
          },
          "goalReached": {
            "type": "boolean",
            "example": true
          },
          "certificateEligible": {
            "type": "boolean",
            "example": true
          }
        }
      },
      "DemsAssessment": {
        "type": "object",
        "properties": {
          "demsScore": {
            "type": "number",
            "minimum": 0,
            "maximum": 100,
            "example": 88
          },
          "demsTier": {
            "type": "string",
            "enum": [
              "EXCELLENT",
              "GOOD",
              "MODERATE",
              "POOR",
              "CRITICAL"
            ],
            "example": "EXCELLENT"
          },
          "complianceStatus": {
            "type": "string",
            "example": "COMPLIANT"
          },
          "factors": {
            "type": "object"
          }
        }
      },
      "Community": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "comm_01"
          },
          "name": {
            "type": "string",
            "example": "CLB Môi Trường Xanh UIT"
          },
          "type": {
            "type": "string",
            "enum": [
              "UNIVERSITY_CLUB",
              "VOLUNTEER_TEAM",
              "YOUTH_UNION",
              "SCHOOL_TEAM"
            ],
            "example": "UNIVERSITY_CLUB"
          },
          "ward": {
            "type": "string",
            "example": "Linh Trung"
          },
          "city": {
            "type": "string",
            "example": "TP. Hồ Chí Minh"
          },
          "member_count": {
            "type": "number",
            "example": 45
          }
        }
      },
      "Campaign": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "camp_01"
          },
          "code": {
            "type": "string",
            "example": "CAMP-2026-SCHOOL-01"
          },
          "title": {
            "type": "string",
            "example": "Chiến dịch Giám sát Bụi Quanh Trường Học Tháng 9"
          },
          "topic": {
            "type": "string",
            "example": "SCHOOL_ZONE_DUST"
          },
          "status": {
            "type": "string",
            "enum": [
              "ACTIVE",
              "COMPLETED",
              "UPCOMING"
            ],
            "example": "ACTIVE"
          },
          "participant_count": {
            "type": "number",
            "example": 28
          },
          "observation_count": {
            "type": "number",
            "example": 64
          }
        }
      },
      "Observation": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "obs_01"
          },
          "code": {
            "type": "string",
            "example": "OBS-2026-A1B2"
          },
          "category": {
            "type": "string",
            "enum": [
              "CONSTRUCTION_DUST",
              "WASTE",
              "WASTEWATER",
              "OPEN_BURNING",
              "AGRICULTURAL_CHEMICAL",
              "AIR_QUALITY",
              "OTHER"
            ],
            "example": "CONSTRUCTION_DUST"
          },
          "address": {
            "type": "string",
            "example": "Số 10 Trịnh Văn Bô, Nam Từ Liêm"
          },
          "ward": {
            "type": "string",
            "example": "Xuân Phương"
          },
          "city": {
            "type": "string",
            "example": "Hà Nội"
          },
          "description": {
            "type": "string",
            "example": "Bụi công trường bay mù mịt khu vực cổng trường"
          },
          "status": {
            "type": "string",
            "enum": [
              "RECORDED",
              "IN_PROGRESS",
              "RESOLVED",
              "REJECTED"
            ],
            "example": "RECORDED"
          },
          "evidences": {
            "type": "array",
            "items": {
              "type": "object"
            }
          },
          "created_at": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "FollowUp": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "fol_01"
          },
          "observation_id": {
            "type": "string",
            "example": "obs_01"
          },
          "outcome_status": {
            "type": "string",
            "enum": [
              "BETTER",
              "UNCHANGED",
              "WORSE",
              "UNKNOWN"
            ],
            "example": "BETTER"
          },
          "notes": {
            "type": "string",
            "example": "Đã có lưới che chắn và xe bồn tưới nước."
          },
          "verified_at": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "Handoff": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "example": "hnd_01"
          },
          "case_id": {
            "type": "string",
            "example": "case_001"
          },
          "recipient_unit": {
            "type": "string",
            "example": "UBND Phường & Đội Thanh Tra Môi Trường"
          },
          "channel": {
            "type": "string",
            "enum": [
              "EMAIL",
              "WEBSITE",
              "HOTLINE",
              "DIRECT",
              "OTHER"
            ],
            "example": "EMAIL"
          },
          "status": {
            "type": "string",
            "enum": [
              "PREPARED",
              "SENT",
              "ACKNOWLEDGED",
              "FOLLOW_UP_NEEDED",
              "CLOSED"
            ],
            "example": "SENT"
          }
        }
      },
      "SystemDataStats": {
        "type": "object",
        "properties": {
          "sites": {
            "type": "number",
            "example": 12
          },
          "cases": {
            "type": "number",
            "example": 7
          },
          "complaints": {
            "type": "number",
            "example": 24
          },
          "sensors": {
            "type": "number",
            "example": 8
          },
          "auditLogs": {
            "type": "number",
            "example": 180
          }
        }
      }
    }
  },
  "paths": {
    "/health": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "Kiểm tra trạng thái máy chủ Worker / Express",
        "responses": {
          "200": {
            "description": "Máy chủ hoạt động bình thường",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "status": {
                      "type": "string",
                      "example": "ok"
                    },
                    "platform": {
                      "type": "string",
                      "example": "Cloudflare Worker Native"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/api/config": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "Lấy cấu hình hệ thống & AI Provider",
        "responses": {
          "200": {
            "description": "Cấu hình nền tảng",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/auth/login": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Đăng nhập người dùng (Email/Password)",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "email": {
                    "type": "string",
                    "example": "staff@dustguard.vn"
                  },
                  "password": {
                    "type": "string",
                    "example": "DustGuard@2026!"
                  }
                },
                "required": [
                  "email",
                  "password"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Đăng nhập thành công, trả thông tin User và thiết lập Cookie HttpOnly",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/User"
                }
              }
            }
          },
          "401": {
            "description": "Sai email hoặc mật khẩu"
          }
        }
      }
    },
    "/api/auth/register": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Đăng ký tài khoản công dân mới",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "full_name": {
                    "type": "string",
                    "example": "Nguyễn Văn Citizen"
                  },
                  "email": {
                    "type": "string",
                    "format": "email",
                    "example": "citizen.new@dustguard.vn"
                  },
                  "password": {
                    "type": "string",
                    "example": "Password123!"
                  }
                },
                "required": [
                  "full_name",
                  "email",
                  "password"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Đăng ký thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/User"
                }
              }
            }
          },
          "400": {
            "description": "Dữ liệu không hợp lệ hoặc Email đã tồn tại"
          }
        }
      }
    },
    "/api/auth/me": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Lấy thông tin tài khoản hiện tại",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Hồ sơ người dùng",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/User"
                }
              }
            }
          },
          "401": {
            "description": "Chưa xác thực"
          }
        }
      }
    },
    "/api/auth/logout": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Đăng xuất và hủy phiên làm việc",
        "responses": {
          "200": {
            "description": "Đăng xuất thành công",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "ok": {
                      "type": "boolean",
                      "example": true
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/api/users": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Danh sách người dùng hệ thống (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách người dùng",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Tạo người dùng mới với phân quyền cụ thể (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "email": {
                    "type": "string",
                    "format": "email",
                    "example": "inspector.new@dustguard.vn"
                  },
                  "password": {
                    "type": "string",
                    "example": "SecretPass123!"
                  },
                  "fullName": {
                    "type": "string",
                    "example": "Trần Văn Cán Bộ"
                  },
                  "role": {
                    "type": "string",
                    "enum": [
                      "citizen",
                      "staff",
                      "contractor",
                      "executive",
                      "admin"
                    ],
                    "example": "staff"
                  }
                },
                "required": [
                  "email",
                  "password",
                  "role"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Tạo tài khoản thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/users/{id}": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Lấy chi tiết người dùng theo ID (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Chi tiết người dùng",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "delete": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Xóa người dùng (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Xóa người dùng thành công"
          }
        }
      }
    },
    "/api/citizen/profile": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Lấy thông tin hồ sơ và tùy chọn công dân",
        "responses": {
          "200": {
            "description": "Thông tin hồ sơ công dân",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "put": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Cập nhật hồ sơ công dân (PUT)",
        "responses": {
          "200": {
            "description": "Cập nhật thành công"
          }
        }
      },
      "patch": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Cập nhật một phần hồ sơ và quyền riêng tư công dân (PATCH)",
        "responses": {
          "200": {
            "description": "Cập nhật thành công"
          }
        }
      }
    },
    "/api/v1/citizen/profile": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "GET /api/v1/citizen/profile",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      },
      "put": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PUT /api/v1/citizen/profile",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      },
      "patch": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PATCH /api/v1/citizen/profile",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/users/{id}/profile": {
      "patch": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Cập nhật từng phần hồ sơ người dùng",
        "responses": {
          "200": {
            "description": "Cập nhật thành công"
          }
        }
      },
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Cập nhật thông tin cá nhân của người dùng",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "fullName": {
                    "type": "string",
                    "example": "Nguyễn Văn An"
                  },
                  "phoneNumber": {
                    "type": "string",
                    "example": "0988123456"
                  },
                  "department": {
                    "type": "string",
                    "example": "Phòng Thanh Tra Môi Trường"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Cập nhật hồ sơ thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/users/{id}/role": {
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Cập nhật vai trò người dùng (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "role": {
                    "type": "string",
                    "enum": [
                      "citizen",
                      "staff",
                      "contractor",
                      "executive",
                      "admin",
                      "youth_member",
                      "inspector"
                    ],
                    "example": "staff"
                  }
                },
                "required": [
                  "role"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Cập nhật vai trò người dùng thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/users/{id}/status": {
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "PUT /api/users/{id}/status - Cập nhật trạng thái người dùng (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "status": {
                    "type": "string",
                    "enum": [
                      "ACTIVE",
                      "DISABLED",
                      "SUSPENDED"
                    ]
                  }
                },
                "required": [
                  "status"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/users": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/v1/users - Danh sách người dùng (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/v1/users - Tạo người dùng mới thủ công (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "fullName": {
                    "type": "string"
                  },
                  "email": {
                    "type": "string"
                  },
                  "role": {
                    "type": "string"
                  },
                  "status": {
                    "type": "string"
                  }
                },
                "required": [
                  "fullName",
                  "email"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Tạo người dùng thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/users/{id}/status": {
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "PUT /api/v1/users/{id}/status - Cập nhật trạng thái người dùng (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "status": {
                    "type": "string",
                    "enum": [
                      "ACTIVE",
                      "DISABLED",
                      "SUSPENDED"
                    ]
                  }
                },
                "required": [
                  "status"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/users/{id}": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/v1/users/{id} - Lấy chi tiết người dùng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      },
      "delete": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "DELETE /api/v1/users/{id} - Vô hiệu hóa người dùng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/v1/users/{id}/profile": {
      "patch": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "Cập nhật từng phần hồ sơ người dùng",
        "responses": {
          "200": {
            "description": "Cập nhật thành công"
          }
        }
      },
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "PUT /api/v1/users/{id}/profile - Cập nhật thông tin cá nhân",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/v1/users/{id}/role": {
      "put": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "PUT /api/v1/users/{id}/role - Cập nhật vai trò người dùng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/sites": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "Lấy danh sách tất cả các công trường",
        "responses": {
          "200": {
            "description": "Danh sách công trường kèm chỉ số rủi ro bụi",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "Tạo công trường xây dựng mới (Staff/Admin)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "name": {
                    "type": "string",
                    "example": "Tòa nhà Landmark 81"
                  },
                  "address": {
                    "type": "string",
                    "example": "720A Điện Biên Phủ, Bình Thạnh, TP.HCM"
                  },
                  "ward": {
                    "type": "string",
                    "example": "Phường 22"
                  },
                  "province": {
                    "type": "string",
                    "example": "Hồ Chí Minh"
                  },
                  "contractorName": {
                    "type": "string",
                    "example": "Coteccons"
                  }
                },
                "required": [
                  "name",
                  "address",
                  "ward"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Tạo công trường thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/sites/{id}": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "Lấy chi tiết công trường theo ID hoặc Mã",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "example": "BD-0237"
          }
        ],
        "responses": {
          "200": {
            "description": "Thông tin chi tiết công trường",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "404": {
            "description": "Không tìm thấy công trường"
          }
        }
      },
      "patch": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "Cập nhật thông tin công trường (Staff/Admin)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Cập nhật thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "delete": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "Xóa mềm công trường (Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Xóa công trường thành công"
          }
        }
      },
      "put": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "PUT /api/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/public/sites": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "Lấy danh sách công trường cho bản đồ giám sát công dân",
        "responses": {
          "200": {
            "description": "Danh sách công trường công khai",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/public/provinces": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "Lấy danh mục 63 Tỉnh/Thành phố Việt Nam",
        "responses": {
          "200": {
            "description": "Danh sách tỉnh thành",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/public/provinces/{code}/wards": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "Lấy danh sách Phường/Xã theo Mã Tỉnh",
        "parameters": [
          {
            "name": "code",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "example": "01"
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách phường xã",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/public/gis/detect-location": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "Định vị tự động Phường/Xã từ tọa độ GPS",
        "parameters": [
          {
            "name": "lat",
            "in": "query",
            "schema": {
              "type": "number"
            },
            "example": 21.0285
          },
          {
            "name": "lng",
            "in": "query",
            "schema": {
              "type": "number"
            },
            "example": 105.8542
          }
        ],
        "responses": {
          "200": {
            "description": "Thông tin đơn vị hành chính xác định được",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/public/stats": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "Thống kê tổng hợp phản ánh công cộng",
        "responses": {
          "200": {
            "description": "Tổng số phản ánh, tỷ lệ giải quyết, thời gian trung bình",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/complaints": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Danh sách phản ánh công dân (có lọc theo trạng thái/công trường)",
        "parameters": [
          {
            "name": "status",
            "in": "query",
            "schema": {
              "type": "string"
            }
          },
          {
            "name": "siteId",
            "in": "query",
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách phản ánh",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Gửi phản ánh vi phạm bụi công trường mới",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "ward": {
                    "type": "string",
                    "example": "Mai Dịch"
                  },
                  "address": {
                    "type": "string",
                    "example": "18 Phạm Hùng, Cầu Giấy, Hà Nội"
                  },
                  "description": {
                    "type": "string",
                    "example": "Bụi phát tán mạnh trong giờ cao điểm."
                  },
                  "reporterName": {
                    "type": "string",
                    "example": "Nguyễn Văn Nam"
                  },
                  "reporterPhone": {
                    "type": "string",
                    "example": "0988123456"
                  }
                },
                "required": [
                  "ward",
                  "address",
                  "description"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Gửi phản ánh thành công, cấp mã theo dõi DG-2026-XXXX",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/complaints/{id}/verify": {
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Ghi nhận phản hồi và quan sát từ công dân (Citizen Observation & Feedback)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ghi nhận thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/complaints/{id}/feedback": {
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Ghi nhận quan sát hiện trường từ người dân (Citizen Observation)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ghi nhận thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/citizen/reports/{id}/observations": {
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Ghi nhận quan sát thực địa cho phản ánh (Citizen Observations)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ghi nhận thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/complaints/{id}/verify": {
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "POST /api/v1/complaints/{id}/verify",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/complaints/{id}/convert-to-case": {
      "post": {
        "tags": [
          "Citizen Reporting",
          "Case Management (DDD)"
        ],
        "summary": "Chuyển phản ánh thành hồ sơ vụ việc thanh tra (convert complaint to case)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Chuyển đổi thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/complaints/{id}": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "Tra cứu chi tiết phản ánh theo Mã hồ sơ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "example": "DG-2026-F4A1"
          }
        ],
        "responses": {
          "200": {
            "description": "Chi tiết phản ánh kèm công trường và minh chứng",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "404": {
            "description": "Không tìm thấy phản ánh"
          }
        }
      },
      "patch": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PATCH /api/complaints/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PUT /api/complaints/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases": {
      "get": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Lấy danh sách toàn bộ hồ sơ vụ việc thanh tra",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "status",
            "in": "query",
            "schema": {
              "type": "string"
            }
          },
          {
            "name": "siteId",
            "in": "query",
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách hồ sơ vụ việc",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "POST /api/cases - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}": {
      "get": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Lấy chi tiết hồ sơ vụ việc, timeline, giải trình & quyết định xử phạt",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "example": "case_001"
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu chi tiết hồ sơ",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "put": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "PUT /api/cases/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "PATCH /api/cases/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Xóa mềm hồ sơ vụ việc (Staff/Admin)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Xóa vụ việc thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          },
          "404": {
            "description": "Không tìm thấy vụ việc"
          }
        }
      }
    },
    "/api/cases/{id}/verify": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Bước 1: Cán bộ xác minh phản ánh hiện trường (VERIFICATION)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "note": {
                    "type": "string",
                    "example": "Đã xác minh nguồn bụi xuất phát từ cổng số 2."
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Chuyển trạng thái thành công"
          }
        }
      }
    },
    "/api/cases/{id}/assign": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Bước 2: Phân công đoàn thanh tra (INSPECTION)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "inspectorId": {
                    "type": "string"
                  },
                  "note": {
                    "type": "string"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Phân công thành công"
          }
        }
      }
    },
    "/api/cases/{id}/request-explanation": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Bước 3: Yêu cầu nhà thầu giải trình (EXPLAINING)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Yêu cầu giải trình thành công"
          }
        }
      }
    },
    "/api/cases/{id}/explanations": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Nhà thầu gửi văn bản giải trình và hồ sơ minh chứng",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "explanation": {
                    "type": "string",
                    "example": "Sự cố vòi xịt rửa xe do hỏng máy bơm, đã thay mới trong 2h."
                  },
                  "evidenceUrls": {
                    "type": "array",
                    "items": {
                      "type": "string"
                    }
                  }
                },
                "required": [
                  "explanation"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Gửi giải trình thành công"
          }
        }
      }
    },
    "/api/cases/{id}/sanction": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Lập dự thảo quyết định xử phạt vi phạm hành chính",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Lập dự thảo xử phạt thành công"
          }
        }
      }
    },
    "/api/cases/{id}/decisions/{decisionId}/approve": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Lãnh đạo ký duyệt quyết định xử phạt",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          },
          {
            "name": "decisionId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ký duyệt quyết định thành công"
          }
        }
      }
    },
    "/api/cases/{id}/rectify": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Bước 4: Nhà thầu tiến hành khắc phục vi phạm (RECTIFYING)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Ghi nhận khắc phục thành công"
          }
        }
      }
    },
    "/api/cases/{id}/complete": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "Bước 5: Hoàn tất và đóng hồ sơ vụ việc (COMPLETED)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Đóng hồ sơ thành công"
          }
        }
      }
    },
    "/api/cases/{id}/dispatch-mission": {
      "post": {
        "tags": [
          "Case Management (DDD)",
          "Youth Community Action"
        ],
        "summary": "Điều phối nhiệm vụ kiểm tra cộng đồng / thanh niên cho vụ việc",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Giao nhiệm vụ thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/contractor/quick-token": {
      "post": {
        "tags": [
          "Contractor Zero-Login"
        ],
        "summary": "Tạo token liên kết truy cập Zalo/SMS không cần đăng nhập (Staff/Executive/Admin)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "contractorPhone": {
                    "type": "string",
                    "example": "0988123456"
                  },
                  "expiresInHours": {
                    "type": "number",
                    "example": 72
                  }
                },
                "required": [
                  "siteId"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Token và liên kết truy cập nhanh Zalo/SMS",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "403": {
            "description": "Chưa xác thực hoặc không đủ quyền hạn"
          }
        }
      }
    },
    "/api/contractor/quick-submit/verify": {
      "get": {
        "tags": [
          "Contractor Zero-Login"
        ],
        "summary": "Xác thực tính hợp lệ của Token Zalo/SMS và lấy ngữ cảnh công trình",
        "parameters": [
          {
            "name": "token",
            "in": "query",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu công trình và thời hạn token",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Token không hợp lệ hoặc đã hết hạn"
          }
        }
      }
    },
    "/api/contractor/quick-submit": {
      "post": {
        "tags": [
          "Contractor Zero-Login"
        ],
        "summary": "Nhà thầu nộp minh chứng khắc phục kèm kiểm định Geofence 50m",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "latitude": {
                    "type": "number",
                    "example": 21.02851
                  },
                  "longitude": {
                    "type": "number",
                    "example": 105.8542
                  },
                  "explanation": {
                    "type": "string",
                    "example": "Đã hoàn tất phun ẩm dập bụi và rửa lốp xe."
                  },
                  "evidenceUrl": {
                    "type": "string",
                    "example": "/uploads/evidence-01.jpg"
                  }
                },
                "required": [
                  "siteId",
                  "latitude",
                  "longitude",
                  "explanation"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Nộp minh chứng thành công, kết quả Geofence 50m",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/csr/calculate-dems": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Tính điểm phơi nhiễm bụi DEMS (Dust Exposure Mitigation Score)",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "barrierInstalled": {
                    "type": "boolean",
                    "example": true
                  },
                  "mistingFrequency": {
                    "type": "number",
                    "example": 4
                  },
                  "uncoveredTruckCount": {
                    "type": "number",
                    "example": 0
                  },
                  "complaintsCount": {
                    "type": "number",
                    "example": 1
                  },
                  "sensitiveZoneDistanceMeters": {
                    "type": "number",
                    "example": 150
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Điểm DEMS và phân hạng tuân thủ",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/csr/escrow/create": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Thiết lập Hợp đồng Quỹ ký quỹ Môi trường CSR cho công trình (Staff/Executive/Admin)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "siteName": {
                    "type": "string",
                    "example": "Dự án Cầu Giấy Complex"
                  },
                  "contractorName": {
                    "type": "string",
                    "example": "Tổng Công ty XD Số 1"
                  },
                  "totalEscrowAmount": {
                    "type": "number",
                    "example": 500000000
                  }
                },
                "required": [
                  "siteId"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Tạo hợp đồng Quỹ Escrow thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/csr/escrow/{siteId}": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Tra cứu trạng thái hợp đồng quỹ ký quỹ CSR của công trường",
        "parameters": [
          {
            "name": "siteId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "example": "BD-0237"
          }
        ],
        "responses": {
          "200": {
            "description": "Thông tin quỹ ký quỹ và các mốc giải ngân",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/csr/escrow/release-milestone": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Giải ngân mốc ký quỹ môi trường theo tiến độ nghiệm thu (Staff/Executive/Admin)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "milestoneId": {
                    "type": "string",
                    "example": "M1"
                  }
                },
                "required": [
                  "siteId",
                  "milestoneId"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Giải ngân mốc ký quỹ thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "403": {
            "description": "Không đủ quyền hạn thực hiện giải ngân"
          }
        }
      }
    },
    "/api/csr/escrow/forfeit": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Tịch thu Quỹ Escrow do vi phạm ô nhiễm nghiêm trọng (Executive/Admin only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "reason": {
                    "type": "string",
                    "example": "Vi phạm ô nhiễm quá thời hạn khắc phục"
                  }
                },
                "required": [
                  "siteId"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Tịch thu Quỹ Escrow thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "403": {
            "description": "Chỉ lãnh đạo mới có quyền tịch thu Quỹ"
          }
        }
      }
    },
    "/api/csr/certificate/export": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "Xuất chứng chỉ tuân thủ CSR & Báo cáo ESG GRI 304/305",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "siteName": {
                    "type": "string",
                    "example": "Dự án Cầu Giấy Complex"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Chứng chỉ CSR có mã QR và chữ ký điện tử"
          }
        }
      }
    },
    "/api/youth/credits": {
      "get": {
        "tags": [
          "Youth Green Credits"
        ],
        "summary": "Tra cứu giờ hoạt động tình nguyện và tiến độ mục tiêu sinh viên",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Tổng giờ đóng góp, đánh giá tích cực và tiến độ mục tiêu",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/youth/claim": {
      "post": {
        "tags": [
          "Youth Green Credits"
        ],
        "summary": "Ghi nhận hoàn thành mục tiêu giờ hoạt động thanh niên",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Ghi nhận hoạt động thành công và lưu nhật ký audit"
          }
        }
      }
    },
    "/api/youth/certificate": {
      "post": {
        "tags": [
          "Youth Green Credits"
        ],
        "summary": "Tạo chứng chỉ số đóng góp xanh có chữ ký số điện tử",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "studentName": {
                    "type": "string",
                    "example": "Nguyễn Thị Lan"
                  },
                  "university": {
                    "type": "string",
                    "example": "Đại học Bách Khoa Hà Nội"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Dữ liệu chứng chỉ số kèm chuỗi băm xác thực"
          }
        }
      },
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/youth/certificate - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/youth/leaderboard": {
      "get": {
        "tags": [
          "Youth Green Credits"
        ],
        "summary": "Bảng xếp hạng câu lạc bộ thanh niên xung kích các trường đại học",
        "responses": {
          "200": {
            "description": "Danh sách xếp hạng CLB"
          }
        }
      }
    },
    "/api/documents/drafts": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Danh sách văn bản hành chính & biên bản nháp",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách bản nháp văn bản",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Khởi tạo bản nháp văn bản A4 chuẩn Nghị định 30/2020",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string",
                    "example": "BD-0237"
                  },
                  "title": {
                    "type": "string",
                    "example": "Biên bản kiểm tra thực địa"
                  },
                  "documentType": {
                    "type": "string",
                    "enum": [
                      "INSPECTION_RECORD",
                      "CORRECTIVE_NOTICE",
                      "SANCTION_DECISION"
                    ],
                    "example": "INSPECTION_RECORD"
                  },
                  "content": {
                    "type": "string",
                    "example": "Nội dung biên bản..."
                  }
                },
                "required": [
                  "title",
                  "siteId"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Tạo bản nháp thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/documents/drafts/{id}": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Lấy chi tiết bản nháp văn bản",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Chi tiết văn bản",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "patch": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Cập nhật nội dung hoặc trạng thái bản nháp",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object"
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Cập nhật thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/documents/drafts/{id}/approve": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Lãnh đạo phê duyệt và ký số SHA-256 văn bản hành chính A4 (Executive only)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Phê duyệt thành công, ghi nhận chuỗi băm chữ ký số vào Audit Log"
          },
          "403": {
            "description": "Chỉ lãnh đạo mới có quyền ký số và duyệt văn bản"
          }
        }
      }
    },
    "/api/documents/drafts/{id}/verify-signature": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "Kiểm tra và thẩm định tính toàn vẹn của chữ ký số văn bản",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Kết quả thẩm định chữ ký số",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/sensors/reading": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "Lấy chỉ số bụi PM2.5 / PM10 mới nhất của cảm biến",
        "parameters": [
          {
            "name": "sensorCode",
            "in": "query",
            "schema": {
              "type": "string"
            },
            "example": "SEN-VD1"
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu cảm biến thời gian thực"
          }
        }
      },
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/sensors/reading - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/telemetry": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "Endpoint đẩy số liệu cảm biến IoT với kiểm tra chữ ký HMAC-SHA256",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "sensorCode": {
                    "type": "string",
                    "example": "SEN-VD1"
                  },
                  "pm10": {
                    "type": "number",
                    "example": 45.2
                  },
                  "pm25": {
                    "type": "number",
                    "example": 22.8
                  }
                },
                "required": [
                  "sensorCode",
                  "pm10",
                  "pm25"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Nhận dữ liệu thành công"
          },
          "400": {
            "description": "Thiếu trường bắt buộc hoặc thời gian trôi > 5 phút"
          }
        }
      }
    },
    "/api/v1/telemetry": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "Endpoint đẩy số liệu cảm biến IoT với kiểm tra chữ ký HMAC-SHA256",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "sensorCode": {
                    "type": "string",
                    "example": "SEN-VD1"
                  },
                  "pm10": {
                    "type": "number",
                    "example": 45.2
                  },
                  "pm25": {
                    "type": "number",
                    "example": 22.8
                  }
                },
                "required": [
                  "sensorCode",
                  "pm10",
                  "pm25"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Nhận dữ liệu thành công"
          },
          "400": {
            "description": "Thiếu trường bắt buộc hoặc thời gian trôi > 5 phút"
          }
        }
      }
    },
    "/api/map": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Lấy dữ liệu GIS bản đồ không gian và tọa độ công trường",
        "responses": {
          "200": {
            "description": "Dữ liệu bản đồ phẳng hóa và mức độ rủi ro"
          }
        }
      }
    },
    "/api/public/map/features": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Lấy dữ liệu GeoJSON / Features bản đồ công khai (Zero PII)",
        "responses": {
          "200": {
            "description": "Dữ liệu bản đồ công khai"
          }
        }
      }
    },
    "/api/spatial/features": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Lấy dữ liệu không gian spatial features (Zero fake coords)",
        "responses": {
          "200": {
            "description": "Dữ liệu spatial features"
          }
        }
      }
    },
    "/api/v1/map": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Lấy dữ liệu bản đồ v1",
        "responses": {
          "200": {
            "description": "Dữ liệu bản đồ v1"
          }
        }
      }
    },
    "/api/v1/spatial/features": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Lấy dữ liệu spatial features v1",
        "responses": {
          "200": {
            "description": "Dữ liệu spatial features v1"
          }
        }
      }
    },
    "/api/spatial/geocode": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Tra cứu địa chỉ / tọa độ không gian WGS84",
        "responses": {
          "200": {
            "description": "Kết quả tra cứu địa chỉ không gian"
          }
        }
      }
    },
    "/api/v1/spatial/geocode": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Tra cứu địa chỉ / tọa độ không gian WGS84 v1",
        "responses": {
          "200": {
            "description": "Kết quả tra cứu địa chỉ không gian"
          }
        }
      }
    },
    "/api/spatial/entities/{type}/{id}/location": {
      "patch": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Cập nhật tọa độ không gian thực thể (site, complaint)",
        "responses": {
          "200": {
            "description": "Cập nhật tọa độ thành công"
          }
        }
      }
    },
    "/api/v1/spatial/entities/{type}/{id}/location": {
      "patch": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Cập nhật tọa độ không gian thực thể v1",
        "responses": {
          "200": {
            "description": "Cập nhật tọa độ thành công"
          }
        }
      }
    },
    "/api/dashboard/stats": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Thống kê tổng quan điều hành (Số công trường, phản ánh, ca xử lý)",
        "responses": {
          "200": {
            "description": "Số liệu thống kê"
          }
        }
      }
    },
    "/api/dashboard/executive": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Số liệu tổng quan phục vụ lãnh đạo ra quyết định",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu điều hành",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/dashboard/operations": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Số liệu vận hành hiện trường cho đoàn thanh tra",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu vận hành",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/dashboard/executive": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Số liệu tổng quan phục vụ lãnh đạo ra quyết định (v1)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu điều hành",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/dashboard/operations": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "Số liệu vận hành hiện trường cho đoàn thanh tra (v1)",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "responses": {
          "200": {
            "description": "Dữ liệu vận hành",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/ai/search": {
      "post": {
        "tags": [
          "AI & Policy Intelligence"
        ],
        "summary": "Tra cứu căn cứ pháp lý & Nghị định xử phạt môi trường",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "query": {
                    "type": "string",
                    "example": "xe chở đất cát không phủ bạt"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Điều khoản và khung tiền phạt theo quy định"
          }
        }
      }
    },
    "/api/ai/explain-violation": {
      "post": {
        "tags": [
          "AI & Policy Intelligence"
        ],
        "summary": "Trợ lý AI giải thích vi phạm và căn cứ pháp lý chi tiết",
        "security": [
          {
            "BearerAuth": []
          },
          {
            "CookieAuth": []
          }
        ],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "siteId": {
                    "type": "string"
                  },
                  "itemKey": {
                    "type": "string",
                    "example": "spray"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Giải thích hành vi vi phạm và biện pháp khắc phục"
          }
        }
      }
    },
    "/api/feedback": {
      "post": {
        "tags": [
          "System & Health"
        ],
        "summary": "Gửi góp ý và phản hồi nâng cấp hệ thống (Rate-limited)",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "name": {
                    "type": "string",
                    "example": "Nguyễn Văn A"
                  },
                  "email": {
                    "type": "string",
                    "example": "user@example.com"
                  },
                  "message": {
                    "type": "string",
                    "example": "Giao diện rất dễ sử dụng và hữu ích."
                  },
                  "page": {
                    "type": "string",
                    "example": "/citizen"
                  }
                },
                "required": [
                  "message"
                ]
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Gửi phản hồi thành công"
          },
          "429": {
            "description": "Vượt quá giới hạn tần suất gửi"
          }
        }
      }
    },
    "/api/v1/health": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /api/v1/health - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/health": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /api/health - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/health/db": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /api/health/db - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/docs/openapi.json": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /api/docs/openapi.json - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/openapi.json": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /openapi.json - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api-docs": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api-docs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/docs": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /docs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/docs": {
      "get": {
        "tags": [
          "System & Health"
        ],
        "summary": "GET /api/docs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/uploads/{key}{.+}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /uploads/:key{.+} - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/uploads/{key}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /uploads/:key - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/uploads/{key}{.+}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /api/uploads/:key{.+} - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/uploads/{key}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /api/uploads/:key - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/storage/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/storage/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/storage/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/v1/storage/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/evidence/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/evidence/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/complaints/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/complaints/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/complaints/{id}/evidence": {
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "POST /api/complaints/:id/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/actions/{id}/evidence": {
      "post": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "POST /api/actions/:id/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/actions/evidence": {
      "post": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "POST /api/actions/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/upload-signed": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/documents/upload-signed - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/upload": {
      "post": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "POST /api/legal-documents/upload - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/storage/file/{key}{.+}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /api/storage/file/:key{.+} - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/storage/file/{key}{.+}": {
      "get": {
        "tags": [
          "Cloudflare R2 Storage & Uploads"
        ],
        "summary": "GET /api/v1/storage/file/:key{.+} - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "key",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh key"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/login": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/login - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/auth/login": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/v1/auth/login - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/register": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/register - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/auth/register": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/v1/auth/register - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/me": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/me - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/auth/me": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/v1/auth/me - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/logout": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/logout - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/auth/logout": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/v1/auth/logout - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/auth/providers": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/auth/providers - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/auth/providers": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/v1/auth/providers - Endpoint nhà cung cấp xác thực",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/providers": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/providers - Alias nhà cung cấp xác thực",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/v1/providers": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/v1/providers - Alias v1 nhà cung cấp xác thực",
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/checklists": {
      "get": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "GET /api/checklists - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sites": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/v1/sites - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "POST /api/v1/sites - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/public/sites": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/v1/public/sites - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sites/{id}": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/v1/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "PUT /api/v1/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "PATCH /api/v1/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "DELETE /api/v1/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sites/{id}/assign-inspector": {
      "post": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "POST /api/sites/:id/assign-inspector - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sites/{id}/sensors": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/sites/:id/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sites/{id}/readings": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/sites/:id/readings - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/public-complaints": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "GET /api/public-complaints - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "POST /api/public-complaints - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/complaints": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "GET /api/v1/complaints - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "POST /api/v1/complaints - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/public-complaints/{id}": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "GET /api/public-complaints/:id - Tra cứu phản ánh công khai theo ID",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã ID phản ánh"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/public-complaints/{code}": {
      "get": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "GET /api/public-complaints/:code - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "code",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh code"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/complaints/{id}/status": {
      "patch": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PATCH /api/complaints/:id/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Citizen Reporting"
        ],
        "summary": "PUT /api/complaints/:id/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/go-on-site": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "POST /api/cases/:id/go-on-site - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/issue-decision": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "POST /api/cases/:id/issue-decision - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/reporting-draft": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "POST /api/cases/:id/reporting-draft - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/appraise": {
      "post": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "POST /api/cases/:id/appraise - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/{id}": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/reference-docs": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents/reference-docs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/obligations": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents/obligations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/obligations/{id}/map-checklist": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/legal-documents/obligations/:id/map-checklist - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/draft": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/draft - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/actions": {
      "get": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "GET /api/actions - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "POST /api/actions - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/actions/{id}/verify": {
      "post": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "POST /api/actions/:id/verify - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/inspections": {
      "get": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "GET /api/inspections - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "POST /api/inspections - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sensors": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sensors/reading": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/v1/sensors/reading - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sensors/telemetry": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/sensors/telemetry - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sensors/audit": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/sensors/audit - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/sensors/audit - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/alerts - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/stats": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/alerts/stats - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/sensors": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/alerts/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/frauds": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/alerts/frauds - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/{id}/status": {
      "put": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "PUT /api/alerts/:id/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/scan": {
      "post": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "POST /api/alerts/scan - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/simulate-violation": {
      "post": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "POST /api/alerts/simulate-violation - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/sensors/{id}/recover": {
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/alerts/sensors/:id/recover - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/alerts/simulate-fraud": {
      "post": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "POST /api/alerts/simulate-fraud - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/assess-gri304": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/assess-gri304 - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/assess-gri305": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/assess-gri305 - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/escrow/auto-trigger": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/escrow/auto-trigger - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/escrow/evaluate-milestone": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/escrow/evaluate-milestone - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/executive-report": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/executive-report - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/sponsorships": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "GET /api/csr/sponsorships - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/csr/sponsorships": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "GET /api/v1/csr/sponsorships - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/impact-reports/{id}": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "GET /api/csr/impact-reports/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/csr/impact-reports/{id}": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "GET /api/v1/csr/impact-reports/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/questions-coverage": {
      "get": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "GET /api/csr/questions-coverage - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/dashboard/documents/{id}/quick-sign": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/dashboard/documents/:id/quick-sign - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/capabilities": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/ai/capabilities - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/system/data-stats": {
      "get": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "GET /api/admin/system/data-stats - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/system/reset-data/preview": {
      "post": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "POST /api/admin/system/reset-data/preview - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/system/reset-data": {
      "post": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "POST /api/admin/system/reset-data - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/system/seed-demo": {
      "post": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "POST /api/admin/system/seed-demo - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/audit-logs": {
      "get": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "GET /api/admin/audit-logs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/trash": {
      "get": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "GET /api/admin/trash - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/trash/{entity}/{id}/restore": {
      "post": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "POST /api/admin/trash/:entity/:id/restore - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "entity",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh entity"
          },
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/trash/{entity}/{id}/permanent": {
      "delete": {
        "tags": [
          "Admin & System Data Management"
        ],
        "summary": "DELETE /api/admin/trash/:entity/:id/permanent - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "entity",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh entity"
          },
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/history": {
      "get": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "GET /api/cases/:id/history - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sites/{id}/priority-history": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/sites/:id/priority-history - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/environmental-categories": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/environmental-categories - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/me": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/me - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/groups": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/groups - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/community/groups - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/impact": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/impact - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/campaigns": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/campaigns - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/campaigns - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/campaigns/{id}/join": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/campaigns/:id/join - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/observations": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/observations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/observations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/observations/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/observations/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/observations/{id}/status": {
      "patch": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PATCH /api/observations/:id/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/follow-ups": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/follow-ups - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/observations/{id}/follow-ups": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/observations/:id/follow-ups - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/handoffs": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/handoffs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/handoffs/{id}": {
      "patch": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PATCH /api/handoffs/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/handoffs/:id - Lấy chi tiết hồ sơ bàn giao",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh handoff"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy"
          }
        }
      }
    },
    "/api/handoffs/{id}/submit": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/handoffs/:id/submit - Gửi hồ sơ bàn giao sang cơ quan chức năng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh handoff"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "400": {
            "description": "Lỗi chuyển trạng thái"
          }
        }
      }
    },
    "/api/handoffs/{id}/acknowledge": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/handoffs/:id/acknowledge - Cơ quan chức năng xác nhận tiếp nhận hồ sơ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh handoff"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/handoffs/{id}/packet": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/handoffs/:id/packet - Lấy gói dữ liệu bàn giao số và mã băm SHA-256",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh handoff"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy"
          }
        }
      }
    },
    "/api/sites/{id}/risk-analysis": {
      "get": {
        "tags": [
          "Sites & Projects"
        ],
        "summary": "GET /api/sites/:id/risk-analysis - Phân tích điểm rủi ro bụi theo DustRiskEngine SSOT",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh site"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy công trường"
          }
        }
      }
    },
    "/api/youth/certificate/{code}": {
      "get": {
        "tags": [
          "Youth Engagement"
        ],
        "summary": "GET /api/youth/certificate/:code - Tra cứu chứng chỉ đóng góp môi trường thanh niên",
        "parameters": [
          {
            "name": "code",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã chứng chỉ"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy chứng chỉ"
          }
        }
      }
    },
    "/api/youth/certificate/{code}/verify": {
      "get": {
        "tags": [
          "Youth Engagement"
        ],
        "summary": "GET /api/youth/certificate/:code/verify - Kiểm tra tính toàn vẹn chữ ký số HMAC-SHA256",
        "parameters": [
          {
            "name": "code",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã chứng chỉ"
          }
        ],
        "responses": {
          "200": {
            "description": "Chứng chỉ hợp lệ"
          },
          "400": {
            "description": "Chứng chỉ bị thu hồi hoặc sai chữ ký"
          }
        }
      }
    },
    "/api/youth/certificate/verify": {
      "get": {
        "tags": [
          "Youth Engagement"
        ],
        "summary": "GET /api/youth/certificate/verify - Kiểm tra tính toàn vẹn chứng chỉ qua query param",
        "parameters": [
          {
            "name": "code",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            },
            "description": "Mã chứng chỉ"
          },
          {
            "name": "hash",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            },
            "description": "Mã băm toàn vẹn HMAC"
          }
        ],
        "responses": {
          "200": {
            "description": "Chứng chỉ hợp lệ"
          },
          "400": {
            "description": "Chứng chỉ không hợp lệ"
          }
        }
      }
    },
    "/api/admin/youth/certificate/{id}/revoke": {
      "post": {
        "tags": [
          "Youth Engagement"
        ],
        "summary": "POST /api/admin/youth/certificate/:id/revoke - Thu hồi chứng chỉ (Admin)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh chứng chỉ"
          }
        ],
        "responses": {
          "200": {
            "description": "Thu hồi thành công"
          }
        }
      }
    },
    "/api/environmental-categories/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/environmental-categories/:id - Chi tiết danh mục môi trường & quy chuẩn viện dẫn",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã danh mục"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy danh mục"
          }
        }
      }
    },
    "/api/campaigns/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/campaigns/:id - Chi tiết chiến dịch thanh niên hành động",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã chiến dịch"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy chiến dịch"
          }
        }
      }
    },
    "/api/campaigns/{id}/impact": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/campaigns/:id/impact - Thống kê tác động thực địa của chiến dịch",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã chiến dịch"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy chiến dịch"
          }
        }
      }
    },
    "/api/observations/{id}/timeline": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/observations/:id/timeline - Dòng thời gian lịch sử xử lý & theo dõi lại",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã quan sát"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          },
          "404": {
            "description": "Không tìm thấy quan sát"
          }
        }
      }
    },
    "/api/executive/overview": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/overview - Dữ liệu tổng quan điều hành lãnh đạo",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/priorities": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/priorities - Hàng đợi điểm nóng ưu tiên xử lý",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/operations": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/operations - Số liệu điều hành tác nghiệp và phân công thanh tra",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/sla": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/sla - Giám sát SLA & điều hành thanh tra",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/sensors": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/sensors - Tình trạng mạng lưới cảm biến",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/impact": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/impact - Báo cáo hiệu quả can thiệp",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/reports": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/reports - Danh mục báo cáo điều hành",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/reports/{id}": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/executive/reports/:id - Chi tiết báo cáo điều hành",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã báo cáo"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "404": {
            "description": "Không tìm thấy báo cáo"
          }
        }
      }
    },
    "/api/executive/cases/{id}/escalate": {
      "post": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "POST /api/executive/cases/:id/escalate - Leo thang vụ việc nghiêm trọng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/overview": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/overview - Dữ liệu tổng quan điều hành lãnh đạo",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/priorities": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/priorities - Hàng đợi điểm nóng ưu tiên xử lý",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/operations": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/operations - Dữ liệu vận hành & điều hành thanh tra",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/sla": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/sla - Giám sát SLA & điều hành thanh tra",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/sensors": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/sensors - Tình trạng mạng lưới cảm biến",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/impact": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/impact - Báo cáo hiệu quả can thiệp",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/reports": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/reports - Danh mục báo cáo điều hành",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/executive/reports/{id}": {
      "get": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "GET /api/v1/executive/reports/:id - Chi tiết báo cáo điều hành",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã báo cáo"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "404": {
            "description": "Không tìm thấy báo cáo"
          }
        }
      }
    },
    "/api/executive/cases/{id}/assign": {
      "post": {
        "tags": [
          "Dashboard & Operations"
        ],
        "summary": "POST /api/executive/cases/:id/assign - Phân công thanh tra khẩn cấp",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/contractor/dashboard": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/dashboard - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/risk-score": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/risk-score - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/priority": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/actions/priority - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/actions - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/remediations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/{id}": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/actions/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations/{id}": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/remediations/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/{id}/acknowledge": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/actions/:id/acknowledge - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations/{id}/acknowledge": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/remediations/:id/acknowledge - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/{id}/start": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/actions/:id/start - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations/{id}/start": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/remediations/:id/start - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/{id}/evidence": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/actions/:id/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations/{id}/evidence": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/remediations/:id/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/actions/{id}/submit": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/actions/:id/submit - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/remediations/{id}/submit": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/remediations/:id/submit - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/projects": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/projects - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/projects/{id}": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/projects/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/projects/{id}/telemetry": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/projects/:id/telemetry - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/projects/{id}/compliance": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/projects/:id/compliance - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/evidence": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/evidence - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/notifications": {
      "get": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "GET /api/contractor/notifications - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/contractor/notifications/{id}/read": {
      "post": {
        "tags": [
          "Contractor Compliance Workspace"
        ],
        "summary": "POST /api/contractor/notifications/:id/read - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/auth/sign-in/social": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/auth/sign-in/social - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/auth/sign-in/social": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /auth/sign-in/social - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/auth/signin/social": {
      "post": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "POST /api/auth/signin/social - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/auth/callback/google": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /api/auth/callback/google - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/auth/callback/google": {
      "get": {
        "tags": [
          "Authentication & RBAC"
        ],
        "summary": "GET /auth/callback/google - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/public/sites/{id}": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/public/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/public/sites/{id}": {
      "get": {
        "tags": [
          "Sites & Monitoring"
        ],
        "summary": "GET /api/v1/public/sites/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/cases/{id}/sla": {
      "get": {
        "tags": [
          "Case Management (DDD)"
        ],
        "summary": "GET /api/cases/:id/sla - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/documents": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/documents - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/reference-docs": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/reference-docs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/obligations": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/obligations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/segments": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents/segments - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/segments": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/segments - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal-documents/search": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal-documents/search - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/legal-documents/search - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/search": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/search - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/legal/search - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/documents/{id}": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/legal/documents/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/legal/obligations/{id}/map-checklist": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/legal/obligations/:id/map-checklist - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/{id}": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "PATCH /api/documents/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/drafts/{id}/sign": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/drafts/:id/sign - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/{id}/sign": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/:id/sign - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/drafts/{id}/export": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents/drafts/:id/export - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/drafts/:id/export - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/{id}/export": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents/:id/export - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/:id/export - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/drafts/{id}/verify": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents/drafts/:id/verify - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/drafts/:id/verify - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/documents/{id}/verify": {
      "get": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "GET /api/documents/:id/verify - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/documents/:id/verify - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/actions/{id}": {
      "get": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "GET /api/actions/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "PUT /api/actions/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "PATCH /api/actions/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "Xóa hành động khắc phục (Staff/Admin)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Xóa hành động thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          },
          "404": {
            "description": "Không tìm thấy hành động"
          }
        }
      }
    },
    "/api/inspections/{id}": {
      "get": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "GET /api/inspections/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "Inspections & Actions"
        ],
        "summary": "Xóa biên bản kiểm tra (Staff/Admin)",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Xóa biên bản thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          },
          "404": {
            "description": "Không tìm thấy biên bản"
          }
        }
      }
    },
    "/api/sensors/audit/integrity": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/sensors/audit/integrity - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sensors/audit/integrity": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/v1/sensors/audit/integrity - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sensors": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/v1/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/v1/sensors - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sensors/{id}": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "PUT /api/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "PATCH /api/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "DELETE /api/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sensors/{id}": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/v1/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "PUT /api/v1/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "patch": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "PATCH /api/v1/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "DELETE /api/v1/sensors/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/sensors/{id}/readings": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/sensors/:id/readings - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/sensors/:id/readings - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/sensors/{id}/readings": {
      "get": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "GET /api/v1/sensors/:id/readings - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "IoT Telemetry"
        ],
        "summary": "POST /api/v1/sensors/:id/readings - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/csr/milestone/{siteId}": {
      "post": {
        "tags": [
          "CSR Escrow & DEMS"
        ],
        "summary": "POST /api/csr/milestone/:siteId - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "siteId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh siteId"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/parse-document": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/parse-document - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/analyze-image": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/analyze-image - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/auto-report": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/auto-report - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/legal-assistant": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/ai/legal-assistant - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/analyze": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/analyze - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/legal-obligations": {
      "post": {
        "tags": [
          "Legal Documents & A4"
        ],
        "summary": "POST /api/ai/legal-obligations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/inspection-report": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/inspection-report - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/ai/image": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/ai/image - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/observations": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/observations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/community/observations - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/follow-ups": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/community/follow-ups - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/handoffs": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/community/handoffs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/staff/dashboard": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/staff/dashboard - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/v1/staff/dashboard": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/v1/staff/dashboard - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/automation/sweep": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/automation/sweep - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/automation/runs": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/automation/runs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/automation/policy": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/automation/policy - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/automation/status": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/automation/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/automation/toggle": {
      "post": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "POST /api/automation/toggle - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/handoffs/{id}/ticket": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/handoffs/:id/ticket - Liên kết mã biên nhận tiếp nhận 1022/iHanoi",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh handoff"
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "ticketNumber": {
                    "type": "string",
                    "description": "Mã biên nhận phản ánh 1022 hoặc iHanoi"
                  },
                  "channel": {
                    "type": "string",
                    "description": "Kênh tiếp nhận (HOTLINE_1022, IHANOI_APP, DIRECT_DISPATCH)"
                  }
                },
                "required": [
                  "ticketNumber"
                ]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Liên kết mã tiếp nhận thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/spatial/entities": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/spatial/entities - Lấy danh sách thực thể không gian (sites, sensors, reports, hotspots)",
        "operationId": "getSpatialEntities",
        "parameters": [
          {
            "name": "bbox",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            },
            "description": "Bounding box: minLng,minLat,maxLng,maxLat"
          },
          {
            "name": "layers",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            },
            "description": "Danh sách lớp: sites,sensors,reports,hotspots,missions"
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách thực thể không gian",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/v1/spatial/entities": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/v1/spatial/entities - Lấy danh sách thực thể không gian V1 alias",
        "operationId": "getSpatialEntitiesV1",
        "parameters": [
          {
            "name": "bbox",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            },
            "description": "Bounding box: minLng,minLat,maxLng,maxLat"
          }
        ],
        "responses": {
          "200": {
            "description": "Danh sách thực thể không gian",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/cases/{id}/directive": {
      "post": {
        "tags": [
          "Executive & Leadership"
        ],
        "summary": "Ban hành chỉ đạo điều hành và giao việc cho cán bộ",
        "operationId": "issueExecutiveDirective",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc (Case ID)"
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "content": {
                    "type": "string"
                  },
                  "inspectorName": {
                    "type": "string"
                  },
                  "priorityLevel": {
                    "type": "string"
                  },
                  "slaHours": {
                    "type": "number"
                  },
                  "requireReport": {
                    "type": "boolean"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Ban hành chỉ đạo thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/cases/{id}/approve": {
      "post": {
        "tags": [
          "Executive & Leadership"
        ],
        "summary": "Phê duyệt kết luận kiểm tra hoặc đề xuất gia hạn",
        "operationId": "approveExecutiveCase",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc (Case ID)"
          }
        ],
        "requestBody": {
          "required": false,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "note": {
                    "type": "string"
                  },
                  "newSlaHours": {
                    "type": "number"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Phê duyệt hồ sơ thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/cases/{id}/reject": {
      "post": {
        "tags": [
          "Executive & Leadership"
        ],
        "summary": "Yêu cầu thanh tra lại hoặc bổ sung minh chứng",
        "operationId": "rejectExecutiveCase",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc (Case ID)"
          }
        ],
        "requestBody": {
          "required": false,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "reason": {
                    "type": "string"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Yêu cầu kiểm tra lại thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/executive/cases/{id}/close": {
      "post": {
        "tags": [
          "Executive & Leadership"
        ],
        "summary": "Đóng hồ sơ vụ việc chính thức",
        "operationId": "closeExecutiveCase",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã vụ việc (Case ID)"
          }
        ],
        "requestBody": {
          "required": false,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "closingSummary": {
                    "type": "string"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Đóng hồ sơ thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/community/discover": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/discover - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/campaigns/{slugOrId}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/campaigns/:slugOrId - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "slugOrId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh slugOrId"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/community/clubs/{slugOrId}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/community/clubs/:slugOrId - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "slugOrId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh slugOrId"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/dashboard": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/dashboard - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/campaigns": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/campaigns - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/campaigns - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/campaigns/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/campaigns/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PUT /api/admin/community/campaigns/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "delete": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "DELETE /api/admin/community/campaigns/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/clubs": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/clubs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/clubs - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/clubs/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/clubs/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "put": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PUT /api/admin/community/clubs/:id - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/participants": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/participants - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/participants/{id}/approve": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/participants/:id/approve - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/participants/{id}/reject": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/participants/:id/reject - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/participants/{id}/status": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/participants/:id/status - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            },
            "description": "Mã định danh id"
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/admin/community/members": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/admin/community/members - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/admin/community/members - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    },
    "/api/tasks/counters": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/tasks/counters - Lấy số liệu thống kê counters cho nhiệm vụ thực địa",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/tasks": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/tasks - Lấy danh sách nhiệm vụ thực địa",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      },
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks - Tạo mới nhiệm vụ thực địa",
        "responses": {
          "201": {
            "description": "Tạo thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          }
        }
      }
    },
    "/api/tasks/{id}": {
      "get": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "GET /api/tasks/{id} - Lấy chi tiết nhiệm vụ thực địa",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "404": {
            "description": "Không tìm thấy nhiệm vụ"
          }
        }
      },
      "patch": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PATCH /api/tasks/{id} - Cập nhật thông tin nhiệm vụ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      },
      "put": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "PUT /api/tasks/{id} - Cập nhật toàn bộ thông tin nhiệm vụ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/archive": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/archive - Lưu trữ nhiệm vụ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/join": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/join - Tình nguyện viên nhận nhiệm vụ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/start": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/start - Bắt đầu thực hiện nhiệm vụ",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/submit": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/submit - Nộp kết quả và minh chứng thực địa",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/task-submissions/{id}/approve": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/task-submissions/{id}/approve - Cán bộ duyệt nghiệm thu minh chứng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/task-submissions/{id}/request-revision": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/task-submissions/{id}/request-revision - Cán bộ yêu cầu làm lại minh chứng",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/submissions/{subId}/approve": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/submissions/{subId}/approve - Duyệt nghiệm thu theo task ID",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          },
          {
            "name": "subId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/tasks/{id}/submissions/{subId}/request-revision": {
      "post": {
        "tags": [
          "Youth Community Action"
        ],
        "summary": "POST /api/tasks/{id}/submissions/{subId}/request-revision - Yêu cầu làm lại theo task ID",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          },
          {
            "name": "subId",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Thành công"
          }
        }
      }
    },
    "/api/dashboard/summary": {
      "get": {
        "tags": [
          "Public & GIS"
        ],
        "summary": "GET /api/dashboard/summary - Endpoint xử lý nghiệp vụ Cloudflare Edge",
        "responses": {
          "200": {
            "description": "Thành công",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/StandardResponse"
                }
              }
            }
          },
          "400": {
            "description": "Yêu cầu không hợp lệ (RFC 7807 Problem Details)"
          },
          "401": {
            "description": "Chưa xác thực danh tính"
          },
          "403": {
            "description": "Không đủ quyền hạn truy cập"
          }
        }
      }
    }
  }
};
