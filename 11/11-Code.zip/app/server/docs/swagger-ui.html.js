/**
 * Generates an interactive Swagger UI HTML page for DustGuard API
 * Built with high-contrast civic tech light theme (No glassmorphism, clean typography)
 */
export function renderSwaggerHtml(specUrl = '/api/docs/openapi.json') {
  return `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DustGuard VN - Swagger API Documentation</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.11.0/swagger-ui.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-cream: #FDFBF7;
      --ink-primary: #231b14;
      --accent-teal: #0d6f64;
      --accent-teal-dark: #084c45;
      --seal-red: #9f241f;
      --border-subtle: #e6dfd5;
      --card-bg: #ffffff;
    }
    body {
      margin: 0;
      padding: 0;
      background-color: var(--bg-cream);
      color: var(--ink-primary);
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .dg-header {
      background-color: #ffffff;
      border-bottom: 2px solid var(--border-subtle);
      padding: 16px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .dg-brand {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .dg-logo-badge {
      background-color: var(--accent-teal);
      color: #ffffff;
      font-weight: 800;
      font-size: 16px;
      padding: 6px 12px;
      border-radius: 6px;
      letter-spacing: 0.5px;
    }
    .dg-title {
      font-size: 18px;
      font-weight: 700;
      color: var(--ink-primary);
      margin: 0;
    }
    .dg-subtitle {
      font-size: 13px;
      color: #666;
      margin: 0;
    }
    .dg-actions {
      display: flex;
      gap: 10px;
    }
    .dg-btn {
      background-color: var(--card-bg);
      border: 1px solid var(--border-subtle);
      color: var(--ink-primary);
      font-weight: 600;
      font-size: 13px;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.15s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .dg-btn:hover {
      background-color: #f4efe6;
      border-color: #d1c7b8;
    }
    .dg-btn-primary {
      background-color: var(--accent-teal);
      color: #ffffff;
      border-color: var(--accent-teal);
    }
    .dg-btn-primary:hover {
      background-color: var(--accent-teal-dark);
      color: #ffffff;
    }
    /* Swagger UI Overrides for clean light mode */
    .swagger-ui .topbar { display: none !important; }
    .swagger-ui {
      max-width: 1280px;
      margin: 0 auto;
      padding: 24px;
      font-family: inherit;
    }
    .swagger-ui .info {
      margin: 20px 0;
      background: #ffffff;
      padding: 24px;
      border-radius: 8px;
      border: 1px solid var(--border-subtle);
    }
    .swagger-ui .info .title {
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-weight: 800;
      color: var(--ink-primary);
    }
    .swagger-ui .scheme-container {
      background: #ffffff;
      box-shadow: none;
      border: 1px solid var(--border-subtle);
      border-radius: 8px;
      padding: 16px;
      margin-bottom: 24px;
    }
    .swagger-ui .opblock {
      border-radius: 8px;
      box-shadow: 0 1px 2px rgba(0,0,0,0.04);
      margin-bottom: 12px;
    }
    .swagger-ui .opblock.opblock-get { border-color: #0d6f64; background: rgba(13, 111, 100, 0.04); }
    .swagger-ui .opblock.opblock-get .opblock-summary-method { background: #0d6f64; }
    .swagger-ui .opblock.opblock-post { border-color: #1d4ed8; background: rgba(29, 78, 216, 0.04); }
    .swagger-ui .opblock.opblock-post .opblock-summary-method { background: #1d4ed8; }
    .swagger-ui .opblock.opblock-patch { border-color: #d97706; background: rgba(217, 119, 6, 0.04); }
    .swagger-ui .opblock.opblock-patch .opblock-summary-method { background: #d97706; }
    .swagger-ui .opblock.opblock-delete { border-color: #9f241f; background: rgba(159, 36, 31, 0.04); }
    .swagger-ui .opblock.opblock-delete .opblock-summary-method { background: #9f241f; }
    .swagger-ui code, .swagger-ui .model-box code {
      font-family: 'JetBrains Mono', monospace !important;
    }
  </style>
</head>
<body>
  <header class="dg-header">
    <div class="dg-brand">
      <div class="dg-logo-badge">DUSTGUARD VN</div>
      <div>
        <h1 class="dg-title">Tài Liệu Swagger & OpenAPI 3.0</h1>
        <p class="dg-subtitle">Cổng kết nối API Giám sát Môi trường & Pháp Lý Bụi Xây Dựng</p>
      </div>
    </div>
    <div class="dg-actions">
      <a href="/" class="dg-btn">← Quay lại Ứng dụng</a>
      <a href="${specUrl}" target="_blank" class="dg-btn dg-btn-primary">Tải OpenAPI JSON</a>
    </div>
  </header>

  <div id="swagger-ui"></div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.11.0/swagger-ui-bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.11.0/swagger-ui-standalone-preset.min.js"></script>
  <script>
    window.onload = function() {
      const ui = SwaggerUIBundle({
        url: "${specUrl}",
        dom_id: '#swagger-ui',
        deepLinking: true,
        presets: [
          SwaggerUIBundle.presets.apis,
          SwaggerUIStandalonePreset
        ],
        plugins: [
          SwaggerUIBundle.plugins.DownloadUrl
        ],
        layout: "BaseLayout",
        defaultModelsExpandDepth: 1,
        defaultModelExpandDepth: 1,
        docExpansion: "list",
        filter: true,
        showExtensions: true,
        showCommonExtensions: true,
        persistAuthorization: true
      });
      window.ui = ui;
    };
  </script>
</body>
</html>`;
}
