/**
 * DustGuard VN - Cloudflare Worker Application Entrypoint (Thin Composition Root)
 * Architecture: Modular Monolith with Thin Entrypoint + Domain Routers
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { ensureSchema } from './db/schema-healer.js';
import { getAuthenticatedUser, formatRfc7807Error } from './routes/worker/helpers.js';

// Import Domain Routers
import healthRoutes from './routes/worker/health.routes.js';
import storageRoutes from './routes/worker/storage.routes.js';
import authRoutes from './routes/worker/auth.routes.js';
import publicRoutes from './routes/worker/public.routes.js';
import sitesRoutes from './routes/worker/sites.routes.js';
import complaintsRoutes from './routes/worker/complaints.routes.js';
import casesRoutes from './routes/worker/cases.routes.js';
import inspectionsRoutes from './routes/worker/inspections.routes.js';
import actionsRoutes from './routes/worker/actions.routes.js';
import sensorsRoutes from './routes/worker/sensors.routes.js';
import iotRoutes from './routes/worker/iot.routes.js';
import documentsRoutes from './routes/worker/documents.routes.js';
import csrRoutes from './routes/worker/csr.routes.js';
import contractorRoutes from './routes/worker/contractor.routes.js';
import communityRoutes from './routes/worker/community.routes.js';
import tasksRoutes from './routes/worker/tasks.routes.js';
import executiveRoutes from './routes/worker/executive.routes.js';
import aiRoutes from './routes/worker/ai.routes.js';
import adminRoutes from './routes/worker/admin.routes.js';
import staffRoutes from './routes/worker/staff.routes.js';
import staffTasksRoutes from './routes/worker/staff-tasks.routes.js';
import staffReportsNotificationsRoutes from './routes/worker/staff-reports-notifications.routes.js';

export function createApp() {
  const app = new Hono();

  // 1. Global Middleware: Request ID & Security Headers
  app.use('*', async (c, next) => {
    const reqId = c.req.header('x-request-id') || `req_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    c.set('requestId', reqId);
    c.header('X-Request-Id', reqId);
    c.header('X-Content-Type-Options', 'nosniff');
    c.header('X-Frame-Options', 'DENY');
    await next();
  });

  // 2. Global Middleware: CORS Policy
  app.use('*', cors({
    origin: (origin) => origin || '*',
    allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization', 'x-user-id', 'x-profile-id', 'x-user-role', 'x-contractor-token', 'idempotency-key', 'x-idempotency-key'],
    exposeHeaders: ['Content-Length', 'X-Request-Id'],
    maxAge: 86400,
    credentials: true
  }));

  // 3. Global Middleware: Lazy D1 Database Schema Healing
  app.use('/api/*', async (c, next) => {
    if (c.env && (c.env.DB || c.env.DATABASE)) {
      try {
        await ensureSchema(c.env);
      } catch (err) {
        console.error('[SchemaHealer] Error verifying schema:', err);
      }
    }
    await next();
  });

  // 4. Global Middleware: User Context Injection
  app.use('/api/*', async (c, next) => {
    try {
      const user = await getAuthenticatedUser(c);
      if (user) {
        c.set('user', user);
      }
    } catch {}
    await next();
  });

  // 5. Mount Domain Routers (Modular Monolith)
  app.route('', healthRoutes);
  app.route('', storageRoutes);
  app.route('', authRoutes);
  app.route('', publicRoutes);
  app.route('', sitesRoutes);
  app.route('', complaintsRoutes);
  app.route('', casesRoutes);
  app.route('', inspectionsRoutes);
  app.route('', actionsRoutes);
  app.route('', sensorsRoutes);
  app.route('', iotRoutes);
  app.route('', documentsRoutes);
  app.route('', csrRoutes);
  app.route('', contractorRoutes);
  app.route('', communityRoutes);
  app.route('', tasksRoutes);
  app.route('', executiveRoutes);
  app.route('', aiRoutes);
  app.route('', adminRoutes);
  app.route('', staffRoutes);
  app.route('', staffTasksRoutes);
  app.route('', staffReportsNotificationsRoutes);

  // 6. RFC 7807 Global Error Handler
  app.onError((err, c) => {
    console.error('[Worker Runtime Error]', err);
    const status = err.statusCode || err.status || 500;
    const code = err.code || 'INTERNAL_SERVER_ERROR';
    const message = err.message || 'Đã xảy ra lỗi máy chủ nội bộ.';
    return c.json(formatRfc7807Error(status, code, 'Server Error', message, c.req.path), status);
  });

  // 7. Catch-all Not Found Route
  app.all('/api/*', (c) => {
    return c.json({
      status: 'error',
      statusCode: 404,
      type: 'https://dustguard.vn/errors/404',
      title: 'Not Found',
      code: 'NOT_FOUND',
      error: `Endpoint ${c.req.method} ${c.req.path} không tồn tại.`,
      detail: `Endpoint ${c.req.method} ${c.req.path} không tồn tại.`,
      instance: c.req.path,
      message: `Endpoint ${c.req.method} ${c.req.path} không tồn tại.`,
      timestamp: new Date().toISOString()
    }, 404);
  });

  return app;
}

const app = createApp();
export default app;
export { app };
export { resetComplaintRateLimits } from './routes/worker/complaints.routes.js';
