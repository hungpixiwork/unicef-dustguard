import { betterAuth } from 'better-auth';
import { fromNodeHeaders, toNodeHandler } from 'better-auth/node';
import { prismaAdapter } from 'better-auth/adapters/prisma';
import { prisma } from './shared/db.js';
import path from 'path';
import fs from 'fs';

function envList(...values) {
  return values
    .flatMap(value => String(value || '').split(','))
    .map(value => value.trim())
    .filter(Boolean);
}

const trustedOrigins = envList(
  process.env.BETTER_AUTH_URL,
  process.env.APP_ORIGIN,
  process.env.CORS_ORIGINS,
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:8787',
  'http://127.0.0.1:8787',
  'http://localhost:3001',
  'http://127.0.0.1:3001',
  'http://localhost:3002',
  'http://127.0.0.1:3002',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'https://dustguard.w9.nu',
  'https://dustguard.phamphunguyenhung.com',
  'http://dustguard.phamphunguyenhung.com',
);

if (process.env.NODE_ENV === 'production' && !process.env.BETTER_AUTH_SECRET) {
  throw new Error('BETTER_AUTH_SECRET is required in production.');
}

const authSecret =
  process.env.BETTER_AUTH_SECRET ||
  process.env.AUTH_SECRET ||
  'dustguard-vn-dev-auth-secret-change-before-production';

// Connect dynamically to PostgreSQL (Supabase/Dokploy) or SQLite
const isSqlite = !process.env.DATABASE_URL || process.env.DATABASE_URL.startsWith('file:') || process.env.DATABASE_URL.includes('.db');

let authDatabase;
if (isSqlite) {
  let dbPath;
  if (process.env.AUTH_DATABASE_PATH) {
    dbPath = path.resolve(process.env.AUTH_DATABASE_PATH);
  } else if (process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith('file:')) {
    const rawPath = process.env.DATABASE_URL.replace(/^file:/, '').split('?')[0];
    dbPath = path.resolve(process.cwd(), rawPath);
  } else {
    const rootPrisma = path.resolve(process.cwd(), 'prisma', 'dev.db');
    const appPrisma = path.resolve(process.cwd(), 'app', 'prisma', 'dev.db');
    const dirnamePrisma = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([a-zA-Z]:)/, '$1')), '..', 'prisma', 'dev.db');
    dbPath = fs.existsSync(rootPrisma) ? rootPrisma : fs.existsSync(appPrisma) ? appPrisma : dirnamePrisma;
  }
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const { default: Database } = await import('better-sqlite3');
  authDatabase = new Database(dbPath);
} else {
  authDatabase = prismaAdapter(prisma, {
    provider: 'postgresql'
  });
}

export const auth = betterAuth({
  appName: 'DustGuard VN',
  baseURL: process.env.BETTER_AUTH_URL || process.env.APP_ORIGIN || 'http://localhost:3000',
  basePath: '/api/auth',
  secret: authSecret,
  database: authDatabase,
  emailAndPassword: {
    enabled: true,
    minPasswordLength: 8,
  },
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
      prompt: 'select_account',
    },
  },
  account: {
    accountLinking: {
      enabled: true,
      trustedProviders: ['google'],
    },
  },
  trustedOrigins,
  user: {
    modelName: 'users',
    fields: {
      name: 'full_name',
      emailVerified: 'email_verified',
    },
    additionalFields: {
      role: {
        type: 'string',
        required: true,
        input: false,
        defaultValue: 'citizen',
      },
    },
  },
  advanced: {
    database: {
      generateId: 'uuid',
    },
    trustedProxyHeaders: true,
    useSecureCookies: process.env.NODE_ENV === 'production',
  },
  onAPIError: {
    onError(error) {
      console.error('[better-auth]', error);
    },
  },
});

export const authHandler = toNodeHandler(auth.handler);

const sessionCache = new Map();
const SESSION_CACHE_TTL = 3000; // 3 giây để tối ưu chịu tải mà vẫn đảm bảo tính tức thì

export function getSessionFromRequest(req) {
  const authHeader = req.headers.authorization || '';
  const cookieHeader = req.headers.cookie || '';
  
  if (!authHeader && !cookieHeader) {
    return auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
  }

  const cacheKey = `${authHeader}::${cookieHeader}`;
  const now = Date.now();
  const cached = sessionCache.get(cacheKey);

  if (cached && (now - cached.timestamp < SESSION_CACHE_TTL)) {
    return cached.promise;
  }

  // Lưu trữ promise để chống kẹt luồng truy vấn cơ sở dữ liệu đồng thời (Promise Coalescing)
  const promise = auth.api.getSession({
    headers: fromNodeHeaders(req.headers),
  }).catch(err => {
    // Nếu lỗi, xóa khỏi cache để lần sau thử lại
    sessionCache.delete(cacheKey);
    throw err;
  });

  sessionCache.set(cacheKey, {
    timestamp: now,
    promise
  });

  if (sessionCache.size > 5000) {
    for (const [key, val] of sessionCache.entries()) {
      if (now - val.timestamp > SESSION_CACHE_TTL) {
        sessionCache.delete(key);
      }
    }
  }

  return promise;
}

export function normalizeAuthUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    full_name: user.name,
    role: user.role || 'citizen',
    emailVerified: user.emailVerified,
    status: user.status || (user.disabled ? 'DISABLED' : 'ACTIVE'),
    disabled: Boolean(user.disabled || user.status === 'DISABLED' || user.status === 'INACTIVE'),
    organizationId: user.organizationId || user.orgId || null,
  };
}

export function isGoogleOauthConfigured() {
  const id = process.env.GOOGLE_CLIENT_ID;
  const secret = process.env.GOOGLE_CLIENT_SECRET;
  return Boolean(id && secret && id.trim() !== '' && secret.trim() !== '' && !id.includes('your-google'));
}

export function sanitizeRedirectUrl(targetUrl, defaultPath = '/citizen') {
  if (!targetUrl || typeof targetUrl !== 'string') return defaultPath;
  const trimmed = targetUrl.trim();
  if (trimmed.startsWith('/') && !trimmed.startsWith('//') && !trimmed.includes(':\\')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (trustedOrigins.includes(parsed.origin)) {
      return parsed.pathname + parsed.search;
    }
  } catch {
    // Ignore invalid URLs
  }
  return defaultPath;
}

