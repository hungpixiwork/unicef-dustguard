/**
 * Domain rules, state machine and validation for Environmental Observations (DustGuard VN)
 */

import { ENVIRONMENTAL_CATEGORIES_DETAIL } from '../categories/category.rules.js';

export const ENVIRONMENTAL_CATEGORIES = ENVIRONMENTAL_CATEGORIES_DETAIL;

export const OBSERVATION_STATUS = {
  DRAFT: 'DRAFT',
  SUBMITTED: 'SUBMITTED',
  RECORDED: 'RECORDED',
  UNDER_REVIEW: 'UNDER_REVIEW',
  VERIFYING: 'VERIFYING',
  NEEDS_FOLLOWUP: 'NEEDS_FOLLOWUP',
  FOLLOWING_UP: 'FOLLOWING_UP',
  READY_FOR_HANDOFF: 'READY_FOR_HANDOFF',
  HANDED_OFF: 'HANDED_OFF',
  CONVERTED_CASE: 'CONVERTED_CASE',
  RESOLVED: 'RESOLVED',
  CLOSED: 'CLOSED',
  REJECTED: 'REJECTED'
};

export const REPORTER_ROLES = {
  INDIVIDUAL: 'INDIVIDUAL',
  CLUB: 'CLUB',
  VOLUNTEER: 'VOLUNTEER',
  CAMPAIGN: 'CAMPAIGN'
};

// Allowed State Transitions Map
const ALLOWED_OBSERVATION_TRANSITIONS = {
  DRAFT: ['SUBMITTED', 'REJECTED'],
  SUBMITTED: ['RECORDED', 'UNDER_REVIEW', 'VERIFYING', 'NEEDS_FOLLOWUP', 'FOLLOWING_UP', 'REJECTED'],
  RECORDED: ['UNDER_REVIEW', 'VERIFYING', 'NEEDS_FOLLOWUP', 'FOLLOWING_UP', 'READY_FOR_HANDOFF', 'RESOLVED', 'REJECTED'],
  UNDER_REVIEW: ['NEEDS_FOLLOWUP', 'FOLLOWING_UP', 'READY_FOR_HANDOFF', 'RESOLVED', 'REJECTED'],
  VERIFYING: ['NEEDS_FOLLOWUP', 'FOLLOWING_UP', 'READY_FOR_HANDOFF', 'RESOLVED', 'REJECTED'],
  NEEDS_FOLLOWUP: ['FOLLOWING_UP', 'READY_FOR_HANDOFF', 'RESOLVED', 'REJECTED'],
  FOLLOWING_UP: ['FOLLOWING_UP', 'NEEDS_FOLLOWUP', 'READY_FOR_HANDOFF', 'HANDED_OFF', 'CONVERTED_CASE', 'RESOLVED', 'CLOSED'],
  READY_FOR_HANDOFF: ['HANDED_OFF', 'CONVERTED_CASE', 'RESOLVED', 'CLOSED', 'NEEDS_FOLLOWUP'],
  HANDED_OFF: ['RESOLVED', 'CLOSED', 'FOLLOWING_UP'],
  CONVERTED_CASE: ['RESOLVED', 'CLOSED'],
  RESOLVED: ['CLOSED', 'NEEDS_FOLLOWUP'], // Allow re-opening if environmental condition recurs
  CLOSED: [], // Terminal state
  REJECTED: [] // Terminal state
};

/**
 * Checks if observation status transition is permitted.
 */
export function isObservationTransitionAllowed(fromStatus, toStatus) {
  if (!fromStatus || !toStatus) return false;
  if (fromStatus === toStatus) return true;
  const allowedNext = ALLOWED_OBSERVATION_TRANSITIONS[fromStatus] || [];
  return allowedNext.includes(toStatus);
}

/**
 * Asserts valid transition, throws if invalid.
 */
export function assertObservationTransition(fromStatus, toStatus) {
  if (!isObservationTransitionAllowed(fromStatus, toStatus)) {
    const error = new Error(`Chuyển trạng thái quan sát không hợp lệ: từ ${fromStatus} sang ${toStatus}.`);
    error.code = 'INVALID_STATE_TRANSITION';
    error.statusCode = 400;
    throw error;
  }
}

/**
 * Validate input for creating an observation
 */
export function validateObservationInput(data) {
  const errors = [];
  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Dữ liệu gửi lên không hợp lệ.'], sanitized: null };
  }

  if (!data.description || typeof data.description !== 'string' || data.description.trim().length < 5) {
    errors.push('Mô tả hiện trường phải có ít nhất 5 ký tự.');
  }
  if (!data.ward || typeof data.ward !== 'string' || !data.ward.trim()) {
    errors.push('Địa bàn / Phường xã là bắt buộc.');
  }
  if (!data.address || typeof data.address !== 'string' || !data.address.trim()) {
    errors.push('Địa chỉ hoặc vị trí cụ thể là bắt buộc.');
  }

  const categoryKey = data.category || data.categoryId || 'CONSTRUCTION_DUST';
  const categoryMeta = ENVIRONMENTAL_CATEGORIES_DETAIL[categoryKey];
  if (!categoryMeta) {
    errors.push(`Danh mục môi trường không hợp lệ: ${categoryKey}`);
  } else if (!categoryMeta.active) {
    errors.push(`Danh mục môi trường ${categoryKey} hiện đang tạm dừng kích hoạt.`);
  }

  let lat = null;
  let lng = null;
  if (data.latitude !== undefined && data.latitude !== null && data.latitude !== '') {
    lat = parseFloat(data.latitude);
    if (isNaN(lat) || lat < -90 || lat > 90) {
      errors.push('Vĩ độ (latitude) không hợp lệ, phải nằm trong khoảng [-90, 90].');
    }
  }

  if (data.longitude !== undefined && data.longitude !== null && data.longitude !== '') {
    lng = parseFloat(data.longitude);
    if (isNaN(lng) || lng < -180 || lng > 180) {
      errors.push('Kinh độ (longitude) không hợp lệ, phải nằm trong khoảng [-180, 180].');
    }
  }

  let observedAt = new Date().toISOString();
  if (data.observedAt) {
    const parsed = new Date(data.observedAt);
    if (isNaN(parsed.getTime())) {
      errors.push('Thời gian ghi nhận (observedAt) không đúng định dạng ngày tháng.');
    } else if (parsed.getTime() > Date.now() + 5 * 60 * 1000) {
      errors.push('Thời gian ghi nhận không thể ở tương lai.');
    } else {
      observedAt = parsed.toISOString();
    }
  }

  const evidenceUrls = Array.isArray(data.evidenceUrls)
    ? data.evidenceUrls
    : (data.evidenceUrl ? [data.evidenceUrl] : []);

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: {
      category: categoryKey,
      categoryId: categoryKey,
      description: (data.description || '').trim(),
      address: (data.address || '').trim(),
      ward: (data.ward || '').trim(),
      city: (data.city || 'Hà Nội').trim(),
      latitude: lat,
      longitude: lng,
      locationAccuracyM: data.locationAccuracyM ? parseFloat(data.locationAccuracyM) : null,
      observedAt,
      severityInput: data.severityInput || categoryMeta?.defaultSeverity || 'HIGH',
      reporterType: data.reporterType || REPORTER_ROLES.INDIVIDUAL,
      reporterName: (data.reporterName || 'Cộng đồng').trim(),
      reporterPhone: (data.reporterPhone || '').trim(),
      communityId: data.communityId || null,
      campaignId: data.campaignId || null,
      siteId: data.siteId || null,
      evidenceUrls,
      sha256: data.sha256 || null,
      privacyLevel: data.privacyLevel || 'PUBLIC',
      source: data.source || 'COMMUNITY'
    }
  };
}
