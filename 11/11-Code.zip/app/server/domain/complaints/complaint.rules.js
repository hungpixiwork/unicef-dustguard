/**
 * DustGuard Domain Rules: Citizen Complaint Lifecycle & State Machine
 * DDD Domain Layer - Independent of HTTP, Express, Hono, or Database
 */

export const COMPLAINT_STATUS = {
  PENDING: 'PENDING',
  LINKED: 'LINKED',
  PROCESSING: 'PROCESSING',
  RESOLVED: 'RESOLVED',
  REJECTED: 'REJECTED'
};

const VALID_COMPLAINT_TRANSITIONS = {
  PENDING: ['LINKED', 'PROCESSING', 'REJECTED'],
  LINKED: ['PROCESSING', 'REJECTED', 'RESOLVED'],
  PROCESSING: ['RESOLVED', 'REJECTED'],
  RESOLVED: ['PROCESSING'], // Only Admin/Executive can reopen
  REJECTED: ['PENDING', 'PROCESSING'] // Only Admin/Staff can reconsider with explanation
};

/**
 * Normalizes complaint status to standard uppercase representation
 * @param {string} status 
 * @returns {string}
 */
export function normalizeComplaintStatus(status) {
  if (!status) return COMPLAINT_STATUS.PENDING;
  const upper = String(status).trim().toUpperCase();
  if (upper === 'NEW' || upper === 'OPEN' || upper === 'PENDING') return COMPLAINT_STATUS.PENDING;
  if (upper === 'LINKED' || upper === 'ASSIGNED_SITE') return COMPLAINT_STATUS.LINKED;
  if (upper === 'PROCESSING' || upper === 'INVESTIGATING' || upper === 'IN_PROGRESS') return COMPLAINT_STATUS.PROCESSING;
  if (upper === 'RESOLVED' || upper === 'CLOSED' || upper === 'COMPLETED') return COMPLAINT_STATUS.RESOLVED;
  if (upper === 'REJECTED' || upper === 'DISMISSED' || upper === 'INVALID') return COMPLAINT_STATUS.REJECTED;
  return upper;
}

/**
 * Validates complaint state transitions with strict domain guards:
 * - Allowed transitions DAG
 * - Authorized role check (only staff/executive/admin can transition)
 * - Required siteId for LINKED status
 * - Required reason/triageNote for REJECTED status
 * - Required resolution note for RESOLVED status
 * - Admin/Executive requirement for reopening terminal states
 * 
 * @param {string} currentStatus 
 * @param {string} newStatus 
 * @param {Object} [options]
 * @param {string} [options.role] - User role (citizen, contractor, staff, executive, admin)
 * @param {string} [options.siteId] - Target site ID (required for LINKED)
 * @param {string} [options.reason] - Rejection reason / triage note
 * @param {string} [options.resolution] - Resolution description for RESOLVED
 * @throws {Error} if transition or guard conditions fail
 * @returns {boolean} true if valid
 */
export function validateComplaintTransition(currentStatus, newStatus, options = {}) {
  const normCurrent = normalizeComplaintStatus(currentStatus);
  const normNew = normalizeComplaintStatus(newStatus);

  // Self-transition is a no-op
  if (normCurrent === normNew) {
    return true;
  }

  // Guard 1: Role Authorization
  if (options.role) {
    const roleLower = String(options.role).toLowerCase();
    const authorizedRoles = ['staff', 'executive', 'admin', 'demo_admin'];
    if (!authorizedRoles.includes(roleLower)) {
      throw new Error(`Cong dan hoac Nha thau khong co quyen thay doi trang thai phan anh. Yeu cau can bo Thanh tra / Lanh dao.`);
    }
  }

  // Guard 2: Terminal State Reopening (RESOLVED / REJECTED)
  if (normCurrent === COMPLAINT_STATUS.RESOLVED || normCurrent === COMPLAINT_STATUS.REJECTED) {
    const isPrivileged = options.role === 'admin' || options.role === 'executive' || options.role === 'demo_admin';
    const hasReason = Boolean(options.reason && options.reason.trim().length >= 5);
    if (!isPrivileged || !hasReason) {
      throw new Error(`Khong the tu y mo lai phan anh da ${normCurrent}. Chi Lanh dao hoac Admin moi co quyen mo lai kem ly do giai trinh ro rang.`);
    }
  }

  // Guard 3: State Transition Graph Validation
  const allowed = VALID_COMPLAINT_TRANSITIONS[normCurrent];
  if (!allowed || !allowed.includes(normNew)) {
    throw new Error(`Chuyen trang thai khong hop le tu ${currentStatus} (${normCurrent}) sang ${newStatus} (${normNew}).`);
  }

  // Guard 4: LINKED state requires siteId
  if (normNew === COMPLAINT_STATUS.LINKED) {
    if (!options.siteId || String(options.siteId).trim().length === 0) {
      throw new Error(`Chuyen sang trang thai LINKED bat buoc phai gan ma cong truong (siteId) hop le.`);
    }
  }

  // Guard 5: REJECTED state requires valid reason / triage note
  if (normNew === COMPLAINT_STATUS.REJECTED) {
    const reason = options.reason || options.triageNote || options.note;
    if (!reason || String(reason).trim().length < 3) {
      throw new Error(`Tu choi / Bac bo phan anh bat buoc phai co ly do hoac ghi chu phan loai (triageNote).`);
    }
  }

  // Guard 6: RESOLVED state requires resolution note
  if (normNew === COMPLAINT_STATUS.RESOLVED) {
    const resolution = options.resolution || options.reason || options.triageNote || options.note;
    if (!resolution || String(resolution).trim().length < 3) {
      throw new Error(`Dong phan anh (RESOLVED) bat buoc phai co thong tin ket qua xu ly (resolution hoac triageNote).`);
    }
  }

  return true;
}
