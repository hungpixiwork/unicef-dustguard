/**
 * Domain rules for Youth & School Campaigns (DustGuard VN)
 */

export const CAMPAIGN_TOPICS = {
  SCHOOL_ZONE_DUST: {
    id: 'SCHOOL_ZONE_DUST',
    nameVi: 'Lá chắn Bụi Trường học',
    description: 'Giám sát và đo đạc bụi mịn quanh khu vực trường tiểu học và mầm non'
  },
  OPEN_BURNING_WATCH: {
    id: 'OPEN_BURNING_WATCH',
    nameVi: 'Giám sát Đốt rác & Đốt rơm rạ',
    description: 'Phát hiện sớm các điểm khói lửa lộ thiên gây ô nhiễm diện rộng'
  },
  CANAL_CLEANUP: {
    id: 'CANAL_CLEANUP',
    nameVi: 'Bảo vệ Kênh rạch Đô thị',
    description: 'Theo dõi xả thải và rác nổi trên các tuyến kênh rạch trọng điểm'
  },
  GREEN_YOUTH_MONTH: {
    id: 'GREEN_YOUTH_MONTH',
    nameVi: 'Tháng Thanh niên Hành động vì Khí hậu',
    description: 'Chiến dịch tổng lực các CLB tình nguyện ghi nhận và phối hợp xử lý điểm nóng'
  }
};

export const CAMPAIGN_STATUS = {
  DRAFT: 'DRAFT',
  ACTIVE: 'ACTIVE',
  COMPLETED: 'COMPLETED',
  ARCHIVED: 'ARCHIVED'
};

export function validateCampaignInput(data) {
  const errors = [];
  if (!data.title || typeof data.title !== 'string' || data.title.trim().length < 3) {
    errors.push('Tên chiến dịch phải có ít nhất 3 ký tự.');
  }
  if (!data.description || typeof data.description !== 'string') {
    errors.push('Mô tả chiến dịch là bắt buộc.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: {
      code: data.code || `CAMP-${Date.now().toString(36).toUpperCase()}`,
      title: (data.title || '').trim(),
      description: (data.description || '').trim(),
      topic: data.topic && CAMPAIGN_TOPICS[data.topic] ? data.topic : 'SCHOOL_ZONE_DUST',
      ward: (data.ward || 'Toàn thành phố').trim(),
      city: (data.city || 'Hà Nội').trim(),
      startDate: data.startDate ? new Date(data.startDate).toISOString() : new Date().toISOString(),
      endDate: data.endDate ? new Date(data.endDate).toISOString() : new Date(Date.now() + 30 * 86400000).toISOString(),
      status: data.status || CAMPAIGN_STATUS.ACTIVE,
      createdBy: data.createdBy || null
    }
  };
}
