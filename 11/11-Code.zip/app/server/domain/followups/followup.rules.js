/**
 * Domain rules for Follow-Up & Re-visitation (DustGuard VN)
 */

export const FOLLOWUP_OUTCOME = {
  BETTER: 'BETTER',       // Đã cải thiện / Đã che chắn / Đã dọn dẹp
  UNCHANGED: 'UNCHANGED', // Vẫn chưa thay đổi / Tình trạng như cũ
  WORSE: 'WORSE',         // Xấu hơn / Ô nhiễm gia tăng
  UNKNOWN: 'UNKNOWN'      // Chưa xác định rõ
};

export function validateFollowUpInput(data) {
  const errors = [];
  if (!data.observationId && !data.caseId) {
    errors.push('Follow-up phải liên kết với một Observation hoặc Case.');
  }
  if (!data.outcomeStatus || !FOLLOWUP_OUTCOME[data.outcomeStatus]) {
    errors.push(`Trạng thái đánh giá không hợp lệ: ${data.outcomeStatus}`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: {
      observationId: data.observationId || null,
      caseId: data.caseId || null,
      performedBy: (data.performedBy || 'Tình nguyện viên').trim(),
      outcomeStatus: data.outcomeStatus,
      notes: (data.notes || '').trim(),
      evidenceUrl: data.evidenceUrl || null,
      evidenceSha256: data.evidenceSha256 || null,
      verifiedAt: data.verifiedAt ? new Date(data.verifiedAt).toISOString() : new Date().toISOString()
    }
  };
}
