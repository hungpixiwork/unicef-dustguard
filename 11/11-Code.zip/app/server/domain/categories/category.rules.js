/**
 * Domain rules and regulatory references for Environmental Categories (DustGuard VN)
 * SSOT for category metadata, regulatory citations, and evidence requirements.
 */

export const ENVIRONMENTAL_CATEGORIES_DETAIL = {
  CONSTRUCTION_DUST: {
    id: 'CONSTRUCTION_DUST',
    code: 'CAT-01-CONST',
    nameVi: 'Bụi công trình / Xây dựng',
    nameEn: 'Construction Dust',
    description: 'Bụi phát tán từ hoạt động thi công, đào đắp, vận chuyển vật liệu xây dựng và trạm trộn bê tông.',
    icon: 'construction',
    defaultSeverity: 'HIGH',
    defaultPriority: 'HIGH',
    standardRef: 'QCVN 05:2023/BTNM & QCVN 18:2021/BXD',
    evidenceRequirements: [
      'Ảnh hiện trường rõ nguồn phát tán bụi hoặc xe tải thi công',
      'Ảnh/video xe không che phủ bạt hoặc công trường không quây lưới chắn',
      'Vị trí GPS và biển báo công trình (nếu có)'
    ],
    regulations: [
      {
        code: 'QCVN 05:2023/BTNMT',
        title: 'Quy chuẩn kỹ thuật quốc gia về chất lượng không khí',
        authority: 'Bộ Tài nguyên và Môi trường',
        effectiveDate: '2023-09-12',
        sourceReference: 'Thông tư 01/2023/TT-BTNMT',
        applicableConditions: 'Bụi lơ lửng TSP và PM10 xung quanh công trình xây dựng'
      },
      {
        code: 'QCVN 18:2021/BXD',
        title: 'Quy chuẩn an toàn trong thi công xây dựng',
        authority: 'Bộ Xây dựng',
        effectiveDate: '2021-12-01',
        sourceReference: 'Thông tư 16/2021/TT-BXD',
        applicableConditions: 'Biện pháp che chắn, rửa xe và phun nước dập bụi tại công trường'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2023-09-12T00:00:00Z',
    effectiveTo: null
  },
  WASTE: {
    id: 'WASTE',
    code: 'CAT-02-WASTE',
    nameVi: 'Rác thải / Điểm tập kết rác tự phát',
    nameEn: 'Waste & Illegal Dumping',
    description: 'Tập kết rác trái phép, bãi rác tự phát lấn chiếm vỉa hè hoặc gây mất vệ sinh công cộng.',
    icon: 'trash',
    defaultSeverity: 'MEDIUM',
    defaultPriority: 'MEDIUM',
    standardRef: 'Nghị định 45/2022/NĐ-CP',
    evidenceRequirements: [
      'Ảnh bãi rác tự phát chụp bao quát và cận cảnh',
      'Ảnh hiện trạng lấn chiếm lòng đường/vỉa hè/kênh rạch',
      'Định vị GPS và mốc địa danh gần nhất'
    ],
    regulations: [
      {
        code: 'Nghị định 45/2022/NĐ-CP',
        title: 'Nghị định quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
        authority: 'Chính phủ',
        effectiveDate: '2022-08-25',
        sourceReference: 'Điều 25 & 26',
        applicableConditions: 'Hành vi vứt, thải rác thải sinh hoạt bừa bãi hoặc không đúng nơi quy định'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2022-08-25T00:00:00Z',
    effectiveTo: null
  },
  WASTEWATER: {
    id: 'WASTEWATER',
    code: 'CAT-03-WATER',
    nameVi: 'Nước thải / Ô nhiễm kênh rạch',
    nameEn: 'Wastewater & Canal Pollution',
    description: 'Xả nước thải chưa qua xử lý, nước đổi màu hoặc bốc mùi hôi nồng nặc vào nguồn nước mặt.',
    icon: 'water',
    defaultSeverity: 'HIGH',
    defaultPriority: 'HIGH',
    standardRef: 'QCVN 08:2023/BTNMT',
    evidenceRequirements: [
      'Ảnh/video miệng cống hoặc dòng chảy xả nước thải',
      'Ảnh màu nước bất thường hoặc hiện tượng cá chết/nổi bọt',
      'Định vị GPS đoạn kênh/hồ bị ảnh hưởng'
    ],
    regulations: [
      {
        code: 'QCVN 08:2023/BTNMT',
        title: 'Quy chuẩn kỹ thuật quốc gia về chất lượng nước mặt',
        authority: 'Bộ Tài nguyên và Môi trường',
        effectiveDate: '2023-09-12',
        sourceReference: 'Thông tư 01/2023/TT-BTNMT',
        applicableConditions: 'Tiêu chuẩn bảo vệ nguồn nước sinh hoạt và hệ sinh thái thủy sinh'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2023-09-12T00:00:00Z',
    effectiveTo: null
  },
  OPEN_BURNING: {
    id: 'OPEN_BURNING',
    code: 'CAT-04-BURN',
    nameVi: 'Đốt rác / Đốt rơm rạ lộ thiên',
    nameEn: 'Open Burning & Smoke',
    description: 'Đốt rác sinh hoạt, phế liệu nhựa hoặc đốt rơm rạ lộ thiên gây khói bụi dày đặc.',
    icon: 'fire',
    defaultSeverity: 'CRITICAL',
    defaultPriority: 'CRITICAL',
    standardRef: 'Chỉ thị 19/CT-TTg',
    evidenceRequirements: [
      'Ảnh/video đám cháy và cột khói phát tán',
      'Ảnh xác định chất liệu bị đốt (rác thải/rơm rạ/phế liệu)',
      'Định vị GPS vị trí đám đốt'
    ],
    regulations: [
      {
        code: 'Chỉ thị 19/CT-TTg',
        title: 'Chỉ thị về tăng cường khắc phục ô nhiễm không khí',
        authority: 'Thủ tướng Chính phủ',
        effectiveDate: '2020-08-15',
        sourceReference: 'Chỉ thị số 19/CT-TTg',
        applicableConditions: 'Kiểm soát triệt để hoạt động đốt rơm rạ, phụ phẩm nông nghiệp và rác thải ngoài trời'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2020-08-15T00:00:00Z',
    effectiveTo: null
  },
  AGRICULTURAL_CHEMICAL: {
    id: 'AGRICULTURAL_CHEMICAL',
    code: 'CAT-05-AGRI',
    nameVi: 'Thuốc BVTV / Hóa chất nông nghiệp',
    nameEn: 'Pesticides & Agricultural Chemicals',
    description: 'Vứt bỏ vỏ bao gói thuốc bảo vệ thực vật bừa bãi hoặc rửa dụng cụ phun thuốc vào nguồn nước.',
    icon: 'flask',
    defaultSeverity: 'HIGH',
    defaultPriority: 'HIGH',
    standardRef: 'Luật Bảo vệ Môi trường 2020',
    evidenceRequirements: [
      'Ảnh bao gói, chai lọ thuốc BVTV tại đồng ruộng/nguồn nước',
      'Định vị GPS cánh đồng hoặc mương máng'
    ],
    regulations: [
      {
        code: 'Luật BVMT 2020',
        title: 'Luật Bảo vệ Môi trường 2020',
        authority: 'Quốc hội',
        effectiveDate: '2022-01-01',
        sourceReference: 'Điều 61 & 62',
        applicableConditions: 'Quản lý bao gói thuốc bảo vệ thực vật, phân bón sau sử dụng'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2022-01-01T00:00:00Z',
    effectiveTo: null
  },
  AIR_QUALITY: {
    id: 'AIR_QUALITY',
    code: 'CAT-06-AIR',
    nameVi: 'Mùi hôi / Khí thải công nghiệp',
    nameEn: 'Odor & Industrial Emission',
    description: 'Ống khói xả khí đen nồng nặc hoặc mùi hóa chất/dung môi nồng từ cơ sở sản xuất.',
    icon: 'wind',
    defaultSeverity: 'MEDIUM',
    defaultPriority: 'MEDIUM',
    standardRef: 'QCVN 19:2009/BTNMT',
    evidenceRequirements: [
      'Ảnh/video ống khói xả thải hoặc khu vực phát tán mùi',
      'Ghi nhận thời điểm và hướng gió',
      'Định vị GPS nhà xưởng hoặc cơ sở sản xuất'
    ],
    regulations: [
      {
        code: 'QCVN 19:2009/BTNMT',
        title: 'Quy chuẩn kỹ thuật quốc gia về khí thải công nghiệp đối với bụi và các chất vô cơ',
        authority: 'Bộ Tài nguyên và Môi trường',
        effectiveDate: '2009-10-07',
        sourceReference: 'Thông tư 25/2009/TT-BTNMT',
        applicableConditions: 'Nồng độ bụi và khí thải phát tán từ cơ sở sản xuất'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2009-10-07T00:00:00Z',
    effectiveTo: null
  },
  OTHER: {
    id: 'OTHER',
    code: 'CAT-07-OTHER',
    nameVi: 'Vấn đề môi trường khác',
    nameEn: 'Other Environmental Concern',
    description: 'Các sự cố hoặc nguy cơ ô nhiễm môi trường khác cần ghi nhận và theo dõi.',
    icon: 'alert-circle',
    defaultSeverity: 'LOW',
    defaultPriority: 'LOW',
    standardRef: 'Luật BVMT 2020',
    evidenceRequirements: [
      'Ảnh mô tả tổng thể hiện trường',
      'Định vị GPS và mô tả chi tiết'
    ],
    regulations: [
      {
        code: 'Luật BVMT 2020',
        title: 'Luật Bảo vệ Môi trường 2020',
        authority: 'Quốc hội',
        effectiveDate: '2022-01-01',
        sourceReference: 'Điều 4',
        applicableConditions: 'Nguyên tắc bảo vệ môi trường và quyền giám sát của công dân'
      }
    ],
    active: true,
    version: 1,
    effectiveFrom: '2022-01-01T00:00:00Z',
    effectiveTo: null
  }
};

export const ENVIRONMENTAL_CATEGORIES = ENVIRONMENTAL_CATEGORIES_DETAIL;

export function getEnvironmentalCategory(id) {
  if (!id) return null;
  return ENVIRONMENTAL_CATEGORIES_DETAIL[id] || null;
}

export function listEnvironmentalCategories(includeInactive = false) {
  const all = Object.values(ENVIRONMENTAL_CATEGORIES_DETAIL);
  if (includeInactive) return all;
  return all.filter(c => c.active);
}
