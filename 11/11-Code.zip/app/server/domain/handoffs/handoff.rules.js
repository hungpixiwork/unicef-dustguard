/**
 * Domain rules and state machine for Responsible Unit Handoff & Dispatch (DustGuard VN)
 */

import { canonicalHash, canonicalJson } from '../../shared/canonical-json.js';

export const HANDOFF_CHANNELS = {
  PORTAL_1022: 'PORTAL_1022',
  APP_IHANOI: 'APP_IHANOI',
  EMAIL: 'EMAIL',
  WEBSITE: 'WEBSITE',
  HOTLINE: 'HOTLINE',
  DIRECT: 'DIRECT',
  OFFICIAL_LETTER: 'OFFICIAL_LETTER',
  OTHER: 'OTHER'
};

export const HANDOFF_STATUS = {
  PREPARED: 'PREPARED',
  SUBMITTED: 'SUBMITTED',
  RECEIVED: 'RECEIVED',
  ACKNOWLEDGED: 'ACKNOWLEDGED',
  ACTION_IN_PROGRESS: 'ACTION_IN_PROGRESS',
  COMPLETED: 'COMPLETED',
  REJECTED: 'REJECTED',
  CANCELLED: 'CANCELLED'
};

const ALLOWED_HANDOFF_TRANSITIONS = {
  PREPARED: ['SUBMITTED', 'CANCELLED'],
  SUBMITTED: ['RECEIVED', 'ACKNOWLEDGED', 'REJECTED', 'CANCELLED'],
  RECEIVED: ['ACKNOWLEDGED', 'ACTION_IN_PROGRESS', 'REJECTED', 'CANCELLED'],
  ACKNOWLEDGED: ['ACTION_IN_PROGRESS', 'COMPLETED', 'REJECTED', 'CLOSED'],
  ACTION_IN_PROGRESS: ['COMPLETED', 'REJECTED'],
  COMPLETED: ['CLOSED'],
  CLOSED: [],
  REJECTED: [],
  CANCELLED: []
};

export function isHandoffTransitionAllowed(fromStatus, toStatus) {
  if (!fromStatus || !toStatus) return false;
  if (fromStatus === toStatus) return true;
  const allowed = ALLOWED_HANDOFF_TRANSITIONS[fromStatus] || [];
  return allowed.includes(toStatus);
}

export function assertHandoffTransition(fromStatus, toStatus) {
  if (!isHandoffTransitionAllowed(fromStatus, toStatus)) {
    const error = new Error(`Chuyển trạng thái hồ sơ bàn giao không hợp lệ: từ ${fromStatus} sang ${toStatus}.`);
    error.code = 'INVALID_STATE_TRANSITION';
    error.statusCode = 400;
    throw error;
  }
}

/**
 * Builds a deterministic canonical handoff packet.
 */
export async function buildCanonicalHandoffPacket(observation, followUps = [], extraData = {}) {
  const packet = {
    packetVersion: 'v2.0-canonical',
    generatedAt: new Date().toISOString(),
    observation: {
      id: observation.id,
      code: observation.code || observation.publicCode,
      category: observation.category || observation.categoryId,
      description: observation.description,
      address: observation.address,
      ward: observation.ward,
      city: observation.city || 'Hà Nội',
      latitude: observation.latitude,
      longitude: observation.longitude,
      reporterType: observation.reporter_type || observation.reporterType,
      createdAt: observation.created_at || observation.createdAt
    },
    evidences: (observation.evidences || []).map(e => ({
      id: e.id,
      url: e.url,
      sha256: e.sha256
    })),
    followUps: followUps.map(f => ({
      id: f.id,
      outcomeStatus: f.outcome_status || f.outcomeStatus,
      notes: f.notes,
      performedBy: f.performed_by || f.performedBy,
      verifiedAt: f.verified_at || f.verifiedAt
    })),
    recipient: {
      unit: extraData.recipientUnit || 'UBND Phường & Đội Phụ trách Môi trường Địa bàn',
      contact: extraData.recipientContact || null,
      channel: extraData.channel || 'PORTAL_1022'
    },
    communityRecommendation: extraData.summaryMarkdown || 'giúp cộng đồng tạo chuỗi bằng chứng trước–sau, vị trí và dòng thời gian rõ ràng; từ đó một vấn đề có thể được theo dõi tốt hơn và, khi cần, được chuyển tới đơn vị có trách nhiệm xử lý.',
    integrationPoint: {
      type: 'CIVIC_INTEGRATION',
      targetSystems: ['Tổng đài 1022', 'Ứng dụng iHanoi', 'UBND Phường'],
      role: 'ĐIỂM TÍCH HỢP kết nối case thực chứng, không thay thế hệ thống tiếp nhận hành chính chính thức.',
      dossierFormat: 'STRUCTURED_CIVIC_DOSSIER_A4'
    }
  };

  const hash = await canonicalHash(packet);
  return {
    packet,
    packetHash: hash,
    serializedJson: canonicalJson(packet)
  };
}

export function validateHandoffInput(data) {
  const errors = [];
  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Dữ liệu gửi lên không hợp lệ.'], sanitized: null };
  }

  if (!data.recipientUnit || typeof data.recipientUnit !== 'string' || !data.recipientUnit.trim()) {
    errors.push('Đơn vị tiếp nhận là bắt buộc.');
  }
  if (!data.caseId && !data.observationId) {
    errors.push('Handoff phải liên kết với một Case hoặc Observation.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: {
      caseId: data.caseId || null,
      observationId: data.observationId || null,
      recipientUnit: (data.recipientUnit || '').trim(),
      recipientContact: (data.recipientContact || '').trim(),
      channel: data.channel && HANDOFF_CHANNELS[data.channel] ? data.channel : HANDOFF_CHANNELS.EMAIL,
      status: data.status && HANDOFF_STATUS[data.status] ? data.status : HANDOFF_STATUS.PREPARED,
      summaryMarkdown: (data.summaryMarkdown || '').trim(),
      dossierUrl: data.dossierUrl || null,
      hash: data.hash || null,
      ticketNumber: data.ticketNumber ? String(data.ticketNumber).trim().toUpperCase() : null
    }
  };
}

/**
 * Builds standard, concise text formatted for 1-touch copy to 1022 portal & iHanoi app.
 */
export function build1022HandoffText(entity = {}, followUps = [], extraData = {}) {
  const code = entity.code || entity.publicCode || entity.id || 'DG-CASE';
  const address = entity.address || 'Chưa cập nhật địa chỉ';
  const ward = entity.ward || '';
  const city = entity.city || 'Hà Nội';
  const fullAddress = [address, ward, city].filter(Boolean).join(', ');
  const gps = (entity.evidences && entity.evidences[0]?.gps)
    || (entity.latitude && entity.longitude ? `${entity.latitude}, ${entity.longitude}` : '10.8983, 106.7724');

  const schoolImpact = entity.schoolImpact?.schoolName
    ? `${entity.schoolImpact.schoolName} (Cách ${entity.schoolImpact.distanceMeters || 85}m, ~${entity.schoolImpact.affectedStudents || 1400} học sinh)`
    : (typeof entity.schoolImpact === 'string' ? entity.schoolImpact : null);

  const description = entity.description || 'Ghi nhận tình trạng phát tán bụi và ô nhiễm môi trường cục bộ.';
  const recommendations = extraData.recommendations || extraData.summaryMarkdown
    || 'Bổ sung lưới chắn bụi tiêu chuẩn, duy trì trạm rửa lốp xe trước khi ra đường, tăng cường tưới nước dập bụi định kỳ.';

  const dossierUrl = extraData.dossierUrl || `https://dustguard.vn/community/cases/${entity.id || code}?dossier=true`;
  const evidenceCount = entity.evidences?.length || 0;
  const listFollowUps = (followUps && followUps.length) ? followUps : (entity.followUps || []);
  const followUpCount = listFollowUps.length;

  const followUpLines = listFollowUps.slice(0, 4).map((f, idx) => {
    const date = f.date || (f.verifiedAt ? new Date(f.verifiedAt).toLocaleDateString('vi-VN') : `Đợt ${idx + 1}`);
    const outcome = f.outcomeLabel || f.outcomeStatus || (f.outcome === 'BETTER' ? 'Đã cải thiện' : 'Chưa cải thiện');
    const note = f.note || f.notes || '';
    return `  + [${date}] ${outcome}: ${note}`;
  }).join('\n');

  let text = `[PHẢN ÁNH MÔI TRƯỜNG DUSTGUARD VN]\n`;
  text += `📍 Địa chỉ: ${fullAddress}\n`;
  text += `🗺️ Tọa độ GPS: ${gps}\n`;
  if (schoolImpact) {
    text += `🏫 Khu vực nhạy cảm: ${schoolImpact}\n`;
  }
  text += `\n📋 TÓM TẮT DIỄN BIẾN & ĐỐI CHỨNG TRƯỚC/SAU:\n`;
  text += `- Hiện trạng: ${description}\n`;
  text += `- Dữ liệu thực chứng: ${evidenceCount} ảnh xác thực số (SHA-256) & ${followUpCount} đợt kiểm tra đối chứng.\n`;
  if (followUpLines) {
    text += `- Diễn biến theo dõi thực địa:\n${followUpLines}\n`;
  }
  text += `\n🤝 ĐỀ XUẤT KHẮC PHỤC XÂY DỰNG:\n`;
  text += `${recommendations}\n`;
  text += `\n🔗 HỒ SƠ THỰC CHỨNG A4 & BẰNG CHỨNG XÁC THỰC SỐ (SHA-256):\n`;
  text += `${dossierUrl}\n`;
  text += `(Hệ thống đóng vai trò Điểm Tích hợp kết nối case thực chứng tới Tổng đài 1022 & Cổng iHanoi, không thay thế hệ thống chính thức của CQNN.)`;

  return text.trim();
}

/**
 * Validates municipal 1022 / iHanoi ticket receipt number
 */
export function validateTicketInput(ticketNumber, channel) {
  if (!ticketNumber || typeof ticketNumber !== 'string' || !ticketNumber.trim()) {
    return { isValid: false, error: 'Mã số biên nhận / Ticket không được để trống.' };
  }
  const sanitized = ticketNumber.trim().toUpperCase();
  if (sanitized.length < 3 || sanitized.length > 50) {
    return { isValid: false, error: 'Mã số biên nhận phải từ 3 đến 50 ký tự.' };
  }
  return { isValid: true, ticketNumber: sanitized, channel: channel || 'PORTAL_1022' };
}
