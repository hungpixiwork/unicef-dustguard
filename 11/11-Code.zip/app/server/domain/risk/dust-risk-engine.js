/**
 * DustRiskEngine (DustGuard VN SSOT)
 * Canonical Explainable Environmental Risk & Priority Domain Service
 * 
 * Invariants:
 * 1. Categorizes environmental risk prioritization, NOT judicial compliance determination.
 * 2. 5-Component Formula: Community (30%), Sensitive Receptors (25%), Compliance & Evidence (20%), History & Recurrence (15%), IoT Telemetry (10% Optional).
 * 3. Zero-IoT Resilience: Missing/faulty/inactive sensors are excluded and remaining 90% weights normalize to 1.0 (Sum = 1.0).
 * 4. Strict numerical safety & clamping [0, 100], deterministic execution, full explainability.
 * 5. SSOT RISK_BANDS:
 *    - CRITICAL: 80 - 100 (Báo động đỏ / P1, SLA 24h)
 *    - HIGH: 65 - 79 (Ưu tiên cao / P2, SLA 48h)
 *    - MEDIUM: 40 - 64 (Cần theo dõi / P3, SLA 7 ngày)
 *    - LOW: 0 - 39 (Bình thường / P4)
 *    - UNKNOWN: -1 (Chưa xác định)
 */

export const DUST_RISK_ENGINE_VERSION = 'dust-risk-v2.0';
export const RISK_ENGINE_VERSION = 'dust-risk-v2.0';
export const PRIORITY_ENGINE_VERSION = 'community-priority-v1';

// 1. RISK_BANDS SSOT
export const RISK_BANDS = {
  CRITICAL: {
    key: 'CRITICAL',
    min: 80,
    max: 100,
    label: 'Báo động đỏ / P1',
    levelText: 'ƯU TIÊN RẤT CAO / P1',
    slaHours: 24,
    slaText: '24h',
    priorityLevel: 'P1',
    tierColor: 'red',
    color: 'red',
    badgeColor: '#9f241f',
    badgeBg: '#FDF2F2',
    description: 'Cần xem xét và can thiệp khẩn cấp trong 24h (SLA P1), có nhiều tín hiệu tập trung và đối tượng nhạy cảm tiếp giáp.'
  },
  HIGH: {
    key: 'HIGH',
    min: 65,
    max: 79,
    label: 'Ưu tiên cao / P2',
    levelText: 'ƯU TIÊN CAO / P2',
    slaHours: 48,
    slaText: '48h',
    priorityLevel: 'P2',
    tierColor: 'red',
    color: 'red',
    badgeColor: '#c4320a',
    badgeBg: '#FFF4F2',
    description: 'Cần bố trí cán bộ thanh tra xác minh hiện trường trong 48h (SLA P2).'
  },
  MEDIUM: {
    key: 'MEDIUM',
    min: 40,
    max: 64,
    label: 'Cần theo dõi / P3',
    levelText: 'CẦN THEO DÕI / P3',
    slaHours: 168,
    slaText: '7 ngày',
    priorityLevel: 'P3',
    tierColor: 'amber',
    color: 'amber',
    badgeColor: '#b54708',
    badgeBg: '#FEF6EE',
    description: 'Theo dõi tiến trình khắc phục, rà soát trong đợt kiểm tra định kỳ 7 ngày (SLA P3).'
  },
  LOW: {
    key: 'LOW',
    min: 0,
    max: 39,
    label: 'Bình thường / P4',
    levelText: 'BÌNH THƯỜNG / THẤP',
    slaHours: null,
    slaText: 'Định kỳ',
    priorityLevel: 'P4',
    tierColor: 'green',
    color: 'green',
    badgeColor: '#0d6f64',
    badgeBg: '#F0FDF9',
    description: 'Duy trì quan trắc và giám sát cộng đồng định kỳ.'
  },
  UNKNOWN: {
    key: 'UNKNOWN',
    min: -1,
    max: -1,
    label: 'Chưa xác định',
    levelText: 'CHƯA XÁC ĐỊNH',
    slaHours: null,
    slaText: '—',
    priorityLevel: 'P0',
    tierColor: 'gray',
    color: 'gray',
    badgeColor: '#667085',
    badgeBg: '#F8F9FA',
    description: 'Chưa đủ dữ liệu quan trắc để đánh giá.'
  }
};

// Aliases for compatibility
RISK_BANDS.MODERATE = RISK_BANDS.MEDIUM;

export const PRIORITY_TIERS = RISK_BANDS;
export const RISK_TIERS = RISK_BANDS;

// 2. Component Weights (Sum = 1.0)
export const COMPONENT_WEIGHTS = {
  community: 0.30,   // Community reports & civic consensus (30%)
  exposure: 0.25,    // Sensitive receptors proximity (25%)
  compliance: 0.20,  // Checklist & mitigation deficit / Evidence (20%)
  history: 0.15,     // Recurrence & repeat violations (15%)
  sensor: 0.10,      // IoT telemetry PM2.5/PM10 (10% - Optional)
};

// Compatibility aliases for component weights
COMPONENT_WEIGHTS.evidence = COMPONENT_WEIGHTS.compliance;
COMPONENT_WEIGHTS.telemetry = COMPONENT_WEIGHTS.sensor;
COMPONENT_WEIGHTS.complaints = COMPONENT_WEIGHTS.community;
COMPONENT_WEIGHTS.inspection = COMPONENT_WEIGHTS.history;

// 3. Sensitive Distance Thresholds (meters)
export const EXPOSURE_THRESHOLDS = {
  school: { critical: 100, high: 200, medium: 500, low: 1000 },
  hospital: { critical: 100, high: 200, medium: 500, low: 1000 },
  res: { critical: 30, high: 100, medium: 300, low: 500 },
  ubnd: { high: 200, medium: 500, low: 1000 }
};

// 4. Standardized UI Copy & Legal Disclaimers
export const PRIORITY_COPY = {
  title: 'Điểm ưu tiên xử lý',
  titleEn: 'Community Priority Score',
  disclaimer: 'Chỉ số ưu tiên can thiệp môi trường cộng đồng, mang tính giải thích minh bạch hỗ trợ ra quyết định, không thay thế kết luận giám định tư pháp.',
  noSensorNote: 'Chưa có dữ liệu IoT — điểm được chuẩn hóa từ các nguồn dữ liệu khả dụng.',
  highPriorityNotice: 'Ưu tiên xem xét cao — nhiều tín hiệu cần được xác minh sớm.',
  componentLabels: {
    community: 'Tín hiệu cộng đồng',
    exposure: 'Phơi nhiễm nhạy cảm',
    compliance: 'Thiếu hụt biện pháp che chắn',
    evidence: 'Độ tin cậy minh chứng',
    history: 'Lịch sử & Tái diễn',
    sensor: 'Cảm biến IoT bổ trợ',
    telemetry: 'Nồng độ bụi quan trắc IoT'
  }
};

export const RISK_COPY = PRIORITY_COPY;

/**
 * Clamps any numeric value strictly to [min, max].
 * Returns fallback if value is NaN or not finite.
 */
export function clampScore(value, min = 0, max = 100, fallback = 0) {
  const num = typeof value === 'number' ? value : parseFloat(value);
  if (isNaN(num) || !Number.isFinite(num)) return fallback;
  return Math.max(min, Math.min(max, Math.round(num)));
}

/**
 * Maps a numeric score to standard Risk Band / Priority Tier
 * @param {number} score - -1 to 100
 * @returns {typeof RISK_BANDS[keyof typeof RISK_BANDS]}
 */
export function getRiskBand(score) {
  if (score === null || score === undefined || score === -1) {
    return RISK_BANDS.UNKNOWN;
  }
  const num = typeof score === 'number' ? score : parseFloat(score);
  if (isNaN(num) || !Number.isFinite(num) || num < 0) {
    return RISK_BANDS.UNKNOWN;
  }
  const clamped = Math.max(0, Math.min(100, Math.round(num)));
  if (clamped >= 80) return RISK_BANDS.CRITICAL;
  if (clamped >= 65) return RISK_BANDS.HIGH;
  if (clamped >= 40) return RISK_BANDS.MEDIUM;
  return RISK_BANDS.LOW;
}

export const getRiskTier = getRiskBand;
export const getPriorityTier = getRiskBand;

/**
 * 1. Community Signal (30% weight)
 * Evaluates strength of civic reports: independent reporters, recency, anti-spam dedup.
 */
export function computeCommunitySignal(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const reasons = [];
  let independentReporters = 0;
  let totalComplaints = 0;
  let hasSpamDeduction = false;

  const unresolvedCount = typeof safeInput.unresolvedCount === 'number' && Number.isFinite(safeInput.unresolvedCount)
    ? Math.max(0, safeInput.unresolvedCount)
    : 0;

  if (Array.isArray(safeInput.complaints)) {
    totalComplaints = safeInput.complaints.length;
    const reporterMap = new Set();
    safeInput.complaints.forEach((c, idx) => {
      const cObj = c && typeof c === 'object' ? c : {};
      const identity = cObj.reporterFingerprint || cObj.reporterPhone || cObj.reporterId || cObj.userId || (cObj.reporterName && cObj.reporterName !== 'Ẩn danh' ? cObj.reporterName : (typeof c === 'string' && c ? c : `anon_${idx}`));
      reporterMap.add(identity);
    });
    independentReporters = reporterMap.size;
  } else {
    const directCount = typeof safeInput.complaints === 'number' && Number.isFinite(safeInput.complaints) 
      ? Math.max(0, safeInput.complaints) 
      : (typeof safeInput.complaintCount === 'number' && Number.isFinite(safeInput.complaintCount) 
          ? Math.max(0, safeInput.complaintCount) 
          : (typeof safeInput.observationCount === 'number' && Number.isFinite(safeInput.observationCount)
              ? Math.max(0, safeInput.observationCount)
              : (Array.isArray(safeInput.observations) ? safeInput.observations.length : 0)));
    totalComplaints = directCount;
    independentReporters = typeof safeInput.independentReporters === 'number' && Number.isFinite(safeInput.independentReporters)
      ? Math.max(0, safeInput.independentReporters) 
      : Math.max(0, Math.ceil(totalComplaints > 3 ? totalComplaints * 0.75 : totalComplaints));
  }

  // Anti-spam rule: If 1 person submits many complaints (>= 5)
  if (totalComplaints >= 5 && independentReporters === 1) {
    hasSpamDeduction = true;
    reasons.push(`${totalComplaints} phản ánh gửi từ cùng 1 nguồn định danh (áp dụng cơ chế chống spam)`);
  }

  let rawScore = 0;
  if (totalComplaints === 0 && unresolvedCount === 0) {
    rawScore = 0;
    reasons.push('Chưa ghi nhận phản ánh cộng đồng tại khu vực');
  } else if (hasSpamDeduction) {
    const safeCount = Math.max(1, totalComplaints);
    rawScore = Math.min(35, Math.round(25 + Math.log2(safeCount) * 2));
  } else if (independentReporters === 1) {
    rawScore = 25;
    if (unresolvedCount >= 1) rawScore = Math.max(rawScore, 60);
    reasons.push(`1 phản ánh từ cộng đồng`);
  } else if (independentReporters <= 3) {
    rawScore = 40 + (independentReporters - 1) * 18; // 2: 58, 3: 76
    if (unresolvedCount >= 3) rawScore = Math.max(rawScore, 90);
    else if (unresolvedCount >= 1) rawScore = Math.max(rawScore, 75);
    reasons.push(`${totalComplaints} phản ánh từ ${independentReporters} người dân độc lập`);
  } else if (independentReporters <= 10) {
    rawScore = 76 + (independentReporters - 3) * 3.2; // 4: ~79 -> 10: ~98
    if (unresolvedCount >= 3) rawScore = Math.max(rawScore, 90);
    reasons.push(`${totalComplaints} phản ánh từ ${independentReporters} người độc lập trong 7 ngày`);
  } else {
    rawScore = 100;
    reasons.push(`${totalComplaints} phản ánh tập trung từ ${independentReporters}+ người độc lập (mức độ đồng thuận cao)`);
  }

  // Support unresolvedCount / obsCount boost
  if (unresolvedCount >= 3 && !hasSpamDeduction) {
    rawScore = Math.max(rawScore, 90);
  }

  // Recency modifier
  if (typeof safeInput.recencyDays === 'number' && Number.isFinite(safeInput.recencyDays) && safeInput.recencyDays > 14 && rawScore > 20) {
    rawScore = Math.round(rawScore * 0.65);
    reasons.push('Tín hiệu giảm dần theo thời gian (>14 ngày)');
  }

  const score = clampScore(rawScore);
  const weight = COMPONENT_WEIGHTS.community;
  const contribution = Math.round(score * weight);

  const driverTags = [];
  if (totalComplaints > 0) {
    const repCount = independentReporters > 0 ? independentReporters : totalComplaints;
    driverTags.push(`+ ${repCount} citizen report${repCount > 1 ? 's' : ''}`);
  }

  return {
    key: 'community',
    code: 'COMMUNITY_SIGNAL',
    name: 'Tín hiệu phản ánh cộng đồng & thanh niên',
    weight,
    score,
    contribution,
    available: true,
    status: score >= 65 ? 'HIGH' : (score >= 40 ? 'MODERATE' : 'LOW'),
    reasons,
    reason: reasons.join('; '),
    driverTags,
    metrics: {
      totalComplaints,
      independentReporters,
      hasSpamDeduction,
      unresolvedCount
    }
  };
}

export const computeComplaintsFactor = computeCommunitySignal;

/**
 * 2. Exposure Signal (25% weight)
 * Evaluates sensitive receptor proximity: schools, hospitals, residential areas.
 * Special emphasis on < 300m buffer zones (e.g., school < 300m, hospital < 300m).
 */
export function computeExposureSignal(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const reasons = [];
  const driverTags = [];
  const nearList = Array.isArray(safeInput.near) ? safeInput.near : [];
  const sensitiveReceptors = Array.isArray(safeInput.sensitiveReceptors) ? safeInput.sensitiveReceptors : [];

  let maxTargetScore = 0;
  let sensitiveCount = 0;
  let nearestDistance = null;
  let nearestType = null;
  let nearestName = null;

  const updateNearest = (dist, type, name) => {
    if (typeof dist === 'number' && Number.isFinite(dist)) {
      if (nearestDistance === null || dist < nearestDistance) {
        nearestDistance = dist;
        nearestType = type;
        nearestName = name;
      }
    }
  };

  // 1. Process nearList [{ t, d, k }]
  nearList.forEach(item => {
    const itemObj = item && typeof item === 'object' ? item : {};
    const type = itemObj.t || itemObj.type;
    const distance = typeof itemObj.d === 'number' && Number.isFinite(itemObj.d)
      ? itemObj.d
      : (typeof itemObj.distance === 'number' && Number.isFinite(itemObj.distance) ? itemObj.distance : 9999);
    const name = itemObj.k || itemObj.name || type;

    updateNearest(distance, type, name);

    let targetScore = 0;
    if (type === 'school') {
      if (distance <= EXPOSURE_THRESHOLDS.school.critical) {
        targetScore = 100;
        reasons.push(`Tiếp giáp trường học (${name}, ${distance}m < 100m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.school.high) {
        targetScore = 95;
        reasons.push(`Gần trường học (${name}, ${distance}m < 200m)`);
      } else if (distance <= 300) {
        targetScore = 80;
        reasons.push(`Tiếp cận trường học (${name}, ${distance}m < 300m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.school.medium) {
        targetScore = 60;
        reasons.push(`Trong bán kính 500m trường học (${name}, ${distance}m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.school.low) {
        targetScore = 30;
      }
    } else if (type === 'hospital') {
      if (distance <= EXPOSURE_THRESHOLDS.hospital.critical) {
        targetScore = 100;
        reasons.push(`Tiếp giáp bệnh viện (${name}, ${distance}m < 100m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.hospital.high) {
        targetScore = 95;
        reasons.push(`Gần bệnh viện (${name}, ${distance}m < 200m)`);
      } else if (distance <= 300) {
        targetScore = 80;
        reasons.push(`Tiếp cận bệnh viện (${name}, ${distance}m < 300m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.hospital.medium) {
        targetScore = 60;
        reasons.push(`Trong bán kính 500m cơ sở y tế (${name}, ${distance}m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.hospital.low) {
        targetScore = 30;
      }
    } else if (type === 'res') {
      if (distance <= EXPOSURE_THRESHOLDS.res.critical) {
        targetScore = 95;
        reasons.push(`Sát khu dân cư đông đúc (${name}, ${distance}m < 30m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.res.high) {
        targetScore = 75;
        reasons.push(`Gần khu dân cư (${name}, ${distance}m < 100m)`);
      } else if (distance <= EXPOSURE_THRESHOLDS.res.medium) {
        targetScore = 50;
      } else if (distance <= EXPOSURE_THRESHOLDS.res.low) {
        targetScore = 25;
      }
    } else if (type === 'ubnd') {
      if (distance <= EXPOSURE_THRESHOLDS.ubnd.high) {
        targetScore = 50;
      }
    }

    if (targetScore > 0) sensitiveCount++;
    if (targetScore > maxTargetScore) {
      maxTargetScore = targetScore;
    }
  });

  // 2. Process sensitiveReceptors string array
  sensitiveReceptors.forEach(rec => {
    if (typeof rec !== 'string') return;
    let targetScore = 0;
    const distMatch = rec.match(/(\d+)\s*m/i);
    const dist = distMatch ? parseInt(distMatch[1], 10) : null;

    if (/school|trường/i.test(rec)) {
      if (dist !== null) {
        updateNearest(dist, 'school', rec);
        targetScore = dist <= 100 ? 100 : (dist <= 200 ? 95 : (dist <= 300 ? 80 : (dist <= 500 ? 60 : 30)));
      } else {
        updateNearest(150, 'school', rec);
        targetScore = 95;
      }
      reasons.push(`Khu vực nhạy cảm: ${rec}`);
    } else if (/hospital|bệnh viện|y tế/i.test(rec)) {
      if (dist !== null) {
        updateNearest(dist, 'hospital', rec);
        targetScore = dist <= 100 ? 100 : (dist <= 200 ? 95 : (dist <= 300 ? 80 : (dist <= 500 ? 60 : 30)));
      } else {
        updateNearest(150, 'hospital', rec);
        targetScore = 95;
      }
      reasons.push(`Khu vực nhạy cảm: ${rec}`);
    } else if (/residential|dân cư/i.test(rec)) {
      if (dist !== null) updateNearest(dist, 'res', rec);
      targetScore = 75;
      reasons.push(`Khu vực nhạy cảm: ${rec}`);
    } else {
      targetScore = 50;
    }

    if (targetScore > 0) sensitiveCount++;
    if (targetScore > maxTargetScore) {
      maxTargetScore = targetScore;
    }
  });

  // 3. Process boolean flags if near and sensitiveReceptors were empty
  if (nearList.length === 0 && sensitiveReceptors.length === 0) {
    if (safeInput.hasSchool) { 
      maxTargetScore = Math.max(maxTargetScore, 95); 
      sensitiveCount++; 
      updateNearest(150, 'school', 'Trường học');
      reasons.push('Gần trường học (<200m)'); 
    }
    if (safeInput.hasHosp) { 
      maxTargetScore = Math.max(maxTargetScore, 95); 
      sensitiveCount++; 
      updateNearest(150, 'hospital', 'Bệnh viện');
      reasons.push('Gần bệnh viện (<200m)'); 
    }
    if (safeInput.hasRes) { 
      maxTargetScore = Math.max(maxTargetScore, 75); 
      sensitiveCount++; 
      updateNearest(80, 'res', 'Khu dân cư');
      reasons.push('Gần khu dân cư (<100m)'); 
    }
  }

  // Multi-receptor synergy bonus
  let finalExposure = maxTargetScore;
  if (sensitiveCount > 1 && finalExposure < 100) {
    finalExposure = Math.min(100, finalExposure + (sensitiveCount - 1) * 5);
  }

  if (reasons.length === 0) {
    finalExposure = 10;
    reasons.push('Xa các đối tượng nhạy cảm (>1000m)');
  }

  // Generate driver tag for sensitive proximity (e.g. "+ 220m from school")
  if (nearestDistance !== null && nearestDistance <= 500) {
    const typeLabel = nearestType === 'school' ? 'school' : (nearestType === 'hospital' ? 'hospital' : (nearestType === 'res' ? 'residential area' : 'sensitive receptor'));
    driverTags.push(`+ ${nearestDistance}m from ${typeLabel}`);
  } else if (sensitiveCount > 0 && maxTargetScore >= 75) {
    driverTags.push(`+ Sensitive receptor zone (<300m)`);
  }

  const score = clampScore(finalExposure);
  const weight = COMPONENT_WEIGHTS.exposure;
  const contribution = Math.round(score * weight);

  return {
    key: 'exposure',
    code: 'SENSITIVE_RECEPTOR',
    name: 'Khoảng cách công trình nhạy cảm (Trường học / Bệnh viện / KDC)',
    weight,
    score,
    contribution,
    available: true,
    status: score >= 75 ? 'CRITICAL_ZONE' : (score >= 50 ? 'WARNING_ZONE' : 'STANDARD_ZONE'),
    reasons,
    reason: reasons.join('; '),
    driverTags,
    metrics: { 
      sensitiveCount, 
      maxTargetScore,
      nearestDistance,
      nearestType,
      nearestName,
      isUnder300m: Boolean(nearestDistance !== null && nearestDistance <= 300)
    }
  };
}

/**
 * 3. Compliance & Evidence Signal (20% weight)
 * Evaluates adherence to environmental protection checklists and cryptographic evidence quality.
 */
export function computeComplianceSignal(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const reasons = [];
  const driverTags = [];
  let scoreAccumulator = 0;

  // Check if high PM reading is present to corroborate unmitigated emission
  const pm25Val = safeInput.currentPm25 ?? safeInput.pm25 ?? safeInput.telemetry?.pm25 ?? 0;
  const pm10Val = safeInput.currentPm10 ?? safeInput.pm10 ?? safeInput.telemetry?.pm10 ?? 0;
  const hasSevereDust = pm25Val >= 75 || pm10Val >= 150;
  const hasElevatedDust = pm25Val >= 50 || pm10Val >= 100;

  // 1. Checklist findings
  const checklist = (safeInput.checklist && typeof safeInput.checklist === 'object')
    ? safeInput.checklist
    : ((safeInput.complianceChecklist && typeof safeInput.complianceChecklist === 'object') ? safeInput.complianceChecklist : null);

  let failedKeys = [];
  if (checklist) {
    failedKeys = Object.keys(checklist).filter(k => checklist[k] === 'fail' || checklist[k] === false);
    const totalChecked = Object.keys(checklist).length;
    if (failedKeys.length >= 3) {
      scoreAccumulator += 100;
      reasons.push(`${failedKeys.length} hạng mục không đạt quy chuẩn bảo vệ môi trường (QCVN 18:2021/BXD)`);
    } else if (failedKeys.length === 2) {
      scoreAccumulator += hasSevereDust ? 85 : 75;
      reasons.push(`${failedKeys.length} hạng mục không đạt quy chuẩn bảo vệ môi trường (QCVN 18:2021/BXD)`);
    } else if (failedKeys.length === 1) {
      scoreAccumulator += hasSevereDust ? 85 : (hasElevatedDust ? 75 : 65);
      reasons.push(`1 hạng mục không đạt quy chuẩn (${failedKeys[0]})`);
    } else if (totalChecked > 0) {
      scoreAccumulator += 10;
      reasons.push('Đạt đầy đủ các biện pháp kiểm soát bụi hiện trường');
    }
  }

  // 2. Photographic & Cryptographic Evidence
  const evidences = Array.isArray(safeInput.evidences) ? safeInput.evidences : [];
  const photoCount = evidences.filter(e => e && typeof e === 'object' && (e.type === 'IMAGE' || (typeof e.url === 'string' && !e.url.endsWith('.pdf')))).length 
    || (safeInput.photo ? 1 : (typeof safeInput.photoCount === 'number' && Number.isFinite(safeInput.photoCount) ? Math.max(0, safeInput.photoCount) : 0));

  let evidenceBoost = 0;
  if (photoCount > 0) {
    evidenceBoost += 25;
    const hasGps = evidences.some(e => e && typeof e === 'object' && (e.gps || e.coordinates)) || safeInput.hasGps || safeInput.coordinates || safeInput.lat;
    const hasHash = evidences.some(e => e && typeof e === 'object' && (e.hmacHash || e.hash)) || safeInput.hasHmac;

    if (hasGps && hasHash) {
      evidenceBoost += 15;
      reasons.push('Có ảnh hiện trường kèm tọa độ GPS và tem niêm phong số bảo chứng');
    } else if (hasGps) {
      evidenceBoost += 10;
      reasons.push('Có ảnh hiện trường kèm định vị GPS thực địa');
    } else {
      reasons.push('Có ảnh hiện trường đính kèm');
    }
  }

  if (safeInput.hasBeforeAfter || evidences.some(e => e && typeof e === 'object' && e.category === 'AFTER')) {
    evidenceBoost += 10;
    reasons.push('Có đối chiếu hình ảnh Trước / Sau khắc phục');
  }

  const desc = typeof safeInput.description === 'string' ? safeInput.description : (typeof safeInput.desc === 'string' ? safeInput.desc : '');
  if (desc.trim().length > 30) {
    evidenceBoost += 10;
  }

  // Blend checklist and evidence
  let finalScore = 0;
  if (checklist && failedKeys.length > 0) {
    finalScore = Math.min(100, scoreAccumulator + Math.min(15, evidenceBoost * 0.3));
  } else if (checklist && failedKeys.length === 0) {
    finalScore = scoreAccumulator;
  } else if (evidenceBoost > 0) {
    finalScore = evidenceBoost;
  } else {
    finalScore = 10;
    reasons.push('Minh chứng sơ bộ, cần cán bộ kiểm tra xác minh thực địa');
  }

  if (failedKeys.length > 0) {
    driverTags.push(`+ ${failedKeys.length} failed checklist item${failedKeys.length > 1 ? 's' : ''}`);
  }

  const score = clampScore(finalScore);
  const weight = COMPONENT_WEIGHTS.compliance;
  const contribution = Math.round(score * weight);

  return {
    key: 'compliance',
    code: 'COMPLIANCE_DEFICIT',
    name: 'Thiếu hụt biện pháp che chắn & dập bụi hiện trường',
    weight,
    score,
    contribution,
    available: true,
    status: score >= 65 ? 'NON_COMPLIANT' : (score >= 40 ? 'PARTIAL_COMPLIANT' : 'COMPLIANT'),
    reasons,
    reason: reasons.join('; '),
    driverTags,
    metrics: {
      failedCount: failedKeys.length,
      failedItems: failedKeys,
      photoCount,
      hasEvidences: evidences.length > 0
    }
  };
}

export const computeEvidenceSignal = computeComplianceSignal;
export const computeComplianceFactor = computeComplianceSignal;
export const computeEvidenceFactor = computeComplianceSignal;

/**
 * 4. History Signal (15% weight)
 * Evaluates historical recurrence, repeat warnings, previously closed cases.
 */
export function computeHistorySignal(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const reasons = [];
  const driverTags = [];
  const recurrenceCount = typeof safeInput.recurrence === 'number' && Number.isFinite(safeInput.recurrence)
    ? Math.max(0, safeInput.recurrence) 
    : (typeof safeInput.recurrenceCount === 'number' && Number.isFinite(safeInput.recurrenceCount) 
        ? Math.max(0, safeInput.recurrenceCount) 
        : (typeof safeInput.pastViolations === 'number' && Number.isFinite(safeInput.pastViolations)
            ? Math.max(0, safeInput.pastViolations)
            : (typeof safeInput.inspectionCount === 'number' && Number.isFinite(safeInput.inspectionCount)
                ? Math.max(0, safeInput.inspectionCount)
                : 0)));

  let rawScore = 15; // baseline clean history

  if (recurrenceCount === 0) {
    rawScore = 15;
    reasons.push('Không có lịch sử vi phạm ghi nhận trong quá khứ');
  } else if (recurrenceCount === 1) {
    rawScore = 50;
    reasons.push('Đã từng có 1 lần bị lập biên bản nhắc nhở trước đó');
  } else if (recurrenceCount === 2) {
    rawScore = 75;
    reasons.push('Có 2 lần tái diễn vi phạm môi trường');
  } else {
    rawScore = Math.min(100, 75 + (recurrenceCount - 2) * 10);
    reasons.push(`${recurrenceCount} lần tái diễn vi phạm liên tục trong quá khứ`);
  }

  if (safeInput.previousClosedThenReopened) {
    rawScore = Math.min(100, rawScore + 20);
    reasons.push('Vấn đề tái xuất hiện sau khi đã đóng hồ sơ cam kết khắc phục');
    driverTags.push('+ Reopened case');
  }

  if (safeInput.unresolvedOverdue || safeInput.unresolvedCount > 0) {
    rawScore = Math.min(100, rawScore + 35);
    reasons.push('Có văn bản yêu cầu khắc phục quá hạn / chưa giải quyết');
    driverTags.push('+ Overdue remediation');
  }

  if (safeInput.hasActiveCase || safeInput.activeCaseId) {
    rawScore = Math.min(100, rawScore + 10);
  }

  if (recurrenceCount > 0) {
    driverTags.push(`+ ${recurrenceCount} past warning${recurrenceCount > 1 ? 's' : ''}`);
  }

  const score = clampScore(rawScore);
  const weight = COMPONENT_WEIGHTS.history;
  const contribution = Math.round(score * weight);

  return {
    key: 'history',
    code: 'RECURRENCE_HISTORY',
    name: 'Lịch sử thanh tra & tái phạm vi phạm môi trường',
    weight,
    score,
    contribution,
    available: true,
    status: score >= 75 ? 'HIGH_RECURRENCE' : (score >= 50 ? 'MODERATE_RECURRENCE' : 'CLEAN'),
    reasons,
    reason: reasons.join('; '),
    driverTags,
    metrics: {
      recurrenceCount,
      previousClosedThenReopened: Boolean(safeInput.previousClosedThenReopened),
      unresolvedOverdue: Boolean(safeInput.unresolvedOverdue)
    }
  };
}

export const computeInspectionFactor = computeHistorySignal;

/**
 * 5. Sensor Signal (10% weight - Optional)
 * Evaluates objective IoT PM1.0/PM2.5/PM10 readings & Duration IF available and healthy.
 * If sensor is missing, faulty, stale, or inactive -> available: false, score: null.
 */
export function computeSensorSignal(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const reasons = [];
  const driverTags = [];

  const sensors = Array.isArray(safeInput.sensors) 
    ? safeInput.sensors 
    : (safeInput.sensor && typeof safeInput.sensor === 'object' ? [safeInput.sensor] : []);
  const telemetry = safeInput.telemetry && typeof safeInput.telemetry === 'object' 
    ? safeInput.telemetry 
    : (safeInput.sensor && typeof safeInput.sensor === 'object' ? safeInput.sensor : {});
  const hasSensorExplicit = safeInput.hasSensor;
  const hasSensor = hasSensorExplicit !== undefined
    ? Boolean(hasSensorExplicit)
    : (Array.isArray(safeInput.sensors) 
        ? safeInput.sensors.length > 0 
        : (safeInput.currentPm25 !== undefined || safeInput.pm25 !== undefined || Object.keys(telemetry).length > 0));

  let sensorActive = false;
  let sensorFresh = false;
  let flatlineDetected = Boolean(safeInput.isFlatline);

  if (hasSensor) {
    if (sensors.length > 0) {
      sensorActive = sensors.some(s => {
        const st = (s && typeof s.status === 'string') ? s.status.toUpperCase() : '';
        return st === 'ACTIVE' || (!st && s);
      });
      if (sensors.every(s => {
        const st = (s && typeof s.status === 'string') ? s.status.toUpperCase() : '';
        return st === 'FAULTY' || st === 'INACTIVE' || st === 'OFFLINE';
      })) {
        sensorActive = false;
      }
    } else {
      sensorActive = !safeInput.isOffline;
    }

    const lastReadingAt = telemetry.lastReadingAt || safeInput.lastReadingAt;
    if (lastReadingAt) {
      const readingAgeMinutes = (Date.now() - new Date(lastReadingAt).getTime()) / (60 * 1000);
      sensorFresh = Number.isFinite(readingAgeMinutes) && readingAgeMinutes <= 15;
    } else {
      sensorFresh = true;
    }

    // Flatline detection (last 5 readings identical for PM2.5 or PM10 independently)
    if (!flatlineDetected && Array.isArray(telemetry.history) && telemetry.history.length >= 5) {
      const sample = telemetry.history.slice(0, 5);
      const pm25Values = sample.map(h => (h && h.pm25 !== null && h.pm25 !== undefined && h.pm25 !== '' && !Number.isNaN(Number(h.pm25))) ? Number(h.pm25) : null);
      const pm25Flatline = pm25Values.length >= 5 && pm25Values.every(v => v !== null && v === pm25Values[0]);

      const pm10Values = sample.map(h => (h && h.pm10 !== null && h.pm10 !== undefined && h.pm10 !== '' && !Number.isNaN(Number(h.pm10))) ? Number(h.pm10) : null);
      const pm10Flatline = pm10Values.length >= 5 && pm10Values.every(v => v !== null && v === pm10Values[0]);

      if (pm25Flatline || pm10Flatline) {
        flatlineDetected = true;
      }
    }
  }

  // Duration evaluation (in hours)
  const durationHours = typeof safeInput.durationHours === 'number' && Number.isFinite(safeInput.durationHours)
    ? safeInput.durationHours
    : (typeof safeInput.durationMinutes === 'number' && Number.isFinite(safeInput.durationMinutes)
        ? Math.round((safeInput.durationMinutes / 60) * 10) / 10
        : (typeof safeInput.duration === 'number' && Number.isFinite(safeInput.duration)
            ? safeInput.duration
            : (telemetry.consecutiveHours || 0)));

  // If flatline detected -> mark FAULTY and exclude from calculation (Zero-IoT normalization)
  if (flatlineDetected) {
    const flatlineMsg = 'Phát hiện tín hiệu cảm biến bị đóng băng (Flatline - 5 bản ghi trùng nhau) — nghi vấn can thiệp, loại trừ khỏi tính điểm';
    return {
      key: 'sensor',
      code: 'PM_LEVEL',
      name: 'Nồng độ bụi quan trắc IoT (PM2.5 / PM10)',
      weight: COMPONENT_WEIGHTS.sensor,
      available: false,
      score: null,
      contribution: 0,
      status: 'FAULTY_FLATLINE',
      reasons: [flatlineMsg],
      reason: flatlineMsg,
      driverTags: ['+ Flatline detected'],
      metrics: { pm10: null, pm25: null, durationHours: 0 },
      sensorHealth: {
        hasSensor: true,
        active: false,
        fresh: sensorFresh,
        flatlineDetected: true
      }
    };
  }

  // If sensor is absent, faulty, offline, or inactive -> available: false, score: null
  if (!hasSensor || !sensorActive) {
    const errorMsg = !hasSensor 
      ? PRIORITY_COPY.noSensorNote 
      : 'Cảm biến tại khu vực đang bảo trì/lỗi tín hiệu (FAULTY/OFFLINE) — loại trừ khỏi trọng số';
    return {
      key: 'sensor',
      code: 'PM_LEVEL',
      name: 'Nồng độ bụi quan trắc IoT (PM2.5 / PM10)',
      weight: COMPONENT_WEIGHTS.sensor,
      available: false,
      score: null,
      contribution: 0,
      status: 'UNAVAILABLE',
      reasons: [errorMsg],
      reason: errorMsg,
      driverTags: [],
      metrics: { pm10: null, pm25: null, durationHours: 0 },
      sensorHealth: {
        hasSensor: Boolean(hasSensor),
        active: sensorActive,
        fresh: sensorFresh,
        flatlineDetected
      }
    };
  }

  // Extract PM values
  const pm25Raw = safeInput.currentPm25 ?? safeInput.pm25 ?? telemetry.pm25 ?? (sensors[0]?.currentPm25 ?? null);
  const pm10Raw = safeInput.currentPm10 ?? safeInput.pm10 ?? telemetry.pm10 ?? (sensors[0]?.currentPm10 ?? null);

  const pm25 = (typeof pm25Raw === 'number' && Number.isFinite(pm25Raw)) ? pm25Raw : (typeof pm25Raw === 'string' && !isNaN(parseFloat(pm25Raw)) ? parseFloat(pm25Raw) : null);
  const pm10 = (typeof pm10Raw === 'number' && Number.isFinite(pm10Raw)) ? pm10Raw : (typeof pm10Raw === 'string' && !isNaN(parseFloat(pm10Raw)) ? parseFloat(pm10Raw) : null);

  if (pm25 === null && pm10 === null) {
    return {
      key: 'sensor',
      code: 'PM_LEVEL',
      name: 'Nồng độ bụi quan trắc IoT (PM2.5 / PM10)',
      weight: COMPONENT_WEIGHTS.sensor,
      available: false,
      score: null,
      contribution: 0,
      status: 'NO_READINGS',
      reasons: ['Chưa nhận được gói tin dữ liệu quan trắc vi khí hậu'],
      reason: 'Chưa nhận được gói tin dữ liệu quan trắc vi khí hậu',
      driverTags: [],
      metrics: { pm10: null, pm25: null, durationHours: 0 },
      sensorHealth: {
        hasSensor: true,
        active: sensorActive,
        fresh: sensorFresh,
        flatlineDetected
      }
    };
  }

  let sensorScore = 15;
  let status = 'SAFE';
  const val25 = pm25 ?? 0;
  const val10 = pm10 ?? 0;

  if (val25 > 150 || val10 > 300) {
    sensorScore = 100;
    status = 'CRITICAL_EXCEEDED';
    reasons.push(`Nồng độ bụi ${val25 > 150 ? `PM2.5 (${val25} µg/m³)` : `PM10 (${val10} µg/m³)`} vượt ngưỡng cảnh báo đỏ nghiêm trọng`);
  } else if (val25 >= 75 || val10 >= 150) {
    sensorScore = 95;
    status = 'CRITICAL';
    if (val25 >= 75) {
      reasons.push(`Nồng độ bụi PM2.5 (${val25} µg/m³) vượt ngưỡng cảnh báo đỏ QCVN 05:2023 (75 µg/m³)`);
    } else {
      reasons.push(`Nồng độ bụi PM10 (${val10} µg/m³) vượt ngưỡng cảnh báo đỏ QCVN 05:2023 (150 µg/m³)`);
    }
  } else if (val25 >= 50 || val10 >= 100) {
    sensorScore = 75;
    status = 'HIGH';
    reasons.push(`Nồng độ ${val25 >= 50 ? `PM2.5 (${val25} µg/m³)` : `PM10 (${val10} µg/m³)`} ở mức cảnh báo cam`);
  } else if (val25 >= 35 || val10 >= 70) {
    sensorScore = 50;
    status = 'MODERATE';
    reasons.push(`Nồng độ ${val25 >= 35 ? `PM2.5 (${val25} µg/m³)` : `PM10 (${val10} µg/m³)`} ở ngưỡng trung bình`);
  } else if (val25 > 15 || val10 > 30) {
    sensorScore = 20;
    status = 'LOW';
    reasons.push(`Nồng độ PM2.5 (${val25} µg/m³) nằm trong giới hạn an toàn`);
  } else {
    sensorScore = 15;
    status = 'SAFE';
    reasons.push(`Nồng độ PM2.5 (${val25} µg/m³) đạt chuẩn không khí trong lành`);
  }

  // Duration modifier: if persistent exceedance > 1h
  if (durationHours >= 1 && (val25 >= 50 || val10 >= 100 || sensorScore >= 70)) {
    if (durationHours >= 6) {
      sensorScore = Math.min(100, sensorScore + 10);
      reasons.push(`Duy trì nồng độ bụi vượt chuẩn liên tục ${durationHours}h (>6h)`);
    } else if (durationHours >= 3) {
      sensorScore = Math.min(100, sensorScore + 5);
      reasons.push(`Duy trì nồng độ bụi vượt chuẩn liên tục ${durationHours}h`);
    } else {
      reasons.push(`Duy trì nồng độ bụi vượt chuẩn trong ${durationHours}h`);
    }
  }

  // Generate driver tags (e.g. "+ High PM10 (165 µg/m³)", "+ Duy trì 3h")
  if (val10 >= 150) {
    driverTags.push(`+ High PM10 (${val10} µg/m³)`);
  } else if (val25 >= 75) {
    driverTags.push(`+ High PM2.5 (${val25} µg/m³)`);
  } else if (val10 >= 100) {
    driverTags.push(`+ Elevated PM10 (${val10} µg/m³)`);
  } else if (val25 >= 50) {
    driverTags.push(`+ Elevated PM2.5 (${val25} µg/m³)`);
  }

  if (durationHours >= 1 && (val25 >= 50 || val10 >= 100 || sensorScore >= 70)) {
    driverTags.push(`+ Duy trì ${durationHours}h`);
  }

  const score = clampScore(sensorScore);
  const weight = COMPONENT_WEIGHTS.sensor;
  const contribution = Math.round(score * weight);

  return {
    key: 'sensor',
    code: 'PM_LEVEL',
    name: 'Nồng độ bụi quan trắc IoT (PM2.5 / PM10)',
    weight,
    score,
    contribution,
    available: true,
    status,
    reasons,
    reason: reasons.join('; '),
    driverTags,
    metrics: { pm10: val10, pm25: val25, durationHours },
    sensorHealth: {
      hasSensor: true,
      active: sensorActive,
      fresh: sensorFresh,
      flatlineDetected
    }
  };
}

export const computeTelemetryFactor = computeSensorSignal;

/**
 * Main Priority & Risk Scoring Calculation (Canonical SSOT)
 * Calculates explainable, normalized Priority & Risk Score (0-100) with complete domain transparency.
 * 
 * @param {Object} input - Comprehensive site / case context object
 * @returns {Object} Full explainable Priority/Risk output object
 */
export function calculatePriorityScore(input = {}) {
  const safeInput = input && typeof input === 'object' ? input : {};
  const calculatedAt = new Date().toISOString();

  // 1. Compute 5 components
  const community = computeCommunitySignal(safeInput);
  const exposure = computeExposureSignal(safeInput);
  const compliance = computeComplianceSignal(safeInput);
  const history = computeHistorySignal(safeInput);
  const sensor = computeSensorSignal(safeInput);

  const componentList = [community, exposure, compliance, history, sensor];
  const activeComponents = componentList.filter(c => c.available && typeof c.score === 'number' && Number.isFinite(c.score));

  // 2. Normalized Weighted Calculation (Zero-IoT Resilience)
  const totalAvailableWeight = activeComponents.reduce((sum, c) => sum + c.weight, 0);
  const weightedSum = activeComponents.reduce((sum, c) => sum + c.score * c.weight, 0);

  // Normalize component weights and contributions for 100% chart/breakdown accuracy
  if (totalAvailableWeight > 0) {
    activeComponents.forEach(c => {
      const normWeight = c.weight / totalAvailableWeight;
      c.normalizedWeight = Number(normWeight.toFixed(4));
      c.normalizedContribution = Math.round(c.score * normWeight);
    });
  }

  const rawScore = totalAvailableWeight > 0 ? (weightedSum / totalAvailableWeight) : 0;
  const finalScore = clampScore(rawScore, 0, 100);

  // 3. Risk Band & Tier Mapping
  const riskBand = getRiskBand(finalScore);
  const tier = riskBand.key;
  const tierLabel = riskBand.label;
  const tierColor = riskBand.tierColor;
  const level = riskBand.levelText;
  const priorityLevel = riskBand.key;
  const riskLevel = riskBand.key;
  const slaHours = riskBand.slaHours;
  const slaText = riskBand.slaText;

  // 4. Confidence evaluation
  let confidence = 1.0;
  const sensorHealth = sensor.sensorHealth || {
    hasSensor: false,
    active: false,
    fresh: false,
    flatlineDetected: false
  };

  if (!sensorHealth.hasSensor) {
    confidence -= 0.25;
  } else {
    if (!sensorHealth.active) confidence -= 0.30;
    if (!sensorHealth.fresh) confidence -= 0.25;
    if (sensorHealth.flatlineDetected) confidence -= 0.40;
  }
  confidence = Math.max(0.2, Math.min(1.0, Number(confidence.toFixed(2))));

  // 5. Synthesize reasons
  const combinedReasons = [];
  componentList.forEach(c => {
    if (Array.isArray(c.reasons)) {
      c.reasons.forEach(r => combinedReasons.push(r));
    }
  });

  // 6. Synthesize recommended actions
  const recommendedActions = [];
  if (tier === 'CRITICAL') {
    recommendedActions.push('🚨 Khẩn cấp: Cán bộ bố trí kiểm tra hiện trường trong 24h (SLA P1)');
    recommendedActions.push('Kích hoạt cảnh báo tới nhà thầu và yêu cầu giải trình ngay');
    if (exposure.score >= 80) recommendedActions.push('Ưu tiên thiết lập rào chắn bảo vệ trường học / cơ sở y tế tiếp giáp');
  } else if (tier === 'HIGH') {
    recommendedActions.push('⚑ Ưu tiên cao: Bố trí cán bộ kiểm tra hiện trường trong 48h (SLA P2)');
    recommendedActions.push('Ghi nhận và phản hồi thông tin tiếp nhận đến người dân');
    if (compliance.score >= 60) recommendedActions.push('Yêu cầu tăng cường phun nước dập bụi và rửa bánh xe');
  } else if (tier === 'MEDIUM') {
    recommendedActions.push('Theo dõi sát tiến độ khắc phục trong đợt kiểm tra định kỳ 7 ngày (SLA P3)');
  } else {
    recommendedActions.push('Duy trì giám sát định kỳ thông qua dữ liệu cộng đồng');
  }

  // 7. Structured Explanation Drivers (e.g. "+ High PM10 (165 µg/m³)", "+ 3 citizen reports", "+ 220m from school")
  const explanationDrivers = [];
  if (Array.isArray(sensor.driverTags)) sensor.driverTags.forEach(t => explanationDrivers.push(t));
  if (Array.isArray(community.driverTags)) community.driverTags.forEach(t => explanationDrivers.push(t));
  if (Array.isArray(exposure.driverTags)) exposure.driverTags.forEach(t => explanationDrivers.push(t));
  if (Array.isArray(history.driverTags)) history.driverTags.forEach(t => explanationDrivers.push(t));
  if (Array.isArray(compliance.driverTags)) compliance.driverTags.forEach(t => explanationDrivers.push(t));

  // 8. Top Drivers & Explainability Summary
  const topDrivers = [];
  if (sensor.available && sensor.score >= 75) topDrivers.push(`Nồng độ bụi PM2.5/PM10 vượt ngưỡng (${sensor.metrics.pm25 || sensor.metrics.pm10} µg/m³)`);
  if (exposure.score >= 75) topDrivers.push('Tiếp giáp vùng đối tượng nhạy cảm cao');
  if (community.score >= 60) topDrivers.push(`${community.metrics.totalComplaints} phản ánh cộng đồng tập trung`);
  if (compliance.score >= 65) topDrivers.push('Thiếu hụt biện pháp che chắn/dập bụi');
  if (history.score >= 75) topDrivers.push('Có tiền sử tái vi phạm nhiều lần');

  const explainabilitySummary = `Đánh giá mức độ ${riskBand.label} (Điểm: ${finalScore}/100, Độ tin cậy: ${Math.round(confidence * 100)}%). SLA xử lý: ${slaText}. ` +
    (topDrivers.length > 0 ? `Yếu tố chính: ${topDrivers.join('; ')}.` : 'Các chỉ số hiện trường đều trong giới hạn an toàn.');

  const whyScoreX = `Điểm ưu tiên ${finalScore}/100 (${tierLabel}, SLA ${slaText}) do: ` +
    (explanationDrivers.length > 0 ? explanationDrivers.join(', ') : 'Hiện trường an toàn định kỳ.');

  // 9. 6-Factor Structured Domain Object
  const factors = {
    baseSeverity: {
      score: sensor.available ? (sensor.score || 0) : null,
      pm25: sensor.metrics?.pm25 ?? null,
      pm10: sensor.metrics?.pm10 ?? null,
      exceeded: Boolean(sensor.metrics?.pm25 >= 75 || sensor.metrics?.pm10 >= 150),
      driverTag: (sensor.metrics?.pm10 >= 150 ? `+ High PM10 (${sensor.metrics.pm10} µg/m³)` : (sensor.metrics?.pm25 >= 75 ? `+ High PM2.5 (${sensor.metrics.pm25} µg/m³)` : null)),
      status: sensor.status,
      label: 'Nồng độ bụi PM vượt chuẩn'
    },
    duration: {
      hours: sensor.metrics?.durationHours || 0,
      driverTag: (sensor.metrics?.durationHours && sensor.metrics.durationHours >= 1) ? `+ Duy trì ${sensor.metrics.durationHours}h` : null,
      label: 'Thời gian duy trì nồng độ cao'
    },
    sensorConfidence: {
      confidence,
      percentage: Math.round(confidence * 100),
      status: sensorHealth.active ? (sensorHealth.fresh ? 'HEALTHY' : 'STALE') : (sensorHealth.hasSensor ? 'FAULTY' : 'ZERO_IOT'),
      label: 'Độ tin cậy cảm biến IoT'
    },
    sensitiveProximity: {
      score: exposure.score,
      nearestDistance: exposure.metrics?.nearestDistance ?? null,
      nearestType: exposure.metrics?.nearestType ?? null,
      nearestName: exposure.metrics?.nearestName ?? null,
      isUnder300m: Boolean(exposure.metrics?.isUnder300m),
      driverTag: exposure.driverTags?.[0] || null,
      label: 'Khoảng cách công trình nhạy cảm (<300m)'
    },
    citizenCorroboration: {
      score: community.score,
      totalComplaints: community.metrics?.totalComplaints || 0,
      independentReporters: community.metrics?.independentReporters || 0,
      hasSpamDeduction: Boolean(community.metrics?.hasSpamDeduction),
      driverTag: community.driverTags?.[0] || null,
      label: 'Số lượng ghi nhận thực tế từ cộng đồng'
    },
    historicalRecurrence: {
      score: history.score,
      recurrenceCount: history.metrics?.recurrenceCount || 0,
      previousClosedThenReopened: history.metrics?.previousClosedThenReopened || false,
      unresolvedOverdue: history.metrics?.unresolvedOverdue || false,
      driverTag: history.driverTags?.[0] || null,
      label: 'Tần suất lặp lại & Lịch sử vi phạm'
    }
  };

  // 10. Hybrid Components Array/Object for 100% interoperability
  const components = [community, exposure, compliance, history, sensor];
  components.community = community;
  components.exposure = exposure;
  components.compliance = compliance;
  components.evidence = compliance;
  components.history = history;
  components.sensor = sensor;
  components.telemetry = sensor;
  components.complaints = community;
  components.inspection = history;

  const breakdown = {
    community: community.score,
    exposure: exposure.score,
    compliance: compliance.score,
    evidence: compliance.score,
    history: history.score,
    sensor: sensor.score || 0,
    telemetry: sensor,
    complaints: community,
    inspection: history,
    complianceDeficit: compliance.score,
    complaintSignal: community.score,
    recurrence: history.score,
    sensorSignal: sensor.score || 0
  };

  return {
    score: finalScore,
    priorityScore: finalScore,
    riskScore: finalScore,
    dustRiskScore: finalScore,
    tier,
    tierLabel,
    tierColor,
    priorityTier: tierColor,
    level,
    priorityLevel,
    riskLevel,
    riskBand,
    slaHours,
    slaText,
    confidence,
    sensorHealth,
    components,
    breakdown,
    factors,
    explanationDrivers,
    whyScoreX,
    explainabilitySummary,
    reasons: combinedReasons,
    recommendedActions,
    calculatedAt,
    engineVersion: DUST_RISK_ENGINE_VERSION,
    scoreVersion: PRIORITY_ENGINE_VERSION,
    disclaimer: PRIORITY_COPY.disclaimer
  };
}

export class DustRiskEngine {
  static calculate(input = {}) {
    return calculatePriorityScore(input);
  }
}

export const calculateRiskScore = calculatePriorityScore;
export const calculateCpsRisk = calculatePriorityScore;

