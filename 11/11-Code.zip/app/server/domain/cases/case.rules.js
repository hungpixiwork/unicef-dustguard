/**
 * DustGuard Domain Rules: Environmental Agency 7-Step Case Lifecycle
 * DDD Domain Layer - Independent of HTTP, Express, Hono, or Database
 */

export const CASE_STATUS = {
  SCREENING: 'SCREENING',
  PREPARING: 'PREPARING',
  DECISION_ISSUED: 'DECISION_ISSUED',
  ON_SITE: 'ON_SITE',
  REPORTING: 'REPORTING',
  APPRAISING: 'APPRAISING',
  COMPLETED: 'COMPLETED'
};

export const STEP_METADATA = {
  SCREENING: { step: 1, name: 'Tiếp nhận', roleRequired: ['staff', 'admin'] },
  PREPARING: { step: 2, name: 'Xác minh', roleRequired: ['staff', 'admin'] },
  DECISION_ISSUED: { step: 3, name: 'Thông báo', roleRequired: ['staff', 'executive', 'admin'] },
  ON_SITE: { step: 4, name: 'Khảo sát', roleRequired: ['staff', 'admin'] },
  REPORTING: { step: 5, name: 'Đề xuất', roleRequired: ['staff', 'admin'] },
  APPRAISING: { step: 6, name: 'Thẩm định', roleRequired: ['staff', 'executive', 'admin'] },
  COMPLETED: { step: 7, name: 'Hoàn tất', roleRequired: ['staff', 'executive', 'admin'] }
};

// Valid status transition map (logical DAG of the Case Lifecycle)
// 1. SCREENING -> 2. PREPARING -> 3. DECISION_ISSUED -> 4. ON_SITE -> 5. REPORTING -> 6. APPRAISING -> 7. COMPLETED
const VALID_CASE_TRANSITIONS = {
  SCREENING: ['PREPARING', 'COMPLETED'],
  PREPARING: ['DECISION_ISSUED', 'COMPLETED'],
  DECISION_ISSUED: ['ON_SITE', 'COMPLETED'],
  ON_SITE: ['REPORTING', 'COMPLETED'],
  REPORTING: ['APPRAISING', 'COMPLETED'],
  APPRAISING: ['COMPLETED'],
  COMPLETED: [] // Terminal: closed/archived
};

export const REQUIRED_DOCUMENTS = {
  'ON_SITE->REPORTING': 'Biên bản kiểm tra hiện trường hoặc minh chứng thực địa (VERIFIED_EVIDENCE)',
  'REPORTING->APPRAISING': 'Dự thảo quyết định xử phạt hoặc mức tiền phạt đề xuất',
  'APPRAISING->COMPLETED': 'Chữ ký số phê duyệt của Lãnh đạo hoặc chứng từ nộp phạt / khắc phục'
};

/**
 * Normalizes case status from legacy/alternative forms to the strict lifecycle states.
 * @param {string} status - Case status string
 * @returns {string} Normalized status
 */
export function normalizeStatus(status) {
  if (!status) return CASE_STATUS.SCREENING;
  const upper = String(status).trim().toUpperCase();
  if (upper === 'PENDING' || upper === 'OPEN' || upper === 'SCREENING' || upper === 'NEW') return CASE_STATUS.SCREENING;
  if (upper === 'PROCESSING' || upper === 'PREPARING' || upper === 'PREPARE' || upper === 'VERIFICATION') return CASE_STATUS.PREPARING;
  if (upper === 'DECISION_ISSUED' || upper === 'DECISION') return CASE_STATUS.DECISION_ISSUED;
  if (upper === 'VIOLATED' || upper === 'EXPLAINING' || upper === 'ON_SITE' || upper === 'INSPECTION' || upper === 'EXPLANATION_REQUESTED' || upper === 'EXPLANATION_SUBMITTED' || upper === 'EXPLAINED') return CASE_STATUS.ON_SITE;
  if (upper === 'SANCTIONED' || upper === 'REPORTING' || upper === 'DRAFT_REPORT' || upper === 'SANCTIONING' || upper === 'SANCTION_ISSUED') return CASE_STATUS.REPORTING;
  if (upper === 'RECTIFYING' || upper === 'APPRAISING' || upper === 'REVIEWING') return CASE_STATUS.APPRAISING;
  if (upper === 'COMPLETED' || upper === 'CLOSED' || upper === 'ARCHIVED') return CASE_STATUS.COMPLETED;
  return upper;
}

/**
 * Validates whether a state transition is allowed in the lifecycle DAG.
 * @param {string} currentStatus - Current case status
 * @param {string} nextStatus - Desired next case status
 * @returns {boolean} True if transition is valid, false otherwise
 */
export function isValidTransition(currentStatus, nextStatus) {
  if (!currentStatus || !nextStatus) return false;
  const current = normalizeStatus(currentStatus);
  const next = normalizeStatus(nextStatus);

  if (current === next) return true; // Self-transition is a no-op
  
  const allowed = VALID_CASE_TRANSITIONS[current];
  if (!allowed) return false;
  return allowed.includes(next);
}

/**
 * Validates required documents or evidence for a step transition.
 * @param {string} currentStatus 
 * @param {string} nextStatus 
 * @param {Object} context - Evidence and document context
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateStepRequirements(currentStatus, nextStatus, context = {}) {
  const current = normalizeStatus(currentStatus);
  const next = normalizeStatus(nextStatus);
  const transitionKey = `${current}->${next}`;

  if (transitionKey === 'ON_SITE->REPORTING') {
    const hasReport = context.hasInspectionReport || context.inspectionId || context.hasEvidence || (Array.isArray(context.evidences) && context.evidences.length > 0) || context.findings || context.note;
    if (!hasReport) {
      return {
        valid: false,
        error: `Yêu cầu biên bản kiểm tra hiện trường hoặc minh chứng thực địa trước khi chuyển sang bước Báo cáo xử phạt (${next}).`
      };
    }
  }

  if (transitionKey === 'REPORTING->APPRAISING') {
    const hasSanctionDetails = context.penaltyAmount !== undefined || context.decisionNumber || context.remedialMeasures || context.hasDecision || context.note;
    if (!hasSanctionDetails) {
      return {
        valid: false,
        error: `Yêu cầu thông tin xử phạt / biện pháp khắc phục trước khi chuyển sang bước Thẩm định (${next}).`
      };
    }
  }

  return { valid: true };
}

/**
 * Validates case state transitions with role and authority guards:
 * - Valid transition in 7-step process
 * - Role permission validation (staff/executive/admin)
 * - Anti-tampering guards on COMPLETED records
 * 
 * @param {string} currentStatus 
 * @param {string} nextStatus 
 * @param {Object} [options]
 * @param {string} [options.role]
 * @param {string} [options.reason]
 * @param {Object} [options.context]
 * @throws {Error} if invalid
 * @returns {boolean} true
 */
export function validateCaseTransition(currentStatus, nextStatus, options = {}) {
  const current = normalizeStatus(currentStatus);
  const next = normalizeStatus(nextStatus);

  if (!current || !next) {
    throw new Error('Trạng thái hiện tại và trạng thái đích không được để trống.');
  }

  if (current === next) {
    return true;
  }

  // Guard 1: Terminal COMPLETED state
  if (current === CASE_STATUS.COMPLETED) {
    const isAdmin = options.role === 'admin' || options.role === 'demo_admin';
    if (!isAdmin || !options.reason) {
      throw new Error(`Khong the chuyen trang thai vu viec da dong (COMPLETED). Chi Admin moi co quyen mo lai kem ly do.`);
    }
    // Authorized admin reopen
    return true;
  }

  // Guard 2: Role check
  if (options.role) {
    const roleLower = String(options.role).toLowerCase();
    const authorizedRoles = ['staff', 'inspector', 'executive', 'admin', 'demo_admin', 'system'];
    if (!authorizedRoles.includes(roleLower)) {
      throw new Error(`Nha thau hoac Cong dan khong co tham quyen chuyen buoc quy trinh vu viec. Yeu cau can bo Thanh tra / Lanh dao.`);
    }
  }

  // Guard 3: DAG transition validity
  if (!isValidTransition(current, next)) {
    throw new Error(`Invalid status transition from ${currentStatus} (${current}) to ${nextStatus} (${next})`);
  }

  // Guard 4: Step requirements
  if (options.context) {
    const reqCheck = validateStepRequirements(current, next, options.context);
    if (!reqCheck.valid) {
      throw new Error(reqCheck.error);
    }
  }

  return true;
}

/**
 * Derives the workflow 7-step number and label strictly from case status
 * @param {string} status 
 * @returns {{ step: number, label: string, stepKey: string, desc: string }}
 */
export function deriveWorkflowStep(status) {
  const norm = normalizeStatus(status);
  switch (norm) {
    case CASE_STATUS.SCREENING:
      return { step: 1, label: '1. Tiếp nhận', stepKey: 'SCREENING', desc: 'Ghi nhận phản ánh & cảm biến' };
    case CASE_STATUS.PREPARING:
      return { step: 2, label: '2. Xác minh', stepKey: 'PREPARING', desc: 'Kiểm tra tọa độ & hình ảnh' };
    case CASE_STATUS.DECISION_ISSUED:
      return { step: 3, label: '3. Thông báo', stepKey: 'DECISION_ISSUED', desc: 'Gửi yêu cầu tới nhà thầu' };
    case CASE_STATUS.ON_SITE:
      return { step: 4, label: '4. Khảo sát', stepKey: 'ON_SITE', desc: 'Đoàn thanh tra kiểm tra thực địa' };
    case CASE_STATUS.REPORTING:
      return { step: 5, label: '5. Đề xuất', stepKey: 'REPORTING', desc: 'Lập phương án khắc phục & xử lý' };
    case CASE_STATUS.APPRAISING:
      return { step: 6, label: '6. Thẩm định', stepKey: 'APPRAISING', desc: 'Đối chứng Before/After nghiệm thu' };
    case CASE_STATUS.COMPLETED:
      return { step: 7, label: '7. Hoàn tất', stepKey: 'COMPLETED', desc: 'Đóng hồ sơ & lưu trữ pháp lý' };
    default:
      return { step: 1, label: '1. Tiếp nhận', stepKey: 'SCREENING', desc: 'Ghi nhận hồ sơ' };
  }
}

/**
 * Generates the domain-driven next action object for a case
 * @param {Object} caseItem 
 * @returns {{ type: string, label: string, actorRole: string, assigneeId: string|null, dueAt: string|null, route: string, urgency: string }}
 */
export function getNextAction(caseItem) {
  if (!caseItem) {
    return {
      type: 'assign_staff',
      label: 'Phân công cán bộ xử lý',
      actorRole: 'admin',
      assigneeId: null,
      dueAt: null,
      route: '/staff/cases',
      urgency: 'high'
    };
  }

  const norm = normalizeStatus(caseItem.status);
  const assigneeId = caseItem.assignedTo || null;
  const deadline = caseItem.slaDeadline || null;

  if (norm === CASE_STATUS.COMPLETED) {
    return {
      type: 'none',
      label: 'Hồ sơ đã hoàn tất và lưu trữ',
      actorRole: 'public',
      assigneeId,
      dueAt: null,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'low'
    };
  }

  if (norm === CASE_STATUS.SCREENING || !assigneeId) {
    return {
      type: 'assign_staff',
      label: 'Phân công cán bộ phụ trách hồ sơ',
      actorRole: 'admin',
      assigneeId: null,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'high'
    };
  }

  if (norm === CASE_STATUS.PREPARING) {
    return {
      type: 'inspection_required',
      label: 'Khảo sát thực địa và kiểm tra 10 tiêu chí',
      actorRole: 'staff',
      assigneeId,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'high'
    };
  }

  if (norm === CASE_STATUS.DECISION_ISSUED) {
    return {
      type: 'assign_contractor',
      label: 'Gửi biên bản yêu cầu nhà thầu khắc phục',
      actorRole: 'staff',
      assigneeId,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'medium'
    };
  }

  if (norm === CASE_STATUS.ON_SITE) {
    return {
      type: 'submit_inspection',
      label: 'Hoàn tất biên bản kiểm tra & nộp minh chứng',
      actorRole: 'staff',
      assigneeId,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'high'
    };
  }

  if (norm === CASE_STATUS.REPORTING) {
    return {
      type: 'await_contractor',
      label: 'Chờ nhà thầu nộp ảnh Before/After và giải trình',
      actorRole: 'contractor',
      assigneeId,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'medium'
    };
  }

  if (norm === CASE_STATUS.APPRAISING) {
    return {
      type: 'verification_required',
      label: 'Tái kiểm thực địa & nghiệm thu kết quả khắc phục',
      actorRole: 'staff',
      assigneeId,
      dueAt: deadline,
      route: `/staff/cases/${caseItem.id || caseItem.code}`,
      urgency: 'high'
    };
  }

  return {
    type: 'inspection_required',
    label: 'Kiểm tra hiện trường & đối chứng kết quả',
    actorRole: 'staff',
    assigneeId,
    dueAt: deadline,
    route: `/staff/cases/${caseItem.id || caseItem.code}`,
    urgency: 'medium'
  };
}
