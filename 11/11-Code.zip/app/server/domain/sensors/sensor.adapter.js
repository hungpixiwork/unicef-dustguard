/**
 * DustGuard VN - Sensor Hardware Adapter & Ingestion Normalizer
 * 
 * Supports protocol normalization for:
 * 1. ESP32 Standard HTTP JSON Payload
 * 2. Pipe-delimited serial / raw telemetry string
 * 3. LoRaWAN hex / Base64 binary payload decoder
 * 4. Modbus RTU / RS485 industrial sensor register mapping
 * 
 * Invariants:
 * - Zero-Fake Hardware Fields: Hardware unsupported channels must remain null.
 * - Deterministic parsing & validation via sensor.rules.js and data-quality.engine.js.
 */

import {
  HARDWARE_PROFILES,
  SENSOR_DEVICE_TYPES,
  MEASUREMENT_PHYSICAL_BOUNDS,
  sanitizeEnvironmentalMeasurements
} from './sensor.rules.js';
import { calculateHmacSha256, buildCanonicalMessage } from '../../auth/device/hmac.js';

export class SensorAdapter {
  /**
   * 1. Normalizes standard ESP32 / HTTP JSON payload.
   * @param {Object} rawPayload
   * @param {string} [hardwareProfile='DUSTGUARD_SOLAR_V1']
   * @returns {{
   *   sensorCode: string,
   *   measurements: { pm1: number|null, pm25: number|null, pm10: number|null, temp: number|null, humidity: number|null },
   *   timestamp: string,
   *   sequenceNumber: number|null,
   *   signature?: string,
   *   nonce?: string,
   *   deviceType?: string,
   *   isExperimental: boolean
   * }}
   */
  static parseHttpJson(rawPayload = {}, hardwareProfile = 'DUSTGUARD_SOLAR_V1') {
    const sensorCode = (rawPayload.sensorCode || rawPayload.deviceId || rawPayload.code || '').trim();
    const { sanitized, violations } = sanitizeEnvironmentalMeasurements(rawPayload, hardwareProfile);

    return {
      sensorCode,
      measurements: {
        pm1: sanitized.pm1,
        pm25: sanitized.pm25,
        pm10: sanitized.pm10,
        temp: sanitized.temp,
        humidity: sanitized.humidity
      },
      timestamp: sanitized.timestamp.toISOString(),
      sequenceNumber: sanitized.sequenceNumber,
      signature: rawPayload.signature || null,
      nonce: rawPayload.nonce || null,
      deviceType: rawPayload.deviceType || SENSOR_DEVICE_TYPES.SOLAR_POLE.code,
      isExperimental: Boolean(rawPayload.isExperimental || rawPayload.tag === 'EXPERIMENTAL' || rawPayload.tier === 'EXPERIMENTAL'),
      violations
    };
  }

  /**
   * 2. Parses pipe-delimited serial telemetry string.
   * Format: `sensorCode|pm10|pm25|timestamp` or `sensorCode|pm1|pm25|pm10|temp|humidity|timestamp|seq`
   * @param {string} rawString
   * @param {string} [hardwareProfile='DUSTGUARD_SOLAR_V1']
   * @returns {Object}
   */
  static parsePipeDelimited(rawString = '', hardwareProfile = 'DUSTGUARD_SOLAR_V1') {
    if (!rawString || typeof rawString !== 'string') {
      throw new Error('Invalid pipe-delimited string payload');
    }

    const tokens = rawString.trim().split('|');
    if (tokens.length < 4) {
      throw new Error(`Insufficient tokens in pipe payload: expected at least 4, got ${tokens.length}`);
    }

    const sensorCode = tokens[0].trim();
    let pm10 = null, pm25 = null, pm1 = null, temp = null, humidity = null, timestamp = new Date().toISOString(), seq = null;

    const parseSafeFloat = (str) => {
      if (str === undefined || str === null || str === '') return null;
      const num = parseFloat(str);
      return Number.isNaN(num) ? null : num;
    };
    const parseSafeInt = (str) => {
      if (str === undefined || str === null || str === '') return null;
      const num = parseInt(str, 10);
      return Number.isNaN(num) ? null : num;
    };

    if (tokens.length === 4) {
      // Standard 4-tuple: sensorCode|pm10|pm25|timestamp
      pm10 = parseSafeFloat(tokens[1]);
      pm25 = parseSafeFloat(tokens[2]);
      timestamp = tokens[3].trim();
    } else if (tokens.length >= 7) {
      // Extended tuple: sensorCode|pm1|pm25|pm10|temp|humidity|timestamp(|seq)
      pm1 = parseSafeFloat(tokens[1]);
      pm25 = parseSafeFloat(tokens[2]);
      pm10 = parseSafeFloat(tokens[3]);
      temp = parseSafeFloat(tokens[4]);
      humidity = parseSafeFloat(tokens[5]);
      timestamp = tokens[6].trim();
      if (tokens.length >= 8) {
        seq = parseSafeInt(tokens[7]);
      }
    } else {
      pm10 = parseSafeFloat(tokens[1]);
      pm25 = parseSafeFloat(tokens[2]);
      timestamp = tokens[tokens.length - 1].trim();
    }

    return this.parseHttpJson({
      sensorCode,
      pm1,
      pm25,
      pm10,
      temp,
      humidity,
      timestamp,
      seq
    }, hardwareProfile);
  }

  /**
   * 3. Decodes binary LoRaWAN payload (Cayenne LPP or custom DustGuard packing).
   * Custom DustGuard binary buffer:
   * [0..1]: PM2.5 (uint16 big-endian, scale 0.1)
   * [2..3]: PM10 (uint16 big-endian, scale 0.1)
   * [4..5]: Temp (int16 big-endian, scale 0.1)
   * [6..7]: Humidity (uint16 big-endian, scale 0.1)
   * [8..9]: Sequence (uint16 big-endian)
   * 
   * @param {string|Buffer} hexOrBase64
   * @param {string} sensorCode
   * @param {string} [hardwareProfile='DUSTGUARD_SOLAR_V1']
   * @returns {Object}
   */
  static parseLoRaWanBinary(hexOrBase64, sensorCode, hardwareProfile = 'DUSTGUARD_SOLAR_V1') {
    let buffer;
    if (Buffer.isBuffer(hexOrBase64)) {
      buffer = hexOrBase64;
    } else if (typeof hexOrBase64 === 'string') {
      const clean = hexOrBase64.trim();
      if (/^[0-9a-fA-F]+$/.test(clean)) {
        buffer = Buffer.from(clean, 'hex');
      } else {
        buffer = Buffer.from(clean, 'base64');
      }
    } else {
      throw new Error('Unsupported LoRaWAN payload format');
    }

    if (buffer.length < 4) {
      throw new Error('LoRaWAN packet too short (minimum 4 bytes required for PM2.5 & PM10)');
    }

    const pm25Raw = buffer.readUInt16BE(0);
    const pm10Raw = buffer.readUInt16BE(2);
    const pm25 = parseFloat((pm25Raw / 10.0).toFixed(1));
    const pm10 = parseFloat((pm10Raw / 10.0).toFixed(1));

    let temp = null;
    let humidity = null;
    let seq = null;

    if (buffer.length >= 8) {
      const tempRaw = buffer.readInt16BE(4);
      const humRaw = buffer.readUInt16BE(6);
      temp = parseFloat((tempRaw / 10.0).toFixed(1));
      humidity = parseFloat((humRaw / 10.0).toFixed(1));
    }

    if (buffer.length >= 10) {
      seq = buffer.readUInt16BE(8);
    }

    return this.parseHttpJson({
      sensorCode,
      pm25,
      pm10,
      temp,
      humidity,
      seq,
      timestamp: new Date().toISOString()
    }, hardwareProfile);
  }

  /**
   * Helper to sign an outgoing hardware telemetry packet with pre-shared key (PSK).
   * @param {Object} payload - { sensorCode, pm10, pm25, timestamp, nonce, seq }
   * @param {string} secretKey
   * @returns {string} HMAC-SHA256 hex signature
   */
  static signTelemetryPayload(payload, secretKey) {
    const msg = buildCanonicalMessage(
      payload.sensorCode,
      payload.pm10,
      payload.pm25,
      payload.timestamp,
      payload.nonce
    );
    return calculateHmacSha256(msg, secretKey, 'hex');
  }
}
