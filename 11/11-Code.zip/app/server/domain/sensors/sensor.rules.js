/**
 * DustGuard VN - IoT Sensor Domain Rules, Enums & Hardware Capability Profiles (SSOT)
 * 
 * Invariants:
 * 1. D1 is SSOT for persistent sensor registration and telemetry histories.
 * 2. Zero-Fake Hardware Fields: Metrics unsupported by the sensor's hardware profile must remain null.
 * 3. Experimental Tagging: Experimental sensors (EXPERIMENTAL/FIELD_TRIAL) are excluded from automated legal enforcement.
 * 4. Comprehensive Health & Calibration State Machines.
 */

// 1. Device Types SSOT
export const SENSOR_DEVICE_TYPES = {
  SOLAR_POLE: {
    code: 'SOLAR_POLE',
    name: 'Trạm quan trắc năng lượng mặt trời',
    description: 'Trạm cố định sử dụng pin mặt trời + 4G/LTE, triển khai tại rào ngoài công trường.',
    typicalMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity']
  },
  MAST_STATION: {
    code: 'MAST_STATION',
    name: 'Cột quan trắc cao cố định',
    description: 'Cột mast cao 6m tích hợp cảm biến bụi quang học, hướng gió và vi khí hậu.',
    typicalMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity']
  },
  HANDHELD: {
    code: 'HANDHELD',
    name: 'Thiết bị quan trắc cầm tay',
    description: 'Thiết bị di động gọn nhẹ phục vụ khảo sát nhanh của thanh niên / tình nguyện viên.',
    typicalMetrics: ['pm25', 'pm10', 'temp', 'humidity']
  },
  SUSPENDED_POD: {
    code: 'SUSPENDED_POD',
    name: 'Hộp cảm biến treo rào / cổng phụ',
    description: 'Thiết bị treo rào bảo vệ, cấp nguồn AC/DC hoặc pin dự phòng 7 ngày.',
    typicalMetrics: ['pm25', 'pm10']
  },
  KIOSK_SOLO: {
    code: 'KIOSK_SOLO',
    name: 'Trạm Kiosk hiển thị công cộng',
    description: 'Trạm kiosk tích hợp bảng LED hiển thị nồng độ bụi công khai cho người dân.',
    typicalMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity']
  },
  MOBILE_NODE: {
    code: 'MOBILE_NODE',
    name: 'Thiết bị gắn phương tiện tuần tra',
    description: 'Thiết bị gắn trên xe tuần tra hoặc drone có GPS động.',
    typicalMetrics: ['pm25', 'pm10', 'temp', 'humidity']
  }
};

// 2. Calibration Status SSOT
export const SENSOR_CALIBRATION_STATUS = {
  CALIBRATED: {
    code: 'CALIBRATED',
    label: 'Đã hiệu chuẩn',
    description: 'Đã được hiệu chuẩn phòng thí nghiệm/đối chuẩn hiện trường trong vòng 180 ngày.',
    confidenceFactor: 1.0,
    allowsLegalDossier: true
  },
  PENDING_CALIBRATION: {
    code: 'PENDING_CALIBRATION',
    label: 'Chờ hiệu chuẩn định kỳ',
    description: 'Sắp hết hạn hiệu chuẩn (150-180 ngày), cần bố trí tái kiểm tra.',
    confidenceFactor: 0.85,
    allowsLegalDossier: true
  },
  EXPIRED: {
    code: 'EXPIRED',
    label: 'Hiệu chuẩn hết hạn',
    description: 'Đã quá 180 ngày chưa hiệu chuẩn, chỉ số có thể bị trôi (zero-drift).',
    confidenceFactor: 0.60,
    allowsLegalDossier: false
  },
  UNCALIBRATED: {
    code: 'UNCALIBRATED',
    label: 'Chưa hiệu chuẩn',
    description: 'Thiết bị mới lắp đặt hoặc tự chế, chỉ dùng để định tính cảnh báo sớm.',
    confidenceFactor: 0.40,
    allowsLegalDossier: false
  }
};

// 3. Sensor Health Status SSOT
export const SENSOR_HEALTH_STATUS = {
  HEALTHY: {
    code: 'HEALTHY',
    label: 'Khỏe mạnh (Healthy)',
    color: 'green',
    description: 'Hoạt động bình thường, heartbeat đều đặn, dữ liệu không lỗi.'
  },
  DEGRADED: {
    code: 'DEGRADED',
    label: 'Suy giảm tín hiệu (Degraded)',
    color: 'amber',
    description: 'Pin yếu, mất một vài gói tin liên lạc, hoặc một kênh đo phụ bị lỗi.'
  },
  CRITICAL: {
    code: 'CRITICAL',
    label: 'Cảnh báo nghiêm trọng (Critical)',
    color: 'red',
    description: 'Dữ liệu bất thường liên tục, nghi vấn nhảy vọt (sudden jump) hoặc ngoài giới hạn.'
  },
  OFFLINE: {
    code: 'OFFLINE',
    label: 'Mất kết nối (Offline)',
    color: 'gray',
    description: 'Không nhận được heartbeat hoặc số đo trong hơn 15 phút (Liveness Timeout).'
  },
  FAULTY: {
    code: 'FAULTY',
    label: 'Hỏng hóc / Đóng băng (Faulty)',
    color: 'red',
    description: 'Phát hiện tín hiệu flatline (đóng băng ADC) hoặc nghi vấn bị che chắn/can thiệp.'
  }
};

// 4. Sensor Deployment Tier / Experimental Tag SSOT
export const SENSOR_TIERS = {
  PRODUCTION: {
    code: 'PRODUCTION',
    label: 'Sản xuất & Vận hành chính thức',
    isExperimental: false,
    description: 'Thiết bị đạt chuẩn, hỗ trợ xuất biên bản hành chính và kích hoạt SLA pháp lý.'
  },
  FIELD_TRIAL: {
    code: 'FIELD_TRIAL',
    label: 'Thử nghiệm thực địa có giám sát',
    isExperimental: false,
    description: 'Đang trong giai đoạn đánh giá độ ổn định 30 ngày tại công trường.'
  },
  EXPERIMENTAL: {
    code: 'EXPERIMENTAL',
    label: 'Thí nghiệm / Nghiên cứu mở rộng',
    isExperimental: true,
    description: 'Mẫu phần cứng thử nghiệm hoặc dự án thanh niên. Không kích hoạt xử phạt tự động.'
  },
  BENCHMARK: {
    code: 'BENCHMARK',
    label: 'Trạm chuẩn đối chứng chất lượng',
    isExperimental: false,
    description: 'Trạm tham chiếu cao cấp dùng để đối sánh và hiệu chỉnh chéo mạng lưới.'
  }
};

// 5. Hardware Capability Profiles SSOT
export const HARDWARE_PROFILES = {
  'PLANTOWER_PMS5003_DHT22': {
    code: 'PLANTOWER_PMS5003_DHT22',
    name: 'Plantower PMS5003 + DHT22 Combo',
    supportedMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity'],
    precision: { pm1: 1, pm25: 1, pm10: 1, temp: 1, humidity: 1 },
    sampleIntervalSec: 60
  },
  'SENSIRION_SPS30_SHT35': {
    code: 'SENSIRION_SPS30_SHT35',
    name: 'Sensirion SPS30 Laser + SHT35 Precision',
    supportedMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity'],
    precision: { pm1: 1, pm25: 1, pm10: 1, temp: 2, humidity: 2 },
    sampleIntervalSec: 30
  },
  'BASIC_OPTICAL_PM': {
    code: 'BASIC_OPTICAL_PM',
    name: 'Basic Optical Dust Sensor (PM2.5 / PM10 only)',
    supportedMetrics: ['pm25', 'pm10'], // PM1, Temp, Humidity NOT supported -> MUST REMAIN NULL
    precision: { pm25: 1, pm10: 1 },
    sampleIntervalSec: 60
  },
  'DUSTGUARD_SOLAR_V1': {
    code: 'DUSTGUARD_SOLAR_V1',
    name: 'DustGuard Solar Station V1 (ESP32 + PMS7003 + BME280)',
    supportedMetrics: ['pm1', 'pm25', 'pm10', 'temp', 'humidity'],
    precision: { pm1: 1, pm25: 1, pm10: 1, temp: 1, humidity: 1 },
    sampleIntervalSec: 60
  }
};

// 6. Physical Measurement Boundaries & Quality Thresholds
export const MEASUREMENT_PHYSICAL_BOUNDS = {
  pm1: { min: 0, max: 1000, unit: 'µg/m³', name: 'Bụi siêu mịn PM1.0' },
  pm25: { min: 0, max: 2500, unit: 'µg/m³', name: 'Bụi mịn PM2.5' },
  pm10: { min: 0, max: 2500, unit: 'µg/m³', name: 'Bụi thô PM10' },
  temp: { min: -20, max: 70, unit: '°C', name: 'Nhiệt độ môi trường' },
  humidity: { min: 0, max: 100, unit: '%', name: 'Độ ẩm không khí' }
};

export const DATA_QUALITY_THRESHOLDS = {
  MAX_DRIFT_MS: 5 * 60 * 1000,          // 5 minutes max clock drift
  STALE_TIMEOUT_MS: 15 * 60 * 1000,      // 15 minutes without readings = STALE / OFFLINE
  DATA_GAP_THRESHOLD_MS: 10 * 60 * 1000, // 10 minutes gap between consecutive readings
  FLATLINE_CONSECUTIVE_COUNT: 5,        // 5 consecutive identical readings = FLATLINE
  FLATLINE_MIN_SPAN_MS: 10 * 60 * 1000,  // Minimum 10 minutes duration for flatline confirmation
  MAX_SUDDEN_JUMP_PM25_PER_SEC: 25.0,    // Max realistic change in PM2.5 per second (250 µg/m³ in 10s)
  MAX_SUDDEN_JUMP_PM10_PER_SEC: 40.0,    // Max realistic change in PM10 per second
  MAX_SUDDEN_JUMP_TEMP_PER_SEC: 1.0      // Max realistic change in Temp per second
};

/**
 * Validates sensor registration / creation input.
 * @param {Object} input
 * @returns {{ isValid: boolean, errors: string[], sanitized: Object }}
 */
export function validateSensorRegistryInput(input = {}) {
  const errors = [];
  if (!input || typeof input !== 'object') {
    return { isValid: false, errors: ['Dữ liệu cấu hình cảm biến không hợp lệ'], sanitized: null };
  }

  const code = (input.code || input.sensorCode || '').trim();
  if (!code) {
    errors.push('Mã cảm biến (code) là bắt buộc');
  } else if (!/^[A-Za-z0-9_-]{3,50}$/.test(code)) {
    errors.push('Mã cảm biến chỉ được chứa chữ cái, số, gạch ngang và gạch dưới (3-50 ký tự)');
  }

  const name = (input.name || input.sensorName || '').trim();
  if (!name) {
    errors.push('Tên cảm biến là bắt buộc');
  }

  const siteId = (input.siteId || '').trim();
  if (!siteId) {
    errors.push('ID công trường / địa điểm liên kết (siteId) là bắt buộc');
  }

  const rawDeviceType = input.deviceType || input.device_type || 'SOLAR_POLE';
  const deviceType = SENSOR_DEVICE_TYPES[rawDeviceType]?.code || 'SOLAR_POLE';

  const rawCalibration = input.calibrationStatus || input.calibration_status || 'CALIBRATED';
  const calibrationStatus = SENSOR_CALIBRATION_STATUS[rawCalibration]?.code || 'CALIBRATED';

  const rawTier = input.tier || input.tag || (input.isExperimental ? 'EXPERIMENTAL' : 'PRODUCTION');
  const tier = SENSOR_TIERS[rawTier]?.code || 'PRODUCTION';

  const rawHardwareProfile = input.hardwareProfile || input.model || 'DUSTGUARD_SOLAR_V1';
  const hardwareProfile = HARDWARE_PROFILES[rawHardwareProfile]?.code || 'DUSTGUARD_SOLAR_V1';

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: {
      code,
      name,
      siteId,
      deviceType,
      calibrationStatus,
      tier,
      isExperimental: SENSOR_TIERS[tier]?.isExperimental ?? false,
      hardwareProfile,
      model: input.model || hardwareProfile,
      serialNumber: input.serialNumber || null,
      coordinates: input.coordinates || null,
      status: input.status || 'ACTIVE',
      healthStatus: input.healthStatus || 'HEALTHY',
      firmwareVersion: input.firmwareVersion || null
    }
  };
}

/**
 * Validates and sanitizes environmental measurement fields strictly conforming to hardware profile.
 * Unpopulated / unsupported fields are kept as null (Zero-Mock Invariant).
 * 
 * @param {Object} rawTelemetry
 * @param {string} [hardwareProfileCode='DUSTGUARD_SOLAR_V1']
 * @returns {{ sanitized: Object, violations: string[] }}
 */
export function sanitizeEnvironmentalMeasurements(rawTelemetry = {}, hardwareProfileCode = 'DUSTGUARD_SOLAR_V1') {
  const profile = HARDWARE_PROFILES[hardwareProfileCode] || HARDWARE_PROFILES.DUSTGUARD_SOLAR_V1;
  const supported = new Set(profile.supportedMetrics);
  const violations = [];

  const parseMetric = (val, key) => {
    if (val === undefined || val === null || val === '') {
      return null;
    }
    const num = parseFloat(val);
    if (isNaN(num)) {
      violations.push(`Giá trị ${key} không phải là số hợp lệ: ${val}`);
      return null;
    }
    const bounds = MEASUREMENT_PHYSICAL_BOUNDS[key];
    if (bounds && (num < bounds.min || num > bounds.max)) {
      violations.push(`Chỉ số ${bounds.name} (${num} ${bounds.unit}) nằm ngoài giới hạn vật lý [${bounds.min}, ${bounds.max}]`);
    }
    return num;
  };

  // Only assign value if metric is supported by hardware profile
  const pm1 = supported.has('pm1') ? parseMetric(rawTelemetry.pm1, 'pm1') : null;
  const pm25 = supported.has('pm25') ? parseMetric(rawTelemetry.pm25, 'pm25') : null;
  const pm10 = supported.has('pm10') ? parseMetric(rawTelemetry.pm10, 'pm10') : null;
  const temp = supported.has('temp') ? parseMetric(rawTelemetry.temp ?? rawTelemetry.temperature, 'temp') : null;
  const humidity = supported.has('humidity') ? parseMetric(rawTelemetry.humidity, 'humidity') : null;

  return {
    sanitized: {
      pm1,
      pm25,
      pm10,
      temp,
      humidity,
      timestamp: rawTelemetry.timestamp ? new Date(rawTelemetry.timestamp) : new Date(),
      sequenceNumber: typeof rawTelemetry.seq === 'number' ? rawTelemetry.seq : (typeof rawTelemetry.sequenceNumber === 'number' ? rawTelemetry.sequenceNumber : null)
    },
    supportedMetrics: Array.from(supported),
    violations
  };
}
