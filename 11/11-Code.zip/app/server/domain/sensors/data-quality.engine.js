/**
 * DustGuard VN - Data Quality & Integrity Engine (SSOT)
 * 
 * Implements 5 Core Quality Integrity Checkpoints:
 * 1. Stale Data & Liveness Timeout Detection
 * 2. Flatline & ADC Freeze / Tamper Detection
 * 3. Impossible Values & Physical Bounds Validation
 * 4. Sudden Jumps & Unrealistic Spike Detection
 * 5. Data Gaps & Packet Loss Sequence Checks
 * 
 * Generates Deterministic Quality Scores (0 - 100) & Integrity Diagnostics.
 */

import {
  MEASUREMENT_PHYSICAL_BOUNDS,
  DATA_QUALITY_THRESHOLDS,
  HARDWARE_PROFILES,
  SENSOR_CALIBRATION_STATUS
} from './sensor.rules.js';

export const QUALITY_FLAGS = {
  VALID: 'VALID',
  OUT_OF_BOUNDS: 'OUT_OF_BOUNDS',
  SUSPICIOUS_FLATLINE: 'SUSPICIOUS_FLATLINE',
  SUDDEN_JUMP: 'SUDDEN_JUMP',
  STALE_DATA: 'STALE_DATA',
  DATA_GAP: 'DATA_GAP',
  SEQUENCE_ANOMALY: 'SEQUENCE_ANOMALY',
  HARDWARE_PROFILE_MISMATCH: 'HARDWARE_PROFILE_MISMATCH',
  CALIBRATION_EXPIRED: 'CALIBRATION_EXPIRED'
};

export const QUALITY_TIERS = {
  EXCELLENT: { code: 'EXCELLENT', label: 'Rất tốt / Chuẩn xác', minScore: 90, color: 'green' },
  GOOD: { code: 'GOOD', label: 'Tốt / Đạt chuẩn', minScore: 75, color: 'teal' },
  FAIR: { code: 'FAIR', label: 'Khả dụng / Cần lưu ý', minScore: 50, color: 'amber' },
  POOR: { code: 'POOR', label: 'Chất lượng kém / Bất thường', minScore: 25, color: 'red' },
  CORRUPTED: { code: 'CORRUPTED', label: 'Dữ liệu hỏng / Vô hiệu', minScore: 0, color: 'darkred' }
};

export class DataQualityEngine {
  /**
   * 1. Physical Bounds Check (Impossible Values)
   * @param {Object} reading - { pm1, pm25, pm10, temp, humidity }
   * @returns {{ passed: boolean, violations: Array<{ metric: string, value: number, expected: string, reason: string }> }}
   */
  static validatePhysicalBounds(reading = {}) {
    const violations = [];

    for (const [key, bounds] of Object.entries(MEASUREMENT_PHYSICAL_BOUNDS)) {
      const val = reading[key];
      if (val !== undefined && val !== null) {
        const num = typeof val === 'number' ? val : parseFloat(val);
        if (isNaN(num)) {
          violations.push({
            metric: key,
            value: val,
            expected: `Số thực từ ${bounds.min} đến ${bounds.max} ${bounds.unit}`,
            reason: `Giá trị ${key} không phải số hợp lệ: ${val}`
          });
        } else if (num < bounds.min || num > bounds.max) {
          violations.push({
            metric: key,
            value: num,
            expected: `${bounds.min} - ${bounds.max} ${bounds.unit}`,
            reason: `Chỉ số ${bounds.name} (${num} ${bounds.unit}) nằm ngoài giới hạn vật lý [${bounds.min}, ${bounds.max} ${bounds.unit}]`
          });
        }
      }
    }

    return {
      passed: violations.length === 0,
      violations
    };
  }

  /**
   * 2. Flatline Detection (ADC Freeze / Sensor Tamper)
   * Detects if the last N consecutive readings have identical PM values across a timespan.
   * @param {Array<Object>} recentReadings - Array of readings ordered from newest to oldest
   * @param {Object} [options]
   * @returns {{ isFlatline: boolean, consecutiveCount: number, timeSpanMins: number, reason?: string }}
   */
  static detectFlatline(recentReadings = [], options = {}) {
    const minCount = options.minCount || DATA_QUALITY_THRESHOLDS.FLATLINE_CONSECUTIVE_COUNT;
    const minSpanMs = options.minSpanMs || DATA_QUALITY_THRESHOLDS.FLATLINE_MIN_SPAN_MS;

    if (!Array.isArray(recentReadings) || recentReadings.length < minCount) {
      return { isFlatline: false, consecutiveCount: recentReadings?.length || 0, timeSpanMins: 0 };
    }

    const window = recentReadings.slice(0, minCount);
    const first = window[0];
    if (!first || first.pm25 === null || first.pm25 === undefined || first.pm25 === '' ||
        first.pm10 === null || first.pm10 === undefined || first.pm10 === '') {
      return { isFlatline: false, consecutiveCount: 0, timeSpanMins: 0 };
    }

    const firstPm25 = typeof first.pm25 === 'number' ? first.pm25 : parseFloat(first.pm25);
    const firstPm10 = typeof first.pm10 === 'number' ? first.pm10 : parseFloat(first.pm10);

    if (Number.isNaN(firstPm25) || Number.isNaN(firstPm10)) {
      return { isFlatline: false, consecutiveCount: 0, timeSpanMins: 0 };
    }

    const allIdentical = window.every(r => {
      if (!r || r.pm25 === null || r.pm25 === undefined || r.pm25 === '' ||
          r.pm10 === null || r.pm10 === undefined || r.pm10 === '') {
        return false;
      }
      const p25 = typeof r.pm25 === 'number' ? r.pm25 : parseFloat(r.pm25);
      const p10 = typeof r.pm10 === 'number' ? r.pm10 : parseFloat(r.pm10);
      return !Number.isNaN(p25) && !Number.isNaN(p10) && p25 === firstPm25 && p10 === firstPm10;
    });

    if (!allIdentical) {
      return { isFlatline: false, consecutiveCount: 0, timeSpanMins: 0 };
    }

    const newestTime = window[0]?.timestamp ? new Date(window[0].timestamp).getTime() : NaN;
    const oldestTime = window[window.length - 1]?.timestamp ? new Date(window[window.length - 1].timestamp).getTime() : NaN;
    const timeSpanMs = (!Number.isNaN(newestTime) && !Number.isNaN(oldestTime)) ? Math.abs(newestTime - oldestTime) : 0;
    const timeSpanMins = Number.isFinite(timeSpanMs) ? Math.round(timeSpanMs / (60 * 1000)) : 0;

    // Flatline is confirmed if readings are identical and span is >= threshold or >= minCount points
    const isFlatline = allIdentical && (timeSpanMs >= minSpanMs || window.length >= minCount);

    return {
      isFlatline,
      consecutiveCount: window.length,
      timeSpanMins,
      reason: isFlatline
        ? `Phát hiện đóng băng tín hiệu (Flatline): ${window.length} số đo liên tiếp hoàn toàn trùng khớp (PM2.5: ${firstPm25}, PM10: ${firstPm10}) trong ${timeSpanMins} phút.`
        : undefined
    };
  }

  /**
   * 3. Sudden Jump Detection (Rate of Change vs Physical Limits)
   * @param {Object} currentReading - Current reading { pm25, pm10, temp, timestamp }
   * @param {Object} previousReading - Previous reading { pm25, pm10, temp, timestamp }
   * @returns {{ hasSuddenJump: boolean, deltaSec: number, deltaPm25: number, deltaPm10: number, reason?: string }}
   */
  static detectSuddenJump(currentReading, previousReading) {
    if (!currentReading || !previousReading) {
      return { hasSuddenJump: false, deltaSec: 0, deltaPm25: 0, deltaPm10: 0 };
    }

    const tCurrent = new Date(currentReading.timestamp).getTime();
    const tPrev = new Date(previousReading.timestamp).getTime();
    const deltaMs = Math.abs(tCurrent - tPrev);
    const deltaSec = Math.max(1, Math.round(deltaMs / 1000));

    // If readings are far apart (> 5 minutes), jump evaluation is less constrained
    if (deltaSec > 300) {
      return { hasSuddenJump: false, deltaSec, deltaPm25: 0, deltaPm10: 0 };
    }

    const deltaPm25 = Math.abs((currentReading.pm25 ?? 0) - (previousReading.pm25 ?? 0));
    const deltaPm10 = Math.abs((currentReading.pm10 ?? 0) - (previousReading.pm10 ?? 0));

    const ratePm25 = deltaPm25 / deltaSec;
    const ratePm10 = deltaPm10 / deltaSec;

    const pm25Jump = (deltaSec <= 15 && deltaPm25 > 250) || ratePm25 > DATA_QUALITY_THRESHOLDS.MAX_SUDDEN_JUMP_PM25_PER_SEC;
    const pm10Jump = (deltaSec <= 15 && deltaPm10 > 400) || ratePm10 > DATA_QUALITY_THRESHOLDS.MAX_SUDDEN_JUMP_PM10_PER_SEC;

    const hasSuddenJump = pm25Jump || pm10Jump;

    return {
      hasSuddenJump,
      deltaSec,
      deltaPm25: Math.round(deltaPm25 * 10) / 10,
      deltaPm10: Math.round(deltaPm10 * 10) / 10,
      ratePm25: Math.round(ratePm25 * 10) / 10,
      ratePm10: Math.round(ratePm10 * 10) / 10,
      reason: hasSuddenJump
        ? `Biến thiên nồng độ bụi bất thường (Sudden Jump): ΔPM2.5 = ${deltaPm25}µg/m³, ΔPM10 = ${deltaPm10}µg/m³ trong ${deltaSec}s (tốc độ ${Math.round(ratePm25)}µg/m³/s vượt ngưỡng vật lý).`
        : undefined
    };
  }

  /**
   * 4. Stale Data & Liveness Check
   * @param {Date|string|number} readingTimestamp
   * @param {number} [now=Date.now()]
   * @returns {{ isStale: boolean, ageMins: number, driftMs: number, reason?: string }}
   */
  static checkStaleness(readingTimestamp, now = Date.now()) {
    if (!readingTimestamp) {
      return { isStale: true, ageMins: Infinity, driftMs: Infinity, reason: 'Thiếu mốc thời gian đọc đo' };
    }

    const t = new Date(readingTimestamp).getTime();
    if (isNaN(t)) {
      return { isStale: true, ageMins: Infinity, driftMs: Infinity, reason: 'Mốc thời gian không hợp lệ' };
    }

    const driftMs = Math.abs(now - t);
    const ageMins = Math.round(driftMs / (60 * 1000));
    const isStale = driftMs > DATA_QUALITY_THRESHOLDS.STALE_TIMEOUT_MS;

    return {
      isStale,
      ageMins,
      driftMs,
      reason: isStale
        ? `Dữ liệu đọc đo bị trễ / hết thời hạn nhận tín hiệu (${ageMins} phút trước > ngưỡng 15 phút).`
        : undefined
    };
  }

  /**
   * 5. Data Gaps & Packet Sequence Continuity Check
   * @param {Object} current - { sequenceNumber, timestamp }
   * @param {Object} previous - { sequenceNumber, timestamp }
   * @param {number} [expectedIntervalSec=60]
   * @returns {{ hasGap: boolean, gapMins: number, packetsLost: number, isOutOfOrder: boolean, reason?: string }}
   */
  static checkDataGaps(current, previous, expectedIntervalSec = 60) {
    if (!current || !previous) {
      return { hasGap: false, gapMins: 0, packetsLost: 0, isOutOfOrder: false };
    }

    const tCurr = new Date(current.timestamp).getTime();
    const tPrev = new Date(previous.timestamp).getTime();
    const gapMs = Math.abs(tCurr - tPrev);
    const gapMins = Math.round(gapMs / (60 * 1000));

    const expectedMs = expectedIntervalSec * 1000;
    const hasGap = gapMs > Math.max(DATA_QUALITY_THRESHOLDS.DATA_GAP_THRESHOLD_MS, expectedMs * 3);

    let packetsLost = 0;
    let isOutOfOrder = false;

    if (current.sequenceNumber !== undefined && current.sequenceNumber !== null &&
        previous.sequenceNumber !== undefined && previous.sequenceNumber !== null) {
      const seqCurr = parseInt(current.sequenceNumber, 10);
      const seqPrev = parseInt(previous.sequenceNumber, 10);

      if (!isNaN(seqCurr) && !isNaN(seqPrev)) {
        if (seqCurr <= seqPrev) {
          isOutOfOrder = true;
        } else if (seqCurr > seqPrev + 1) {
          packetsLost = seqCurr - seqPrev - 1;
        }
      }
    }

    let reason = undefined;
    if (hasGap || packetsLost > 0 || isOutOfOrder) {
      const parts = [];
      if (hasGap) parts.push(`Khoảng trống dữ liệu ${gapMins} phút`);
      if (packetsLost > 0) parts.push(`Mất ${packetsLost} gói tin truyền`);
      if (isOutOfOrder) parts.push(`Gói tin nhận sai thứ tự / lặp chuỗi sequence`);
      reason = parts.join('; ');
    }

    return {
      hasGap,
      gapMins,
      packetsLost,
      isOutOfOrder,
      reason
    };
  }

  /**
   * Evaluates comprehensive Data Quality Score & Diagnostics for a telemetry packet.
   * 
   * @param {Object} params
   * @param {Object} params.reading - Current telemetry { pm1, pm25, pm10, temp, humidity, timestamp, sequenceNumber }
   * @param {Array<Object>} [params.recentReadings=[]] - Recent telemetry history (ordered desc)
   * @param {string} [params.hardwareProfile='DUSTGUARD_SOLAR_V1'] - Hardware profile code
   * @param {string} [params.calibrationStatus='CALIBRATED'] - Calibration status
   * @param {boolean} [params.isExperimental=false] - Experimental device tag
   * @returns {{
   *   score: number,
   *   tier: string,
   *   tierDetails: Object,
   *   isValid: boolean,
   *   flags: string[],
   *   diagnostics: {
   *     bounds: Object,
   *     flatline: Object,
   *     suddenJump: Object,
   *     staleness: Object,
   *     dataGaps: Object
   *   },
   *   summaryText: string
   * }}
   */
  static evaluateTelemetryQuality({
    reading = {},
    recentReadings = [],
    hardwareProfile = 'DUSTGUARD_SOLAR_V1',
    calibrationStatus = 'CALIBRATED',
    isExperimental = false
  } = {}) {
    const flags = [];
    let qualityScore = 100;
    const summaries = [];

    // 1. Physical Bounds Check
    const bounds = this.validatePhysicalBounds(reading);
    if (!bounds.passed) {
      flags.push(QUALITY_FLAGS.OUT_OF_BOUNDS);
      qualityScore -= 50;
      summaries.push(`Lỗi giới hạn vật lý: ${bounds.violations.map(v => v.reason).join(', ')}`);
    }

    // 2. Flatline Check
    const flatlineHistory = [reading, ...(Array.isArray(recentReadings) ? recentReadings : [])];
    const flatline = this.detectFlatline(flatlineHistory);
    if (flatline.isFlatline) {
      flags.push(QUALITY_FLAGS.SUSPICIOUS_FLATLINE);
      qualityScore -= 40;
      summaries.push(flatline.reason);
    }

    // 3. Sudden Jump Check
    const prevReading = recentReadings?.[0] || null;
    const suddenJump = this.detectSuddenJump(reading, prevReading);
    if (suddenJump.hasSuddenJump) {
      flags.push(QUALITY_FLAGS.SUDDEN_JUMP);
      qualityScore -= 25;
      summaries.push(suddenJump.reason);
    }

    // 4. Staleness Check
    const staleness = this.checkStaleness(reading.timestamp);
    if (staleness.isStale) {
      flags.push(QUALITY_FLAGS.STALE_DATA);
      qualityScore -= 20;
      summaries.push(staleness.reason);
    }

    // 5. Data Gaps & Sequence Check
    const dataGaps = this.checkDataGaps(reading, prevReading);
    if (dataGaps.hasGap || dataGaps.packetsLost > 0 || dataGaps.isOutOfOrder) {
      if (dataGaps.hasGap) flags.push(QUALITY_FLAGS.DATA_GAP);
      if (dataGaps.isOutOfOrder || dataGaps.packetsLost > 0) flags.push(QUALITY_FLAGS.SEQUENCE_ANOMALY);
      qualityScore -= Math.min(20, (dataGaps.hasGap ? 10 : 0) + (dataGaps.packetsLost > 0 ? 10 : 0));
      summaries.push(dataGaps.reason);
    }

    // 6. Calibration Check
    const calMeta = SENSOR_CALIBRATION_STATUS[calibrationStatus];
    if (calibrationStatus === 'EXPIRED') {
      flags.push(QUALITY_FLAGS.CALIBRATION_EXPIRED);
      qualityScore -= 15;
      summaries.push('Hiệu chuẩn cảm biến đã quá hạn (>180 ngày).');
    } else if (calibrationStatus === 'UNCALIBRATED') {
      qualityScore -= 10;
      summaries.push('Thiết bị chưa qua hiệu chuẩn chuẩn độ.');
    }

    // Clamp score
    const finalScore = Math.max(0, Math.min(100, Math.round(qualityScore)));

    // Determine Tier
    let tier = QUALITY_TIERS.CORRUPTED;
    for (const t of [QUALITY_TIERS.EXCELLENT, QUALITY_TIERS.GOOD, QUALITY_TIERS.FAIR, QUALITY_TIERS.POOR]) {
      if (finalScore >= t.minScore) {
        tier = t;
        break;
      }
    }

    if (flags.length === 0) {
      flags.push(QUALITY_FLAGS.VALID);
      summaries.push('Dữ liệu đạt chuẩn toàn vẹn (Data Quality Verified).');
    }

    const isValid = finalScore >= 50 && !flags.includes(QUALITY_FLAGS.OUT_OF_BOUNDS) && !flags.includes(QUALITY_FLAGS.SUSPICIOUS_FLATLINE);

    return {
      score: finalScore,
      tier: tier.code,
      tierDetails: tier,
      isValid,
      isExperimental,
      flags,
      diagnostics: {
        bounds,
        flatline,
        suddenJump,
        staleness,
        dataGaps
      },
      summaryText: summaries.join(' ')
    };
  }
}
