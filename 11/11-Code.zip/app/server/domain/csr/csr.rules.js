/**
 * DustGuard Domain Rules: CSR Escrow & ESG Fund State Machine
 * DDD Domain Layer - Independent of HTTP, Express, Hono, or Database
 */

export const ESCROW_STATUS = {
  LOCKED: 'LOCKED',
  LOCKED_RISK: 'LOCKED_RISK',
  PARTIALLY_RELEASED: 'PARTIALLY_RELEASED',
  FULLY_RELEASED: 'FULLY_RELEASED',
  FORFEITED: 'FORFEITED',
  DISPUTED: 'DISPUTED'
};

export const MILESTONE_STATUS = {
  PENDING: 'PENDING',
  VERIFIED: 'VERIFIED',
  RELEASED: 'RELEASED'
};

/**
 * Validates whether an escrow contract milestone can be released
 * @param {Object} escrowContract 
 * @param {string} milestoneId 
 * @param {Object} [options]
 * @throws {Error} if release is blocked by risk lock or invalid milestone state
 * @returns {boolean}
 */
export function validateEscrowRelease(escrowContract, milestoneId, options = {}) {
  if (!escrowContract) {
    throw new Error('Hợp đồng CSR Escrow không tồn tại.');
  }

  if (escrowContract.status === ESCROW_STATUS.FORFEITED) {
    throw new Error('Không thể giải ngân: Quỹ Escrow đã bị tịch thu do vi phạm môi trường nghiêm trọng.');
  }

  if (escrowContract.status === ESCROW_STATUS.LOCKED_RISK && !options.forceOverride) {
    throw new Error('Không thể giải ngân: Quỹ Escrow đang bị tự động khóa rủi ro do nồng độ PM10 hoặc điểm rủi ro vượt ngưỡng.');
  }

  const milestone = escrowContract.milestones?.find(m => m.id === milestoneId);
  if (!milestone) {
    throw new Error(`Không tìm thấy mốc Escrow với ID: ${milestoneId}`);
  }

  if (milestone.status === MILESTONE_STATUS.RELEASED) {
    return true; // Already released, no-op
  }

  if (escrowContract.remainingBalance < milestone.amount) {
    throw new Error(`Số dư khả dụng (${escrowContract.remainingBalance}) không đủ để giải ngân mốc ${milestoneId} (${milestone.amount}).`);
  }

  return true;
}

/**
 * Validates whether an escrow contract can be forfeited
 * @param {Object} escrowContract 
 * @param {string} reason 
 * @param {Object} [options]
 * @throws {Error} if forfeit is invalid
 * @returns {boolean}
 */
export function validateEscrowForfeit(escrowContract, reason, options = {}) {
  if (!escrowContract) {
    throw new Error('Hợp đồng CSR Escrow không tồn tại.');
  }

  if (escrowContract.status === ESCROW_STATUS.FULLY_RELEASED) {
    throw new Error('Không thể tịch thu hợp đồng Escrow đã giải ngân toàn bộ.');
  }

  if (escrowContract.status === ESCROW_STATUS.FORFEITED) {
    return true; // Already forfeited
  }

  if (!reason || String(reason).trim().length < 5) {
    throw new Error('Tịch thu quỹ Escrow bắt buộc phải có căn cứ và lý do vi phạm rõ ràng.');
  }

  return true;
}
