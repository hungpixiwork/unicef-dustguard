/**
 * DustGuard Domain Rules: Action & Remediation Lifecycle
 * DDD Domain Layer - Independent of HTTP, Express, Hono, or Database
 */

export const ACTION_STATUS = {
  PENDING: 'PENDING',
  IN_PROGRESS: 'IN_PROGRESS',
  PENDING_VERIFICATION: 'PENDING_VERIFICATION',
  COMPLETED: 'COMPLETED',
  VERIFIED: 'VERIFIED',
  CLOSED: 'CLOSED'
};

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf'
]);

const ALLOWED_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.pdf']);
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

/**
 * Normalizes action status to standard uppercase representation
 * @param {string} status
 * @returns {string}
 */
export function normalizeActionStatus(status) {
  if (!status) return ACTION_STATUS.PENDING;
  const upper = String(status).trim().toUpperCase();
  if (upper === 'IN_REMEDIATION' || upper === 'PROCESSING' || upper === 'IN_PROGRESS') return ACTION_STATUS.IN_PROGRESS;
  if (upper === 'SUBMITTED' || upper === 'PENDING_VERIFICATION' || upper === 'AWAITING_VERIFICATION') return ACTION_STATUS.PENDING_VERIFICATION;
  if (upper === 'RESOLVED' || upper === 'DONE' || upper === 'COMPLETED') return ACTION_STATUS.COMPLETED;
  if (upper === 'VERIFIED' || upper === 'APPROVED') return ACTION_STATUS.VERIFIED;
  if (upper === 'CLOSED' || upper === 'ARCHIVED') return ACTION_STATUS.CLOSED;
  if (upper === 'PENDING' || upper === 'OPEN' || upper === 'NEW') return ACTION_STATUS.PENDING;
  return upper;
}

// Valid status transition graph (DAG)
const VALID_ACTION_TRANSITIONS = {
  PENDING: ['IN_PROGRESS', 'PENDING_VERIFICATION', 'COMPLETED', 'CLOSED'],
  IN_PROGRESS: ['PENDING_VERIFICATION', 'COMPLETED', 'CLOSED', 'PENDING'],
  PENDING_VERIFICATION: ['VERIFIED', 'IN_PROGRESS', 'PENDING', 'COMPLETED', 'CLOSED'],
  COMPLETED: ['VERIFIED', 'IN_PROGRESS', 'PENDING_VERIFICATION', 'CLOSED'],
  VERIFIED: ['CLOSED', 'IN_PROGRESS'],
  CLOSED: ['IN_PROGRESS'] // Only admin can reopen with valid reason
};

/**
 * Checks if an action record is overdue
 * @param {{ status?: string, deadlineAt?: string|Date, dueDate?: string|Date }} action 
 * @returns {boolean}
 */
export function isActionOverdue(action) {
  if (!action) return false;
  const status = normalizeActionStatus(action.status);
  if (status === ACTION_STATUS.CLOSED || status === ACTION_STATUS.COMPLETED || status === ACTION_STATUS.VERIFIED) {
    return false;
  }
  const deadlineValue = action.deadlineAt || action.dueDate;
  if (!deadlineValue) {
    return false;
  }
  const deadline = new Date(deadlineValue).getTime();
  return !isNaN(deadline) && deadline < Date.now();
}

/**
 * Computes runtime action status accounting for deadlines
 * @param {{ status?: string, deadlineAt?: string|Date, dueDate?: string|Date }} action 
 * @returns {string}
 */
export function computeActionStatus(action) {
  if (!action) return 'unknown';
  const rawStatus = String(action.status || '').toLowerCase();
  if (rawStatus === 'closed' || action.status === ACTION_STATUS.CLOSED || action.status === ACTION_STATUS.COMPLETED) {
    return rawStatus || 'closed';
  }
  if (isActionOverdue(action)) {
    return 'overdue';
  }
  return action.status || 'pending';
}

/**
 * Validates state transition for actions with strict guards:
 * - Allowed transitions DAG
 * - Required role enforcement (only staff/admin/executive can VERIFY)
 * - Required evidence enforcement for PENDING_VERIFICATION
 * - Required reason/notes when reopening or rejecting
 * 
 * @param {string} currentStatus 
 * @param {string} newStatus 
 * @param {Object} [options]
 * @param {string} [options.role] - User role: citizen, contractor, staff, executive, admin
 * @param {string} [options.evidenceUrl] - URL or file path of evidence
 * @param {string} [options.reason] - Reopen / rejection explanation
 * @throws {Error} if transition or guard fails
 * @returns {boolean} true if valid
 */
export function validateActionTransition(currentStatus, newStatus, options = {}) {
  const normCurrent = normalizeActionStatus(currentStatus);
  const normNew = normalizeActionStatus(newStatus);

  // Self-transition is a no-op
  if (normCurrent === normNew) {
    return true;
  }

  // Guard 1: Closed records cannot be reopened unless by admin with explanation
  if (normCurrent === ACTION_STATUS.CLOSED) {
    const isReopenByAdmin = (options.role === 'admin' || options.role === 'demo_admin') && Boolean(options.reason && options.reason.trim().length >= 5);
    if (!isReopenByAdmin) {
      throw new Error(`Khong the chuyen trang thai tu closed sang ${newStatus}. Chi Admin moi co quyen mo lai kem ly do giai trinh.`);
    }
  }

  // Guard 2: Valid transition DAG check
  const allowed = VALID_ACTION_TRANSITIONS[normCurrent];
  if (!allowed || !allowed.includes(normNew)) {
    throw new Error(`Chuyen trang thai khong hop le tu ${currentStatus} (${normCurrent}) sang ${newStatus} (${normNew}).`);
  }

  // Guard 3: VERIFIED requires authorized staff, executive, or admin role
  if (normNew === ACTION_STATUS.VERIFIED) {
    const authorizedRoles = ['staff', 'executive', 'admin', 'demo_admin'];
    if (options.role && !authorizedRoles.includes(options.role.toLowerCase())) {
      throw new Error(`Nha thau hoac Cong dan khong co tham quyen xac nhan (VERIFIED) hanh dong khac phuc. Yeu cau can bo Thanh tra / Admin.`);
    }
  }

  // Guard 4: PENDING_VERIFICATION requires evidence URL or attachment
  if (normNew === ACTION_STATUS.PENDING_VERIFICATION) {
    const hasEvidence = Boolean(options.evidenceUrl || options.evidence || options.file);
    if (!hasEvidence && options.enforceEvidence !== false) {
      throw new Error(`Chuyen sang trang thai cho xac minh (PENDING_VERIFICATION) bat buoc phai co hinh anh hoac tai lieu minh chung.`);
    }
  }

  // Guard 5: Moving back from PENDING_VERIFICATION or VERIFIED to IN_PROGRESS/PENDING requires rejection reason
  if ((normCurrent === ACTION_STATUS.PENDING_VERIFICATION || normCurrent === ACTION_STATUS.VERIFIED) && (normNew === ACTION_STATUS.IN_PROGRESS || normNew === ACTION_STATUS.PENDING)) {
    if (options.enforceReason && (!options.reason || options.reason.trim().length < 3)) {
      throw new Error(`Yeu cau nhap ly do tu choi / yeu cau khac phuc lai.`);
    }
  }

  return true;
}

/**
 * Validates uploaded evidence file metadata
 * @param {{ originalname?: string, mimetype?: string, size?: number }} file 
 * @returns {string|null} Error message or null if valid
 */
export function validateEvidenceFile(file) {
  if (!file) {
    return 'Vui lòng chọn tệp tin minh chứng.';
  }

  const { originalname = '', mimetype = '', size = 0 } = file;
  const ext = originalname.includes('.') ? originalname.slice(originalname.lastIndexOf('.')).toLowerCase() : '';

  if (!ALLOWED_MIME_TYPES.has(mimetype) || !ALLOWED_EXTENSIONS.has(ext)) {
    return 'Chi ho tro cac dinh dang anh (JPG, PNG, WEBP) va tai lieu PDF.';
  }

  if (size > MAX_FILE_SIZE_BYTES) {
    return `Dung luong tep tin (${(size / 1024 / 1024).toFixed(1)}MB) vuot qua gioi han 5MB cho phep.`;
  }

  return null;
}
