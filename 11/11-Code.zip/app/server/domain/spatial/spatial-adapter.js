/**
 * Spatial Domain Adapter & WGS84 Coordinate SSOT (DustGuard VN)
 * Standardizes coordinate parsing, serialization, distance calculation and geofence verification across all repositories and services.
 */

export const DEFAULT_HANOI_COORDINATES = Object.freeze({
  latitude: 21.02851,
  longitude: 105.85420,
  lat: 21.02851,
  lng: 105.85420
});

export const WGS84_BOUNDS = Object.freeze({
  MIN_LATITUDE: -90,
  MAX_LATITUDE: 90,
  MIN_LONGITUDE: -180,
  MAX_LONGITUDE: 180
});

const EARTH_RADIUS_METERS = 6371000;

/**
 * Validates whether numeric latitude and longitude conform to standard WGS84 coordinate bounds.
 * @param {number|any} latitude
 * @param {number|any} longitude
 * @returns {boolean}
 */
export function isValidWgs84(latitude, longitude) {
  if (latitude === null || latitude === undefined || longitude === null || longitude === undefined) {
    return false;
  }
  if (typeof latitude === 'string' && latitude.trim() === '') return false;
  if (typeof longitude === 'string' && longitude.trim() === '') return false;
  const lat = Number(latitude);
  const lng = Number(longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || isNaN(lat) || isNaN(lng)) {
    return false;
  }
  if (lat === 0 && lng === 0) return false;
  return lat >= WGS84_BOUNDS.MIN_LATITUDE &&
         lat <= WGS84_BOUNDS.MAX_LATITUDE &&
         lng >= WGS84_BOUNDS.MIN_LONGITUDE &&
         lng <= WGS84_BOUNDS.MAX_LONGITUDE;
}

/**
 * Parses and normalizes coordinates from any supported input format:
 * - Direct coordinate string: "21.02851, 105.85420", "21.02851,105.85420", "21.02851; 105.85420", "21.02851 105.85420"
 * - JSON string: '{"lat": 21.0285, "lng": 105.8542}' or '{"latitude": 21.0285, "longitude": 105.8542}'
 * - Coordinate object: { latitude, longitude } or { lat, lng } or { lat, lon }
 * - Entity object containing coordinates, latitude, longitude, location, position
 * - Coordinate array: [lat, lng] or [lng, lat]
 * - Dual arguments: parseCoordinates(lat, lng)
 *
 * @param {any} input Coordinate input or entity
 * @param {object} [options]
 * @param {boolean} [options.allowNull=false] If true and input is empty/invalid, returns null
 * @param {object} [options.fallback=DEFAULT_HANOI_COORDINATES] Fallback coordinates when input is invalid
 * @param {number} [options.precision=6] Decimal rounding precision
 * @returns {{ latitude: number, longitude: number, lat: number, lng: number, isValid: boolean, formatted: string }|null}
 */
export function parseCoordinates(input, options = {}) {
  // Support dual arguments: parseCoordinates(lat, lng)
  if (arguments.length >= 2 && (typeof arguments[1] === 'number' || (typeof arguments[1] === 'string' && !isNaN(Number(arguments[1]))))) {
    const lat = Number(arguments[0]);
    const lng = Number(arguments[1]);
    if (isValidWgs84(lat, lng)) {
      return buildCoordinateResult(lat, lng, true, options.precision);
    }
  }

  const {
    allowNull = false,
    fallback = DEFAULT_HANOI_COORDINATES,
    precision = 6
  } = (typeof options === 'object' && options !== null) ? options : {};

  if (input === null || input === undefined || input === '') {
    if (allowNull) return null;
    return buildFallbackResult(fallback, precision);
  }

  let rawLat = null;
  let rawLng = null;

  // 1. If input is a string
  if (typeof input === 'string') {
    const trimmed = input.trim();
    if (!trimmed) {
      if (allowNull) return null;
      return buildFallbackResult(fallback, precision);
    }

    // Try parsing as JSON object/array
    if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
      try {
        const parsedJson = JSON.parse(trimmed);
        return parseCoordinates(parsedJson, options);
      } catch {
        // Continue to string delimiter extraction
      }
    }

    // Try comma, semicolon, pipe, or whitespace split
    let parts = trimmed.split(/[,;|]/).map(s => s.trim()).filter(Boolean);
    if (parts.length < 2) {
      parts = trimmed.split(/\s+/).map(s => s.trim()).filter(Boolean);
    }

    if (parts.length >= 2) {
      rawLat = parseFloat(parts[0]);
      rawLng = parseFloat(parts[1]);
    }
  }
  // 2. If input is an Array: [lat, lng]
  else if (Array.isArray(input)) {
    if (input.length >= 2) {
      rawLat = Number(input[0]);
      rawLng = Number(input[1]);
    }
  }
  // 3. If input is an Object
  else if (typeof input === 'object') {
    // If entity has nested coordinates field (e.g. site.coordinates)
    if (input.coordinates !== undefined && input.coordinates !== null && input.coordinates !== input) {
      const nested = parseCoordinates(input.coordinates, { allowNull: true, precision });
      if (nested && nested.isValid) {
        return nested;
      }
    }

    // Direct object keys: latitude/longitude, lat/lng, lat/lon, y/x
    if (input.latitude !== undefined && input.latitude !== null) {
      rawLat = Number(input.latitude);
    } else if (input.lat !== undefined && input.lat !== null) {
      rawLat = Number(input.lat);
    } else if (input.y !== undefined && input.y !== null) {
      rawLat = Number(input.y);
    }

    if (input.longitude !== undefined && input.longitude !== null) {
      rawLng = Number(input.longitude);
    } else if (input.lng !== undefined && input.lng !== null) {
      rawLng = Number(input.lng);
    } else if (input.lon !== undefined && input.lon !== null) {
      rawLng = Number(input.lon);
    } else if (input.x !== undefined && input.x !== null) {
      rawLng = Number(input.x);
    }
  }

  // Evaluate validity
  if (rawLat !== null && rawLng !== null && isValidWgs84(rawLat, rawLng)) {
    return buildCoordinateResult(rawLat, rawLng, true, precision);
  }

  if (allowNull) {
    return null;
  }

  return buildFallbackResult(fallback, precision);
}

function roundTo(num, dec) {
  if (!dec && dec !== 0) return num;
  const factor = Math.pow(10, dec);
  return Math.round(num * factor) / factor;
}

function buildCoordinateResult(lat, lng, isValid, precision) {
  const roundedLat = roundTo(lat, precision);
  const roundedLng = roundTo(lng, precision);
  return {
    latitude: roundedLat,
    longitude: roundedLng,
    lat: roundedLat,
    lng: roundedLng,
    isValid: Boolean(isValid),
    formatted: `${roundedLat},${roundedLng}`
  };
}

function buildFallbackResult(fallback, precision) {
  const fLat = fallback?.latitude ?? fallback?.lat ?? DEFAULT_HANOI_COORDINATES.lat;
  const fLng = fallback?.longitude ?? fallback?.lng ?? DEFAULT_HANOI_COORDINATES.lng;
  return {
    latitude: roundTo(fLat, precision),
    longitude: roundTo(fLng, precision),
    lat: roundTo(fLat, precision),
    lng: roundTo(fLng, precision),
    isValid: false,
    formatted: `${roundTo(fLat, precision)},${roundTo(fLng, precision)}`
  };
}

/**
 * Serializes coordinate object/input into desired database representation.
 * @param {any} coords Coordinate input
 * @param {'STRING'|'TEXT'|'OBJECT'|'WGS84'|'SHORT_OBJECT'|'ARRAY'|'GEOJSON'} [format='STRING']
 * @returns {string|object|number[]|null}
 */
export function serializeCoordinates(coords, format = 'STRING') {
  const parsed = parseCoordinates(coords, { allowNull: true });
  if (!parsed || !parsed.isValid) return null;

  switch (format.toUpperCase()) {
    case 'STRING':
    case 'TEXT':
      return `${parsed.latitude},${parsed.longitude}`;
    case 'OBJECT':
    case 'WGS84':
      return { latitude: parsed.latitude, longitude: parsed.longitude };
    case 'SHORT_OBJECT':
      return { lat: parsed.lat, lng: parsed.lng };
    case 'ARRAY':
    case 'LAT_LNG_ARRAY':
      return [parsed.latitude, parsed.longitude];
    case 'GEOJSON':
    case 'LNG_LAT_ARRAY':
      return [parsed.longitude, parsed.latitude];
    default:
      return `${parsed.latitude},${parsed.longitude}`;
  }
}

/**
 * Normalizes an entity or list of entities by standardizing all coordinate representations:
 * Attaches { latitude, longitude, lat, lng, coordinates } consistently.
 * @param {object|object[]} entity
 * @param {object} [options]
 * @returns {object|object[]}
 */
export function normalizeEntityCoordinates(entity, options = {}) {
  if (!entity) return entity;
  if (Array.isArray(entity)) {
    return entity.map(item => normalizeEntityCoordinates(item, options));
  }

  const parsed = parseCoordinates(entity, { allowNull: true, ...options });
  if (!parsed || !parsed.isValid) {
    return {
      ...entity,
      latitude: entity.latitude !== undefined ? entity.latitude : null,
      longitude: entity.longitude !== undefined ? entity.longitude : null,
      lat: entity.lat !== undefined ? entity.lat : (entity.latitude !== undefined ? entity.latitude : null),
      lng: entity.lng !== undefined ? entity.lng : (entity.longitude !== undefined ? entity.longitude : null),
      coordinates: entity.coordinates || null
    };
  }

  return {
    ...entity,
    latitude: parsed.latitude,
    longitude: parsed.longitude,
    lat: parsed.lat,
    lng: parsed.lng,
    coordinates: parsed.formatted
  };
}

/**
 * Calculates Haversine distance in meters between two WGS84 coordinates.
 * Supports both:
 *  - calculateHaversineDistance(lat1, lon1, lat2, lon2)
 *  - calculateHaversineDistance(point1, point2)
 * @returns {number} Distance in meters rounded to 1 decimal place (or Infinity if invalid)
 */
export function calculateHaversineDistance(arg1, arg2, arg3, arg4) {
  let lat1, lon1, lat2, lon2;

  if (arg3 !== undefined && arg4 !== undefined) {
    lat1 = Number(arg1);
    lon1 = Number(arg2);
    lat2 = Number(arg3);
    lon2 = Number(arg4);
  } else {
    const p1 = parseCoordinates(arg1, { allowNull: true });
    const p2 = parseCoordinates(arg2, { allowNull: true });
    if (!p1 || !p2 || !p1.isValid || !p2.isValid) return Infinity;
    lat1 = p1.lat;
    lon1 = p1.lng;
    lat2 = p2.lat;
    lon2 = p2.lng;
  }

  if (!isValidWgs84(lat1, lon1) || !isValidWgs84(lat2, lon2)) {
    return Infinity;
  }

  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(EARTH_RADIUS_METERS * c * 10) / 10;
}

/**
 * Checks if two coordinate points are within a specified radius in meters.
 * @param {any} point1
 * @param {any} point2
 * @param {number} radiusMeters
 * @returns {boolean}
 */
export function isWithinRadius(point1, point2, radiusMeters) {
  const dist = calculateHaversineDistance(point1, point2);
  return Number.isFinite(dist) && dist <= Number(radiusMeters);
}

/**
 * Evaluates whether evidence coordinates are within site geofence buffer (e.g. 50m).
 * Supports both:
 *  - evaluateGeofenceBuffer(contractorLat, contractorLng, siteLat, siteLng, bufferMeters = 50)
 *  - evaluateGeofenceBuffer(siteCoords, evidenceCoords, bufferMeters = 50)
 */
export function evaluateGeofenceBuffer(arg1, arg2, arg3 = 50, arg4, arg5 = 50) {
  let cLat, cLng, sLat, sLng, bufferMeters;

  if (arg4 !== undefined) {
    cLat = Number(arg1);
    cLng = Number(arg2);
    sLat = Number(arg3);
    sLng = Number(arg4);
    bufferMeters = Number(arg5) || 50;
  } else {
    const site = parseCoordinates(arg1, { allowNull: true });
    const evidence = parseCoordinates(arg2, { allowNull: true });
    if (!site || !evidence || !site.isValid || !evidence.isValid) {
      return {
        valid: false,
        within50m: false,
        distanceMeters: Infinity,
        allowedBufferMeters: Number(arg3) || 50,
        maxAllowedMeters: Number(arg3) || 50,
        matchStatus: 'INVALID_COORDINATES',
        status: 'INVALID_COORDINATES',
        reason: 'Tọa độ công trình hoặc minh chứng không đúng định dạng WGS84.'
      };
    }
    sLat = site.lat;
    sLng = site.lng;
    cLat = evidence.lat;
    cLng = evidence.lng;
    bufferMeters = Number(arg3) || 50;
  }

  if (!isValidWgs84(cLat, cLng) || !isValidWgs84(sLat, sLng)) {
    return {
      valid: false,
      within50m: false,
      distanceMeters: Infinity,
      allowedBufferMeters: bufferMeters,
      maxAllowedMeters: bufferMeters,
      matchStatus: 'OUT_OF_BOUNDS',
      status: 'OUT_OF_BOUNDS',
      reason: 'Tọa độ vượt ra ngoài giới hạn WGS84 [-90, 90], [-180, 180].'
    };
  }

  const distanceMeters = calculateHaversineDistance(cLat, cLng, sLat, sLng);
  const isWithin = distanceMeters <= bufferMeters;

  return {
    valid: isWithin,
    within50m: distanceMeters <= 50,
    distanceMeters,
    allowedBufferMeters: bufferMeters,
    maxAllowedMeters: bufferMeters,
    matchStatus: isWithin ? 'EXACT_MATCH' : (distanceMeters <= 100 ? 'BUFFER_WARNING' : 'OUT_OF_BOUNDS'),
    status: isWithin ? 'MATCH' : 'OUT_OF_BOUNDS',
    reason: isWithin
      ? `Tọa độ hợp lệ trong ranh giới ${bufferMeters}m (${distanceMeters}m).`
      : `Tọa độ cách công trình ${distanceMeters}m (vượt quá ranh giới cho phép ${bufferMeters}m).`
  };
}

/**
 * Formats coordinates into standard WGS84 comma-separated string.
 * @param {number} latitude
 * @param {number} longitude
 * @param {number} [precision=6]
 * @returns {string}
 */
export function formatWgs84(latitude, longitude, precision = 6) {
  if (!isValidWgs84(latitude, longitude)) return null;
  return `${Number(latitude).toFixed(precision)},${Number(longitude).toFixed(precision)}`;
}
