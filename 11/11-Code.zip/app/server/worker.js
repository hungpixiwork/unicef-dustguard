/**
 * DustGuard VN - Cloudflare Worker Entrypoint (Production SSOT)
 * Architecture: Modular Monolith with Thin Worker Entrypoint & Hono Composition Root
 * Framework: Hono
 * Database: Cloudflare D1 (env.DB)
 * Storage: Cloudflare R2 (env.EVIDENCE_BUCKET / env.STORAGE)
 * Assets: Workers Static Assets (env.ASSETS)
 */
import app, { resetComplaintRateLimits } from './app.js';
import { runOperationalSweep } from './services/automation-engine.service.js';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (
      url.pathname.startsWith('/api') ||
      url.pathname.startsWith('/auth') ||
      url.pathname.startsWith('/docs') ||
      url.pathname.startsWith('/api-docs') ||
      url.pathname.startsWith('/uploads') ||
      url.pathname === '/health' ||
      url.pathname === '/openapi.json'
    ) {
      return app.fetch(request, env, ctx);
    }
    if (env.ASSETS) {
      return env.ASSETS.fetch(request);
    }
    return app.fetch(request, env, ctx);
  },

  async scheduled(event, env, ctx) {
    if (env && env.DB) {
      if (ctx && typeof ctx.waitUntil === 'function') {
        ctx.waitUntil(runOperationalSweep(env, { event, ctx }));
      } else {
        await runOperationalSweep(env, { event, ctx });
      }
    }
  }
};

export { app, resetComplaintRateLimits };
