/**
 * Idempotency Protection Service (DustGuard VN)
 * Guarantees that duplicate write requests with the same Idempotency-Key
 * return the original response without executing side-effects multiple times.
 */

import { canonicalHash } from './canonical-json.js';
import { getD1OrSqlite } from './db.js';

const IN_MEMORY_IDEMPOTENCY = new Map();
const DEFAULT_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

export async function getIdempotentResponse(key, requestPayload, envOrDb) {
  if (!key) return null;

  const now = Date.now();
  const cached = IN_MEMORY_IDEMPOTENCY.get(key);
  if (cached) {
    if (cached.expiresAt > now) {
      return cached.response;
    }
    IN_MEMORY_IDEMPOTENCY.delete(key);
  }

  // Also check D1 if table exists
  try {
    const db = getD1OrSqlite(envOrDb);
    const row = await db.prepare('SELECT response_json, status_code, expires_at FROM idempotency_keys WHERE key = ?')
      .bind(key).first();
    if (row && new Date(row.expires_at).getTime() > now) {
      return {
        status: row.status_code || 200,
        body: JSON.parse(row.response_json)
      };
    }
  } catch {
    // Graceful fallback if idempotency_keys table is not yet migrated
  }

  return null;
}

export async function setIdempotentResponse(key, requestPayload, response, envOrDb, ttlMs = DEFAULT_TTL_MS) {
  if (!key) return;

  const now = Date.now();
  const expiresAt = now + ttlMs;

  IN_MEMORY_IDEMPOTENCY.set(key, {
    response,
    expiresAt
  });

  try {
    const db = getD1OrSqlite(envOrDb);
    const expiresAtIso = new Date(expiresAt).toISOString();
    const nowIso = new Date(now).toISOString();
    const reqHash = requestPayload ? await canonicalHash(requestPayload) : null;
    
    await db.prepare(`
      INSERT OR REPLACE INTO idempotency_keys (key, request_hash, response_json, status_code, expires_at, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      key,
      reqHash,
      JSON.stringify(response.body),
      response.status || 200,
      expiresAtIso,
      nowIso
    ).run();
  } catch {
    // Graceful fallback
  }
}
