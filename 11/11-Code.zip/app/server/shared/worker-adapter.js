/**
 * Express Controller to Hono Handler Adapter for DustGuard VN
 * Enables standard Express controllers and middlewares to execute
 * inside Cloudflare Worker Native runtime with Hono.
 */
import { getSessionFromRequest, normalizeAuthUser } from '../auth.js';

export function adaptChain(...handlers) {
  return async (c) => {
    let body = {};
    const method = c.req.method;
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      try {
        body = await c.req.json();
      } catch {
        try {
          body = await c.req.parseBody();
        } catch {
          body = {};
        }
      }
    }

    const req = {
      method,
      url: c.req.url,
      path: c.req.path,
      headers: Object.fromEntries(Object.entries(c.req.header())),
      body,
      query: c.req.query(),
      params: c.req.param(),
      user: c.get('user') || null,
      authSession: c.get('authSession') || null,
      env: c.env,
      id: crypto.randomUUID(),
      ip: c.req.header('cf-connecting-ip') || c.req.header('x-forwarded-for') || '127.0.0.1'
    };

    // Attempt to resolve auth user if authorization header or cookie is present
    if (!req.user && (req.headers.authorization || req.headers.cookie)) {
      try {
        const session = await getSessionFromRequest(req);
        const user = normalizeAuthUser(session?.user);
        if (user) {
          req.user = user;
          req.authSession = session.session;
          c.set('user', user);
          c.set('authSession', session.session);
        }
      } catch (e) {
        // ignore session resolution error in adapter
      }
    }

    let statusCode = 200;
    let resBody = null;
    let headers = {};

    const res = {
      status(code) {
        statusCode = code;
        return res;
      },
      json(data) {
        resBody = data;
        return res;
      },
      send(data) {
        resBody = data;
        return res;
      },
      setHeader(name, val) {
        headers[name] = val;
        return res;
      }
    };

    for (const handler of handlers) {
      let stepErr = null;

      const next = (err) => {
        if (err) stepErr = err;
      };

      await handler(req, res, next);

      if (stepErr) {
        const status = stepErr.status || stepErr.statusCode || 500;
        return c.json({
          status: 'error',
          message: stepErr.message || 'Internal Server Error'
        }, status);
      }

      // If res.json or res.send was called, return response immediately
      if (resBody !== null) {
        return c.json(resBody, statusCode);
      }
    }

    return c.json(resBody || { status: 'success' }, statusCode);
  };
}

export function adaptHandler(handler) {
  return adaptChain(handler);
}
