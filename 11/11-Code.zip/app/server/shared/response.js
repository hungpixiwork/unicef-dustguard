export function success(res, data, statusOrMeta = 200) {
  let statusCode = 200;
  let meta = undefined;
  
  if (typeof statusOrMeta === 'number') {
    statusCode = statusOrMeta;
  } else if (statusOrMeta && typeof statusOrMeta === 'object') {
    meta = statusOrMeta;
  }

  const payload = {
    ok: true,
    data,
  };
  
  if (meta !== undefined) {
    payload.meta = meta;
  }

  return res.status(statusCode).json(payload);
}

export function failure(res, error, statusCode = 500) {
  const code = error?.code || 'INTERNAL_SERVER_ERROR';
  const message = error?.message || 'Đã xảy ra lỗi hệ thống';
  const details = error?.details || {};

  return res.status(statusCode).json({
    ok: false,
    error: {
      code,
      message,
      details,
    },
  });
}
