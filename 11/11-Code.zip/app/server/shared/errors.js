export class AppError extends Error {
  constructor(message, statusCode = 500, code = 'INTERNAL_ERROR', details = {}) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    if (typeof Error.captureStackTrace === 'function') {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Resource not found', details = {}) {
    super(message, 404, 'NOT_FOUND', details);
  }
}

export class ValidationError extends AppError {
  constructor(message = 'Validation failed', details = {}) {
    super(message, 422, 'VALIDATION_ERROR', details);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Unauthorized', details = {}) {
    super(message, 401, 'UNAUTHORIZED', details);
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'Forbidden', details = {}) {
    super(message, 403, 'FORBIDDEN', details);
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Resource conflict', details = {}) {
    super(message, 409, 'CONFLICT', details);
  }
}

export class InvalidStateTransitionError extends AppError {
  constructor(message = 'Invalid state transition', details = {}) {
    super(message, 400, 'INVALID_STATE_TRANSITION', details);
  }
}

export class RateLimitedError extends AppError {
  constructor(message = 'Too many requests, please slow down', details = {}) {
    super(message, 429, 'RATE_LIMITED', details);
  }
}

export class DependencyError extends AppError {
  constructor(message = 'External dependency error', details = {}) {
    super(message, 502, 'DEPENDENCY_ERROR', details);
  }
}
