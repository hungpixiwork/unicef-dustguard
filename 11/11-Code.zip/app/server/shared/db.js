import { createRequire } from 'node:module';

let _prismaInstance = null;
let _d1PrismaInstance = null;
let _sqliteInstance = null;
let _require = null;

function getRequire() {
  if (!_require) {
    try {
      if (typeof import.meta !== 'undefined' && import.meta.url) {
        _require = createRequire(import.meta.url);
      }
    } catch (e) {}
  }
  return _require;
}

/**
 * Creates or retrieves a D1-bound PrismaClient for Cloudflare Worker runtime execution.
 * @param {Env} env Worker environment bindings containing env.DB
 */
export function getDbClient(env) {
  if (env && env.DB) {
    if (!_d1PrismaInstance) {
      try {
        const req = getRequire();
        if (req) {
          const { PrismaClient } = req('@prisma/client');
          const { PrismaD1 } = req('@prisma/adapter-d1');
          const adapter = new PrismaD1(env.DB);
          _d1PrismaInstance = new PrismaClient({ adapter });
        }
      } catch (e) {}
    }
    return _d1PrismaInstance || env.DB;
  }
  if (!_prismaInstance) {
    try {
      const req = getRequire();
      if (req) {
        const { PrismaClient } = req('@prisma/client');
        _prismaInstance = new PrismaClient();
      }
    } catch (e) {}
  }
  return _prismaInstance;
}

/**
 * Universal D1 / SQLite Query Interface
 * Returns native env.DB on Cloudflare Worker, or better-sqlite3 D1-compatible adapter on Node.js.
 */
export function getD1OrSqlite(envOrDb) {
  if (envOrDb && envOrDb.DB && typeof envOrDb.DB.prepare === 'function') {
    return envOrDb.DB;
  }
  if (envOrDb && typeof envOrDb.prepare === 'function') {
    return envOrDb;
  }

  if (!_sqliteInstance) {
    try {
      const req = getRequire();
      if (req) {
        const Database = req('better-sqlite3');
        const fs = req('fs');
        const path = req('path');
        const dbPath = fs.existsSync('prisma/dev.db')
          ? 'prisma/dev.db'
          : (fs.existsSync('app/prisma/dev.db')
              ? 'app/prisma/dev.db'
              : (fs.existsSync('../prisma/dev.db') ? '../prisma/dev.db' : path.resolve(process.cwd(), 'prisma/dev.db')));
        _sqliteInstance = new Database(dbPath);
        _sqliteInstance.pragma('journal_mode = WAL');
        _sqliteInstance.pragma('foreign_keys = ON');
      }
    } catch (e) {}
  }

  if (!_sqliteInstance) {
    return {
      prepare() {
        return {
          bind() { return this; },
          async first() { return null; },
          async all() { return { results: [] }; },
          async run() { return { success: true, meta: { changes: 0, last_row_id: null } }; }
        };
      },
      async batch() { return []; },
      async exec() { return { success: true }; }
    };
  }

  // D1-compatible wrapper over better-sqlite3
  return {
    prepare(sql) {
      function createStmt(args = []) {
        return {
          _sql: sql,
          _args: args,
          bind(...newArgs) {
            return createStmt(newArgs);
          },
          async first() {
            const stmt = _sqliteInstance.prepare(sql);
            return stmt.get(...args) || null;
          },
          async all() {
            const stmt = _sqliteInstance.prepare(sql);
            const rows = stmt.all(...args);
            return { results: rows || [] };
          },
          async run() {
            const stmt = _sqliteInstance.prepare(sql);
            const info = stmt.run(...args);
            return {
              success: true,
              meta: {
                changes: info.changes,
                last_row_id: info.lastInsertRowid
              }
            };
          }
        };
      }
      return createStmt([]);
    },
    async batch(statements) {
      if (!Array.isArray(statements)) {
        throw new Error('db.batch requires an array of prepared statements');
      }
      const results = [];
      const runTx = _sqliteInstance.transaction((stmts) => {
        for (const s of stmts) {
          const prepared = _sqliteInstance.prepare(s._sql);
          if (prepared.reader) {
            const rows = prepared.all(...(s._args || []));
            results.push({
              success: true,
              results: rows || []
            });
          } else {
            const info = prepared.run(...(s._args || []));
            results.push({
              success: true,
              meta: {
                changes: info.changes,
                last_row_id: info.lastInsertRowid
              }
            });
          }
        }
      });
      runTx(statements);
      return results;
    },
    async exec(sql) {
      _sqliteInstance.exec(sql);
      return { success: true };
    }
  };
}

// Lazy proxy for Node.js / dev fallback environments to prevent top-level initialization errors in Workers
export const prisma = new Proxy({}, {
  get(target, prop) {
    if (!_prismaInstance) {
      try {
        const req = getRequire();
        if (req) {
          const { PrismaClient } = req('@prisma/client');
          _prismaInstance = new PrismaClient();
        }
      } catch (e) {}
    }
    return _prismaInstance ? _prismaInstance[prop] : undefined;
  }
});
