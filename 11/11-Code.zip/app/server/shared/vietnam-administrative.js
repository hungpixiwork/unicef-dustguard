/**
 * Vietnam Administrative Dataset & Google Maps Helper SSOT (Backend Worker)
 */

export const VIETNAM_PROVINCES = [
  { code: '01', name: 'Hà Nội', fullName: 'Thành phố Hà Nội' },
  { code: '79', name: 'Hồ Chí Minh', fullName: 'Thành phố Hồ Chí Minh' },
  { code: '48', name: 'Đà Nẵng', fullName: 'Thành phố Đà Nẵng' },
  { code: '31', name: 'Hải Phòng', fullName: 'Thành phố Hải Phòng' },
  { code: '92', name: 'Cần Thơ', fullName: 'Thành phố Cần Thơ' },
  { code: '27', name: 'Bắc Ninh', fullName: 'Tỉnh Bắc Ninh' },
  { code: '22', name: 'Quảng Ninh', fullName: 'Tỉnh Quảng Ninh' },
  { code: '74', name: 'Bình Dương', fullName: 'Tỉnh Bình Dương' },
  { code: '75', name: 'Đồng Nai', fullName: 'Tỉnh Đồng Nai' },
  { code: '77', name: 'Bà Rịa - Vũng Tàu', fullName: 'Tỉnh Bà Rịa - Vũng Tàu' }
];

export const VIETNAM_WARDS_BY_PROVINCE = {
  '01': [
    { code: '00001', name: 'Mai Dịch', fullName: 'Phường Mai Dịch', lat: 21.0384, lng: 105.7768 },
    { code: '00002', name: 'Dịch Vọng Hậu', fullName: 'Phường Dịch Vọng Hậu', lat: 21.0312, lng: 105.7845 },
    { code: '00003', name: 'Dịch Vọng', fullName: 'Phường Dịch Vọng', lat: 21.0345, lng: 105.7923 },
    { code: '00004', name: 'Nghĩa Tân', fullName: 'Phường Nghĩa Tân', lat: 21.0421, lng: 105.7912 },
    { code: '00005', name: 'Nghĩa Đô', fullName: 'Phường Nghĩa Đô', lat: 21.0465, lng: 105.8012 },
    { code: '00006', name: 'Yên Hòa', fullName: 'Phường Yên Hòa', lat: 21.0212, lng: 105.7915 },
    { code: '00007', name: 'Trung Hòa', fullName: 'Phường Trung Hòa', lat: 21.0112, lng: 105.7985 },
    { code: '00008', name: 'Mễ Trì', fullName: 'Phường Mễ Trì', lat: 21.0145, lng: 105.7785 },
    { code: '00009', name: 'Mỹ Đình 1', fullName: 'Phường Mỹ Đình 1', lat: 21.0245, lng: 105.7712 },
    { code: '00010', name: 'Mỹ Đình 2', fullName: 'Phường Mỹ Đình 2', lat: 21.0312, lng: 105.7725 },
    { code: '00011', name: 'Tây Mỗ', fullName: 'Phường Tây Mỗ', lat: 20.9985, lng: 105.7423 },
    { code: '00012', name: 'Đại Mỗ', fullName: 'Phường Đại Mỗ', lat: 20.9885, lng: 105.7512 },
    { code: '00013', name: 'Cổ Nhuế 1', fullName: 'Phường Cổ Nhuế 1', lat: 21.0468, lng: 105.7892 },
    { code: '00014', name: 'Cổ Nhuế 2', fullName: 'Phường Cổ Nhuế 2', lat: 21.0612, lng: 105.7785 },
    { code: '00015', name: 'Xuân Đỉnh', fullName: 'Phường Xuân Đỉnh', lat: 21.0685, lng: 105.7912 },
    { code: '00016', name: 'Đông Ngạc', fullName: 'Phường Đông Ngạc', lat: 21.0854, lng: 105.7791 },
    { code: '00017', name: 'Láng Thượng', fullName: 'Phường Láng Thượng', lat: 21.0215, lng: 105.8089 },
    { code: '00018', name: 'Láng Hạ', fullName: 'Phường Láng Hạ', lat: 21.0145, lng: 105.8123 },
    { code: '00019', name: 'Ô Chợ Dừa', fullName: 'Phường Ô Chợ Dừa', lat: 21.0185, lng: 105.8245 },
    { code: '00020', name: 'Cát Linh', fullName: 'Phường Cát Linh', lat: 21.0295, lng: 105.8272 }
  ],
  '79': [
    { code: '79001', name: 'Bến Nghé', fullName: 'Phường Bến Nghé', lat: 10.7765, lng: 106.7009 },
    { code: '79002', name: 'Bến Thành', fullName: 'Phường Bến Thành', lat: 10.7712, lng: 106.6945 },
    { code: '79003', name: 'Phạm Ngũ Lão', fullName: 'Phường Phạm Ngũ Lão', lat: 10.7685, lng: 106.6912 }
  ]
};
