/**
 * Deterministic / Canonical JSON Serializer for Cryptographic Hashes (DustGuard VN)
 * Ensures identical cryptographic hashes across Node.js, Cloudflare Workers, and Browser environments.
 */

export function canonicalJson(obj) {
  if (obj === null || typeof obj !== 'object') {
    return JSON.stringify(obj);
  }

  if (Array.isArray(obj)) {
    return '[' + obj.map(item => canonicalJson(item)).join(',') + ']';
  }

  const sortedKeys = Object.keys(obj).sort();
  const entries = sortedKeys
    .filter(key => obj[key] !== undefined)
    .map(key => JSON.stringify(key) + ':' + canonicalJson(obj[key]));

  return '{' + entries.join(',') + '}';
}

/**
 * Calculates SHA-256 hex digest of a canonical JSON payload.
 * Supports Web Crypto (Cloudflare Workers / Modern Node.js) with fallback.
 */
export async function canonicalHash(obj) {
  const jsonStr = canonicalJson(obj);
  const encoder = new TextEncoder();
  const data = encoder.encode(jsonStr);

  if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // Node.js crypto fallback
  const nodeCrypto = await import('node:crypto');
  return nodeCrypto.createHash('sha256').update(jsonStr).digest('hex');
}
