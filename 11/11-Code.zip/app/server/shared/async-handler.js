import { failure } from './response.js';

export function asyncHandler(fn) {
  return function (req, res, next) {
    Promise.resolve(fn(req, res, next)).catch((err) => {
      if (err.statusCode || err?.name === 'ZodError') {
        return failure(res, err, err.statusCode || 422);
      }
      next(err);
    });
  };
}
