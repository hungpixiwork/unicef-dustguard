import { Hono } from 'hono';
import {
  generateId,
  formatRfc7807Error,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

router.get('/api/actions', async (c) => {
  try {
    const { limit, offset } = parsePaginationParams(c, 50, 100);
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare('SELECT * FROM actions WHERE deletedAt IS NULL ORDER BY createdAt DESC LIMIT ? OFFSET ?').bind(limit, offset).all();
      return c.json({ status: 'success', data: { items: results || [], pagination: { limit, offset, count: (results || []).length } }, pagination: { limit, offset, count: (results || []).length } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/actions', async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const actionId = generateId('act');
    const now = new Date().toISOString();
    const dueDate = body.dueDate || new Date(Date.now() + 48 * 3600 * 1000).toISOString();

    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        'INSERT INTO actions (id, title, description, status, siteId, assignee, dueDate, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(actionId, body.title || 'Khắc phục vi phạm môi trường', body.description || '', 'PENDING', body.siteId || 'BD-0237', body.assignee || 'Nhà thầu thi công', dueDate, now, now).run();
    }

    return c.json({
      status: 'success',
      data: { id: actionId, ...body, status: 'PENDING', dueDate, createdAt: now },
      message: 'Tạo hành động khắc phục thành công'
    }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/actions/:id', async (c) => {
  try {
    const id = c.req.param('id');
    if (c.env && c.env.DB) {
      const action = await c.env.DB.prepare('SELECT * FROM actions WHERE id = ? AND deletedAt IS NULL').bind(id).first();
      if (!action) {
        return c.json({ status: 'error', message: 'Không tìm thấy hành động' }, 404);
      }
      const site = action.siteId ? await c.env.DB.prepare('SELECT * FROM sites WHERE id = ?').bind(action.siteId).first() : null;
      return c.json({ status: 'success', data: { ...action, site }, message: 'Lấy thông tin hành động thành công' });
    }
    return c.json({ status: 'error', message: 'Không tìm thấy hành động' }, 404);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleUpdateAction = async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();

    if (c.env && c.env.DB) {
      const existing = await c.env.DB.prepare('SELECT * FROM actions WHERE id = ? AND deletedAt IS NULL').bind(id).first();
      if (!existing) {
        return c.json({ status: 'error', message: 'Không tìm thấy hành động' }, 404);
      }

      const status = body.status !== undefined ? body.status : existing.status;
      const description = body.description !== undefined ? body.description : existing.description;
      const assignee = body.assignee !== undefined ? body.assignee : existing.assignee;
      const dueDate = body.dueDate !== undefined ? body.dueDate : existing.dueDate;
      const evidenceUrl = body.evidenceUrl !== undefined ? body.evidenceUrl : existing.evidenceUrl;

      await c.env.DB.prepare(
        'UPDATE actions SET status = ?, description = ?, assignee = ?, dueDate = ?, evidenceUrl = ?, updatedAt = ? WHERE id = ?'
      ).bind(status, description, assignee, dueDate, evidenceUrl, now, id).run();

      return c.json({
        status: 'success',
        data: { id, status, description, assignee, dueDate, evidenceUrl, updatedAt: now },
        message: 'Cập nhật hành động thành công'
      });
    }
    return c.json({ status: 'error', message: 'D1 database không khả dụng' }, 500);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.put('/api/actions/:id', handleUpdateAction);
router.patch('/api/actions/:id', handleUpdateAction);

router.post('/api/actions/:id/verify', async (c) => {
  try {
    const id = c.req.param('id');
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      await c.env.DB.prepare("UPDATE actions SET status = 'VERIFIED', updatedAt = ? WHERE id = ?").bind(now, id).run();
    }
    return c.json({ status: 'success', data: { id, status: 'VERIFIED', updatedAt: now }, message: 'Xác minh hành động hoàn tất' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleDeleteAction = async (c) => {
  try {
    const id = c.req.param('id');
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      const existing = await c.env.DB.prepare('SELECT * FROM actions WHERE id = ? AND deletedAt IS NULL').bind(id).first();
      if (!existing) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy hành động khắc phục để xóa.', c.req.path), 404);
      }
      await c.env.DB.prepare('UPDATE actions SET deletedAt = ? WHERE id = ?').bind(now, existing.id).run();
      return c.json({ status: 'success', data: { id: existing.id, deleted: true }, message: 'Xóa hành động khắc phục thành công' });
    }
    return c.json({ status: 'success', data: { id, deleted: true }, message: 'Xóa hành động khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.delete('/api/actions/:id', handleDeleteAction);

export default router;
