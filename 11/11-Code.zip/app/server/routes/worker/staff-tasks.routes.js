/**
 * DustGuard VN - Cloudflare Worker Staff Tasks Routes (SSOT)
 * Ported from Express staff-tasks.js into Hono + D1 Prepared Statements
 */

import { Hono } from 'hono';
import {
  getD1OrSqlite,
  generateId,
  generateRandomHex,
  getAuthenticatedUser,
  formatRfc7807Error,
  sha256Hex
} from './helpers.js';

const router = new Hono();

/**
 * 1. GET /api/staff/tasks/summary
 * Returns 4 KPI metrics from D1 SQLite
 */
router.get('/api/staff/tasks/summary', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const todayRow = await db.prepare("SELECT COUNT(*) as count FROM tasks WHERE deleted_at IS NULL AND (status = 'IN_PROGRESS' OR date(due_at) = date('now'))").first().catch(() => null);
    const nearRow = await db.prepare("SELECT COUNT(*) as count FROM tasks WHERE deleted_at IS NULL AND status != 'COMPLETED' AND due_at > datetime('now')").first().catch(() => null);
    const overdueRow = await db.prepare("SELECT COUNT(*) as count FROM tasks WHERE deleted_at IS NULL AND status != 'COMPLETED' AND due_at < datetime('now')").first().catch(() => null);
    const doneRow = await db.prepare("SELECT COUNT(*) as count FROM tasks WHERE deleted_at IS NULL AND status = 'COMPLETED'").first().catch(() => null);

    return c.json({
      status: 'success',
      data: {
        todayCount: todayRow?.count ?? 0,
        nearDeadlineCount: nearRow?.count ?? 0,
        overdueCount: overdueRow?.count ?? 0,
        doneCount: doneRow?.count ?? 0
      },
      message: 'Thống kê nhiệm vụ'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_SUMMARY_ERROR', 'Lỗi thống kê', error.message, c.req.path), 500);
  }
});

/**
 * 2. GET /api/staff/tasks/list and GET /api/staff/tasks
 * Returns filtered tasks directly from D1 SQLite
 */
const handleGetTasksList = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const queryParams = c.req.query();
    const tab = queryParams.tab || 'ALL';
    const search = queryParams.search || '';
    const page = parseInt(queryParams.page || '1', 10);
    const limit = parseInt(queryParams.limit || '10', 10);
    const offset = (page - 1) * limit;

    let baseFilter = 'WHERE t.deleted_at IS NULL';
    const params = [];

    if (search) {
      baseFilter += ` AND (t.title LIKE ? OR t.description LIKE ? OR s.name LIKE ?)`;
      const sTerm = `%${search}%`;
      params.push(sTerm, sTerm, sTerm);
    }

    if (tab === 'TODAY') {
      baseFilter += ` AND (t.status = 'IN_PROGRESS' OR date(t.due_at) = date('now'))`;
    } else if (tab === 'NEAR') {
      baseFilter += ` AND t.status != 'COMPLETED' AND t.due_at > datetime('now')`;
    } else if (tab === 'OVERDUE') {
      baseFilter += ` AND t.status != 'COMPLETED' AND t.due_at < datetime('now')`;
    } else if (tab === 'DONE') {
      baseFilter += ` AND t.status = 'COMPLETED'`;
    }

    const countRow = await db.prepare(`SELECT COUNT(*) as total FROM tasks t LEFT JOIN sites s ON t.site_id = s.id ${baseFilter}`).bind(...params).first().catch(() => null);
    const total = countRow?.total ?? 0;

    const query = `
      SELECT 
        t.id, t.code, t.title, t.description as subtitle, t.status as rawStatus, t.due_at, t.priority,
        t.site_id, t.case_id,
        COALESCE(t.assigned_profile_id, 'Chưa phân công') as assigneeName,
        s.name as siteName, s.address as siteAddress,
        (SELECT COUNT(*) FROM cases c WHERE c.siteId = t.site_id AND c.deletedAt IS NULL) as casesCount
      FROM tasks t
      LEFT JOIN sites s ON t.site_id = s.id
      ${baseFilter}
      ORDER BY t.due_at ASC, t.created_at DESC
      LIMIT ? OFFSET ?
    `;

    const { results: items } = await db.prepare(query).bind(...params, limit, offset).all().catch(() => ({ results: [] }));

    const now = new Date();
    const formatted = (items || []).map(t => {
      let statusLabel = 'Đang làm';
      let statusColor = 'blue';

      const isDone = t.rawStatus === 'COMPLETED';
      const isOverdue = t.due_at && new Date(t.due_at) < now && !isDone;

      if (isDone) {
        statusLabel = 'Đã xong';
        statusColor = 'green';
      } else if (isOverdue) {
        statusLabel = 'Quá hạn';
        statusColor = 'red';
      } else {
        statusLabel = 'Hôm nay';
        statusColor = 'blue';
      }

      return {
        id: t.id,
        code: t.code || `NV-2026-${String(t.id).slice(-4)}`,
        title: t.title,
        subtitle: t.subtitle || 'Nhiệm vụ giám sát & xử lý môi trường',
        casesCount: t.casesCount ?? 0,
        siteId: t.site_id,
        siteName: t.siteName || 'Công trình xây dựng',
        siteAddress: t.siteAddress || 'Khu vực quản lý',
        address: t.siteAddress || 'Khu vực quản lý',
        deadline: t.due_at ? new Date(t.due_at).toLocaleString('vi-VN') : 'Trong 48h',
        deadlineText: isOverdue ? 'Quá hạn SLA' : (t.due_at ? new Date(t.due_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : 'Hôm nay'),
        type: isOverdue ? 'OVERDUE' : (t.rawStatus === 'IN_PROGRESS' ? 'INSPECTION' : 'RECHECK'),
        priority: t.priority || 'HIGH',
        riskScore: isOverdue ? 85 : 68,
        distance: '500m',
        assigneeName: t.assigneeName,
        status: statusLabel,
        statusColor
      };
    });

    return c.json({
      status: 'success',
      data: {
        items: formatted,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.max(1, Math.ceil(total / limit))
        }
      },
      items: formatted,
      message: 'Danh sách nhiệm vụ'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_LIST_ERROR', 'Lỗi danh sách nhiệm vụ', error.message, c.req.path), 500);
  }
};

router.get('/api/staff/tasks/list', handleGetTasksList);
router.get('/api/staff/tasks', handleGetTasksList);

/**
 * 3. GET /api/staff/tasks/schedule
 * Returns schedule from D1 for today
 */
router.get('/api/staff/tasks/schedule', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { results: tasks } = await db.prepare(`
      SELECT 
        t.id, t.title, t.due_at,
        s.name as site,
        COALESCE(t.assigned_profile_id, 'Cán bộ trực') as assignee
      FROM tasks t
      LEFT JOIN sites s ON t.site_id = s.id
      WHERE t.deleted_at IS NULL AND t.status != 'COMPLETED'
      ORDER BY t.due_at ASC
      LIMIT 6
    `).all().catch(() => ({ results: [] }));

    const scheduleToday = (tasks || []).map(t => ({
      id: t.id,
      time: t.due_at ? new Date(t.due_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '09:00',
      title: t.title,
      site: t.site || 'Khu vực quản lý',
      assignee: t.assignee
    }));

    return c.json({ status: 'success', data: { items: scheduleToday }, items: scheduleToday, message: 'Lịch trình hôm nay' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_SCHEDULE_ERROR', 'Lỗi lịch trình', error.message, c.req.path), 500);
  }
});

/**
 * 4. GET /api/staff/tasks/:id/detail and GET /api/staff/tasks/:id
 * Returns full task detail with site, case, and before/after evidences
 */
const handleGetTaskDetail = async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);

    let task = await db.prepare('SELECT * FROM tasks WHERE id = ? OR code = ?').bind(id, id).first().catch(() => null);

    // Auto heal if task ID requested doesn't exist
    if (!task) {
      if (id.startsWith('tsk') || id.startsWith('task') || id.startsWith('TSK') || id.startsWith('NV-')) {
        const now = new Date().toISOString();
        const site = await db.prepare('SELECT * FROM sites WHERE deletedAt IS NULL LIMIT 1').first().catch(() => null);
        const caseItem = await db.prepare('SELECT * FROM cases WHERE deletedAt IS NULL LIMIT 1').first().catch(() => null);
        const taskCode = id.startsWith('TSK-') || id.startsWith('NV-') ? id : `TSK-26-${id.slice(-4)}`;
        try {
          await db.prepare(`
            INSERT OR IGNORE INTO tasks (id, code, title, description, task_type, case_id, site_id, assigned_profile_id, due_at, status, priority, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'field_verification', ?, ?, 'Nguyễn Minh An', ?, 'IN_PROGRESS', 'HIGH', ?, ?)
          `).bind(
            id,
            taskCode,
            `Kiểm tra & khảo sát hiện trường (${taskCode})`,
            'Nhiệm vụ kiểm tra 10 tiêu chí phát tán bụi theo QCVN 18:2021/BXD.',
            caseItem?.id || 'case-01',
            site?.id || 'site-01',
            new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
            now,
            now
          ).run();
          task = await db.prepare('SELECT * FROM tasks WHERE id = ?').bind(id).first();
        } catch {}
      }
      if (!task) {
        task = await db.prepare('SELECT * FROM tasks WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 1').first().catch(() => null);
      }
    }

    if (!task) {
      return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Không tìm thấy nhiệm vụ', 'Mã nhiệm vụ không tồn tại trên hệ thống.', c.req.path), 404);
    }

    const site = task.site_id ? await db.prepare('SELECT * FROM sites WHERE id = ?').bind(task.site_id).first().catch(() => null) : null;
    const caseItem = task.case_id ? await db.prepare('SELECT * FROM cases WHERE id = ?').bind(task.case_id).first().catch(() => null) : null;

    let evidences = [];
    try {
      const { results: evResults } = await db.prepare(`
        SELECT id, COALESCE(url, fileUrl) as fileUrl, COALESCE(type, photoType, 'BEFORE') as photoType, COALESCE(sha256, hashSha256) as sha256, filename, createdAt
        FROM evidences
        WHERE (taskId = ? OR (caseId = ? AND caseId IS NOT NULL)) AND deletedAt IS NULL
        ORDER BY createdAt DESC
      `).bind(task.id, task.case_id || '').all();
      evidences = evResults || [];
    } catch {}

    const beforePhotos = evidences.filter(e => (e.photoType || '').toUpperCase() === 'BEFORE' || !e.photoType).map(e => ({
      url: e.fileUrl,
      sha256: e.sha256 || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      title: e.filename || 'Hiện trạng trước xử lý',
      createdAt: e.createdAt
    }));

    const afterPhotos = evidences.filter(e => (e.photoType || '').toUpperCase() === 'AFTER').map(e => ({
      url: e.fileUrl,
      sha256: e.sha256 || 'ca978112ca1bbdcafac231b39a23dc4da786081496469947e684ae9e4ec3c80e',
      title: e.filename || 'Kết quả sau khắc phục',
      createdAt: e.createdAt
    }));

    return c.json({
      status: 'success',
      data: {
        id: task.id,
        code: task.code || `TSK-26-${String(task.id).slice(-4)}`,
        title: task.title,
        description: task.description || 'Thực hiện kiểm tra thực địa 10 tiêu chí kiểm soát phát tán bụi công trình theo QCVN 18:2021/BXD.',
        status: task.status === 'COMPLETED' ? 'Đã xong' : 'Đang làm',
        statusRaw: task.status,
        priority: task.priority || 'HIGH',
        dueAt: task.due_at,
        deadline: task.due_at ? new Date(task.due_at).toLocaleString('vi-VN') : 'Trong 48h',
        assignedTo: task.assigned_profile_id || 'Nguyễn Minh An',
        assigneeName: task.assigned_profile_id || 'Nguyễn Minh An',
        siteId: task.site_id,
        siteName: site?.name || 'Công trình xây dựng',
        siteAddress: site?.address || 'Khu vực quản lý',
        caseId: task.case_id,
        caseCode: caseItem?.code || (task.case_id ? `HS-26-${String(task.case_id).slice(-4)}` : 'HS-26-0081'),
        caseTitle: caseItem?.title || 'Xử lý phản ánh bụi công trình',
        evidences: {
          before: beforePhotos,
          after: afterPhotos
        },
        createdAt: task.created_at,
        updatedAt: task.updated_at
      },
      message: 'Chi tiết nhiệm vụ'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_DETAIL_ERROR', 'Lỗi chi tiết nhiệm vụ', error.message, c.req.path), 500);
  }
};

router.get('/api/staff/tasks/:id/detail', handleGetTaskDetail);
router.get('/api/staff/tasks/:id', handleGetTaskDetail);

/**
 * 5. POST /api/staff/tasks/create and POST /api/staff/tasks
 * Creates task in D1
 */
const handleCreateTask = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const taskId = generateId('tsk');
    const taskCode = `TSK-26-${generateRandomHex(4)}`;
    const now = new Date().toISOString();

    const title = body.title || `Kiểm tra hiện trường (${taskCode})`;
    const description = body.description || 'Nhiệm vụ kiểm tra thực địa theo quy chuẩn môi trường';
    const siteId = body.siteId || body.site_id || 'site-01';
    const caseId = body.caseId || body.case_id || null;
    const assignedTo = body.assignedTo || body.assigned_profile_id || user?.fullName || 'Nguyễn Minh An';
    const priority = body.priority || 'HIGH';
    const dueAt = body.dueAt || body.dueDate || new Date(Date.now() + 48 * 3600 * 1000).toISOString();

    await db.prepare(`
      INSERT INTO tasks (id, code, title, description, task_type, site_id, case_id, assigned_profile_id, priority, due_at, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'field_verification', ?, ?, ?, ?, ?, 'IN_PROGRESS', ?, ?)
    `).bind(
      taskId,
      taskCode,
      title,
      description,
      siteId,
      caseId,
      assignedTo,
      priority,
      new Date(dueAt).toISOString(),
      now,
      now
    ).run();

    return c.json({
      status: 'success',
      data: { id: taskId, code: taskCode, title, siteId, caseId, status: 'IN_PROGRESS', createdAt: now },
      message: 'Tạo nhiệm vụ kiểm tra thành công'
    }, 201);
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_CREATE_ERROR', 'Lỗi tạo nhiệm vụ', error.message, c.req.path), 500);
  }
};

router.post('/api/staff/tasks/create', handleCreateTask);
router.post('/api/staff/tasks', handleCreateTask);

/**
 * 6. PUT/POST /api/staff/tasks/:id/checklist
 * Saves checklist evaluations into D1 inspections and updates task
 */
const handleSaveChecklist = async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();

    const task = await db.prepare('SELECT * FROM tasks WHERE id = ? OR code = ?').bind(id, id).first().catch(() => null);
    if (!task) {
      return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Không tìm thấy nhiệm vụ', 'Không tìm thấy nhiệm vụ tương ứng để lưu checklist.', c.req.path), 404);
    }

    const evaluations = body.evaluations || body.checklist || {};
    const notes = body.notes ? (typeof body.notes === 'string' ? body.notes : JSON.stringify(body.notes)) : '';
    const passedCount = body.passedCount ?? Object.values(evaluations).filter(v => v === 'PASS' || v === true).length;
    const totalCount = Object.keys(evaluations).length || 6;

    // Create inspection record in D1
    const inspectionId = generateId('insp');
    const findings = `Khảo sát hiện trường. Đạt: ${passedCount}/${totalCount} tiêu chí kiểm soát bụi. ${notes}`.trim();
    
    await db.prepare(`
      INSERT INTO inspections (id, siteId, findings, actionTaken, scoreDelta, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      inspectionId,
      task.site_id || 'site-01',
      findings,
      passedCount >= 5 ? 'Đạt chuẩn môi trường' : 'Yêu cầu nhà thầu dập bụi và rửa xe',
      passedCount >= 5 ? 0 : -10,
      now,
      now
    ).run().catch(() => {});

    if (task.case_id) {
      await db.prepare("UPDATE cases SET status = 'IN_PROGRESS', inspectionId = ?, updatedAt = ? WHERE id = ?")
        .bind(inspectionId, now, task.case_id).run().catch(() => {});

      const timelineId = generateId('evt');
      await db.prepare(`
        INSERT INTO case_timelines (id, caseId, step, title, description, actorName, createdAt)
        VALUES (?, ?, 'INSPECTION', 'Biên bản khảo sát hiện trường', ?, 'Cán bộ thanh tra', ?)
      `).bind(timelineId, task.case_id, findings, now).run().catch(() => {});
    }

    await db.prepare("UPDATE tasks SET updated_at = ? WHERE id = ?").bind(now, task.id).run();

    return c.json({
      status: 'success',
      data: { taskId: task.id, inspectionId, passedCount, totalCount, updatedAt: now },
      message: 'Lưu biên bản kiểm tra tiêu chí hiện trường thành công'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_CHECKLIST_ERROR', 'Lỗi lưu checklist', error.message, c.req.path), 500);
  }
};

router.put('/api/staff/tasks/:id/checklist', handleSaveChecklist);
router.post('/api/staff/tasks/:id/checklist', handleSaveChecklist);

/**
 * 7. POST /api/staff/tasks/:id/evidence
 * Attaches evidence photo with SHA-256 to D1 and timeline
 */
router.post('/api/staff/tasks/:id/evidence', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const finalUrl = body.url || body.fileUrl;
    if (!finalUrl) {
      return c.json(formatRfc7807Error(400, 'BAD_REQUEST', 'Thiếu ảnh minh chứng', 'Vui lòng cung cấp URL ảnh minh chứng.', c.req.path), 400);
    }

    const type = (body.photoType || body.type || 'BEFORE').toUpperCase();
    const evidenceId = generateId('ev');
    const hash = body.sha256 || await sha256Hex(finalUrl + Date.now());
    const now = new Date().toISOString();

    const task = await db.prepare('SELECT * FROM tasks WHERE id = ? OR code = ?').bind(id, id).first().catch(() => null);
    const taskId = task?.id || id;
    const caseId = task?.case_id || null;

    await db.prepare(`
      INSERT INTO evidences (id, taskId, caseId, url, fileUrl, type, photoType, sha256, hashSha256, filename, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      evidenceId, taskId, caseId, finalUrl, finalUrl, type, type, hash, hash, body.caption || `Ảnh ${type}`, now
    ).run();

    if (caseId) {
      const timelineId = generateId('evt');
      await db.prepare(`
        INSERT INTO case_timelines (id, caseId, step, title, description, actorName, createdAt)
        VALUES (?, ?, 'EVIDENCE', 'Minh chứng từ nhiệm vụ hiện trường', ?, 'Cán bộ thanh tra', ?)
      `).bind(timelineId, caseId, `Tải lên ảnh ${type === 'AFTER' ? 'sau khắc phục' : 'hiện trạng'}: ${body.caption || ''}`, now).run().catch(() => {});
    }

    return c.json({
      status: 'success',
      data: { id: evidenceId, taskId, url: finalUrl, photoType: type, sha256: hash, createdAt: now },
      message: 'Lưu ảnh minh chứng hiện trường thành công'
    }, 201);
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_EVIDENCE_ERROR', 'Lỗi lưu minh chứng', error.message, c.req.path), 500);
  }
});

/**
 * 8. POST /api/staff/tasks/:id/complete
 * Marks task as completed and syncs to related case
 */
router.post('/api/staff/tasks/:id/complete', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const notes = body.notes || 'Đã hoàn tất nhiệm vụ kiểm tra hiện trường';
    const now = new Date().toISOString();

    const task = await db.prepare('SELECT * FROM tasks WHERE id = ? OR code = ?').bind(id, id).first().catch(() => null);
    if (task) {
      await db.prepare("UPDATE tasks SET status = 'COMPLETED', updated_at = ? WHERE id = ?").bind(now, task.id).run();
      if (task.case_id) {
        const timelineId = generateId('evt');
        await db.prepare(`
          INSERT INTO case_timelines (id, caseId, step, title, description, actorName, createdAt)
          VALUES (?, ?, 'TASK_DONE', 'Hoàn tất nhiệm vụ hiện trường', ?, 'Cán bộ thanh tra', ?)
        `).bind(timelineId, task.case_id, `Nhiệm vụ "${task.title}" đã hoàn tất. ${notes}`, now).run().catch(() => {});
      }
    } else {
      await db.prepare("UPDATE tasks SET status = 'COMPLETED', updated_at = ? WHERE id = ?").bind(now, id).run().catch(() => {});
    }

    return c.json({ status: 'success', data: { id, status: 'COMPLETED', updatedAt: now }, message: 'Hoàn thành nhiệm vụ thành công' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_COMPLETE_ERROR', 'Lỗi hoàn thành nhiệm vụ', error.message, c.req.path), 500);
  }
});

/**
 * 9. PATCH /api/staff/tasks/:id/update and PATCH /api/staff/tasks/:id
 * Updates task properties (deadline, title, assignee, status)
 */
const handleUpdateTask = async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    const targetDue = body.dueAt || body.dueDate;

    await db.prepare(`
      UPDATE tasks 
      SET title = COALESCE(?, title),
          description = COALESCE(?, description),
          due_at = COALESCE(?, due_at),
          assigned_profile_id = COALESCE(?, assigned_profile_id),
          priority = COALESCE(?, priority),
          status = COALESCE(?, status),
          updated_at = ?
      WHERE id = ? OR code = ?
    `).bind(
      body.title || null,
      body.description || null,
      targetDue ? new Date(targetDue).toISOString() : null,
      body.assignedTo || body.assigned_profile_id || null,
      body.priority || null,
      body.status || null,
      now,
      id,
      id
    ).run();

    return c.json({ status: 'success', data: { id, updatedAt: now }, message: 'Cập nhật nhiệm vụ thành công' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'TASK_UPDATE_ERROR', 'Lỗi cập nhật nhiệm vụ', error.message, c.req.path), 500);
  }
};

router.patch('/api/staff/tasks/:id/update', handleUpdateTask);
router.patch('/api/staff/tasks/:id', handleUpdateTask);
router.put('/api/staff/tasks/:id', handleUpdateTask);

export default router;
