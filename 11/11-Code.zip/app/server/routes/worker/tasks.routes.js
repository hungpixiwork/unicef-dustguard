import { Hono } from 'hono';
import {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  archiveTask,
  joinTask,
  startTask,
  submitTaskProof,
  approveSubmission,
  requestRevision,
  getTaskCounters
} from '../../repositories/task.repository.js';
import { getD1OrSqlite } from './helpers.js';

const router = new Hono();

router.get('/api/tasks/counters', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const data = await getTaskCounters(db);
    return c.json({ status: 'success', data, message: 'Lấy thống kê nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/tasks', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const query = c.req.query();
    const user = c.get('user');
    const current_user_id = user?.id || c.req.header('x-user-id') || null;
    const current_profile_id = user?.profileId || user?.id || c.req.header('x-profile-id') || null;

    const data = await getTasks(db, {
      status: query.status,
      task_type: query.task_type,
      assignment_type: query.assignment_type,
      campaign_id: query.campaign_id,
      case_id: query.case_id,
      site_id: query.site_id,
      club_id: query.club_id,
      assigned_profile_id: query.assigned_profile_id,
      current_user_id,
      current_profile_id,
      search: query.search,
      include_archived: query.include_archived === 'true',
      limit: query.limit ? Number(query.limit) : 50,
      offset: query.offset ? Number(query.offset) : 0
    });

    return c.json({ status: 'success', data, message: 'Lấy danh sách nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/tasks/:id', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const user = c.get('user');
    const current_user_id = user?.id || c.req.header('x-user-id') || null;
    const task = await getTaskById(db, c.req.param('id'), current_user_id);
    if (!task) return c.json({ status: 'error', message: 'Nhiệm vụ không tồn tại' }, 404);

    return c.json({ status: 'success', data: task, message: 'Lấy chi tiết nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/tasks', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const actor = {
      id: user?.id || 'staff_system',
      email: user?.email || 'staff@dustguard.vn',
      name: user?.fullName || user?.name || 'Cán bộ điều phối',
      role: user?.role || 'staff'
    };

    const task = await createTask(db, body, actor);
    return c.json({ status: 'success', data: task, message: 'Tạo nhiệm vụ thành công' }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.patch('/api/tasks/:id', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const actor = {
      id: user?.id || 'staff_system',
      email: user?.email || 'staff@dustguard.vn',
      name: user?.fullName || user?.name || 'Cán bộ điều phối',
      role: user?.role || 'staff'
    };

    const task = await updateTask(db, c.req.param('id'), body, actor);
    return c.json({ status: 'success', data: task, message: 'Cập nhật nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/archive', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const user = c.get('user');
    const actor = {
      id: user?.id || 'staff_system',
      email: user?.email || 'staff@dustguard.vn',
      role: user?.role || 'staff'
    };

    const result = await archiveTask(db, c.req.param('id'), actor);
    return c.json({ status: 'success', data: result, message: 'Lưu trữ nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/join', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const user_id = user?.id || body.user_id || c.req.header('x-user-id') || 'user_1';
    const profile_id = user?.profileId || body.profile_id || user_id;
    const club_id = body.club_id || user?.club_id || null;
    const full_name = body.full_name || user?.fullName || user?.name || 'Tình nguyện viên';

    const result = await joinTask(db, c.req.param('id'), {
      user_id,
      profile_id,
      club_id,
      full_name
    });

    return c.json({ status: 'success', data: result, message: 'Nhận nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/start', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const user_id = user?.id || body.user_id || c.req.header('x-user-id') || 'user_1';
    const profile_id = user?.profileId || body.profile_id || user_id;

    const result = await startTask(db, c.req.param('id'), { user_id, profile_id });
    return c.json({ status: 'success', data: result, message: 'Bắt đầu nhiệm vụ thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/submit', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const user_id = user?.id || body.user_id || c.req.header('x-user-id') || 'user_1';
    const profile_id = user?.profileId || body.profile_id || user_id;
    const { image_url, image_hash, outcome, notes, latitude, longitude } = body;

    const result = await submitTaskProof(db, c.req.param('id'), {
      user_id,
      profile_id,
      image_url,
      image_hash,
      outcome,
      notes,
      latitude,
      longitude
    });

    return c.json({ status: 'success', data: result, message: 'Nộp minh chứng thành công, hồ sơ chuyển sang Chờ xác minh' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/task-submissions/:id/approve', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const reviewer_id = user?.id || 'staff_system';
    const reviewer_name = user?.fullName || user?.name || 'Cán bộ nghiệm thu';

    const result = await approveSubmission(db, c.req.param('id'), {
      reviewer_id,
      reviewer_name,
      review_note: body.review_note
    });

    return c.json({ status: 'success', data: result, message: 'Đã duyệt nghiệm thu và ghi nhận đóng góp thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/task-submissions/:id/request-revision', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const reviewer_id = user?.id || 'staff_system';
    const reviewer_name = user?.fullName || user?.name || 'Cán bộ thẩm định';

    const result = await requestRevision(db, c.req.param('id'), {
      reviewer_id,
      reviewer_name,
      review_note: body.review_note
    });

    return c.json({ status: 'success', data: result, message: 'Đã gửi yêu cầu làm lại minh chứng' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/submissions/:subId/approve', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const reviewer_id = user?.id || 'staff_system';
    const reviewer_name = user?.fullName || user?.name || 'Cán bộ nghiệm thu';

    const result = await approveSubmission(db, c.req.param('subId'), {
      reviewer_id,
      reviewer_name,
      review_note: body.review_note
    });

    return c.json({ status: 'success', data: result, message: 'Đã duyệt nghiệm thu và ghi nhận đóng góp thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/tasks/:id/submissions/:subId/request-revision', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user');
    const reviewer_id = user?.id || 'staff_system';
    const reviewer_name = user?.fullName || user?.name || 'Cán bộ thẩm định';

    const result = await requestRevision(db, c.req.param('subId'), {
      reviewer_id,
      reviewer_name,
      review_note: body.review_note
    });

    return c.json({ status: 'success', data: result, message: 'Đã gửi yêu cầu làm lại minh chứng' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

export default router;
