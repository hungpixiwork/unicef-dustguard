import { Hono } from 'hono';
import { DustRiskEngine } from '../../domain/risk/dust-risk-engine.js';
import {
  generateId,
  generateRandomCode,
  getAuthenticatedUser,
  getD1OrSqlite,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

export const DEFAULT_CHECKLIST = {
  barrier: 'pass', spray: 'pass', cover: 'pass', wheel: 'pass', spill: 'pass',
  demo: 'pass', hours: 'pass', gate: 'pass', height: 'pass', signage: 'pass'
};

export const CHECKLIST_METADATA = [
  { id: 'chk_01', key: 'barrier', label: 'Hàng rào bao che kín quanh công trường', legalRef: 'QCVN 18:2021/BXD Mục 2.1', weight: 15 },
  { id: 'chk_02', key: 'spray', label: 'Hệ thống phun nước dập bụi hoạt động', legalRef: 'QCVN 18:2021/BXD Mục 2.3', weight: 15 },
  { id: 'chk_03', key: 'cover', label: 'Bạt phủ kín vật liệu rời & bãi đất', legalRef: 'Nghị định 45/2022/NĐ-CP Điều 43', weight: 15 },
  { id: 'chk_04', key: 'wheel', label: 'Cầu rửa xe & xịt lốp trước khi ra đường', legalRef: 'Nghị định 16/2022/NĐ-CP Điều 16', weight: 15 },
  { id: 'chk_05', key: 'spill', label: 'Không rơi vãi phế thải ra đường phố', legalRef: 'Luật BVMT 2020 Điều 64', weight: 10 },
  { id: 'chk_06', key: 'demo', label: 'Phun ẩm liên tục khi phá dỡ kết cấu', legalRef: 'QCVN 18:2021/BXD Mục 3.1', weight: 10 },
  { id: 'chk_07', key: 'hours', label: 'Tuân thủ giờ giấc thi công hạn chế bụi đêm', legalRef: 'QCVN 26:2010/BTNMT', weight: 5 },
  { id: 'chk_08', key: 'gate', label: 'Cổng công trình đóng kín khi thi công', legalRef: 'QCVN 18:2021/BXD Mục 2.2', weight: 5 },
  { id: 'chk_09', key: 'height', label: 'Ống dẫn xả rác/bụi từ tầng cao xuống', legalRef: 'QCVN 18:2021/BXD Mục 2.5', weight: 5 },
  { id: 'chk_10', key: 'signage', label: 'Biển báo thông tin bảo vệ môi trường & hotline', legalRef: 'Nghị định 16/2022/NĐ-CP', weight: 5 }
];

export function formatWorkerSite(s) {
  const dustRiskScore = s.dustRiskScore ?? 50;
  const priorityScore = dustRiskScore;
  const riskAnalysis = DustRiskEngine.calculate({
    telemetry: {
      pm10: s.currentPm10 || (dustRiskScore >= 80 ? 145 : dustRiskScore >= 50 ? 95 : 45),
      pm25: s.currentPm25 || (dustRiskScore >= 80 ? 82 : dustRiskScore >= 50 ? 55 : 32),
      lastReadingAt: s.updatedAt || s.createdAt
    },
    observationCount: s.observationCount || 1,
    unresolvedCount: s.unresolvedCount || 0,
    sensitiveReceptors: s.near || ['SCHOOL'],
    complianceChecklist: s.checklist || DEFAULT_CHECKLIST
  });

  const riskLevel = s.riskLevel || (dustRiskScore >= 80 ? 'CRITICAL' : dustRiskScore >= 70 ? 'HIGH' : dustRiskScore >= 40 ? 'MEDIUM' : 'LOW');
  const priorityLevel = riskLevel;
  const priorityTier = dustRiskScore >= 70 ? 'red' : dustRiskScore >= 40 ? 'amber' : 'green';
  const gaugeData = {
    pm25: s.currentPm25 || (dustRiskScore >= 80 ? 82 : dustRiskScore >= 50 ? 55 : 32),
    score: priorityScore,
    priorityScore,
    status: priorityLevel,
    color: dustRiskScore >= 80 ? '#9f241f' : dustRiskScore >= 50 ? '#d97706' : '#0d6f64'
  };
  return {
    ...s,
    priorityScore,
    priorityLevel,
    priorityTier,
    dustRiskScore,
    riskLevel,
    checklist: s.checklist || DEFAULT_CHECKLIST,
    gaugeData,
    gauge: gaugeData,
    riskAnalysis,
    riskEngine: riskAnalysis
  };
}

router.get('/api/checklists', (c) => {
  c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
  return c.json({ status: 'success', data: { items: CHECKLIST_METADATA } });
});

const handleGetSites = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const userRole = (user?.role || user?.primaryRole || '').toLowerCase();
    const userRoles = (user?.roles || [userRole]).map(r => r.toLowerCase());
    const isPrivileged = user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    const { limit, offset } = parsePaginationParams(c, 50, 100);
    const db = getD1OrSqlite(c.env);
    const { results } = await db.prepare('SELECT * FROM sites WHERE deletedAt IS NULL ORDER BY name ASC LIMIT ? OFFSET ?').bind(limit, offset).all();
    const items = (results && results.length > 0) ? results.map(s => {
      const formatted = formatWorkerSite(s);
      if (!isPrivileged) {
        formatted.managerPhone = null;
        formatted.managerEmail = null;
      }
      return formatted;
    }) : [];
    return c.json({ status: 'success', data: { items, pagination: { limit, offset, count: items.length } }, items, pagination: { limit, offset, count: items.length } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

const handleGetSiteById = async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    const userRole = (user?.role || user?.primaryRole || '').toLowerCase();
    const userRoles = (user?.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    const db = getD1OrSqlite(c.env);
    const site = await db.prepare('SELECT * FROM sites WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
    if (site) {
      const isSiteContractor = user && (userRole === 'contractor' || userRoles.includes('contractor') || userRole === 'demo_contractor') &&
        (site.contractorId === user.id || site.contractorName === user.fullName || site.contractorName === user.name || site.managerEmail === user.email);

      const isPrivileged = isStaffOrAdmin || isSiteContractor;

      const { results: sensors } = await db.prepare('SELECT * FROM sensors WHERE siteId = ?').bind(site.id).all().catch(() => ({ results: [] }));
      const { results: inspections } = await db.prepare('SELECT * FROM inspections WHERE siteId = ? AND deletedAt IS NULL ORDER BY createdAt DESC').bind(site.id).all().catch(() => ({ results: [] }));
      const { results: actions } = await db.prepare('SELECT * FROM actions WHERE siteId = ? AND deletedAt IS NULL ORDER BY createdAt DESC').bind(site.id).all().catch(() => ({ results: [] }));
      const { results: complaints } = await db.prepare('SELECT * FROM complaints WHERE siteId = ? AND deletedAt IS NULL ORDER BY createdAt DESC').bind(site.id).all().catch(() => ({ results: [] }));
      const { results: cases } = await db.prepare('SELECT * FROM cases WHERE siteId = ? AND deletedAt IS NULL ORDER BY createdAt DESC').bind(site.id).all().catch(() => ({ results: [] }));

      const parsedInspections = (inspections || []).map(ins => {
        let findings = ins.findings;
        if (typeof findings === 'string') {
          try {
            findings = JSON.parse(findings);
          } catch (e) {
            findings = {};
          }
        }
        return {
          ...ins,
          findings
        };
      });

      const formatted = formatWorkerSite(site);

      if (!isPrivileged) {
        formatted.managerPhone = null;
        formatted.managerEmail = null;
      }

      return c.json({
        status: 'success',
        data: {
          ...formatted,
          sensors: sensors || [],
          inspections: isPrivileged ? parsedInspections : [],
          actions: actions || [],
          complaints: complaints || [],
          cases: isPrivileged ? (cases || []) : []
        }
      });
    }
    return c.json({
      status: 'error',
      statusCode: 404,
      code: 'SITE_NOT_FOUND',
      message: `Không tìm thấy công trình với mã hoặc ID "${id}".`
    }, 404);
  } catch (err) {
    return c.json({
      status: 'error',
      statusCode: 500,
      code: 'SITE_LOOKUP_ERROR',
      message: err.message || 'Lỗi truy vấn dữ liệu công trình'
    }, 500);
  }
};

router.get('/api/sites', handleGetSites);
router.get('/api/public/sites', handleGetSites);
router.get('/api/v1/sites', handleGetSites);
router.get('/api/v1/public/sites', handleGetSites);
router.get('/api/sites/:id', handleGetSiteById);
router.get('/api/v1/sites/:id', handleGetSiteById);
router.get('/api/public/sites/:id', handleGetSiteById);
router.get('/api/v1/public/sites/:id', handleGetSiteById);

router.get('/api/sites/:id/risk-analysis', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    const site = await db.prepare('SELECT * FROM sites WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
    if (!site) {
      return c.json({ status: 'error', statusCode: 404, message: 'Không tìm thấy công trường' }, 404);
    }
    const formatted = formatWorkerSite(site);
    return c.json({
      status: 'success',
      data: {
        siteId: site.id,
        siteName: site.name,
        ...formatted.riskAnalysis
      }
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleCreateSite = async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    if (!body.name || !body.address) {
      return c.json({ status: 'error', message: 'Tên và địa chỉ công trình là bắt buộc' }, 400);
    }
    const siteId = generateId('site');
    const code = body.code || generateRandomCode('BD', 1000, 9999);
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      await db.prepare(
        'INSERT INTO sites (id, code, name, address, ward, province, coordinates, managerName, contractorName, dustRiskScore, riskLevel, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(
        siteId,
        code,
        body.name,
        body.address,
        body.ward || 'Phường Dịch Vọng, Cầu Giấy',
        body.province || 'Hà Nội',
        body.coordinates || null,
        body.managerName || 'Nguyễn Văn An',
        body.contractorName || null,
        body.dustRiskScore || 50,
        body.riskLevel || 'MEDIUM',
        body.status || 'ACTIVE',
        now,
        now
      ).run();
    }

    return c.json({
      status: 'success',
      data: { id: siteId, code, ...body, createdAt: now },
      message: 'Tạo công trình thành công'
    }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.post('/api/sites', handleCreateSite);
router.post('/api/v1/sites', handleCreateSite);
router.post('/api/staff/sites/create', handleCreateSite);
router.post('/api/v1/staff/sites/create', handleCreateSite);

const handleUpdateSite = async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();

    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        'UPDATE sites SET name = COALESCE(?, name), address = COALESCE(?, address), ward = COALESCE(?, ward), dustRiskScore = COALESCE(?, dustRiskScore), riskLevel = COALESCE(?, riskLevel), status = COALESCE(?, status), updatedAt = ? WHERE (id = ? OR code = ?)'
      ).bind(body.name || null, body.address || null, body.ward || null, body.dustRiskScore || null, body.riskLevel || null, body.status || null, now, id, id).run();
    }

    return c.json({ status: 'success', data: { id, ...body, updatedAt: now }, message: 'Cập nhật công trường thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.put('/api/sites/:id', handleUpdateSite);
router.put('/api/v1/sites/:id', handleUpdateSite);
router.patch('/api/sites/:id', handleUpdateSite);
router.patch('/api/v1/sites/:id', handleUpdateSite);

const handleDeleteSite = async (c) => {
  try {
    const id = c.req.param('id');
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      await c.env.DB.prepare('UPDATE sites SET deletedAt = ? WHERE id = ? OR code = ?').bind(now, id, id).run();
    }
    return c.json({ status: 'success', message: 'Xóa công trường thành công (Soft Delete)' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.delete('/api/sites/:id', handleDeleteSite);
router.delete('/api/v1/sites/:id', handleDeleteSite);

router.post('/api/sites/:id/assign-inspector', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const inspectorName = body.inspectorName || 'Cán bộ Thanh tra';
    const slaHours = parseInt(body.slaHours || '48', 10);
    const dueDate = new Date(Date.now() + slaHours * 3600 * 1000).toISOString();
    const actionId = generateId('act');
    const now = new Date().toISOString();

    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        'INSERT INTO actions (id, title, description, status, siteId, assignee, dueDate, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(actionId, `Phân công kiểm tra: ${inspectorName}`, body.note || `Yêu cầu kiểm tra thực địa (SLA ${slaHours}h)`, 'PENDING', id, inspectorName, dueDate, now, now).run();

      const auditId = generateId('aud');
      await c.env.DB.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(auditId, user?.name || 'Lãnh đạo cơ quan', user?.role || 'executive', 'INSPECTOR_ASSIGNMENT', id, JSON.stringify({ inspectorName, slaHours, actionId }), now).run();
    }

    return c.json({
      status: 'success',
      data: { siteId: id, inspectorName, slaHours, dueDate, actionId },
      message: 'Phân công cán bộ thanh tra thành công'
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/sites/:id/sensors', async (c) => {
  try {
    const id = c.req.param('id');
    const { limit, offset } = parsePaginationParams(c, 50, 100);
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare('SELECT * FROM sensors WHERE siteId = ? LIMIT ? OFFSET ?').bind(id, limit, offset).all();
      return c.json({ status: 'success', data: { items: results || [], pagination: { limit, offset, count: (results || []).length } } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/sites/:id/readings', async (c) => {
  try {
    const id = c.req.param('id');
    const { limit, offset } = parsePaginationParams(c, 50, 100);
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare(
        'SELECT r.* FROM sensor_readings r JOIN sensors s ON r.sensorId = s.id WHERE s.siteId = ? ORDER BY r.timestamp DESC LIMIT ? OFFSET ?'
      ).bind(id, limit, offset).all();
      return c.json({ status: 'success', data: { items: results || [], pagination: { limit, offset, count: (results || []).length } } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

export default router;
