import { Hono } from 'hono';
import {
  generateId,
  getAuthenticatedUser,
  formatRfc7807Error,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

router.get('/api/inspections', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để xem danh sách biên bản kiểm tra.', c.req.path), 401);
    }
    const userRole = (user.role || user.primaryRole || '').toLowerCase();
    const userRoles = (user.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    if (!isStaffOrAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ cán bộ quản lý (Staff/Inspector/Executive/Admin) được xem biên bản kiểm tra nội bộ.', c.req.path), 403);
    }

    const { limit, offset } = parsePaginationParams(c, 50, 100);
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare('SELECT * FROM inspections WHERE deletedAt IS NULL ORDER BY createdAt DESC LIMIT ? OFFSET ?').bind(limit, offset).all();
      return c.json({ status: 'success', data: { items: results || [], pagination: { limit, offset, count: (results || []).length } }, pagination: { limit, offset, count: (results || []).length } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/inspections/:id', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để xem chi tiết biên bản kiểm tra.', c.req.path), 401);
    }
    const userRole = (user.role || user.primaryRole || '').toLowerCase();
    const userRoles = (user.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    if (!isStaffOrAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền xem biên bản kiểm tra nội bộ.', c.req.path), 403);
    }

    const id = c.req.param('id');
    if (c.env && c.env.DB) {
      const inspection = await c.env.DB.prepare('SELECT * FROM inspections WHERE id = ? AND deletedAt IS NULL').bind(id).first();
      if (!inspection) {
        return c.json({ status: 'error', message: 'Không tìm thấy biên bản kiểm tra' }, 404);
      }
      const site = inspection.siteId ? await c.env.DB.prepare('SELECT * FROM sites WHERE id = ?').bind(inspection.siteId).first() : null;
      const { results: evidences } = await c.env.DB.prepare('SELECT * FROM evidences WHERE inspectionId = ?').bind(inspection.id).all().catch(() => ({ results: [] }));
      return c.json({
        status: 'success',
        data: {
          ...inspection,
          site,
          evidences: evidences || []
        },
        message: 'Lấy thông tin biên bản kiểm tra thành công'
      });
    }
    return c.json({ status: 'error', message: 'Không tìm thấy biên bản kiểm tra' }, 404);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/inspections', async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const inspectionId = generateId('ins');
    const now = new Date().toISOString();
    const inspectorId = body.inspectorId || body.inspectorName || 'Nguyễn Văn An';
    const actionTaken = body.actionTaken || 'Nhắc nhở và lập biên bản';
    const scoreDelta = typeof body.scoreDelta === 'number' ? body.scoreDelta : 0;
    const findingsStr = typeof body.findings === 'string' ? body.findings : JSON.stringify(body.findings || {});

    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        'INSERT INTO inspections (id, siteId, inspectorId, findings, actionTaken, scoreDelta, sourceComplaintId, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(inspectionId, body.siteId || 'BD-0237', inspectorId, findingsStr, actionTaken, scoreDelta, body.sourceComplaintId || null, now, now).run();
    }

    return c.json({ status: 'success', data: { id: inspectionId, ...body, inspectorId, actionTaken, scoreDelta, createdAt: now }, message: 'Lập biên bản kiểm tra thành công' }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleDeleteInspection = async (c) => {
  try {
    const id = c.req.param('id');
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      const existing = await c.env.DB.prepare('SELECT * FROM inspections WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy biên bản kiểm tra để xóa.', c.req.path), 404);
      }
      await c.env.DB.prepare('UPDATE inspections SET deletedAt = ? WHERE id = ?').bind(now, existing.id).run();
      return c.json({ status: 'success', data: { id: existing.id, deleted: true }, message: 'Xóa biên bản kiểm tra thành công' });
    }
    return c.json({ status: 'success', data: { id, deleted: true }, message: 'Xóa biên bản kiểm tra thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.delete('/api/inspections/:id', handleDeleteInspection);

export default router;
