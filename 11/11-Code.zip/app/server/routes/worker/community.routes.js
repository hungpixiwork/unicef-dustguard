import { Hono } from 'hono';
import {
  calculateVolunteerHours,
  verifyStudentCredit,
  generateImpactCertificate,
  calculateProgressGoal,
  getTopClubsLeaderboard
} from '../../../src/lib/youth-credits.js';
import {
  createObservation,
  getObservationById,
  getObservations,
  updateObservationStatus,
  maskObservationForPublic
} from '../../repositories/observation.repository.js';
import {
  createFollowUp,
  getFollowUpsByObservationId
} from '../../repositories/followup.repository.js';
import {
  createHandoff,
  getHandoffById,
  updateHandoffStatus,
  recordHandoffTicket
} from '../../repositories/handoff.repository.js';
import {
  getCommunities,
  createCommunity
} from '../../repositories/community.repository.js';
import {
  getCampaigns,
  getCampaignById,
  createCampaign,
  joinCampaign,
  getCampaignImpact
} from '../../repositories/campaign.repository.js';
import {
  getPublicDiscoverData,
  getPublicCampaignDetail,
  getPublicClubDetail,
  getCommunityDashboardStats,
  getAdminCampaigns,
  getAdminCampaignById,
  createAdminCampaign,
  updateAdminCampaign,
  archiveAdminCampaign,
  getAdminClubs,
  getAdminClubById,
  createAdminClub,
  updateAdminClub,
  getCampaignParticipants,
  updateParticipantStatus,
  getCommunityMembers,
  addCommunityMember
} from '../../repositories/community-admin.repository.js';
import { getCommunityImpactStats } from '../../repositories/impact.repository.js';
import { getCategories, getCategoryById } from '../../repositories/category.repository.js';
import { getIdempotentResponse, setIdempotentResponse } from '../../shared/idempotency.js';
import {
  issueYouthCertificate,
  getYouthCertificateByCode,
  verifyYouthCertificateSignature,
  revokeYouthCertificate
} from '../../repositories/youth.repository.js';
import { validateObservationInput } from '../../domain/observations/observation.rules.js';
import {
  generateId,
  getAuthenticatedUser,
  getD1OrSqlite,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

// Youth Credits & Certificate
router.get('/api/youth/credits', async (c) => {
  const user = await getAuthenticatedUser(c);
  return c.json({
    status: 'success',
    data: {
      userId: user?.id || 'usr_volunteer_01',
      studentName: user?.name || user?.fullName || 'Nguyễn Văn Volunteer',
      university: 'Đại học Bách Khoa Hà Nội',
      studentId: '2026-HUST-8899',
      volunteerHours: 20.0,
      targetHours: 20.0,
      extracurricularCredits: 4.0,
      creditsAwarded: 4.0,
      rating: 'Tích cực xuất sắc',
      progressPercentage: 100,
      goalReached: true,
      certificateEligible: true,
      disclaimer: 'Hồ sơ này ghi nhận dữ liệu hoạt động trong hệ thống DustGuard. Việc công nhận cho mục đích học thuật, hành chính hoặc tổ chức thuộc quyền quyết định của đơn vị tiếp nhận.',
      history: [
        { id: 'act_01', title: 'Phản ánh bụi Vành Đai 3', hours: 2.5, status: 'VERIFIED', date: '2026-08-10' },
        { id: 'act_02', title: 'Khảo sát nồng độ bụi Mai Dịch', hours: 5.0, status: 'VERIFIED', date: '2026-08-12' },
        { id: 'act_03', title: 'Kiểm tra hàng rào Cầu Giấy', hours: 12.5, status: 'VERIFIED', date: '2026-08-15' }
      ]
    }
  });
});

router.post('/api/youth/claim', async (c) => {
  const user = await getAuthenticatedUser(c);
  const now = new Date().toISOString();
  return c.json({
    status: 'success',
    data: {
      claimId: `clm_${Date.now()}`,
      userId: user?.id || 'usr_demo_citizen',
      hoursRecorded: 20.0,
      creditsAwarded: 4.0,
      extracurricularCredits: 4.0,
      claimedAt: now,
      status: 'CONFIRMED'
    },
    message: 'Ghi nhận hoàn thành mục tiêu 20.0 giờ hoạt động môi trường thành công!'
  });
});

router.get('/api/youth/certificate', async (c) => {
  try {
    const user = await getAuthenticatedUser(c) || { id: 'usr_volunteer_anonymous', name: 'Nguyễn Thị Lan' };
    const cert = await getYouthCertificateByCode(user.id, c.env);
    if (cert) {
      return c.json({ status: 'success', data: cert });
    }
    const generated = await issueYouthCertificate({ userId: user.id, studentName: user.name || user.fullName }, user, c.env);
    return c.json({ status: 'success', data: generated, message: 'Lấy thông tin hồ sơ hoạt động môi trường thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/youth/certificate', async (c) => {
  try {
    const key = c.req.header('idempotency-key') || c.req.header('x-idempotency-key');
    const body = await c.req.json().catch(() => ({}));

    if (key) {
      const cached = await getIdempotentResponse(key, body, c.env);
      if (cached) {
        return c.json(cached.body, cached.status);
      }
    }

    const user = await getAuthenticatedUser(c) || { id: body.userId || 'usr_volunteer_anonymous', name: body.studentName || 'Tình nguyện viên' };
    const cert = await issueYouthCertificate(body, user, c.env);
    const resp = {
      status: 'success',
      data: cert,
      message: 'Tạo hồ sơ hoạt động môi trường thành công'
    };

    if (key) {
      await setIdempotentResponse(key, body, { status: 200, body: resp }, c.env);
    }
    return c.json(resp);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/youth/certificate/:code', async (c) => {
  const code = c.req.param('code');
  try {
    const cert = await getYouthCertificateByCode(code, c.env);
    if (!cert) {
      return c.json({ status: 'error', statusCode: 404, message: 'Không tìm thấy chứng chỉ này.' }, 404);
    }
    return c.json({ status: 'success', data: cert });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleVerifyYouthCertificate = async (c) => {
  const code = c.req.param('code') || c.req.query('code') || c.req.query('certId') || c.req.query('certificateCode');
  const hash = c.req.query('hash');
  try {
    if (!code) {
      return c.json({ status: 'error', statusCode: 400, message: 'Vui lòng cung cấp mã chứng chỉ (code) để xác thực.' }, 400);
    }
    const verification = await verifyYouthCertificateSignature(code, hash, c.env);
    if (!verification.isValid) {
      return c.json({ status: 'error', statusCode: 400, data: verification, message: verification.reason }, 400);
    }
    return c.json({ status: 'success', data: verification, message: verification.reason });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/youth/certificate/:code/verify', handleVerifyYouthCertificate);
router.get('/api/youth/certificate/verify', handleVerifyYouthCertificate);

router.post('/api/admin/youth/certificate/:id/revoke', async (c) => {
  const id = c.req.param('id');
  try {
    const user = await getAuthenticatedUser(c);
    const body = await c.req.json().catch(() => ({}));
    const updated = await revokeYouthCertificate(id, body.reason || 'Thu hồi theo yêu cầu quản trị', user || {}, c.env);
    return c.json({ status: 'success', data: updated, message: 'Đã thu hồi chứng chỉ thành công.' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/youth/leaderboard', (c) => {
  const clubs = getTopClubsLeaderboard();
  return c.json({ status: 'success', data: { items: clubs } });
});

// Environmental Categories
router.get('/api/environmental-categories', async (c) => {
  try {
    c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
    const all = c.req.query('all') === 'true';
    const categories = await getCategories(all, c.env);
    return c.json({ status: 'success', data: categories, count: categories.length });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/environmental-categories/:id', async (c) => {
  const id = c.req.param('id');
  try {
    c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
    const cat = await getCategoryById(id, c.env);
    if (!cat) {
      return c.json({ status: 'error', statusCode: 404, message: `Không tìm thấy danh mục môi trường: ${id}` }, 404);
    }
    return c.json({ status: 'success', data: cat });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Community Profile & Groups
router.get('/api/community/me', async (c) => {
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || { id: 'volunteer_guest', name: 'Thanh niên Hành động', role: 'volunteer' };
    const impact = await getCommunityImpactStats({}, c.env);
    return c.json({
      status: 'success',
      data: {
        user,
        community: {
          id: 'comm_green_uit',
          name: 'CLB Môi Trường Xanh - ĐH Bách Khoa & UIT',
          role: 'Thành viên Tích cực'
        },
        impactSummary: impact
      }
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/community/groups', async (c) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(c, 50, 100);
    const groups = await getCommunities({ limit, offset, page, pageSize }, c.env);
    const items = Array.isArray(groups) ? groups : (groups.items || []);
    return c.json({ status: 'success', data: items, items, pagination: { limit, offset, count: items.length } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/community/groups', async (c) => {
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const group = await createCommunity(body, user, c.env);
    return c.json({ status: 'success', data: group }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.get('/api/community/impact', async (c) => {
  try {
    const query = c.req.query();
    const stats = await getCommunityImpactStats(query, c.env);
    return c.json({ status: 'success', data: stats, ...stats });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/community/discover', async (c) => {
  try {
    const data = await getPublicDiscoverData(c.env);
    return c.json({ status: 'success', data, ...data });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/community/campaigns/:slugOrId', async (c) => {
  const slugOrId = c.req.param('slugOrId');
  try {
    const data = await getPublicCampaignDetail(slugOrId, c.env);
    if (!data) return c.json({ status: 'error', statusCode: 404, message: 'Chiến dịch không tồn tại' }, 404);
    return c.json({ status: 'success', data });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/community/clubs/:slugOrId', async (c) => {
  const slugOrId = c.req.param('slugOrId');
  try {
    const data = await getPublicClubDetail(slugOrId, c.env);
    if (!data) return c.json({ status: 'error', statusCode: 404, message: 'Câu lạc bộ không tồn tại' }, 404);
    return c.json({ status: 'success', data });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Admin Community Campaigns & Clubs
router.get('/api/admin/community/dashboard', async (c) => {
  try {
    const data = await getCommunityDashboardStats(c.env);
    return c.json({ status: 'success', data });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/admin/community/campaigns', async (c) => {
  try {
    const query = c.req.query();
    const list = await getAdminCampaigns(query, c.env);
    return c.json({ status: 'success', data: list, items: list });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/campaigns', async (c) => {
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const item = await createAdminCampaign(body, user, c.env);
    return c.json({ status: 'success', data: item }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.get('/api/admin/community/campaigns/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const item = await getAdminCampaignById(id, c.env);
    if (!item) return c.json({ status: 'error', statusCode: 404, message: 'Chiến dịch không tồn tại' }, 404);
    return c.json({ status: 'success', data: item });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.put('/api/admin/community/campaigns/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const item = await updateAdminCampaign(id, body, user, c.env);
    return c.json({ status: 'success', data: item });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.delete('/api/admin/community/campaigns/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const result = await archiveAdminCampaign(id, user, c.env);
    return c.json({ status: 'success', data: result });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/admin/community/clubs', async (c) => {
  try {
    const query = c.req.query();
    const list = await getAdminClubs(query, c.env);
    return c.json({ status: 'success', data: list, items: list });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/clubs', async (c) => {
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const item = await createAdminClub(body, user, c.env);
    return c.json({ status: 'success', data: item }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.get('/api/admin/community/clubs/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const item = await getAdminClubById(id, c.env);
    if (!item) return c.json({ status: 'error', statusCode: 404, message: 'Câu lạc bộ không tồn tại' }, 404);
    return c.json({ status: 'success', data: item });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.put('/api/admin/community/clubs/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const item = await updateAdminClub(id, body, user, c.env);
    return c.json({ status: 'success', data: item });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.get('/api/admin/community/participants', async (c) => {
  try {
    const query = c.req.query();
    const list = await getCampaignParticipants(query, c.env);
    return c.json({ status: 'success', data: list, items: list });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/participants/:id/approve', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const result = await updateParticipantStatus(id, 'APPROVED', user, c.env);
    return c.json({ status: 'success', data: result });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/participants/:id/reject', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const result = await updateParticipantStatus(id, 'REJECTED', user, c.env);
    return c.json({ status: 'success', data: result });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/participants/:id/status', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const result = await updateParticipantStatus(id, body.status || 'APPROVED', user, c.env);
    return c.json({ status: 'success', data: result });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/admin/community/members', async (c) => {
  try {
    const query = c.req.query();
    const list = await getCommunityMembers(query, c.env);
    return c.json({ status: 'success', data: list, items: list });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/community/members', async (c) => {
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const result = await addCommunityMember(body, user, c.env);
    return c.json({ status: 'success', data: result }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

// Campaigns
router.get('/api/campaigns', async (c) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(c, 50, 100);
    const list = await getCampaigns({ limit, offset, page, pageSize }, c.env);
    const items = Array.isArray(list) ? list : (list.items || []);
    return c.json({ status: 'success', data: items, items, pagination: { limit, offset, count: items.length } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/campaigns/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const camp = await getCampaignById(id, c.env);
    if (!camp) {
      return c.json({ status: 'error', statusCode: 404, message: 'Chiến dịch không tồn tại' }, 404);
    }
    return c.json({ status: 'success', data: camp });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/campaigns/:id/impact', async (c) => {
  const id = c.req.param('id');
  try {
    const impact = await getCampaignImpact(id, c.env);
    if (!impact) {
      return c.json({ status: 'error', statusCode: 404, message: 'Chiến dịch không tồn tại' }, 404);
    }
    return c.json({ status: 'success', data: impact });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/campaigns', async (c) => {
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const campaign = await createCampaign(body, user, c.env);
    return c.json({ status: 'success', data: campaign }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/campaigns/:id/join', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user') || await getAuthenticatedUser(c) || { id: 'volunteer_member' };
    
    const db = getD1OrSqlite(c.env);
    const participantId = generateId('part');
    const now = new Date().toISOString();
    
    await db.prepare(`
      INSERT OR IGNORE INTO campaign_participants (
        id, campaign_id, user_id, full_name, email, phone, organization, commitment_hours, status, joined_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'APPROVED', ?)
    `).bind(
      participantId,
      id,
      user.id || 'volunteer_member',
      body.fullName || user.name || 'Tình nguyện viên',
      body.emailOrPhone || user.email || '',
      body.emailOrPhone || '',
      body.organization || '',
      body.commitmentHours || '4h/tuần',
      now
    ).run().catch(() => {});

    const res = await joinCampaign(id, user.id, c.env);
    return c.json({ status: 'success', data: { ...res, participantId } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Observations
const handleGetObservations = async (c) => {
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const role = (user?.role || user?.primaryRole || 'citizen').toLowerCase();
    const isStaffOrAdmin = ['staff', 'inspector', 'admin', 'executive', 'super_admin', 'demo_admin'].includes(role);

    const { limit, offset, page, pageSize } = parsePaginationParams(c, 20, 100);
    const query = { ...c.req.query(), page, pageSize: limit, limit, offset };
    const result = await getObservations(query, c.env);
    
    let items = result.items;
    if (!isStaffOrAdmin) {
      items = items.map(maskObservationForPublic);
    }

    return c.json({ status: 'success', data: items, items, pagination: result.pagination });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/observations', handleGetObservations);
router.get('/api/community/observations', handleGetObservations);

const handleCreateObservation = async (c) => {
  try {
    const key = c.req.header('idempotency-key') || c.req.header('x-idempotency-key');
    const body = await c.req.json().catch(() => ({}));

    if (key) {
      const cached = await getIdempotentResponse(key, body, c.env);
      if (cached) {
        return c.json(cached.body, cached.status);
      }
    }

    const validation = validateObservationInput(body);
    if (!validation.isValid) {
      return c.json({
        status: 'error',
        statusCode: 400,
        type: 'https://dustguard.vn/errors/400',
        title: 'Validation Error',
        message: validation.errors.join(' '),
        errors: validation.errors
      }, 400);
    }

    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const observation = await createObservation(validation.sanitized, user, c.env);
    const resp = {
      status: 'success',
      data: observation,
      message: 'Ghi nhận hiện trường đã lưu thành công vào D1 SSOT.'
    };

    if (key) {
      await setIdempotentResponse(key, body, { status: 201, body: resp }, c.env);
    }

    return c.json(resp, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.post('/api/observations', handleCreateObservation);
router.post('/api/community/observations', handleCreateObservation);

router.get('/api/observations/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const role = (user?.role || user?.primaryRole || 'citizen').toLowerCase();
    const isStaffOrAdmin = ['staff', 'inspector', 'admin', 'executive', 'super_admin', 'demo_admin'].includes(role);

    const obs = await getObservationById(id, c.env);
    if (!obs) {
      return c.json({ status: 'error', statusCode: 404, message: 'Không tìm thấy ghi nhận này.' }, 404);
    }
    const data = isStaffOrAdmin ? obs : maskObservationForPublic(obs);
    return c.json({ status: 'success', data });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/observations/:id/timeline', async (c) => {
  const id = c.req.param('id');
  try {
    const obs = await getObservationById(id, c.env);
    if (!obs) {
      return c.json({ status: 'error', statusCode: 404, message: 'Không tìm thấy ghi nhận này.' }, 404);
    }
    return c.json({ status: 'success', data: obs.timeline || [] });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.patch('/api/observations/:id/status', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json().catch(() => ({}));
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const updated = await updateObservationStatus(id, body.status, user, c.env);
    return c.json({ status: 'success', data: updated });
  } catch (err) {
    const status = err.statusCode || 500;
    return c.json({ status: 'error', statusCode: status, message: err.message, code: err.code }, status);
  }
});

// Follow-ups
const handleCreateFollowUp = async (c) => {
  try {
    const key = c.req.header('idempotency-key') || c.req.header('x-idempotency-key');
    const body = await c.req.json().catch(() => ({}));

    if (key) {
      const cached = await getIdempotentResponse(key, body, c.env);
      if (cached) {
        return c.json(cached.body, cached.status);
      }
    }

    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const followUp = await createFollowUp(body, user, c.env);
    const resp = {
      status: 'success',
      data: followUp,
      message: 'Đã lưu kết quả theo dõi lại vào D1 SSOT.'
    };

    if (key) {
      await setIdempotentResponse(key, body, { status: 201, body: resp }, c.env);
    }

    return c.json(resp, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.post('/api/follow-ups', handleCreateFollowUp);
router.post('/api/community/follow-ups', handleCreateFollowUp);

router.get('/api/observations/:id/follow-ups', async (c) => {
  const id = c.req.param('id');
  try {
    const list = await getFollowUpsByObservationId(id, c.env);
    return c.json({ status: 'success', data: list });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Handoffs
const handleCreateHandoff = async (c) => {
  try {
    const key = c.req.header('idempotency-key') || c.req.header('x-idempotency-key');
    const body = await c.req.json().catch(() => ({}));

    if (key) {
      const cached = await getIdempotentResponse(key, body, c.env);
      if (cached) {
        return c.json(cached.body, cached.status);
      }
    }

    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const handoff = await createHandoff(body, user, c.env);
    const resp = {
      status: 'success',
      data: handoff,
      message: 'Hồ sơ bàn giao đã được thiết lập và lưu trữ D1.'
    };

    if (key) {
      await setIdempotentResponse(key, body, { status: 201, body: resp }, c.env);
    }

    return c.json(resp, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.post('/api/handoffs', handleCreateHandoff);
router.post('/api/community/handoffs', handleCreateHandoff);

router.get('/api/handoffs/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const handoff = await getHandoffById(id, c.env);
    if (!handoff) {
      return c.json({ status: 'error', statusCode: 404, message: 'Hồ sơ bàn giao không tồn tại' }, 404);
    }
    return c.json({ status: 'success', data: handoff });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/handoffs/:id/submit', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const updated = await updateHandoffStatus(id, 'SUBMITTED', user, c.env);
    return c.json({ status: 'success', data: updated, message: 'Hồ sơ đã gửi tới cơ quan chức năng.' });
  } catch (err) {
    const status = err.statusCode || 500;
    return c.json({ status: 'error', statusCode: status, message: err.message }, status);
  }
});

router.post('/api/handoffs/:id/acknowledge', async (c) => {
  const id = c.req.param('id');
  try {
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const updated = await updateHandoffStatus(id, 'ACKNOWLEDGED', user, c.env);
    return c.json({ status: 'success', data: updated, message: 'Cơ quan chức năng đã tiếp nhận hồ sơ.' });
  } catch (err) {
    const status = err.statusCode || 500;
    return c.json({ status: 'error', statusCode: status, message: err.message }, status);
  }
});

router.get('/api/handoffs/:id/packet', async (c) => {
  const id = c.req.param('id');
  try {
    const handoff = await getHandoffById(id, c.env);
    if (!handoff) {
      return c.json({ status: 'error', statusCode: 404, message: 'Hồ sơ bàn giao không tồn tại' }, 404);
    }
    return c.json({ status: 'success', data: { id: handoff.id, hash: handoff.hash, status: handoff.status, summary: handoff.summaryMarkdown } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/handoffs/:id/ticket', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const updated = await recordHandoffTicket(id, body.ticketNumber, body.channel, user, c.env);
    return c.json({
      status: 'success',
      data: updated,
      message: 'Đã liên kết mã biên nhận tiếp nhận 1022/iHanoi thành công.'
    });
  } catch (err) {
    const status = err.statusCode || 500;
    return c.json({ status: 'error', statusCode: status, message: err.message }, status);
  }
});

router.patch('/api/handoffs/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const body = await c.req.json();
    const user = c.get('user') || await getAuthenticatedUser(c) || {};
    const updated = await updateHandoffStatus(id, body.status, user, c.env);
    return c.json({ status: 'success', data: updated });
  } catch (err) {
    const status = err.statusCode || 500;
    return c.json({ status: 'error', statusCode: status, message: err.message }, status);
  }
});

export default router;
