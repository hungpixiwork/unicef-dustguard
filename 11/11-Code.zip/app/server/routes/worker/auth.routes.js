import { Hono } from 'hono';
import {
  generateId,
  hashPassword,
  getAuthenticatedUser,
  setAuthCookies,
  getTokenFromContext,
  getD1OrSqlite,
  formatRfc7807Error,
  IN_MEMORY_SESSIONS,
  DEMO_ACCOUNTS,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

const handleLogin = async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { email, password } = body;

    if (!email || !password) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Vui lòng nhập email và mật khẩu.', c.req.path), 400);
    }

    const db = getD1OrSqlite(c.env);
    let userToAuth = null;

    if (DEMO_ACCOUNTS[email] && (password === 'DustGuard@2026!' || password === '123456')) {
      userToAuth = { ...DEMO_ACCOUNTS[email] };
      if (db) {
        try {
          const existing = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
          if (!existing) {
            const now = new Date().toISOString();
            await db.prepare(
              'INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt) VALUES (?, ?, ?, 1, ?, ?, ?, ?)'
            ).bind(userToAuth.id, userToAuth.name, email, userToAuth.role, 'ACTIVE', now, now).run();
          } else {
            userToAuth.id = existing.id;
          }
        } catch (e) {}
      }
    } else if (db) {
      try {
        const user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
        if (!user || user.status === 'DISABLED') {
          return c.json(formatRfc7807Error(401, 'UNAUTHENTICATED', 'Unauthorized', 'Email hoặc mật khẩu không chính xác hoặc tài khoản đã bị khóa.', c.req.path), 401);
        }

        const account = await db.prepare('SELECT * FROM account WHERE userId = ? AND providerId = ?').bind(user.id, 'credential').first().catch(() => null);
        if (account && account.password) {
          const hashedInput = await hashPassword(password);
          if (account.password !== hashedInput && account.password !== password) {
            return c.json(formatRfc7807Error(401, 'UNAUTHENTICATED', 'Unauthorized', 'Email hoặc mật khẩu không chính xác.', c.req.path), 401);
          }
        }

        const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
        userToAuth = {
          id: user.id,
          email: user.email,
          name: user.full_name,
          full_name: user.full_name,
          role: user.role || 'citizen',
          status: user.status || 'ACTIVE',
          emailVerified: Boolean(user.email_verified),
          profile: profile ? {
            fullName: profile.fullName,
            phoneNumber: profile.phoneNumber,
            department: profile.department,
            avatarUrl: profile.avatarUrl
          } : { fullName: user.full_name }
        };
      } catch (dbErr) {
        return c.json(formatRfc7807Error(401, 'UNAUTHENTICATED', 'Unauthorized', 'Email hoặc mật khẩu không chính xác.', c.req.path), 401);
      }
    }

    if (!userToAuth) {
      return c.json(formatRfc7807Error(401, 'UNAUTHENTICATED', 'Unauthorized', 'Email hoặc mật khẩu không chính xác.', c.req.path), 401);
    }

    const token = generateId('sess');
    const sessionId = generateId('session');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    const now = new Date().toISOString();

    if (db) {
      try {
        await db.prepare(
          'INSERT INTO session (id, expiresAt, token, createdAt, updatedAt, userId) VALUES (?, ?, ?, ?, ?, ?)'
        ).bind(sessionId, expiresAt, token, now, now, userToAuth.id).run();
      } catch (e) {}
    }

    IN_MEMORY_SESSIONS.set(token, {
      userId: userToAuth.id,
      user: userToAuth,
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
    });

    setAuthCookies(c, token);
    return c.json({
      status: 'success',
      data: {
        ...userToAuth,
        token,
        user: userToAuth
      },
      message: 'Đăng nhập thành công',
      ...userToAuth,
      token
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

router.post('/api/auth/login', handleLogin);
router.post('/api/login', handleLogin);
router.post('/api/v1/auth/login', handleLogin);

const handleRegister = async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { email, password, full_name, name } = body;
    const displayName = full_name || name;

    if (!email || !password || !displayName) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Vui lòng điền đầy đủ họ tên, email và mật khẩu.', c.req.path), 400);
    }

    const userId = generateId('usr');
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      try {
        const existing = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
        if (existing) {
          return c.json(formatRfc7807Error(400, 'EMAIL_EXISTS', 'Bad Request', 'Email này đã được đăng ký tài khoản.', c.req.path), 400);
        }

        await db.prepare(
          'INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt) VALUES (?, ?, ?, 0, ?, ?, ?, ?)'
        ).bind(userId, displayName, email, 'citizen', 'ACTIVE', now, now).run();

        const profileId = generateId('prof');
        await db.prepare(
          'INSERT INTO profiles (id, userId, fullName, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?)'
        ).bind(profileId, userId, displayName, now, now).run();

        const passwordHash = await hashPassword(password);
        const accountId = generateId('acc');
        await db.prepare(
          'INSERT INTO account (id, accountId, providerId, userId, password, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(accountId, userId, 'credential', userId, passwordHash, now, now).run();
      } catch (dbErr) {
        const errMsg = String(dbErr?.message || '');
        if (errMsg.includes('UNIQUE constraint failed: users.email') || errMsg.includes('EMAIL_EXISTS')) {
          return c.json(formatRfc7807Error(400, 'EMAIL_EXISTS', 'Bad Request', 'Email này đã được đăng ký tài khoản.', c.req.path), 400);
        }
        if (errMsg.includes('constraint failed') || errMsg.includes('SQLITE_CONSTRAINT') || errMsg.includes('UNIQUE constraint')) {
          return c.json(formatRfc7807Error(409, 'SQLITE_CONSTRAINT', 'Conflict', `Lỗi ràng buộc cơ sở dữ liệu: ${errMsg}`, c.req.path), 409);
        }
        throw dbErr;
      }
    }

    const newUser = {
      id: userId,
      email,
      name: displayName,
      full_name: displayName,
      role: 'citizen',
      status: 'ACTIVE',
      emailVerified: false,
      profile: { fullName: displayName }
    };

    const token = generateId('sess');
    const sessionId = generateId('session');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    if (db) {
      try {
        await db.prepare(
          'INSERT INTO session (id, expiresAt, token, createdAt, updatedAt, userId) VALUES (?, ?, ?, ?, ?, ?)'
        ).bind(sessionId, expiresAt, token, now, now, userId).run();
      } catch (e) {}
    }

    IN_MEMORY_SESSIONS.set(token, {
      userId,
      user: newUser,
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
    });

    setAuthCookies(c, token);
    return c.json({
      status: 'success',
      data: {
        ...newUser,
        token,
        user: newUser
      },
      message: 'Đăng ký tài khoản thành công',
      ...newUser,
      token
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

router.post('/api/auth/register', handleRegister);
router.post('/api/register', handleRegister);
router.post('/api/v1/auth/register', handleRegister);

const handleMe = async (c) => {
  const user = await getAuthenticatedUser(c);
  if (!user || user.disabled || user.status === 'DISABLED') {
    return c.json(formatRfc7807Error(401, 'UNAUTHENTICATED', 'Unauthorized', 'Chưa đăng nhập.', c.req.path), 401);
  }
  return c.json({
    status: 'success',
    data: {
      ...user,
      user
    },
    message: 'Lấy thông tin tài khoản thành công',
    ...user,
    user
  });
};

router.get('/api/auth/me', handleMe);
router.get('/api/me', handleMe);
router.get('/api/v1/auth/me', handleMe);

const handleLogout = async (c) => {
  const token = getTokenFromContext(c);
  if (token) {
    IN_MEMORY_SESSIONS.delete(token);
    const db = getD1OrSqlite(c.env);
    if (db) {
      try {
        await db.prepare('DELETE FROM session WHERE token = ? OR id = ?').bind(token, token).run();
      } catch (e) {}
    }
  }
  setAuthCookies(c, '', 0);
  return c.json({
    status: 'success',
    ok: true,
    data: { loggedOut: true },
    message: 'Đăng xuất thành công'
  });
};

router.post('/api/auth/logout', handleLogout);
router.post('/api/logout', handleLogout);
router.post('/api/v1/auth/logout', handleLogout);

const handleGetProviders = (c) => {
  const isGoogleConfigured = Boolean(
    c.env?.GOOGLE_CLIENT_ID &&
    c.env?.GOOGLE_CLIENT_SECRET &&
    !c.env.GOOGLE_CLIENT_ID.includes('your-google')
  );
  return c.json({
    googleConfigured: isGoogleConfigured,
    providers: ['email', ...(isGoogleConfigured ? ['google'] : [])]
  });
};

router.get('/api/auth/providers', handleGetProviders);
router.get('/api/v1/auth/providers', handleGetProviders);
router.get('/api/providers', handleGetProviders);
router.get('/api/v1/providers', handleGetProviders);

const handleSignInSocial = async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { provider = 'google', callbackURL = '/citizen' } = body;

    const clientId = c.env?.GOOGLE_CLIENT_ID;
    const clientSecret = c.env?.GOOGLE_CLIENT_SECRET;
    const isGoogleConfigured = Boolean(
      clientId &&
      clientSecret &&
      !clientId.includes('your-google')
    );

    if (provider === 'google' && !isGoogleConfigured) {
      return c.json(formatRfc7807Error(400, 'MISSING_CONFIG', 'Bad Request', 'Chưa cấu hình GOOGLE_CLIENT_ID hoặc GOOGLE_CLIENT_SECRET trên server.', c.req.path), 400);
    }

    const appOrigin = c.env?.APP_ORIGIN || new URL(c.req.url).origin;
    const redirectUri = `${appOrigin}/api/auth/callback/google`;
    const statePayload = JSON.stringify({
      callbackURL: callbackURL || '/citizen',
      nonce: generateId('nonce')
    });
    const state = btoa(encodeURIComponent(statePayload));

    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(clientId)}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=openid%20email%20profile&state=${encodeURIComponent(state)}&prompt=consent&access_type=offline`;

    return c.json({
      status: 'success',
      data: {
        url: authUrl,
        redirect: true
      },
      url: authUrl,
      redirect: true,
      message: 'Tạo liên kết đăng nhập xã hội thành công'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

const handleGoogleCallback = async (c) => {
  try {
    const url = new URL(c.req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');
    let targetCallback = '/citizen';

    if (state) {
      try {
        const decodedState = JSON.parse(decodeURIComponent(atob(state)));
        if (decodedState?.callbackURL) {
          targetCallback = decodedState.callbackURL;
        }
      } catch (e) {}
    }

    if (!code) {
      return c.redirect(`${targetCallback}?error=missing_oauth_code`);
    }

    const clientId = c.env?.GOOGLE_CLIENT_ID;
    const clientSecret = c.env?.GOOGLE_CLIENT_SECRET;
    const appOrigin = c.env?.APP_ORIGIN || url.origin;
    const redirectUri = `${appOrigin}/api/auth/callback/google`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      })
    });

    const tokenData = await tokenRes.json();
    if (!tokenData.access_token) {
      return c.redirect(`${targetCallback}?error=oauth_token_exchange_failed`);
    }

    const userRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const googleUser = await userRes.json();

    if (!googleUser.email) {
      return c.redirect(`${targetCallback}?error=no_email_from_google`);
    }

    const email = googleUser.email;
    const displayName = googleUser.name || email.split('@')[0];
    const avatarUrl = googleUser.picture || null;
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    let user = null;
    if (db) {
      try {
        user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
        if (!user) {
          const userId = generateId('usr');
          await db.prepare(
            'INSERT INTO users (id, full_name, email, email_verified, image, role, status, createdAt, updatedAt) VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?)'
          ).bind(userId, displayName, email, avatarUrl, 'citizen', 'ACTIVE', now, now).run();

          const profileId = generateId('prof');
          await db.prepare(
            'INSERT INTO profiles (id, userId, fullName, avatarUrl, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)'
          ).bind(profileId, userId, displayName, avatarUrl, now, now).run();

          user = { id: userId, email, full_name: displayName, role: 'citizen', image: avatarUrl, status: 'ACTIVE' };
        }
      } catch (dbErr) {}
    }

    if (!user) {
      user = { id: generateId('usr'), email, full_name: displayName, role: 'citizen', image: avatarUrl, status: 'ACTIVE' };
    }

    const sessionToken = generateId('sess');
    const sessionId = generateId('session');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    if (db) {
      try {
        await db.prepare(
          'INSERT INTO session (id, expiresAt, token, createdAt, updatedAt, userId) VALUES (?, ?, ?, ?, ?, ?)'
        ).bind(sessionId, expiresAt, sessionToken, now, now, user.id).run();
      } catch (e) {}
    }

    IN_MEMORY_SESSIONS.set(sessionToken, {
      userId: user.id,
      user,
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
    });

    setAuthCookies(c, sessionToken);
    return c.redirect(targetCallback);
  } catch (err) {
    return c.redirect(`/login?error=${encodeURIComponent(err.message)}`);
  }
};

router.post('/api/auth/sign-in/social', handleSignInSocial);
router.post('/auth/sign-in/social', handleSignInSocial);
router.post('/api/auth/signin/social', handleSignInSocial);
router.get('/api/auth/callback/google', handleGoogleCallback);
router.get('/auth/callback/google', handleGoogleCallback);

// Citizen Profile Endpoints
const handleGetCitizenProfile = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    let profile = null;
    if (c.env && c.env.DB) {
      profile = await c.env.DB.prepare('SELECT * FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
    }

    let preferences = {};
    if (profile?.department && profile.department.startsWith('{')) {
      try {
        preferences = JSON.parse(profile.department);
      } catch {}
    }

    const data = {
      id: user.id,
      email: user.email,
      fullName: profile?.fullName || user.full_name || user.name || '',
      phoneNumber: profile?.phoneNumber || '',
      avatarUrl: profile?.avatarUrl || '',
      nickname: preferences.nickname || profile?.fullName || user.full_name || user.name || '',
      organization: preferences.organization || (!preferences.nickname ? profile?.department : '') || '',
      identityMode: (preferences.identityMode || 'anonymous').toLowerCase(),
      notifyWebPush: preferences.notifyWebPush !== undefined ? Boolean(preferences.notifyWebPush) : true,
      notifyEmail: preferences.notifyEmail !== undefined ? Boolean(preferences.notifyEmail) : false
    };

    return c.json({ status: 'success', data, message: 'Lấy thông tin hồ sơ thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/citizen/profile', handleGetCitizenProfile);
router.get('/api/v1/citizen/profile', handleGetCitizenProfile);

const handleUpdateCitizenProfile = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }

    const body = await c.req.json().catch(() => ({}));
    const {
      fullName,
      nickname,
      organization,
      identityMode: rawMode,
      notifyWebPush,
      notifyEmail,
      phoneNumber,
      avatarUrl
    } = body;

    const normalizedMode = (rawMode || 'anonymous').toLowerCase();

    if (normalizedMode === 'nickname') {
      if (!nickname || !nickname.trim() || nickname.trim().length < 2) {
        return c.json({
          status: 'error',
          statusCode: 400,
          code: 'VALIDATION_ERROR',
          field: 'nickname',
          message: 'Vui lòng nhập Nickname (tối thiểu 2 ký tự) khi chọn chế độ Công khai Nickname.',
          error: 'Vui lòng nhập Nickname (tối thiểu 2 ký tự) khi chọn chế độ Công khai Nickname.'
        }, 400);
      }
    }

    if (normalizedMode === 'organization') {
      if (!organization || !organization.trim() || organization.trim().length < 2) {
        return c.json({
          status: 'error',
          statusCode: 400,
          code: 'VALIDATION_ERROR',
          field: 'organization',
          message: 'Vui lòng nhập Trường học / CLB khi chọn chế độ Thành viên Tổ chức.',
          error: 'Vui lòng nhập Trường học / CLB khi chọn chế độ Thành viên Tổ chức.'
        }, 400);
      }
    }

    const cleanNickname = nickname ? nickname.trim() : '';
    const cleanOrganization = organization ? organization.trim() : '';
    const preferencesPayload = JSON.stringify({
      nickname: cleanNickname,
      organization: cleanOrganization,
      identityMode: normalizedMode,
      notifyWebPush: Boolean(notifyWebPush),
      notifyEmail: Boolean(notifyEmail)
    });

    const now = new Date().toISOString();
    const finalFullName = fullName?.trim() || cleanNickname || user.full_name || user.name || 'Người dân';
    const db = getD1OrSqlite(c.env);

    if (db) {
      await db.prepare('UPDATE users SET full_name = ?, updatedAt = ? WHERE id = ?').bind(finalFullName, now, user.id).run();

      const existingProfile = await db.prepare('SELECT id FROM profiles WHERE userId = ?').bind(user.id).first().catch(() => null);
      if (existingProfile) {
        await db.prepare(
          'UPDATE profiles SET fullName = ?, phoneNumber = COALESCE(?, phoneNumber), department = ?, avatarUrl = COALESCE(?, avatarUrl), updatedAt = ? WHERE userId = ?'
        ).bind(finalFullName, phoneNumber || null, preferencesPayload, avatarUrl || null, now, user.id).run();
      } else {
        const profId = generateId('prof');
        await db.prepare(
          'INSERT INTO profiles (id, userId, fullName, phoneNumber, department, avatarUrl, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(profId, user.id, finalFullName, phoneNumber || null, preferencesPayload, avatarUrl || null, now, now).run();
      }
    }

    const responseData = {
      id: user.id,
      email: user.email,
      fullName: finalFullName,
      phoneNumber: phoneNumber || '',
      avatarUrl: avatarUrl || '',
      nickname: cleanNickname || finalFullName,
      organization: cleanOrganization,
      identityMode: normalizedMode,
      notifyWebPush: Boolean(notifyWebPush),
      notifyEmail: Boolean(notifyEmail)
    };

    return c.json({ status: 'success', data: responseData, message: 'Cập nhật hồ sơ và cài đặt thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.patch('/api/citizen/profile', handleUpdateCitizenProfile);
router.put('/api/citizen/profile', handleUpdateCitizenProfile);
router.patch('/api/v1/citizen/profile', handleUpdateCitizenProfile);
router.put('/api/v1/citizen/profile', handleUpdateCitizenProfile);

// Users Management (Admin)
const handleUpdateUserProfile = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const id = c.req.param('id');
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (user.id !== id && !isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền chỉnh sửa hồ sơ này.', c.req.path), 403);
    }

    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      if (body.fullName || body.name) {
        await db.prepare('UPDATE users SET full_name = ?, updatedAt = ? WHERE id = ?').bind(body.fullName || body.name, now, id).run();
      }
      await db.prepare(
        'UPDATE profiles SET fullName = COALESCE(?, fullName), phoneNumber = COALESCE(?, phoneNumber), department = COALESCE(?, department), avatarUrl = COALESCE(?, avatarUrl), updatedAt = ? WHERE userId = ?'
      ).bind(body.fullName || body.name || null, body.phoneNumber !== undefined ? body.phoneNumber : null, body.department !== undefined ? body.department : null, body.avatarUrl || body.image || null, now, id).run();
    }
    return c.json({ status: 'success', data: { userId: id, ...body }, message: 'Cập nhật thông tin thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.put('/api/users/:id/profile', handleUpdateUserProfile);
router.put('/api/v1/users/:id/profile', handleUpdateUserProfile);
router.patch('/api/users/:id/profile', handleUpdateUserProfile);
router.patch('/api/v1/users/:id/profile', handleUpdateUserProfile);

const handleGetUsers = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (!isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền xem danh sách người dùng.', c.req.path), 403);
    }

    const { limit, offset } = parsePaginationParams(c, 50, 100);
    const url = new URL(c.req.url);
    const search = url.searchParams.get('search') || '';
    const roleFilter = url.searchParams.get('role') || 'ALL';
    const statusFilter = url.searchParams.get('status') || 'ALL';
    const db = getD1OrSqlite(c.env);

    if (db) {
      let whereClauses = [];
      let params = [];

      if (roleFilter && roleFilter !== 'ALL') {
        whereClauses.push('LOWER(u.role) = ?');
        params.push(roleFilter.toLowerCase());
      }
      if (statusFilter && statusFilter !== 'ALL') {
        whereClauses.push('UPPER(u.status) = ?');
        params.push(statusFilter.toUpperCase());
      }
      if (search) {
        whereClauses.push('(u.full_name LIKE ? OR u.email LIKE ? OR p.department LIKE ?)');
        params.push(`%${search}%`, `%${search}%`, `%${search}%`);
      }

      const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
      const querySql = `
        SELECT u.id, u.clerk_user_id, u.full_name, u.email, u.role, u.email_verified, u.status, u.createdAt, u.updatedAt,
               p.fullName as profileFullName, p.phoneNumber, p.department, p.avatarUrl
        FROM users u
        LEFT JOIN profiles p ON p.userId = u.id
        ${whereSql}
        ORDER BY u.createdAt DESC
        LIMIT ? OFFSET ?
      `;

      const { results } = await db.prepare(querySql).bind(...params, limit, offset).all();
      const items = (results || []).map(r => ({
        id: r.id,
        clerk_user_id: r.clerk_user_id,
        fullName: r.full_name || r.profileFullName,
        full_name: r.full_name,
        email: r.email,
        role: r.role,
        status: r.status,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
        profile: {
          fullName: r.profileFullName || r.full_name,
          phoneNumber: r.phoneNumber,
          department: r.department,
          avatarUrl: r.avatarUrl
        }
      }));

      return c.json({ status: 'success', data: { items, pagination: { limit, offset, count: items.length } }, pagination: { limit, offset, count: items.length } });
    }
    return c.json({ status: 'success', data: { items: [], pagination: { limit, offset, count: 0 } } });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/users', handleGetUsers);
router.get('/api/v1/users', handleGetUsers);

const handleGetUserById = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const id = c.req.param('id');
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (user.id !== id && !isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền xem thông tin người dùng này.', c.req.path), 403);
    }

    let targetUser = null;
    const db = getD1OrSqlite(c.env);
    if (db) {
      targetUser = await db.prepare('SELECT id, clerk_user_id, full_name, email, role, email_verified, status, createdAt FROM users WHERE id = ?').bind(id).first();
      if (targetUser) {
        const profile = await db.prepare('SELECT * FROM profiles WHERE userId = ?').bind(id).first().catch(() => null);
        targetUser.profile = profile || null;
      }
    }
    if (!targetUser && DEMO_ACCOUNTS[id]) {
      targetUser = DEMO_ACCOUNTS[id];
    }
    if (!targetUser) {
      return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy người dùng.', c.req.path), 404);
    }
    return c.json({ status: 'success', data: targetUser, message: 'Lấy thông tin người dùng thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/users/:id', handleGetUserById);
router.get('/api/v1/users/:id', handleGetUserById);

const handleUpdateUserRole = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (!isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền thay đổi vai trò người dùng.', c.req.path), 403);
    }

    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const { role } = body;
    const validRoles = [
      'public', 'citizen', 'community', 'staff', 'executive', 'admin',
      'contractor', 'operator', 'site_representative', 'youth_member',
      'inspector', 'volunteer', 'super_admin', 'demo_admin'
    ];
    if (!role || !validRoles.includes(role.toLowerCase())) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Vai trò (role) không hợp lệ.', c.req.path), 400);
    }
    const cleanRole = role.toLowerCase();
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      let existing = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
      if (!existing && DEMO_ACCOUNTS[id]) {
        const demo = DEMO_ACCOUNTS[id];
        await db.prepare(
          'INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt) VALUES (?, ?, ?, 1, ?, ?, ?, ?)'
        ).bind(id, demo.name || demo.full_name, demo.email, cleanRole, 'ACTIVE', now, now).run().catch(() => {});
        existing = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
      }

      if (!existing && !DEMO_ACCOUNTS[id]) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy người dùng.', c.req.path), 404);
      }

      await db.prepare('UPDATE users SET role = ?, updatedAt = ? WHERE id = ?').bind(cleanRole, now, id).run();
      const updated = await db.prepare('SELECT id, full_name, email, role, status, updatedAt FROM users WHERE id = ?').bind(id).first();

      // Sync in-memory session cache
      for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
        if (sess.userId === id || sess.user?.id === id) {
          sess.user.role = cleanRole;
          sess.user.roles = [cleanRole];
        }
      }

      return c.json({ status: 'success', data: updated || { id, role: cleanRole }, message: 'Cập nhật vai trò người dùng thành công' });
    }

    // Sync in-memory session cache even if no db
    for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
      if (sess.userId === id || sess.user?.id === id) {
        sess.user.role = cleanRole;
        sess.user.roles = [cleanRole];
      }
    }

    return c.json({ status: 'success', data: { id, role: cleanRole }, message: 'Cập nhật vai trò người dùng thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.put('/api/users/:id/role', handleUpdateUserRole);
router.put('/api/v1/users/:id/role', handleUpdateUserRole);
router.patch('/api/users/:id/role', handleUpdateUserRole);
router.patch('/api/v1/users/:id/role', handleUpdateUserRole);

const handleUpdateUserStatus = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (!isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền thay đổi trạng thái người dùng.', c.req.path), 403);
    }

    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const { status } = body;
    const validStatuses = ['ACTIVE', 'INACTIVE', 'DISABLED'];
    if (!status || !validStatuses.includes(status.toUpperCase())) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Trạng thái không hợp lệ (ACTIVE, INACTIVE, DISABLED).', c.req.path), 400);
    }
    const cleanStatus = status.toUpperCase();
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      let existing = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
      if (!existing && DEMO_ACCOUNTS[id]) {
        const demo = DEMO_ACCOUNTS[id];
        await db.prepare(
          'INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt) VALUES (?, ?, ?, 1, ?, ?, ?, ?)'
        ).bind(id, demo.name || demo.full_name, demo.email, demo.role || 'citizen', cleanStatus, now, now).run().catch(() => {});
        existing = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
      }

      if (!existing && !DEMO_ACCOUNTS[id]) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy người dùng.', c.req.path), 404);
      }
      await db.prepare('UPDATE users SET status = ?, updatedAt = ? WHERE id = ?').bind(cleanStatus, now, id).run();
      const updated = await db.prepare('SELECT id, full_name, email, role, status, updatedAt FROM users WHERE id = ?').bind(id).first();

      // Sync or Evict in-memory session cache
      for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
        if (sess.userId === id || sess.user?.id === id) {
          sess.user.status = cleanStatus;
          sess.user.disabled = cleanStatus === 'DISABLED';
          if (cleanStatus === 'DISABLED') {
            IN_MEMORY_SESSIONS.delete(token);
          }
        }
      }

      return c.json({ status: 'success', data: updated || { id, status: cleanStatus }, message: 'Cập nhật trạng thái người dùng thành công' });
    }

    // Sync in-memory session cache even if no db
    for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
      if (sess.userId === id || sess.user?.id === id) {
        sess.user.status = cleanStatus;
        sess.user.disabled = cleanStatus === 'DISABLED';
        if (cleanStatus === 'DISABLED') {
          IN_MEMORY_SESSIONS.delete(token);
        }
      }
    }

    return c.json({ status: 'success', data: { id, status: cleanStatus }, message: 'Cập nhật trạng thái người dùng thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.put('/api/users/:id/status', handleUpdateUserStatus);
router.put('/api/v1/users/:id/status', handleUpdateUserStatus);
router.patch('/api/users/:id/status', handleUpdateUserStatus);
router.patch('/api/v1/users/:id/status', handleUpdateUserStatus);

const handleCreateUser = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (!isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền tạo người dùng.', c.req.path), 403);
    }

    const body = await c.req.json().catch(() => ({}));
    const email = String(body.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Email không hợp lệ.', c.req.path), 400);
    }

    const rawRole = (body.role || 'staff').toLowerCase();
    const validRoles = [
      'public', 'citizen', 'community', 'staff', 'executive', 'admin',
      'contractor', 'operator', 'site_representative', 'youth_member',
      'inspector', 'volunteer', 'super_admin', 'demo_admin'
    ];
    const role = validRoles.includes(rawRole) ? rawRole : 'staff';
    const fullName = String(body.profile?.fullName || body.fullName || body.name || email.split('@')[0]).trim();
    const department = body.profile?.department || body.department || body.organization || body.profile?.organization || null;
    const phoneNumber = body.profile?.phoneNumber || body.phoneNumber || body.phone || body.profile?.phone || null;
    const status = (body.status || 'ACTIVE').toUpperCase();
    const now = new Date().toISOString();
    const newUserId = generateId('usr');
    const db = getD1OrSqlite(c.env);

    if (db) {
      const existing = await db.prepare('SELECT id FROM users WHERE email = ?').bind(email).first();
      if (existing) {
        return c.json(formatRfc7807Error(400, 'EMAIL_EXISTS', 'Bad Request', 'Email này đã tồn tại trong hệ thống.', c.req.path), 400);
      }

      try {
        await db.prepare(`
          INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt)
          VALUES (?, ?, ?, 1, ?, ?, ?, ?)
        `).bind(newUserId, fullName, email, role, status, now, now).run();

        const profId = generateId('prof');
        await db.prepare(`
          INSERT INTO profiles (id, userId, fullName, phoneNumber, department, createdAt, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(profId, newUserId, fullName, phoneNumber, department, now, now).run();

        const created = await db.prepare('SELECT id, full_name, email, role, status, createdAt FROM users WHERE id = ?').bind(newUserId).first();
        return c.json({ status: 'success', data: { ...created, profile: { fullName, phoneNumber, department } }, message: 'Tạo người dùng thành công' }, 201);
      } catch (dbErr) {
        const errMsg = String(dbErr?.message || '');
        if (errMsg.includes('UNIQUE constraint failed: users.email') || errMsg.includes('EMAIL_EXISTS')) {
          return c.json(formatRfc7807Error(400, 'EMAIL_EXISTS', 'Bad Request', 'Email này đã tồn tại trong hệ thống.', c.req.path), 400);
        }
        if (errMsg.includes('constraint failed') || errMsg.includes('SQLITE_CONSTRAINT') || errMsg.includes('UNIQUE constraint')) {
          return c.json(formatRfc7807Error(409, 'SQLITE_CONSTRAINT', 'Conflict', `Lỗi ràng buộc cơ sở dữ liệu: ${errMsg}`, c.req.path), 409);
        }
        throw dbErr;
      }
    }

    return c.json({ status: 'success', data: { id: newUserId, email, fullName, role, status }, message: 'Tạo người dùng thành công' }, 201);
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.post('/api/users', handleCreateUser);
router.post('/api/v1/users', handleCreateUser);

const handleDeleteUser = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const isAdmin = ['admin', 'super_admin', 'demo_admin'].includes((user.role || '').toLowerCase());
    if (!isAdmin) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền vô hiệu hóa người dùng.', c.req.path), 403);
    }
    const id = c.req.param('id');
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      await db.prepare("UPDATE users SET status = 'DISABLED', updatedAt = ? WHERE id = ?").bind(now, id).run();
      for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
        if (sess.userId === id || sess.user?.id === id) {
          IN_MEMORY_SESSIONS.delete(token);
        }
      }
      const updated = await db.prepare('SELECT id, full_name, email, role, status FROM users WHERE id = ?').bind(id).first();
      return c.json({ status: 'success', data: updated, message: 'Vô hiệu hóa người dùng thành công' });
    }

    for (const [token, sess] of IN_MEMORY_SESSIONS.entries()) {
      if (sess.userId === id || sess.user?.id === id) {
        IN_MEMORY_SESSIONS.delete(token);
      }
    }

    return c.json({ status: 'success', data: { id, status: 'DISABLED' }, message: 'Vô hiệu hóa người dùng thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.delete('/api/users/:id', handleDeleteUser);
router.delete('/api/v1/users/:id', handleDeleteUser);

export default router;
