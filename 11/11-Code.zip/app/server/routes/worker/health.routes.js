import { Hono } from 'hono';
import { openApiSpec } from '../../docs/openapi.spec.js';
import { renderSwaggerHtml } from '../../docs/swagger-ui.html.js';
import { getD1OrSqlite } from './helpers.js';

const router = new Hono();

// Health & System Endpoints
router.get('/health', (c) => c.json({ status: 'ok', platform: 'Cloudflare Worker', timestamp: new Date().toISOString() }));
router.get('/api/v1/health', (c) => c.json({ status: 'ok', platform: 'Cloudflare Worker', database: 'Cloudflare D1', timestamp: new Date().toISOString() }));

router.get('/api/health', async (c) => {
  let dbReachable = false;
  let dbError = null;
  const db = c.env?.DB;

  if (db && typeof db.prepare === 'function') {
    try {
      const result = await db.prepare('SELECT 1 as alive').first();
      dbReachable = result !== null && (result.alive === 1 || result.alive === '1' || Boolean(result));
    } catch (err) {
      dbError = err.message || 'D1 connection error';
      dbReachable = false;
    }
  } else if (!db) {
    dbReachable = false;
  }

  const r2Bucket = c.env?.EVIDENCE_BUCKET || c.env?.STORAGE;
  const storageReachable = Boolean(
    r2Bucket &&
    typeof r2Bucket.get === 'function' &&
    typeof r2Bucket.put === 'function'
  );

  const envName = c.env?.ENVIRONMENT || c.env?.APP_ENV || 'development';
  const resourceMode = envName === 'production' ? 'remote-production' : (c.env?.DB ? 'development' : 'local-in-memory');
  const isHealthy = dbReachable || !c.env?.DB;

  return c.json({
    ok: isHealthy,
    status: isHealthy ? 'ok' : 'degraded',
    service: 'dustguard-api',
    database: dbReachable ? 'connected' : (dbError ? `error: ${dbError}` : 'disconnected'),
    environment: envName,
    runtime: 'cloudflare-worker',
    storage: {
      provider: 'r2',
      reachable: storageReachable
    },
    resourceMode,
    timestamp: new Date().toISOString()
  }, isHealthy ? 200 : 503);
});

router.get('/api/health/db', async (c) => {
  let siteCount = 0, complaintCount = 0, inspectionCount = 0, actionCount = 0;
  if (c.env && c.env.DB) {
    try {
      const s = await c.env.DB.prepare('SELECT COUNT(*) as cnt FROM sites WHERE deletedAt IS NULL').first();
      const cp = await c.env.DB.prepare('SELECT COUNT(*) as cnt FROM complaints WHERE deletedAt IS NULL').first();
      const ins = await c.env.DB.prepare('SELECT COUNT(*) as cnt FROM inspections WHERE deletedAt IS NULL').first();
      const act = await c.env.DB.prepare('SELECT COUNT(*) as cnt FROM actions WHERE deletedAt IS NULL').first();
      if (s) siteCount = s.cnt;
      if (cp) complaintCount = cp.cnt;
      if (ins) inspectionCount = ins.cnt;
      if (act) actionCount = act.cnt;
    } catch (e) {}
  }
  return c.json({
    ok: true,
    status: 'healthy',
    database: 'connected',
    timestamp: new Date().toISOString(),
    counts: { sites: siteCount, complaints: complaintCount, inspections: inspectionCount, actions: actionCount }
  });
});

// Dashboard Summary KPI SSOT Endpoint
router.get('/api/dashboard/summary', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { getStaffDashboardData } = await import('../../services/staff-dashboard.service.js');
    const dashboardData = await getStaffDashboardData(db);

    return c.json({
      status: 'success',
      data: dashboardData,
      message: 'Tải dữ liệu tổng quan Dashboard thành công từ D1 SSOT'
    });
  } catch (err) {
    console.error('[Worker] Error aggregating dashboard summary:', err);
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Swagger & OpenAPI 3.0 Endpoints
const handleOpenApiSpec = (c) => {
  c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
  return c.json(openApiSpec);
};
router.get('/api/docs/openapi.json', handleOpenApiSpec);
router.get('/openapi.json', handleOpenApiSpec);

const handleSwaggerUi = (c) => {
  c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
  return c.html(renderSwaggerHtml('/api/docs/openapi.json'));
};
router.get('/api-docs', handleSwaggerUi);
router.get('/docs', handleSwaggerUi);
router.get('/api/docs', handleSwaggerUi);

export default router;
