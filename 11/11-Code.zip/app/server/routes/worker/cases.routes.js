import { Hono } from 'hono';
import {
  CASE_STATUS,
  normalizeStatus,
  isValidTransition,
  validateCaseTransition,
  deriveWorkflowStep,
  getNextAction
} from '../../domain/cases/case.rules.js';
import {
  generateId,
  generateRandomCode,
  sha256Hex,
  getAuthenticatedUser,
  getD1OrSqlite,
  formatRfc7807Error,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

router.get('/api/cases', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để truy cập hồ sơ vụ việc.', c.req.path), 401);
    }
    const userRole = (user.role || user.primaryRole || '').toLowerCase();
    const userRoles = (user.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);
    const isContractor = userRole === 'contractor' || userRoles.includes('contractor') || userRole === 'demo_contractor';

    if (!isStaffOrAdmin && !isContractor) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ cán bộ quản lý (Staff/Executive/Admin) hoặc nhà thầu liên quan mới được truy cập hồ sơ vụ việc.', c.req.path), 403);
    }

    const status = c.req.query('status');
    const siteId = c.req.query('siteId');
    const assignedToFilter = c.req.query('assignedTo');
    const { limit, offset } = parsePaginationParams(c, 50, 100);

    if (c.env && c.env.DB) {
      let query = `
        SELECT c.*, 
               s.name as siteName, s.address as siteAddress, s.ward as siteWard, s.contractorName, s.managerEmail,
               u.full_name as assigneeName, u.email as assigneeEmail,
               cb.full_name as creatorName
        FROM cases c 
        LEFT JOIN sites s ON c.siteId = s.id 
        LEFT JOIN users u ON c.assignedTo = u.id
        LEFT JOIN users cb ON c.createdBy = cb.id
        WHERE c.deletedAt IS NULL
      `;
      const params = [];
      if (status) {
        query += ' AND c.status = ?';
        params.push(status);
      }
      if (siteId) {
        query += ' AND c.siteId = ?';
        params.push(siteId);
      }
      if (assignedToFilter === 'me') {
        query += ' AND (c.assignedTo = ? OR c.createdBy = ?)';
        params.push(user.id, user.id);
      } else if (assignedToFilter === 'unassigned') {
        query += ' AND (c.assignedTo IS NULL OR c.assignedTo = "")';
      } else if (assignedToFilter) {
        query += ' AND c.assignedTo = ?';
        params.push(assignedToFilter);
      }

      if (isContractor && !isStaffOrAdmin) {
        const contractorName = user.fullName || user.name || '';
        const contractorEmail = user.email || '';
        query += ' AND (s.contractorName = ? OR s.managerEmail = ?)';
        params.push(contractorName, contractorEmail);
      }
      query += ' ORDER BY c.createdAt DESC LIMIT ? OFFSET ?';
      params.push(limit, offset);

      const stmt = c.env.DB.prepare(query);
      const { results } = await stmt.bind(...params).all();

      const items = (results || []).map(r => ({
        ...r,
        inspectorName: r.assigneeName || (r.assignedTo ? 'Cán bộ xử lý' : 'Chưa phân công'),
        site: { id: r.siteId, name: r.siteName, address: r.siteAddress, ward: r.siteWard }
      }));

      return c.json({ status: 'success', data: { items, pagination: { limit, offset, count: items.length } }, pagination: { limit, offset, count: items.length } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases', async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const actorName = user?.name || user?.fullName || 'Cán bộ';
    const actorRole = (user?.role || 'staff').toLowerCase();
    const actorRoles = (user?.roles || [actorRole]).map(r => r.toLowerCase());
    const isCoordinator = ['coordinator', 'team_lead', 'executive', 'admin', 'super_admin', 'demo_admin'].some(r => actorRoles.includes(r) || actorRole === r);

    const caseId = generateId('case');
    const code = body.code || generateRandomCode('CASE-2026', 1000, 9999);
    const now = new Date().toISOString();

    const priority = (body.priority || 'HIGH').toUpperCase();
    let slaHours = 24;
    if (priority === 'URGENT' || priority === 'CRITICAL') slaHours = 4;
    else if (priority === 'HIGH') slaHours = 24;
    else if (priority === 'MEDIUM') slaHours = 72;
    else if (priority === 'LOW') slaHours = 168;

    const slaDeadline = new Date(Date.now() + slaHours * 3600 * 1000).toISOString();

    let assignedTo = user?.id || null;
    let initialStatus = 'SCREENING';

    if (body.sendToQueue === true || body.unassigned === true) {
      assignedTo = null;
      initialStatus = 'SCREENING';
    } else if (isCoordinator && body.assignedTo) {
      assignedTo = body.assignedTo;
    } else {
      assignedTo = user?.id || null;
    }

    if (body.status) {
      initialStatus = normalizeStatus(body.status);
    }

    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        `INSERT INTO cases (id, code, siteId, complaintId, inspectionId, title, description, status, priority, slaDeadline, createdBy, assignedTo, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).bind(
        caseId,
        code,
        body.siteId || null,
        body.complaintId || null,
        body.inspectionId || null,
        body.title || 'Hồ sơ giám sát môi trường',
        body.description || null,
        initialStatus,
        priority,
        slaDeadline,
        user?.id || null,
        assignedTo,
        now,
        now
      ).run();

      const timelineId = generateId('tl');
      const timelineDesc = assignedTo
        ? `Tiếp nhận hồ sơ giám sát. Cán bộ phụ trách: ${actorName}`
        : 'Khởi tạo hồ sơ giám sát, chuyển vào hàng đợi chờ điều phối phân công.';

      await c.env.DB.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, caseId, 'Khởi tạo vụ việc', timelineDesc, `STATUS_${initialStatus}`, actorName, actorRole, now).run();

      const cshId = generateId('csh');
      try {
        await c.env.DB.prepare(
          'INSERT INTO case_status_history (id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(cshId, caseId, 'NONE', initialStatus, user?.id || null, actorName, actorRole, 'Khởi tạo vụ việc mới', now).run();
      } catch (e) {}

      const auditId = generateId('aud');
      try {
        await c.env.DB.prepare(
          'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(auditId, actorName, actorRole, 'CASE_CREATE', caseId, JSON.stringify({ code, title: body.title, siteId: body.siteId, priority, assignedTo, status: initialStatus }), now).run();
      } catch (e) {}
    }

    return c.json({
      status: 'success',
      data: {
        id: caseId,
        code,
        title: body.title,
        siteId: body.siteId,
        priority,
        status: initialStatus,
        assignedTo,
        slaDeadline,
        createdAt: now
      },
      message: 'Mở hồ sơ vụ việc thành công'
    }, 201);
  } catch (err) {
    console.error('POST /api/cases error:', err);
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleUpdateCase = async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const actorName = user?.name || user?.fullName || 'Cán bộ';
    const actorRole = (user?.role || 'staff').toLowerCase();
    const now = new Date().toISOString();

    if (c.env && c.env.DB) {
      const existing = await c.env.DB.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
      }

      const newStatus = body.status ? normalizeStatus(body.status) : (existing.status || 'SCREENING');
      const title = body.title !== undefined ? body.title : (existing.title || 'Hồ sơ giám sát');
      const description = body.description !== undefined ? body.description : (existing.description || null);
      const slaDeadline = body.slaDeadline !== undefined ? body.slaDeadline : (existing.slaDeadline || null);

      if (newStatus !== existing.status) {
        try {
          validateCaseTransition(existing.status, newStatus, {
            role: actorRole,
            reason: body.note || body.description,
            context: body
          });
        } catch (smErr) {
          return c.json(formatRfc7807Error(400, 'INVALID_TRANSITION', 'Invalid Transition', smErr.message, c.req.path), 400);
        }
      }

      await c.env.DB.prepare(
        'UPDATE cases SET title = ?, description = ?, status = ?, slaDeadline = ?, updatedAt = ? WHERE id = ?'
      ).bind(title, description, newStatus, slaDeadline, now, existing.id).run();

      if (newStatus !== existing.status) {
        const timelineId = generateId('tl');
        await c.env.DB.prepare(
          'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(timelineId, existing.id, `Chuyển trạng thái sang ${newStatus}`, body.note || `Cán bộ cập nhật trạng thái sang ${newStatus}`, `STATUS_${newStatus}`, actorName, actorRole, now).run();

        const cshId = generateId('csh');
        try {
          await c.env.DB.prepare(
            'INSERT INTO case_status_history (id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
          ).bind(cshId, existing.id, existing.status, newStatus, user?.id || null, actorName, actorRole, body.note || 'Cập nhật trạng thái qua API', now).run();
        } catch (e) {}

        const auditId = generateId('aud');
        try {
          await c.env.DB.prepare(
            'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
          ).bind(auditId, actorName, actorRole, `CASE_STATUS_${newStatus}`, existing.id, JSON.stringify({ previousStatus: existing.status, newStatus, note: body.note }), now).run();
        } catch (e) {}
      }

      return c.json({
        status: 'success',
        data: { id: existing.id, code: existing.code, title, description, status: newStatus, slaDeadline, updatedAt: now },
        message: 'Cập nhật hồ sơ vụ việc thành công'
      });
    }
    return c.json({ status: 'error', message: 'D1 database không khả dụng' }, 500);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.put('/api/cases/:id', handleUpdateCase);
router.patch('/api/cases/:id', handleUpdateCase);

router.get('/api/cases/:id/sla', async (c) => {
  try {
    const id = c.req.param('id');
    if (c.env && c.env.DB) {
      const caseItem = await c.env.DB.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!caseItem) {
        return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
      }

      const createdAtMs = new Date(caseItem.createdAt).getTime();
      const now = Date.now();
      const status = normalizeStatus(caseItem.status);

      const screeningDeadline = new Date(createdAtMs + 2 * 24 * 3600 * 1000).toISOString();
      const preparingDeadline = new Date(createdAtMs + 3 * 24 * 3600 * 1000).toISOString();
      const decisionIssuedDeadline = new Date(createdAtMs + 3 * 24 * 3600 * 1000).toISOString();
      const onSiteDeadline = new Date(createdAtMs + 5 * 24 * 3600 * 1000).toISOString();
      const reportingDeadline = new Date(createdAtMs + 5 * 24 * 3600 * 1000).toISOString();
      const appraisingDeadline = new Date(createdAtMs + 10 * 24 * 3600 * 1000).toISOString();

      let activeDeadline = screeningDeadline;
      if (status === 'PREPARING') activeDeadline = preparingDeadline;
      else if (status === 'DECISION_ISSUED') activeDeadline = decisionIssuedDeadline;
      else if (status === 'ON_SITE') activeDeadline = onSiteDeadline;
      else if (status === 'REPORTING') activeDeadline = reportingDeadline;
      else if (status === 'APPRAISING') activeDeadline = appraisingDeadline;

      const remainingMs = new Date(activeDeadline).getTime() - now;
      const remainingHours = Math.round(remainingMs / (3600 * 1000));
      const isOverdue = remainingMs < 0;

      return c.json({
        status: 'success',
        data: {
          caseId: caseItem.id,
          code: caseItem.code,
          status,
          activeDeadline,
          remainingHours,
          isOverdue,
          deadlines: {
            screeningDeadline,
            preparingDeadline,
            decisionIssuedDeadline,
            onSiteDeadline,
            reportingDeadline,
            appraisingDeadline
          }
        }
      });
    }
    return c.json({ status: 'error', message: 'D1 database không khả dụng' }, 500);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/cases/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    if (!db) {
      return c.json({ status: 'error', message: 'CSDL không khả dụng' }, 500);
    }

    const caseItem = await db.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
    if (!caseItem) {
      return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
    }

    const site = caseItem.siteId ? await db.prepare('SELECT * FROM sites WHERE id = ?').bind(caseItem.siteId).first().catch(() => null) : null;
    const complaint = caseItem.complaintId ? await db.prepare('SELECT * FROM complaints WHERE id = ?').bind(caseItem.complaintId).first().catch(() => null) : null;

    let assigneeUser = null;
    if (caseItem.assignedTo) {
      assigneeUser = await db.prepare('SELECT id, full_name, email, role FROM users WHERE id = ?').bind(caseItem.assignedTo).first().catch(() => null);
    }

    const { results: timelineRaw } = await db.prepare('SELECT * FROM case_timelines WHERE caseId = ? ORDER BY createdAt DESC').bind(caseItem.id).all().catch(() => ({ results: [] }));
    const { results: explanations } = await db.prepare('SELECT * FROM contractor_explanations WHERE caseId = ? ORDER BY createdAt DESC').bind(caseItem.id).all().catch(() => ({ results: [] }));
    const { results: decisions } = await db.prepare('SELECT * FROM sanction_decisions WHERE caseId = ? ORDER BY createdAt DESC').bind(caseItem.id).all().catch(() => ({ results: [] }));
    const { results: statusHistories } = await db.prepare('SELECT * FROM case_status_history WHERE caseId = ? ORDER BY createdAt ASC').bind(caseItem.id).all().catch(() => ({ results: [] }));
    const { results: evidences } = await db.prepare('SELECT * FROM evidences WHERE caseId = ? AND deletedAt IS NULL ORDER BY createdAt DESC').bind(caseItem.id).all().catch(() => ({ results: [] }));
    const { results: tasks } = await db.prepare('SELECT * FROM tasks WHERE (case_id = ? OR site_id = ?) AND deleted_at IS NULL ORDER BY created_at DESC').bind(caseItem.id, caseItem.siteId || '').all().catch(() => ({ results: [] }));
    const latestInspection = await db.prepare('SELECT * FROM inspections WHERE (caseId = ? OR siteId = ?) ORDER BY createdAt DESC LIMIT 1').bind(caseItem.id, caseItem.siteId || '').first().catch(() => null);

    const stepMeta = deriveWorkflowStep(caseItem.status);
    const nextAction = getNextAction(caseItem);

    const beforePhotos = (evidences || []).filter(e => e.photoType === 'BEFORE' || e.type === 'BEFORE' || (!e.photoType && !e.type)).map(e => e.url || e.fileUrl).filter(Boolean);
    const afterPhotos = (evidences || []).filter(e => e.photoType === 'AFTER' || e.type === 'AFTER').map(e => e.url || e.fileUrl).filter(Boolean);

    const formattedTimeline = (timelineRaw && timelineRaw.length > 0) ? timelineRaw.map(t => ({
      id: t.id,
      title: t.eventTitle || t.title,
      desc: t.eventDescription || t.description || t.desc,
      actor: t.actorName || t.actor || 'Hệ thống',
      time: t.createdAt ? new Date(t.createdAt).toLocaleString('vi-VN') : 'Vừa xong'
    })) : [
      { time: new Date(caseItem.createdAt).toLocaleString('vi-VN'), title: 'Tiếp nhận hồ sơ', desc: 'Hồ sơ được tạo và lưu vào CSDL D1/SQLite.', actor: 'Hệ thống' }
    ];

    const formattedTasks = (tasks || []).map(t => ({
      id: t.id,
      title: t.title,
      deadline: t.due_at ? new Date(t.due_at).toLocaleDateString('vi-VN') : 'Trong 48h',
      status: t.status === 'COMPLETED' ? 'Đã xong' : t.status === 'IN_PROGRESS' ? 'Đang làm' : 'Chưa bắt đầu',
      statusRaw: t.status,
      assignedTo: t.assigned_profile_id
    }));

    const assigneeName = assigneeUser?.full_name || caseItem.assignedTo || 'Chưa phân công';
    const assigneeInitials = assigneeName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'CB';

    const aggregatePayload = {
      case: {
        id: caseItem.id,
        code: caseItem.code,
        title: caseItem.title,
        description: caseItem.description,
        status: caseItem.status === 'CLOSED' || caseItem.status === 'COMPLETED' ? 'Đã đóng' : 'Đang xử lý',
        rawStatus: caseItem.status,
        priority: caseItem.priority || 'HIGH',
        slaDeadline: caseItem.slaDeadline,
        currentStep: stepMeta.label,
        currentStepNumber: stepMeta.step,
        dustRiskScore: site?.dustRiskScore ?? caseItem.dustRiskScore ?? 75,
        createdAt: caseItem.createdAt,
        updatedAt: caseItem.updatedAt
      },
      report: complaint || { id: caseItem.complaintId || null, description: caseItem.description },
      site: site || { id: caseItem.siteId, name: 'Công trình xây dựng', address: 'Hà Nội' },
      assignment: {
        assignedTo: caseItem.assignedTo,
        assigneeName,
        assigneeInitials,
        assignedEmail: assigneeUser?.email || null
      },
      tasks: formattedTasks,
      evidence: evidences || [],
      inspection: latestInspection || null,
      remediation: explanations || [],
      timeline: formattedTimeline,
      nextAction,
      currentStep: stepMeta.label,
      currentStepNumber: stepMeta.step,
      deadline: caseItem.slaDeadline ? new Date(caseItem.slaDeadline).toLocaleDateString('vi-VN') : '48 giờ',
      id: caseItem.id,
      code: caseItem.code,
      title: caseItem.title,
      description: caseItem.description,
      status: caseItem.status === 'CLOSED' || caseItem.status === 'COMPLETED' ? 'Đã đóng' : 'Đang xử lý',
      rawStatus: caseItem.status,
      priority: caseItem.priority || 'HIGH',
      dustRiskScore: site?.dustRiskScore ?? caseItem.dustRiskScore ?? 75,
      assigneeName,
      assigneeInitials,
      siteName: site?.name || 'Công trình xây dựng',
      address: site?.address || 'Hà Nội',
      violationType: 'Phát tán bụi do thiếu che chắn và rửa lốp',
      emissionSource: 'Bãi tập kết vật liệu rời và phương tiện vận tải',
      missingEvidences: [
        { id: 1, title: 'Ảnh chụp trạm rửa xe cổng chính', action: 'Bổ sung', type: 'photo' },
        { id: 2, title: 'Biên bản làm việc với chỉ huy trưởng', action: 'Tải lên', type: 'document' }
      ],
      beforePhotos: beforePhotos.length > 0 ? beforePhotos : ['https://images.unsplash.com/photo-1541888946425-d0fbb180c5f2?auto=format&fit=crop&w=600&q=80'],
      afterPhotos: afterPhotos.length > 0 ? afterPhotos : ['https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=600&q=80'],
      evidencePhotos: {
        before: beforePhotos,
        after: afterPhotos
      },
      todoTasks: formattedTasks
    };

    return c.json({
      status: 'success',
      data: aggregatePayload
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleCaseTransition = (targetStatus, defaultEventTitle) => async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const actorRole = (user?.role || 'staff').toLowerCase();

    if (actorRole === 'citizen') {
      return c.json({
        code: 'FORBIDDEN',
        status: 'error',
        message: 'Chỉ cán bộ có thẩm quyền mới được thay đổi trạng thái hồ sơ vụ việc.'
      }, 403);
    }

    const actorName = user?.name || user?.fullName || 'Cán bộ Thanh tra';
    const now = new Date().toISOString();
    const normalizedTarget = normalizeStatus(targetStatus);
    const db = getD1OrSqlite(c.env);

    if (db) {
      const existing = await db.prepare('SELECT * FROM cases WHERE id = ? OR code = ?').bind(id, id).first();
      if (existing) {
        try {
          validateCaseTransition(existing.status, normalizedTarget, {
            role: actorRole,
            reason: body.note || body.description,
            context: body
          });
        } catch (smErr) {
          return c.json(formatRfc7807Error(400, 'INVALID_TRANSITION', 'Invalid Transition', smErr.message, c.req.path), 400);
        }
      }

      const caseDbId = existing ? existing.id : id;
      const previousStatus = existing ? existing.status : 'SCREENING';

      await db.prepare('UPDATE cases SET status = ?, updatedAt = ? WHERE id = ? OR code = ?').bind(normalizedTarget, now, id, id).run();

      const timelineId = generateId('tl');
      await db.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, caseDbId, body.title || defaultEventTitle, body.note || body.description || '', `STATUS_${normalizedTarget}`, actorName, actorRole, now).run();

      const cshId = generateId('csh');
      try {
        await db.prepare(
          'INSERT INTO case_status_history (id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(cshId, caseDbId, previousStatus, normalizedTarget, user?.id || null, actorName, actorRole, body.note || body.description || defaultEventTitle, now).run();
      } catch (e) {}

      const auditId = generateId('aud');
      try {
        await db.prepare(
          'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(auditId, actorName, actorRole, `CASE_STATUS_${normalizedTarget}`, caseDbId, JSON.stringify({ previousStatus, newStatus: normalizedTarget, note: body.note || body.description }), now).run();
      } catch (e) {}
    }

    return c.json({
      status: 'success',
      data: { id, status: normalizedTarget, updatedAt: now },
      message: `Chuyển trạng thái vụ việc sang ${normalizedTarget} thành công`
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.post('/api/cases/:id/verify', handleCaseTransition('PREPARING', 'Xác minh hiện trường'));

router.post('/api/cases/:id/assign', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const actorRole = (user?.role || 'staff').toLowerCase();
    const actorRoles = (user?.roles || [actorRole]).map(r => r.toLowerCase());
    const isCoordinator = ['coordinator', 'team_lead', 'executive', 'admin', 'staff', 'super_admin', 'demo_admin'].some(r => actorRoles.includes(r) || actorRole === r);

    if (!isCoordinator) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ cán bộ có thẩm quyền mới có thể phân công hồ sơ vụ việc.', c.req.path), 403);
    }

    const actorName = user?.name || user?.fullName || 'Điều phối viên';
    const now = new Date().toISOString();
    const targetUserId = body.userId || body.assignedTo || user?.id || 'usr_staff_default';
    const db = getD1OrSqlite(c.env);

    if (db) {
      const existing = await db.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
      }

      let targetUserName = typeof body.assignedTo === 'string' && body.assignedTo.length > 2 ? body.assignedTo : 'Cán bộ';
      const targetUser = await db.prepare('SELECT id, full_name, email FROM users WHERE id = ?').bind(targetUserId).first().catch(() => null);
      if (targetUser) {
        targetUserName = targetUser.full_name || targetUser.email;
      }

      const nextStatus = existing.status === 'SCREENING' || existing.status === 'OPEN' ? 'PREPARING' : existing.status;
      const dueDate = body.dueDate || body.dueAt || new Date(Date.now() + 48 * 3600 * 1000).toISOString();

      await db.prepare(
        'UPDATE cases SET assignedTo = ?, status = ?, slaDeadline = ?, updatedAt = ? WHERE id = ?'
      ).bind(targetUserId, nextStatus, dueDate, now, existing.id).run();

      const taskId = generateId('tsk');
      const taskCode = generateRandomCode('TSK-26', 1000, 9999);
      try {
        await db.prepare(`
          INSERT INTO tasks (id, code, title, description, task_type, case_id, site_id, assigned_profile_id, due_at, status, priority, created_by, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, ?, ?)
        `).bind(
          taskId,
          taskCode,
          body.taskTitle || 'Khảo sát thực địa và kiểm tra 10 tiêu chí QCVN',
          body.notes || body.description || `Phân công kiểm tra hồ sơ ${existing.code}`,
          body.taskType || 'field_verification',
          existing.id,
          existing.siteId || null,
          targetUserId,
          dueDate,
          existing.priority || 'HIGH',
          user?.id || 'system',
          now,
          now
        ).run();
      } catch (tErr) {
        console.warn('Cannot insert auto-task:', tErr.message);
      }

      const timelineId = generateId('tl');
      await db.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, existing.id, 'Phân công cán bộ phụ trách', `Phân công hồ sơ cho ${targetUserName}. Giao nhiệm vụ khảo sát thực địa.`, 'CASE_ASSIGNED', actorName, actorRole, now).run();

      const cshId = generateId('csh');
      try {
        await db.prepare(
          'INSERT INTO case_status_history (id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(cshId, existing.id, existing.status, nextStatus, user?.id || null, actorName, actorRole, `Phân công cho ${targetUserName}`, now).run();
      } catch (e) {}

      const auditId = generateId('aud');
      try {
        await db.prepare(
          'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(auditId, actorName, actorRole, 'CASE_ASSIGN', existing.id, JSON.stringify({ assignedTo: targetUserId, targetUserName, taskId }), now).run();
      } catch (e) {}

      const notifId = generateId('notif');
      try {
        await db.prepare(`
          INSERT INTO notifications (id, user_id, case_id, type, title, message, priority, is_read, is_muted, created_at)
          VALUES (?, ?, ?, 'CASE_ASSIGNED', ?, ?, 'high', 0, 0, ?)
        `).bind(
          notifId,
          targetUserId,
          existing.id,
          `Nhiệm vụ mới: ${existing.code}`,
          `Bạn được phân công xử lý hồ sơ ${existing.code}. Hạn hoàn thành: ${new Date(dueDate).toLocaleDateString('vi-VN')}`,
          now
        ).run();
      } catch (nErr) {}

      return c.json({
        status: 'success',
        data: {
          id: existing.id,
          assignedTo: targetUserId,
          assigneeName: targetUserName,
          status: nextStatus,
          taskId,
          updatedAt: now
        },
        message: `Đã phân công hồ sơ cho ${targetUserName} và khởi tạo nhiệm vụ kiểm tra thành công`
      });
    }

    return c.json({ status: 'success', data: { id, assignedTo: targetUserId, updatedAt: now } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases/:id/close', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const actorRole = (user?.role || 'staff').toLowerCase();
    const actorRoles = (user?.roles || [actorRole]).map(r => r.toLowerCase());
    const isAuthorized = ['staff', 'inspector', 'executive', 'admin', 'super_admin', 'demo_admin'].some(r => actorRoles.includes(r) || actorRole === r);

    if (!isAuthorized) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ cán bộ có thẩm quyền mới được duyệt hoàn tất và đóng hồ sơ.', c.req.path), 403);
    }

    const actorName = user?.name || user?.fullName || 'Lãnh đạo phê duyệt';
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      const existing = await db.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
      }

      await db.prepare('UPDATE cases SET status = ?, updatedAt = ? WHERE id = ?').bind('COMPLETED', now, existing.id).run();

      const timelineId = generateId('tl');
      await db.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, existing.id, 'Duyệt hoàn tất & Đóng hồ sơ', body.notes || 'Đã nghiệm thu hiện trường đạt chuẩn môi trường theo QCVN 18:2021/BXD.', 'STATUS_COMPLETED', actorName, actorRole, now).run();

      const cshId = generateId('csh');
      try {
        await db.prepare(
          'INSERT INTO case_status_history (id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(cshId, existing.id, existing.status, 'COMPLETED', user?.id || null, actorName, actorRole, body.notes || 'Đóng hồ sơ vụ việc hoàn tất', now).run();
      } catch (e) {}

      const auditId = generateId('aud');
      try {
        await db.prepare(
          'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(auditId, actorName, actorRole, 'CASE_CLOSE', existing.id, JSON.stringify({ previousStatus: existing.status, note: body.notes }), now).run();
      } catch (e) {}

      if (existing.complaintId) {
        const notifId = generateId('notif');
        try {
          await db.prepare(`
            INSERT INTO notifications (id, user_id, case_id, type, title, message, priority, is_read, is_muted, created_at)
            VALUES (?, ?, ?, 'CASE_CLOSED', ?, ?, 'normal', 0, 0, ?)
          `).bind(
            notifId,
            existing.createdBy || 'citizen_user',
            existing.id,
            `Hồ sơ ${existing.code} đã được xử lý xong`,
            `Phản ánh của bạn đã được kiểm tra, khắc phục và đóng hồ sơ hoàn tất. Cảm ơn sự đóng góp của bạn!`,
            now
          ).run();
        } catch (nErr) {}
      }

      return c.json({
        status: 'success',
        data: { id: existing.id, status: 'COMPLETED', updatedAt: now },
        message: 'Đã duyệt đóng và lưu trữ hồ sơ thành công'
      });
    }

    return c.json({ status: 'success', data: { id, status: 'COMPLETED' } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases/:id/evidences', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const db = getD1OrSqlite(c.env);
    const now = new Date().toISOString();
    const evidenceId = generateId('ev');

    if (!body.url && !body.fileUrl) {
      return c.json(formatRfc7807Error(400, 'INVALID_INPUT', 'Bad Request', 'Vui lòng cung cấp URL hình ảnh minh chứng.', c.req.path), 400);
    }

    const fileUrl = body.url || body.fileUrl;
    const photoType = (body.photoType || body.phase || 'BEFORE').toUpperCase();
    const sha256 = body.sha256 || body.hashSha256 || await sha256Hex(`${fileUrl}-${now}`);

    if (db) {
      const existing = await db.prepare('SELECT id FROM cases WHERE id = ? OR code = ?').bind(id, id).first();
      const caseId = existing?.id || id;

      await db.prepare(`
        INSERT INTO evidences (id, caseId, url, type, sha256, uploaded_by, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(
        evidenceId,
        caseId,
        fileUrl,
        photoType,
        sha256,
        user?.id || 'staff',
        now
      ).run();

      const timelineId = generateId('tl');
      await db.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, caseId, 'Bổ sung ảnh minh chứng', `Tải lên ảnh ${photoType === 'AFTER' ? 'sau khắc phục' : 'hiện trường'}.`, 'EVIDENCE_ADDED', user?.name || user?.fullName || 'Cán bộ', user?.role || 'staff', now).run();

      return c.json({
        status: 'success',
        data: {
          id: evidenceId,
          caseId,
          url: fileUrl,
          photoType,
          sha256,
          createdAt: now
        },
        message: 'Thêm ảnh minh chứng thành công'
      }, 201);
    }

    return c.json({ status: 'success', data: { id: evidenceId, url: fileUrl, photoType } }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases/:id/inspection', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const db = getD1OrSqlite(c.env);
    const now = new Date().toISOString();
    const inspectionId = generateId('insp');

    if (db) {
      const existing = await db.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json({ status: 'error', message: 'Không tìm thấy hồ sơ vụ việc' }, 404);
      }

      const findings = body.findings || 'Đã kiểm tra 10 tiêu chí theo QCVN 18:2021/BXD và QĐ 48/2021/QĐ-UBND.';
      await db.prepare(`
        INSERT INTO inspections (id, siteId, inspectorId, findings, actionTaken, scoreDelta, sourceComplaintId, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        inspectionId,
        existing.siteId || null,
        user?.id || 'staff_default',
        findings,
        body.recommendations || 'Yêu cầu nhà thầu khắc phục vi phạm phát tán bụi trong 48h.',
        body.scoreDelta || 0,
        existing.complaintId || null,
        now,
        now
      ).run();

      const nextStatus = existing.status === 'PREPARING' || existing.status === 'SCREENING' ? 'ON_SITE' : 'REPORTING';
      await db.prepare('UPDATE cases SET status = ?, inspectionId = ?, updatedAt = ? WHERE id = ?').bind(nextStatus, inspectionId, now, existing.id).run();

      await db.prepare("UPDATE tasks SET status = 'COMPLETED', updated_at = ? WHERE case_id = ? AND status != 'COMPLETED'").bind(now, existing.id).run().catch(() => {});

      const timelineId = generateId('tl');
      await db.prepare(
        'INSERT INTO case_timelines (id, caseId, eventTitle, eventDescription, eventType, actorName, actorRole, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(timelineId, existing.id, 'Lập biên bản khảo sát hiện trường', findings, 'INSPECTION_COMPLETED', user?.name || user?.fullName || 'Đoàn kiểm tra', user?.role || 'staff', now).run();

      return c.json({
        status: 'success',
        data: {
          inspectionId,
          caseId: existing.id,
          status: nextStatus,
          updatedAt: now
        },
        message: 'Lưu biên bản khảo sát hiện trường thành công'
      });
    }

    return c.json({ status: 'success', data: { inspectionId, id } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases/:id/go-on-site', handleCaseTransition('ON_SITE', 'Tiến hành kiểm tra trực tiếp tại công trường'));
router.post('/api/cases/:id/request-explanation', handleCaseTransition('ON_SITE', 'Yêu cầu nhà thầu giải trình'));
router.post('/api/cases/:id/issue-decision', handleCaseTransition('DECISION_ISSUED', 'Ban hành quyết định thanh tra'));
router.post('/api/cases/:id/reporting-draft', handleCaseTransition('REPORTING', 'Lập báo cáo thẩm định'));
router.post('/api/cases/:id/appraise', handleCaseTransition('APPRAISING', 'Thẩm định hồ sơ vụ việc'));
router.post('/api/cases/:id/sanction', handleCaseTransition('REPORTING', 'Dự thảo quyết định xử phạt'));
router.post('/api/cases/:id/rectify', handleCaseTransition('APPRAISING', 'Nhà thầu khắc phục vi phạm'));
router.post('/api/cases/:id/complete', handleCaseTransition('COMPLETED', 'Đóng hồ sơ vụ việc hoàn tất'));

router.post('/api/cases/:id/explanations', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const user = await getAuthenticatedUser(c);
    const expId = generateId('exp');
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);

    if (db) {
      await db.prepare(
        'INSERT INTO contractor_explanations (id, caseId, contractorId, explanation, evidenceUrls, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(expId, id, user?.id || user?.name || 'Đại diện Nhà thầu', body.explanation || '', JSON.stringify(body.evidenceUrls || []), 'SUBMITTED', now).run();

      await db.prepare('UPDATE cases SET status = ?, updatedAt = ? WHERE id = ?').bind('EXPLAINED', now, id).run();
    }

    return c.json({ status: 'success', data: { id: expId, caseId: id, status: 'SUBMITTED', createdAt: now }, message: 'Nộp giải trình thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/cases/:id/decisions/:decisionId/approve', async (c) => {
  try {
    const { id, decisionId } = c.req.param();
    const user = await getAuthenticatedUser(c);
    const now = new Date().toISOString();
    const hash = await sha256Hex(`SANCTION-APPROVED-${decisionId}-${now}`);
    const db = getD1OrSqlite(c.env);

    if (db) {
      await db.prepare('UPDATE sanction_decisions SET status = ?, issuedAt = ? WHERE id = ?').bind('ISSUED', now, decisionId).run();
      await db.prepare('UPDATE cases SET status = ?, updatedAt = ? WHERE id = ?').bind('SANCTION_ISSUED', now, id).run();

      const auditId = generateId('aud');
      await db.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(auditId, user?.name || 'Giám Đốc Sở', 'executive', 'APPROVE_SANCTION', decisionId, JSON.stringify({ hash, caseId: id }), now).run();
    }

    return c.json({ status: 'success', data: { decisionId, status: 'ISSUED', hash }, message: 'Phê duyệt & ban hành quyết định thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleDeleteCase = async (c) => {
  try {
    const id = c.req.param('id');
    const now = new Date().toISOString();
    const db = getD1OrSqlite(c.env);
    if (db) {
      const existing = await db.prepare('SELECT * FROM cases WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(id, id).first();
      if (!existing) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy hồ sơ vụ việc để xóa.', c.req.path), 404);
      }
      await db.prepare('UPDATE cases SET deletedAt = ?, status = ? WHERE id = ?').bind(now, 'COMPLETED', existing.id).run();
      return c.json({ status: 'success', data: { id: existing.id, deleted: true }, message: 'Xóa hồ sơ vụ việc thành công (Soft Delete)' });
    }
    return c.json({ status: 'success', data: { id, deleted: true }, message: 'Xóa hồ sơ vụ việc thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.delete('/api/cases/:id', handleDeleteCase);

export default router;
