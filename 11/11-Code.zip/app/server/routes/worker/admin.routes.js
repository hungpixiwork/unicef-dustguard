import { Hono } from 'hono';
import {
  getSystemDataStats,
  previewResetCounts
} from '../../repositories/system.repository.js';
import {
  executeSystemReset,
  seedCanonicalData
} from '../../services/system-data.service.js';
import { getAuditLogs } from '../../repositories/audit.repository.js';
import {
  getSites,
  restoreSite,
  hardDeleteSite
} from '../../repositories/site.repository.js';
import {
  getComplaints,
  restoreComplaint,
  hardDeleteComplaint
} from '../../repositories/complaint.repository.js';
import {
  getCases,
  restoreCase,
  hardDeleteCase
} from '../../repositories/case.repository.js';
import {
  getCaseStatusHistories,
  getPriorityScoreHistories
} from '../../repositories/history.repository.js';
import {
  getAutomationConfig,
  setAutomationConfig,
  runOperationalSweep,
  getRecentAutomationRuns,
  DEFAULT_SLA_POLICY,
  PRIORITY_SLA_POLICIES,
  AUTOMATION_MODES
} from '../../services/automation-engine.service.js';
import {
  getAuthenticatedUser,
  parsePaginationParams,
  getD1OrSqlite,
  formatRfc7807Error
} from './helpers.js';

const router = new Hono();

// System Reset & Stats
router.get('/api/admin/system/data-stats', async (c) => {
  try {
    const stats = await getSystemDataStats(c.env);
    return c.json({ status: 'success', data: stats });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/system/reset-data/preview', async (c) => {
  try {
    const preview = await previewResetCounts(c.env);
    return c.json({ status: 'success', data: preview });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/system/reset-data', async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const userHeader = c.req.header('x-user-role') || 'admin';
    const actor = { id: 'admin', name: 'Admin Operator', role: userHeader };
    
    const result = await executeSystemReset({
      mode: body.mode || 'EMPTY',
      deleteStoredFiles: !!body.deleteStoredFiles,
      confirmation: body.confirmation,
      actor,
      env: c.env
    });
    return c.json({ status: 'success', data: result, message: 'Dữ liệu hệ thống đã được thiết lập lại an toàn' });
  } catch (err) {
    return c.json({
      status: 'error',
      code: err.code || 'RESET_FAILED',
      message: err.message
    }, err.statusCode || 400);
  }
});

router.post('/api/admin/system/seed-demo', async (c) => {
  try {
    const actor = { id: 'admin', name: 'Admin Operator', role: 'admin' };
    const result = await seedCanonicalData({ actor, env: c.env });
    return c.json({ status: 'success', data: result, message: 'Đã khởi tạo bộ dữ liệu mẫu chuẩn hóa' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Audit Logs
router.get('/api/admin/audit-logs', async (c) => {
  try {
    const query = c.req.query();
    const result = await getAuditLogs({
      entityType: query.entityType,
      entityId: query.entityId,
      actorId: query.actorId,
      action: query.action,
      page: Number(query.page) || 1,
      pageSize: Number(query.pageSize) || 50
    }, c.env);
    return c.json({ status: 'success', data: result });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Trash & Restore
router.get('/api/admin/trash', async (c) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(c, 50, 100);
    const [sites, complaints, cases] = await Promise.all([
      getSites({ includeDeleted: true, pageSize: limit, page }, c.env),
      getComplaints({ includeDeleted: true, pageSize: limit, page }, c.env),
      getCases({ includeDeleted: true, pageSize: limit, page }, c.env)
    ]);
    const trashSites = sites.items.filter(s => s.deletedAt);
    const trashComplaints = complaints.items.filter(comp => comp.deletedAt);
    const trashCases = cases.items.filter(cs => cs.deletedAt);
    const totalCount = trashSites.length + trashComplaints.length + trashCases.length;
    return c.json({
      status: 'success',
      data: {
        sites: trashSites,
        complaints: trashComplaints,
        cases: trashCases,
        total: totalCount
      },
      pagination: { limit, offset, count: totalCount }
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.post('/api/admin/trash/:entity/:id/restore', async (c) => {
  const { entity, id } = c.req.param();
  const actor = { id: 'admin', name: 'Admin', role: 'admin' };
  try {
    let result = null;
    if (entity === 'sites') result = await restoreSite(id, actor, c.env);
    else if (entity === 'complaints') result = await restoreComplaint(id, actor, c.env);
    else if (entity === 'cases') result = await restoreCase(id, actor, c.env);
    else return c.json({ status: 'error', message: 'Entity không hợp lệ' }, 400);

    if (!result) return c.json({ status: 'error', message: 'Không tìm thấy thực thể để khôi phục' }, 404);
    return c.json({ status: 'success', data: result, message: 'Khôi phục thực thể thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.delete('/api/admin/trash/:entity/:id/permanent', async (c) => {
  const { entity, id } = c.req.param();
  const actor = { id: 'admin', name: 'Admin', role: 'admin' };
  try {
    let result = null;
    if (entity === 'sites') result = await hardDeleteSite(id, actor, c.env);
    else if (entity === 'complaints') result = await hardDeleteComplaint(id, actor, c.env);
    else if (entity === 'cases') result = await hardDeleteCase(id, actor, c.env);
    else return c.json({ status: 'error', message: 'Entity không hợp lệ' }, 400);

    return c.json({ status: 'success', data: result, message: 'Đã xóa vĩnh viễn thực thể' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Domain History Endpoints
router.get('/api/cases/:id/history', async (c) => {
  const id = c.req.param('id');
  try {
    const histories = await getCaseStatusHistories(id, c.env);
    return c.json({ status: 'success', data: histories });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

router.get('/api/sites/:id/priority-history', async (c) => {
  const id = c.req.param('id');
  try {
    const histories = await getPriorityScoreHistories(id, c.env);
    return c.json({ status: 'success', data: histories });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Automation Engine & Soft SLA Sweep
router.get('/api/automation/status', async (c) => {
  const config = getAutomationConfig(c.env || {});
  return c.json({ status: 'success', data: config, message: 'Trạng thái động cơ tự động hóa & Cron' });
});

router.post('/api/automation/toggle', async (c) => {
  const user = await getAuthenticatedUser(c);
  if (!user || !['staff', 'inspector', 'admin', 'executive', 'demo_admin'].includes(user.role)) {
    return c.json({ status: 'error', statusCode: 403, message: 'Forbidden' }, 403);
  }
  const body = await c.req.json().catch(() => ({}));
  const updatedConfig = setAutomationConfig(body);
  return c.json({ status: 'success', data: updatedConfig, message: 'Cập nhật cấu hình & chế độ tự động hóa thành công' });
});

router.post('/api/automation/sweep', async (c) => {
  const user = await getAuthenticatedUser(c);
  if (!user || !['staff', 'inspector', 'admin', 'executive', 'demo_admin'].includes(user.role)) {
    return c.json({ status: 'error', statusCode: 403, message: 'Forbidden' }, 403);
  }
  const body = await c.req.json().catch(() => ({}));
  const report = await runOperationalSweep(c.env || {}, body);
  return c.json({ status: 'success', data: report, message: 'Thực thi quét tự động (Operational Sweep) hoàn tất.' });
});

router.get('/api/automation/runs', async (c) => {
  const user = await getAuthenticatedUser(c);
  if (!user || !['staff', 'inspector', 'admin', 'executive', 'demo_admin'].includes(user.role)) {
    return c.json({ status: 'error', statusCode: 403, message: 'Forbidden' }, 403);
  }
  const limit = parseInt(c.req.query('limit') || '20', 10);
  const runs = await getRecentAutomationRuns(c.env || {}, limit);
  return c.json({ status: 'success', data: { runs, count: runs.length }, message: 'Danh sách lịch sử thực thi tác vụ tự động' });
});

router.get('/api/automation/policy', async (c) => {
  return c.json({
    status: 'success',
    data: {
      defaultPolicy: DEFAULT_SLA_POLICY,
      priorityPolicies: PRIORITY_SLA_POLICIES,
      modes: AUTOMATION_MODES
    },
    message: 'Cấu hình chính sách tự động hóa & SLA mềm'
  });
});

// QCVN 05:2023/BTNMT, SLA & Geofence System Settings (D1 SQLite SSOT)
export const DEFAULT_SYSTEM_SETTINGS = {
  pm25Limit24h: 50,
  pm25Limit1h: 100,
  pm10Limit24h: 100,
  tspLimit24h: 300,
  so2Limit1h: 350,
  no2Limit1h: 200,
  coLimit1h: 30000,
  geofenceBufferMeters: 50,
  slaEmergencyHours: 24,
  slaStandardHours: 48,
  zaloWebhookUrl: 'https://openapi.zalo.me/v3.0/oa/message/transaction',
  telegramBotToken: 'bot812938472:AAFH89s-dustguard-alert',
  telegramChatId: '-1002384719283',
  d1AutoBackup: true,
  r2EvidenceRetentionDays: 365
};

const SETTINGS_METADATA_KEY = 'system_settings_qcvn05';

const handleGetSettings = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    let settings = { ...DEFAULT_SYSTEM_SETTINGS };

    if (db) {
      try {
        const row = await db.prepare('SELECT value FROM system_metadata WHERE key = ?').bind(SETTINGS_METADATA_KEY).first();
        if (row && row.value) {
          const parsed = JSON.parse(row.value);
          settings = { ...DEFAULT_SYSTEM_SETTINGS, ...parsed };
        }
      } catch (dbErr) {
        // Fallback to default if table is not yet populated
      }
    }

    return c.json({
      status: 'success',
      data: settings,
      message: 'Lấy cấu hình hệ thống và quy chuẩn QCVN 05:2023 thành công'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

router.get('/api/admin/settings', handleGetSettings);
router.get('/api/v1/admin/settings', handleGetSettings);
router.get('/api/staff/settings', handleGetSettings);
router.get('/api/v1/staff/settings', handleGetSettings);
router.get('/api/settings', handleGetSettings);
router.get('/api/v1/settings', handleGetSettings);

const handleUpdateSettings = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const isAdminOrStaff = user && ['admin', 'super_admin', 'demo_admin', 'executive', 'staff'].includes((user.role || '').toLowerCase());
    if (!isAdminOrStaff) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền thay đổi cấu hình hệ thống.', c.req.path), 403);
    }

    const body = await c.req.json().catch(() => ({}));
    const db = getD1OrSqlite(c.env);

    // Merge with current or default
    let currentSettings = { ...DEFAULT_SYSTEM_SETTINGS };
    if (db) {
      try {
        const row = await db.prepare('SELECT value FROM system_metadata WHERE key = ?').bind(SETTINGS_METADATA_KEY).first();
        if (row && row.value) {
          currentSettings = { ...currentSettings, ...JSON.parse(row.value) };
        }
      } catch (e) {}
    }

    const updatedSettings = {
      ...currentSettings,
      ...body,
      pm25Limit24h: body.pm25Limit24h !== undefined ? Number(body.pm25Limit24h) : currentSettings.pm25Limit24h,
      pm25Limit1h: body.pm25Limit1h !== undefined ? Number(body.pm25Limit1h) : currentSettings.pm25Limit1h,
      pm10Limit24h: body.pm10Limit24h !== undefined ? Number(body.pm10Limit24h) : currentSettings.pm10Limit24h,
      tspLimit24h: body.tspLimit24h !== undefined ? Number(body.tspLimit24h) : currentSettings.tspLimit24h,
      geofenceBufferMeters: body.geofenceBufferMeters !== undefined ? Number(body.geofenceBufferMeters) : currentSettings.geofenceBufferMeters,
      slaEmergencyHours: body.slaEmergencyHours !== undefined ? Number(body.slaEmergencyHours) : currentSettings.slaEmergencyHours,
      slaStandardHours: body.slaStandardHours !== undefined ? Number(body.slaStandardHours) : currentSettings.slaStandardHours
    };

    const now = new Date().toISOString();
    if (db) {
      try {
        await db.prepare(`
          INSERT INTO system_metadata (key, value, updated_at)
          VALUES (?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).bind(SETTINGS_METADATA_KEY, JSON.stringify(updatedSettings), now).run();
      } catch (dbErr) {
        // If ON CONFLICT syntax differs in older sqlite
        try {
          await db.prepare('DELETE FROM system_metadata WHERE key = ?').bind(SETTINGS_METADATA_KEY).run();
          await db.prepare('INSERT INTO system_metadata (key, value, updated_at) VALUES (?, ?, ?)').bind(SETTINGS_METADATA_KEY, JSON.stringify(updatedSettings), now).run();
        } catch (innerErr) {}
      }
    }

    return c.json({
      status: 'success',
      data: updatedSettings,
      message: 'Cập nhật cấu hình quy chuẩn QCVN 05:2023 và hệ thống thành công'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

router.put('/api/admin/settings', handleUpdateSettings);
router.put('/api/v1/admin/settings', handleUpdateSettings);
router.put('/api/staff/settings', handleUpdateSettings);
router.put('/api/v1/staff/settings', handleUpdateSettings);
router.put('/api/settings', handleUpdateSettings);
router.put('/api/v1/settings', handleUpdateSettings);
router.post('/api/admin/settings', handleUpdateSettings);
router.post('/api/staff/settings', handleUpdateSettings);
router.post('/api/settings', handleUpdateSettings);
router.patch('/api/admin/settings', handleUpdateSettings);
router.patch('/api/staff/settings', handleUpdateSettings);
router.patch('/api/v1/staff/settings', handleUpdateSettings);
router.patch('/api/settings', handleUpdateSettings);

const handleResetSettings = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const isAdminOrStaff = user && ['admin', 'super_admin', 'demo_admin', 'executive', 'staff'].includes((user.role || '').toLowerCase());
    if (!isAdminOrStaff) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền khôi phục cấu hình hệ thống.', c.req.path), 403);
    }

    const db = getD1OrSqlite(c.env);
    const now = new Date().toISOString();
    const defaultSettings = { ...DEFAULT_SYSTEM_SETTINGS };

    if (db) {
      try {
        await db.prepare(`
          INSERT INTO system_metadata (key, value, updated_at)
          VALUES (?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).bind(SETTINGS_METADATA_KEY, JSON.stringify(defaultSettings), now).run();
      } catch (dbErr) {
        try {
          await db.prepare('DELETE FROM system_metadata WHERE key = ?').bind(SETTINGS_METADATA_KEY).run();
          await db.prepare('INSERT INTO system_metadata (key, value, updated_at) VALUES (?, ?, ?)').bind(SETTINGS_METADATA_KEY, JSON.stringify(defaultSettings), now).run();
        } catch (innerErr) {}
      }
    }

    return c.json({
      status: 'success',
      data: defaultSettings,
      message: 'Đã khôi phục cấu hình mặc định theo quy chuẩn QCVN 05:2023 thành công'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};

router.post('/api/admin/settings/reset', handleResetSettings);
router.post('/api/settings/reset', handleResetSettings);

export default router;
