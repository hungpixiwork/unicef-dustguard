import { Hono } from 'hono';
import { VIETNAM_PROVINCES, VIETNAM_WARDS_BY_PROVINCE } from '../../shared/vietnam-administrative.js';
import { getD1OrSqlite } from './helpers.js';

const router = new Hono();

// Provinces & Wards
router.get('/api/public/provinces', async (c) => {
  try {
    c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare('SELECT * FROM provinces ORDER BY code ASC').all().catch(() => ({ results: [] }));
      if (results && results.length > 0) {
        return c.json({ status: 'success', data: results });
      }
    }
    return c.json({ status: 'success', data: VIETNAM_PROVINCES });
  } catch (err) {
    return c.json({ status: 'success', data: VIETNAM_PROVINCES });
  }
});

router.get('/api/public/provinces/:code/wards', async (c) => {
  try {
    c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
    const code = c.req.param('code');
    if (c.env && c.env.DB) {
      const { results } = await c.env.DB.prepare('SELECT * FROM wards WHERE province_code = ? ORDER BY name ASC').bind(code).all().catch(() => ({ results: [] }));
      if (results && results.length > 0) {
        return c.json({ status: 'success', data: results });
      }
    }
    const fallbackWards = VIETNAM_WARDS_BY_PROVINCE[code] || VIETNAM_WARDS_BY_PROVINCE['01'] || [];
    return c.json({ status: 'success', data: fallbackWards });
  } catch (err) {
    const fallbackWards = VIETNAM_WARDS_BY_PROVINCE[code] || [];
    return c.json({ status: 'success', data: fallbackWards });
  }
});

router.get('/api/public/gis/detect-location', (c) => {
  c.header('Cache-Control', 'public, max-age=3600, s-maxage=86400');
  return c.json({
    status: 'success',
    data: {
      wardCode: '00001',
      wardName: 'Mai Dịch',
      wardFullName: 'Phường Mai Dịch',
      provinceCode: '01',
      provinceName: 'Hà Nội',
      provinceFullName: 'Thành phố Hà Nội'
    }
  });
});

router.get('/api/public/stats', async (c) => {
  c.header('Cache-Control', 'public, max-age=30, s-maxage=60');
  let total = 12, resolved = 10;
  if (c.env && c.env.DB) {
    try {
      const totalRow = await c.env.DB.prepare('SELECT COUNT(*) as cnt FROM complaints WHERE deletedAt IS NULL').first();
      const resolvedRow = await c.env.DB.prepare("SELECT COUNT(*) as cnt FROM complaints WHERE status = 'RESOLVED' AND deletedAt IS NULL").first();
      if (totalRow) total = totalRow.cnt;
      if (resolvedRow) resolved = resolvedRow.cnt;
    } catch (e) {}
  }
  const rate = total > 0 ? `${Math.round((resolved / total) * 100)}%` : '92%';
  return c.json({ status: 'success', data: { total, resolvedRate: rate, avgVerify: '2.4h' } });
});

function parseSpatialCoordinates(rawCoords) {
  if (!rawCoords) return { lat: null, lng: null };
  if (typeof rawCoords === 'object') {
    const lat = typeof rawCoords.lat === 'number' ? rawCoords.lat : parseFloat(rawCoords.lat || rawCoords.latitude);
    const lng = typeof rawCoords.lng === 'number' ? rawCoords.lng : parseFloat(rawCoords.lng || rawCoords.longitude);
    if (!isNaN(lat) && !isNaN(lng) && Number.isFinite(lat) && Number.isFinite(lng) && !(lat === 0 && lng === 0) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      return { lat, lng };
    }
    return { lat: null, lng: null };
  }
  if (typeof rawCoords === 'string') {
    const trimmed = rawCoords.trim();
    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        const lat = typeof parsed.lat === 'number' ? parsed.lat : parseFloat(parsed.lat || parsed.latitude);
        const lng = typeof parsed.lng === 'number' ? parsed.lng : parseFloat(parsed.lng || parsed.longitude);
        if (!isNaN(lat) && !isNaN(lng) && Number.isFinite(lat) && Number.isFinite(lng) && !(lat === 0 && lng === 0) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
          return { lat, lng };
        }
      } catch {}
    }
    const parts = trimmed.split(',').map(p => parseFloat(p.trim()));
    if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1]) && Number.isFinite(parts[0]) && Number.isFinite(parts[1])) {
      const lat = parts[0];
      const lng = parts[1];
      if (!(lat === 0 && lng === 0) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        return { lat, lng };
      }
    }
  }
  return { lat: null, lng: null };
}

const handleGetMapFeatures = async (c) => {
  c.header('Cache-Control', 'public, max-age=15, s-maxage=30');
  const db = getD1OrSqlite(c.env);
  
  let sites = [];
  let sensors = [];
  let reports = [];
  let hotspots = [];
  let missions = [];
  let summary = {
    total: 0,
    mapped: 0,
    missingLocation: 0,
    highRiskCount: 0,
    warningCount: 0,
    safeCount: 0,
    activeSensorsCount: 0,
    recentReportsCount: 0,
    resolvedCount: 0
  };

  try {
    const [sitesRes, sensorsRes, complaintsRes, readingsRes] = await Promise.all([
      db.prepare('SELECT id, code, name, address, ward, province, coordinates, dustRiskScore, riskLevel, status FROM sites WHERE deletedAt IS NULL ORDER BY dustRiskScore DESC LIMIT 200').all().catch(() => ({ results: [] })),
      db.prepare('SELECT s.id, s.code, s.siteId, s.name, s.status, si.coordinates as siteCoordinates FROM sensors s LEFT JOIN sites si ON s.siteId = si.id WHERE s.deletedAt IS NULL LIMIT 200').all().catch(() => ({ results: [] })),
      db.prepare('SELECT c.id, c.code, c.siteId, c.description, c.address, c.ward, c.status, c.createdAt, si.coordinates as siteCoordinates FROM complaints c LEFT JOIN sites si ON c.siteId = si.id WHERE c.deletedAt IS NULL ORDER BY c.createdAt DESC LIMIT 100').all().catch(() => ({ results: [] })),
      db.prepare('SELECT sensorId, pm10, pm25, timestamp FROM sensor_readings ORDER BY timestamp DESC LIMIT 200').all().catch(() => ({ results: [] }))
    ]);

    const rawSites = sitesRes.results || [];
    const rawSensors = sensorsRes.results || [];
    const rawComplaints = complaintsRes.results || [];
    const rawReadings = readingsRes.results || [];

    const latestReadingMap = {};
    for (const r of rawReadings) {
      if (!latestReadingMap[r.sensorId]) {
        latestReadingMap[r.sensorId] = r;
      }
    }

    let safeCount = 0;
    sites = rawSites.map((s, idx) => {
      const coords = parseSpatialCoordinates(s.coordinates || (s.lat != null && s.lng != null ? { lat: s.lat, lng: s.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;

      const score = s.dustRiskScore || 45;
      const isHigh = score >= 75 || s.riskLevel === 'HIGH' || s.riskLevel === 'CRITICAL';
      const isMed = score >= 45 && score < 75;
      const riskLevel = isHigh ? 'HIGH' : isMed ? 'MEDIUM' : 'LOW';
      const tier = isHigh ? 'red' : isMed ? 'amber' : 'green';
      const complaintsCount = rawComplaints.filter(c => c.siteId === s.id || c.siteId === s.code).length;

      if (isHigh) summary.highRiskCount++;
      else if (isMed) summary.warningCount++;
      else safeCount++;

      return {
        id: s.id || `SITE-${idx}`,
        code: s.code || `SITE-${idx + 1}`,
        name: s.name || 'Công trình xây dựng đô thị',
        address: s.address || 'Hà Nội',
        ward: s.ward || 'Cầu Giấy',
        province: s.province || 'Hà Nội',
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        pm25: Math.round(score * 0.95),
        dustRiskScore: score,
        riskLevel,
        tier,
        status: s.status || (isHigh ? 'INSPECTING' : 'NORMAL'),
        complaintsCount: complaintsCount || (isHigh ? 3 : 1),
        actions: isHigh ? 'Yêu cầu dập bụi và rửa xe ra vào' : 'Tuân thủ quy chuẩn kiểm soát bụi'
      };
    });

    summary.total = sites.length;
    summary.mapped = sites.filter(s => s.hasLocation).length;
    summary.missingLocation = summary.total - summary.mapped;
    summary.safeCount = safeCount;

    const bboxParam = c.req.query('bbox');
    let bboxBounds = null;
    if (bboxParam && typeof bboxParam === 'string') {
      const parts = bboxParam.split(',').map(p => parseFloat(p.trim()));
      if (parts.length === 4 && parts.every(p => !isNaN(p))) {
        bboxBounds = { minLng: parts[0], minLat: parts[1], maxLng: parts[2], maxLat: parts[3] };
      }
    }

    if (bboxBounds) {
      const isAntimeridian = bboxBounds.minLng > bboxBounds.maxLng;
      const inLng = (lng) => isAntimeridian ? (lng >= bboxBounds.minLng || lng <= bboxBounds.maxLng) : (lng >= bboxBounds.minLng && lng <= bboxBounds.maxLng);
      const inLat = (lat) => lat >= bboxBounds.minLat && lat <= bboxBounds.maxLat;

      sites = sites.filter(s => s.lat != null && s.lng != null && inLng(s.lng) && inLat(s.lat));
    }

    sensors = rawSensors.map((sens, idx) => {
      const coords = parseSpatialCoordinates(sens.coordinates || sens.siteCoordinates || (sens.lat != null && sens.lng != null ? { lat: sens.lat, lng: sens.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;

      const reading = latestReadingMap[sens.id] || latestReadingMap[sens.code] || {};
      const pm25 = reading.pm25 !== undefined ? reading.pm25 : (sens.pm25 !== undefined ? reading.pm25 : 42);
      const isOnline = sens.status === 'ONLINE' || sens.status === 'ACTIVE' || !sens.status;
      if (isOnline) summary.activeSensorsCount++;

      return {
        id: sens.id || `SENS-${idx}`,
        code: sens.code || `SENSOR-0${idx + 1}`,
        siteId: sens.siteId || null,
        name: sens.name || `Trạm quan trắc ${sens.code || idx + 1}`,
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        pm25: Math.round(pm25),
        status: isOnline ? 'ONLINE' : 'OFFLINE',
        lastSeen: sens.lastSeen || reading.timestamp || '2 phút trước',
        trend: pm25 > 65 ? 'UP' : pm25 < 35 ? 'DOWN' : 'STABLE'
      };
    });

    if (bboxBounds) {
      const isAntimeridian = bboxBounds.minLng > bboxBounds.maxLng;
      const inLng = (lng) => isAntimeridian ? (lng >= bboxBounds.minLng || lng <= bboxBounds.maxLng) : (lng >= bboxBounds.minLng && lng <= bboxBounds.maxLng);
      const inLat = (lat) => lat >= bboxBounds.minLat && lat <= bboxBounds.maxLat;

      sensors = sensors.filter(s => s.lat != null && s.lng != null && inLng(s.lng) && inLat(s.lat));
    }

    reports = rawComplaints.map((comp, idx) => {
      const coords = parseSpatialCoordinates(comp.coordinates || comp.siteCoordinates || (comp.lat != null && comp.lng != null ? { lat: comp.lat, lng: comp.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;

      summary.recentReportsCount++;
      if (comp.status === 'RESOLVED') summary.resolvedCount++;

      return {
        id: comp.id || `REP-${idx}`,
        code: comp.code || `DG-PA-${1000 + idx}`,
        siteId: comp.siteId || null,
        title: comp.title || comp.description || 'Phát sinh bụi mịn từ công trình thi công',
        address: comp.address || 'Khu vực dân cư lân cận',
        ward: comp.ward || 'Cầu Giấy',
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        status: comp.status || 'PENDING',
        riskScore: comp.riskScore || 65,
        category: comp.category || 'DUST_EMISSION',
        createdAt: comp.createdAt || new Date().toISOString()
      };
    });

    if (bboxBounds) {
      const isAntimeridian = bboxBounds.minLng > bboxBounds.maxLng;
      const inLng = (lng) => isAntimeridian ? (lng >= bboxBounds.minLng || lng <= bboxBounds.maxLng) : (lng >= bboxBounds.minLng && lng <= bboxBounds.maxLng);
      const inLat = (lat) => lat >= bboxBounds.minLat && lat <= bboxBounds.maxLat;

      reports = reports.filter(r => r.lat != null && r.lng != null && inLng(r.lng) && inLat(r.lat));
    }

    hotspots = sites.filter(s => s.dustRiskScore >= 70 && s.lat != null && s.lng != null).slice(0, 5).map((s, idx) => ({
      id: `HOTSPOT-${idx + 1}`,
      name: `Điểm nóng ${s.ward || 'Hà Nội'} #${idx + 1}`,
      lat: s.lat,
      lng: s.lng,
      radius: 400 + idx * 50,
      severity: s.dustRiskScore >= 80 ? 'CRITICAL' : 'HIGH',
      score: s.dustRiskScore,
      reason: `${s.complaintsCount} phản ánh trong 24h · PM2.5 vượt ngưỡng QCVN`
    }));

    missions = [
      {
        id: 'MISSION-01',
        title: 'Giám sát bụi quanh trường THPT Cầu Giấy',
        ward: 'Cầu Giấy',
        lat: 21.0335,
        lng: 105.7915,
        requiredVolunteers: 6,
        currentVolunteers: 4,
        status: 'ACTIVE',
        organizer: 'Đoàn TN ĐHQGHN'
      },
      {
        id: 'MISSION-02',
        title: 'Khảo sát nồng độ bụi công trường Vành đai 3',
        ward: 'Nam Từ Liêm',
        lat: 21.0180,
        lng: 105.7760,
        requiredVolunteers: 8,
        currentVolunteers: 7,
        status: 'ACTIVE',
        organizer: 'CLB Môi trường Xanh'
      }
    ];

  } catch (err) {
    console.error('Error fetching map features:', err);
  }

  return c.json({
    status: 'success',
    data: {
      sites,
      constructions: sites,
      sensors,
      reports,
      hotspots,
      missions,
      summary
    }
  });
};

const handleGetNearbySites = async (c) => {
  c.header('Cache-Control', 'public, max-age=15, s-maxage=30');
  const db = getD1OrSqlite(c.env);
  
  const rawLat = c.req.query('lat') || c.req.query('latitude');
  const rawLng = c.req.query('lng') || c.req.query('longitude');
  const radiusKm = parseFloat(c.req.query('radius') || c.req.query('radiusKm') || '2.0');
  const maxRadius = Math.min(Math.max(isNaN(radiusKm) ? 2.0 : radiusKm, 0.1), 50.0);

  const userCoords = parseSpatialCoordinates(rawLat && rawLng ? { lat: parseFloat(rawLat), lng: parseFloat(rawLng) } : null);

  try {
    const { results: rawSites } = await db.prepare(
      'SELECT id, code, name, address, ward, province, coordinates, dustRiskScore, riskLevel, status, contractorName FROM sites WHERE deletedAt IS NULL LIMIT 200'
    ).all().catch(() => ({ results: [] }));

    const sites = (rawSites || []).map((s, idx) => {
      const coords = parseSpatialCoordinates(s.coordinates || (s.lat != null && s.lng != null ? { lat: s.lat, lng: s.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;
      const hasLocation = lat != null && lng != null;

      let distanceKm = null;
      let distanceMeters = null;

      if (hasLocation && userCoords.lat != null && userCoords.lng != null) {
        const R = 6371; // Earth radius in KM
        const dLat = ((lat - userCoords.lat) * Math.PI) / 180;
        const dLon = ((lng - userCoords.lng) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((userCoords.lat * Math.PI) / 180) *
            Math.cos((lat * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const cVal = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        distanceKm = Math.round(R * cVal * 10) / 10;
        distanceMeters = Math.round(R * cVal * 1000);
      }

      const score = s.dustRiskScore || 45;
      const isHigh = score >= 75 || s.riskLevel === 'HIGH' || s.riskLevel === 'CRITICAL';
      const isMed = score >= 45 && score < 75;
      const riskLevel = isHigh ? 'HIGH' : isMed ? 'MEDIUM' : 'LOW';
      const tier = isHigh ? 'red' : isMed ? 'amber' : 'green';

      const googleMapsUrl = hasLocation
        ? `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`
        : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s.address || 'Hà Nội')}`;

      return {
        id: s.id || `SITE-${idx}`,
        code: s.code || `SITE-${idx + 1}`,
        name: s.name || 'Công trình xây dựng',
        siteName: s.name || 'Công trình xây dựng',
        address: s.address || 'Hà Nội',
        ward: s.ward || 'Cầu Giấy',
        province: s.province || 'Hà Nội',
        lat,
        lng,
        hasLocation,
        distanceKm,
        distanceMeters,
        distance: distanceMeters !== null
          ? (distanceMeters < 1000 ? `${distanceMeters}m` : `${distanceKm.toFixed(1)}km`)
          : 'Chưa có tọa độ',
        pm25: Math.round(score * 0.95),
        pm10: Math.round(score * 1.8),
        dustRiskScore: score,
        riskLevel,
        tier,
        status: s.status || 'ACTIVE',
        contractorName: s.contractorName || 'Đơn vị thi công',
        googleMapsUrl
      };
    });

    // If user coordinates provided, filter by radius and sort by distance
    let filtered = sites;
    if (userCoords.lat != null && userCoords.lng != null) {
      filtered = sites
        .filter(s => s.distanceKm !== null && s.distanceKm <= maxRadius)
        .sort((a, b) => (a.distanceKm || 0) - (b.distanceKm || 0));
    }

    return c.json({
      status: 'success',
      data: {
        items: filtered,
        total: filtered.length,
        radiusKm: maxRadius,
        userLocation: userCoords.lat != null ? userCoords : null
      }
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/map/features', handleGetMapFeatures);
router.get('/api/map', handleGetMapFeatures);
router.get('/api/v1/map/features', handleGetMapFeatures);
router.get('/api/v1/map', handleGetMapFeatures);
router.get('/api/spatial/entities', handleGetMapFeatures);
router.get('/api/v1/spatial/entities', handleGetMapFeatures);
router.get('/api/spatial/features', handleGetMapFeatures);
router.get('/api/v1/spatial/features', handleGetMapFeatures);
router.get('/api/public/map/features', handleGetMapFeatures);
router.get('/api/public/map', handleGetMapFeatures);

router.get('/api/public/sites/nearby', handleGetNearbySites);
router.get('/api/sites/nearby', handleGetNearbySites);
router.get('/api/v1/public/sites/nearby', handleGetNearbySites);
router.get('/api/v1/sites/nearby', handleGetNearbySites);

export default router;
