import { Hono } from 'hono';
import crypto from 'node:crypto';
import {
  generateId,
  formatRfc7807Error,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

const DEFAULT_SECRET = process.env.IOT_PRE_SHARED_KEY || 'dustguard_secret_key_2026';

/**
 * Helper to compute or verify HMAC-SHA256
 */
function verifyHmacSignature(rawPayload, signature, secret) {
  if (!signature) return false;
  try {
    const computed = crypto.createHmac('sha256', secret).update(rawPayload).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(computed, 'utf8'), Buffer.from(signature, 'utf8'));
  } catch {
    return false;
  }
}

/**
 * POST /api/iot/v1/readings
 * Main telemetry ingestion endpoint for physical ESP32 Nodes
 */
router.post('/api/iot/v1/readings', async (c) => {
  try {
    const rawBody = await c.req.text();
    let body;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return c.json(formatRfc7807Error(400, 'BAD_REQUEST', 'Bad Request', 'Dữ liệu JSON không hợp lệ.', c.req.path), 400);
    }

    const deviceId = body.deviceId || c.req.header('x-device-id');
    if (!deviceId) {
      return c.json(formatRfc7807Error(400, 'MISSING_DEVICE_ID', 'Validation Error', 'Thiếu deviceId của thiết bị.', c.req.path), 400);
    }

    // Security check: If signature or secret provided, verify HMAC
    const signature = c.req.header('x-signature') || body.signature;
    const clientSecret = c.req.header('x-device-secret') || body.deviceSecret;
    const clientTimestamp = c.req.header('x-timestamp') || body.timestamp;

    // Verify authentication if signature or secret is passed
    if (signature) {
      const isValid = verifyHmacSignature(rawBody, signature, DEFAULT_SECRET);
      if (!isValid) {
        return c.json(formatRfc7807Error(401, 'INVALID_SIGNATURE', 'Unauthorized', 'Chữ ký HMAC-SHA256 không hợp lệ hoặc thiết bị bị từ chối.', c.req.path), 401);
      }
    } else if (clientSecret && clientSecret !== DEFAULT_SECRET) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Khóa bí mật thiết bị (device_secret) không khớp.', c.req.path), 401);
    }

    // Validate sensor payload
    const sensors = body.sensors || {};
    const pm1 = parseFloat(sensors.pm1 ?? body.pm1 ?? 0);
    const pm25 = parseFloat(sensors.pm25 ?? body.pm25 ?? 0);
    const pm10 = parseFloat(sensors.pm10 ?? body.pm10 ?? 0);

    // Physical sanity check (0 - 1000 ug/m3)
    if (isNaN(pm25) || pm25 < 0 || pm25 > 1000 || isNaN(pm10) || pm10 < 0 || pm10 > 1000) {
      return c.json(formatRfc7807Error(422, 'INVALID_SENSOR_RANGE', 'Unprocessable Entity', 'Giá trị cảm biến nằm ngoài dải đo vật lý thực tế.', c.req.path), 422);
    }

    const system = body.system || {};
    const wifiRssi = parseInt(system.wifiRssi ?? body.wifiRssi ?? -50, 10);
    const uptime = parseInt(system.uptime ?? body.uptime ?? 0, 10);
    const firmware = system.firmware || body.firmware || '1.0.0';

    let capturedAt;
    if (clientTimestamp) {
      const tsNum = Number(clientTimestamp);
      if (!isNaN(tsNum) && tsNum > 0) {
        capturedAt = new Date(tsNum > 1e11 ? tsNum : tsNum * 1000).toISOString();
      } else {
        capturedAt = new Date(clientTimestamp).toISOString();
      }
    } else {
      capturedAt = new Date().toISOString();
    }

    const nowIso = new Date().toISOString();
    const readingId = generateId('iot_rd');

    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;

      // Ensure device exists in iot_devices
      const existingDev = await db.prepare('SELECT id FROM iot_devices WHERE device_id = ?').bind(deviceId).first();
      if (!existingDev) {
        const devId = generateId('iot_dev');
        await db.prepare(`
          INSERT INTO iot_devices (id, device_id, name, sensor_type, device_secret_hash, firmware_version, status, last_seen_at, created_at, updated_at)
          VALUES (?, ?, ?, 'APM2000', 'hmac_sha256', ?, 'ONLINE', ?, ?, ?)
        `).bind(devId, deviceId, `DustGuard Node ${deviceId}`, firmware, nowIso, nowIso, nowIso).run().catch((e) => {
          console.warn('[IoT Routes] Insert device warning:', e.message);
        });
      } else {
        await db.prepare(`
          UPDATE iot_devices 
          SET status = 'ONLINE', last_seen_at = ?, firmware_version = ?, updated_at = ?
          WHERE device_id = ?
        `).bind(nowIso, firmware, nowIso, deviceId).run().catch(() => {});
      }

      // Insert into iot_readings
      await db.prepare(`
        INSERT INTO iot_readings (id, device_id, pm1, pm25, pm10, wifi_rssi, uptime, captured_at, received_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(readingId, deviceId, pm1, pm25, pm10, wifiRssi, uptime, capturedAt, nowIso).run();

      // Legacy synchronization: If sensor exists in `sensors`, also write to `sensor_readings`
      const legacySensor = await db.prepare('SELECT id, siteId FROM sensors WHERE code = ?').bind(deviceId).first().catch(() => null);
      if (legacySensor) {
        const legacyReadingId = generateId('srd');
        await db.prepare(`
          INSERT INTO sensor_readings (id, sensorId, pm10, pm25, timestamp)
          VALUES (?, ?, ?, ?, ?)
        `).bind(legacyReadingId, legacySensor.id, pm10, pm25, capturedAt).run().catch(() => {});

        // Check for alert conditions (QCVN 05:2023/BTNMT: PM2.5 > 50 or PM10 > 100)
        if (pm25 > 50 || pm10 > 100) {
          const alertId = generateId('alt');
          const severity = (pm25 > 100 || pm10 > 150) ? 'CRITICAL' : 'HIGH';
          await db.prepare(`
            INSERT INTO alerts (id, title, siteId, sensorId, severity, pm10Value, pm25Value, priorityReasons, status, triggeredAt, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?, ?)
          `).bind(
            alertId,
            `Cảnh báo bụi vượt ngưỡng QCVN tại trạm ${deviceId}`,
            legacySensor.siteId,
            legacySensor.id,
            severity,
            pm10,
            pm25,
            `PM2.5: ${pm25} µg/m³, PM10: ${pm10} µg/m³ (Phát hiện bởi IoT Node APM2000)`,
            nowIso,
            nowIso,
            nowIso
          ).run().catch(() => {});
        }
      }
    }

    return c.json({
      status: 'success',
      statusCode: 201,
      data: {
        id: readingId,
        deviceId,
        pm1,
        pm25,
        pm10,
        wifiRssi,
        uptime,
        capturedAt,
        receivedAt: nowIso,
        verified: true
      },
      message: 'Tiếp nhận dữ liệu đo DustGuard IoT thành công.'
    }, 201);
  } catch (err) {
    console.error('[IoT Ingest Error]', err);
    return c.json(formatRfc7807Error(500, 'INGEST_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

/**
 * GET /api/iot/v1/devices
 * Danh sách thiết bị IoT và trạng thái hoạt động
 */
router.get('/api/iot/v1/devices', async (c) => {
  try {
    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;
      const { results: devices } = await db.prepare(`
        SELECT d.*, 
               (SELECT json_object('pm1', r.pm1, 'pm25', r.pm25, 'pm10', r.pm10, 'captured_at', r.captured_at, 'wifi_rssi', r.wifi_rssi)
                FROM iot_readings r WHERE r.device_id = d.device_id ORDER BY r.captured_at DESC LIMIT 1) as latest_reading
        FROM iot_devices d
        ORDER BY d.created_at DESC
      `).all().catch(() => ({ results: [] }));

      const parsedDevices = (devices || []).map(dev => {
        let latest = null;
        try {
          if (dev.latest_reading) latest = JSON.parse(dev.latest_reading);
        } catch {}
        return {
          ...dev,
          latestReading: latest
        };
      });

      return c.json({ status: 'success', data: { items: parsedDevices, total: parsedDevices.length } });
    }

    return c.json({ status: 'success', data: { items: [], total: 0 } });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Error', err.message, c.req.path), 500);
  }
});

/**
 * GET /api/iot/v1/devices/:deviceId
 */
router.get('/api/iot/v1/devices/:deviceId', async (c) => {
  try {
    const deviceId = c.req.param('deviceId');
    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;
      const device = await db.prepare('SELECT * FROM iot_devices WHERE device_id = ?').bind(deviceId).first();
      if (!device) {
        return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', `Không tìm thấy thiết bị IoT ${deviceId}`, c.req.path), 404);
      }
      const latest = await db.prepare('SELECT * FROM iot_readings WHERE device_id = ? ORDER BY captured_at DESC LIMIT 1').bind(deviceId).first();
      return c.json({ status: 'success', data: { ...device, latestReading: latest || null } });
    }
    return c.json({ status: 'error', message: 'No database connection' }, 500);
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Error', err.message, c.req.path), 500);
  }
});

/**
 * GET /api/iot/v1/devices/:deviceId/latest
 */
router.get('/api/iot/v1/devices/:deviceId/latest', async (c) => {
  try {
    const deviceId = c.req.param('deviceId');
    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;
      const reading = await db.prepare('SELECT * FROM iot_readings WHERE device_id = ? ORDER BY captured_at DESC LIMIT 1').bind(deviceId).first();
      if (!reading) {
        return c.json({
          status: 'success',
          data: {
            deviceId,
            pm1: 12.0,
            pm25: 25.0,
            pm10: 42.0,
            wifi_rssi: -55,
            uptime: 100,
            captured_at: new Date().toISOString()
          },
          isDefault: true
        });
      }
      return c.json({ status: 'success', data: reading });
    }
    return c.json({ status: 'error', message: 'No database connection' }, 500);
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Error', err.message, c.req.path), 500);
  }
});

/**
 * GET /api/iot/v1/devices/:deviceId/readings
 */
router.get('/api/iot/v1/devices/:deviceId/readings', async (c) => {
  try {
    const deviceId = c.req.param('deviceId');
    const { limit, offset } = parsePaginationParams(c, 50, 200);

    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;
      const { results } = await db.prepare(`
        SELECT * FROM iot_readings 
        WHERE device_id = ? 
        ORDER BY captured_at DESC 
        LIMIT ? OFFSET ?
      `).bind(deviceId, limit, offset).all().catch(() => ({ results: [] }));

      return c.json({
        status: 'success',
        data: {
          items: results || [],
          pagination: { limit, offset, count: (results || []).length }
        }
      });
    }

    return c.json({ status: 'success', data: { items: [], pagination: { limit, offset, count: 0 } } });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Error', err.message, c.req.path), 500);
  }
});

/**
 * POST /api/iot/v1/devices/:deviceId/heartbeat
 */
router.post('/api/iot/v1/devices/:deviceId/heartbeat', async (c) => {
  try {
    const deviceId = c.req.param('deviceId');
    const nowIso = new Date().toISOString();

    if (c.env && (c.env.DB || c.env.DATABASE)) {
      const db = c.env.DB || c.env.DATABASE;
      await db.prepare(`
        UPDATE iot_devices 
        SET status = 'ONLINE', last_seen_at = ?, updated_at = ?
        WHERE device_id = ?
      `).bind(nowIso, nowIso, deviceId).run().catch(() => {});
    }

    return c.json({
      status: 'success',
      data: { deviceId, status: 'ONLINE', timestamp: nowIso },
      message: 'Nhận tín hiệu Heartbeat thiết bị thành công.'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Error', err.message, c.req.path), 500);
  }
});

export default router;
