import { Hono } from 'hono';
import {
  calculateDEMS,
  assessGRI304,
  assessGRI305,
  createEscrowContract,
  evaluateMilestone,
  releaseMilestone,
  forfeitEscrow,
  evaluateAutomatedEscrowTrigger,
  generateESGImpactReport,
  exportCSRAuditCertificate
} from '../../../src/lib/csr-engine.js';
import { getAuthenticatedUser } from './helpers.js';

const router = new Hono();

const escrowStore = new Map();
function getOrCreateEscrow(siteId = 'BD-0237', siteName = 'Dự án Cầu Giấy Complex', contractorName = 'Tổng Công Ty XD Số 1') {
  if (!escrowStore.has(siteId)) {
    const newEscrow = createEscrowContract({
      escrowId: `ESC-${siteId}`,
      siteId,
      siteName,
      contractorName,
      totalEscrowAmount: 500000000
    });
    escrowStore.set(siteId, newEscrow);
  }
  return escrowStore.get(siteId);
}

router.post('/api/csr/calculate-dems', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const result = calculateDEMS(body);
  return c.json({ status: 'success', data: result, message: 'Tính toán điểm DEMS thành công' });
});

router.post('/api/csr/assess-gri304', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const result = assessGRI304(body);
  return c.json({ status: 'success', data: result, message: 'Đánh giá GRI 304 thành công' });
});

router.post('/api/csr/assess-gri305', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const result = assessGRI305(body);
  return c.json({ status: 'success', data: result, message: 'Đánh giá GRI 305 thành công' });
});

router.get('/api/csr/escrow/:siteId', (c) => {
  const siteId = c.req.param('siteId');
  const escrow = getOrCreateEscrow(siteId);
  return c.json({ status: 'success', data: escrow });
});

router.post('/api/csr/escrow/create', async (c) => {
  const user = await getAuthenticatedUser(c);
  if (user && user.role === 'citizen') {
    return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Không có quyền tạo hợp đồng ký quỹ.' }, 403);
  }
  const body = await c.req.json().catch(() => ({}));
  const escrow = createEscrowContract(body);
  escrowStore.set(escrow.siteId, escrow);
  return c.json({ status: 'success', data: escrow, message: 'Tạo hợp đồng CSR Escrow thành công' }, 201);
});

router.post('/api/csr/escrow/release-milestone', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (user && user.role === 'citizen') {
      return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ cán bộ thanh tra hoặc lãnh đạo mới có quyền giải ngân ký quỹ.' }, 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const escrow = getOrCreateEscrow(body.siteId || 'BD-0237');
    const verifiedBy = user?.name || user?.fullName || body.verifiedBy || 'Cán bộ Thanh tra Môi trường';
    const updated = releaseMilestone(escrow, body.milestoneId || 'M1', verifiedBy);
    escrowStore.set(body.siteId || 'BD-0237', updated);
    return c.json({ status: 'success', data: updated, message: 'Giải ngân quỹ ký quỹ CSR thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/csr/escrow/forfeit', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (user && user.role === 'citizen') {
      return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ lãnh đạo (Executive/Admin) mới có quyền tịch thu Quỹ Escrow.' }, 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const escrow = getOrCreateEscrow(body.siteId || 'BD-0237');
    const forfeitedBy = user?.name || user?.fullName || body.forfeitedBy || 'Lãnh đạo Chi cục BVMT';
    const updated = forfeitEscrow(escrow, body.reason || 'Vi phạm nghiêm trọng', forfeitedBy);
    escrowStore.set(body.siteId || 'BD-0237', updated);
    return c.json({ status: 'success', data: updated, message: 'Tịch thu Quỹ Escrow thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/csr/escrow/auto-trigger', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const escrow = getOrCreateEscrow(body.siteId || 'BD-0237');
  const result = evaluateAutomatedEscrowTrigger(escrow, body.latestReading || {}, body.riskScore || 50);
  return c.json({ status: 'success', data: result, message: 'Kích hoạt tự động khóa/mở quỹ rủi ro CSR thành công' });
});

router.post('/api/csr/certificate/export', async (c) => {
  const enableExport = (c.env?.ENABLE_EXPORT_GENERATION ?? process.env?.ENABLE_EXPORT_GENERATION ?? 'true').toString().toLowerCase();
  if (enableExport === 'false') {
    return c.json({
      status: 'error',
      code: 'KILL_SWITCH_ACTIVE',
      message: 'Export generation features are temporarily disabled by kill switch.'
    }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  const cert = exportCSRAuditCertificate(body);
  return c.json({ status: 'success', data: cert, message: 'Xuất chứng chỉ CSR & Báo cáo ESG thành công' });
});

router.post('/api/csr/milestone/:siteId', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (user && user.role === 'citizen') {
      return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ cán bộ/lãnh đạo mới có quyền thực hiện nghiệp vụ mốc Escrow.' }, 403);
    }
    const siteId = c.req.param('siteId');
    const body = await c.req.json().catch(() => ({}));
    const { action = 'evaluate', milestoneId = 'M1', evaluationParams = {} } = body;
    const escrow = getOrCreateEscrow(siteId);

    if (action === 'release') {
      const verifiedBy = user?.name || user?.fullName || 'Cán bộ Thanh tra Môi trường';
      const updated = releaseMilestone(escrow, milestoneId, verifiedBy);
      escrowStore.set(siteId, updated);
      return c.json({ status: 'success', data: updated, message: `Giải ngân mốc ${milestoneId} cho công trình ${siteId} thành công` });
    } else {
      const evaluation = evaluateMilestone(escrow, milestoneId, evaluationParams);
      return c.json({ status: 'success', data: { escrowId: escrow.escrowId, siteId, milestoneId, evaluation }, message: `Đánh giá mốc ${milestoneId} thành công` });
    }
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/csr/escrow/evaluate-milestone', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (user && user.role === 'citizen') {
      return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ cán bộ/lãnh đạo mới có quyền đánh giá mốc giải ngân.' }, 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const { siteId = 'BD-0237', milestoneId = 'M1', evaluationParams = {} } = body;
    const escrow = getOrCreateEscrow(siteId);
    const evaluation = evaluateMilestone(escrow, milestoneId, evaluationParams);
    return c.json({ status: 'success', data: { escrowId: escrow.escrowId, milestoneId, evaluation }, message: 'Đánh giá mốc Escrow thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.post('/api/csr/executive-report', async (c) => {
  try {
    const enableExport = (c.env?.ENABLE_EXPORT_GENERATION ?? process.env?.ENABLE_EXPORT_GENERATION ?? 'true').toString().toLowerCase();
    if (enableExport === 'false') {
      return c.json({
        status: 'error',
        code: 'KILL_SWITCH_ACTIVE',
        message: 'Export generation features are temporarily disabled by kill switch.'
      }, 503);
    }
    const user = await getAuthenticatedUser(c);
    if (user && user.role === 'citizen') {
      return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ cán bộ/lãnh đạo mới có quyền tạo báo cáo ESG.' }, 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const { siteId = 'BD-0237', siteInfo = {}, demsParams = {}, gri304Params = {}, gri305Params = {} } = body;
    const escrow = getOrCreateEscrow(siteId);
    const demsResult = calculateDEMS(demsParams);
    const gri304Result = assessGRI304(gri304Params);
    const gri305Result = assessGRI305(gri305Params);

    const report = generateESGImpactReport({
      siteInfo: { id: siteId, name: siteInfo.name || 'Dự án Tòa nhà X', contractor: siteInfo.contractor || 'Tổng Công ty XD Số 1' },
      demsResult,
      gri304Result,
      gri305Result,
      escrowContract: escrow
    });

    return c.json({ status: 'success', data: report, message: 'Tạo báo cáo ESG Executive Impact thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 400);
  }
});

router.get('/api/csr/sponsorships', (c) => {
  const sponsorships = [
    {
      id: 'CSR-SPONSOR-01',
      title: 'Gói Tài Trợ Dập Bụi Môi Trường - Dự án Vành Đai 3',
      siteId: 'site-vd1',
      sponsorName: 'Tập đoàn Xi Măng & Xây dựng Việt Nam',
      fundedAmountVND: 500000000,
      demsTargetScore: 85,
      currentDemsScore: 88,
      status: 'ACTIVE',
      griAlignment: ['GRI-304', 'GRI-305'],
      avoidedHealthCostVND: 120000000,
      suppressedDustMassKg: 450
    },
    {
      id: 'CSR-SPONSOR-02',
      title: 'Gói Tài Trợ Hệ Thống Phun Sương Tự Động - Cầu Giấy Complex',
      siteId: 'BD-0237',
      sponsorName: 'Ngân Hàng Xanh ESG Bank',
      fundedAmountVND: 350000000,
      demsTargetScore: 80,
      currentDemsScore: 82,
      status: 'ACTIVE',
      griAlignment: ['GRI-305'],
      avoidedHealthCostVND: 85000000,
      suppressedDustMassKg: 320
    }
  ];

  return c.json({ status: 'success', data: { items: sponsorships }, message: 'Lấy danh sách gói tài trợ CSR thành công' });
});

router.get('/api/csr/impact-reports/:id', (c) => {
  const id = c.req.param('id');
  const siteId = id.startsWith('site-') || id.startsWith('BD-') ? id : 'BD-0237';
  const escrow = getOrCreateEscrow(siteId);
  
  const demsResult = calculateDEMS({ baselinePm10: 120, currentPm10: 45, mistCannonActive: true, wheelWasherActive: true });
  const gri304Result = assessGRI304();
  const gri305Result = assessGRI305();

  const report = generateESGImpactReport({
    siteInfo: { id: siteId, name: `Công trình ${siteId}`, contractor: 'Tổng Công ty XD Số 1' },
    demsResult,
    gri304Result,
    gri305Result,
    escrowContract: escrow
  });

  return c.json({
    status: 'success',
    data: {
      reportId: id,
      ...report
    },
    message: 'Lấy báo cáo tác động CSR & DEMS thành công'
  });
});

export default router;
