import { Hono } from 'hono';
import { ContractorService } from '../../services/contractor.service.js';
import {
  generateRandomHex,
  getAuthenticatedUser,
  formatRfc7807Error
} from './helpers.js';

const router = new Hono();

const DEFAULT_CONTRACTOR_SECRET = 'dustguard_contractor_zalo_sms_secret_2026';

export async function hmacSha256Hex(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return Array.from(new Uint8Array(sig))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * UTF-8 Safe Base64URL encoder
 */
function utf8ToBase64Url(str) {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(str, 'utf8').toString('base64url');
  }
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * UTF-8 Safe Base64URL decoder
 */
function base64UrlToUtf8(base64Url) {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(base64Url, 'base64url').toString('utf8');
  }
  let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export async function generateContractorToken(payload, expiresInHours = 72, secret = DEFAULT_CONTRACTOR_SECRET) {
  const expiresAt = Date.now() + (expiresInHours || 72) * 3600 * 1000;
  const data = {
    siteId: payload.siteId || 'BD-0237',
    actionId: payload.actionId || null,
    caseId: payload.caseId || null,
    contractorPhone: payload.contractorPhone || '0988123456',
    expiresAt,
    nonce: generateRandomHex(8)
  };
  const jsonStr = JSON.stringify(data);
  const base64Data = utf8ToBase64Url(jsonStr);
  const hmac = await hmacSha256Hex(secret, base64Data);
  return `${base64Data}.${hmac}`;
}

export async function verifyContractorToken(token, secret = DEFAULT_CONTRACTOR_SECRET) {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Token không được để trống' };
  }
  const parts = token.split('.');
  if (parts.length !== 2) {
    return { valid: false, error: 'Cấu trúc token không hợp lệ' };
  }
  const [base64Data, signature] = parts;
  const expectedHmac = await hmacSha256Hex(secret, base64Data);
  if (signature !== expectedHmac) {
    return { valid: false, error: 'Chữ ký token không hợp lệ hoặc đã bị thay đổi' };
  }
  try {
    const raw = base64UrlToUtf8(base64Data);
    const data = JSON.parse(raw);
    if (data.expiresAt && Date.now() > data.expiresAt) {
      return { valid: false, error: 'Mã token đã hết hạn' };
    }
    return { valid: true, data };
  } catch (err) {
    return { valid: false, error: 'Token không đúng định dạng' };
  }
}

router.post('/api/contractor/quick-token', async (c) => {
  const user = await getAuthenticatedUser(c);
  if (user && user.role === 'citizen') {
    return c.json({ status: 'error', code: 'FORBIDDEN', message: 'Chỉ cán bộ/lãnh đạo mới có quyền sinh mã token Zalo/SMS.' }, 403);
  }
  const body = await c.req.json().catch(() => ({}));
  const siteId = body.siteId || 'BD-0237';
  const secretKey = c.env?.CONTRACTOR_TOKEN_SECRET || DEFAULT_CONTRACTOR_SECRET;
  const tokenPayload = {
    siteId,
    actionId: body.actionId || null,
    caseId: body.caseId || null,
    contractorPhone: body.contractorPhone || '0988123456'
  };
  const token = await generateContractorToken(tokenPayload, body.expiresInHours || 72, secretKey);
  return c.json({
    status: 'success',
    data: {
      token,
      quickUrl: `/contractor?token=${encodeURIComponent(token)}`,
      expiresInHours: body.expiresInHours || 72,
      channel: 'Zalo/SMS'
    },
    message: 'Tạo liên kết nộp nhanh Zalo/SMS thành công'
  });
});

router.get('/api/contractor/quick-submit/verify', async (c) => {
  const token = c.req.query('token') || c.req.header('x-contractor-token');
  if (!token) return c.json({ status: 'error', message: 'Mã token không hợp lệ' }, 400);

  const secretKey = c.env?.CONTRACTOR_TOKEN_SECRET || DEFAULT_CONTRACTOR_SECRET;
  const verification = await verifyContractorToken(token, secretKey);
  if (!verification.valid) {
    return c.json({ status: 'error', message: verification.error || 'Mã token không hợp lệ' }, 401);
  }

  const data = verification.data;
  let site = null;

  if (c.env && c.env.DB && data.siteId) {
    try {
      site = await c.env.DB.prepare('SELECT * FROM sites WHERE (id = ? OR code = ?) AND deletedAt IS NULL')
        .bind(data.siteId, data.siteId)
        .first();
    } catch {}
  }

  const siteResponse = site ? {
    id: site.id,
    code: site.code || site.id,
    name: site.name,
    address: site.address,
    contractorName: site.contractorName || 'Đơn vị Thi công',
    dustRiskScore: site.dustRiskScore || 45,
    riskLevel: site.riskLevel || 'MEDIUM'
  } : {
    id: data.siteId,
    code: data.siteId,
    name: data.siteId === 'BD-0237' ? 'Dự án Cầu Giấy Complex' : `Công trình ${data.siteId}`,
    address: '123 Xuân Thủy, Cầu Giấy, Hà Nội',
    contractorName: 'Tổng Công Ty XD Số 1',
    dustRiskScore: 45,
    riskLevel: 'MEDIUM'
  };

  return c.json({
    status: 'success',
    data: {
      valid: true,
      site: siteResponse,
      actionId: data.actionId || 'act_quick_01',
      caseId: data.caseId,
      expiresAt: new Date(data.expiresAt).toISOString()
    }
  });
});

const calculateHaversineDistance = (lat1, lon1, lat2, lon2) => {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return Infinity;
  const nLat1 = Number(lat1);
  const nLon1 = Number(lon1);
  const nLat2 = Number(lat2);
  const nLon2 = Number(lon2);
  if (isNaN(nLat1) || isNaN(nLon1) || isNaN(nLat2) || isNaN(nLon2)) return Infinity;
  if (nLat1 < -90 || nLat1 > 90 || nLat2 < -90 || nLat2 > 90 || nLon1 < -180 || nLon1 > 180 || nLon2 < -180 || nLon2 > 180) return Infinity;
  const R = 6371000;
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(nLat2 - nLat1);
  const dLon = toRad(nLon2 - nLon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(nLat1)) * Math.cos(toRad(nLat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
};

router.post('/api/contractor/quick-submit', async (c) => {
  try {
    const contentType = c.req.header('content-type') || '';
    let body = {};
    if (contentType.includes('multipart/form-data') || contentType.includes('application/x-www-form-urlencoded')) {
      const parsed = await c.req.parseBody().catch(() => ({}));
      body = { ...parsed };
      if (body.file && typeof body.file === 'object') {
        body.filename = body.file.name || 'evidence.jpg';
        body.mimeType = body.file.type || 'image/jpeg';
        body.fileSize = body.file.size || 0;
        body.evidenceUrl = `/uploads/${Date.now()}_${body.filename}`;
      }
    } else {
      body = await c.req.json().catch(() => ({}));
    }

    const token = body.token || c.req.query('token') || c.req.header('x-contractor-token');
    if (token) {
      const secretKey = c.env?.CONTRACTOR_TOKEN_SECRET || DEFAULT_CONTRACTOR_SECRET;
      const verifyRes = await verifyContractorToken(token, secretKey);
      if (!verifyRes.valid) {
        return c.json({ status: 'error', message: verifyRes.error || 'Token không hợp lệ' }, 401);
      }
      if (verifyRes.data?.siteId) {
        body.siteId = body.siteId || verifyRes.data.siteId;
      }
    }

    const siteId = body.siteId || 'BD-0237';
    let siteCoords = { lat: 21.02851, lng: 105.85420 };

    if (c.env && c.env.DB) {
      const site = await c.env.DB.prepare('SELECT coordinates FROM sites WHERE (id = ? OR code = ?) AND deletedAt IS NULL').bind(siteId, siteId).first().catch(() => null);
      if (site && site.coordinates) {
        try {
          const parsed = typeof site.coordinates === 'string' ? JSON.parse(site.coordinates) : site.coordinates;
          if (parsed?.lat && parsed?.lng) siteCoords = parsed;
        } catch {}
      }
    }

    const rawLat = body.latitude !== undefined ? body.latitude : body.lat;
    const rawLng = body.longitude !== undefined ? body.longitude : body.lng;
    const cLat = rawLat !== undefined && rawLat !== null ? parseFloat(rawLat) : null;
    const cLng = rawLng !== undefined && rawLng !== null ? parseFloat(rawLng) : null;

    let valid = false;
    let distanceMeters = Infinity;

    if (cLat !== null && cLng !== null && !isNaN(cLat) && !isNaN(cLng) && siteCoords.lat !== null && siteCoords.lng !== null) {
      distanceMeters = calculateHaversineDistance(cLat, cLng, siteCoords.lat, siteCoords.lng);
      valid = distanceMeters <= 50;
    }

    return c.json({
      status: 'success',
      data: {
        submissionId: `sub_${Date.now()}`,
        siteId,
        explanation: body.explanation || 'Đã phun nước dập bụi hoàn tất.',
        evidenceUrl: body.evidenceUrl || body.url || '/uploads/evidence.jpg',
        geofence: {
          valid,
          within50m: valid,
          distanceMeters,
          allowedBufferMeters: 50,
          matchStatus: valid ? 'VALID_50M_BUFFER' : (cLat === null || cLng === null ? 'NO_GPS' : 'OUT_OF_BOUNDS')
        },
        actionStatus: 'PENDING_VERIFICATION'
      }
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Contractor Workspace & Remediation Endpoints
router.get('/api/contractor/dashboard', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const data = await ContractorService.getDashboardSummary(user, c.env);
    return c.json({ status: 'success', data, message: 'Lấy dữ liệu tổng quan nhà thầu thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/risk-score', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const siteId = c.req.query('siteId');
    const target = siteId || user;
    const data = await ContractorService.getNormalizedRiskScore(target, c.env);
    return c.json({ status: 'success', data, message: 'Lấy điểm rủi ro chuẩn hóa thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/actions/priority', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const limit = parseInt(c.req.query('limit') || '5', 10);
    const data = await ContractorService.getPriorityActions(user, limit, c.env);
    return c.json({ status: 'success', data: { items: data }, message: 'Lấy danh sách việc cần xử lý ngay thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

const handleWorkerGetRemediations = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const query = c.req.query();
    const data = await ContractorService.getRemediations(user, query, c.env);
    return c.json({ status: 'success', data, message: 'Lấy danh sách yêu cầu khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
};

router.get('/api/contractor/actions', handleWorkerGetRemediations);
router.get('/api/contractor/remediations', handleWorkerGetRemediations);

const handleWorkerGetRemediationById = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const data = await ContractorService.getRemediationById(id, user, c.env);
    return c.json({ status: 'success', data, message: 'Lấy chi tiết yêu cầu khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
};

router.get('/api/contractor/actions/:id', handleWorkerGetRemediationById);
router.get('/api/contractor/remediations/:id', handleWorkerGetRemediationById);

const handleWorkerAcknowledge = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const data = await ContractorService.acknowledgeRemediation(id, user, c.env);
    return c.json({ status: 'success', data, message: 'Tiếp nhận yêu cầu khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
};

router.post('/api/contractor/actions/:id/acknowledge', handleWorkerAcknowledge);
router.post('/api/contractor/remediations/:id/acknowledge', handleWorkerAcknowledge);

const handleWorkerStart = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const data = await ContractorService.startRemediation(id, user, c.env);
    return c.json({ status: 'success', data, message: 'Bắt đầu triển khai khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
};

router.post('/api/contractor/actions/:id/start', handleWorkerStart);
router.post('/api/contractor/remediations/:id/start', handleWorkerStart);

const handleWorkerAddEvidence = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const contentType = c.req.header('content-type') || '';
    let body = {};

    if (contentType.includes('multipart/form-data') || contentType.includes('application/x-www-form-urlencoded')) {
      const parsed = await c.req.parseBody().catch(() => ({}));
      body = { ...parsed };
      if (body.file && typeof body.file === 'object') {
        body.filename = body.file.name || 'evidence.jpg';
        body.mimeType = body.file.type || 'image/jpeg';
        body.fileSize = body.file.size || 0;
        body.url = body.url || `/uploads/${Date.now()}_${body.filename}`;
      }
    } else {
      body = await c.req.json().catch(() => ({}));
    }

    const rawContractorToken = body.token || body.contractorToken || c.req.query('token') || c.req.header('x-contractor-token');

    let quickTokenData = null;
    const secretKey = c.env?.CONTRACTOR_TOKEN_SECRET || DEFAULT_CONTRACTOR_SECRET;
    if (rawContractorToken && typeof rawContractorToken === 'string' && rawContractorToken.includes('.')) {
      const verification = await verifyContractorToken(rawContractorToken, secretKey);
      if (!verification.valid) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', verification.error || 'Mã token truy cập không hợp lệ.', c.req.path), 401);
      }
      quickTokenData = verification.data;
    }

    if (!quickTokenData) {
      if (user && user.disabled) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Tài khoản đã bị vô hiệu hóa.', c.req.path), 401);
      }
      if (user && user.role === 'citizen') {
        return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Tài khoản công dân không có quyền thực hiện thao tác này.', c.req.path), 403);
      }
    }

    body.token = rawContractorToken;
    const data = await ContractorService.addEvidence(id, body, user, c.env);
    return c.json({ status: 'success', data, message: 'Tải lên minh chứng khắc phục thành công' });
  } catch (err) {
    const status = err.statusCode || err.status || 500;
    const code = err.code || (status === 403 ? 'FORBIDDEN' : status === 401 ? 'UNAUTHORIZED' : 'BAD_REQUEST');
    const title = status === 403 ? 'Forbidden' : status === 401 ? 'Unauthorized' : 'Error';
    return c.json(formatRfc7807Error(status, code, title, err.message, c.req.path), status);
  }
};

router.post('/api/contractor/actions/:id/evidence', handleWorkerAddEvidence);
router.post('/api/contractor/remediations/:id/evidence', handleWorkerAddEvidence);

const handleWorkerSubmitRemediation = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const contentType = c.req.header('content-type') || '';
    let body = {};

    if (contentType.includes('multipart/form-data') || contentType.includes('application/x-www-form-urlencoded')) {
      const parsed = await c.req.parseBody().catch(() => ({}));
      body = { ...parsed };
    } else {
      body = await c.req.json().catch(() => ({}));
    }

    const data = await ContractorService.submitRemediation(id, body, user, c.env);
    return c.json({ status: 'success', data, message: 'Gửi hồ sơ thẩm định khắc phục thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
};

router.post('/api/contractor/actions/:id/submit', handleWorkerSubmitRemediation);
router.post('/api/contractor/remediations/:id/submit', handleWorkerSubmitRemediation);

router.get('/api/contractor/projects', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const data = await ContractorService.getContractorProjects(user, c.env);
    return c.json({ status: 'success', data: { items: data }, items: data, message: 'Lấy danh sách công trình thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/projects/:id', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    return c.json({ status: 'success', data: { id }, message: 'Lấy thông tin chi tiết công trình thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/projects/:id/telemetry', async (c) => {
  try {
    const id = c.req.param('id');
    const range = c.req.query('range') || '24h';
    const data = await ContractorService.getProjectTelemetry(id, range, c.env);
    return c.json({ status: 'success', data, message: 'Lấy dữ liệu cảm biến đo bụi thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/projects/:id/compliance', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const data = await ContractorService.getProjectDetail(id, user, c.env);
    return c.json({
      status: 'success',
      data: {
        projectId: id,
        complianceRate: data.health?.complianceRate || 90,
        checklist: data.complianceChecklist || []
      },
      message: 'Lấy danh mục kiểm tra tuân thủ môi trường thành công'
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/evidence', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const query = c.req.query();
    const data = await ContractorService.getContractorEvidence(user, query, c.env);
    return c.json({ status: 'success', data, message: 'Lấy danh sách bằng chứng thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.get('/api/contractor/notifications', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const data = await ContractorService.getContractorNotifications(user, c.env);
    return c.json({ status: 'success', data, message: 'Lấy danh sách thông báo thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

router.post('/api/contractor/notifications/:id/read', async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const id = c.req.param('id');
    const data = await ContractorService.markNotificationRead(id, user, c.env);
    return c.json({ status: 'success', data, message: 'Đã đánh dấu thông báo đã đọc' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, err.statusCode || 500);
  }
});

export default router;
