import { Hono } from 'hono';
import { ExecutiveService } from '../../services/executive.service.js';
import {
  generateId,
  sha256Hex,
  getAuthenticatedUser,
  formatRfc7807Error,
  getD1OrSqlite,
  parseSpatialCoordinates
} from './helpers.js';

const router = new Hono();

const handleExecutiveOverview = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getOverview(c.env);
    return c.json({ status: 'success', data, message: 'Tải dữ liệu tổng quan điều hành thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/overview', handleExecutiveOverview);
router.get('/api/dashboard/executive', handleExecutiveOverview);

const handleExecutivePriorities = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getPriorities(c.env);
    return c.json({ status: 'success', data, message: 'Tải hàng đợi vấn đề ưu tiên thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/priorities', handleExecutivePriorities);

const handleExecutiveOperations = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getOperations(c.env);
    return c.json({ status: 'success', data, message: 'Tải số liệu điều hành tác nghiệp thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/operations', handleExecutiveOperations);
router.get('/api/dashboard/operations', handleExecutiveOperations);

const handleExecutiveSla = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getSlaOperations(c.env);
    return c.json({ status: 'success', data, message: 'Tải số liệu SLA & điều hành thanh tra thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/sla', handleExecutiveSla);

const handleExecutiveSensors = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getSensorHealth(c.env);
    return c.json({ status: 'success', data, message: 'Tải tình trạng mạng lưới cảm biến thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/sensors', handleExecutiveSensors);

const handleExecutiveImpact = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getInterventionImpact(c.env);
    return c.json({ status: 'success', data, message: 'Tải báo cáo hiệu quả can thiệp thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/impact', handleExecutiveImpact);

const handleExecutiveReports = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const data = await ExecutiveService.getReports(c.env);
    return c.json({ status: 'success', data, message: 'Tải danh mục báo cáo điều hành thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/reports', handleExecutiveReports);

const handleExecutiveReportById = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    const allowedRoles = ['executive', 'admin', 'demo_admin', 'super_admin', 'staff', 'inspector'];
    const userRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
    const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [userRole];
    const isAllowed = allowedRoles.some(r => userRoles.includes(r) || userRole === r);
    if (!isAllowed) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Bạn không có quyền truy cập trung tâm chỉ đạo điều hành.', c.req.path), 403);
    }
    const id = c.req.param('id');
    const data = await ExecutiveService.getReportById(id, c.env);
    if (!data) {
      return c.json(formatRfc7807Error(404, 'NOT_FOUND', 'Not Found', 'Không tìm thấy báo cáo này', c.req.path), 404);
    }
    return c.json({ status: 'success', data, message: 'Tải chi tiết báo cáo thành công' });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
};
router.get('/api/executive/reports/:id', handleExecutiveReportById);

router.post('/api/executive/cases/:id/escalate', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền chỉ đạo khẩn cấp.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const reason = body.reason || 'Lãnh đạo cơ quan kích hoạt chỉ đạo xử lý khẩn cấp vượt cấp.';
    const now = new Date().toISOString();

    if (c.env?.DB) {
      await c.env.DB.prepare(
        'UPDATE cases SET priority = "CRITICAL", updatedAt = ? WHERE id = ?'
      ).bind(now, id).run();

      const auditId = generateId('aud');
      await c.env.DB.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(auditId, user?.name || user?.fullName || 'Lãnh đạo cơ quan', 'executive', 'EXECUTIVE_CASE_ESCALATE', id, JSON.stringify({ reason }), now).run();
    }

    return c.json({
      status: 'success',
      data: { caseId: id, priority: 'CRITICAL', escalatedAt: now, escalatedBy: user?.name || user?.fullName || 'Lãnh đạo cơ quan' },
      message: 'Kích hoạt chỉ đạo khẩn cấp vụ việc thành công!'
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

router.post('/api/executive/cases/:id/assign', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền phân công thanh tra.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const inspectorName = body.inspectorName || 'Nguyễn Văn An';
    const now = new Date().toISOString();

    if (c.env?.DB) {
      await c.env.DB.prepare(
        'UPDATE cases SET assignedTo = ?, status = "PREPARING", updatedAt = ? WHERE id = ?'
      ).bind(inspectorName, now, id).run();
    }

    return c.json({
      status: 'success',
      data: { caseId: id, assignedTo: inspectorName, status: 'PREPARING', updatedAt: now },
      message: `Đã phân công hồ sơ cho thanh tra viên ${inspectorName} thành công!`
    });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

router.post('/api/executive/cases/:id/directive', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền ban hành chỉ đạo.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const result = await ExecutiveService.issueDirective(id, body, user, c.env);
    return c.json({ status: 'success', data: result, message: result.message });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

router.post('/api/executive/cases/:id/approve', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền phê duyệt hồ sơ.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const result = await ExecutiveService.approveCase(id, body, user, c.env);
    return c.json({ status: 'success', data: result, message: result.message });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

router.post('/api/executive/cases/:id/reject', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền từ chối/yêu cầu thanh tra lại.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const result = await ExecutiveService.rejectCase(id, body, user, c.env);
    return c.json({ status: 'success', data: result, message: result.message });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

router.post('/api/executive/cases/:id/close', async (c) => {
  try {
    const id = c.req.param('id');
    const user = await getAuthenticatedUser(c);
    if (!user || user.disabled) {
      return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
    }
    if (!['executive', 'admin', 'demo_admin', 'super_admin'].includes((user.role || '').toLowerCase())) {
      return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', 'Chỉ Lãnh đạo (Executive/Admin) mới có quyền đóng hồ sơ.', c.req.path), 403);
    }
    const body = await c.req.json().catch(() => ({}));
    const result = await ExecutiveService.closeCase(id, body, user, c.env);
    return c.json({ status: 'success', data: result, message: result.message });
  } catch (err) {
    return c.json(formatRfc7807Error(500, 'SERVER_ERROR', 'Internal Server Error', err.message, c.req.path), 500);
  }
});

// Staff Dashboard & Quick Sign
const handleStaffDashboard = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { getStaffDashboardData } = await import('../../services/staff-dashboard.service.js');
    const dashboardData = await getStaffDashboardData(db);

    return c.json({
      status: 'success',
      data: dashboardData,
      message: 'Tải dữ liệu Staff Dashboard thành công từ D1 SSOT'
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/staff/dashboard', handleStaffDashboard);
router.get('/api/v1/staff/dashboard', handleStaffDashboard);

router.get('/api/dashboard/stats', async (c) => {
  let total = 3, active = 3, high = 1, open = 4, resolved = 8;
  if (c.env && c.env.DB) {
    try {
      const s = await c.env.DB.prepare('SELECT COUNT(*) as c FROM sites WHERE deletedAt IS NULL').first();
      const cp = await c.env.DB.prepare("SELECT COUNT(*) as c FROM complaints WHERE status = 'PENDING' AND deletedAt IS NULL").first();
      const res = await c.env.DB.prepare("SELECT COUNT(*) as c FROM actions WHERE status = 'VERIFIED' AND deletedAt IS NULL").first();
      if (s) total = s.c;
      if (cp) open = cp.c;
      if (res) resolved = res.c;
    } catch (e) {}
  }
  return c.json({
    status: 'success',
    data: {
      totalSites: total,
      activeSites: active,
      highPriorityCases: high,
      openReports: open,
      activeCases: 2,
      resolvedIssues: resolved
    }
  });
});

router.post('/api/dashboard/documents/:id/quick-sign', async (c) => {
  const id = c.req.param('id');
  const user = await getAuthenticatedUser(c);
  const now = new Date().toISOString();
  const hash = await sha256Hex(`QUICKSIGN-${id}-${now}`);
  return c.json({
    status: 'success',
    data: { id, status: 'SIGNED', hash, signedAt: now, approvedBy: user?.name || 'Giám Đốc Sở' },
    message: 'Phê duyệt ký số biên bản thành công!'
  });
});

router.post('/api/feedback', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const id = `fb_${Date.now()}`;
  return c.json({ status: 'success', data: { id, ...body, createdAt: new Date().toISOString() }, message: 'Gửi góp ý thành công' });
});

export default router;
