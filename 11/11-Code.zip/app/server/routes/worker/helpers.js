/**
 * DustGuard VN - Worker Shared Route Helpers & Utilities SSOT
 */
import {
  IdentityContext,
  createIdentityContext,
  ClerkAuthAdapter,
  clerkAuthMiddleware,
  resolveIdentityFromToken,
  extractTokenFromHono,
  requireAuth as requireHonoAuth,
  requireRole as requireHonoRole,
  requireAnyRole as requireHonoAnyRole,
  requirePermission as requireHonoPermission,
  verifyDeviceAuth,
  formatRfc7807Error,
  IN_MEMORY_SESSIONS,
  DEMO_ACCOUNTS
} from '../../auth/index.js';
import { getD1OrSqlite } from '../../shared/db.js';

export function generateId(prefix = 'id') {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID().replace(/-/g, '').substring(0, 12)}`;
  }
  return `${prefix}_${Date.now()}`;
}

export function generateRandomHex(len = 4) {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const bytes = new Uint8Array(Math.ceil(len / 2));
    crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('').substring(0, len).toUpperCase();
  }
  return Date.now().toString(16).slice(-len).toUpperCase();
}

export function generateRandomCode(prefix = 'DG', min = 1000, max = 9999) {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    const num = min + (arr[0] % (max - min + 1));
    return `${prefix}-${num}`;
  }
  return `${prefix}-${Math.floor(min + (Date.now() % (max - min + 1)))}`;
}

export async function sha256Hex(message) {
  let msgUint8;
  if (message instanceof Uint8Array) {
    msgUint8 = message;
  } else if (message instanceof ArrayBuffer) {
    msgUint8 = new Uint8Array(message);
  } else if (ArrayBuffer.isView(message)) {
    msgUint8 = new Uint8Array(message.buffer, message.byteOffset, message.byteLength);
  } else {
    msgUint8 = new TextEncoder().encode(String(message));
  }
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function parsePaginationParams(c, defaultLimit = 50, maxLimit = 100) {
  const query = typeof c.req.query === 'function' ? c.req.query() : (c.req.query || {});
  const rawPage = parseInt(query.page || '1', 10);
  const page = isNaN(rawPage) ? 1 : Math.max(rawPage, 1);

  const rawLimit = parseInt(query.limit || query.pageSize || String(defaultLimit), 10);
  const limit = isNaN(rawLimit) ? defaultLimit : Math.min(Math.max(rawLimit, 1), maxLimit);

  let offset = 0;
  if (query.offset !== undefined) {
    const rawOffset = parseInt(query.offset || '0', 10);
    offset = isNaN(rawOffset) ? 0 : Math.max(rawOffset, 0);
  } else if (query.page) {
    offset = (page - 1) * limit;
  }

  return { limit, offset, page, pageSize: limit };
}

export const MIME_MAP = {
  'jpg': 'image/jpeg',
  'jpeg': 'image/jpeg',
  'png': 'image/png',
  'webp': 'image/webp',
  'svg': 'image/svg+xml',
  'pdf': 'application/pdf',
  'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'doc': 'application/msword'
};

export const hashPassword = async (password, salt = 'dustguard_salt_2026') => {
  const enc = new TextEncoder();
  const data = enc.encode(`${salt}:${password}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

export const getTokenFromContext = (c) => {
  return extractTokenFromHono(c);
};

export const setAuthCookies = (c, token, maxAge = 2592000) => {
  const isSecure = c.req.url.startsWith('https://') || c.env?.NODE_ENV === 'production';
  const secureFlag = isSecure ? '; Secure' : '';
  c.header('Set-Cookie', `better-auth.session_token=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secureFlag}`, { append: true });
  c.header('Set-Cookie', `auth_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secureFlag}`, { append: true });
};

export const getAuthenticatedUser = async (c) => {
  // 1. Check IdentityContext already resolved in context
  const identity = c.get('identity');
  if (identity && !identity.disabled) {
    return identity.toNormalizedUser();
  }
  const existingUser = c.get('user');
  if (existingUser && !existingUser.disabled) {
    return existingUser;
  }

  const token = getTokenFromContext(c);
  if (!token) return null;

  // 2. Resolve via Hybrid Auth (Clerk JWT -> D1 -> Memory -> Demo)
  const resolvedIdentity = await resolveIdentityFromToken(token, c.env);
  if (resolvedIdentity && !resolvedIdentity.disabled) {
    c.set('identity', resolvedIdentity);
    c.set('user', resolvedIdentity.toNormalizedUser());
    return resolvedIdentity.toNormalizedUser();
  }

  return null;
};

export function createRoleEnforcementMiddleware(allowedRoles, entityName = 'Tài nguyên') {
  const normalizedAllowed = allowedRoles.map(r => r.toLowerCase());
  return async (c, next) => {
    const method = c.req.method.toUpperCase();
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      const path = c.req.path.toLowerCase();

      // Allow contractor on explanation and rectify endpoints
      const isContractorAllowedCaseEndpoint = path.includes('/explanations') || path.includes('/rectify');
      let effectiveAllowed = normalizedAllowed;
      if (isContractorAllowedCaseEndpoint && (path.includes('/cases/') || path.includes('/cases'))) {
        effectiveAllowed = [...normalizedAllowed, 'contractor', 'demo_contractor'];
      }
      // Allow contractor, citizen, volunteer to submit remediation/verification on actions
      if ((method === 'PUT' || method === 'PATCH') && (path.startsWith('/api/actions/') || path.startsWith('/api/v1/actions/'))) {
        effectiveAllowed = [...normalizedAllowed, 'contractor', 'demo_contractor', 'citizen', 'volunteer', 'community'];
      }

      const user = await getAuthenticatedUser(c);
      if (!user || user.disabled) {
        return c.json(formatRfc7807Error(401, 'UNAUTHORIZED', 'Unauthorized', 'Vui lòng đăng nhập để tiếp tục.', c.req.path), 401);
      }

      const role = (user.role || user.primaryRole || 'citizen').toLowerCase();
      const roles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [role];
      const isBypass = role === 'admin' || role === 'super_admin' || role === 'demo_admin' ||
        roles.includes('admin') || roles.includes('super_admin') || roles.includes('demo_admin');

      const isAllowed = isBypass || effectiveAllowed.some(r => roles.includes(r) || role === r);

      if (!isAllowed) {
        return c.json(formatRfc7807Error(403, 'FORBIDDEN', 'Forbidden', `Bạn không có quyền thực hiện thao tác trên ${entityName}.`, c.req.path), 403);
      }
    }
    await next();
  };
}

export const CASE_WRITE_ROLES = ['staff', 'inspector', 'admin', 'executive', 'demo_admin'];
export const INSPECTION_WRITE_ROLES = ['staff', 'inspector', 'admin', 'executive', 'demo_admin'];
export const ACTION_WRITE_ROLES = ['staff', 'inspector', 'admin', 'executive', 'demo_admin'];
export const SITE_WRITE_ROLES = ['admin', 'staff', 'demo_admin'];

export function parseSpatialCoordinates(coords) {
  if (!coords) return { lat: 21.02851, lng: 105.85420 };
  if (typeof coords === 'object' && coords !== null) {
    const lat = Number(coords.lat ?? coords.latitude ?? 21.02851);
    const lng = Number(coords.lng ?? coords.longitude ?? 105.85420);
    return {
      lat: isNaN(lat) ? 21.02851 : lat,
      lng: isNaN(lng) ? 105.85420 : lng
    };
  }
  if (typeof coords === 'string') {
    const trimmed = coords.trim();
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      try {
        const parsed = JSON.parse(trimmed);
        return parseSpatialCoordinates(parsed);
      } catch {}
    }
    const parts = trimmed.split(',').map(p => parseFloat(p.trim()));
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      return { lat: parts[0], lng: parts[1] };
    }
  }
  return { lat: 21.02851, lng: 105.85420 };
}

export {
  getD1OrSqlite,
  formatRfc7807Error,
  IN_MEMORY_SESSIONS,
  DEMO_ACCOUNTS,
  IdentityContext,
  createIdentityContext,
  ClerkAuthAdapter,
  clerkAuthMiddleware,
  resolveIdentityFromToken,
  extractTokenFromHono,
  requireHonoAuth,
  requireHonoRole,
  requireHonoAnyRole,
  requireHonoPermission,
  verifyDeviceAuth
};
