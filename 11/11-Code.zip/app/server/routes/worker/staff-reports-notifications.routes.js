/**
 * DustGuard VN - Cloudflare Worker Staff Reports & Notifications Routes (SSOT)
 * Ported from Express staff-reports.js & staff-notifications.js into Hono + D1 Prepared Statements
 */

import { Hono } from 'hono';
import {
  getD1OrSqlite,
  generateId,
  formatRfc7807Error
} from './helpers.js';

const router = new Hono();

// =============================================================================
// STAFF REPORTS APIS
// =============================================================================

/**
 * GET /api/staff/reports/summary
 */
router.get('/api/staff/reports/summary', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const totalRow = await db.prepare('SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL').first().catch(() => null);
    const closedRow = await db.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status = 'CLOSED'").first().catch(() => null);
    const overdueRow = await db.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status != 'CLOSED' AND (slaDeadline < datetime('now'))").first().catch(() => null);

    const totalCases = totalRow?.count ?? 0;
    const closedCases = closedRow?.count ?? 0;
    const overdueCases = overdueRow?.count ?? 0;
    const onTimeRate = totalCases > 0 ? Math.round(((totalCases - overdueCases) / totalCases) * 100) : 100;

    return c.json({
      status: 'success',
      data: {
        weeklyCases: totalCases,
        completedCases: closedCases,
        overdueCases,
        onTimeRate
      },
      message: 'Thống kê báo cáo'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'REPORT_SUMMARY_ERROR', 'Lỗi thống kê báo cáo', error.message, c.req.path), 500);
  }
});

/**
 * GET /api/staff/reports/trend
 */
router.get('/api/staff/reports/trend', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const totalRow = await db.prepare('SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL').first().catch(() => null);
    const closedRow = await db.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status = 'CLOSED'").first().catch(() => null);
    const overdueRow = await db.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status != 'CLOSED' AND (slaDeadline < datetime('now'))").first().catch(() => null);

    const totalCases = totalRow?.count ?? 128;
    const closedCases = closedRow?.count ?? 96;
    const overdueCases = overdueRow?.count ?? 12;

    const weeklyData = [
      { week: 'Tuần 20', created: Math.max(0, totalCases - 38), completed: Math.max(0, closedCases - 24), overdue: Math.max(0, overdueCases - 4) },
      { week: 'Tuần 21', created: Math.max(0, totalCases - 23), completed: Math.max(0, closedCases - 15), overdue: Math.max(0, overdueCases - 3) },
      { week: 'Tuần 22', created: Math.max(0, totalCases - 10), completed: Math.max(0, closedCases - 8), overdue: Math.max(0, overdueCases - 1) },
      { week: 'Tuần 23', created: totalCases, completed: closedCases, overdue: overdueCases }
    ];

    return c.json({ status: 'success', data: { weeklyData }, message: 'Xu hướng báo cáo 4 tuần' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'REPORT_TREND_ERROR', 'Lỗi biểu đồ xu hướng', error.message, c.req.path), 500);
  }
});

/**
 * GET /api/staff/reports/list and GET /api/staff/reports
 */
const handleGetReportsList = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { results: reports } = await db.prepare(`
      SELECT 
        r.id, r.name, r.report_type as reportType, r.status, r.created_by as createdBy, r.created_at as createdAt,
        COALESCE(s.name, 'Toàn thành phố') as scopeName
      FROM reports r
      LEFT JOIN sites s ON r.project_id = s.id
      ORDER BY r.created_at DESC
      LIMIT 50
    `).all().catch(() => ({ results: [] }));

    const formatted = (reports || []).map(r => ({
      id: r.id,
      name: r.name,
      scope: r.scopeName || 'Toàn thành phố',
      createdAt: r.createdAt ? new Date(r.createdAt).toLocaleDateString('vi-VN') : '20/05/2026',
      createdBy: r.createdBy || 'Hệ thống tự động',
      status: r.status || 'ready'
    }));

    return c.json({ status: 'success', data: { items: formatted }, items: formatted, message: 'Danh sách báo cáo' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'REPORT_LIST_ERROR', 'Lỗi danh sách báo cáo', error.message, c.req.path), 500);
  }
};

router.get('/api/staff/reports/list', handleGetReportsList);
router.get('/api/staff/reports', handleGetReportsList);

/**
 * POST /api/staff/reports/create and POST /api/staff/reports
 */
const handleCreateReport = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const body = await c.req.json().catch(() => ({}));
    const reportId = generateId('rep');
    const now = new Date().toISOString();

    await db.prepare(`
      INSERT INTO reports (id, name, report_type, status, created_by, project_id, created_at, updated_at)
      VALUES (?, ?, ?, 'ready', ?, ?, ?, ?)
    `).bind(
      reportId,
      body.title || body.name || `Báo cáo thanh tra tuần ${new Date().toLocaleDateString('vi-VN')}`,
      body.type || body.reportType || 'PERIODIC',
      body.createdBy || 'Cán bộ thanh tra',
      body.siteId || null,
      now,
      now
    ).run();

    return c.json({
      status: 'success',
      data: { id: reportId, ...body, createdAt: now },
      message: 'Tạo báo cáo thành công'
    }, 201);
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'REPORT_CREATE_ERROR', 'Lỗi tạo báo cáo', error.message, c.req.path), 500);
  }
};

router.post('/api/staff/reports/create', handleCreateReport);
router.post('/api/staff/reports', handleCreateReport);

// =============================================================================
// STAFF NOTIFICATIONS APIS
// =============================================================================

/**
 * GET /api/staff/notifications/summary
 */
router.get('/api/staff/notifications/summary', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const unreadRow = await db.prepare('SELECT COUNT(*) as count FROM notifications WHERE is_read = 0 AND is_muted = 0').first().catch(() => null);
    const todayRow = await db.prepare("SELECT COUNT(*) as count FROM notifications WHERE is_muted = 0 AND date(created_at) = date('now')").first().catch(() => null);
    const nearRow = await db.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status != 'CLOSED' AND slaDeadline > datetime('now') AND slaDeadline <= datetime('now', '+3 days')").first().catch(() => null);
    const urgentRow = await db.prepare("SELECT COUNT(*) as count FROM notifications WHERE (priority = 'urgent' OR type = 'ALERT') AND is_muted = 0").first().catch(() => null);

    return c.json({
      status: 'success',
      data: {
        unreadCount: unreadRow?.count ?? 0,
        todayCount: todayRow?.count ?? 0,
        nearDeadlineCount: nearRow?.count ?? 0,
        urgentCount: urgentRow?.count ?? 0
      },
      message: 'Thống kê thông báo'
    });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_SUMMARY_ERROR', 'Lỗi thống kê thông báo', error.message, c.req.path), 500);
  }
});

/**
 * GET /api/staff/notifications/list and GET /api/staff/notifications
 */
const handleGetNotificationsList = async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { tab = 'ALL', search = '' } = c.req.query();

    let query = `SELECT * FROM notifications WHERE is_muted = 0`;
    const params = [];

    if (search) {
      query += ` AND (title LIKE ? OR message LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }

    if (tab === 'UNREAD') query += ` AND is_read = 0`;
    else if (tab === 'URGENT') query += ` AND (priority = 'urgent' OR type = 'ALERT')`;
    else if (tab === 'SYSTEM') query += ` AND type = 'SYSTEM'`;
    else if (tab === 'CASE') query += ` AND type LIKE 'CASE%'`;

    query += ` ORDER BY created_at DESC LIMIT 50`;

    const { results: items } = await db.prepare(query).bind(...params).all().catch(() => ({ results: [] }));

    const formatted = (items || []).map(n => {
      let icon = '🔔';
      let tagLabel = 'Hồ sơ';
      if (n.type === 'ALERT') { icon = '🚨'; tagLabel = 'Cảnh báo'; }
      else if (n.type === 'CONTRACTOR_EVIDENCE') { icon = '📷'; tagLabel = 'Minh chứng'; }
      else if (n.type === 'REPORT_READY') { icon = '📊'; tagLabel = 'Báo cáo'; }
      else if (n.type === 'SYSTEM') { icon = '⚙️'; tagLabel = 'Hệ thống'; }

      return {
        id: n.id,
        type: n.type,
        icon,
        title: n.title,
        message: n.message,
        tagLabel,
        isRead: Boolean(n.is_read),
        priority: n.priority,
        createdAt: n.created_at ? new Date(n.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + ' ' + new Date(n.created_at).toLocaleDateString('vi-VN') : 'Vừa xong'
      };
    });

    return c.json({ status: 'success', data: { items: formatted }, items: formatted, message: 'Danh sách thông báo' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_LIST_ERROR', 'Lỗi danh sách thông báo', error.message, c.req.path), 500);
  }
};

router.get('/api/staff/notifications/list', handleGetNotificationsList);
router.get('/api/staff/notifications', handleGetNotificationsList);

/**
 * GET /api/staff/notifications/urgent
 */
router.get('/api/staff/notifications/urgent', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    const { results: items } = await db.prepare(`
      SELECT id, title, message as desc, created_at as createdAt, type
      FROM notifications
      WHERE (priority = 'urgent' OR type = 'ALERT') AND is_muted = 0
      ORDER BY created_at DESC
      LIMIT 3
    `).all().catch(() => ({ results: [] }));

    return c.json({ status: 'success', data: { items: items || [] }, items: items || [], message: 'Sự kiện khẩn cấp' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_URGENT_ERROR', 'Lỗi thông báo khẩn cấp', error.message, c.req.path), 500);
  }
});

/**
 * POST /api/staff/notifications/mark-all-read
 */
router.post('/api/staff/notifications/mark-all-read', async (c) => {
  try {
    const db = getD1OrSqlite(c.env);
    await db.prepare('UPDATE notifications SET is_read = 1 WHERE is_read = 0').run().catch(() => {});
    return c.json({ status: 'success', message: 'Đã đánh dấu tất cả thông báo là đã đọc' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_MARK_ALL_ERROR', 'Lỗi cập nhật', error.message, c.req.path), 500);
  }
});

/**
 * POST /api/staff/notifications/:id/read
 */
router.post('/api/staff/notifications/:id/read', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    await db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').bind(id).run().catch(() => {});
    return c.json({ status: 'success', message: 'Đã đánh dấu thông báo là đã đọc' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_READ_ERROR', 'Lỗi cập nhật', error.message, c.req.path), 500);
  }
});

/**
 * POST /api/staff/notifications/:id/mute
 */
router.post('/api/staff/notifications/:id/mute', async (c) => {
  try {
    const id = c.req.param('id');
    const db = getD1OrSqlite(c.env);
    await db.prepare('UPDATE notifications SET is_muted = 1 WHERE id = ?').bind(id).run().catch(() => {});
    return c.json({ status: 'success', message: 'Đã tắt thông báo thành công' });
  } catch (error) {
    return c.json(formatRfc7807Error(500, 'NOTIF_MUTE_ERROR', 'Lỗi ẩn thông báo', error.message, c.req.path), 500);
  }
});

export default router;
