import { Hono } from 'hono';
import { formatRfc7807Error } from './helpers.js';

const router = new Hono();

router.get('/api/ai/capabilities', (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({
      status: 'error',
      code: 'KILL_SWITCH_ACTIVE',
      message: 'AI Assistant features are temporarily disabled by kill switch.'
    }, 503);
  }
  return c.json({
    status: 'success',
    data: {
      provider: 'hybrid_edge_ai',
      hasApiKey: Boolean(c.env?.GEMINI_API_KEY || c.env?.OPENROUTER_API_KEY || process.env?.OPENROUTER_API_KEY),
      directPdf: true,
      vision: true,
      ragEnabled: true
    }
  });
});

router.post('/api/ai/parse-document', async (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({ status: 'error', code: 'KILL_SWITCH_ACTIVE', message: 'AI Assistant features are temporarily disabled by kill switch.' }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  const text = body.text || body.content || '';
  const obligations = [
    { id: 'obl_01', obligation: 'Che chắn bạt kín toàn bộ bãi chứa vật liệu và xe vận tải', checklist_item: 'cover', legal_basis: { document_name: 'Nghị định 45/2022/NĐ-CP', article: 'Điều 43.1' }, risk_level: 'high' },
    { id: 'obl_02', obligation: 'Lắp đặt rào chắn kiên cố tối thiểu 2.0m quanh công trường', checklist_item: 'barrier', legal_basis: { document_name: 'QCVN 18:2021/BXD', article: 'Mục 2.1' }, risk_level: 'medium' },
    { id: 'obl_03', obligation: 'Phun nước dập bụi liên tục trong giờ thi công cao điểm', checklist_item: 'spray', legal_basis: { document_name: 'QĐ 48/2024/QĐ-UBND', article: 'Điều 5.2' }, risk_level: 'high' }
  ];
  return c.json({
    status: 'success',
    data: {
      summary: `Phân tích ${text.length} ký tự văn bản pháp lý. Trích xuất thành công ${obligations.length} nghĩa vụ tuân thủ.`,
      obligations,
      provider: 'hybrid_edge_parser',
      timestamp: new Date().toISOString()
    },
    message: 'Trích xuất nghĩa vụ pháp lý từ văn bản thành công'
  });
});

router.post('/api/ai/analyze-image', async (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({ status: 'error', code: 'KILL_SWITCH_ACTIVE', message: 'AI Assistant features are temporarily disabled by kill switch.' }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  return c.json({
    status: 'success',
    data: {
      analyzedAt: new Date().toISOString(),
      siteId: body.siteId || 'BD-0237',
      imageUrl: body.imageUrl || '/uploads/evidence.jpg',
      overallCompliance: 'COMPLIANT',
      riskScore: 25,
      findings: [
        { criterion: 'barrier', label: 'Hàng rào bao che', status: 'compliant', confidence: 0.90, note: 'Hàng rào kiên cố, lưới che chắn đầy đủ.' },
        { criterion: 'spray', label: 'Phun sương dập bụi', status: 'compliant', confidence: 0.85, note: 'Hệ thống phun nước vận hành đều đặn.' },
        { criterion: 'wheel', label: 'Rửa bánh xe', status: 'warning', confidence: 0.78, note: 'Cần vệ sinh bùn đọng ở rãnh thoát cầu rửa xe.' }
      ],
      violationsDetected: [],
      tamperProof: true,
      provider: 'edge_vision_heuristic'
    },
    message: 'Phân tích hình ảnh hiện trường thành công'
  });
});

router.post('/api/ai/auto-report', async (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({ status: 'error', code: 'KILL_SWITCH_ACTIVE', message: 'AI Assistant features are temporarily disabled by kill switch.' }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  const siteId = body.siteId || 'BD-0237';
  const now = new Date().toISOString();

  const report = {
    documentType: 'BIEN_BAN_KIEM_TRA_HIEN_TRUONG',
    title: 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH XÂY DỰNG',
    standard: 'Nghị định 30/2020/NĐ-CP',
    siteId,
    generatedAt: now,
    metadata: {
      location: 'Hà Nội',
      department: 'Đội Thanh tra Xây dựng & Môi trường',
      inspector: body.items?.inspector || 'Nguyễn Văn An'
    },
    sections: [
      { heading: 'I. CĂN CỨ KIỂM TRA', content: '1. Nghị định số 45/2022/NĐ-CP về xử phạt vi phạm hành chính lĩnh vực bảo vệ môi trường.\n2. QCVN 18:2021/BXD về an toàn trong thi công xây dựng.' },
      { heading: 'II. KẾT QUẢ KIỂM TRA HIỆN TRƯỜNG', content: 'Công trình duy trì rào chắn, hệ thống phun sương dập bụi và rửa bánh xe theo quy chuẩn.' }
    ],
    signatures: {
      inspector: { name: body.items?.inspector || 'Nguyễn Văn An', title: 'Thanh tra viên' },
      representative: { name: body.items?.representative || 'Đại diện Nhà thầu', title: 'Chỉ huy trưởng công trình' }
    }
  };

  return c.json({
    status: 'success',
    data: {
      report,
      markdown: `# BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG\n\n**Căn cứ pháp lý:** Nghị định 45/2022/NĐ-CP, QCVN 18:2021/BXD.\n\n**Kết quả:** Công trình tuân thủ các quy định về kiểm soát bụi.`,
      provider: 'internal_ast_template',
      timestamp: now
    },
    message: 'Tự động tạo báo cáo kiểm tra thành công'
  });
});

const handleAiSearch = async (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({
      status: 'error',
      code: 'KILL_SWITCH_ACTIVE',
      message: 'AI Assistant features are temporarily disabled by kill switch.'
    }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  const query = body.query || c.req.query('q') || '';
  return c.json({
    status: 'success',
    data: {
      query,
      answer: `Căn cứ theo Nghị định 45/2022/NĐ-CP (Điều 43) và QCVN 18:2021/BXD, các công trình xây dựng bắt buộc phải thực hiện các biện pháp kiểm soát bụi: lắp đặt rào chắn kín cao tối thiểu 2.0m, phun ẩm dập bụi liên tục và rửa sạch lốp xe trước khi rời công trường.`,
      results: [
        { id: 'L1', title: 'Nghị định 45/2022/NĐ-CP', clause: 'Điều 43', content: 'Quy định xử phạt vi phạm kiểm soát bụi xây dựng' },
        { id: 'L2', title: 'QCVN 18:2021/BXD', clause: 'Mục 2.1 & 2.3', content: 'Quy chuẩn an toàn và biện pháp dập bụi, che chắn công trình' },
        { id: 'L3', title: 'QĐ 48/2024/QĐ-UBND', clause: 'Điều 5', content: 'Quy định quản lý vệ sinh môi trường trong hoạt động xây dựng tại Hà Nội' }
      ],
      citations: [
        { documentCode: 'NĐ 45/2022/NĐ-CP', article: 'Điều 43' },
        { documentCode: 'QCVN 18:2021/BXD', article: 'Mục 2.1' }
      ],
      provider: 'hybrid_edge_rag'
    },
    message: 'Tìm kiếm & tư vấn pháp lý thành công'
  });
};

router.post('/api/ai/search', handleAiSearch);
router.post('/api/ai/legal-assistant', handleAiSearch);
router.post('/api/ai/analyze', handleAiSearch);
router.post('/api/ai/legal-obligations', handleAiSearch);
router.post('/api/ai/inspection-report', async (c) => {
  return c.redirect('/api/ai/auto-report', 307);
});

router.post('/api/ai/explain-violation', async (c) => {
  const enableAi = (c.env?.ENABLE_AI ?? process.env?.ENABLE_AI ?? 'true').toString().toLowerCase();
  if (enableAi === 'false') {
    return c.json({
      status: 'error',
      code: 'KILL_SWITCH_ACTIVE',
      message: 'AI Assistant features are temporarily disabled by kill switch.'
    }, 503);
  }
  const body = await c.req.json().catch(() => ({}));
  const itemKey = body.itemKey || 'general';
  return c.json({
    status: 'success',
    data: {
      itemKey,
      explanation: `Hạng mục "${itemKey}" cần tuân thủ nghiêm ngặt theo quy định tại QCVN 18:2021/BXD và Nghị định 45/2022/NĐ-CP để phòng ngừa phát tán bụi mịn ra môi trường.`,
      provider: 'rule_based_legal_mapping'
    },
    message: 'Giải thích vi phạm thành công'
  });
});

router.post('/api/ai/image', (c) => {
  return c.json(formatRfc7807Error(501, 'NOT_IMPLEMENTED', 'Not Implemented', 'Tính năng phân tích/sinh ảnh AI đang trong lộ trình phát triển. Hệ thống ưu tiên sử dụng ảnh thực tế hiện trường.', c.req.path), 501);
});

export default router;
