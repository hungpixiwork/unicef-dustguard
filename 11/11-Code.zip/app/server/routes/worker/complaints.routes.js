import { Hono } from 'hono';
import {
  generateId,
  generateRandomHex,
  sha256Hex,
  getAuthenticatedUser,
  getD1OrSqlite,
  parsePaginationParams
} from './helpers.js';

const router = new Hono();

export const maskPhone = (p) => (p ? p.replace(/(\d{3})\d{4}(\d{3,4})/, '$1****$2') : '');

const handleGetComplaints = async (c) => {
  try {
    const user = await getAuthenticatedUser(c);
    const userRole = (user?.role || user?.primaryRole || '').toLowerCase();
    const userRoles = (user?.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    const siteId = c.req.query('siteId');
    const status = c.req.query('status');
    const { limit, offset } = parsePaginationParams(c, 50, 100);

    if (c.env && c.env.DB) {
      let query = 'SELECT * FROM complaints WHERE deletedAt IS NULL';
      const params = [];
      if (siteId) {
        query += ' AND siteId = ?';
        params.push(siteId);
      }
      if (status) {
        query += ' AND status = ?';
        params.push(status);
      }
      query += ' ORDER BY createdAt DESC LIMIT ? OFFSET ?';
      params.push(limit, offset);

      const stmt = c.env.DB.prepare(query);
      const { results } = await stmt.bind(...params).all();
      
      const items = (results || []).map((row) => ({
        ...row,
        reporterPhone: isStaffOrAdmin ? row.reporterPhone : null,
        reporterName: isStaffOrAdmin ? row.reporterName : null,
        triageNote: isStaffOrAdmin ? row.triageNote : null
      }));

      return c.json({ status: 'success', data: { items, pagination: { limit, offset, count: items.length } }, pagination: { limit, offset, count: items.length } });
    }
    return c.json({ status: 'success', data: { items: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/public-complaints', handleGetComplaints);
router.get('/api/complaints', handleGetComplaints);
router.get('/api/v1/complaints', handleGetComplaints);

const handleGetComplaintById = async (c) => {
  try {
    const id = c.req.param('id') || c.req.param('code');
    const user = await getAuthenticatedUser(c);
    const userRole = (user?.role || user?.primaryRole || '').toLowerCase();
    const userRoles = (user?.roles || [userRole]).map(r => r.toLowerCase());
    const isStaffOrAdmin = user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

    if (c.env && c.env.DB) {
      const complaint = await c.env.DB.prepare(
        'SELECT * FROM complaints WHERE (id = ? OR code = ?) AND deletedAt IS NULL'
      ).bind(id, id).first();

      if (complaint) {
        const site = complaint.siteId ? await c.env.DB.prepare('SELECT * FROM sites WHERE id = ?').bind(complaint.siteId).first() : null;
        
        const { results: evidences } = await c.env.DB.prepare(
          'SELECT * FROM evidences WHERE complaintId = ? AND deletedAt IS NULL ORDER BY createdAt ASC'
        ).bind(complaint.id).all().catch(() => ({ results: [] }));
        
        const { results: logs } = await c.env.DB.prepare(
          'SELECT * FROM audit_logs WHERE targetId = ? OR targetId = ? ORDER BY createdAt ASC'
        ).bind(complaint.id, complaint.code).all().catch(() => ({ results: [] }));

        let caseTimelines = [];
        let resolvedEvidenceUrl = null;
        const linkedCase = await c.env.DB.prepare(
          'SELECT id, siteId FROM cases WHERE complaintId = ? OR id = ? LIMIT 1'
        ).bind(complaint.id, complaint.caseId || '').first().catch(() => null);

        const caseId = linkedCase?.id || complaint.caseId;
        if (caseId) {
          const { results: ct } = await c.env.DB.prepare(
            'SELECT * FROM case_timelines WHERE caseId = ? ORDER BY createdAt ASC'
          ).bind(caseId).all().catch(() => ({ results: [] }));
          caseTimelines = ct || [];

          const actionEv = await c.env.DB.prepare(
            'SELECT evidenceUrl FROM actions WHERE caseId = ? AND evidenceUrl IS NOT NULL ORDER BY updatedAt DESC LIMIT 1'
          ).bind(caseId).first().catch(() => null);
          if (actionEv?.evidenceUrl) {
            resolvedEvidenceUrl = actionEv.evidenceUrl;
          }
        }

        const timeline = [
          {
            id: `evt_created_${complaint.id}`,
            event: 'REPORT_SUBMITTED',
            title: 'Bạn đã gửi phản ánh',
            description: `Tiếp nhận phản ánh tại ${complaint.address || 'vị trí hiện trường'}`,
            time: complaint.createdAt,
            actorRole: 'citizen'
          }
        ];

        (logs || []).forEach((log) => {
          if (log.action === 'COMPLAINT_EVIDENCE_APPEND') {
            timeline.push({
              id: log.id,
              event: 'EVIDENCE_APPENDED',
              title: 'Bổ sung bằng chứng hiện trường',
              description: 'Đã đính kèm ảnh và minh chứng cập nhật',
              time: log.createdAt,
              actorRole: log.actor_role || 'citizen'
            });
          } else if (log.action === 'COMPLAINT_REOPEN_REQUESTED') {
            timeline.push({
              id: log.id,
              event: 'REOPEN_REQUESTED',
              title: 'Yêu cầu kiểm tra lại hiện trường',
              description: 'Người dân báo tình trạng ô nhiễm bụi vẫn tiếp diễn',
              time: log.createdAt,
              actorRole: 'citizen'
            });
          } else if (log.action === 'DISPATCH_COMMUNITY_MISSION') {
            timeline.push({
              id: log.id,
              event: 'COMMUNITY_DISPATCHED',
              title: 'Cộng đồng đang hỗ trợ xác minh',
              description: 'Nhiệm vụ khảo sát đã giao cho CLB Môi trường / Thanh niên',
              time: log.createdAt,
              actorRole: 'community'
            });
          } else if (log.action === 'CONVERT_TO_CASE') {
            timeline.push({
              id: log.id,
              event: 'CASE_FORMALIZED',
              title: 'Đã lập hồ sơ thanh tra xử lý',
              description: 'Hồ sơ đã chuyển tới Đội Thanh tra Môi trường phụ trách',
              time: log.createdAt,
              actorRole: 'staff'
            });
          }
        });

        caseTimelines.forEach((ct) => {
          timeline.push({
            id: ct.id,
            event: ct.eventType || 'CASE_EVENT',
            title: ct.title || 'Cập nhật tiến trình xử lý',
            description: ct.description || 'Đang thực hiện quy trình kiểm tra',
            time: ct.createdAt,
            actorRole: ct.actorRole || 'staff'
          });
        });

        if (complaint.status === 'RESOLVED' || complaint.status === 'CLOSED') {
          timeline.push({
            id: `evt_resolved_${complaint.id}`,
            event: 'REPORT_RESOLVED',
            title: 'Đã hoàn tất xử lý hiện trường',
            description: 'Công trình đã thực hiện các biện pháp dập bụi và che chắn',
            time: complaint.updatedAt || complaint.createdAt,
            actorRole: 'system'
          });
        }

        timeline.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

        return c.json({
          status: 'success',
          data: {
            ...complaint,
            reporterPhone: isStaffOrAdmin ? complaint.reporterPhone : maskPhone(complaint.reporterPhone),
            reporterName: isStaffOrAdmin ? complaint.reporterName : null,
            triageNote: isStaffOrAdmin ? complaint.triageNote : null,
            site,
            evidences: (evidences || []).map((e) => ({ ...e, fileUrl: e.url })),
            resolvedEvidenceUrl,
            timeline
          }
        });
      }
    }
    return c.json({ status: 'error', message: 'Không tìm thấy phản ánh' }, 404);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.get('/api/complaints/:id', handleGetComplaintById);
router.get('/api/public-complaints/:id', handleGetComplaintById);
router.get('/api/public-complaints/:code', handleGetComplaintById);

export const COMPLAINT_RATE_LIMIT_STORE = new Map();
export const COMPLAINT_DUPLICATE_STORE = new Map();

export function resetComplaintRateLimits() {
  COMPLAINT_RATE_LIMIT_STORE.clear();
  COMPLAINT_DUPLICATE_STORE.clear();
}

function extractClientIp(c) {
  return c.req.header('cf-connecting-ip')
    || c.req.header('x-forwarded-for')?.split(',')[0]?.trim()
    || c.req.header('x-real-ip')
    || '127.0.0.1';
}

function extractClientSession(c, body = {}) {
  return c.req.header('x-session-id')
    || c.req.header('x-device-id')
    || c.req.header('x-client-id')
    || c.get('user')?.id
    || c.get('identity')?.id
    || body.sessionId
    || body.deviceId
    || body.deviceHash
    || null;
}

function normalizeCoordinate(val) {
  if (val === undefined || val === null || val === '') return '';
  const num = Number(val);
  return isNaN(num) ? String(val).trim() : num.toFixed(4);
}

async function computeComplaintDuplicateHash(body = {}) {
  const normDesc = (body.description || body.notes || '').trim().toLowerCase();
  const rawLat = body.lat ?? body.latitude ?? body.location?.lat ?? body.location?.latitude ?? (Array.isArray(body.coordinates) ? body.coordinates[1] : '') ?? '';
  const rawLng = body.lng ?? body.lon ?? body.longitude ?? body.location?.lng ?? body.location?.longitude ?? (Array.isArray(body.coordinates) ? body.coordinates[0] : '') ?? '';
  const normLat = normalizeCoordinate(rawLat);
  const normLng = normalizeCoordinate(rawLng);
  const normAddress = (body.address || '').trim().toLowerCase();
  const normWard = (body.ward || '').trim().toLowerCase();

  const rawPayload = `${normDesc}|lat:${normLat}|lng:${normLng}|addr:${normAddress}|ward:${normWard}`;
  return sha256Hex(rawPayload);
}

export const complaintAntiSpamMiddleware = async (c, next) => {
  let body = {};
  try {
    body = await c.req.raw.clone().json();
  } catch {
    body = {};
  }
  c.set('parsedBody', body);

  const now = Date.now();
  const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
  const MAX_COMPLAINTS_PER_WINDOW = 5;
  const DUPLICATE_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

  const ip = extractClientIp(c);
  const sessionId = extractClientSession(c, body);

  const ipKey = `ip:${ip}`;
  const sessionKey = sessionId ? `session:${sessionId}` : null;

  const ipTimestamps = (COMPLAINT_RATE_LIMIT_STORE.get(ipKey) || []).filter(t => (now - t) < RATE_LIMIT_WINDOW_MS);
  COMPLAINT_RATE_LIMIT_STORE.set(ipKey, ipTimestamps);

  let sessionTimestamps = [];
  if (sessionKey) {
    sessionTimestamps = (COMPLAINT_RATE_LIMIT_STORE.get(sessionKey) || []).filter(t => (now - t) < RATE_LIMIT_WINDOW_MS);
    COMPLAINT_RATE_LIMIT_STORE.set(sessionKey, sessionTimestamps);
  }

  if (ipTimestamps.length >= MAX_COMPLAINTS_PER_WINDOW || (sessionKey && sessionTimestamps.length >= MAX_COMPLAINTS_PER_WINDOW)) {
    const relevantTimestamps = ipTimestamps.length >= MAX_COMPLAINTS_PER_WINDOW ? ipTimestamps : sessionTimestamps;
    const oldest = Math.min(...relevantTimestamps);
    const retryAfterSeconds = Math.max(1, Math.ceil((oldest + RATE_LIMIT_WINDOW_MS - now) / 1000));

    c.header('Retry-After', String(retryAfterSeconds));
    return c.json({
      status: 'error',
      statusCode: 429,
      type: 'https://dustguard.vn/errors/429',
      title: 'Too Many Requests',
      detail: `Bạn đã vượt quá giới hạn gửi phản ánh (tối đa ${MAX_COMPLAINTS_PER_WINDOW} phản ánh / 10 phút). Vui lòng thử lại sau ${retryAfterSeconds} giây.`,
      instance: c.req.path,
      message: `Vượt quá giới hạn nộp phản ánh (tối đa ${MAX_COMPLAINTS_PER_WINDOW} phản ánh / 10 phút).`,
      retryAfter: retryAfterSeconds,
      timestamp: new Date().toISOString()
    }, 429);
  }

  const normDesc = (body.description || body.notes || '').trim().toLowerCase();
  const rawLat = body.lat ?? body.latitude ?? body.location?.lat ?? body.location?.latitude ?? (Array.isArray(body.coordinates) ? body.coordinates[1] : '') ?? '';
  const normAddress = (body.address || '').trim().toLowerCase();
  const normWard = (body.ward || '').trim().toLowerCase();

  let dupHash = null;
  if (normDesc || normAddress || rawLat || normWard) {
    dupHash = await computeComplaintDuplicateHash(body);
    const existingDup = COMPLAINT_DUPLICATE_STORE.get(dupHash);

    if (existingDup && existingDup.expiresAt > now) {
      const retryAfterSeconds = Math.max(1, Math.ceil((existingDup.expiresAt - now) / 1000));
      c.header('Retry-After', String(retryAfterSeconds));
      return c.json({
        status: 'error',
        statusCode: 429,
        type: 'https://dustguard.vn/errors/429',
        title: 'Too Many Requests',
        detail: `Phát hiện phản ánh có nội dung và tọa độ trùng lặp trong vòng 5 phút. Vui lòng thử lại sau ${retryAfterSeconds} giây.`,
        instance: c.req.path,
        message: 'Phát hiện phản ánh trùng lặp nội dung và tọa độ trong vòng 5 phút.',
        retryAfter: retryAfterSeconds,
        timestamp: new Date().toISOString()
      }, 429);
    }
  }

  if (dupHash) {
    COMPLAINT_DUPLICATE_STORE.set(dupHash, {
      expiresAt: now + DUPLICATE_WINDOW_MS,
      createdAt: now
    });
  }

  ipTimestamps.push(now);
  COMPLAINT_RATE_LIMIT_STORE.set(ipKey, ipTimestamps);

  if (sessionKey) {
    sessionTimestamps.push(now);
    COMPLAINT_RATE_LIMIT_STORE.set(sessionKey, sessionTimestamps);
  }

  await next();
};

const handleCreateComplaint = async (c) => {
  try {
    const body = c.get('parsedBody') || await c.req.json().catch(() => ({}));
    const complaintId = generateId('cmp');
    const randomHex = generateRandomHex(4);
    const now = new Date().toISOString();
    const code = body.code || `DG-2026-${randomHex.toUpperCase()}`;

    const ward = body.ward || 'Chưa xác định';
    const address = body.address || 'Hồ Chí Minh';
    const description = body.description || body.notes || 'Phản ánh ô nhiễm bụi công trường.';
    const reporterName = body.reporterName || body.citizenName || 'Công dân';
    const reporterPhone = body.reporterPhone || body.citizenPhone || '';
    const siteId = body.siteId || null;

    const evidences = [];
    if (c.env && c.env.DB) {
      try {
        await c.env.DB.prepare(
          'INSERT INTO complaints (id, code, siteId, ward, address, description, reporterName, reporterPhone, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(complaintId, code, siteId, ward, address, description, reporterName, reporterPhone, 'PENDING', now, now).run();

        if (Array.isArray(body.evidences) && body.evidences.length > 0) {
          for (const ev of body.evidences) {
            const evId = generateId('evd');
            const fileUrl = typeof ev === 'string' ? ev : (ev.url || ev.fileUrl || '');
            const fileType = typeof ev === 'object' ? (ev.type || ev.fileType || 'IMAGE') : 'IMAGE';
            const hash = typeof ev === 'object' ? (ev.sha256 || ev.hash || generateRandomHex(32)) : generateRandomHex(32);
            if (fileUrl) {
              await c.env.DB.prepare(
                'INSERT INTO evidences (id, url, type, sha256, complaintId, createdAt) VALUES (?, ?, ?, ?, ?, ?)'
              ).bind(evId, fileUrl, fileType, hash, complaintId, now).run().catch(() => {});
              evidences.push({ id: evId, complaintId, url: fileUrl, fileUrl, type: fileType, sha256: hash, createdAt: now });
            }
          }
        }

        const auditId = generateId('aud');
        await c.env.DB.prepare(
          'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).bind(auditId, reporterName, 'citizen', 'CREATE_COMPLAINT', complaintId, JSON.stringify({ code, ward, address }), now).run();
      } catch (e) {}
    }

    return c.json({
      status: 'success',
      data: {
        id: complaintId,
        code,
        trackingCode: code,
        siteId,
        ward,
        address,
        description,
        reporterName,
        reporterPhone: maskPhone(reporterPhone),
        status: 'PENDING',
        evidences,
        createdAt: now
      },
      message: 'Gửi phản ánh thành công'
    }, 201);
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};

router.post('/api/public-complaints', complaintAntiSpamMiddleware, handleCreateComplaint);
router.post('/api/complaints', complaintAntiSpamMiddleware, handleCreateComplaint);
router.post('/api/v1/complaints', complaintAntiSpamMiddleware, handleCreateComplaint);

// Append Evidence Endpoint for Citizen
router.post('/api/complaints/:id/evidence', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    const appended = [];

    if (c.env && c.env.DB) {
      const complaint = await c.env.DB.prepare(
        'SELECT * FROM complaints WHERE id = ? OR code = ?'
      ).bind(id, id).first();

      if (!complaint) {
        return c.json({ status: 'error', message: 'Không tìm thấy phản ánh' }, 404);
      }

      const inputEvidences = Array.isArray(body.evidences) ? body.evidences : (body.fileUrl || body.url ? [body] : []);
      for (const ev of inputEvidences) {
        const evId = generateId('evd');
        const fileUrl = typeof ev === 'string' ? ev : (ev.url || ev.fileUrl || '');
        const fileType = typeof ev === 'object' ? (ev.type || ev.fileType || 'IMAGE') : 'IMAGE';
        const hash = typeof ev === 'object' ? (ev.sha256 || ev.hash || generateRandomHex(32)) : generateRandomHex(32);
        if (fileUrl) {
          await c.env.DB.prepare(
            'INSERT INTO evidences (id, url, type, sha256, complaintId, createdAt) VALUES (?, ?, ?, ?, ?, ?)'
          ).bind(evId, fileUrl, fileType, hash, complaint.id, now).run().catch(() => {});
          appended.push({ id: evId, complaintId: complaint.id, url: fileUrl, fileUrl, type: fileType, sha256: hash, createdAt: now });
        }
      }

      const auditId = generateId('aud');
      await c.env.DB.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(auditId, body.actorName || 'Công dân', 'citizen', 'COMPLAINT_EVIDENCE_APPEND', complaint.id, JSON.stringify({ count: appended.length }), now).run();

      return c.json({
        status: 'success',
        data: { complaintId: complaint.id, appended, count: appended.length },
        message: 'Bổ sung bằng chứng thành công'
      });
    }

    return c.json({ status: 'success', data: { appended: [] } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

// Convert Complaint to Formal Case Endpoint
router.post('/api/complaints/:id/convert-to-case', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    const caseId = generateId('cas');

    if (c.env && c.env.DB) {
      const complaint = await c.env.DB.prepare(
        'SELECT * FROM complaints WHERE id = ? OR code = ?'
      ).bind(id, id).first();

      if (!complaint) {
        return c.json({ status: 'error', message: 'Không tìm thấy phản ánh' }, 404);
      }

      const caseCode = `CASE-${new Date().getFullYear()}-${generateRandomHex(4).toUpperCase()}`;
      await c.env.DB.prepare(
        'INSERT INTO cases (id, code, siteId, complaintId, sourceType, sourceId, title, description, status, priority, createdBy, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(caseId, caseCode, complaint.siteId || null, complaint.id, 'COMPLAINT', complaint.id, `Hồ sơ xử lý phản ánh ${complaint.code}`, complaint.description, 'SCREENING', 'HIGH', body.inspectorName || 'Cán bộ Thanh tra', now, now).run();

      await c.env.DB.prepare(
        'UPDATE complaints SET status = ?, updatedAt = ? WHERE id = ?'
      ).bind('INVESTIGATING', now, complaint.id).run();

      const auditId = generateId('aud');
      await c.env.DB.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(auditId, body.inspectorName || 'Cán bộ Thanh tra', 'staff', 'CONVERT_TO_CASE', complaint.id, JSON.stringify({ caseId, caseCode }), now).run();

      return c.json({
        status: 'success',
        data: { caseId, caseCode, complaintId: complaint.id, status: 'SCREENING' },
        message: 'Đã lập hồ sơ thanh tra xử lý phản ánh'
      }, 201);
    }

    return c.json({ status: 'success', data: { caseId } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
});

const handleUpdateComplaint = async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      await c.env.DB.prepare(
        'UPDATE complaints SET status = COALESCE(?, status), description = COALESCE(?, description), updatedAt = ? WHERE id = ?'
      ).bind(body.status || null, body.description || null, now, id).run();
    }
    return c.json({ status: 'success', data: { id, ...body, updatedAt: now }, message: 'Cập nhật phản ánh thành công' });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.patch('/api/complaints/:id', handleUpdateComplaint);
router.put('/api/complaints/:id', handleUpdateComplaint);

const handleUpdateComplaintStatus = async (c) => {
  try {
    const id = c.req.param('id');
    const { status } = await c.req.json().catch(() => ({}));
    const now = new Date().toISOString();
    if (c.env && c.env.DB) {
      await c.env.DB.prepare('UPDATE complaints SET status = ?, updatedAt = ? WHERE id = ?').bind(status || 'VERIFIED', now, id).run();
    }
    return c.json({ status: 'success', data: { id, status, updatedAt: now } });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.put('/api/complaints/:id/status', handleUpdateComplaintStatus);
router.patch('/api/complaints/:id/status', handleUpdateComplaintStatus);
const handleVerifyComplaint = async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const { isSatisfied, feedback, action: clientAction, evidenceUrl } = body;
    const user = await getAuthenticatedUser(c);
    const now = new Date().toISOString();

    if (!c.env?.DB) {
      return c.json({ status: 'error', message: 'Cơ sở dữ liệu D1 chưa sẵn sàng' }, 500);
    }

    const complaint = await c.env.DB.prepare(
      'SELECT * FROM complaints WHERE (id = ? OR code = ?) AND deletedAt IS NULL LIMIT 1'
    ).bind(id, id).first();

    if (!complaint) {
      return c.json({ status: 'error', message: 'Không tìm thấy thông tin phản ánh' }, 404);
    }

    const action = clientAction || (isSatisfied === false ? 'REOPEN_REQUEST' : 'CONFIRM_RESOLVED');

    if (action === 'REOPEN_REQUEST' || isSatisfied === false) {
      const triageNote = feedback || 'Người dân yêu cầu kiểm tra lại hiện trường (REOPEN_REQUEST)';
      await c.env.DB.prepare(
        'UPDATE complaints SET triageNote = ?, updatedAt = ? WHERE id = ?'
      ).bind(triageNote, now, complaint.id).run();

      const auditId = generateId('aud');
      await c.env.DB.prepare(
        'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).bind(
        auditId,
        user?.name || user?.fullName || 'Người dân',
        user?.role || 'citizen',
        'COMPLAINT_REOPEN_REQUESTED',
        complaint.id,
        JSON.stringify({ complaintId: complaint.id, code: complaint.code, feedback: triageNote, evidenceUrl: evidenceUrl || null }),
        now
      ).run().catch(() => {});

      return c.json({
        status: 'success',
        data: {
          id: complaint.id,
          code: complaint.code,
          status: complaint.status,
          action: 'REOPEN_REQUESTED',
          updatedAt: now
        },
        message: 'Đã tiếp nhận yêu cầu kiểm tra lại của bạn. Cán bộ thanh tra sẽ xem xét.'
      });
    }

    const newStatus = 'RESOLVED';
    const triageNote = feedback || 'Đã xác nhận hoàn thành bởi người dân';
    await c.env.DB.prepare(
      'UPDATE complaints SET status = ?, closedAt = ?, triageNote = ?, updatedAt = ? WHERE id = ?'
    ).bind(newStatus, now, triageNote, now, complaint.id).run();

    const auditId = generateId('aud');
    await c.env.DB.prepare(
      'INSERT INTO audit_logs (id, actor_name, actor_role, action, targetId, details, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).bind(
      auditId,
      user?.name || user?.fullName || 'Người dân',
      user?.role || 'citizen',
      'COMPLAINT_CITIZEN_VERIFY',
      complaint.id,
      JSON.stringify({ complaintId: complaint.id, code: complaint.code, isSatisfied: true, newStatus }),
      now
    ).run().catch(() => {});

    return c.json({
      status: 'success',
      data: {
        id: complaint.id,
        code: complaint.code,
        status: newStatus,
        isSatisfied: true,
        verifiedAt: now
      },
      message: 'Xác nhận xử lý thành công (+30 điểm cộng đồng)'
    });
  } catch (err) {
    return c.json({ status: 'error', message: err.message }, 500);
  }
};
router.post('/api/complaints/:id/verify', handleVerifyComplaint);
router.patch('/api/complaints/:id/verify', handleVerifyComplaint);
router.put('/api/complaints/:id/verify', handleVerifyComplaint);

export default router;
