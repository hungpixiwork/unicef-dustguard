import { Router } from 'express';
import multer from 'multer';
import {
  listLegalDocuments,
  getLegalReferenceDocs,
  getLegalDocumentFile,
  uploadLegalDocument,
  runLegalPipeline,
  getLegalObligations,
  reviewObligation,
  generateChecklistFromObligations,
  activateChecklist,
  createLegalObligation,
  getLegalDocumentById,
  getActiveLegalContextSummary,
  updateLegalDocumentMetadata,
  getLegalSegments,
  searchLegal,
  deleteLegalDocument,
  deleteLegalObligation
} from '../../controllers/legal.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { successResponse, errorResponse } from '../../lib/response.js';
import { prisma } from '../../shared/db.js';
import logger from '../../lib/logger.js';

const uploadMemory = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 40 * 1024 * 1024 } // 40MB limit for legal docs
});

const router = Router();

// Staff and Admin access middleware group
const staffAccess = [requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin')];

router.get('/', ...staffAccess, listLegalDocuments);
router.get('/documents', ...staffAccess, listLegalDocuments);
router.get('/documents/:id', ...staffAccess, getLegalDocumentById);
router.get('/reference-docs', ...staffAccess, getLegalReferenceDocs);
router.get('/active-context/summary', ...staffAccess, getActiveLegalContextSummary);
router.get('/segments', ...staffAccess, getLegalSegments);
router.get('/search', ...staffAccess, searchLegal);
router.post('/search', ...staffAccess, searchLegal);


// /api/legal-documents/obligations — list with optional ?documentId= filter
router.get('/obligations', ...staffAccess, getLegalObligations);
router.post('/obligations', ...staffAccess, createLegalObligation);

// /api/legal-documents/obligations/:id/map-checklist — map obligation to checklist item(s)
router.post('/obligations/:id/map-checklist', ...staffAccess, async (req, res, next) => {
  try {
    const { id: obligationId } = req.params;
    const { checklistItemIds, checklistItemId, checklistItemCode, notes } = req.body || {};

    const obligation = await prisma.legalObligation.findUnique({
      where: { id: obligationId }
    });

    if (!obligation) {
      return errorResponse(res, 'Không tìm thấy nghĩa vụ pháp lý (LegalObligation).', 404);
    }

    // Support both batch (checklistItemIds array) and single (checklistItemId / checklistItemCode)
    const itemIds = Array.isArray(checklistItemIds) && checklistItemIds.length > 0
      ? checklistItemIds
      : [checklistItemId || checklistItemCode].filter(Boolean);

    if (itemIds.length === 0) {
      return errorResponse(res, 'Thiếu checklistItemIds hoặc checklistItemId.', 400);
    }

    // Upsert all mappings, skipping duplicates safely for SQLite
    for (const cid of itemIds) {
      try {
        const existing = await prisma.obligationChecklistMapping.findFirst({
          where: { obligationId, checklistItemId: cid }
        });
        if (!existing) {
          await prisma.obligationChecklistMapping.create({
            data: {
              obligationId,
              checklistItemId: cid,
              notes: notes || null,
            }
          });
        }
      } catch (err) {
        logger.warn('Error creating obligationChecklistMapping', { obligationId, cid, error: err.message });
      }
    }

    // Fetch the created/existing records for this obligation
    const mappings = await prisma.obligationChecklistMapping.findMany({
      where: {
        obligationId,
        checklistItemId: { in: itemIds },
      },
    });

    logger.info('map-checklist persisted', { obligationId, itemIds, count: mappings.length });
    return successResponse(res, {
      success: true,
      mapped: mappings.length,
      mappings,
    }, 'Mapping checklist thành công');
  } catch (error) {
    next(error);
  }
});

// /api/legal-documents/obligation-checklist-mappings/:id — update a mapping
router.patch('/obligation-checklist-mappings/:id', ...staffAccess, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { notes, checklistItemId } = req.body || {};

    const existing = await prisma.obligationChecklistMapping.findUnique({ where: { id } });
    if (!existing) {
      return errorResponse(res, 'Không tìm thấy mapping checklist.', 404);
    }

    const updated = await prisma.obligationChecklistMapping.update({
      where: { id },
      data: {
        ...(notes !== undefined ? { notes } : {}),
        ...(checklistItemId !== undefined ? { checklistItemId } : {}),
      },
    });

    logger.info('obligation-checklist-mappings PATCH', { mappingId: id });
    return successResponse(res, { mapping: updated }, 'Cập nhật mapping checklist thành công');
  } catch (error) {
    next(error);
  }
});

router.get('/:id/file', ...staffAccess, getLegalDocumentFile);
router.get('/:id', ...staffAccess, getLegalDocumentById);
router.patch('/:id/metadata', ...staffAccess, updateLegalDocumentMetadata);
router.patch('/:id', ...staffAccess, updateLegalDocumentMetadata);
router.post('/upload', ...staffAccess, uploadMemory.single('file'), uploadLegalDocument);
router.post('/:id/run-full-pipeline', ...staffAccess, runLegalPipeline);
router.get('/:id/obligations', ...staffAccess, getLegalObligations);
router.patch('/obligations/:id/review', ...staffAccess, reviewObligation);
router.delete('/obligations/:id', ...staffAccess, deleteLegalObligation);
router.delete('/:id', ...staffAccess, deleteLegalDocument);
router.post('/checklist-templates/generate-from-obligations', ...staffAccess, generateChecklistFromObligations);
router.post('/checklist-templates/:id/activate', ...staffAccess, activateChecklist);

export default router;
