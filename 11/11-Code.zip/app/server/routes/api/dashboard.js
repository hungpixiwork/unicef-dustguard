import { Router } from 'express';
import { getExecutiveDashboard, quickSignDocument } from '../../controllers/dashboard.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { prisma } from '../../shared/db.js';
import { successResponse } from '../../lib/response.js';
import { getCached, setCached } from '../../lib/cache.js';

const router = Router();

// Retrieve executive dashboard stats and lists
router.get('/executive', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), getExecutiveDashboard);

// GET /api/dashboard/summary & GET /api/staff/dashboard/summary & GET /api/staff/dashboard
router.get(['/summary', '/staff/summary', '/staff/dashboard'], async (req, res, next) => {
  try {
    const { getStaffDashboardData } = await import('../../services/staff-dashboard.service.js');
    const dashboardData = await getStaffDashboardData();
    return successResponse(res, dashboardData, 'Tổng quan Dashboard cán bộ từ CSDL dev.db');
  } catch (error) {
    next(error);
  }
});

// /api/dashboard/operations — operational KPIs for staff view
router.get('/operations', requireAuth, async (req, res, next) => {
  try {
    const cacheKey = 'dashboard:operations';
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Dữ liệu vận hành (cached)');
    }

    const now = new Date();

    // 1. Group actions by status in a single aggregation query
    const statusGroups = await prisma.action.groupBy({
      by: ['status'],
      _count: { id: true },
    });

    let pendingCount = 0;
    let inProgressCount = 0;
    let resolvedCount = 0;

    statusGroups.forEach(g => {
      if (g.status === 'PENDING') pendingCount += g._count.id;
      else if (g.status === 'IN_PROGRESS') inProgressCount += g._count.id;
      else if (['VERIFIED', 'COMPLETED'].includes(g.status)) resolvedCount += g._count.id;
    });

    const [overdueCount, totalWithDue, completedWithDue, rawLoad] = await Promise.all([
      prisma.action.count({
        where: {
          dueDate: { lt: now },
          status: { notIn: ['VERIFIED', 'COMPLETED', 'PENDING_VERIFICATION'] },
        },
      }),
      prisma.action.count({ where: { dueDate: { not: null } } }),
      prisma.action.count({
        where: { dueDate: { not: null }, status: { in: ['VERIFIED', 'COMPLETED'] } },
      }),
      // Inspector workload (actions grouped by assignee)
      prisma.action.groupBy({
        by: ['assignee'],
        where: { status: { notIn: ['VERIFIED', 'COMPLETED'] } },
        _count: { id: true },
        orderBy: { _count: { id: 'desc' } },
        take: 10,
      })
    ]);

    // Calculate SLA on-time rate selecting only required timestamp fields for verified actions with due dates
    const verifiedActionsWithDueDate = await prisma.action.findMany({
      where: { status: 'VERIFIED', dueDate: { not: null } },
      select: { dueDate: true, updatedAt: true },
    });
    const totalVerifiedCount = resolvedCount;
    const lateVerifiedCount = verifiedActionsWithDueDate.filter(
      a => new Date(a.updatedAt) > new Date(a.dueDate)
    ).length;
    const slaOnTimeRate = totalVerifiedCount > 0
      ? Math.round(((totalVerifiedCount - lateVerifiedCount) / totalVerifiedCount) * 100)
      : 100;

    const inspectorLoad = rawLoad.map(r => ({
      inspector: r.assignee || 'Chưa phân công',
      activeActions: r._count.id,
    }));

    // Province hotspots: Group overdue actions by siteId via prisma.action.groupBy instead of loading all rows into RAM
    const overdueGroupedBySite = await prisma.action.groupBy({
      by: ['siteId'],
      where: {
        dueDate: { lt: now },
        status: { notIn: ['VERIFIED', 'COMPLETED', 'PENDING_VERIFICATION'] },
      },
      _count: { id: true },
    });

    const siteIds = overdueGroupedBySite.map(g => g.siteId);
    const sitesProvinces = siteIds.length > 0
      ? await prisma.site.findMany({
          where: { id: { in: siteIds } },
          select: { id: true, province: true },
        })
      : [];

    const siteProvinceMap = new Map(sitesProvinces.map(s => [s.id, s.province || 'TP. Hà Nội']));
    const provinceMap = {};
    overdueGroupedBySite.forEach(g => {
      const province = siteProvinceMap.get(g.siteId) || 'TP. Hà Nội';
      provinceMap[province] = (provinceMap[province] || 0) + g._count.id;
    });

    const provinceHotspots = Object.entries(provinceMap)
      .map(([province, count]) => ({ province, overdueCount: count }))
      .sort((a, b) => b.overdueCount - a.overdueCount)
      .slice(0, 5);

    // Fetch top 10 overdue actions for response list using take: 10
    const topOverdueActions = await prisma.action.findMany({
      where: {
        dueDate: { lt: now },
        status: { notIn: ['VERIFIED', 'COMPLETED', 'PENDING_VERIFICATION'] },
      },
      select: {
        id: true,
        title: true,
        assignee: true,
        dueDate: true,
        site: { select: { province: true } },
      },
      orderBy: { dueDate: 'asc' },
      take: 10,
    });

    const completionRate = totalWithDue
      ? Math.round((completedWithDue / totalWithDue) * 100)
      : 0;

    const result = {
      kpis: { pending: pendingCount, inProgress: inProgressCount, resolved: resolvedCount, overdue: overdueCount, slaOnTimeRate },
      inspectorLoad,
      provinceHotspots,
      beforeAfterEffectiveness: { completionRate },
      overdueActions: topOverdueActions.map(a => ({
        id: a.id,
        title: a.title,
        assignee: a.assignee,
        dueDate: a.dueDate,
        siteProvince: a.site?.province,
      })),
    };

    setCached(cacheKey, result, 3000); // cache 3 giây
    return successResponse(res, result, 'Dữ liệu vận hành');
  } catch (error) {
    next(error);
  }
});

// Quick sign/approve a draft document (official inspection minutes / corrective notices)
router.post('/documents/:id/quick-sign', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), quickSignDocument);

export default router;
