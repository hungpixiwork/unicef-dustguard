import { Router } from 'express';
import { getCommunities, createCommunity } from '../../repositories/community.repository.js';
import { getCommunityImpactStats } from '../../repositories/impact.repository.js';
import { getObservations, createObservation } from '../../repositories/observation.repository.js';
import { createFollowUp } from '../../repositories/followup.repository.js';
import { createHandoff } from '../../repositories/handoff.repository.js';
import {
  getPublicDiscoverData,
  getPublicCampaignDetail,
  getPublicClubDetail
} from '../../repositories/community-admin.repository.js';
import { validateObservationInput } from '../../domain/observations/observation.rules.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();

// GET /api/community/discover (Pure DB SSOT Query)
router.get('/discover', async (req, res) => {
  try {
    const data = await getPublicDiscoverData(req.db);
    return successResponse(res, data, 'Lấy dữ liệu khám phá cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/campaigns/:slugOrId
router.get('/campaigns/:slugOrId', async (req, res) => {
  try {
    const data = await getPublicCampaignDetail(req.params.slugOrId, req.db);
    if (!data) return errorResponse(res, 'Chiến dịch không tồn tại', 404);
    return successResponse(res, data, 'Lấy chi tiết chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/clubs/:slugOrId
router.get('/clubs/:slugOrId', async (req, res) => {
  try {
    const data = await getPublicClubDetail(req.params.slugOrId, req.db);
    if (!data) return errorResponse(res, 'Câu lạc bộ không tồn tại', 404);
    return successResponse(res, data, 'Lấy chi tiết câu lạc bộ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/groups
router.get('/groups', async (req, res) => {
  try {
    const groups = await getCommunities();
    return successResponse(res, groups, 'Lấy danh sách câu lạc bộ cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// POST /api/community/groups
router.post('/groups', async (req, res) => {
  try {
    const group = await createCommunity(req.body, req.user || {});
    return successResponse(res, group, 'Tạo câu lạc bộ cộng đồng thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

// GET /api/community/impact
router.get('/impact', async (req, res) => {
  try {
    const stats = await getCommunityImpactStats();
    return successResponse(res, stats, 'Lấy thống kê tác động cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/me
router.get('/me', async (req, res) => {
  try {
    const user = req.user || { id: 'volunteer_guest', name: 'Thanh niên Hành động', role: 'volunteer' };
    const impact = await getCommunityImpactStats();
    return successResponse(res, {
      user,
      community: {
        id: 'comm_green_uit',
        name: 'CLB Môi Trường Xanh - ĐH Bách Khoa & UIT',
        role: 'Thành viên Tích cực'
      },
      impactSummary: impact
    }, 'Lấy thông tin tài khoản cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/observations
router.get('/observations', async (req, res) => {
  try {
    const result = await getObservations(req.query);
    return successResponse(res, result.items, 'Lấy danh sách ghi nhận cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// POST /api/community/observations
router.post('/observations', async (req, res) => {
  try {
    const validation = validateObservationInput(req.body);
    if (!validation.isValid) {
      return errorResponse(res, validation.errors.join(' '), 400);
    }
    const user = req.user || {};
    const observation = await createObservation(validation.sanitized, user);
    return successResponse(res, observation, 'Ghi nhận hiện trường đã lưu thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// POST /api/community/follow-ups
router.post('/follow-ups', async (req, res) => {
  try {
    const user = req.user || {};
    const followUp = await createFollowUp(req.body, user);
    return successResponse(res, followUp, 'Đã lưu kết quả theo dõi lại thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// POST /api/community/handoffs
router.post('/handoffs', async (req, res) => {
  try {
    const user = req.user || {};
    const handoff = await createHandoff(req.body, user);
    return successResponse(res, handoff, 'Hồ sơ bàn giao đã được thiết lập thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

export default router;
