import { Router } from 'express';
import { createHash } from 'crypto';
import { prisma } from '../../shared/db.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { successResponse, errorResponse, parsePaginationParams } from '../../lib/response.js';
import { normalizeStatus, transitionCaseStatus, createCase, calculateDeadlines, checkSlaViolations } from '../../services/case.service.js';
import { logCaseEvent } from '../../services/caseTimelineLogger.js';

const router = Router();

function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Verifies whether the authenticated contractor user is associated with the site.
 * Uses exact contractor ID matching or site contractor verification.
 */
function verifySiteContractor(site, user) {
  if (!site || !user) return false;

  const userId = user.id;
  const userFullName = (user.fullName || user.name || '').trim().toLowerCase();
  const userEmail = (user.email || '').trim().toLowerCase();

  if (site.contractorId && site.contractorId === userId) {
    return true;
  }
  if (site.contractorName && userFullName && site.contractorName.trim().toLowerCase() === userFullName) {
    return true;
  }
  if (site.managerEmail && userEmail && site.managerEmail.trim().toLowerCase() === userEmail) {
    return true;
  }
  if (site.managerName && userFullName && site.managerName.trim().toLowerCase() === userFullName) {
    return true;
  }

  return false;
}

// GET /api/cases: list all cases with optional filters for status, siteId, and sourceType
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const userRole = (req.user?.role || '').toLowerCase();
    if (userRole === 'citizen' || userRole === 'volunteer' || userRole === 'guest') {
      return errorResponse(res, 'Chỉ cán bộ quản lý (Staff/Inspector/Executive/Admin) hoặc nhà thầu liên quan mới được truy cập hồ sơ vụ việc.', 403);
    }

    const { status, siteId, sourceType } = req.query;
    const { limit, offset, page } = parsePaginationParams(req, 20, 100);
    const where = { deletedAt: null };

    // Contractor security scoping: only see cases of their own sites
    if (req.user.role === 'contractor') {
      const contractorNameVal = (req.user.fullName || req.user.name || '').trim();
      const userEmail = (req.user.email || '').trim();
      const siteOrConditions = [];
      if (contractorNameVal) {
        siteOrConditions.push({ contractorName: contractorNameVal });
        siteOrConditions.push({ managerName: contractorNameVal });
      }
      if (userEmail) {
        siteOrConditions.push({ managerEmail: userEmail });
      }
      where.site = {
        OR: siteOrConditions
      };
    }

    if (status) {
      const norm = normalizeStatus(status);
      if (norm === 'PENDING') {
        where.status = { in: ['PENDING', 'OPEN'] };
      } else if (norm === 'COMPLETED') {
        where.status = { in: ['COMPLETED', 'CLOSED'] };
      } else {
        where.status = norm;
      }
    }

    if (siteId) {
      where.siteId = siteId;
    }

    if (sourceType) {
      const st = sourceType.toUpperCase();
      if (st === 'COMPLAINT') {
        where.complaintId = { not: null };
      } else if (st === 'INSPECTION') {
        where.inspectionId = { not: null };
      }
    }

    const [total, cases] = await Promise.all([
      prisma.case.count({ where }),
      prisma.case.findMany({
        where,
        include: {
          site: true
        },
        orderBy: {
          createdAt: 'desc'
        },
        skip: offset,
        take: limit
      })
    ]);

    return successResponse(res, { 
      items: cases,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách vụ việc');
  } catch (error) {
    next(error);
  }
});

// POST /api/cases: create a new case manually
router.post('/', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { siteId, title, description, complaintId, inspectionId, sourceType, sourceId, slaDeadline } = req.body || {};
    if (!siteId) {
      return errorResponse(res, 'siteId là bắt buộc để khởi tạo vụ việc', 400);
    }
    if (!title) {
      return errorResponse(res, 'Tiêu đề (title) là bắt buộc', 400);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const newCase = await createCase({
      siteId,
      title,
      description,
      complaintId,
      inspectionId,
      sourceType,
      sourceId,
      actor
    });

    if (slaDeadline) {
      await prisma.case.update({
        where: { id: newCase.id },
        data: { slaDeadline: new Date(slaDeadline) }
      });
    }

    return successResponse(res, newCase, 'Khởi tạo vụ việc thành công', 201);
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// PUT & PATCH /api/cases/:id: update case details (title, description, status, slaDeadline)
const updateCaseHandler = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, description, status, slaDeadline, siteId, complaintId, inspectionId, assignedTo, priority, note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    // If status change is requested, transition status safely
    let updatedCase = caseItem;
    if (status && normalizeStatus(status) !== normalizeStatus(caseItem.status)) {
      updatedCase = await transitionCaseStatus(id, status, actor, { note: note || 'Cập nhật trạng thái qua API' });
    }

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (slaDeadline !== undefined) updateData.slaDeadline = slaDeadline ? new Date(slaDeadline) : null;
    if (assignedTo !== undefined) updateData.assignedTo = assignedTo;
    if (priority !== undefined) updateData.priority = priority;
    if (siteId !== undefined) updateData.siteId = siteId;
    if (complaintId !== undefined) updateData.complaintId = complaintId;
    if (inspectionId !== undefined) updateData.inspectionId = inspectionId;

    if (Object.keys(updateData).length > 0) {
      updatedCase = await prisma.case.update({
        where: { id },
        data: {
          ...updateData,
          updatedAt: new Date()
        },
        include: {
          site: true,
          timeline: { orderBy: { createdAt: 'desc' } }
        }
      });
    }

    return successResponse(res, updatedCase, 'Cập nhật thông tin vụ việc thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
};

router.put('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateCaseHandler);
router.patch('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateCaseHandler);

// GET /api/cases/:id/sla: get SLA deadlines and countdown
router.get('/:id/sla', requireAuth, async (req, res, next) => {
  try {
    const userRole = (req.user?.role || '').toLowerCase();
    if (userRole === 'citizen' || userRole === 'volunteer' || userRole === 'guest') {
      return errorResponse(res, 'Bạn không có quyền xem thông tin SLA vụ việc nội bộ.', 403);
    }

    const { id } = req.params;
    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: { timeline: true }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const deadlines = await calculateDeadlines(caseItem);
    const violations = await checkSlaViolations(caseItem);

    const now = Date.now();
    const currentStatus = normalizeStatus(caseItem.status);
    let activeDeadline = null;
    if (currentStatus === 'SCREENING') activeDeadline = deadlines.screeningDeadline;
    else if (currentStatus === 'PREPARING') activeDeadline = deadlines.preparingDeadline;
    else if (currentStatus === 'DECISION_ISSUED') activeDeadline = deadlines.decisionIssuedDeadline;
    else if (currentStatus === 'ON_SITE') activeDeadline = deadlines.onSiteDeadline;
    else if (currentStatus === 'REPORTING') activeDeadline = deadlines.reportingDeadline;
    else if (currentStatus === 'APPRAISING') activeDeadline = deadlines.appraisingDeadline;

    const remainingMs = activeDeadline ? (new Date(activeDeadline).getTime() - now) : null;
    const remainingHours = remainingMs !== null ? Math.round(remainingMs / (1000 * 60 * 60)) : null;

    return successResponse(res, {
      caseId: id,
      code: caseItem.code,
      status: currentStatus,
      activeDeadline,
      remainingHours,
      isOverdue: remainingMs !== null && remainingMs < 0,
      deadlines,
      violations: violations.violations,
      isViolated: violations.isViolated
    }, 'Thông tin hạn chót SLA và tiến trình xử lý');
  } catch (error) {
    next(error);
  }
});

// GET /api/cases/:id: retrieve a specific case including site, timeline, explanations, and decisions
router.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const userRole = (req.user?.role || '').toLowerCase();
    if (userRole === 'citizen' || userRole === 'volunteer' || userRole === 'guest') {
      return errorResponse(res, 'Bạn không có quyền xem chi tiết hồ sơ vụ việc nội bộ.', 403);
    }

    const { id } = req.params;

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        timeline: {
          orderBy: { createdAt: 'desc' }
        },
        contractorExplanations: {
          orderBy: { createdAt: 'desc' }
        },
        sanctionDecisions: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // Contractor scope: can only view their own sites' cases
    if (req.user.role === 'contractor') {
      if (!verifySiteContractor(caseItem.site, req.user)) {
        return errorResponse(res, 'Không tìm thấy vụ việc', 404);
      }
    }

    return successResponse(res, caseItem, 'Chi tiết vụ việc');
  } catch (error) {
    next(error);
  }
});

// POST /api/cases/:id/verify: let staff verify the case (advances status from PENDING to PREPARING)
router.post('/:id/verify', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // Call service to transition state
    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, 'PREPARING', actor, {
      note: note || 'Cán bộ xác minh và chuyển trạng thái vụ việc sang chuẩn bị thanh tra (PREPARING).'
    });

    return successResponse(res, updatedCase, 'Xác minh vụ việc thành công');
  } catch (error) {
    // If transition fails due to business rules, transitionCaseStatus throws an error
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/issue-decision: Ban hành quyết định thanh tra (nhận decisionNumber, inspectors, chuyển status sang DECISION_ISSUED)
router.post('/:id/issue-decision', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { decisionNumber, inspectors, note } = req.body || {};

    if (!decisionNumber) {
      return errorResponse(res, 'Số quyết định thanh tra là bắt buộc', 400);
    }

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const inspectorsStr = Array.isArray(inspectors) ? inspectors.join(', ') : (inspectors || 'Chưa rõ');

    // Create SanctionDecision record
    const decision = await prisma.sanctionDecision.create({
      data: {
        caseId: id,
        decisionNumber,
        status: 'PENDING',
        remedialMeasures: `Cán bộ tham gia: ${inspectorsStr}`
      }
    });

    const updatedCase = await transitionCaseStatus(id, 'DECISION_ISSUED', actor, {
      note: note || `Ban hành quyết định thanh tra số ${decisionNumber}. Các cán bộ tham gia: ${inspectorsStr}.`
    });

    return successResponse(res, { case: updatedCase, decision }, 'Ban hành quyết định thanh tra thành công');
  } catch (error) {
    if (error.code === 'P2002') {
      return errorResponse(res, 'Số quyết định này đã tồn tại trong hệ thống.', 409);
    }
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/go-on-site: Bắt đầu kiểm tra tại cơ sở (chuyển status sang ON_SITE)
router.post('/:id/go-on-site', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, 'ON_SITE', actor, {
      note: note || 'Đoàn kiểm tra bắt đầu kiểm tra thực tế tại cơ sở (ON_SITE).'
    });

    return successResponse(res, updatedCase, 'Bắt đầu kiểm tra tại cơ sở thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/reporting-draft: Lập báo cáo kết quả và dự thảo quyết định xử phạt (nhận penaltyAmount, remedialMeasures, chuyển status sang REPORTING)
router.post('/:id/reporting-draft', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { penaltyAmount, remedialMeasures, note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    if (penaltyAmount !== undefined && penaltyAmount !== null) {
      const num = Number(penaltyAmount);
      if (isNaN(num) || num < 0) {
        return errorResponse(res, 'Số tiền xử phạt không hợp lệ (phải là số không âm)', 400);
      }
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const existingDecision = await prisma.sanctionDecision.findFirst({
      where: { caseId: id },
      orderBy: { createdAt: 'desc' }
    });

    let decision = null;
    if (existingDecision) {
      decision = await prisma.sanctionDecision.update({
        where: { id: existingDecision.id },
        data: {
          penaltyAmount: penaltyAmount ? Number(penaltyAmount) : null,
          remedialMeasures: remedialMeasures || null
        }
      });
    }

    const updatedCase = await transitionCaseStatus(id, 'REPORTING', actor, {
      note: note || `Lập báo cáo kết quả và dự thảo quyết định xử phạt (REPORTING). Số tiền xử phạt đề xuất: ${penaltyAmount ? Number(penaltyAmount).toLocaleString('vi-VN') : 'Chưa rõ'} VNĐ.`
    });

    return successResponse(res, { case: updatedCase, decision }, 'Lập báo cáo kết quả và dự thảo quyết định xử phạt thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/escalate: Executive triggers urgent SLA escalation for overdue case or action
router.post('/:id/escalate', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason, hoursOverdue } = req.body || {};

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Lãnh đạo',
      role: req.user.role
    };

    let targetSiteId = null;
    let targetCode = id;
    let targetTitle = 'Vụ việc quá hạn SLA';
    const overdueDuration = hoursOverdue || 48;

    // 1. Try finding Case first
    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: { site: true }
    });

    if (caseItem) {
      targetSiteId = caseItem.siteId;
      targetCode = caseItem.code;
      targetTitle = caseItem.title;

      // Log SLA Escalation event to CaseTimeline
      await prisma.caseTimeline.create({
        data: {
          caseId: id,
          eventType: 'SLA_ESCALATION_HIGH',
          eventTitle: '⚡ Chỉ đạo Leo thang Hỏa tốc',
          eventDescription: reason || `Lãnh đạo (${actor.name}) đã phát lệnh chỉ đạo leo thang hỏa tốc cho vụ việc quá hạn SLA ${overdueDuration}h.`,
          actorId: req.user.id,
          actorName: actor.name,
          actorRole: actor.role
        }
      });

      // Send urgent warning notification to contractor
      await sendContractorNotification(id, 'SLA_ESCALATION_URGENT');
    } else {
      // 2. Check if it is an Action ID
      const actionItem = await prisma.action.findUnique({
        where: { id },
        include: { site: true }
      });

      if (actionItem) {
        targetSiteId = actionItem.siteId;
        targetTitle = actionItem.title;

        // Find associated active case to log timeline
        const relatedCase = await prisma.case.findFirst({
          where: { siteId: actionItem.siteId, deletedAt: null }
        });

        if (relatedCase) {
          await prisma.caseTimeline.create({
            data: {
              caseId: relatedCase.id,
              eventType: 'SLA_ESCALATION_HIGH',
              eventTitle: '⚡ Chỉ đạo Leo thang Hỏa tốc',
              eventDescription: reason || `Lãnh đạo (${actor.name}) chỉ đạo hỏa tốc đối với hành vi quá hạn: ${actionItem.title}`,
              actorId: req.user.id,
              actorName: actor.name,
              actorRole: actor.role
            }
          });
        }
      }
    }

    // 3. Write Audit Log entry
    await logAuditEvent({
      actorId: req.user.id,
      actorName: actor.name,
      actorRole: actor.role,
      action: 'EXEC_SLA_ESCALATED',
      targetId: id,
      details: {
        targetCode,
        title: targetTitle,
        siteId: targetSiteId,
        reason: reason || `Chỉ đạo Leo thang Hỏa tốc SLA quá hạn ${overdueDuration}h`,
        hoursOverdue: overdueDuration
      }
    });

    return successResponse(res, {
      id,
      escalated: true,
      timestamp: new Date()
    }, 'Đã phát lệnh chỉ đạo leo thang hỏa tốc và ghi nhật ký Audit Log thành công.');
  } catch (error) {
    next(error);
  }
});

// POST /api/cases/:id/appraise: Thẩm định hồ sơ (chuyển status sang APPRAISING)
router.post('/:id/appraise', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, 'APPRAISING', actor, {
      note: note || 'Tiến hành thẩm định hồ sơ vụ việc (APPRAISING).'
    });

    return successResponse(res, updatedCase, 'Thẩm định hồ sơ thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/assign: assign an inspector to the case
router.post('/:id/assign', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { inspectorId, assignee } = req.body || {};
    const targetInspectorId = inspectorId || assignee;

    if (!targetInspectorId) {
      return errorResponse(res, 'Vui lòng cung cấp mã cán bộ (inspectorId hoặc assignee)', 400);
    }

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // Retrieve inspector's name if they exist
    const inspector = await prisma.user.findUnique({
      where: { id: targetInspectorId },
      include: { profile: true }
    });

    const inspectorName = inspector?.fullName || inspector?.profile?.fullName || targetInspectorId;

    // Log case timeline event
    await logCaseEvent(
      id,
      'ASSIGNMENT',
      `Phân công cán bộ xử lý vụ việc: ${inspectorName}`,
      req
    );

    // Update related structures if linked
    if (caseItem.inspectionId) {
      await prisma.inspection.update({
        where: { id: caseItem.inspectionId },
        data: { inspectorId: targetInspectorId }
      });
    }

    if (caseItem.complaintId) {
      await prisma.complaint.update({
        where: { id: caseItem.complaintId },
        data: { assignedTo: targetInspectorId }
      });
    }

    // Let's reload case with timeline and site
    const updatedCase = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        timeline: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    return successResponse(res, updatedCase, `Đã phân công cán bộ ${inspectorName} xử lý vụ việc`);
  } catch (error) {
    next(error);
  }
});

// POST /api/cases/:id/request-explanation: request explanation from contractor (status -> EXPLAINING)
router.post('/:id/request-explanation', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, 'EXPLAINING', actor, {
      note: note || 'Yêu cầu nhà thầu nộp giải trình về hành vi vi phạm.'
    });

    return successResponse(res, updatedCase, 'Yêu cầu giải trình thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/explanations: contractor submits explanation
router.post('/:id/explanations', requireAuth, requireRoles('contractor', 'admin', 'staff', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { explanation, evidenceUrls } = req.body || {};

    if (!explanation) {
      return errorResponse(res, 'Nội dung giải trình là bắt buộc', 400);
    }

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: { site: true }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // Nghiệp vụ: Chỉ cho phép nộp giải trình khi vụ việc đang ở trạng thái ON_SITE (bao gồm EXPLAINING / VIOLATED)
    const normalizedStatus = normalizeStatus(caseItem.status);
    if (normalizedStatus !== 'ON_SITE') {
      return errorResponse(res, 'Hiện tại không ở bước tiếp nhận giải trình (chỉ tiếp nhận giải trình ở bước kiểm tra thực địa / yêu cầu giải trình).', 400);
    }

    // IDOR guard: contractor can only submit for their own sites
    if (req.user.role === 'contractor') {
      if (!verifySiteContractor(caseItem.site, req.user)) {
        return errorResponse(res, 'Không có quyền nộp giải trình cho vụ việc này', 403);
      }
    }

    const contractorExplanation = await prisma.contractorExplanation.create({
      data: {
        caseId: id,
        contractorId: req.user.id,
        explanation,
        evidenceUrls: evidenceUrls ? (typeof evidenceUrls === 'string' ? evidenceUrls : JSON.stringify(evidenceUrls)) : null,
        status: 'PENDING'
      }
    });

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Nhà thầu',
      role: req.user.role
    };

    // Log timeline event — case stays at EXPLAINING, awaiting staff review
    await prisma.caseTimeline.create({
      data: {
        caseId: id,
        eventType: 'EXPLANATION_SUBMITTED',
        eventTitle: 'Nhà thầu nộp giải trình',
        eventDescription: `Nhà thầu đã gửi giải trình: "${explanation.substring(0, 100)}${explanation.length > 100 ? '...' : ''}"`,
        actorId: req.user.id,
        actorName: actor.name,
        actorRole: actor.role
      }
    });

    return successResponse(res, { contractorExplanation }, 'Nộp giải trình thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/sanction: draft sanction decision (status -> SANCTIONED)
router.post('/:id/sanction', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { decisionNumber, penaltyAmount, remedialMeasures, documentUrl } = req.body || {};

    if (!decisionNumber) {
      return errorResponse(res, 'Số quyết định là bắt buộc', 400);
    }

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    if (penaltyAmount !== undefined && penaltyAmount !== null) {
      const num = Number(penaltyAmount);
      if (isNaN(num) || num < 0) {
        return errorResponse(res, 'Số tiền xử phạt không hợp lệ (phải là số không âm)', 400);
      }
    }

    const decision = await prisma.sanctionDecision.create({
      data: {
        caseId: id,
        decisionNumber,
        penaltyAmount: penaltyAmount ? Number(penaltyAmount) : null,
        remedialMeasures: remedialMeasures || null,
        documentUrl: documentUrl || null,
        status: 'PENDING'
      }
    });

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    // Automatically create a DraftDocument for the Executive signing queue
    await prisma.draftDocument.create({
      data: {
        siteId: caseItem.siteId,
        caseId: id,
        documentType: 'corrective_notice',
        title: `Quyết định xử phạt vi phạm hành chính số ${decisionNumber}`,
        content: `Căn cứ Nghị định 45/2022/NĐ-CP về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường.\n\nHành vi vi phạm: Phát tán ô nhiễm bụi mịn vượt quy chuẩn kỹ thuật.\nXử phạt đối với công trường: ${caseItem.title}\nSố tiền phạt đề xuất: ${(penaltyAmount != null && !isNaN(Number(penaltyAmount))) ? Number(penaltyAmount).toLocaleString('vi-VN') : 'Chưa xác định'} VNĐ\nBiện pháp khắc phục buộc áp dụng: ${remedialMeasures || 'Nêu cao lưới che chắn, dập bụi thường xuyên.'}`,
        status: 'DRAFT',
        metadata: JSON.stringify({
          officer: { name: actor.name },
          penaltyAmount,
          decisionNumber
        })
      }
    });

    const updatedCase = await transitionCaseStatus(id, 'SANCTIONED', actor, {
      note: `Lập dự thảo Quyết định xử phạt số ${decisionNumber}. Số tiền đề xuất: ${penaltyAmount?.toLocaleString('vi-VN')} VNĐ.`
    });

    return successResponse(res, { decision, case: updatedCase }, 'Lập dự thảo quyết định xử phạt thành công');
  } catch (error) {
    if (error.code === 'P2002') {
      return errorResponse(res, 'Số quyết định xử phạt này đã tồn tại trong hệ thống. Vui lòng dùng số khác.', 409);
    }
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/decisions/:decisionId/approve: executive signs/approves sanction decision (transitions case status to COMPLETED)
router.post('/:id/decisions/:decisionId/approve', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res, next) => {
  try {
    const { id, decisionId } = req.params;

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const decision = await prisma.sanctionDecision.findUnique({
      where: { id: decisionId }
    });

    if (!decision) {
      return errorResponse(res, 'Không tìm thấy quyết định xử phạt', 404);
    }

    if (decision.caseId !== id) {
      return errorResponse(res, 'Quyết định xử phạt không thuộc vụ việc này', 400);
    }

    const signatureInput = `${decision.decisionNumber}-${new Date().getTime()}-${req.user.id}`;
    const hash = createHash('sha256').update(signatureInput).digest('hex');

    const updatedDecision = await prisma.sanctionDecision.update({
      where: { id: decisionId },
      data: {
        status: 'SENT',
        issuedAt: new Date()
      }
    });

    await prisma.draftDocument.create({
      data: {
        siteId: caseItem.siteId,
        caseId: id,
        documentType: 'bien-ban-vphc',
        title: `Quyết định xử phạt chính thức ${decision.decisionNumber}`,
        content: `Đã ký số bởi Lãnh đạo cơ quan: ${req.user.fullName || req.user.name}\nChữ ký số SHA256: ${hash}`,
        status: 'SIGNED',
        hash,
        signedAt: new Date(),
        approvedById: req.user.id
      }
    });

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Lãnh đạo',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, 'COMPLETED', actor, {
      note: `Quyết định xử phạt số ${decision.decisionNumber} đã được phê duyệt và ký số bởi Lãnh đạo (${actor.name}). Hash: ${hash.substring(0, 16)}...`
    });

    return successResponse(res, { decision: updatedDecision, hash, case: updatedCase }, 'Phê duyệt và ký số quyết định xử phạt thành công');
  } catch (error) {
    next(error);
  }
});

// POST /api/cases/:id/rectify: contractor submits payment fine / rectification evidence
router.post('/:id/rectify', requireAuth, requireRoles('contractor', 'admin', 'staff', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { paymentEvidenceUrl, remedyEvidenceUrl, notes } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: { sanctionDecisions: { orderBy: { createdAt: 'desc' } }, site: true }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // IDOR guard: contractor can only rectify their own sites' cases
    if (req.user.role === 'contractor') {
      if (!verifySiteContractor(caseItem.site, req.user)) {
        return errorResponse(res, 'Không có quyền báo cáo khắc phục cho vụ việc này', 403);
      }
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Nhà thầu',
      role: req.user.role
    };

    const systemActor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Nhà thầu',
      role: 'system'
    };

    const updatedCase = await transitionCaseStatus(id, 'RECTIFYING', systemActor, {
      note: `Nhà thầu báo cáo đã nộp phạt và khắc phục hiện trường. Ghi chú: ${notes || ''}`
    });

    const activeDecision = caseItem.sanctionDecisions?.[0];
    if (activeDecision) {
      await prisma.sanctionDecision.update({
        where: { id: activeDecision.id },
        data: {
          status: 'PAID',
          documentUrl: paymentEvidenceUrl || activeDecision.documentUrl
        }
      });
    }

    await prisma.caseTimeline.create({
      data: {
        caseId: id,
        eventType: 'DOCUMENT_SUBMITTED',
        eventTitle: 'Nộp bằng chứng khắc phục',
        eventDescription: `Nhà thầu nộp tài liệu chứng minh. Minh chứng nộp phạt: ${paymentEvidenceUrl || 'Chưa đính kèm'}. Minh chứng thực địa: ${remedyEvidenceUrl || 'Chưa đính kèm'}.`,
        actorId: req.user.id,
        actorName: actor.name,
        actorRole: actor.role || 'contractor'
      }
    });

    return successResponse(res, updatedCase, 'Báo cáo khắc phục thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// GET /api/cases/:id/archive-package: export case dossier package as HTML download (staff/admin only)
router.get('/:id/archive-package', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        timeline: { orderBy: { createdAt: 'asc' } },
        contractorExplanations: { orderBy: { createdAt: 'desc' } },
        sanctionDecisions: { orderBy: { createdAt: 'desc' } },
        draftDocuments: { orderBy: { createdAt: 'asc' } }
      }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const cleanCode = caseItem.code.replace(/[^a-zA-Z0-9-]/g, '_');
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="Ho_so_vu_viec_${cleanCode}.html"`);

    const timelineHtml = caseItem.timeline.map(t => `
      <div class="timeline-item">
        <div class="timeline-time">${new Date(t.createdAt).toLocaleString('vi-VN')}</div>
        <div class="timeline-title">${escapeHtml(t.eventTitle)}</div>
        <div class="timeline-desc">${escapeHtml(t.eventDescription || '')}</div>
        <div class="timeline-desc" style="font-size: 11px; font-style: italic; color: #888;">Thực hiện bởi: ${escapeHtml(t.actorName || 'Hệ thống')} (${escapeHtml(t.actorRole || 'system')})</div>
      </div>
    `).join('');

    const explanationHtml = caseItem.contractorExplanations.map(e => {
      let imgSrc = null;
      if (e.evidenceUrls) {
        try {
          const parsed = JSON.parse(e.evidenceUrls);
          imgSrc = Array.isArray(parsed) ? parsed[0] : e.evidenceUrls;
        } catch {
          imgSrc = e.evidenceUrls;
        }
      }
      return `
      <div style="border: 1px solid #d1c7bd; padding: 15px; border-radius: 8px; margin-bottom: 15px; background: #fff;">
        <div style="font-size: 12px; color: #888; margin-bottom: 5px;">Gửi lúc: ${new Date(e.submittedAt).toLocaleString('vi-VN')} | Trạng thái duyệt: <strong>${escapeHtml(e.status)}</strong></div>
        <div style="font-size: 14px; font-weight: bold; color: #231b14; margin-bottom: 8px;">Nội dung giải trình của Nhà thầu:</div>
        <div style="font-size: 13px; color: #444; line-height: 1.5; white-space: pre-wrap; font-style: italic;">${escapeHtml(e.explanation)}</div>
        ${imgSrc ? `
          <div style="margin-top: 10px;">
            <span style="font-size: 12px; font-weight: bold; color: #0d6f64;">Ảnh minh chứng đính kèm:</span>
            <img class="evidence-img" src="${escapeHtml(imgSrc)}" alt="Minh chứng" />
          </div>
        ` : ''}
      </div>
      `;
    }).join('');

    const decisionsHtml = caseItem.sanctionDecisions.map(d => `
      <div style="border: 1px solid #9f241f; border-left: 4px solid #9f241f; padding: 15px; border-radius: 8px; margin-bottom: 15px; background: #fdf5f5;">
        <div style="font-size: 13px; font-weight: bold; color: #9f241f; margin-bottom: 10px;">Quyết định số: ${escapeHtml(d.decisionNumber)}</div>
        <div class="meta-item"><span class="meta-label">Số tiền xử phạt:</span> ${(d.penaltyAmount != null && !isNaN(Number(d.penaltyAmount))) ? Number(d.penaltyAmount).toLocaleString('vi-VN') : 'Chưa xác định'} VNĐ</div>
        <div class="meta-item"><span class="meta-label">Biện pháp khắc phục buộc áp dụng:</span> ${escapeHtml(d.remedialMeasures || 'Nêu cao lưới che chắn, dập bụi thường xuyên.')}</div>
        <div class="meta-item"><span class="meta-label">Trạng thái quyết định:</span> <strong>${escapeHtml(d.status)}</strong></div>
        <div class="meta-item"><span class="meta-label">Ngày ban hành:</span> ${d.issuedAt ? new Date(d.issuedAt).toLocaleDateString('vi-VN') : 'Chưa ban hành'}</div>
      </div>
    `).join('');

    const draftDocumentsHtml = caseItem.draftDocuments.map(d => {
      let meta = {};
      try {
        meta = d.metadata ? (typeof d.metadata === 'string' ? JSON.parse(d.metadata) : d.metadata) : {};
      } catch (err) {
        meta = {};
      }
      const officer = meta.officer || {};
      const approval = meta.approvalInfo || {};
      
      const statusLabel = d.status === 'SIGNED' ? 'Đã đóng dấu đỏ' : d.status === 'APPROVED' ? 'Đã ký số' : d.status === 'SUBMITTED' ? 'Chờ duyệt' : 'Bản nháp';
      
      return `
      <div style="border: 1px solid #d1c7bd; padding: 15px; border-radius: 8px; margin-bottom: 15px; background: #fff;">
        <div style="font-size: 13px; font-weight: bold; color: #0d6f64; margin-bottom: 8px;">
          ${escapeHtml(d.title || 'Văn bản nghiệp vụ')} (Loại: ${escapeHtml(d.documentType)})
        </div>
        <div class="meta-item"><span class="meta-label">Trạng thái:</span> <strong style="color: ${d.status === 'SIGNED' ? '#16a34a' : d.status === 'APPROVED' ? '#0d6f64' : '#eab308'};">${escapeHtml(statusLabel)}</strong></div>
        <div class="meta-item"><span class="meta-label">Người lập:</span> ${escapeHtml(officer.name || 'Cán bộ thụ lý')} (${escapeHtml(officer.title || 'Thanh tra viên')})</div>
        <div class="meta-item"><span class="meta-label">Ngày lập:</span> ${new Date(d.createdAt).toLocaleDateString('vi-VN')}</div>
        
        ${d.hash ? `
          <div style="margin-top: 10px; padding: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px;">
            <div style="font-size: 11px; font-weight: bold; color: #166534; display: flex; align-items: center; gap: 5px; margin-bottom: 4px;">
              🛡️ Xác thực Chữ ký số mã hóa (Nghị định 30/2020/NĐ-CP)
            </div>
            <div style="font-family: monospace; font-size: 10px; color: #166534; word-break: break-all;">
              Mã Hash SHA-256: ${escapeHtml(d.hash)}
            </div>
            <div style="font-size: 11px; color: #166534; margin-top: 3px;">
              Người ký ban hành: <strong>${escapeHtml(approval.approvedByName || 'Lãnh đạo cơ quan')}</strong> (${escapeHtml(approval.approvedByEmail || '')})
            </div>
            <div style="font-size: 11px; color: #166534;">
              Thời gian ký duyệt: ${d.signedAt ? new Date(d.signedAt).toLocaleString('vi-VN') : ''}
            </div>
          </div>
        ` : ''}

        ${d.signedUrl ? `
          <div style="margin-top: 10px; padding: 10px; background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px;">
            <span style="font-size: 11px; font-weight: bold; color: #b45309; display: block; margin-bottom: 4px;">📂 Bản quét tài liệu gốc có đóng con dấu đỏ:</span>
            <a href="${escapeHtml(d.signedUrl)}" target="_blank" style="font-size: 12px; color: #0d6f64; text-decoration: underline; font-weight: bold;">Tải về bản quét (PDF/Image)</a>
          </div>
        ` : ''}
      </div>
      `;
    }).join('');

    const htmlContent = `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Hồ sơ lưu trữ vụ việc - ${caseItem.code}</title>
  <style>
    body { font-family: 'Times New Roman', Times, serif; margin: 40px; color: #231b14; background-color: #FCFAF6; line-height: 1.6; }
    .container { max-width: 800px; margin: 0 auto; background: #FFF; padding: 40px; border: 1px solid #d1c7bd; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-radius: 8px; }
    .header-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    .header-table td { vertical-align: top; border: none; }
    .left-header { text-align: center; width: 45%; font-size: 13px; }
    .right-header { text-align: center; width: 55%; font-size: 13px; font-weight: bold; }
    .title { text-align: center; font-size: 22px; font-weight: bold; margin-top: 30px; margin-bottom: 8px; color: #9f241f; }
    .sub-title { text-align: center; font-size: 14px; font-style: italic; margin-bottom: 40px; }
    .section-title { font-size: 16px; font-weight: bold; border-bottom: 2px solid #0d6f64; color: #0d6f64; padding-bottom: 5px; margin-top: 30px; margin-bottom: 15px; text-transform: uppercase; }
    .meta-item { margin-bottom: 8px; font-size: 14px; }
    .meta-label { font-weight: bold; color: #555; display: inline-block; width: 180px; }
    .timeline-item { border-left: 2px solid #0d6f64; padding-left: 15px; margin-bottom: 15px; position: relative; }
    .timeline-item::before { content: ""; width: 8px; height: 8px; background-color: #9f241f; border-radius: 50%; position: absolute; left: -5px; top: 6px; }
    .timeline-time { font-size: 12px; color: #888; font-weight: bold; }
    .timeline-title { font-weight: bold; font-size: 14px; color: #231b14; }
    .timeline-desc { font-size: 13px; color: #555; margin-top: 3px; }
    .evidence-img { max-width: 100%; max-height: 250px; border: 1px solid #d1c7bd; margin-top: 10px; display: block; border-radius: 6px; }
    .footer-sig { width: 100%; margin-top: 60px; text-align: center; font-size: 14px; }
    .footer-sig td { width: 50%; }
    .sig-box { height: 100px; }
  </style>
</head>
<body>
  <div class="container">
    <table class="header-table">
      <tr>
        <td class="left-header">
          <div>ỦY BAN NHÂN DÂN PHƯỜNG TRUNG HÒA</div>
          <div style="font-weight: bold; text-decoration: underline;">ĐOÀN KIỂM TRA LIÊN NGÀNH</div>
        </td>
        <td class="right-header">
          <div>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div>
          <div style="text-decoration: underline;">Độc lập - Tự do - Hạnh phúc</div>
          <div style="font-weight: normal; font-style: italic; margin-top: 10px;">Hà Nội, ngày ${new Date(caseItem.createdAt).toLocaleDateString('vi-VN')}</div>
        </td>
      </tr>
    </table>

    <div class="title">HỒ SƠ TỔNG HỢP VỤ VIỆC VI PHẠM</div>
    <div class="sub-title">(Mã số lưu trữ: ${escapeHtml(caseItem.code)})</div>

    <div class="section-title">I. Thông tin chung về vụ việc</div>
    <div class="meta-item"><span class="meta-label">Mã vụ việc:</span> ${escapeHtml(caseItem.id)}</div>
    <div class="meta-item"><span class="meta-label">Tiêu đề vụ việc:</span> ${escapeHtml(caseItem.title)}</div>
    <div class="meta-item"><span class="meta-label">Trạng thái hồ sơ:</span> <strong>${escapeHtml(caseItem.status)}</strong></div>
    <div class="meta-item"><span class="meta-label">Công trình vi phạm:</span> ${escapeHtml(caseItem.site.name)}</div>
    <div class="meta-item"><span class="meta-label">Địa chỉ thi công:</span> ${escapeHtml(caseItem.site.address)}, Phường ${escapeHtml(caseItem.site.ward)}</div>
    <div class="meta-item"><span class="meta-label">Nhà thầu phụ trách:</span> ${escapeHtml(caseItem.site.contractorName || 'Chưa xác định')}</div>
    <div class="meta-item"><span class="meta-label">Chi tiết vi phạm:</span> ${escapeHtml(caseItem.description || 'Chưa có mô tả chi tiết')}</div>
    <div class="meta-item"><span class="meta-label">Thời gian phát hiện:</span> ${new Date(caseItem.createdAt).toLocaleString('vi-VN')}</div>

    <div class="section-title">II. Lịch sử tiến trình xử lý (Timeline)</div>
    <div style="margin-top: 15px;">
      ${timelineHtml || '<div style="font-size: 13px; font-style: italic; color: #888;">Chưa ghi nhận timeline vụ việc.</div>'}
    </div>

    <div class="section-title">III. Giải trình từ Nhà thầu</div>
    <div style="margin-top: 15px;">
      ${explanationHtml || '<div style="font-size: 13px; font-style: italic; color: #888;">Không ghi nhận giải trình từ nhà thầu trong vụ việc này.</div>'}
    </div>

    <div class="section-title">IV. Quyết định xử phạt & Khắc phục</div>
    <div style="margin-top: 15px;">
      ${decisionsHtml || '<div style="font-size: 13px; font-style: italic; color: #888;">Chưa ban hành quyết định xử phạt hành chính đối với vụ việc này.</div>'}
    </div>

    <div class="section-title">V. Danh mục văn bản pháp lý & Chữ ký số</div>
    <div style="margin-top: 15px;">
      ${draftDocumentsHtml || '<div style="font-size: 13px; font-style: italic; color: #888;">Chưa có văn bản pháp lý nào được lập cho vụ việc này.</div>'}
    </div>

    <table class="footer-sig">
      <tr>
        <td>
          <div style="font-weight: bold; text-transform: uppercase;">Đại diện Nhà thầu</div>
          <div style="font-style: italic; font-size: 12px;">(Ký, ghi rõ họ tên)</div>
          <div class="sig-box"></div>
        </td>
        <td>
          <div style="font-weight: bold; text-transform: uppercase;">Trưởng đoàn kiểm tra</div>
          <div style="font-style: italic; font-size: 12px;">(Ký, ghi rõ họ tên và đóng dấu)</div>
          <div class="sig-box"></div>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>`;

    return res.send(htmlContent);
  } catch (error) {
    next(error);
  }
});


// POST /api/cases/:id/approve-proof: executive/staff approves contractor remedy proof
router.post('/:id/approve-proof', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        contractorExplanations: { orderBy: { createdAt: 'desc' } }
      }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Lãnh đạo',
      role: req.user.role
    };

    // Update latest contractor explanation if exists
    const latestExplanation = caseItem.contractorExplanations[0];
    if (latestExplanation) {
      await prisma.contractorExplanation.update({
        where: { id: latestExplanation.id },
        data: { status: 'APPROVED' }
      });
    }

    await prisma.caseTimeline.create({
      data: {
        caseId: id,
        eventType: 'PROOF_APPROVED',
        eventTitle: 'Phê duyệt minh chứng khắc phục',
        eventDescription: `Lãnh đạo/Cán bộ (${actor.name}) đã phê duyệt minh chứng khắc phục của nhà thầu. Ghi chú: ${note || 'Đạt tiêu chuẩn hiện trường'}.`,
        actorId: req.user.id,
        actorName: actor.name,
        actorRole: actor.role
      }
    });

    return successResponse(res, { caseId: id, status: 'APPROVED' }, 'Phê duyệt minh chứng khắc phục thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/reject-proof: executive/staff rejects contractor remedy proof
router.post('/:id/reject-proof', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason, note } = req.body || {};

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        contractorExplanations: { orderBy: { createdAt: 'desc' } }
      }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const rejectNote = reason || note || 'Yêu cầu nhà thầu cập nhật lại bằng chứng khắc phục mới.';

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Lãnh đạo',
      role: req.user.role
    };

    // Update latest contractor explanation status if exists
    const latestExplanation = caseItem.contractorExplanations[0];
    if (latestExplanation) {
      await prisma.contractorExplanation.update({
        where: { id: latestExplanation.id },
        data: { status: 'REJECTED' }
      });
    }

    // Log event in case timeline
    await prisma.caseTimeline.create({
      data: {
        caseId: id,
        eventType: 'PROOF_REJECTED',
        eventTitle: 'Từ chối minh chứng khắc phục',
        eventDescription: `Lãnh đạo/Cán bộ (${actor.name}) đã từ chối minh chứng khắc phục. Lý do: ${rejectNote}.`,
        actorId: req.user.id,
        actorName: actor.name,
        actorRole: actor.role
      }
    });

    return successResponse(res, { caseId: id, status: 'REJECTED', reason: rejectNote }, 'Từ chối minh chứng khắc phục thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/transition-status: transition case status to any valid 7-step status (staff/admin only)
router.post('/:id/transition-status', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, note } = req.body || {};

    if (!status) {
      return errorResponse(res, 'Trạng thái mới (status) là bắt buộc', 400);
    }

    const caseItem = await prisma.case.findFirst({
      where: { id, deletedAt: null }
    });

    if (!caseItem) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    const updatedCase = await transitionCaseStatus(id, status, actor, {
      note: note || `Cán bộ chuyển trạng thái vụ việc sang ${status}.`
    });

    return successResponse(res, updatedCase, `Chuyển trạng thái vụ việc sang ${status} thành công`);
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// POST /api/cases/:id/complete: staff/executive archives/completes case
router.post('/:id/complete', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body || {};

    const caseObj = await prisma.case.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: true,
        sanctionDecisions: { orderBy: { createdAt: 'desc' } },
        draftDocuments: { orderBy: { createdAt: 'desc' } }
      }
    });

    if (!caseObj) {
      return errorResponse(res, 'Không tìm thấy vụ việc', 404);
    }

    // Nghiệp vụ pháp chế: Kiểm tra thẩm quyền và trạng thái văn bản trước khi đóng vụ việc
    if (req.user.role === 'staff') {
      // 1. Kiểm tra nếu có quyết định xử phạt đang ở dạng dự thảo hoặc chờ duyệt (chưa ký ban hành)
      const unapprovedSancDoc = caseObj.draftDocuments.find(
        d => (d.documentType === 'quyet-dinh-xu-phat' || d.documentType === 'corrective_notice') &&
             d.status !== 'APPROVED' && d.status !== 'SIGNED'
      );
      if (unapprovedSancDoc) {
        return errorResponse(
          res, 
          `Không thể đóng vụ việc do Quyết định xử phạt / Thông báo yêu cầu khắc phục (${unapprovedSancDoc.title}) chưa được Lãnh đạo phê duyệt ban hành.`, 
          400
        );
      }

      // 2. Kiểm tra nếu có Quyết định xử phạt mà chưa nộp phạt
      const pendingFine = caseObj.sanctionDecisions.find(
        d => d.penaltyAmount > 0 && d.status !== 'PAID' && d.status !== 'COMPLETED'
      );
      if (pendingFine) {
        return errorResponse(
          res, 
          `Không thể đóng vụ việc do Nhà thầu chưa hoàn thành nghĩa vụ nộp phạt đối với Quyết định xử phạt số ${pendingFine.decisionNumber}.`, 
          400
        );
      }
    }

    const actor = {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ',
      role: req.user.role
    };

    let noteText = note;
    if (req.user.role === 'executive') {
      const signatureInput = `${id}-${new Date().getTime()}-${req.user.id}`;
      const hash = createHash('sha256').update(signatureInput).digest('hex');
      noteText = note || `Lãnh đạo phê duyệt thẩm định và ký số ban hành kết quả xử lý công khai. Hash băm SHA256: ${hash.substring(0, 16)}...`;
      if (caseObj) {
        await prisma.draftDocument.create({
          data: {
            siteId: caseObj.siteId,
            caseId: id,
            documentType: 'corrective_notice',
            title: `Quyết định ban hành kết quả xử lý công khai vụ việc ${caseObj.code}`,
            content: `Căn cứ kết quả thẩm định vụ việc vi phạm trật tự xây dựng, vệ sinh môi trường đô thị.\n\nĐã ký số ban hành bởi Lãnh đạo cơ quan: ${actor.name}\nChữ ký số SHA256: ${hash}`,
            status: 'SIGNED',
            hash,
            signedAt: new Date(),
            approvedById: req.user.id
          }
        });
      }
    }

    const updatedCase = await transitionCaseStatus(id, 'COMPLETED', actor, {
      note: noteText || 'Cán bộ xác nhận công trường đã khắc phục hoàn toàn vi phạm, hồ sơ vụ việc chính thức được lưu trữ.'
    });

    return successResponse(res, updatedCase, 'Đóng vụ việc thành công');
  } catch (error) {
    return errorResponse(res, error.message, 400);
  }
});

// DELETE /api/cases/:id — Delete/Archive case (Soft delete)
router.delete('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.case.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy hồ sơ vụ việc để xóa.', 404);
    }

    await prisma.case.update({
      where: { id: existing.id },
      data: {
        deletedAt: new Date(),
        status: 'CLOSED'
      }
    });

    await logCaseEvent(existing.id, 'CASE_DELETED', 'Xóa hồ sơ vụ việc', `Hồ sơ vụ việc ${existing.code} đã được xóa/lưu trữ bởi ${req.user.fullName || req.user.name || 'Quản trị viên'}.`, {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Quản trị viên',
      role: req.user.role
    });

    return successResponse(res, { id: existing.id, code: existing.code, deleted: true }, 'Xóa hồ sơ vụ việc thành công');
  } catch (error) {
    next(error);
  }
});

export default router;
