import { Router } from 'express';
import Database from 'better-sqlite3';
import path from 'path';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();
const dbPath = path.resolve(process.cwd(), 'app/prisma/dev.db');
let db;
try {
  db = new Database(dbPath);
} catch (e) {
  try {
    db = new Database(path.resolve(process.cwd(), 'prisma/dev.db'));
  } catch (err) {
    console.error('Cannot connect to dev.db in staff-settings:', err);
  }
}

// Ensure settings table exists
if (db) {
  try {
    db.prepare(`
      CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();
  } catch (e) {}
}

/**
 * 1. GET /api/staff/settings
 * Returns persisted settings from D1
 */
router.get('/', (req, res, next) => {
  try {
    const rows = db?.prepare('SELECT key, value FROM system_settings').all() || [];
    const settingsMap = {};
    rows.forEach(r => {
      try {
        settingsMap[r.key] = JSON.parse(r.value);
      } catch {
        settingsMap[r.key] = r.value;
      }
    });

    const defaultSettings = {
      emailAlerts: true,
      browserNotifications: true,
      urgentSms: false,
      autoRefresh: true,
      pm25Threshold: 50,
      pm10Threshold: 100,
      slaHours: 48,
      contactEmail: 'thanh-tra.moitruong@gov.vn',
      ...settingsMap
    };

    return successResponse(res, defaultSettings, 'Cài đặt hệ thống');
  } catch (error) {
    next(error);
  }
});

/**
 * 2. PATCH /api/staff/settings
 * Updates settings in D1
 */
router.patch('/', (req, res, next) => {
  try {
    const updates = req.body || {};
    const now = new Date().toISOString();

    const insertOrUpdate = db?.prepare(`
      INSERT INTO system_settings (key, value, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `);

    if (db && insertOrUpdate) {
      const transaction = db.transaction((entries) => {
        for (const [key, value] of Object.entries(entries)) {
          insertOrUpdate.run(key, JSON.stringify(value), now);
        }
      });
      transaction(updates);
    }

    return successResponse(res, updates, 'Cập nhật cài đặt thành công');
  } catch (error) {
    next(error);
  }
});

export default router;
