// app/server/routes/api/tasks.js
// Express API Router for DustGuard Tasks & Field Actions SSOT

import { Router } from 'express';
import {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  archiveTask,
  joinTask,
  startTask,
  submitTaskProof,
  approveSubmission,
  requestRevision,
  getTaskCounters
} from '../../repositories/task.repository.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();

/**
 * GET /api/tasks/counters
 * Trả về 4 chỉ số counters cho header dashboard
 */
router.get('/counters', async (req, res) => {
  try {
    const data = await getTaskCounters(req.db);
    return successResponse(res, data, 'Lấy thống kê nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * GET /api/tasks
 * Danh sách nhiệm vụ hỗ trợ tìm kiếm và phân loại
 */
router.get('/', async (req, res) => {
  try {
    const {
      status,
      task_type,
      assignment_type,
      campaign_id,
      case_id,
      site_id,
      club_id,
      assigned_profile_id,
      search,
      include_archived,
      limit,
      offset
    } = req.query;

    const current_user_id = req.user?.id || req.headers['x-user-id'] || null;
    const current_profile_id = req.user?.profileId || req.user?.id || req.headers['x-profile-id'] || null;

    const items = await getTasks(req.db, {
      status,
      task_type,
      assignment_type,
      campaign_id,
      case_id,
      site_id,
      club_id,
      assigned_profile_id,
      current_user_id,
      current_profile_id,
      search,
      include_archived: include_archived === 'true',
      limit: limit ? Number(limit) : 50,
      offset: offset ? Number(offset) : 0
    });

    return successResponse(res, items, 'Lấy danh sách nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * GET /api/tasks/:id
 * Chi tiết một nhiệm vụ
 */
router.get('/:id', async (req, res) => {
  try {
    const current_user_id = req.user?.id || req.headers['x-user-id'] || null;
    const task = await getTaskById(req.db, req.params.id, current_user_id);
    if (!task) return errorResponse(res, 'Nhiệm vụ không tồn tại', 404);

    return successResponse(res, task, 'Lấy chi tiết nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * POST /api/tasks
 * Tạo nhiệm vụ mới (Staff / Admin)
 */
router.post('/', async (req, res) => {
  try {
    const actor = {
      id: req.user?.id || 'staff_system',
      email: req.user?.email || 'staff@dustguard.vn',
      name: req.user?.name || req.user?.fullName || 'Cán bộ điều phối',
      role: req.user?.role || 'staff'
    };

    const task = await createTask(req.db, req.body, actor);
    return successResponse(res, task, 'Tạo nhiệm vụ thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * PATCH /api/tasks/:id
 * Cập nhật nhiệm vụ (Staff / Admin)
 */
router.patch('/:id', async (req, res) => {
  try {
    const actor = {
      id: req.user?.id || 'staff_system',
      email: req.user?.email || 'staff@dustguard.vn',
      name: req.user?.name || req.user?.fullName || 'Cán bộ điều phối',
      role: req.user?.role || 'staff'
    };

    const task = await updateTask(req.db, req.params.id, req.body, actor);
    return successResponse(res, task, 'Cập nhật nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

router.put('/:id', async (req, res) => {
  try {
    const actor = {
      id: req.user?.id || 'staff_system',
      email: req.user?.email || 'staff@dustguard.vn',
      name: req.user?.name || req.user?.fullName || 'Cán bộ điều phối',
      role: req.user?.role || 'staff'
    };

    const task = await updateTask(req.db, req.params.id, req.body, actor);
    return successResponse(res, task, 'Cập nhật nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/tasks/:id/archive
 * Lưu trữ nhiệm vụ
 */
router.post('/:id/archive', async (req, res) => {
  try {
    const actor = {
      id: req.user?.id || 'staff_system',
      email: req.user?.email || 'staff@dustguard.vn',
      role: req.user?.role || 'staff'
    };

    const result = await archiveTask(req.db, req.params.id, actor);
    return successResponse(res, result, 'Lưu trữ nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/tasks/:id/join
 * User nhận việc
 */
router.post('/:id/join', async (req, res) => {
  try {
    const user_id = req.user?.id || req.body.user_id || req.headers['x-user-id'] || 'user_1';
    const profile_id = req.user?.profileId || req.body.profile_id || user_id;
    const club_id = req.body.club_id || req.user?.club_id || null;
    const full_name = req.body.full_name || req.user?.fullName || req.user?.name || 'Tình nguyện viên';

    const result = await joinTask(req.db, req.params.id, {
      user_id,
      profile_id,
      club_id,
      full_name
    });

    return successResponse(res, result, 'Nhận nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/tasks/:id/start
 * User bắt đầu làm việc
 */
router.post('/:id/start', async (req, res) => {
  try {
    const user_id = req.user?.id || req.body.user_id || req.headers['x-user-id'] || 'user_1';
    const profile_id = req.user?.profileId || req.body.profile_id || user_id;

    const result = await startTask(req.db, req.params.id, { user_id, profile_id });
    return successResponse(res, result, 'Bắt đầu nhiệm vụ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/tasks/:id/submit
 * User nộp kết quả / minh chứng thực địa
 */
router.post('/:id/submit', async (req, res) => {
  try {
    const user_id = req.user?.id || req.body.user_id || req.headers['x-user-id'] || 'user_1';
    const profile_id = req.user?.profileId || req.body.profile_id || user_id;
    const { image_url, image_hash, outcome, notes, latitude, longitude } = req.body;

    const result = await submitTaskProof(req.db, req.params.id, {
      user_id,
      profile_id,
      image_url,
      image_hash,
      outcome,
      notes,
      latitude,
      longitude
    });

    return successResponse(res, result, 'Nộp minh chứng thành công, hồ sơ chuyển sang Chờ xác minh');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/task-submissions/:id/approve
 * Staff duyệt nghiệm thu minh chứng và tự động cộng điểm / giờ thật vào DB
 */
router.post('/submissions/:subId/approve', async (req, res) => {
  try {
    const reviewer_id = req.user?.id || 'staff_system';
    const reviewer_name = req.user?.fullName || req.user?.name || 'Cán bộ nghiệm thu';
    const { review_note } = req.body;

    const result = await approveSubmission(req.db, req.params.subId, {
      reviewer_id,
      reviewer_name,
      review_note
    });

    return successResponse(res, result, 'Đã duyệt nghiệm thu và ghi nhận đóng góp thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * POST /api/task-submissions/:id/request-revision
 * Staff yêu cầu bổ sung / làm lại minh chứng
 */
router.post('/submissions/:subId/request-revision', async (req, res) => {
  try {
    const reviewer_id = req.user?.id || 'staff_system';
    const reviewer_name = req.user?.fullName || req.user?.name || 'Cán bộ thẩm định';
    const { review_note } = req.body;

    const result = await requestRevision(req.db, req.params.subId, {
      reviewer_id,
      reviewer_name,
      review_note
    });

    return successResponse(res, result, 'Đã gửi yêu cầu làm lại minh chứng');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

export default router;
