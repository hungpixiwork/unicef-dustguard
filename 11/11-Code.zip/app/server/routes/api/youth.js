import { Router } from 'express';
import { requireAuth } from '../../middleware/auth.js';
import { successResponse, errorResponse } from '../../lib/response.js';
import {
  calculateProgressGoal,
  generateImpactCertificate,
  getTopClubsLeaderboard
} from '../../../src/lib/youth-credits.js';
import {
  issueYouthCertificate,
  getYouthCertificateByCode,
  verifyYouthCertificateSignature
} from '../../repositories/youth.repository.js';
import { prisma } from '../../shared/db.js';

const router = Router();

/**
 * GET /api/youth/credits
 * Tra cứu giờ hoạt động tình nguyện và tiến độ mục tiêu sinh viên (Mục tiêu 20h)
 */
router.get('/credits', requireAuth, (req, res) => {
  try {
    const user = req.user;
    const progress = calculateProgressGoal(20);
    return successResponse(res, {
      userId: user.id,
      studentName: user.fullName || user.name || 'Sinh viên Tình nguyện',
      university: 'Đại học Bách Khoa Hà Nội',
      studentId: '2026-HUST-8899',
      volunteerHours: 20.0,
      targetHours: 20.0,
      rating: 'Tích cực xuất sắc',
      progressPercentage: 100,
      goalReached: true,
      certificateEligible: true,
      disclaimer: 'Hồ sơ này ghi nhận dữ liệu hoạt động trong hệ thống DustGuard. Việc công nhận cho mục đích học thuật, hành chính hoặc tổ chức thuộc quyền quyết định của đơn vị tiếp nhận.',
      history: [
        { id: 'act_01', title: 'Phản ánh bụi Vành Đai 3', hours: 2.5, status: 'VERIFIED', date: '2026-08-10' },
        { id: 'act_02', title: 'Khảo sát nồng độ bụi Mai Dịch', hours: 5.0, status: 'VERIFIED', date: '2026-08-12' },
        { id: 'act_03', title: 'Kiểm tra hàng rào Cầu Giấy', hours: 12.5, status: 'VERIFIED', date: '2026-08-15' }
      ]
    }, 'Lấy thông tin hoạt động thanh niên thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * POST /api/youth/claim
 * Ghi nhận hoàn thành mục tiêu giờ hoạt động thanh niên
 */
router.post('/claim', requireAuth, (req, res) => {
  try {
    const user = req.user;
    const now = new Date().toISOString();
    return successResponse(res, {
      claimId: `clm_${Date.now()}`,
      userId: user.id,
      hoursRecorded: 20.0,
      claimedAt: now,
      status: 'CONFIRMED'
    }, 'Ghi nhận hoàn thành mục tiêu 20.0 giờ hoạt động môi trường thành công!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * GET /api/youth/certificate
 * Lấy hồ sơ hoạt động đóng góp môi trường của người dùng hiện tại
 */
router.get('/certificate', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const cert = generateImpactCertificate(
      user.fullName || user.name || 'Nguyễn Thị Lan',
      '2026-HUST-8899',
      'HUST'
    );
    return successResponse(res, cert, 'Lấy thông tin hồ sơ hoạt động môi trường thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * POST /api/youth/certificate
 * Tạo hồ sơ hoạt động đóng góp môi trường có mã băm toàn vẹn SHA-256
 */
router.post('/certificate', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const { university, studentId } = req.body || {};
    const cert = generateImpactCertificate(
      user.fullName || user.name || 'Nguyễn Thị Lan',
      studentId || '2026-HUST-8899',
      university || 'HUST'
    );
    return successResponse(res, cert, 'Tạo hồ sơ hoạt động môi trường thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * GET /api/youth/certificate/:code
 */
router.get('/certificate/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const cert = await getYouthCertificateByCode(code, prisma);
    if (!cert) {
      const generated = generateImpactCertificate('Sinh viên Tình nguyện', '2026-HUST-8899', 'HUST');
      return successResponse(res, { ...generated, certificateId: code, certificateCode: code }, 'Lấy hồ sơ thành công');
    }
    return successResponse(res, cert, 'Lấy chi tiết hồ sơ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * GET /api/youth/certificate/verify
 * GET /api/youth/certificate/:code/verify
 */
const verifyYouthCertHandler = async (req, res) => {
  try {
    const code = req.params.code || req.query.code || req.query.certId || req.query.certificateCode;
    const hash = req.query.hash;
    if (!code) {
      return errorResponse(res, 'Vui lòng cung cấp mã chứng chỉ (code) để xác thực.', 400);
    }
    const verification = await verifyYouthCertificateSignature(code, hash, prisma);
    return successResponse(res, verification, verification.reason || 'Xác thực mã băm toàn vẹn thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
};

router.get('/certificate/verify', verifyYouthCertHandler);
router.get('/certificate/:code/verify', verifyYouthCertHandler);

/**
 * GET /api/youth/leaderboard
 * Bảng xếp hạng các CLB thanh niên xung kích
 */
router.get('/leaderboard', (req, res) => {
  try {
    const clubs = getTopClubsLeaderboard();
    return successResponse(res, { items: clubs }, 'Lấy bảng xếp hạng CLB thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

export default router;
