import { Router } from 'express';
import Database from 'better-sqlite3';
import path from 'path';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();
const dbPath = path.resolve(process.cwd(), 'app/prisma/dev.db');
let db;
try {
  db = new Database(dbPath);
} catch (e) {
  try {
    db = new Database(path.resolve(process.cwd(), 'prisma/dev.db'));
  } catch (err) {
    console.error('Cannot connect to dev.db in staff-notifications:', err);
  }
}

/**
 * 1. GET /api/staff/notifications/summary
 * Returns 4 KPI metrics from D1 SQLite
 */
router.get('/summary', (req, res, next) => {
  try {
    const unreadRow = db?.prepare('SELECT COUNT(*) as count FROM notifications WHERE is_read = 0 AND is_muted = 0').get();
    const todayRow = db?.prepare("SELECT COUNT(*) as count FROM notifications WHERE is_muted = 0 AND date(created_at) = date('now')").get();
    const nearRow = db?.prepare("SELECT COUNT(*) as count FROM cases WHERE deletedAt IS NULL AND status != 'CLOSED' AND deadline > datetime('now') AND deadline <= datetime('now', '+3 days')").get();
    const urgentRow = db?.prepare("SELECT COUNT(*) as count FROM notifications WHERE (priority = 'urgent' OR type = 'ALERT') AND is_muted = 0").get();

    return successResponse(res, {
      unreadCount: unreadRow?.count ?? 0,
      todayCount: todayRow?.count ?? 0,
      nearDeadlineCount: nearRow?.count ?? 0,
      urgentCount: urgentRow?.count ?? 0
    }, 'Thống kê thông báo');
  } catch (error) {
    next(error);
  }
});

/**
 * 2. GET /api/staff/notifications/list
 * Returns notifications from D1 dev.db
 */
router.get('/list', (req, res, next) => {
  try {
    const { tab = 'ALL', search = '' } = req.query;

    let query = `SELECT * FROM notifications WHERE is_muted = 0`;
    const params = [];

    if (search) {
      query += ` AND (title LIKE ? OR message LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }

    if (tab === 'UNREAD') query += ` AND is_read = 0`;
    else if (tab === 'URGENT') query += ` AND (priority = 'urgent' OR type = 'ALERT')`;
    else if (tab === 'SYSTEM') query += ` AND type = 'SYSTEM'`;
    else if (tab === 'CASE') query += ` AND type LIKE 'CASE%'`;

    query += ` ORDER BY created_at DESC LIMIT 50`;

    const items = db?.prepare(query).all(...params) || [];

    const formatted = items.map(n => {
      let icon = '🔔';
      let tagLabel = 'Hồ sơ';
      if (n.type === 'ALERT') { icon = '🚨'; tagLabel = 'Cảnh báo'; }
      else if (n.type === 'CONTRACTOR_EVIDENCE') { icon = '📷'; tagLabel = 'Minh chứng'; }
      else if (n.type === 'REPORT_READY') { icon = '📊'; tagLabel = 'Báo cáo'; }
      else if (n.type === 'SYSTEM') { icon = '⚙️'; tagLabel = 'Hệ thống'; }

      return {
        id: n.id,
        type: n.type,
        icon,
        title: n.title,
        message: n.message,
        tagLabel,
        isRead: Boolean(n.is_read),
        priority: n.priority,
        createdAt: n.created_at ? new Date(n.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + ' ' + new Date(n.created_at).toLocaleDateString('vi-VN') : 'Vừa xong'
      };
    });

    return successResponse(res, { items: formatted }, 'Danh sách thông báo');
  } catch (error) {
    next(error);
  }
});

/**
 * 3. GET /api/staff/notifications/urgent
 * Returns urgent events from D1 SQLite
 */
router.get('/urgent', (req, res, next) => {
  try {
    const items = db?.prepare(`
      SELECT id, title, message as desc, created_at, type
      FROM notifications
      WHERE is_muted = 0 AND (priority = 'urgent' OR type = 'ALERT')
      ORDER BY created_at DESC
      LIMIT 5
    `).all() || [];

    const urgentItems = items.map(u => ({
      id: u.id,
      title: u.title,
      desc: u.desc,
      time: u.created_at ? new Date(u.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '09:00',
      type: u.type
    }));

    return successResponse(res, { items: urgentItems }, 'Việc cần chú ý khẩn');
  } catch (error) {
    next(error);
  }
});

/**
 * 4. POST /api/staff/notifications/:id/read
 * Marks single notification as read
 */
router.post('/:id/read', (req, res, next) => {
  try {
    const { id } = req.params;
    db?.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(id);
    return successResponse(res, null, 'Đã đánh dấu đã đọc');
  } catch (error) {
    next(error);
  }
});

/**
 * 5. POST /api/staff/notifications/mark-all-read
 * Marks all active notifications as read
 */
router.post('/mark-all-read', (req, res, next) => {
  try {
    db?.prepare('UPDATE notifications SET is_read = 1 WHERE is_muted = 0').run();
    return successResponse(res, null, 'Đã đánh dấu tất cả là đã đọc');
  } catch (error) {
    next(error);
  }
});

/**
 * 6. POST /api/staff/notifications/:id/mute
 * Mutes a notification
 */
router.post('/:id/mute', (req, res, next) => {
  try {
    const { id } = req.params;
    db?.prepare('UPDATE notifications SET is_muted = 1 WHERE id = ?').run(id);
    return successResponse(res, null, 'Đã ẩn thông báo');
  } catch (error) {
    next(error);
  }
});

export default router;
