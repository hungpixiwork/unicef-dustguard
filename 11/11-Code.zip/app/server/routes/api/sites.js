import { Router } from 'express';
import {
  getSites,
  getSiteById,
  createSite,
  updateSite,
  deleteSite,
  getSiteSensors,
  getSiteReadings,
  assignInspector,
  getSiteRiskAnalysis,
  getSitePriorityHistory
} from '../../controllers/site.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';

const router = Router();

// Allow authenticated user to view sites and their sensor data & risk analysis
router.get('/', requireAuth, getSites);
router.get('/:id', requireAuth, getSiteById);
router.get('/:id/sensors', requireAuth, getSiteSensors);
router.get('/:id/readings', requireAuth, getSiteReadings);
router.get('/:id/risk-analysis', requireAuth, getSiteRiskAnalysis);
router.get('/:id/priority-history', requireAuth, getSitePriorityHistory);

// Require admin, staff, or demo_admin role to modify or assign sites
router.post('/', requireAuth, requireRoles('admin', 'staff', 'demo_admin'), createSite);
router.post('/:id/assign-inspector', requireAuth, requireRoles('admin', 'staff', 'demo_admin'), assignInspector);
router.put('/:id', requireAuth, requireRoles('admin', 'staff', 'demo_admin'), updateSite);
router.patch('/:id', requireAuth, requireRoles('admin', 'staff', 'demo_admin'), updateSite);
router.delete('/:id', requireAuth, requireRoles('admin', 'staff', 'demo_admin'), deleteSite);

export default router;
