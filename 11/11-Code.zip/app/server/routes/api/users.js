import { Router } from 'express';
import {
  getUsers,
  getUserById,
  createUser,
  updateUserProfile,
  getCitizenProfile,
  updateCitizenProfile,
  updateUserRole,
  updateUserStatus,
  deleteUser
} from '../../controllers/user.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';

const router = Router();

// Citizen Profile endpoints (supports both /api/citizen/profile and /api/users/citizen/profile)
router.get(['/profile', '/citizen/profile'], requireAuth, getCitizenProfile);
router.patch(['/profile', '/citizen/profile'], requireAuth, updateCitizenProfile);
router.put(['/profile', '/citizen/profile'], requireAuth, updateCitizenProfile);

// Only admins can manage users generally
router.get('/', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), getUsers);
router.post('/', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), createUser);
router.get('/:id', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), getUserById);
router.delete('/:id', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), deleteUser);
router.put('/:id/role', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), updateUserRole);
router.put('/:id/status', requireAuth, requireRoles('admin', 'staff', 'demo_admin', 'super_admin'), updateUserStatus);

// Any authenticated user should be able to update their profile (the controller should check if they are updating their own profile)
router.put('/:id/profile', requireAuth, updateUserProfile);
router.patch('/:id/profile', requireAuth, updateUserProfile);

export default router;


