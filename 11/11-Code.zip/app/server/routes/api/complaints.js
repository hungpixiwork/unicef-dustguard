import { Router } from 'express';
import { 
  submitComplaint, 
  listComplaints, 
  getComplaintByCode, 
  updateComplaint, 
  updateComplaintStatus, 
  verifyComplaint,
  deleteComplaint,
  convertComplaintToCase
} from '../../controllers/complaints.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { upload } from '../../middleware/upload.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();

// Simple in-memory rate limiter: max 10 requests per IP per minute
const rateLimitMap = new Map();
function simpleRateLimit(req, res, next) {
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const now = Date.now();
    const windowMs = 60_000;
    const maxRequests = 10;
    const entry = rateLimitMap.get(ip) || { count: 0, start: now };
    if (now - entry.start > windowMs) {
        entry.count = 0;
        entry.start = now;
    }
    entry.count++;
    rateLimitMap.set(ip, entry);
    if (entry.count > maxRequests) {
        return res.status(429).json({
            status: 'error',
            statusCode: 429,
            code: 'TOO_MANY_REQUESTS',
            type: 'https://dustguard.vn/errors/TOO_MANY_REQUESTS',
            title: 'Too Many Requests',
            detail: 'Quá nhiều yêu cầu. Vui lòng thử lại sau.',
            instance: req.originalUrl || req.url,
            error: 'Quá nhiều yêu cầu. Vui lòng thử lại sau.',
            message: 'Quá nhiều yêu cầu. Vui lòng thử lại sau.',
            timestamp: new Date().toISOString()
        });
    }
    next();
}

router.post('/', simpleRateLimit, submitComplaint);
router.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return errorResponse(res, 'Không có tệp tin nào được tải lên', 400);
    }
    const url = `/uploads/${req.file.filename}`;
    return successResponse(res, { url, filename: req.file.filename, size: req.file.size, mimeType: req.file.mimetype }, 'Tải lên minh chứng thành công', 201);
});
router.get('/', listComplaints);
router.get('/:code', getComplaintByCode);
router.post('/:id/verify', verifyComplaint);
router.post('/:id/convert-to-case', requireAuth, requireRoles('staff', 'admin', 'executive'), convertComplaintToCase);
router.put('/:id', requireAuth, requireRoles('staff', 'admin', 'executive'), updateComplaint);
router.patch('/:id', requireAuth, requireRoles('staff', 'admin', 'executive'), updateComplaint);
router.put('/:id/status', requireAuth, requireRoles('staff', 'admin', 'executive'), updateComplaintStatus);
router.patch('/:id/status', requireAuth, requireRoles('staff', 'admin', 'executive'), updateComplaintStatus);
router.delete('/:id', requireAuth, requireRoles('staff', 'admin', 'executive'), deleteComplaint);

export default router;

