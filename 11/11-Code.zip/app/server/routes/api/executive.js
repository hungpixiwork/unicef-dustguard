import { Router } from 'express';
import { ExecutiveService } from '../../services/executive.service.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { successResponse, errorResponse } from '../../lib/response.js';
import { prisma } from '../../shared/db.js';
import { randomUUID } from 'crypto';

const router = Router();

/**
 * 1. GET /api/executive/overview
 * Top-level KPIs, risk distribution, ward summary
 */
router.get('/overview', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getOverview(prisma);
    return successResponse(res, data, 'Tải dữ liệu tổng quan điều hành thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 2. GET /api/executive/priorities
 * Critical issue queue ranked by risk score and SLA urgency
 */
router.get('/priorities', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getPriorities(prisma);
    return successResponse(res, data, 'Tải hàng đợi vấn đề ưu tiên thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 3. GET /api/executive/operations
 * Operational command center, real inspector workload from users/profiles, 7-step pipeline
 */
router.get('/operations', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getOperations(prisma);
    return successResponse(res, data, 'Tải số liệu điều hành tác nghiệp thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 4. GET /api/executive/sla
 * SLA performance, 7-step pipeline distribution, overdue queue
 */
router.get('/sla', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getSlaOperations(prisma);
    return successResponse(res, data, 'Tải số liệu SLA & điều hành thanh tra thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 4. GET /api/executive/sensors
 * IoT Sensor Network health, flatline detection, HMAC integrity
 */
router.get('/sensors', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getSensorHealth(prisma);
    return successResponse(res, data, 'Tải tình trạng mạng lưới cảm biến thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 5. GET /api/executive/impact
 * Before/after intervention analysis with PM2.5 reduction
 */
router.get('/impact', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getInterventionImpact(prisma);
    return successResponse(res, data, 'Tải báo cáo hiệu quả can thiệp thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 6. GET /api/executive/reports
 * Executive and inspection draft documents
 */
router.get('/reports', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getReports(prisma);
    return successResponse(res, data, 'Tải danh mục báo cáo điều hành thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 7. GET /api/executive/reports/:id
 */
router.get('/reports/:id', requireAuth, requireRoles('executive', 'admin', 'demo_admin', 'staff'), async (req, res) => {
  try {
    const data = await ExecutiveService.getReportById(req.params.id, prisma);
    if (!data) {
      return errorResponse(res, 'Không tìm thấy báo cáo này', 404);
    }
    return successResponse(res, data, 'Tải chi tiết báo cáo thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 8. POST /api/executive/cases/:id/escalate
 * Executive emergency order escalation
 */
router.post('/cases/:id/escalate', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body || {};
    const user = req.user;
    const now = new Date().toISOString();

    await prisma.case.update({
      where: { id },
      data: {
        priority: 'CRITICAL',
        updatedAt: new Date()
      }
    }).catch(() => null);

    try {
      await prisma.auditLog.create({
        data: {
          id: `aud_${randomUUID()}`,
          actorName: user?.name || user?.fullName || 'Lãnh đạo cơ quan',
          actorRole: 'executive',
          action: 'EXECUTIVE_CASE_ESCALATE',
          targetId: id,
          details: JSON.stringify({ reason: reason || 'Kích hoạt chỉ đạo khẩn cấp vượt cấp' }),
          createdAt: new Date()
        }
      });
    } catch {}

    return successResponse(res, {
      caseId: id,
      priority: 'CRITICAL',
      escalatedAt: now,
      escalatedBy: user?.name || user?.fullName || 'Lãnh đạo cơ quan'
    }, 'Kích hoạt chỉ đạo khẩn cấp vụ việc thành công!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 9. POST /api/executive/cases/:id/assign
 * Executive direct inspector assignment
 */
router.post('/cases/:id/assign', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { inspectorName = 'Nguyễn Văn An' } = req.body || {};
    const now = new Date().toISOString();

    await prisma.case.update({
      where: { id },
      data: {
        assignedTo: inspectorName,
        status: 'PREPARING',
        updatedAt: new Date()
      }
    }).catch(() => null);

    return successResponse(res, {
      caseId: id,
      assignedTo: inspectorName,
      status: 'PREPARING',
      updatedAt: now
    }, `Đã phân công hồ sơ cho thanh tra viên ${inspectorName} thành công!`);
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 10. POST /api/executive/cases/:id/directive
 * Issue official executive directive / instructions on a case
 */
router.post('/cases/:id/directive', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body || {};
    const directiveText = (body.content || body.directive || '').trim();
    if (!directiveText) {
      return errorResponse(res, 'Nội dung chỉ đạo không được để trống', 400);
    }
    const result = await ExecutiveService.issueDirective(id, body, req.user, prisma);
    return successResponse(res, result, result.message || 'Ban hành chỉ đạo điều hành thành công!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 11. POST /api/executive/cases/:id/approve
 * Executive approve case
 */
router.post('/cases/:id/approve', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await ExecutiveService.approveCase(id, req.body, req.user, prisma);
    return successResponse(res, result, result.message || 'Phê duyệt hồ sơ thành công!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 12. POST /api/executive/cases/:id/reject
 * Executive reject case
 */
router.post('/cases/:id/reject', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await ExecutiveService.rejectCase(id, req.body, req.user, prisma);
    return successResponse(res, result, result.message || 'Đã yêu cầu kiểm tra lại!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * 13. POST /api/executive/cases/:id/close
 * Executive close case
 */
router.post('/cases/:id/close', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await ExecutiveService.closeCase(id, req.body, req.user, prisma);
    return successResponse(res, result, result.message || 'Đã đóng hồ sơ vụ việc!');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

export default router;

