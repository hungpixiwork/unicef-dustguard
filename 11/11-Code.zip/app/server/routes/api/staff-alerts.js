import { Router } from 'express';
import Database from 'better-sqlite3';
import path from 'path';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();
let db;
const candidates = [
  path.resolve(process.cwd(), 'prisma/dev.db'),
  path.resolve(process.cwd(), 'app/prisma/dev.db'),
  path.resolve(process.cwd(), '../prisma/dev.db')
];

for (const p of candidates) {
  try {
    db = new Database(p);
    break;
  } catch (e) {
    // continue trying
  }
}

// 1. GET /api/staff/alerts/summary
router.get('/summary', (req, res, next) => {
  try {
    const totalRow = db.prepare("SELECT COUNT(*) as cnt FROM alerts WHERE status != 'DELETED'").get();
    const criticalRow = db.prepare("SELECT COUNT(*) as cnt FROM alerts WHERE (severity = 'CRITICAL' OR pm10Value > 150) AND status = 'PENDING'").get();
    const unopenedRow = db.prepare("SELECT COUNT(*) as cnt FROM alerts WHERE caseId IS NULL AND status = 'PENDING'").get();
    const resolvedRow = db.prepare("SELECT COUNT(*) as cnt FROM alerts WHERE status = 'RESOLVED'").get();

    return successResponse(res, {
      totalAlerts: totalRow?.cnt ?? 0,
      criticalCount: criticalRow?.cnt ?? 0,
      unopenedCaseCount: unopenedRow?.cnt ?? 0,
      resolvedCount: resolvedRow?.cnt ?? 0,
      timestamp: new Date().toISOString()
    }, 'Thống kê cảnh báo');
  } catch (error) {
    next(error);
  }
});

// 2. GET /api/staff/alerts/priorities
router.get('/priorities', (req, res, next) => {
  try {
    const items = db.prepare(`
      SELECT 
        a.id, a.siteId, a.pm10Value as pm10, COALESCE(a.pm25Value, 45) as pm25,
        COALESCE(a.severity, 'CRITICAL') as severity,
        COALESCE(a.priorityReasons, '[]') as priorityReasonsRaw,
        COALESCE(a.evidenceUrls, '[]') as evidenceUrlsRaw,
        a.triggeredAt,
        si.name as siteName,
        si.address as address,
        COALESCE(si.dustRiskScore, 50) as dustRiskScore
      FROM alerts a
      LEFT JOIN sites si ON a.siteId = si.id
      WHERE a.status = 'PENDING'
      ORDER BY si.dustRiskScore DESC, a.pm10Value DESC
      LIMIT 3
    `).all() || [];

    const formatted = items.map(r => {
      let priorityReasons = [];
      let evidenceUrls = [];
      try { priorityReasons = JSON.parse(r.priorityReasonsRaw); } catch (e) {}
      try { evidenceUrls = JSON.parse(r.evidenceUrlsRaw); } catch (e) {}
      const timeFormatted = r.triggeredAt ? new Date(r.triggeredAt).toLocaleString('vi-VN') : 'Vừa xong';
      return { 
        ...r, 
        timeFormatted, 
        siteName: r.siteName || 'Công trình chưa đặt tên',
        address: r.address || 'Hà Nội',
        priorityReasons, 
        evidenceUrls 
      };
    });

    return successResponse(res, { items: formatted }, 'Top cảnh báo ưu tiên');
  } catch (error) {
    next(error);
  }
});

// 3. GET /api/staff/alerts & /api/staff/alerts/list
const getAlertsList = (req, res, next) => {
  try {
    const { filter = 'ALL', search = '', page = 1, limit = 6 } = req.query;
    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    let whereClause = "WHERE a.status != 'DELETED'";
    const params = [];

    if (filter === 'CRITICAL') whereClause += " AND a.severity = 'CRITICAL'";
    else if (filter === 'HIGH') whereClause += " AND a.severity = 'HIGH'";
    else if (filter === 'MEDIUM') whereClause += " AND a.severity = 'MEDIUM'";
    else if (filter === 'VIEWED') whereClause += " AND a.status = 'IN_PROGRESS'";

    if (search) {
      whereClause += ` AND (LOWER(COALESCE(si.name, '')) LIKE ? OR LOWER(COALESCE(si.address, '')) LIKE ?)`;
      params.push(`%${search.toLowerCase()}%`, `%${search.toLowerCase()}%`);
    }

    const query = `
      SELECT 
        a.id, a.siteId, a.sensorId, a.pm10Value as pm10, COALESCE(a.pm25Value, 45) as pm25,
        COALESCE(a.severity, 'CRITICAL') as severity, a.title, a.status,
        COALESCE(a.priorityReasons, '[]') as priorityReasonsRaw,
        COALESCE(a.evidenceUrls, '[]') as evidenceUrlsRaw,
        a.assignedTo, a.caseId, a.triggeredAt,
        si.name as siteName,
        si.address as address,
        COALESCE(si.ward, 'Thanh Xuân') as district,
        COALESCE(si.dustRiskScore, 50) as dustRiskScore
      FROM alerts a
      LEFT JOIN sites si ON a.siteId = si.id
      ${whereClause}
      ORDER BY a.triggeredAt DESC
      LIMIT ? OFFSET ?
    `;

    const items = db.prepare(query).all(...params, parseInt(limit, 10), offset) || [];

    const formatted = items.map(r => {
      let priorityReasons = [];
      let evidenceUrls = [];
      try { priorityReasons = JSON.parse(r.priorityReasonsRaw); } catch (e) {}
      try { evidenceUrls = JSON.parse(r.evidenceUrlsRaw); } catch (e) {}
      const timeFormatted = r.triggeredAt ? new Date(r.triggeredAt).toLocaleString('vi-VN') : 'Vừa xong';
      return { 
        ...r, 
        timeFormatted, 
        siteName: r.siteName || 'Công trình chưa đặt tên',
        address: r.address || 'Hà Nội',
        priorityReasons, 
        evidenceUrls 
      };
    });

    const totalCount = db.prepare("SELECT COUNT(*) as count FROM alerts WHERE status != 'DELETED'").get()?.count ?? formatted.length;

    return successResponse(res, {
      items: formatted,
      pagination: {
        page: parseInt(page, 10),
        limit: parseInt(limit, 10),
        total: totalCount,
        totalPages: Math.max(1, Math.ceil(totalCount / parseInt(limit, 10)))
      }
    }, 'Danh sách cảnh báo');
  } catch (error) {
    next(error);
  }
};

router.get('/', getAlertsList);
router.get('/list', getAlertsList);

// 4. POST /api/staff/alerts/:id/convert-to-case (Anti-Duplicate & Atomic Transaction)
router.post('/:id/convert-to-case', (req, res, next) => {
  try {
    const { id } = req.params;
    const alert = db.prepare('SELECT * FROM alerts WHERE id = ?').get(id);
    if (!alert) return errorResponse(res, `Không tìm thấy cảnh báo ${id}`, 404);
    if (alert.caseId) {
      return errorResponse(res, 'Cảnh báo này đã được chuyển thành hồ sơ kiểm tra!', 409);
    }

    const caseId = `case-${Date.now()}`;
    const caseCode = `HS-26-${Date.now().toString().slice(-5)}`;
    const now = new Date().toISOString();

    const createCaseTx = db.transaction(() => {
      db.prepare(`
        INSERT INTO cases (id, code, title, description, status, sourceType, sourceId, siteId, priority, slaDeadline, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        caseId,
        caseCode,
        `Xử lý cảnh báo vượt ngưỡng bụi tại công trình`,
        `Tạo từ cảnh báo ${id}`,
        'IN_PROGRESS',
        'ALERT',
        id,
        alert.siteId,
        alert.severity === 'CRITICAL' ? 'URGENT' : 'NORMAL',
        new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
        now,
        now
      );

      db.prepare("UPDATE alerts SET status = 'IN_PROGRESS', caseId = ?, updatedAt = ? WHERE id = ?").run(caseId, now, id);
    });

    createCaseTx();

    return successResponse(res, { caseId, caseCode, alertId: id }, 'Mở hồ sơ kiểm tra thành công', 201);
  } catch (error) {
    next(error);
  }
});

// 5. POST /api/staff/alerts/:id/ignore
router.post('/:id/ignore', (req, res, next) => {
  try {
    const { id } = req.params;
    db.prepare("UPDATE alerts SET status = 'IGNORED', updatedAt = ? WHERE id = ?").run(new Date().toISOString(), id);
    return successResponse(res, null, 'Đã bỏ qua cảnh báo');
  } catch (error) {
    next(error);
  }
});

// 6. POST /api/staff/alerts/:id/assign
router.post('/:id/assign', (req, res, next) => {
  try {
    const { id } = req.params;
    const { assignedTo } = req.body || {};
    db.prepare("UPDATE alerts SET assignedTo = ?, status = 'IN_PROGRESS', updatedAt = ? WHERE id = ?").run(
      assignedTo || 'Thanh tra môi trường',
      new Date().toISOString(),
      id
    );
    return successResponse(res, null, 'Phân công cán bộ thành công');
  } catch (error) {
    next(error);
  }
});

export default router;
