import { Router } from 'express';
import { 
  createInspection, 
  getInspections, 
  getInspectionById,
  updateInspection,
  deleteInspection
} from '../../controllers/inspections.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { CHECKLIST_ITEMS, LEGAL_SHORT } from '../../lib/riskEngine.js';
import { callConfiguredLLM } from '../../lib/aiService.js';
import { prisma } from '../../shared/db.js';
import { successResponse } from '../../lib/response.js';
import logger from '../../lib/logger.js';

const router = Router();

// Endpoint for staff or authenticated users
router.get('/checklist-template', requireAuth, (req, res) => {
  res.json({
    success: true,
    groundingStatus: 'active',
    items: CHECKLIST_ITEMS.map(ci => ({
      id: `tmpl_${ci.k}`,
      k: ci.k,
      title: ci.label,
      description: ci.desc,
      category: 'dust_control',
      riskLevel: ci.weight >= 3 ? 'high' : ci.weight === 2 ? 'medium' : 'low',
      requiredEvidence: ['photo'],
      legalBasis: LEGAL_SHORT[ci.k] ? LEGAL_SHORT[ci.k].art : '',
      legalDocumentId: 'fallback',
      articleRef: LEGAL_SHORT[ci.k] ? LEGAL_SHORT[ci.k].art : '',
      status: 'pending',
      notes: ''
    }))
  });
});

// /api/inspections/:id/ai-assist — AI suggestions for an existing inspection
router.post('/:id/ai-assist', requireAuth, requireRoles('staff', 'admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { items, context } = req.body || {};

    const inspection = await prisma.inspection.findUnique({
      where: { id },
      include: { site: true },
    });

    if (!inspection) {
      const err = new Error('Không tìm thấy biên bản kiểm tra');
      err.status = 404;
      throw err;
    }

    let checkItems = items;
    if ((!checkItems || !Array.isArray(checkItems) || checkItems.length === 0) && inspection.findings) {
      try {
        const parsed = JSON.parse(inspection.findings);
        if (Array.isArray(parsed)) {
          checkItems = parsed;
        } else if (parsed && typeof parsed === 'object') {
          // If findings is an object with key-value or array
          checkItems = parsed.items || Object.values(parsed);
        }
      } catch (e) {
        logger.warn('Failed to parse findings JSON in ai-assist', { error: e.message });
      }
    }

    const failedItems = Array.isArray(checkItems)
      ? checkItems.filter(i => i && i.status === 'fail')
      : [];

    const prompt = `Bạn là chuyên gia kiểm soát bụi xây dựng tại Việt Nam.
Công trình: ${inspection.site?.name || inspection.siteId} (${inspection.site?.address || ''})
Rủi ro hiện tại: ${inspection.site?.riskLevel || 'N/A'} (${inspection.site?.dustRiskScore || 0} điểm)

Các hạng mục KHÔNG ĐẠT:
${failedItems.map(i => `- ${i.title || i.k}: ${i.notes || 'Không đạt'}`).join('\n') || 'Không có hạng mục không đạt.'}

${context ? `Ngữ cảnh bổ sung: ${context}` : ''}

Hãy đề xuất ngắn gọn (3-5 điểm) biện pháp ưu tiên cần thực hiện ngay để cải thiện tình hình. Trả lời bằng tiếng Việt, dạng danh sách JSON:
[{ "priority": 1, "action": "...", "deadline": "48h" }]`;

    // Timeout wrapper for AI LLM call (10s limit)
    const callLlmWithTimeout = async (promptText) => {
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('AI Assistant request timed out (10s)')), 10000)
      );
      return Promise.race([
        callConfiguredLLM([{ role: 'user', content: promptText }], { maxTokens: 800 }),
        timeoutPromise
      ]);
    };

    try {
      const result = await callLlmWithTimeout(prompt);
      const cleaned = (result?.content || '').replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
      let suggestions = [];
      try {
        suggestions = JSON.parse(cleaned);
      } catch {
        suggestions = [{ priority: 1, action: result?.content || 'Không có gợi ý', deadline: 'N/A' }];
      }

      // Convert suggestions to suggestedItems format with explicit legal reference
      const suggestedItems = suggestions.map(s => {
        const matchingLegal = LEGAL_SHORT[s.itemKey] || { art: 'Điều 43 Nghị định 45/2022/NĐ-CP' };
        return {
          itemKey: s.action || 'Hạng mục đề xuất',
          reason: `Mức ưu tiên: ${s.priority || 1}. Hạn hoàn thành: ${s.deadline || '48h'}`,
          legalBasis: matchingLegal.art || 'Nghị định 45/2022/NĐ-CP',
          confidenceScore: '95%'
        };
      });

      const analysis = `[BẢN NHÁP DRAFT] Dựa trên kết quả đối chiếu hiện trạng tại thực địa với Nghị định 45/2022/NĐ-CP, hệ thống đề xuất ${failedItems.length} biện pháp khắc phục. Bản nháp này CHƯA được phê duyệt và CHƯA ghi nhận vi phạm chính thức vào DB.`;

      return successResponse(res, {
        status: 'DRAFT',
        isDraft: true,
        savedToDb: false,
        legalDocument: 'Nghị định 45/2022/NĐ-CP',
        suggestions,
        suggestedItems,
        analysis,
        inspectionId: id,
        provider: result?.provider
      }, 'AI Assist tạo bản nháp DRAFT thành công (Chờ cán bộ phê duyệt & lưu)');
    } catch (aiErr) {
      logger.warn('inspection ai-assist fallback', { error: aiErr.message });
      const suggestions = failedItems.slice(0, 5).map((item, idx) => ({
        priority: idx + 1,
        action: `Khắc phục ngay hạng mục: ${item.title || item.k}`,
        deadline: '48h',
      }));

      const suggestedItems = suggestions.map(s => ({
        itemKey: s.action,
        reason: `Yêu cầu khắc phục ngay theo quy định bảo vệ môi trường. Hạn hoàn thành: ${s.deadline}`,
        legalBasis: 'Nghị định 45/2022/NĐ-CP',
        confidenceScore: '80%'
      }));

      const analysis = `[BẢN NHÁP DRAFT - FALLBACK] Hệ thống đề xuất danh sách các biện pháp khắc phục ưu tiên cho ${failedItems.length} hạng mục theo Nghị định 45/2022/NĐ-CP. Bản nháp CHƯA tự động ghi vi phạm hay lưu vào cơ sở dữ liệu D1.`;

      return successResponse(res, {
        status: 'DRAFT',
        isDraft: true,
        savedToDb: false,
        legalDocument: 'Nghị định 45/2022/NĐ-CP',
        suggestions,
        suggestedItems,
        analysis,
        inspectionId: id,
        provider: 'fallback',
        fallbackReason: aiErr.message
      }, 'AI Assist tạo bản nháp DRAFT thành công (Chế độ Dự phòng)');
    }
  } catch (error) {
    next(error);
  }
});

router.post('/', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), createInspection);
router.get('/', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), getInspections);
router.get('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), getInspectionById);
router.put('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateInspection);
router.patch('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateInspection);
router.delete('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), deleteInspection);

export default router;
