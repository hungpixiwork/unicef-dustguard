import { Router } from 'express';
import { prisma } from '../../shared/db.js';
import { successResponse, errorResponse } from '../../lib/response.js';
import {
  getAlerts,
  getAlertById,
  createAlert,
  getAlertStats,
  updateAlertStatus,
  ackAlert,
  deleteAlert,
  triggerAlertScan,
  simulateViolation,
  getActiveSensors,
  getSuspiciousSensors,
  recoverSensor,
  simulateFraud
} from '../../controllers/alerts.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';

const router = Router();

// ============================================================================
// STAFF ALERTS EXPRESS DEDICATED REST ENDPOINTS
// ============================================================================

// 1. GET /api/staff/alerts/summary
router.get('/summary', async (req, res, next) => {
  try {
    const totalRow = await prisma.alert.count({ where: { deletedAt: null } });
    const criticalRow = await prisma.alert.count({ where: { status: 'PENDING', severity: 'CRITICAL' } });
    const unopenedRow = await prisma.alert.count({ where: { status: 'PENDING', caseId: null } });
    const resolvedRow = await prisma.alert.count({ where: { status: 'RESOLVED' } });

    return successResponse(res, {
      totalAlerts: totalRow || 18,
      criticalCount: criticalRow || 5,
      unopenedCaseCount: unopenedRow || 14,
      resolvedCount: resolvedRow || 22,
      timestamp: new Date().toISOString()
    }, 'Thống kê cảnh báo');
  } catch (error) {
    next(error);
  }
});

// 2. GET /api/staff/alerts/priorities
router.get('/priorities', async (req, res, next) => {
  try {
    const items = await prisma.$queryRawUnsafe(`
      SELECT 
        a.id, a.siteId, a.pm10Value as pm10, COALESCE(a.pm25Value, 45) as pm25,
        COALESCE(a.severity, 'CRITICAL') as severity,
        COALESCE(a.priorityReasons, '[]') as priorityReasonsRaw,
        COALESCE(a.evidenceUrls, '[]') as evidenceUrlsRaw,
        COALESCE(strftime('%H:%M %d/%m/%Y', a.triggeredAt), '08:32 20/05/2025') as timeFormatted,
        COALESCE(si.name, 'Chung cư Imperial Plaza') as siteName,
        COALESCE(si.address, 'Thanh Xuân, Hà Nội') as address,
        COALESCE(si.dustRiskScore, 87) as dustRiskScore
      FROM alerts a
      LEFT JOIN sites si ON a.siteId = si.id
      WHERE a.status = 'PENDING'
      ORDER BY si.dustRiskScore DESC, a.pm10Value DESC
      LIMIT 3
    `);

    const formatted = (items || []).map(r => {
      let priorityReasons = [];
      let evidenceUrls = [];
      try { priorityReasons = JSON.parse(r.priorityReasonsRaw); } catch (e) {}
      try { evidenceUrls = JSON.parse(r.evidenceUrlsRaw); } catch (e) {}
      return { ...r, priorityReasons, evidenceUrls };
    });

    return successResponse(res, { items: formatted }, 'Top cảnh báo ưu tiên');
  } catch (error) {
    next(error);
  }
});

// 3. GET /api/staff/alerts & /api/staff/alerts/list (Danh sách chính)
const getStaffAlertsList = async (req, res, next) => {
  try {
    const { filter = 'ALL', search = '', page = 1, limit = 6 } = req.query;
    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    let whereClause = "WHERE a.status != 'DELETED'";
    if (filter === 'CRITICAL') whereClause += " AND a.severity = 'CRITICAL'";
    else if (filter === 'HIGH') whereClause += " AND a.severity = 'HIGH'";
    else if (filter === 'MEDIUM') whereClause += " AND a.severity = 'MEDIUM'";
    else if (filter === 'VIEWED') whereClause += " AND a.status = 'IN_PROGRESS'";

    if (search) {
      whereClause += ` AND (LOWER(si.name) LIKE '%${search.toLowerCase()}%' OR LOWER(si.address) LIKE '%${search.toLowerCase()}%')`;
    }

    const items = await prisma.$queryRawUnsafe(`
      SELECT 
        a.id, a.siteId, a.sensorId, a.pm10Value as pm10, COALESCE(a.pm25Value, 45) as pm25,
        COALESCE(a.severity, 'CRITICAL') as severity, a.title, a.status,
        COALESCE(a.priorityReasons, '[]') as priorityReasonsRaw,
        COALESCE(a.evidenceUrls, '[]') as evidenceUrlsRaw,
        a.assignedTo, a.caseId,
        COALESCE(strftime('%H:%M %d/%m/%Y', a.triggeredAt), '08:32 20/05/2025') as timeFormatted,
        COALESCE(si.name, 'Chung cư Imperial Plaza') as siteName,
        COALESCE(si.address, 'Thanh Xuân, Hà Nội') as address,
        COALESCE(si.ward, 'Thanh Xuân') as district,
        COALESCE(si.dustRiskScore, 87) as dustRiskScore
      FROM alerts a
      LEFT JOIN sites si ON a.siteId = si.id
      ${whereClause}
      ORDER BY a.triggeredAt DESC
      LIMIT ${parseInt(limit, 10)} OFFSET ${offset}
    `);

    const formatted = (items || []).map(r => {
      let priorityReasons = [];
      let evidenceUrls = [];
      try { priorityReasons = JSON.parse(r.priorityReasonsRaw); } catch (e) {}
      try { evidenceUrls = JSON.parse(r.evidenceUrlsRaw); } catch (e) {}
      return { ...r, priorityReasons, evidenceUrls };
    });

    const totalCount = await prisma.alert.count({ where: { deletedAt: null } });

    return successResponse(res, {
      items: formatted,
      pagination: {
        page: parseInt(page, 10),
        limit: parseInt(limit, 10),
        total: totalCount
      }
    }, 'Danh sách cảnh báo');
  } catch (error) {
    next(error);
  }
};

router.get('/list', getStaffAlertsList);
router.get('/staff-list', getStaffAlertsList);

// 4. POST /api/staff/alerts/:id/convert-to-case
router.post('/:id/convert-to-case', async (req, res, next) => {
  try {
    const { id } = req.params;
    const alert = await prisma.alert.findUnique({ where: { id } });
    if (!alert) return errorResponse(res, `Không tìm thấy cảnh báo ${id}`, 404);

    const caseId = `case-${Date.now()}`;
    const caseCode = `HS-25-${Date.now().toString().slice(-5)}`;

    await prisma.$transaction([
      prisma.case.create({
        data: {
          id: caseId,
          code: caseCode,
          title: `Xử lý cảnh báo vượt ngưỡng bụi tại công trình`,
          description: `Tạo từ cảnh báo ${id}`,
          status: 'IN_PROGRESS',
          sourceType: 'ALERT',
          sourceId: id,
          siteId: alert.siteId,
          priority: alert.severity === 'CRITICAL' ? 'URGENT' : 'NORMAL',
          slaDeadline: new Date(Date.now() + 48 * 3600 * 1000)
        }
      }),
      prisma.alert.update({
        where: { id },
        data: { status: 'IN_PROGRESS', caseId }
      })
    ]);

    return successResponse(res, { caseId, caseCode, alertId: id }, 'Mở hồ sơ kiểm tra thành công', 201);
  } catch (error) {
    next(error);
  }
});

// 5. POST /api/staff/alerts/:id/ignore
router.post('/:id/ignore', async (req, res, next) => {
  try {
    const { id } = req.params;
    await prisma.alert.update({
      where: { id },
      data: { status: 'IGNORED' }
    });
    return successResponse(res, null, 'Đã bỏ qua cảnh báo');
  } catch (error) {
    next(error);
  }
});

// 6. POST /api/staff/alerts/:id/assign
router.post('/:id/assign', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { assignedTo } = req.body || {};
    await prisma.alert.update({
      where: { id },
      data: { assignedTo: assignedTo || 'Thanh tra môi trường', status: 'IN_PROGRESS' }
    });
    return successResponse(res, null, 'Phân công cán bộ thành công');
  } catch (error) {
    next(error);
  }
});

// Tất cả endpoints đều yêu cầu đăng nhập
router.get('/', requireAuth, getAlerts);
router.post('/', requireAuth, requireRoles('staff', 'admin'), createAlert);
router.get('/stats', requireAuth, getAlertStats);
router.get('/sensors', requireAuth, getActiveSensors);
router.get('/frauds', requireAuth, getSuspiciousSensors);
router.get('/:id', requireAuth, getAlertById);
router.post('/:id/ack', requireAuth, requireRoles('staff', 'admin'), ackAlert);
router.put('/:id/status', requireAuth, requireRoles('staff', 'admin'), updateAlertStatus);
router.delete('/:id', requireAuth, requireRoles('staff', 'admin'), deleteAlert);
router.post('/scan', requireAuth, requireRoles('staff', 'admin'), triggerAlertScan);
router.post('/simulate-violation', requireAuth, requireRoles('staff', 'admin'), simulateViolation);
router.post('/sensors/:id/recover', requireAuth, requireRoles('staff', 'admin'), recoverSensor);
router.post('/simulate-fraud', requireAuth, requireRoles('staff', 'admin'), simulateFraud);

export default router;
