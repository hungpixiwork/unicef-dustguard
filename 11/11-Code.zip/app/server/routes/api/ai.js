import { Router } from 'express';
import {
  generateInspectionReport,
  searchAi,
  analyzeAi,
  explainViolation,
  parseDocumentAi,
  analyzeImageAi,
  autoReportAi,
  legalAssistantAi
} from '../../controllers/ai.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { getAiCapabilities } from '../../lib/aiService.js';

const router = Router();

// /api/ai/capabilities — returns which AI provider is configured
router.get('/capabilities', requireAuth, (req, res) => {
  const capabilities = getAiCapabilities();
  return res.json({ data: capabilities });
});

// Core AI Assistant Endpoints
router.post('/parse-document', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), parseDocumentAi);
router.post('/analyze-image', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), analyzeImageAi);
router.post('/auto-report', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), autoReportAi);
router.post('/legal-assistant', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin', 'citizen', 'contractor'), legalAssistantAi);

// Aliases & Legacy Endpoints
router.post('/inspection-report', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), generateInspectionReport);
router.post('/search', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin', 'citizen', 'contractor'), searchAi);
router.post('/analyze', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), analyzeAi);
router.post('/legal-obligations', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), analyzeAi);
router.post('/explain-violation', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin', 'citizen', 'contractor'), explainViolation);

// /api/ai/image — Roadmap feature indicator
router.post('/image', requireAuth, requireRoles('admin', 'staff', 'executive', 'demo_admin'), (req, res) => {
  return res.status(501).json({
    ok: false,
    code: 'NOT_IMPLEMENTED',
    message: 'Tính năng phân tích/sinh ảnh AI đang trong lộ trình phát triển (Roadmap). Hiện tại hệ thống ưu tiên sử dụng ảnh thực tế từ biên bản kiểm tra.',
    data: null
  });
});

export default router;

