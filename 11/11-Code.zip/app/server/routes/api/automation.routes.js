import express from 'express';
import {
  runOperationalSweep,
  getRecentAutomationRuns,
  getAutomationConfig,
  setAutomationConfig,
  AUTOMATION_MODES,
  DEFAULT_SLA_POLICY,
  PRIORITY_SLA_POLICIES
} from '../../services/automation-engine.service.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = express.Router();

/**
 * GET /api/automation/status
 * Get current automation engine status, active mode, and per-task toggles
 */
router.get('/status', (req, res) => {
  const config = getAutomationConfig(process.env);
  return successResponse(res, config, 'Trạng thái động cơ tự động hóa & Cron');
});

/**
 * POST /api/automation/toggle
 * Toggle automation engine on/off or change operational mode (ACTIVE, DRY_RUN, DISABLED)
 */
router.post('/toggle', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), (req, res) => {
  const body = req.body || {};
  const updatedConfig = setAutomationConfig(body);
  return successResponse(res, updatedConfig, 'Cập nhật cấu hình & chế độ tự động hóa thành công');
});

/**
 * POST /api/automation/sweep
 * Manually trigger or test the operational sweep engine (Supports DRY_RUN mode)
 */
router.post('/sweep', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const options = req.body || {};
    const report = await runOperationalSweep(null, options);
    return successResponse(res, report, 'Thực thi quét tự động (Operational Sweep) hoàn tất.');
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/automation/runs
 * Retrieve recent automation runs history from automation_runs table
 */
router.get('/runs', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit || '20', 10);
    const runs = await getRecentAutomationRuns(null, limit);
    return successResponse(res, { runs, count: runs.length }, 'Danh sách lịch sử thực thi tác vụ tự động');
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/automation/policy
 * Retrieve the active SLA and automation policy configuration
 */
router.get('/policy', (req, res) => {
  return successResponse(res, {
    defaultPolicy: DEFAULT_SLA_POLICY,
    priorityPolicies: PRIORITY_SLA_POLICIES,
    modes: AUTOMATION_MODES
  }, 'Cấu hình chính sách tự động hóa & SLA mềm');
});

export default router;
