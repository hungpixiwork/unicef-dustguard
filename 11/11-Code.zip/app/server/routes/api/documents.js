import { Router } from 'express';
import {
  createDraftDocument,
  listDraftDocuments,
  getDraftDocument,
  updateDraftDocument,
  exportDraftDocument,
  exportToDocx,
  uploadSignedDocument,
  submitDraftDocument,
  approveDraftDocument,
  verifyDraftDocument,
  listDraftRevisions,
  restoreDraftRevision
} from '../../controllers/documents.controller.js';
import { upload } from '../../middleware/upload.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';

const router = Router();

const generalStaffAccess = [requireAuth, requireRoles('staff', 'admin', 'executive', 'demo_admin')];
const executiveAccess = [requireAuth, requireRoles('executive', 'admin', 'demo_admin')];

// Root Document Endpoints (RESTful SSOT)
router.get('/', ...generalStaffAccess, listDraftDocuments);
router.post('/', ...generalStaffAccess, createDraftDocument);
router.get('/:id', ...generalStaffAccess, getDraftDocument);
router.patch('/:id', ...generalStaffAccess, updateDraftDocument);
router.post('/:id/sign', ...executiveAccess, approveDraftDocument);
router.post('/:id/export', ...generalStaffAccess, exportDraftDocument);
router.get('/:id/export', ...generalStaffAccess, exportDraftDocument);
router.get('/:id/verify', ...generalStaffAccess, verifyDraftDocument);
router.post('/:id/verify', ...generalStaffAccess, verifyDraftDocument);
router.get('/:id/verify-signature', ...generalStaffAccess, verifyDraftDocument);
router.post('/:id/verify-signature', ...generalStaffAccess, verifyDraftDocument);

// Draft Generation & List Endpoints (Legacy / Component compatibility)
router.post('/draft', ...generalStaffAccess, createDraftDocument);
router.post('/drafts', ...generalStaffAccess, createDraftDocument);
router.post('/generate', ...generalStaffAccess, createDraftDocument);
router.get('/drafts', ...generalStaffAccess, listDraftDocuments);

// Single Draft Item Endpoints
router.get('/drafts/:id', ...generalStaffAccess, getDraftDocument);
router.patch('/drafts/:id', ...generalStaffAccess, updateDraftDocument);
router.post('/drafts/:id/export', ...generalStaffAccess, exportDraftDocument);
router.get('/drafts/:id/export', ...generalStaffAccess, exportDraftDocument);
router.get('/drafts/:id/revisions', ...generalStaffAccess, listDraftRevisions);
router.post('/drafts/:id/revisions/:revisionId/restore', ...generalStaffAccess, restoreDraftRevision);

// Signature Verification Endpoints
router.get('/drafts/:id/verify', ...generalStaffAccess, verifyDraftDocument);
router.post('/drafts/:id/verify', ...generalStaffAccess, verifyDraftDocument);
router.get('/drafts/:id/verify-signature', ...generalStaffAccess, verifyDraftDocument);
router.post('/drafts/:id/verify-signature', ...generalStaffAccess, verifyDraftDocument);

// Submit & Approve Endpoints
router.post('/drafts/:id/submit', ...generalStaffAccess, submitDraftDocument);
router.post('/drafts/:id/approve', ...executiveAccess, approveDraftDocument);
router.post('/drafts/:id/sign', ...executiveAccess, approveDraftDocument);

// Global export & signed copy upload
router.post('/export-docx', ...generalStaffAccess, exportToDocx);
router.post('/:id/upload-signed', ...generalStaffAccess, upload.single('document'), uploadSignedDocument);

export default router;

