// app/server/routes/api/community-admin.js
// Express API Router for Community & Campaign Backoffice Administration & SSOT

import { Router } from 'express';
import {
  getCommunityDashboardStats,
  getAdminCampaigns,
  getAdminCampaignById,
  createAdminCampaign,
  updateAdminCampaign,
  archiveAdminCampaign,
  getAdminClubs,
  getAdminClubById,
  createAdminClub,
  updateAdminClub,
  getCampaignParticipants,
  updateParticipantStatus,
  getCommunityMembers,
  addCommunityMember,
  getPublicDiscoverData,
  getPublicCampaignDetail,
  getPublicClubDetail
} from '../../repositories/community-admin.repository.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();

// =========================================================================
// PUBLIC DISCOVERY ENDPOINTS (Pure DB)
// =========================================================================

// GET /api/community/discover
router.get('/discover', async (req, res) => {
  try {
    const data = await getPublicDiscoverData(req.db);
    return successResponse(res, data, 'Lấy dữ liệu khám phá cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/campaigns/:slugOrId
router.get('/campaigns/:slugOrId', async (req, res) => {
  try {
    const data = await getPublicCampaignDetail(req.params.slugOrId, req.db);
    if (!data) return errorResponse(res, 'Chiến dịch không tồn tại', 404);
    return successResponse(res, data, 'Lấy chi tiết chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// GET /api/community/clubs/:slugOrId
router.get('/clubs/:slugOrId', async (req, res) => {
  try {
    const data = await getPublicClubDetail(req.params.slugOrId, req.db);
    if (!data) return errorResponse(res, 'Câu lạc bộ không tồn tại', 404);
    return successResponse(res, data, 'Lấy chi tiết câu lạc bộ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// =========================================================================
// ADMIN & STAFF MANAGEMENT ENDPOINTS
// =========================================================================

// GET /api/admin/community/dashboard
router.get('/admin/community/dashboard', async (req, res) => {
  try {
    const data = await getCommunityDashboardStats(req.db);
    return successResponse(res, data, 'Lấy thống kê điều hành cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// Campaigns Management
router.get('/admin/community/campaigns', async (req, res) => {
  try {
    const list = await getAdminCampaigns(req.query, req.db);
    return successResponse(res, list, 'Lấy danh sách chiến dịch quản trị thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/campaigns', async (req, res) => {
  try {
    const item = await createAdminCampaign(req.body, req.user || {}, req.db);
    return successResponse(res, item, 'Tạo chiến dịch mới thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

router.get('/admin/community/campaigns/:id', async (req, res) => {
  try {
    const item = await getAdminCampaignById(req.params.id, req.db);
    if (!item) return errorResponse(res, 'Chiến dịch không tồn tại', 404);
    return successResponse(res, item, 'Lấy chi tiết chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.put('/admin/community/campaigns/:id', async (req, res) => {
  try {
    const item = await updateAdminCampaign(req.params.id, req.body, req.user || {}, req.db);
    return successResponse(res, item, 'Cập nhật chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

router.delete('/admin/community/campaigns/:id', async (req, res) => {
  try {
    const result = await archiveAdminCampaign(req.params.id, req.user || {}, req.db);
    return successResponse(res, result, 'Lưu trữ chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// Clubs Management
router.get('/admin/community/clubs', async (req, res) => {
  try {
    const list = await getAdminClubs(req.query, req.db);
    return successResponse(res, list, 'Lấy danh sách câu lạc bộ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/clubs', async (req, res) => {
  try {
    const item = await createAdminClub(req.body, req.user || {}, req.db);
    return successResponse(res, item, 'Tạo câu lạc bộ mới thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

router.get('/admin/community/clubs/:id', async (req, res) => {
  try {
    const item = await getAdminClubById(req.params.id, req.db);
    if (!item) return errorResponse(res, 'Câu lạc bộ không tồn tại', 404);
    return successResponse(res, item, 'Lấy chi tiết câu lạc bộ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.put('/admin/community/clubs/:id', async (req, res) => {
  try {
    const item = await updateAdminClub(req.params.id, req.body, req.user || {}, req.db);
    return successResponse(res, item, 'Cập nhật câu lạc bộ thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

// Participants Management
router.get('/admin/community/participants', async (req, res) => {
  try {
    const list = await getCampaignParticipants(req.query, req.db);
    return successResponse(res, list, 'Lấy danh sách đăng ký tham gia thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/participants/:id/approve', async (req, res) => {
  try {
    const result = await updateParticipantStatus(req.params.id, 'APPROVED', req.user || {}, req.db);
    return successResponse(res, result, 'Duyệt người tham gia thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/participants/:id/reject', async (req, res) => {
  try {
    const result = await updateParticipantStatus(req.params.id, 'REJECTED', req.user || {}, req.db);
    return successResponse(res, result, 'Từ chối đăng ký tham gia');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/participants/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const result = await updateParticipantStatus(req.params.id, status || 'APPROVED', req.user || {}, req.db);
    return successResponse(res, result, 'Cập nhật trạng thái người tham gia thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// Members Management
router.get('/admin/community/members', async (req, res) => {
  try {
    const list = await getCommunityMembers(req.query, req.db);
    return successResponse(res, list, 'Lấy danh sách thành viên cộng đồng thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

router.post('/admin/community/members', async (req, res) => {
  try {
    const result = await addCommunityMember(req.body, req.user || {}, req.db);
    return successResponse(res, result, 'Thêm thành viên vào CLB thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

export default router;
