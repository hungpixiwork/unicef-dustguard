import { Router } from 'express';
import {
  handleGetDataStats,
  handleResetPreview,
  handleResetData,
  handleSeedDemo,
  handleGetAuditLogs
} from '../../controllers/system.controller.js';

const router = Router();

router.get('/data-stats', handleGetDataStats);
router.post('/reset-data/preview', handleResetPreview);
router.post('/reset-data', handleResetData);
router.post('/seed-demo', handleSeedDemo);
router.get('/audit-logs', handleGetAuditLogs);

export default router;
