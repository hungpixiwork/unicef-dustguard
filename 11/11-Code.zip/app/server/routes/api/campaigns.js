import { Router } from 'express';
import { getCampaigns, createCampaign, joinCampaign } from '../../repositories/campaign.repository.js';
import { successResponse, errorResponse } from '../../lib/response.js';

const router = Router();

// GET /api/campaigns
router.get('/', async (req, res) => {
  try {
    const list = await getCampaigns();
    return successResponse(res, list, 'Lấy danh sách chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

// POST /api/campaigns
router.post('/', async (req, res) => {
  try {
    const campaign = await createCampaign(req.body, req.user || {});
    return successResponse(res, campaign, 'Tạo chiến dịch mới thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

// POST /api/campaigns/:id/join
router.post('/:id/join', async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id || req.body?.userId || 'anonymous_volunteer';
    const result = await joinCampaign(id, userId);
    return successResponse(res, result, 'Đăng ký tham gia chiến dịch thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

export default router;
