import { Router } from 'express';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { successResponse, errorResponse } from '../../lib/response.js';
import {
  calculateDEMS,
  assessGRI304,
  assessGRI305,
  createEscrowContract,
  evaluateMilestone,
  releaseMilestone,
  forfeitEscrow,
  evaluateAutomatedEscrowTrigger,
  generateESGImpactReport,
  exportCSRAuditCertificate,
  solveQuestionsCoverage
} from '../../../src/lib/csr-engine.js';

const router = Router();

// In-memory store for demo/runtime escrow contracts
const escrowStore = new Map();

// Helper to seed initial demo escrow contract
function getOrCreateEscrow(siteId = 'BD-0237', siteName = 'Dự án Tòa nhà X', contractorName = 'Tổng Công ty XD Số 1') {
  if (!escrowStore.has(siteId)) {
    const newEscrow = createEscrowContract({
      escrowId: `ESC-${siteId}`,
      siteId,
      siteName,
      contractorName,
      totalEscrowAmount: 500000000
    });
    escrowStore.set(siteId, newEscrow);
  }
  return escrowStore.get(siteId);
}

/**
 * @route POST /api/csr/calculate-dems
 * @desc Solves Q6: DEMS (Dust Exposure Mitigation Score) calculation
 */
router.post('/calculate-dems', (req, res) => {
  try {
    const params = req.body || {};
    const result = calculateDEMS(params);
    return successResponse(res, result, 'Tính toán điểm DEMS thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/assess-gri304
 * @desc Solves Q7: GRI 304 Biodiversity & Sensitive Zone Impact Assessment
 */
router.post('/assess-gri304', (req, res) => {
  try {
    const params = req.body || {};
    const result = assessGRI304(params);
    return successResponse(res, result, 'Đánh giá GRI 304 thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/assess-gri305
 * @desc Solves Q8: GRI 305 Emissions & Dust Suppression Assessment
 */
router.post('/assess-gri305', (req, res) => {
  try {
    const params = req.body || {};
    const result = assessGRI305(params);
    return successResponse(res, result, 'Đánh giá GRI 305 thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/escrow/create
 * @desc Solves Q9: Create CSR Escrow Fund Contract (Privileged: Staff/Executive/Admin)
 */
router.post('/escrow/create', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const params = req.body || {};
    const escrow = createEscrowContract(params);
    escrowStore.set(escrow.siteId, escrow);
    return successResponse(res, escrow, 'Tạo hợp đồng CSR Escrow thành công', 201);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route GET /api/csr/escrow/:siteId
 * @desc Get CSR Escrow Contract status
 */
router.get('/escrow/:siteId', (req, res) => {
  try {
    const siteId = req.params.siteId;
    const escrow = getOrCreateEscrow(siteId);
    return successResponse(res, escrow, 'Lấy thông tin CSR Escrow thành công');
  } catch (err) {
    return errorResponse(res, err.message, 404);
  }
});

/**
 * @route POST /api/csr/milestone/:siteId
 * @desc Evaluate or release milestone directly by siteId
 */
router.post('/milestone/:siteId', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const siteId = req.params.siteId;
    const { action = 'evaluate', milestoneId = 'M1', evaluationParams = {} } = req.body || {};
    const escrow = getOrCreateEscrow(siteId);
    if (action === 'release') {
      const verifiedBy = req.user?.fullName || req.user?.name || req.user?.email || 'Cán bộ Thanh tra Môi trường';
      const updated = releaseMilestone(escrow, milestoneId, verifiedBy);
      escrowStore.set(siteId, updated);
      return successResponse(res, updated, `Giải ngân mốc ${milestoneId} cho công trình ${siteId} thành công`);
    } else {
      const evaluation = evaluateMilestone(escrow, milestoneId, evaluationParams);
      return successResponse(res, { escrowId: escrow.escrowId, siteId, milestoneId, evaluation }, `Đánh giá mốc ${milestoneId} thành công`);
    }
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/escrow/evaluate-milestone
 * @desc Evaluate milestone condition compliance (Privileged: Staff/Executive/Admin)
 */
router.post('/escrow/evaluate-milestone', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const { siteId = 'BD-0237', milestoneId = 'M1', evaluationParams = {} } = req.body || {};
    const escrow = getOrCreateEscrow(siteId);
    const evaluation = evaluateMilestone(escrow, milestoneId, evaluationParams);
    return successResponse(res, { escrowId: escrow.escrowId, milestoneId, evaluation }, 'Đánh giá mốc Escrow thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/escrow/release-milestone
 * @desc Release escrow funds for verified milestone (Privileged: Staff/Executive/Admin, Server-Controlled Actor)
 */
router.post('/escrow/release-milestone', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const { siteId = 'BD-0237', milestoneId = 'M1' } = req.body || {};
    // Strict RBAC: Actor is server-controlled from authenticated session, not client body
    const verifiedBy = req.user?.fullName || req.user?.name || req.user?.email || 'Cán bộ Thanh tra Môi trường';
    const escrow = getOrCreateEscrow(siteId);
    const updated = releaseMilestone(escrow, milestoneId, verifiedBy);
    escrowStore.set(siteId, updated);
    return successResponse(res, updated, `Giải ngân mốc ${milestoneId} thành công`);
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/escrow/forfeit
 * @desc Forfeit escrow contract due to severe violations (Privileged: Executive/Admin, Server-Controlled Actor)
 */
router.post('/escrow/forfeit', requireAuth, requireRoles('executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const { siteId = 'BD-0237', reason = 'Vi phạm ô nhiễm quá thời hạn' } = req.body || {};
    // Strict RBAC: Actor is server-controlled from authenticated executive session, not client body
    const forfeitedBy = req.user?.fullName || req.user?.name || req.user?.email || 'Lãnh đạo Chi cục BVMT';
    const escrow = getOrCreateEscrow(siteId);
    const updated = forfeitEscrow(escrow, reason, forfeitedBy);
    escrowStore.set(siteId, updated);
    return successResponse(res, updated, 'Tịch thu Quỹ Escrow thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/escrow/auto-trigger
 * @desc Solves Q29: Automated real-time risk & telemetry escrow lock/unlock trigger & Recidivism forfeit (Privileged: Staff/Executive/Admin)
 */
router.post('/escrow/auto-trigger', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const {
      siteId = 'BD-0237',
      siteRiskScore = 0,
      currentPm10 = 45,
      demsScore = 80,
      openComplaints = 0,
      severeViolationCount = 0,
      consecutiveOverdueDays = 0,
    } = req.body || {};
    const escrow = getOrCreateEscrow(siteId);
    const { updatedContract, autoTriggersExecuted } = evaluateAutomatedEscrowTrigger(escrow, {
      siteRiskScore,
      currentPm10,
      demsScore,
      openComplaints,
      severeViolationCount,
      consecutiveOverdueDays,
    });
    escrowStore.set(siteId, updatedContract);
    return successResponse(res, { updatedContract, autoTriggersExecuted }, 'Kiểm tra trigger Escrow tự động thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/executive-report
 * @desc Solves Q10: Integrated ESG & CSR Escrow Executive Impact Report (Privileged: Staff/Executive/Admin)
 */
router.post('/executive-report', requireAuth, requireRoles('staff', 'executive', 'admin', 'demo_admin'), (req, res) => {
  try {
    const { siteId = 'BD-0237', siteInfo = {}, demsParams = {}, gri304Params = {}, gri305Params = {} } = req.body || {};
    const escrow = getOrCreateEscrow(siteId);
    const demsResult = calculateDEMS(demsParams);
    const gri304Result = assessGRI304(gri304Params);
    const gri305Result = assessGRI305(gri305Params);

    const report = generateESGImpactReport({
      siteInfo: { id: siteId, name: siteInfo.name || 'Dự án Tòa nhà X', contractor: siteInfo.contractor || 'Tổng Công ty XD Số 1' },
      demsResult,
      gri304Result,
      gri305Result,
      escrowContract: escrow
    });

    return successResponse(res, report, 'Tạo báo cáo ESG Executive Impact thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route POST /api/csr/certificate/export
 * @desc Solves Q30: Standardized Audit Certificate Payload (Privileged: Staff/Executive/Admin/Contractor)
 */
router.post('/certificate/export', requireAuth, requireRoles('staff', 'executive', 'admin', 'contractor', 'demo_admin'), (req, res) => {
  try {
    const { siteId = 'BD-0237', siteInfo = {}, demsParams = {}, gri305Params = {} } = req.body || {};
    const escrow = getOrCreateEscrow(siteId);
    const demsResult = calculateDEMS(demsParams);
    const gri305Result = assessGRI305(gri305Params);

    const certificate = exportCSRAuditCertificate({
      siteData: { id: siteId, name: siteInfo.name || 'Dự án Tòa nhà X', contractor: siteInfo.contractor || 'Tổng Công ty XD Số 1' },
      demsResult,
      gri305Result,
      escrowContract: escrow
    });

    return successResponse(res, certificate, 'Xuất chứng nhận kiểm toán CSR thành công');
  } catch (err) {
    return errorResponse(res, err.message, 400);
  }
});

/**
 * @route GET /api/csr/sponsorships
 * @route GET /api/v1/csr/sponsorships
 * @desc Solves Q3: List CSR Sponsorship Packages & DEMS alignment metrics
 */
router.get('/sponsorships', (req, res) => {
  try {
    const sponsorships = [
      {
        id: 'CSR-SPONSOR-01',
        title: 'Gói Tài Trợ Dập Bụi Môi Trường - Dự án Vành Đai 3',
        siteId: 'site-vd1',
        sponsorName: 'Tập đoàn Xi Măng & Xây dựng Việt Nam',
        fundedAmountVND: 500000000,
        demsTargetScore: 85,
        currentDemsScore: 88,
        status: 'ACTIVE',
        griAlignment: ['GRI-304', 'GRI-305'],
        avoidedHealthCostVND: 120000000,
        suppressedDustMassKg: 450
      },
      {
        id: 'CSR-SPONSOR-02',
        title: 'Gói Tài Trợ Hệ Thống Phun Sương Tự Động - Cầu Giấy Complex',
        siteId: 'BD-0237',
        sponsorName: 'Ngân Hàng Xanh ESG Bank',
        fundedAmountVND: 350000000,
        demsTargetScore: 80,
        currentDemsScore: 82,
        status: 'ACTIVE',
        griAlignment: ['GRI-305'],
        avoidedHealthCostVND: 85000000,
        suppressedDustMassKg: 320
      }
    ];

    return successResponse(res, { items: sponsorships }, 'Lấy danh sách gói tài trợ CSR thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * @route GET /api/csr/impact-reports/:id
 * @route GET /api/v1/csr/impact-reports/:id
 * @desc Solves Q3: Detailed DEMS & ESG Impact Report
 */
router.get('/impact-reports/:id', (req, res) => {
  try {
    const id = req.params.id;
    const siteId = id.startsWith('site-') || id.startsWith('BD-') ? id : 'BD-0237';
    const escrow = getOrCreateEscrow(siteId);
    
    const demsResult = calculateDEMS({ baselinePm10: 120, currentPm10: 45, mistCannonActive: true, wheelWasherActive: true });
    const gri304Result = assessGRI304();
    const gri305Result = assessGRI305();

    const report = generateESGImpactReport({
      siteInfo: { id: siteId, name: `Công trình ${siteId}`, contractor: 'Tổng Công ty XD Số 1' },
      demsResult,
      gri304Result,
      gri305Result,
      escrowContract: escrow
    });

    return successResponse(res, {
      reportId: id,
      ...report
    }, 'Lấy báo cáo tác động CSR & DEMS thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

/**
 * @route GET /api/csr/questions-coverage
 * @desc Comprehensive Coverage & Verification Endpoint for Q6-Q10 and Q29-Q30
 */
router.get('/questions-coverage', (req, res) => {
  try {
    const siteId = req.query.siteId || 'BD-0237';
    const escrow = getOrCreateEscrow(siteId);
    const coverage = solveQuestionsCoverage({
      site: { id: siteId, name: 'Dự án Tòa nhà X', contractor: 'Tổng Công ty XD Số 1' },
      escrow,
      triggerParams: { siteRiskScore: 30, currentPm10: 45, demsScore: 82, openComplaints: 0 }
    });

    return successResponse(res, coverage, 'Xác nhận phủ hoàn toàn Q6-Q10 và Q29-Q30 thành công');
  } catch (err) {
    return errorResponse(res, err.message, 500);
  }
});

export default router;
