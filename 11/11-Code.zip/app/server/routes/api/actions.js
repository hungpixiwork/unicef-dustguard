import { Router } from 'express';
import {
  getActions,
  getAction,
  createAction,
  updateAction,
  deleteAction,
  verifyAction,
  uploadActionEvidence,
  draftActionsFromInspection,
  confirmDraftActions
} from '../../controllers/actions.controller.js';
import { requireAuth, requireRoles } from '../../middleware/auth.js';
import { upload } from '../../middleware/upload.js';

const router = Router();

router.get('/', requireAuth, getActions);
router.post('/draft-from-inspection', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), draftActionsFromInspection);
router.post('/confirm-draft', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), confirmDraftActions);
router.get('/:id', requireAuth, getAction);
router.post('/', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), createAction);
router.put('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateAction);
router.patch('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), updateAction);
router.delete('/:id', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), deleteAction);
router.post('/:id/verify', requireAuth, requireRoles('staff', 'inspector', 'admin', 'executive', 'demo_admin'), verifyAction);
router.post('/:id/evidence', requireAuth, upload.single('file'), uploadActionEvidence);

export default router;

