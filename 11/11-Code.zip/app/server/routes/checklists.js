import { Router } from 'express';
import { asyncHandler } from '../shared/async-handler.js';
import { successResponse } from '../lib/response.js';
import { CHECKLIST_ITEMS } from '../lib/riskEngine.js';

const router = Router();

router.get('/', asyncHandler(async (req, res) => {
  const items = CHECKLIST_ITEMS.map(item => ({
    id: item.k,
    code: item.k,
    label: item.label,
    description: item.desc,
    category: 'general',
    active: true
  }));
  return successResponse(res, { items });
}));

export default router;
