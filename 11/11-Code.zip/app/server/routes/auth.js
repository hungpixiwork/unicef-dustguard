import { Router } from 'express';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { fromNodeHeaders } from 'better-auth/node';
import { auth, getSessionFromRequest, normalizeAuthUser, isGoogleOauthConfigured, sanitizeRedirectUrl } from '../auth.js';
import { prisma } from '../shared/db.js';

const router = Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    code: 'RATE_LIMIT_EXCEEDED',
    error: 'Quá nhiều thao tác đăng nhập/đăng ký. Vui lòng thử lại sau 15 phút.',
  },
});

router.get('/providers', (req, res) => {
  return res.json({
    googleConfigured: isGoogleOauthConfigured(),
    providers: ['email', ...(isGoogleOauthConfigured() ? ['google'] : [])],
  });
});

router.post('/sign-in/social', async (req, res, next) => {
  try {
    const { provider, callbackURL } = req.body ?? {};
    if (provider === 'google' && !isGoogleOauthConfigured()) {
      return res.status(400).json({
        code: 'MISSING_CONFIG',
        error: 'Chưa cấu hình GOOGLE_CLIENT_ID hoặc GOOGLE_CLIENT_SECRET trên server.',
      });
    }

    const safeCallback = sanitizeRedirectUrl(callbackURL, '/citizen');
    const result = await auth.api.signInSocial({
      body: {
        provider: provider || 'google',
        callbackURL: safeCallback,
      },
      asResponse: true,
    });
    res.status(result.status);
    result.headers.forEach((value, key) => res.setHeader(key, value));
    const body = await result.json();
    return res.json(body);
  } catch (error) {
    next(error);
  }
});

router.post('/register', authLimiter, async (req, res, next) => {
  try {
    const { email, password, full_name, name } = req.body ?? {};
    const result = await auth.api.signUpEmail({
      body: {
        email,
        password,
        name: full_name || name,
      },
      asResponse: true,
    });
    res.status(result.status);
    result.headers.forEach((value, key) => res.setHeader(key, value));
    const body = await result.json();
    return res.json(normalizeAuthUser(body.user));
  } catch (error) {
    next(error);
  }
});

router.post('/login', authLimiter, async (req, res, next) => {
  try {
    const { email, password } = req.body ?? {};
    const result = await auth.api.signInEmail({
      body: { email, password },
      asResponse: true,
    });
    res.status(result.status);
    result.headers.forEach((value, key) => res.setHeader(key, value));
    const body = await result.json();
    return res.json(normalizeAuthUser(body.user));
  } catch (error) {
    next(error);
  }
});

router.post('/logout', async (req, res, next) => {
  try {
    const result = await auth.api.signOut({
      headers: fromNodeHeaders(req.headers),
      asResponse: true,
    });
    res.status(result.status);
    result.headers.forEach((value, key) => res.setHeader(key, value));
    return res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});
router.get('/me', async (req, res, next) => {
  try {
    let user = req.user || req.identity?.toNormalizedUser?.();
    if (!user) {
      const session = await getSessionFromRequest(req).catch(() => null);
      user = normalizeAuthUser(session?.user);
    }

    if (!user || user.disabled) {
      return res.status(401).json({ code: 'UNAUTHENTICATED', error: 'Chưa đăng nhập.' });
    }
    
    try {
      let dbUser = await prisma.user.findUnique({
        where: { email: user.email },
        include: { profile: true }
      });
      
      if (dbUser && !dbUser.profile) {
        try {
          const newProfile = await prisma.profile.create({
            data: {
              userId: dbUser.id,
              fullName: dbUser.fullName || user.name || user.email.split('@')[0],
            }
          });
          dbUser.profile = newProfile;
        } catch (profErr) {
          console.error('Lỗi khi tự động tạo profile cho user:', profErr);
        }
      }
      
      if (!dbUser) {
        dbUser = await prisma.user.create({
          data: {
            id: user.id || `usr_${crypto.randomUUID()}`,
            email: user.email,
            fullName: user.name || user.email.split('@')[0],
            emailVerified: user.emailVerified || false,
            role: user.role || 'citizen',
            profile: {
              create: {
                fullName: user.name || user.email.split('@')[0],
              }
            }
          },
          include: { profile: true }
        });
      }
      
      return res.json({
        ...user,
        id: dbUser.id,
        role: dbUser.role,
        profile: dbUser.profile
      });
    } catch (dbError) {
      console.error('Lỗi khi fetch profile từ Prisma:', dbError);
      return res.json(user);
    }
  } catch (error) {
    next(error);
  }
});

export default router;
