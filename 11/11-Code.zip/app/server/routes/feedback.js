import { Router } from 'express';
import { z } from 'zod';
import { createFeedbackAndSendEmail } from '../services/feedbackService.js';

const router = Router();
const rateStore = new Map();
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_LIMIT = 8;

const feedbackSchema = z.object({
  name: z.string().trim().max(100).optional(),
  email: z.string().trim().email().max(254).optional().or(z.literal('')),
  message: z.string().trim().min(10).max(2000),
  page: z.string().trim().max(200).optional(),
  language: z.enum(['vi', 'en', 'vi-en']).optional(),
});

function isAllowedOrigin(origin) {
  if (!origin) return true;
  const configured = (process.env.FEEDBACK_ALLOWED_ORIGINS || '')
    .split(',')
    .map(value => value.trim())
    .filter(Boolean);
  if (!configured.length) return true;
  return configured.includes(origin);
}

function parseIp(req) {
  const forwarded = req.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0].trim();
  return req.ip || req.socket?.remoteAddress || 'unknown';
}

function checkRateLimit(ip) {
  const key = ip || 'unknown';
  const now = Date.now();
  const current = rateStore.get(key) || { count: 0, resetAt: now + RATE_WINDOW_MS };

  if (now > current.resetAt) {
    const reset = { count: 1, resetAt: now + RATE_WINDOW_MS };
    rateStore.set(key, reset);
    return { allowed: true, remaining: RATE_LIMIT - reset.count, resetAt: reset.resetAt };
  }

  if (current.count >= RATE_LIMIT) {
    return { allowed: false, remaining: 0, resetAt: current.resetAt };
  }

  current.count += 1;
  rateStore.set(key, current);
  return { allowed: true, remaining: RATE_LIMIT - current.count, resetAt: current.resetAt };
}

function cleanupRateStore() {
  const now = Date.now();
  for (const [key, value] of rateStore.entries()) {
    if (value.resetAt <= now) rateStore.delete(key);
  }
}

setInterval(cleanupRateStore, 5 * 60 * 1000).unref();

function setRateHeaders(res, info) {
  res.setHeader('X-RateLimit-Limit', String(RATE_LIMIT));
  res.setHeader('X-RateLimit-Remaining', String(info.remaining));
  res.setHeader('X-RateLimit-Reset', String(Math.floor(info.resetAt / 1000)));
}

function normalizeError(error) {
  const message = String(error?.message || '').toLowerCase();
  if (message.includes('missing mailchimp config')) {
    return { status: 500, error: 'Feedback service is not configured on server.' };
  }
  if (message.includes('mailchimp') || message.includes('mandrill')) {
    return { status: 502, error: 'Feedback delivery failed. Please try again later.' };
  }
  return { status: 500, error: 'Feedback processing failed.' };
}

router.post('/', async (req, res) => {
  const origin = req.get('origin') || null;
  if (!isAllowedOrigin(origin)) {
    return res.status(403).json({ error: 'Origin is not allowed for feedback submission.' });
  }

  const limit = checkRateLimit(parseIp(req));
  setRateHeaders(res, limit);
  if (!limit.allowed) {
    const retryAfter = Math.max(1, Math.ceil((limit.resetAt - Date.now()) / 1000));
    res.setHeader('Retry-After', String(retryAfter));
    return res.status(429).json({ error: 'Too many feedback submissions. Please try again later.' });
  }

  const parsed = feedbackSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  try {
    const languageHeader = String(req.get('accept-language') || '').toLowerCase();
    const language = parsed.data.language
      || (languageHeader.startsWith('vi') ? 'vi' : languageHeader.startsWith('en') ? 'en' : 'vi-en');

    const payload = {
      ...parsed.data,
      email: parsed.data.email || undefined,
      page: parsed.data.page || '/',
      language,
    };

    const feedback = await createFeedbackAndSendEmail(payload, {
      ip: parseIp(req),
      userAgent: req.get('user-agent') || null,
      referer: req.get('referer') || null,
      origin,
    });

    return res.status(201).json({ feedback });
  } catch (error) {
    const normalized = normalizeError(error);
    return res.status(normalized.status).json({ error: normalized.error });
  }
});

export { RATE_LIMIT, RATE_WINDOW_MS };
export default router;
