import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { asyncHandler } from '../shared/async-handler.js';
import { success } from '../shared/response.js';
import { NotFoundError, ValidationError, AppError } from '../shared/errors.js';
import { extractProcurementRequirementsWithAI, extractProcurementRequirements } from '../lib/aiService.js';
import {
    createProcurementDocument,
    getProcurementDocument,
    updateProcurementDocumentStatus,
    saveProcurementRequirements,
    getProcurementRequirements,
    updateProcurementRequirementStatus,
    hasReviewedProcurementRequirements
} from '../services/procurementService.js';

const PROCUREMENT_REFERENCE_DOCUMENTS = [
    {
        id: 'nd-24-2024-nd-cp',
        code: 'NĐ 24/2024/NĐ-CP',
        title: 'Nghị định 24/2024/NĐ-CP hướng dẫn lựa chọn nhà thầu',
        issued_date: '2024-02-27',
        issuer: 'Chính phủ',
        summary: 'Quy định quy trình lựa chọn nhà thầu, hồ sơ mời thầu và tiêu chí đánh giá.',
        sample_text: 'Bên mời thầu phải quy định rõ tiêu chí kỹ thuật, năng lực tài chính, yêu cầu về môi trường và an toàn trong hồ sơ mời thầu.'
    },
    {
        id: 'tt-06-2024-bkhdt',
        code: 'TT 06/2024/TT-BKHĐT',
        title: 'Thông tư 06/2024/TT-BKHĐT về mẫu hồ sơ mời thầu',
        issued_date: '2024-04-26',
        issuer: 'Bộ Kế hoạch và Đầu tư',
        summary: 'Ban hành mẫu hồ sơ mời thầu xây lắp và hướng dẫn tiêu chí đánh giá.',
        sample_text: 'Hồ sơ mời thầu cần nêu rõ yêu cầu kỹ thuật, biện pháp tổ chức thi công, giải pháp bảo vệ môi trường và cơ chế giám sát hợp đồng.'
    }
];

const MAX_UPLOAD_SIZE = 10 * 1024 * 1024;
const MAX_TEXT_LENGTH = 500000;
const MIN_MEANINGFUL_TEXT_LENGTH = 40;
const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
const PDF_MIME = 'application/pdf';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_UPLOAD_SIZE } });
const router = Router();

function buildReferenceText(doc) {
    return [
        `${doc.code} - ${doc.title}`,
        `Cơ quan ban hành: ${doc.issuer}`,
        `Ngày ban hành: ${doc.issued_date}`,
        `Tóm tắt: ${doc.summary}`,
        '',
        doc.sample_text
    ].join('\n');
}

function getExtension(filename = '') {
    const idx = filename.lastIndexOf('.');
    if (idx < 0) return '';
    return filename.slice(idx).toLowerCase();
}

function normalizeText(raw = '') {
    return String(raw).replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
}

function isLikelyScanPdf(text) {
    const cleaned = String(text || '').replace(/\s+/g, ' ').trim();
    return cleaned.length < MIN_MEANINGFUL_TEXT_LENGTH;
}

function validateUploadFile(file) {
    if (!file) return 'Thiếu tệp tải lên.';
    const extension = getExtension(file.originalname || '');
    const mimeType = file.mimetype || '';
    const isPdf = extension === '.pdf' || mimeType === PDF_MIME;
    const isDocx = extension === '.docx' || mimeType === DOCX_MIME;

    if (!isPdf && !isDocx) return 'Chỉ hỗ trợ tệp PDF hoặc DOCX.';
    if (!file.size || file.size <= 0) return 'Tệp tải lên rỗng.';
    return null;
}

async function parseUploadedDocument(file) {
    const extension = getExtension(file.originalname || '');
    const mimeType = file.mimetype || '';

    if (extension === '.pdf' || mimeType === PDF_MIME) {
        const { PDFParse } = await import('pdf-parse');
        const parser = new PDFParse({ data: file.buffer });
        try {
            const parsed = await parser.getText();
            const text = normalizeText(parsed?.text || '');
            if (isLikelyScanPdf(text)) throw new Error('PDF dạng scan/ảnh chưa có OCR. Vui lòng OCR tài liệu trước khi tải lên.');
            return { text, sourceType: 'pdf' };
        } finally {
            await parser.destroy().catch(() => {});
        }
    }

    if (extension === '.docx' || mimeType === DOCX_MIME) {
        const mammoth = await import('mammoth');
        const parsed = await mammoth.extractRawText({ buffer: file.buffer });
        const text = normalizeText(parsed?.value || '');
        if (!text) throw new Error('Không đọc được nội dung DOCX. Vui lòng kiểm tra lại tệp.');
        return { text, sourceType: 'docx' };
    }

    throw new Error('Chỉ hỗ trợ tệp PDF hoặc DOCX.');
}

router.get('/reference-docs', asyncHandler(async (req, res) => {
    return success(res, {
        items: PROCUREMENT_REFERENCE_DOCUMENTS.map(item => ({
            id: item.id,
            code: item.code,
            title: item.title,
            issued_date: item.issued_date,
            issuer: item.issuer,
            summary: item.summary,
            preview_text: buildReferenceText(item)
        }))
    });
}));

router.post('/upload', asyncHandler(async (req, res) => {
    const contentType = req.headers['content-type'] || '';

    if (contentType.includes('multipart/form-data')) {
        await new Promise((resolve, reject) => {
            upload.single('file')(req, res, (uploadError) => {
                if (uploadError) {
                    if (uploadError.code === 'LIMIT_FILE_SIZE') {
                        reject(new ValidationError(`Kích thước tệp vượt quá ${Math.floor(MAX_UPLOAD_SIZE / (1024 * 1024))}MB.`));
                    } else {
                        reject(new ValidationError('Tệp tải lên không hợp lệ.'));
                    }
                }
                resolve();
            });
        });

        try {
            const invalidReason = validateUploadFile(req.file);
            if (invalidReason) throw new ValidationError(invalidReason);
            
            const { text, sourceType } = await parseUploadedDocument(req.file);
            if (!text) throw new ValidationError('Không trích xuất được nội dung văn bản từ tệp.');
            if (text.length > MAX_TEXT_LENGTH) throw new ValidationError('Nội dung văn bản quá dài, vui lòng chia nhỏ tài liệu.');

            const doc = await createProcurementDocument(text, sourceType);
            return success(res, { document: doc });
        } catch (error) {
            const message = error instanceof Error ? error.message : '';
            if (message.includes('OCR') || message.includes('PDF') || message.includes('DOCX') || message.includes('tệp')) {
                throw new ValidationError(message);
            }
            throw new AppError('Không thể xử lý tệp tải lên.', 400);
        }
    }

    const parsed = z.object({ text: z.string().trim().min(1), source_type: z.string().optional() }).safeParse(req.body);
    if (!parsed.success) throw new ValidationError('Dữ liệu không hợp lệ', parsed.error.flatten());

    const text = String(parsed.data.text || '').trim();
    if (text.length > MAX_TEXT_LENGTH) throw new ValidationError('Nội dung văn bản quá dài, vui lòng chia nhỏ tài liệu.');

    const doc = await createProcurementDocument(text, parsed.data.source_type || 'text');
    return success(res, { document: doc });
}));

router.post('/:id/run-full-pipeline', asyncHandler(async (req, res) => {
    const doc = await getProcurementDocument(req.params.id);
    if (!doc) throw new NotFoundError('Document not found');
    if (await hasReviewedProcurementRequirements(doc.id)) {
        throw new AppError('Tài liệu đã có yêu cầu được duyệt. Không thể chạy lại pipeline.', 409);
    }

    try {
        const result = await extractProcurementRequirementsWithAI(doc.text);
        await saveProcurementRequirements(doc.id, result.requirements);
        await updateProcurementDocumentStatus(doc.id, 'extracted');
        return success(res, { ...result, requirements: await getProcurementRequirements(doc.id), status: 'extracted' });
    } catch (error) {
        if (error && error.code === 'REVIEW_LOCKED') {
            throw new AppError('Tài liệu đã có yêu cầu được duyệt. Không thể chạy lại pipeline.', 409);
        }

        const fallback = extractProcurementRequirements(doc.text);
        try {
            await saveProcurementRequirements(doc.id, fallback.requirements);
        } catch (saveError) {
            if (saveError && saveError.code === 'REVIEW_LOCKED') {
                throw new AppError('Tài liệu đã có yêu cầu được duyệt. Không thể chạy lại pipeline.', 409);
            }
            throw saveError;
        }

        await updateProcurementDocumentStatus(doc.id, 'extracted_mock');
        return success(res, {
            ...fallback,
            requirements: await getProcurementRequirements(doc.id),
            provider: 'mock',
            status: 'extracted_mock',
            degraded: true,
            degraded_reason: 'AI provider unavailable or failed'
        }, 206);
    }
}));

router.get('/requirements', asyncHandler(async (req, res) => {
    const docId = req.query.documentId;
    if (!docId) throw new ValidationError('Missing documentId');
    const rows = await getProcurementRequirements(docId);
    return success(res, { requirements: rows });
}));

router.patch('/requirements/:id/review', asyncHandler(async (req, res) => {
    const parsed = z.object({ status: z.enum(['approved', 'rejected', 'pending']) }).safeParse(req.body);
    if (!parsed.success) throw new ValidationError('Dữ liệu không hợp lệ', parsed.error.flatten());

    const updated = await updateProcurementRequirementStatus(req.params.id, parsed.data.status);
    if (!updated) throw new AppError('Không thể cập nhật yêu cầu: không tồn tại hoặc trạng thái chuyển đổi không hợp lệ.', 409);
    return success(res, { requirement: updated });
}));

router.post('/checklist-templates/generate-from-requirements', asyncHandler(async (req, res) => {
    const parsed = z.object({ documentId: z.string().min(1) }).safeParse(req.body);
    if (!parsed.success) throw new ValidationError('Dữ liệu không hợp lệ', parsed.error.flatten());

    const docId = parsed.data.documentId;
    const reqs = (await getProcurementRequirements(docId)).filter(o => o.status === 'approved' || o.status === 'pending');
    return success(res, { checklistDraft: reqs });
}));

router.post('/checklist-templates/:id/activate', asyncHandler(async (req, res) => {
    const doc = await getProcurementDocument(req.params.id);
    if (!doc) throw new NotFoundError('Không tìm thấy tài liệu để kích hoạt checklist.');
    await updateProcurementDocumentStatus(req.params.id, 'compiled');
    return success(res, { success: true, activeChecklistId: req.params.id });
}));

export default router;
