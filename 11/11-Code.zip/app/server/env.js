import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import dotenv from 'dotenv';

const ENV_FILES = ['.env', '.env.local', 'user.env'];

function loadEnvFile(file, protectedKeys) {
  const path = resolve(process.cwd(), file);
  if (!existsSync(path)) return;
  const parsed = dotenv.parse(readFileSync(path));
  for (const [key, value] of Object.entries(parsed)) {
    if (protectedKeys.has(key)) continue;
    process.env[key] = value;
  }
}

export function loadServerEnv() {
  const protectedKeys = new Set(Object.keys(process.env));
  for (const file of ENV_FILES) loadEnvFile(file, protectedKeys);
}

loadServerEnv();
