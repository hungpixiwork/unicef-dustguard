import { getSessionFromRequest, normalizeAuthUser } from '../auth.js';
import { resolveIdentityFromToken, extractTokenFromExpress } from '../auth/human/clerk.middleware.js';

export async function requireAuth(req, res, next) {
  try {
    if (req.user && !req.user.disabled) {
      return next();
    }

    // 1. Try Clerk Hybrid Token resolution
    const token = extractTokenFromExpress(req);
    if (token) {
      const identity = await resolveIdentityFromToken(token, process.env);
      if (identity && !identity.disabled) {
        req.identity = identity;
        req.user = identity.toNormalizedUser();
        req.authSession = { id: identity.sessionId, userId: identity.userId };
        return next();
      }
    }

    // 2. Fallback to session resolution
    const session = await getSessionFromRequest(req).catch(() => null);
    const user = normalizeAuthUser(session?.user);

    if (!user || user.disabled) {
      return res.status(401).json({
        status: 'error',
        statusCode: 401,
        code: 'UNAUTHORIZED',
        type: 'https://dustguard.vn/errors/UNAUTHORIZED',
        title: 'Unauthorized',
        detail: 'Vui lòng đăng nhập để tiếp tục.',
        instance: req.originalUrl || req.url,
        error: 'Vui lòng đăng nhập để tiếp tục.',
        message: 'Vui lòng đăng nhập để tiếp tục.',
        timestamp: new Date().toISOString()
      });
    }

    req.authSession = session.session;
    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
}

export function requireRoles(...roles) {
  const allowedRoles = roles.flat().map(r => r.toLowerCase());

  return async (req, res, next) => {
    try {
      let user = req.user || req.identity?.toNormalizedUser?.();
      if (!user) {
        const token = extractTokenFromExpress(req);
        if (token) {
          const identity = await resolveIdentityFromToken(token, process.env);
          if (identity && !identity.disabled) {
            req.identity = identity;
            req.user = identity.toNormalizedUser();
            req.authSession = { id: identity.sessionId, userId: identity.userId };
            user = req.user;
          }
        }
      }

      if (!user || user.disabled) {
        return res.status(401).json({
          status: 'error',
          statusCode: 401,
          code: 'UNAUTHORIZED',
          type: 'https://dustguard.vn/errors/UNAUTHORIZED',
          title: 'Unauthorized',
          detail: 'Vui lòng đăng nhập để tiếp tục.',
          instance: req.originalUrl || req.url,
          error: 'Vui lòng đăng nhập để tiếp tục.',
          message: 'Vui lòng đăng nhập để tiếp tục.',
          timestamp: new Date().toISOString()
        });
      }

      const currentRole = (user.role || user.primaryRole || 'citizen').toLowerCase();
      const userRoles = Array.isArray(user.roles) ? user.roles.map(r => r.toLowerCase()) : [currentRole];
      const isBypass = currentRole === 'admin' || currentRole === 'super_admin' || currentRole === 'demo_admin' ||
        userRoles.includes('admin') || userRoles.includes('super_admin') || userRoles.includes('demo_admin');

      const isAllowed = allowedRoles.length === 0 || isBypass || allowedRoles.some(r => userRoles.includes(r) || currentRole === r);

      if (!isAllowed) {
        return res.status(403).json({
          status: 'error',
          statusCode: 403,
          code: 'FORBIDDEN',
          type: 'https://dustguard.vn/errors/FORBIDDEN',
          title: 'Forbidden',
          detail: 'Bạn không có quyền thực hiện thao tác này.',
          instance: req.originalUrl || req.url,
          error: 'Bạn không có quyền thực hiện thao tác này.',
          message: 'Bạn không có quyền thực hiện thao tác này.',
          timestamp: new Date().toISOString()
        });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

export function scopeByOrganization(user, records) {
  if (!user) return [];
  if (user.role === 'admin' || user.role === 'super_admin' || user.role === 'demo_admin') return records;
  if (!user.organizationId) return records;
  return records.filter(r => !r.organizationId || r.organizationId === user.organizationId);
}
