import { logAuditEvent } from '../lib/auditLogger.js';
import { getSessionFromRequest, normalizeAuthUser } from '../auth.js';
import logger, { maskSensitiveData } from '../lib/logger.js';

export { maskSensitiveData };

/**
 * Helper to determine action name from request path and method
 */
function getActionName(req) {
  if (req.auditAction) return req.auditAction;

  const method = req.method;
  const path = req.originalUrl.split('?')[0]; // E.g. /api/sites/123/resolve -> ['api', 'sites', '123', 'resolve']
  const parts = path.split('/').filter(Boolean);

  let resource = 'UNKNOWN';
  let subAction = '';

  if (parts[0] === 'api' && parts[1]) {
    resource = parts[1].toUpperCase();
    if (parts.length > 3) {
      subAction = `_${parts[parts.length - 1].toUpperCase()}`;
    }
  } else if (parts[0]) {
    resource = parts[0].toUpperCase();
  }

  // Normalize plural resource names
  if (resource.endsWith('S') && resource !== 'STATUS' && resource !== 'PROCESS') {
    resource = resource.slice(0, -1);
  }
  
  resource = resource.replace(/[-_]/g, '_');

  switch (method) {
    case 'POST':
      return `CREATE_${resource}${subAction}`;
    case 'PUT':
    case 'PATCH':
      return `UPDATE_${resource}${subAction}`;
    case 'DELETE':
      return `DELETE_${resource}${subAction}`;
    default:
      return `${method}_${resource}${subAction}`;
  }
}

/**
 * Middleware to automatically audit log successful data modifying operations (POST, PUT, PATCH, DELETE)
 */
export async function autoAuditMiddleware(req, res, next) {
  // We only track state-modifying requests (POST, PUT, PATCH, DELETE)
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    return next();
  }

  // Intercept res.json to capture response body (helpful to extract auto-generated IDs)
  const originalJson = res.json;
  let responseBody = null;

  res.json = function (body) {
    responseBody = body;
    return originalJson.apply(res, arguments);
  };

  res.on('finish', async () => {
    // Only log if the request was successful (2xx status codes)
    if (res.statusCode >= 200 && res.statusCode < 300) {
      try {
        // 1. Resolve user details
        let userId = req.user?.id;
        let actorName = req.user?.full_name || req.user?.name;
        let actorRole = req.user?.role;

        if (!userId) {
          // If req.user is not populated yet, try parsing from active session headers
          try {
            const session = await getSessionFromRequest(req);
            const user = normalizeAuthUser(session?.user);
            if (user) {
              userId = user.id;
              actorName = user.full_name || user.name;
              actorRole = user.role;
            }
          } catch (err) {
            // Ignore error
          }
        }

        // 2. Resolve target record ID
        let targetId = req.params?.id || req.body?.id || null;
        if (!targetId && responseBody) {
          if (responseBody.data && responseBody.data.id) {
            targetId = responseBody.data.id;
          } else if (responseBody.id) {
            targetId = responseBody.id;
          }
        }

        // Fallback: search URL path for a UUID / alphanumeric ID (longer than 10 characters)
        if (!targetId) {
          const parts = req.originalUrl.split('?')[0].split('/').filter(Boolean);
          for (const part of parts) {
            if (part !== 'api' && part !== 'auth' && part.length > 10) {
              targetId = part;
              break;
            }
          }
        }

        // 3. Resolve Audit Action Name
        const action = getActionName(req);

        // 4. Sanitize Request Body & Query (recursive deep redact sensitive values)
        const sanitizedBody = maskSensitiveData(req.body);
        const sanitizedQuery = maskSensitiveData(req.query);

        // 5. Build Audit Details Object
        const detailsObj = {
          url: req.originalUrl,
          method: req.method,
          body: sanitizedBody,
          query: sanitizedQuery,
          responseStatus: res.statusCode,
          responseMessage: responseBody?.message || null
        };

        // 6. Record Audit Log using helper
        await logAuditEvent({
          actorId: userId,
          actorName,
          actorRole,
          action,
          targetId,
          details: detailsObj
        }, req);

      } catch (err) {
        logger.error('[autoAuditMiddleware] Error writing audit log', { error: err.message, stack: err.stack });
      }
    }
  });

  next();
}
