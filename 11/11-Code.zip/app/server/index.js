import './env.js';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { fileURLToPath } from 'url';
import path, { dirname } from 'path';
import { randomUUID } from 'crypto';
import { prisma } from './shared/db.js';
import { SEED_SITES } from '../src/lib/seedData.js';
import logger from './lib/logger.js';
import { errorResponse, formatZodError } from './lib/response.js';
import { startAlertEngineScheduler } from './services/alert-engine.service.js';
import { startSensorSimulator } from './lib/sensorSimulator.js';
import { startSlaScheduler } from './services/caseSlaChecker.js';
import { getCached, setCached } from './lib/cache.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();

// ── Security headers ──
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdnjs.cloudflare.com", "https://unpkg.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://unpkg.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:", "https://*.tile.openstreetmap.org", "https://unpkg.com", "https://*"],
      connectSrc: ["'self'", "https://*.tile.openstreetmap.org", "https://*"],
    },
  },
}));

// ── Rate limiters ──
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 'RATE_LIMIT', error: 'Quá nhiều yêu cầu, vui lòng thử lại sau.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 'RATE_LIMIT', error: 'Quá nhiều lần thử đăng nhập, vui lòng thử lại sau.' },
});

const aiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 'RATE_LIMIT', error: 'Đã vượt giới hạn AI, vui lòng thử lại sau.' },
});

if (process.env.NODE_ENV === 'production') {
  app.use('/api/', generalLimiter);
  app.use('/api/auth/', authLimiter);
  app.use('/api/ai/', aiLimiter);
}

app.use(cors());
app.use(express.json());

// Request ID tracking — attach unique ID to every request
app.use((req, res, next) => { req.id = randomUUID(); next(); });

import { autoAuditMiddleware } from './middleware/audit.js';
import { clerkExpressMiddleware } from './auth/human/clerk.middleware.js';

app.use(autoAuditMiddleware);
app.use(clerkExpressMiddleware());

import userRoutes from './routes/api/users.js';
import siteRoutes from './routes/api/sites.js';
import aiRoutes from './routes/api/ai.js';
import complaintRoutes from './routes/api/complaints.js';
import inspectionRoutes from './routes/api/inspections.js';
import actionRoutes from './routes/api/actions.js';
import documentRoutes from './routes/api/documents.js';
import legalRoutes from './routes/api/legal.js';
import caseRoutes from './routes/api/cases.js';
import authRoutes from './routes/auth.js';
import feedbackRoutes from './routes/feedback.js';
import checklistRoutes from './routes/checklists.js';
// import procurementRoutes from './routes/procurement.js';
import dashboardRoutes from './routes/api/dashboard.js';
import alertRoutes from './routes/api/alerts.js';
import staffAlertsRoutes from './routes/api/staff-alerts.js';
import staffSitesRoutes from './routes/api/staff-sites.js';
import staffCasesRoutes from './routes/api/staff-cases.js';
import staffTasksRoutes from './routes/api/staff-tasks.js';
import staffReportsRoutes from './routes/api/staff-reports.js';
import staffNotificationsRoutes from './routes/api/staff-notifications.js';
import staffSettingsRoutes from './routes/api/staff-settings.js';
import sensorRoutes from './routes/api/sensors.js';
import publicRoutes from './routes/api/public.js';
import csrRoutes from './routes/api/csr.js';
import contractorRoutes from './routes/api/contractor.js';
import executiveRoutes from './routes/api/executive.js';
import youthRoutes from './routes/api/youth.js';
import campaignRoutes from './routes/api/campaigns.js';
import communityRoutes from './routes/api/community.js';
import communityAdminRoutes from './routes/api/community-admin.js';
import taskRoutes from './routes/api/tasks.js';
import systemRoutes from './routes/api/system.routes.js';
import automationRoutes from './routes/api/automation.routes.js';
import { auth, authHandler } from './auth.js';

app.all(/^\/api\/auth\/(?!(login|register|logout|me|providers|sign-in\/social)\/?$).*/, authHandler);
app.use(['/api/auth', '/api/v1/auth'], authRoutes);

// Aliases for core auth endpoints
app.post(['/api/login', '/api/v1/login'], (req, res, next) => { req.url = '/login'; authRoutes(req, res, next); });
app.post(['/api/register', '/api/v1/register'], (req, res, next) => { req.url = '/register'; authRoutes(req, res, next); });
app.get(['/api/me', '/api/v1/me'], (req, res, next) => { req.url = '/me'; authRoutes(req, res, next); });
app.post(['/api/logout', '/api/v1/logout'], (req, res, next) => { req.url = '/logout'; authRoutes(req, res, next); });
app.get(['/api/providers', '/api/v1/providers'], (req, res, next) => { req.url = '/providers'; authRoutes(req, res, next); });

app.use(['/api/users', '/api/v1/users'], userRoutes);
app.use(['/api/citizen', '/api/v1/citizen'], userRoutes);
app.use(['/api/sites', '/api/v1/sites'], siteRoutes);
app.use(['/api/staff/sites', '/api/v1/staff/sites'], staffSitesRoutes);
app.use(['/api/staff/cases', '/api/v1/staff/cases'], staffCasesRoutes);
app.use(['/api/staff/tasks', '/api/v1/staff/tasks'], staffTasksRoutes);
app.use(['/api/staff/reports', '/api/v1/staff/reports'], staffReportsRoutes);
app.use(['/api/staff/notifications', '/api/v1/staff/notifications'], staffNotificationsRoutes);
app.use(['/api/staff/settings', '/api/v1/staff/settings'], staffSettingsRoutes);
app.use(['/api/ai', '/api/v1/ai'], aiRoutes);
app.use(['/api/complaints', '/api/v1/complaints'], complaintRoutes);
app.use('/api/public-complaints', complaintRoutes);
app.use(['/api/inspections', '/api/v1/inspections'], inspectionRoutes);
app.use(['/api/actions', '/api/v1/actions'], actionRoutes);
app.use(['/api/tasks', '/api/v1/tasks'], taskRoutes);
app.use(['/api/documents', '/api/v1/documents'], documentRoutes);
app.use(['/api/legal-documents', '/api/v1/legal-documents', '/api/legal', '/api/v1/legal'], legalRoutes);
app.use(['/api/cases', '/api/v1/cases'], caseRoutes);
app.use(['/api/feedback', '/api/v1/feedback'], feedbackRoutes);
app.use(['/api/dashboard', '/api/v1/dashboard'], dashboardRoutes);
app.use(['/api/executive', '/api/v1/executive'], executiveRoutes);
app.use(['/api/alerts', '/api/v1/alerts'], alertRoutes);
app.use(['/api/staff/alerts', '/api/v1/staff/alerts'], staffAlertsRoutes);
app.use(['/api/sensors', '/api/v1/sensors'], sensorRoutes);
app.use(['/api/staff/monitoring', '/api/v1/staff/monitoring'], sensorRoutes);
app.post(['/api/telemetry', '/api/v1/telemetry'], (req, res, next) => { req.url = '/telemetry'; sensorRoutes(req, res, next); });
app.use(['/api/checklists', '/api/v1/checklists'], checklistRoutes);
// app.use('/api/procurement-documents', procurementRoutes);
app.use(['/api/public', '/api/v1/public'], publicRoutes);
app.use(['/api/csr', '/api/v1/csr'], csrRoutes);
app.use(['/api/contractor', '/api/v1/contractor'], contractorRoutes);
app.use(['/api/youth', '/api/v1/youth'], youthRoutes);
app.use(['/api/campaigns', '/api/v1/campaigns'], campaignRoutes);
app.use(['/api/community', '/api/v1/community'], communityRoutes);
app.use(['/api/admin/community', '/api/v1/admin/community'], communityAdminRoutes);
app.use(['/api/admin/system', '/api/v1/admin/system'], systemRoutes);
app.use(['/api/automation', '/api/v1/automation'], automationRoutes);


app.post(['/api/map/demo/reset', '/api/v1/map/demo/reset'], (req, res) => {
  const { clearCache } = require ? {} : {};
  import('./lib/cache.js').then(({ clearCache }) => clearCache('map:'));
  res.json({ status: 'success', message: 'Đặt lại dữ liệu demo bản đồ thành công' });
});

// Swagger & OpenAPI 3.0 Endpoints
app.get(['/api/docs/openapi.json', '/openapi.json'], async (req, res) => {
  const { openApiSpec } = await import('./docs/openapi.spec.js');
  res.json(openApiSpec);
});

app.get(['/api-docs', '/docs', '/api/docs'], async (req, res) => {
  const { renderSwaggerHtml } = await import('./docs/swagger-ui.html.js');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(renderSwaggerHtml('/api/docs/openapi.json'));
});


// /api/config — lightweight config probe (AI provider, feature flags)
app.get('/api/config', async (req, res) => {
  try {
    const { getAiCapabilities } = await import('./lib/aiService.js');
    const caps = getAiCapabilities();
    res.json({
      status: 'success',
      data: {
        aiProvider: caps.provider || 'none',
        aiConfigured: !!(caps.apiKey || caps.provider),
        capabilities: caps,
      }
    });
  } catch (err) {
    res.json({ status: 'success', data: { aiProvider: 'none', aiConfigured: false, capabilities: {} } });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    // Run a fast raw query to check database connectivity
    await prisma.$queryRaw`SELECT 1`;
    res.json({
      ok: true,
      status: 'healthy',
      database: 'connected',
      timestamp: new Date()
    });
  } catch (error) {
    logger.error('Health check failed', { error: error.message });
    res.status(500).json({
      ok: false,
      status: 'unhealthy',
      database: 'disconnected',
      error: error.message,
      timestamp: new Date()
    });
  }
});

app.get('/api/health/db', async (req, res) => {
  try {
    // Test database connection
    await prisma.$queryRaw`SELECT 1`;
    
    // Count records in tables using prisma
    const siteCount = await prisma.site.count().catch(() => null);
    const complaintCount = await prisma.complaint.count().catch(() => null);
    const inspectionCount = await prisma.inspection.count().catch(() => null);
    const actionCount = await prisma.action.count().catch(() => null);
    const evidenceCount = await prisma.evidence.count().catch(() => null);
    
    res.json({
      ok: true,
      status: 'healthy',
      database: 'connected',
      timestamp: new Date(),
      counts: {
        sites: siteCount,
        complaints: complaintCount,
        inspections: inspectionCount,
        actions: actionCount,
        evidences: evidenceCount
      }
    });
  } catch (error) {
    logger.error('DB Health check failed', { error: error.message });
    res.status(500).json({
      ok: false,
      status: 'unhealthy',
      database: 'disconnected',
      error: error.message,
      timestamp: new Date()
    });
  }
});

function parseCoordinatesStrict(rawCoords) {
  if (!rawCoords) return { lat: null, lng: null };
  if (typeof rawCoords === 'object') {
    const lat = typeof rawCoords.lat === 'number' ? rawCoords.lat : parseFloat(rawCoords.lat || rawCoords.latitude);
    const lng = typeof rawCoords.lng === 'number' ? rawCoords.lng : parseFloat(rawCoords.lng || rawCoords.longitude);
    return {
      lat: !isNaN(lat) && lat >= -90 && lat <= 90 ? lat : null,
      lng: !isNaN(lng) && lng >= -180 && lng <= 180 ? lng : null
    };
  }
  if (typeof rawCoords === 'string') {
    const trimmed = rawCoords.trim();
    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        const lat = typeof parsed.lat === 'number' ? parsed.lat : parseFloat(parsed.lat || parsed.latitude);
        const lng = typeof parsed.lng === 'number' ? parsed.lng : parseFloat(parsed.lng || parsed.longitude);
        if (!isNaN(lat) && !isNaN(lng)) {
          return {
            lat: lat >= -90 && lat <= 90 ? lat : null,
            lng: lng >= -180 && lng <= 180 ? lng : null
          };
        }
      } catch {}
    }
    const parts = trimmed.split(',').map(p => parseFloat(p.trim()));
    if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      const lat = parts[0];
      const lng = parts[1];
      return {
        lat: lat >= -90 && lat <= 90 ? lat : null,
        lng: lng >= -180 && lng <= 180 ? lng : null
      };
    }
  }
  return { lat: null, lng: null };
}

app.get(['/api/map', '/api/public/map/features', '/api/spatial/features', '/api/spatial/entities', '/api/v1/map', '/api/v1/spatial/features', '/api/v1/spatial/entities'], async (req, res) => {
  try {
    const { bbox, layers, risk, ward, district, status } = req.query;

    let bboxBounds = null;
    if (bbox && typeof bbox === 'string') {
      const parts = bbox.split(',').map(p => parseFloat(p.trim()));
      if (parts.length === 4 && parts.every(p => !isNaN(p))) {
        bboxBounds = {
          minLng: parts[0],
          minLat: parts[1],
          maxLng: parts[2],
          maxLat: parts[3]
        };
      }
    }

    const [dbSites, dbSensors, dbComplaints, dbReadings] = await Promise.all([
      prisma.site.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          code: true,
          name: true,
          address: true,
          ward: true,
          coordinates: true,
          dustRiskScore: true,
          riskLevel: true,
          status: true
        }
      }).catch(() => []),
      prisma.sensor.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          code: true,
          name: true,
          siteId: true,
          coordinates: true,
          status: true
        }
      }).catch(() => []),
      prisma.complaint.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          code: true,
          title: true,
          address: true,
          ward: true,
          coordinates: true,
          status: true,
          riskScore: true,
          category: true,
          createdAt: true
        },
        orderBy: { createdAt: 'desc' },
        take: 100
      }).catch(() => []),
      prisma.sensorReading.findMany({
        select: {
          sensorId: true,
          pm25: true,
          aqi: true,
          timestamp: true
        },
        orderBy: { timestamp: 'desc' },
        take: 100
      }).catch(() => [])
    ]);

    const latestReadingMap = {};
    for (const r of dbReadings) {
      if (!latestReadingMap[r.sensorId]) {
        latestReadingMap[r.sensorId] = r;
      }
    }

    let highRiskCount = 0;
    let warningCount = 0;
    let safeCount = 0;
    let activeSensorsCount = 0;
    let recentReportsCount = dbComplaints.length;
    let resolvedCount = dbComplaints.filter(c => c.status === 'RESOLVED').length;

    // Process Sites — strictly real coordinates or null
    let sites = (dbSites.length > 0 ? dbSites : SEED_SITES).map((site, idx) => {
      const coords = parseCoordinatesStrict(site.coordinates);
      const lat = coords.lat;
      const lng = coords.lng;

      const score = site.dustRiskScore || (site.riskLevel === 'HIGH' ? 82 : site.riskLevel === 'MEDIUM' ? 60 : 35);
      const isHigh = score >= 75 || site.riskLevel === 'CRITICAL' || site.riskLevel === 'HIGH';
      const isMed = score >= 45 && score < 75;
      const tier = isHigh ? 'red' : isMed ? 'amber' : 'green';
      const riskLevel = isHigh ? 'HIGH' : isMed ? 'MEDIUM' : 'LOW';

      if (isHigh) highRiskCount++;
      else if (isMed) warningCount++;
      else safeCount++;

      return {
        id: site.id || `SITE-${idx + 1}`,
        code: site.code || `SITE-${idx + 1}`,
        name: site.name || `Công trình xây dựng đô thị #${idx + 1}`,
        address: site.address || 'Quận Cầu Giấy, Hà Nội',
        ward: site.ward || 'Cầu Giấy',
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        pm25: Math.round(score * 0.95),
        dustRiskScore: score,
        riskLevel,
        tier,
        status: site.status || (isHigh ? 'INSPECTING' : 'NORMAL'),
        complaintsCount: isHigh ? 3 : 1
      };
    });

    const totalSitesCount = sites.length;
    const mappedSitesCount = sites.filter(s => s.hasLocation).length;
    const missingLocationCount = totalSitesCount - mappedSitesCount;

    // Optional BBox filtering
    if (bboxBounds) {
      sites = sites.filter(s => s.lat != null && s.lng != null && s.lng >= bboxBounds.minLng && s.lng <= bboxBounds.maxLng && s.lat >= bboxBounds.minLat && s.lat <= bboxBounds.maxLat);
    }

    // Process Sensors — strictly real coordinates or null
    let sensors = (dbSensors.length > 0 ? dbSensors : [
      { id: 'SENS-01', code: 'DG-HN-012', name: 'Trạm quan trắc Cầu Giấy', coordinates: '21.0335,105.7860', status: 'ONLINE', pm25: 82 },
      { id: 'SENS-02', code: 'DG-HN-018', name: 'Trạm quan trắc Mai Dịch', coordinates: '21.0380,105.7790', status: 'ONLINE', pm25: 48 },
      { id: 'SENS-03', code: 'DG-NTL-004', name: 'Trạm quan trắc Mỹ Đình', coordinates: '21.0210,105.7740', status: 'ONLINE', pm25: 36 },
      { id: 'SENS-04', code: 'DG-TH-009', name: 'Trạm quan trắc Trung Hòa', coordinates: '21.0120,105.7980', status: 'ONLINE', pm25: 64 }
    ]).map((sens, idx) => {
      const coords = parseCoordinatesStrict(sens.coordinates || (sens.lat != null && sens.lng != null ? { lat: sens.lat, lng: sens.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;

      const reading = latestReadingMap[sens.id] || latestReadingMap[sens.code] || {};
      const pm25 = sens.pm25 !== undefined ? sens.pm25 : (reading.pm25 !== undefined ? reading.pm25 : 42);
      const isOnline = sens.status === 'ONLINE' || !sens.status;
      if (isOnline) activeSensorsCount++;

      return {
        id: sens.id || `SENS-${idx}`,
        code: sens.code || `SENSOR-0${idx + 1}`,
        siteId: sens.siteId || null,
        name: sens.name || `Trạm quan trắc ${sens.code || idx + 1}`,
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        pm25: Math.round(pm25),
        status: isOnline ? 'ONLINE' : 'OFFLINE',
        lastSeen: '2 phút trước',
        trend: pm25 > 65 ? 'UP' : pm25 < 35 ? 'DOWN' : 'STABLE'
      };
    });

    if (bboxBounds) {
      sensors = sensors.filter(s => s.lat != null && s.lng != null && s.lng >= bboxBounds.minLng && s.lng <= bboxBounds.maxLng && s.lat >= bboxBounds.minLat && s.lat <= bboxBounds.maxLat);
    }

    // Process Reports (Zero PII) — strictly real coordinates or null
    let reports = (dbComplaints.length > 0 ? dbComplaints : [
      { id: 'REP-01', code: 'DG-2026-F54A', title: 'Xe chở phế thải không che bạt gây bụi', address: 'Đường Vành Đai 3, Cầu Giấy', coordinates: '21.0315,105.7845', status: 'IN_PROGRESS' },
      { id: 'REP-02', code: 'DG-2026-M102', title: 'Công trường đào móng không phun nước', address: 'Số 18 Phạm Hùng, Nam Từ Liêm', coordinates: '21.0225,105.7765', status: 'RESOLVED' },
      { id: 'REP-03', code: 'DG-2026-K882', title: 'Bụi phát tán từ trạm trộn bê tông', address: 'Ngõ 124 Hoàng Quốc Việt, Cầu Giấy', coordinates: '21.0450,105.7920', status: 'IN_PROGRESS' }
    ]).map((c, idx) => {
      const coords = parseCoordinatesStrict(c.coordinates || (c.lat != null && c.lng != null ? { lat: c.lat, lng: c.lng } : null));
      const lat = coords.lat;
      const lng = coords.lng;

      return {
        id: c.id || `REP-${idx}`,
        code: c.code || `DG-PA-${1000 + idx}`,
        title: c.title || 'Phát sinh bụi tại khu vực',
        address: c.address || 'Cầu Giấy, Hà Nội',
        ward: c.ward || 'Cầu Giấy',
        lat,
        lng,
        hasLocation: lat != null && lng != null,
        status: c.status || 'PENDING',
        riskScore: c.riskScore || 65,
        category: c.category || 'DUST_EMISSION',
        createdAt: c.createdAt || new Date().toISOString()
      };
    });

    if (bboxBounds) {
      reports = reports.filter(r => r.lat != null && r.lng != null && r.lng >= bboxBounds.minLng && r.lng <= bboxBounds.maxLng && r.lat >= bboxBounds.minLat && r.lat <= bboxBounds.maxLat);
    }

    // Hotspots from sites with REAL coordinates
    const hotspots = sites.filter(s => s.dustRiskScore >= 70 && s.lat != null && s.lng != null).slice(0, 4).map((s, idx) => ({
      id: `HOTSPOT-${idx + 1}`,
      name: `Điểm nóng ${s.ward || 'Hà Nội'} #${idx + 1}`,
      lat: s.lat,
      lng: s.lng,
      radius: 400 + idx * 50,
      severity: s.dustRiskScore >= 80 ? 'CRITICAL' : 'HIGH',
      score: s.dustRiskScore,
      reason: `${s.complaintsCount || 3} phản ánh trong 24h · PM2.5 vượt ngưỡng QCVN`
    }));

    // Missions
    const missions = [
      {
        id: 'MISSION-01',
        title: 'Giám sát bụi quanh trường THPT Cầu Giấy',
        ward: 'Cầu Giấy',
        lat: 21.0335,
        lng: 105.7915,
        requiredVolunteers: 6,
        currentVolunteers: 4,
        status: 'ACTIVE',
        organizer: 'Đoàn TN ĐHQGHN'
      },
      {
        id: 'MISSION-02',
        title: 'Khảo sát nồng độ bụi công trường Vành đai 3',
        ward: 'Nam Từ Liêm',
        lat: 21.0180,
        lng: 105.7760,
        requiredVolunteers: 8,
        currentVolunteers: 7,
        status: 'ACTIVE',
        organizer: 'CLB Môi trường Xanh'
      }
    ];

    const result = {
      sites,
      constructions: sites,
      sensors,
      reports,
      hotspots,
      missions,
      summary: {
        total: totalSitesCount,
        mapped: mappedSitesCount,
        missingLocation: missingLocationCount,
        highRiskCount: highRiskCount || 3,
        warningCount: warningCount || 2,
        safeCount: safeCount || 1,
        activeSensorsCount: activeSensorsCount || sensors.length,
        recentReportsCount: recentReportsCount || reports.length,
        resolvedCount: resolvedCount || 1
      }
    };

    res.json({
      status: 'success',
      data: result
    });
  } catch (error) {
    logger.error('API Map Error', { requestId: req.id, error: error.message });
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Spatial Location Management: Geocode Proxy & Landmark Directory
app.get('/api/spatial/geocode', async (req, res) => {
  try {
    const q = req.query.q;
    if (!q || typeof q !== 'string' || q.trim().length < 2) {
      return res.json({ status: 'success', data: [] });
    }
    // Return standard response structure
    res.json({
      status: 'success',
      data: []
    });
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});

// Spatial Location Correction / Update Endpoint
app.patch('/api/spatial/entities/:type/:id/location', async (req, res) => {
  try {
    const { type, id } = req.params;
    const { lat, lng, formattedAddress, source, accuracyMeters, reason } = req.body;

    if (lat == null || lng == null || isNaN(Number(lat)) || isNaN(Number(lng))) {
      return res.status(400).json({ status: 'error', message: 'Tọa độ không hợp lệ.' });
    }

    const numLat = Number(lat);
    const numLng = Number(lng);
    if (numLat < -90 || numLat > 90 || numLng < -180 || numLng > 180) {
      return res.status(400).json({ status: 'error', message: 'Tọa độ ngoài dải chuẩn WGS84.' });
    }

    const coordsStr = `${numLat.toFixed(6)},${numLng.toFixed(6)}`;

    if (type === 'site' || type === 'sites') {
      await prisma.site.update({
        where: { id },
        data: {
          coordinates: coordsStr,
          ...(formattedAddress ? { address: formattedAddress } : {})
        }
      });
    } else if (type === 'sensor' || type === 'sensors') {
      await prisma.sensor.update({
        where: { id },
        data: {
          coordinates: coordsStr
        }
      });
    } else if (type === 'complaint' || type === 'complaints' || type === 'report') {
      await prisma.complaint.update({
        where: { id },
        data: {
          coordinates: coordsStr,
          ...(formattedAddress ? { address: formattedAddress } : {})
        }
      });
    }

    // Append Audit Log
    await prisma.auditLog.create({
      data: {
        action: 'SPATIAL_LOCATION_UPDATED',
        targetId: id,
        details: JSON.stringify({
          entityType: type,
          entityId: id,
          coordinates: coordsStr,
          formattedAddress,
          source: source || 'ADMIN_CORRECTION',
          accuracyMeters,
          reason: reason || 'Cập nhật tọa độ thực tế'
        })
      }
    }).catch(() => {});

    res.json({
      status: 'success',
      data: {
        id,
        type,
        lat: numLat,
        lng: numLng,
        coordinates: coordsStr,
        formattedAddress,
        updatedAt: new Date().toISOString()
      }
    });
  } catch (err) {
    logger.error('Update Spatial Location Error', { error: err.message });
    res.status(500).json({ status: 'error', message: err.message });
  }
});

app.get('/api/dashboard/stats', async (req, res) => {
  try {
    const cacheKey = 'dashboard:stats';
    const cached = getCached(cacheKey);
    if (cached) {
      return res.json({
        status: 'success',
        data: cached
      });
    }

    const totalSites = await prisma.site.count();
    const activeSites = await prisma.site.count({
      where: { status: 'ACTIVE' }
    });
    const highRiskSites = await prisma.site.count({
      where: { riskLevel: { in: ['HIGH', 'CRITICAL'] } }
    });
    const resolvedIssues = await prisma.action.count({
      where: { status: 'VERIFIED' }
    });

    const result = {
      totalSites,
      activeSites,
      highRiskSites,
      resolvedIssues
    };

    setCached(cacheKey, result, 3000); // cache 3 giây
    res.json({
      status: 'success',
      data: result
    });
  } catch (error) {
    logger.error('API Dashboard Stats Error', { requestId: req.id, error: error.message });
    res.status(500).json({ status: 'error', message: error.message });
  }
});

const distPath = path.join(__dirname, '../dist');
app.use('/uploads', express.static(path.join(__dirname, '../public/uploads')));
app.use(express.static(distPath));

app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

// Centralized error handling middleware
app.use((err, req, res, next) => {
  const reqId = req.id || req.headers['x-request-id'] || undefined;
  logger.error(`API Error${reqId ? ` [${reqId}]` : ''}`, { error: err.message || String(err) });

  // ZodError → 400 with user-friendly field messages
  if (err.name === 'ZodError') {
    const { message, fieldErrors } = formatZodError(err);
    return errorResponse(res, message, 400, fieldErrors);
  }

  // Prisma P2025 (Record not found) → 404 Not Found
  if (err.code === 'P2025') {
    return errorResponse(res, err.message || 'Không tìm thấy dữ liệu yêu cầu', 404);
  }

  // AppError / known status codes
  if (err.statusCode || err.status) {
    const statusCode = err.statusCode || err.status;
    return errorResponse(res, err.message, statusCode, err.details || null);
  }

  // Fallback 500 — don't leak internal details
  const safeMessage = process.env.NODE_ENV === 'production'
    ? 'Internal Server Error'
    : (err.message || 'Internal Server Error');
  return errorResponse(res, safeMessage, 500);
});

async function seedDemoUsersOnStartup() {
  try {
    const users = [
      { email: 'admin@dustguard.vn', password: '123456', name: 'Quản trị viên Hệ thống', role: 'admin' },
      { email: 'staff@dustguard.vn', password: '123456', name: 'Cán bộ Thanh tra', role: 'staff' },
      { email: 'executive@dustguard.vn', password: '123456', name: 'Lãnh đạo Cơ quan', role: 'executive' },
      { email: 'citizen@dustguard.vn', password: '123456', name: 'Công dân Báo cáo', role: 'citizen' },
      { email: 'contractor@dustguard.vn', password: '123456', name: 'Đại diện Nhà thầu', role: 'contractor' }
    ];

    logger.info('Checking/seeding demo users...');
    const context = await auth.$context;
    const passwordHash = await context.password.hash('123456');

    for (const u of users) {
      try {
        const existing = await prisma.user.findUnique({ where: { email: u.email } });
        if (!existing) {
          // Register user via better-auth api
          const res = await auth.api.signUpEmail({
            body: {
              email: u.email,
              password: u.password,
              name: u.name,
            }
          });
          logger.info(`✅ Seeded demo user: ${u.email}`);
          
          // Set role
          await prisma.user.update({
            where: { email: u.email },
            data: { role: u.role }
          });
          
          // Seed profile
          await prisma.profile.create({
            data: {
              userId: res.user.id,
              fullName: u.name,
              phoneNumber: '0987654321',
              department: u.role === 'staff' ? 'Phòng Thanh tra Môi trường' : u.role === 'executive' ? 'UBND Quận Cầu Giấy' : u.role === 'contractor' ? 'Tổng công ty XD số 1' : 'Cộng đồng'
            }
          });
        } else {
          // User exists, make sure password and role are reset
          await prisma.user.update({
            where: { email: u.email },
            data: { role: u.role }
          });
          
          await prisma.account.updateMany({
            where: {
              userId: existing.id,
              providerId: 'credential'
            },
            data: {
              password: passwordHash
            }
          });
        }
      } catch (userErr) {
        logger.error(`Error seeding/resetting demo user ${u.email}:`, { error: userErr.message });
      }
    }
    logger.info('Demo users checking/seeding complete.');
  } catch (err) {
    logger.error('Failed to seed demo users on startup:', { error: err.message });
  }
}

// Khởi động scheduler quét cảm biến tự động (định kỳ mỗi 60 giây)
const isMain = process.argv[1] && (
  process.argv[1] === fileURLToPath(import.meta.url) ||
  process.argv[1].endsWith('server/index.js') ||
  process.argv[1].endsWith('server\\index.js')
);

if (isMain) {
  startAlertEngineScheduler(60000);
  startSlaScheduler(1800000);

  const port = Number(process.env.PORT || 3001);
  
  // Seed demo users on startup in non-production environments
  if (process.env.NODE_ENV !== 'production') {
    seedDemoUsersOnStartup().catch(err => {
      logger.error('Error seeding demo users on startup', { error: err.message });
    });
  }

  app.listen(port, '0.0.0.0', () => {
    logger.info('Server started', { port, url: `http://localhost:${port}` });
    startSensorSimulator(30000);
  });
}

export default app;
