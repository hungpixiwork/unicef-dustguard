import {
  getSystemDataStats,
  previewResetCounts,
  executeSystemReset,
  seedCanonicalData
} from '../services/system-data.service.js';
import { getAuditLogs } from '../repositories/audit.repository.js';
import { successResponse, errorResponse } from '../lib/response.js';

export async function handleGetDataStats(req, res) {
  try {
    const stats = await getSystemDataStats(req.dbClient || req.env);
    return successResponse(res, stats, 'Thống kê dữ liệu D1 thành công');
  } catch (error) {
    return errorResponse(res, error.message, error.statusCode || 500);
  }
}

export async function handleResetPreview(req, res) {
  try {
    const preview = await previewResetCounts(req.dbClient || req.env);
    return successResponse(res, preview, 'Xem trước thông số xóa dữ liệu thành công');
  } catch (error) {
    return errorResponse(res, error.message, error.statusCode || 500);
  }
}

export async function handleResetData(req, res) {
  try {
    const { mode, deleteStoredFiles, confirmation } = req.body || {};
    const actor = req.user || { id: 'admin', name: 'Quản trị viên', role: 'admin' };
    
    const result = await executeSystemReset({
      mode,
      deleteStoredFiles,
      confirmation,
      actor,
      env: req.env || req.dbClient
    });

    return successResponse(res, result, 'Thiết lập lại dữ liệu hệ thống thành công');
  } catch (error) {
    return errorResponse(res, error.message, error.statusCode || 500, error.code);
  }
}

export async function handleSeedDemo(req, res) {
  try {
    const actor = req.user || { id: 'admin', name: 'Quản trị viên', role: 'admin' };
    const result = await seedCanonicalData({ actor, env: req.env || req.dbClient });
    return successResponse(res, result, 'Khởi tạo dữ liệu mẫu chuẩn hóa thành công');
  } catch (error) {
    return errorResponse(res, error.message, error.statusCode || 500);
  }
}

export async function handleGetAuditLogs(req, res) {
  try {
    const { entityType, entityId, actorId, action, page, pageSize } = req.query || {};
    const result = await getAuditLogs({
      entityType,
      entityId,
      actorId,
      action,
      page: Number(page) || 1,
      pageSize: Number(pageSize) || 50
    }, req.dbClient || req.env);

    return successResponse(res, result, 'Lấy lịch sử Audit Trail thành công');
  } catch (error) {
    return errorResponse(res, error.message, error.statusCode || 500);
  }
}
