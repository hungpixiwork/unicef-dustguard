import { createHash } from 'crypto';
import { successResponse, errorResponse } from '../lib/response.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { safeJsonParse } from '../lib/jsonHelper.js';
import { prisma } from '../shared/db.js';
import { transitionCaseStatus } from '../services/case.service.js';
import { getCached, setCached, clearCache } from '../lib/cache.js';

// Helper to determine risk tier
function getRiskTier(riskLevel) {
  if (riskLevel === 'CRITICAL' || riskLevel === 'HIGH') return 'red';
  if (riskLevel === 'MEDIUM') return 'amber';
  return 'green';
}

export const getExecutiveDashboard = async (req, res, next) => {
  try {
    const cacheKey = 'dashboard:executive';
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Lấy dữ liệu điều hành thành công (cached)');
    }

    const [sites, complaints, actions, draftDocs, auditLogs, cases] = await Promise.all([
      prisma.site.findMany({
        include: {
          complaints: true,
          inspections: true,
          actions: true
        }
      }),
      prisma.complaint.findMany(),
      prisma.action.findMany({
        include: { site: true }
      }),
      prisma.draftDocument.findMany({
        where: {
          status: { in: ['DRAFT', 'EXPORTED', 'SUBMITTED'] }
        },
        include: { site: true },
        orderBy: { createdAt: 'desc' }
      }),
      prisma.auditLog.findMany({
        take: 50,
        orderBy: { createdAt: 'desc' }
      }),
      prisma.case.findMany({
        include: { site: true },
        orderBy: { createdAt: 'desc' }
      })
    ]);

    // 1. Calculate General KPIs
    const totalSites = sites.length;
    const highRiskSites = sites.filter(s => s.riskLevel === 'HIGH' || s.riskLevel === 'CRITICAL').length;
    const amberSites = sites.filter(s => s.riskLevel === 'MEDIUM').length;
    const greenSites = sites.filter(s => s.riskLevel === 'LOW').length;

    const totalComplaints = complaints.length;
    const newComplaints = complaints.filter(c => c.status === 'PENDING').length;
    const resolvedComplaints = complaints.filter(c => c.status === 'RESOLVED' || c.status === 'REJECTED').length;
    const resolutionRate = totalComplaints ? Math.round((resolvedComplaints / totalComplaints) * 100) : 0;

    const totalRiskScore = sites.reduce((sum, s) => sum + (s.dustRiskScore || 0), 0);
    const averageRiskScore = totalSites ? Math.round(totalRiskScore / totalSites) : 0;

    const now = new Date();
    const overdueActions = actions.filter(a => 
      a.dueDate && 
      new Date(a.dueDate) < now && 
      a.status !== 'VERIFIED' && 
      a.status !== 'COMPLETED' &&
      a.status !== 'PENDING_VERIFICATION'
    ).length;

    // SLA On-Time Rate: verified actions completed before/on due date
    const verifiedActions = actions.filter(a => a.status === 'VERIFIED');
    const onTimeVerified = verifiedActions.filter(a => !a.dueDate || new Date(a.updatedAt) <= new Date(a.dueDate)).length;
    const slaOnTimeRate = verifiedActions.length ? Math.round((onTimeVerified / verifiedActions.length) * 100) : 100;

    // 7-step process KPIs
    const totalCases = cases.length;
    const casesScreening = cases.filter(c => c.status === 'PENDING' || c.status === 'SCREENING' || c.status === 'OPEN').length;
    const casesPreparing = cases.filter(c => c.status === 'PREPARING').length;
    const casesDecisionIssued = cases.filter(c => c.status === 'DECISION_ISSUED').length;
    const casesOnSite = cases.filter(c => c.status === 'ON_SITE').length;
    const casesReporting = cases.filter(c => c.status === 'REPORTING').length;
    const casesAppraising = cases.filter(c => c.status === 'APPRAISING').length;
    const casesCompleted = cases.filter(c => c.status === 'COMPLETED' || c.status === 'CLOSED').length;
    const casesProcessing = casesPreparing + casesDecisionIssued + casesOnSite + casesReporting;

    // 2. Ward Data for Heatmap & District Ranking
    // Group sites & complaints by ward
    const wardMap = new Map();
    
    // Seed default wards if DB has no data to prevent blank screen
    const defaultWards = ['Yên Hòa', 'Mộ Lao', 'Trung Hòa', 'Láng Hạ', 'Kim Mã'];
    defaultWards.forEach(wName => {
      wardMap.set(wName, {
        name: wName,
        totalSites: 0,
        highRiskSites: 0,
        amberSites: 0,
        activeSites: 0,
        totalReports: 0,
        scoreTotal: 0,
        overdueActions: 0
      });
    });

    // Populate from actual sites
    sites.forEach(site => {
      const ward = site.ward || 'Chưa phân loại';
      if (!wardMap.has(ward)) {
        wardMap.set(ward, {
          name: ward,
          totalSites: 0,
          highRiskSites: 0,
          amberSites: 0,
          activeSites: 0,
          totalReports: 0,
          scoreTotal: 0,
          overdueActions: 0
        });
      }
      const data = wardMap.get(ward);
      data.totalSites += 1;
      if (site.status === 'ACTIVE') data.activeSites += 1;
      if (site.riskLevel === 'HIGH' || site.riskLevel === 'CRITICAL') {
        data.highRiskSites += 1;
      } else if (site.riskLevel === 'MEDIUM') {
        data.amberSites += 1;
      }
      data.scoreTotal += site.dustRiskScore || 0;
    });

    // Populate from actual complaints
    complaints.forEach(c => {
      const ward = c.ward;
      if (ward) {
        if (!wardMap.has(ward)) {
          wardMap.set(ward, {
            name: ward,
            totalSites: 0,
            highRiskSites: 0,
            amberSites: 0,
            activeSites: 0,
            totalReports: 0,
            scoreTotal: 0,
            overdueActions: 0
          });
        }
        wardMap.get(ward).totalReports += 1;
      }
    });

    // Populate actual action records
    actions.forEach(a => {
      if (a.site && a.dueDate && new Date(a.dueDate) < now && a.status !== 'VERIFIED' && a.status !== 'COMPLETED' && a.status !== 'PENDING_VERIFICATION') {
        const ward = a.site.ward;
        if (ward && wardMap.has(ward)) {
          wardMap.get(ward).overdueActions += 1;
        }
      }
    });

    const wardData = Array.from(wardMap.values()).map(ward => {
      const avgRisk = ward.totalSites ? Math.round(ward.scoreTotal / ward.totalSites) : 0;
      const maxPm10Val = Math.round(50 + avgRisk * 1.8);
      
      // Compute status label based on risk score
      let status = 'An toàn';
      if (avgRisk > 80) status = 'Báo động đỏ';
      else if (avgRisk > 60) status = 'Nguy cơ cao';
      else if (avgRisk > 40) status = 'Cảnh báo';
      else if (avgRisk > 20) status = 'Trung bình';

      // Deterministic trend based on ward name hash
      const trendVal = ward.name && ward.name.length > 0
        ? ((ward.name.charCodeAt(0) + ward.name.charCodeAt(ward.name.length - 1)) % 30) - 15
        : 0;
      const trend = trendVal >= 0 ? `+${trendVal}%` : `${trendVal}%`;

      return {
        name: ward.name,
        avgRisk,
        maxPm10: `${maxPm10Val} µg/m³`,
        totalReports: ward.totalReports,
        activeSites: ward.activeSites,
        highRiskSites: ward.highRiskSites,
        amberSites: ward.amberSites,
        overdueActions: ward.overdueActions,
        status,
        trend
      };
    }).sort((a, b) => b.avgRisk - a.avgRisk);

    // 3. Province Ranking (For compatibility with existing layout components)
    // Map wards/provinces to province level
    const provinceMap = new Map();
    sites.forEach(site => {
      const prov = site.province || 'TP. Hà Nội';
      if (!provinceMap.has(prov)) {
        provinceMap.set(prov, {
          province: prov,
          totalSites: 0,
          highRiskSites: 0,
          amberSites: 0,
          complaints: 0,
          scoreTotal: 0,
          overdueActions: 0
        });
      }
      const data = provinceMap.get(prov);
      data.totalSites += 1;
      if (site.riskLevel === 'HIGH' || site.riskLevel === 'CRITICAL') data.highRiskSites += 1;
      if (site.riskLevel === 'MEDIUM') data.amberSites += 1;
      data.scoreTotal += site.dustRiskScore || 0;
      data.complaints += site.complaints ? site.complaints.length : 0;
    });

    // Populate overdue actions to provinces
    actions.forEach(a => {
      if (a.site && a.dueDate && new Date(a.dueDate) < now && a.status !== 'VERIFIED' && a.status !== 'COMPLETED' && a.status !== 'PENDING_VERIFICATION') {
        const prov = a.site.province || 'TP. Hà Nội';
        if (provinceMap.has(prov)) {
          provinceMap.get(prov).overdueActions += 1;
        }
      }
    });

    const provinceRanking = Array.from(provinceMap.values()).map(p => ({
      ...p,
      avgRisk: p.totalSites ? Math.round(p.scoreTotal / p.totalSites) : 0
    })).sort((a, b) => b.avgRisk - a.avgRisk);

    // 4. Priority Sites (Top 8 highest risk sites)
    const prioritySites = sites
      .map(s => {
        const sensitive = (s.address || '').includes('Trường') || (s.address || '').includes('Bệnh viện') || (s.address || '').includes('Trường học');
        return {
          id: s.id,
          name: s.name,
          province: s.province || 'TP. Hà Nội',
          ward: s.ward,
          score: s.dustRiskScore,
          tier: getRiskTier(s.riskLevel),
          complaints: s.complaints ? s.complaints.length : 0,
          reason: [
            `${s.dustRiskScore} điểm rủi ro`,
            s.riskLevel === 'CRITICAL' ? 'Nguy hiểm cực độ' : s.riskLevel === 'HIGH' ? 'Rủi ro cao' : null,
            sensitive ? 'gần khu nhạy cảm' : null
          ].filter(Boolean).join(' · ')
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);

    // 5. Deadline Alerts (Actions overdue or near due)
    const deadlineAlerts = actions
      .filter(a => a.dueDate && a.status !== 'VERIFIED' && a.status !== 'COMPLETED' && a.status !== 'PENDING_VERIFICATION')
      .map(a => {
        const msDiff = new Date(a.dueDate).getTime() - now.getTime();
        const hoursLeft = Math.ceil(msDiff / (1000 * 60 * 60));
        return {
          id: a.id,
          siteId: a.siteId,
          name: a.site ? a.site.name : 'Công trường',
          hoursLeft: Math.max(0, hoursLeft),
          tier: a.site ? getRiskTier(a.site.riskLevel) : 'amber',
          inspector: a.assignee || 'Chưa phân công',
          action: a.title
        };
      })
      .sort((a, b) => a.hoursLeft - b.hoursLeft)
      .slice(0, 8);

    // 6. Format Audit Logs
    const formattedAuditLogs = auditLogs.map(log => {
      let parsedDetails = {};
      if (log.details) {
        parsedDetails = safeJsonParse(log.details);
        if (!parsedDetails || typeof parsedDetails !== 'object') {
          parsedDetails = { raw: log.details };
        }
      }

      return {
        id: log.id,
        userId: log.userId,
        action: log.action,
        createdAt: log.createdAt,
        actorName: parsedDetails.actorName || 'Hệ thống',
        actorRole: parsedDetails.actorRole || 'system',
        details: parsedDetails
      };
    });

    // 7. Format Draft Documents awaiting signature
    const formattedDrafts = draftDocs.map(doc => {
      const meta = safeJsonParse(doc.metadata, {});

      return {
        id: doc.id,
        siteId: doc.siteId,
        siteName: doc.site ? doc.site.name : 'Công trường',
        documentType: doc.documentType,
        title: doc.title,
        content: doc.content,
        status: doc.status,
        createdAt: doc.createdAt,
        officerName: meta?.officer?.name || 'Thanh tra viên'
      };
    });

    const formattedCases = cases.map(c => ({
      id: c.id,
      code: c.code,
      title: c.title,
      status: c.status,
      siteId: c.siteId,
      siteName: c.site ? c.site.name : 'Công trường',
      description: c.description || 'Chưa có mô tả chi tiết',
      createdAt: c.createdAt
    }));

    const result = {
      kpis: {
        totalSites,
        highRiskSites,
        highRiskClusters: provinceRanking.filter(p => p.highRiskSites > 0).length,
        totalComplaints,
        newComplaints,
        resolutionRate,
        averageRiskScore,
        overdueActions,
        slaOnTimeRate,
        totalCases,
        casesScreening,
        casesPreparing,
        casesDecisionIssued,
        casesOnSite,
        casesReporting,
        casesAppraising,
        casesCompleted,
        casesProcessing
      },
      wardData,
      provinceRanking,
      prioritySites,
      deadlineAlerts,
      draftDocuments: formattedDrafts,
      cases: formattedCases,
      auditLogs: formattedAuditLogs,
      riskTrend: sites.length > 0 
        ? sites.map(s => s.dustRiskScore || 0).slice(0, 7)
        : [averageRiskScore]
    };

    setCached(cacheKey, result, 3000); // cache 3 giây
    return successResponse(res, result, 'Lấy dữ liệu điều hành thành công');

  } catch (error) {
    next(error);
  }
};

export const quickSignDocument = async (req, res, next) => {
  try {
    const { id } = req.params;
    const draft = await prisma.draftDocument.findUnique({
      where: { id },
      include: { site: true }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy tài liệu/biên bản cần phê duyệt.', 404);
    }

    // Generate SHA-256 digital signature hash
    const signatureInput = `${draft.title}-${new Date().getTime()}-${req.user?.id || 'system'}`;
    const hash = createHash('sha256').update(signatureInput).digest('hex');

    const updated = await prisma.draftDocument.update({
      where: { id },
      data: {
        status: 'SIGNED',
        hash,
        signedAt: new Date(),
        approvedById: req.user?.id
      }
    });

    // If linked to a Case, update the SanctionDecision, transition status if APPRAISING, and log timeline event
    if (draft.caseId) {
      const caseItem = await prisma.case.findUnique({
        where: { id: draft.caseId }
      });

      const actor = {
        id: req.user?.id || 'system',
        name: req.user?.fullName || req.user?.name || 'Lãnh đạo',
        role: req.user?.role || 'executive'
      };

      if (caseItem && caseItem.status === 'APPRAISING') {
        await transitionCaseStatus(draft.caseId, 'COMPLETED', actor, {
          note: `Lãnh đạo phê duyệt thẩm định kết quả và ký số ban hành quyết định chính thức. Mã tài liệu liên kết: DOC-${id.slice(0, 8).toUpperCase()}`
        });
      }

      const activeDecision = await prisma.sanctionDecision.findFirst({
        where: {
          caseId: draft.caseId,
          status: 'PENDING'
        }
      });

      if (activeDecision) {
        await prisma.sanctionDecision.update({
          where: { id: activeDecision.id },
          data: {
            status: 'SENT',
            issuedAt: new Date()
          }
        });

        // Add event to Case timeline
        await prisma.caseTimeline.create({
          data: {
            caseId: draft.caseId,
            eventType: 'DOCUMENT_APPROVED',
            eventTitle: 'Phê duyệt & Ký số quyết định',
            eventDescription: `Quyết định xử phạt số ${activeDecision.decisionNumber} đã được phê duyệt và ký số bởi Lãnh đạo (${actor.name}). Hash băm SHA256: ${hash.substring(0, 16)}...`,
            actorId: actor.id,
            actorName: actor.name,
            actorRole: actor.role
          }
        });
      }
    }

    // Log to audit log
    await logAuditEvent({
      actorId: req.user?.id,
      actorName: req.user?.fullName || req.user?.name,
      actorRole: req.user?.role || 'executive',
      action: 'LEADER_SIGN_DOCUMENT',
      details: {
        documentId: id,
        documentTitle: draft.title,
        siteId: draft.siteId,
        siteName: draft.site?.name || 'Công trường',
        hash
      }
    }, req);

    // Clear cache
    clearCache('dashboard:');

    return successResponse(res, { draft: updated, hash }, 'Phê duyệt ký số biên bản thành công!');
  } catch (error) {
    next(error);
  }
};
