import { z } from 'zod';
import crypto from 'node:crypto';
import { successResponse, errorResponse, parsePaginationParams } from '../lib/response.js';
import { scanSensorsAndTriggerAlerts, checkAlertSLA } from '../services/alert-engine.service.js';
import { runSensorAudit } from '../services/sensor-audit.service.js';
import { prisma } from '../shared/db.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { getCached, setCached, clearCache } from '../lib/cache.js';

/**
 * Lấy danh sách cảnh báo (có lọc & phân trang)
 */
export const getAlerts = async (req, res, next) => {
  try {
    const { siteId, status, isOverdue } = req.query;
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    
    // Đảm bảo cập nhật trạng thái SLA quá hạn trước khi trả danh sách
    await checkAlertSLA();

    const where = {};
    if (siteId) {
      where.siteId = siteId;
    }
    if (status) {
      where.status = status;
    } else if (isOverdue === 'true') {
      where.status = 'OVERDUE';
    }

    const [total, alerts] = await Promise.all([
      prisma.alert.count({ where }),
      prisma.alert.findMany({
        where,
        orderBy: { triggeredAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          site: true,
          sensor: true,
          notifications: true
        }
      })
    ]);

    return successResponse(res, {
      items: alerts,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách cảnh báo bụi & SLA');
  } catch (error) {
    next(error);
  }
};


/**
 * Thống kê các chỉ số SLA của cảnh báo
 */
export const getAlertStats = async (req, res, next) => {
  try {
    const cacheKey = 'alerts:stats';
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Thống kê chỉ số SLA cảnh báo (cached)');
    }

    // Cập nhật trạng thái quá hạn trước khi thống kê
    await checkAlertSLA();

    const total = await prisma.alert.count();
    const pending = await prisma.alert.count({ where: { status: 'PENDING' } });
    const inProgress = await prisma.alert.count({ where: { status: 'IN_PROGRESS' } });
    const resolved = await prisma.alert.count({ where: { status: 'RESOLVED' } });
    const overdue = await prisma.alert.count({ where: { status: 'OVERDUE' } });

    // Tính tỷ lệ đúng hạn SLA: các cảnh báo RESOLVED mà resolvedAt <= slaDeadline
    const resolvedAlerts = await prisma.alert.findMany({
      where: { status: 'RESOLVED' }
    });

    let metSlaCount = 0;
    let totalResolutionTimeMs = 0;

    resolvedAlerts.forEach(alert => {
      const resolvedAt = alert.resolvedAt ? new Date(alert.resolvedAt) : new Date();
      const slaDeadline = new Date(alert.slaDeadline);
      const triggeredAt = new Date(alert.triggeredAt);

      if (resolvedAt <= slaDeadline) {
        metSlaCount++;
      }
      
      totalResolutionTimeMs += (resolvedAt.getTime() - triggeredAt.getTime());
    });

    const slaComplianceRate = resolvedAlerts.length > 0 
      ? Math.round((metSlaCount / resolvedAlerts.length) * 100) 
      : 100;

    const avgResolutionHours = resolvedAlerts.length > 0
      ? parseFloat(((totalResolutionTimeMs / resolvedAlerts.length) / (1000 * 60 * 60)).toFixed(1))
      : 0;

    // Lấy top 5 công trường bị nhiều cảnh báo nhất
    const sitesWithAlerts = await prisma.alert.groupBy({
      by: ['siteId'],
      _count: {
        id: true
      },
      orderBy: {
        _count: {
          id: 'desc'
        }
      },
      take: 5
    });

    // Giải quyết N+1 query: lấy thông tin của top siteIds trong một câu truy vấn duy nhất
    const siteIds = sitesWithAlerts.map(item => item.siteId).filter(Boolean);
    const sites = await prisma.site.findMany({
      where: { id: { in: siteIds } },
      select: { id: true, name: true }
    });
    const siteMap = new Map(sites.map(s => [s.id, s.name]));

    const topViolatingSites = sitesWithAlerts.map(item => ({
      siteId: item.siteId,
      siteName: siteMap.get(item.siteId) || 'Không xác định',
      alertCount: item._count.id
    })).filter(s => s.siteName !== 'Không xác định');

    const result = {
      total,
      pending,
      inProgress,
      resolved,
      overdue,
      slaComplianceRate,
      avgResolutionHours,
      topViolatingSites
    };

    setCached(cacheKey, result, 3000); // cache 3 giây
    return successResponse(res, result, 'Thống kê chỉ số SLA cảnh báo');
  } catch (error) {
    next(error);
  }
};

/**
 * Đánh dấu cảnh báo đã khắc phục (RESOLVED) hoặc chuyển sang IN_PROGRESS
 */
export const updateAlertStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['IN_PROGRESS', 'RESOLVED'].includes(status)) {
      return res.status(400).json({ status: 'error', message: 'Trạng thái chuyển đổi không hợp lệ. Chỉ chấp nhận IN_PROGRESS hoặc RESOLVED.' });
    }

    const alert = await prisma.alert.findUnique({
      where: { id },
      include: { site: true }
    });

    if (!alert) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy cảnh báo.' });
    }

    const now = new Date();
    const updateData = { status };
    
    if (status === 'RESOLVED') {
      updateData.resolvedAt = now;
      
      // Nếu đã quá deadline thì vẫn ghi nhận RESOLVED nhưng log audit
      const slaDeadline = new Date(alert.slaDeadline);
      if (now > slaDeadline) {
        // Cảnh báo này thực chất đã quá hạn SLA, nhưng được giải quyết muộn
        console.log(`[Alert Controller] Alert ${id} giải quyết muộn sau deadline.`);
      }
    }

    const updatedAlert = await prisma.alert.update({
      where: { id },
      data: updateData
    });

    // Thêm log audit hành động
    await logAuditEvent({
      action: `ALERT_RESOLVE_${status}`,
      targetId: alert.id,
      details: {
        siteName: alert.site.name,
        previousStatus: alert.status,
        newStatus: status,
        resolvedAt: status === 'RESOLVED' ? now : null
      }
    }, req);

    // Clear cache
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, updatedAlert, `Cập nhật trạng thái cảnh báo thành ${status} thành công`);
  } catch (error) {
    next(error);
  }
};

/**
 * Trigger quét cảm biến thủ công từ giao diện
 */
export const triggerAlertScan = async (req, res, next) => {
  try {
    const alertsCount = await scanSensorsAndTriggerAlerts();

    // Clear cache
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, { triggeredAlerts: alertsCount }, `Quét cảm biến hoàn tất. Đã kích hoạt ${alertsCount} cảnh báo mới.`);
  } catch (error) {
    next(error);
  }
};

/**
 * Mô phỏng đẩy dữ liệu vi phạm của cảm biến (PM10 > 150 liên tục 20 phút)
 */
export const simulateViolation = async (req, res, next) => {
  try {
    // Kill switch guard
    if (process.env.ENABLE_SENSOR_SIMULATOR === 'false') {
      return res.status(503).json({
        status: 'error',
        code: 'KILL_SWITCH_ACTIVE',
        message: 'Sensor simulator is temporarily disabled by kill switch.'
      });
    }

    const { sensorId } = req.body;

    if (!sensorId) {
      return res.status(400).json({ status: 'error', message: 'sensorId là bắt buộc' });
    }

    const sensor = await prisma.sensor.findUnique({
      where: { id: sensorId },
      include: { site: true }
    });

    if (!sensor) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy cảm biến' });
    }

    // Tạo 5 bản ghi readings có PM10 > 150 µg/m³ trong 20 phút qua (mỗi bản ghi cách nhau 5 phút)
    const now = new Date();
    const readingsCreated = [];

    for (let i = 0; i < 5; i++) {
      const timestamp = new Date(now.getTime() - (20 - i * 5) * 60 * 1000); // 20, 15, 10, 5, 0 phút trước
      const pm10 = 160 + crypto.randomInt(5, 45); // PM10 dao động từ 165 -> 205
      const pm25 = 80 + crypto.randomInt(5, 25);

      const reading = await prisma.sensorReading.create({
        data: {
          sensorId,
          pm10,
          pm25,
          timestamp
        }
      });
      readingsCreated.push(reading);
    }

    // Ghi nhận hành động audit log
    await logAuditEvent({
      action: 'SENSOR_VIOLATION_SIMULATED',
      targetId: sensor.id,
      details: {
        sensorCode: sensor.code,
        siteName: sensor.site.name,
        simulatedReadingsCount: readingsCreated.length
      }
    }, req);

    // Sau khi mô phỏng xong, tự động trigger scan luôn để người dùng thấy kết quả tức thì
    const triggeredAlerts = await scanSensorsAndTriggerAlerts();

    // Clear cache
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, { 
      simulatedReadings: readingsCreated.length,
      triggeredAlerts
    }, `Mô phỏng dữ liệu vi phạm thành công cho cảm biến ${sensor.code} và đã kích hoạt quét.`);
  } catch (error) {
    next(error);
  }
};

/**
 * Lấy danh sách tất cả các cảm biến đang hoạt động
 */
export const getActiveSensors = async (req, res, next) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    const [total, sensors] = await Promise.all([
      prisma.sensor.count({ where: { status: 'ACTIVE' } }),
      prisma.sensor.findMany({
        where: { status: 'ACTIVE' },
        skip: offset,
        take: limit,
        include: { site: true }
      })
    ]);
    return successResponse(res, {
      items: sensors,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách cảm biến hoạt động');
  } catch (error) {
    next(error);
  }
};

/**
 * Lấy danh sách các cảm biến nghi vấn / lỗi / mất kết nối (frauds)
 */
export const getSuspiciousSensors = async (req, res, next) => {
  try {
    // Run background audit to ensure data is updated
    await runSensorAudit().catch(err => {
      console.error('[Alert Controller] Error running sensor audit on demand:', err);
    });

    // Check permissions
    if (req.user && !['staff', 'executive', 'admin'].includes(req.user.role)) {
      return res.status(403).json({
        status: 'error',
        code: 'FORBIDDEN',
        message: 'Bạn không có quyền truy cập thông tin cảm biến nghi vấn.'
      });
    }

    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    const where = { status: { in: ['FAULTY', 'INACTIVE'] } };

    const [total, suspiciousSensors] = await Promise.all([
      prisma.sensor.count({ where }),
      prisma.sensor.findMany({
        where,
        skip: offset,
        take: limit,
        include: {
          site: true,
          readings: {
            orderBy: { timestamp: 'desc' },
            take: 5
          }
        },
        orderBy: { updatedAt: 'desc' }
      })
    ]);

    const sensorIds = suspiciousSensors.map(s => s.id);
    const auditLogs = sensorIds.length > 0 ? await prisma.auditLog.findMany({
      where: {
        targetId: { in: sensorIds },
        action: { in: ['SENSOR_TAMPER_SUSPECTED', 'SENSOR_LIVENESS_TIMEOUT', 'SENSOR_RECOVERED'] }
      },
      orderBy: { createdAt: 'desc' }
    }) : [];

    const latestAuditLogMap = new Map();
    for (const log of auditLogs) {
      if (log.targetId && !latestAuditLogMap.has(log.targetId)) {
        latestAuditLogMap.set(log.targetId, log);
      }
    }

    const items = suspiciousSensors.map((sensor) => {
      const latestReading = sensor.readings[0] || null;
      const latestAuditLog = latestAuditLogMap.get(sensor.id) || null;

      let fraudType = 'UNKNOWN';
      let fraudReason = 'Chưa xác định';
      let confidence = 0.5;

      if (latestAuditLog) {
        if (latestAuditLog.action === 'SENSOR_TAMPER_SUSPECTED') {
          fraudType = 'FLATLINE_DETECTED';
          fraudReason = 'Chỉ số không đổi (Flatline) trong thời gian dài';
          confidence = 0.95;
        } else if (latestAuditLog.action === 'SENSOR_LIVENESS_TIMEOUT') {
          fraudType = 'LIVENESS_TIMEOUT';
          fraudReason = 'Mất tín hiệu kết nối > 15 phút';
          confidence = 0.99;
        }
      }

      return {
        id: sensor.id,
        name: sensor.name || sensor.code,
        code: sensor.code,
        sensorCode: sensor.code,
        siteId: sensor.siteId,
        site: sensor.site,
        siteName: sensor.site ? sensor.site.name : 'Chưa gắn',
        siteAddress: sensor.site ? sensor.site.address : '',
        status: sensor.status,
        updatedAt: sensor.updatedAt,
        fraudType,
        fraudReason,
        confidence,
        lastReadings: sensor.readings || [],
        latestReading: latestReading ? {
          pm10: latestReading.pm10,
          pm25: latestReading.pm25,
          timestamp: latestReading.timestamp
        } : null,
        recentReadings: sensor.readings.map(r => ({
          pm10: r.pm10,
          pm25: r.pm25,
          timestamp: r.timestamp
        })),
        latestAuditLog: latestAuditLog ? {
          id: latestAuditLog.id,
          action: latestAuditLog.action,
          createdAt: latestAuditLog.createdAt,
          details: latestAuditLog.details ? (() => { try { return JSON.parse(latestAuditLog.details); } catch { return null; } })() : null
        } : null,
        auditEvent: latestAuditLog ? {
          action: latestAuditLog.action,
          createdAt: latestAuditLog.createdAt,
          details: latestAuditLog.details ? (() => { try { return JSON.parse(latestAuditLog.details); } catch { return null; } })() : null
        } : null
      };
    });


    return successResponse(res, {
      items,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách cảm biến nghi vấn / lỗi / mất kết nối');
  } catch (error) {
    next(error);
  }
};

/**
 * Mô phỏng đẩy dữ liệu gian lận / lỗi cảm biến
 */
export const simulateFraud = async (req, res, next) => {
  try {
    // Kill switch guard
    if (process.env.ENABLE_SENSOR_SIMULATOR === 'false') {
      return res.status(503).json({
        status: 'error',
        code: 'KILL_SWITCH_ACTIVE',
        message: 'Sensor simulator is temporarily disabled by kill switch.'
      });
    }

    const { sensorId, type } = req.body;


    if (!sensorId) {
      return res.status(400).json({ status: 'error', message: 'sensorId là bắt buộc' });
    }

    if (!type || !['flatline', 'timeout'].includes(type)) {
      return res.status(400).json({ status: 'error', message: 'type phải là flatline hoặc timeout' });
    }

    const sensor = await prisma.sensor.findUnique({
      where: { id: sensorId },
      include: { site: true }
    });

    if (!sensor) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy cảm biến' });
    }

    const now = new Date();
    let readingsCreatedCount = 0;
    let readingsDeletedCount = 0;

    if (type === 'flatline') {
      for (let i = 0; i < 5; i++) {
        const timestamp = new Date(now.getTime() - i * 9 * 60 * 1000);
        await prisma.sensorReading.create({
          data: {
            sensorId,
            pm10: 5.0,
            pm25: 2.0,
            timestamp
          }
        });
        readingsCreatedCount++;
      }
    } else if (type === 'timeout') {
      const fifteenMinutesAgo = new Date(now.getTime() - 15 * 60 * 1000);
      const deleteResult = await prisma.sensorReading.deleteMany({
        where: {
          sensorId,
          timestamp: {
            gte: fifteenMinutesAgo
          }
        }
      });
      readingsDeletedCount = deleteResult.count;

      const twentyMinutesAgo = new Date(now.getTime() - 20 * 60 * 1000);
      await prisma.sensorReading.create({
        data: {
          sensorId,
          pm10: 45.0,
          pm25: 22.0,
          timestamp: twentyMinutesAgo
        }
      });
      readingsCreatedCount = 1;
    }

    // Run sensor health audit
    await runSensorAudit();

    // Log SENSOR_VIOLATION_SIMULATED audit event
    await logAuditEvent({
      action: 'SENSOR_VIOLATION_SIMULATED',
      targetId: sensor.id,
      details: {
        sensorCode: sensor.code,
        siteName: sensor.site?.name,
        simulatedType: type,
        readingsCreatedCount,
        readingsDeletedCount
      }
    }, req);

    // Clear cache
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, {
      sensorId,
      type,
      readingsCreated: readingsCreatedCount,
      readingsDeleted: readingsDeletedCount
    }, `Mô phỏng thành công hành vi ${type} cho cảm biến ${sensor.code}`);
  } catch (error) {
    next(error);
  }
};

/**
 * Khôi phục trạng thái hoạt động của cảm biến về ACTIVE
 */
export const recoverSensor = async (req, res, next) => {
  try {
    const { id } = req.params;

    const sensor = await prisma.sensor.findUnique({
      where: { id },
      include: { site: true }
    });

    if (!sensor) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy cảm biến' });
    }

    const updatedSensor = await prisma.sensor.update({
      where: { id },
      data: { status: 'ACTIVE' }
    });

    const freshReading = await prisma.sensorReading.create({
      data: {
        sensorId: id,
        pm10: 28.0,
        pm25: 14.0,
        timestamp: new Date()
      }
    });

    await logAuditEvent({
      action: 'SENSOR_RECOVERED',
      targetId: id,
      details: {
        sensorCode: sensor.code,
        siteName: sensor.site?.name,
        message: 'Sensor status reset to ACTIVE with fresh reading'
      }
    }, req);

    // Clear cache
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(
      res,
      { sensor: updatedSensor, reading: freshReading },
      `Khôi phục trạng thái hoạt động thành công cho cảm biến ${sensor.code}`
    );
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/alerts
 * Tạo cảnh báo thủ công hoặc qua hệ thống
 */
export const createAlert = async (req, res, next) => {
  try {
    const { siteId, sensorId, level, type, message, slaDeadline } = req.body || {};
    if (!siteId || !message) {
      return errorResponse(res, 'siteId và message là bắt buộc', 400);
    }

    const alertLevel = level || 'MEDIUM';
    const alertType = type || 'AIR_QUALITY_WARNING';
    const deadline = slaDeadline ? new Date(slaDeadline) : new Date(Date.now() + 4 * 60 * 60 * 1000);

    const alert = await prisma.alert.create({
      data: {
        siteId,
        sensorId: sensorId || null,
        level: alertLevel,
        type: alertType,
        message,
        status: 'PENDING',
        slaDeadline: deadline,
        triggeredAt: new Date()
      },
      include: { site: true, sensor: true }
    });

    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, alert, 'Tạo cảnh báo thành công', 201);
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/alerts/:id
 * Lấy chi tiết một cảnh báo
 */
export const getAlertById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const alert = await prisma.alert.findUnique({
      where: { id },
      include: { site: true, sensor: true, notifications: true }
    });

    if (!alert) {
      return errorResponse(res, 'Không tìm thấy cảnh báo', 404);
    }

    return successResponse(res, alert, 'Chi tiết cảnh báo');
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/alerts/:id/ack
 * Tiếp nhận / Xác nhận cảnh báo (Acknowledge)
 */
export const ackAlert = async (req, res, next) => {
  try {
    const { id } = req.params;
    const alert = await prisma.alert.findUnique({ where: { id } });
    if (!alert) {
      return errorResponse(res, 'Không tìm thấy cảnh báo', 404);
    }

    const updated = await prisma.alert.update({
      where: { id },
      data: { status: 'IN_PROGRESS' }
    });

    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, updated, 'Tiếp nhận cảnh báo thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/alerts/:id
 * Xóa cảnh báo
 */
export const deleteAlert = async (req, res, next) => {
  try {
    const { id } = req.params;
    const alert = await prisma.alert.findUnique({ where: { id } });
    if (!alert) {
      return errorResponse(res, 'Không tìm thấy cảnh báo để xóa', 404);
    }

    await prisma.alert.delete({ where: { id } });
    clearCache('alerts:');
    clearCache('dashboard:');

    return successResponse(res, { id, deleted: true }, 'Xóa cảnh báo thành công');
  } catch (error) {
    next(error);
  }
};

