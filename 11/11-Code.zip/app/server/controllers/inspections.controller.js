import { z } from 'zod';
import { recalculateSiteRisk } from '../lib/riskEngine.js';
import { successResponse, errorResponse, formatZodError, parsePaginationParams } from '../lib/response.js';

import { logAuditEvent } from '../lib/auditLogger.js';
import { safeJsonParse } from '../lib/jsonHelper.js';
import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';
import { transitionCaseStatus } from '../services/case.service.js';
import { clearCache } from '../lib/cache.js';

const createInspectionSchema = z.object({
  siteId: z.string({ required_error: 'siteId là bắt buộc' }).min(1, 'siteId không được để trống'),
  inspectorId: z.string().optional().nullable(),
  inspector: z.string().optional().nullable(),
  findings: z.string().optional().nullable(),
  actionTaken: z.string().optional().nullable(),
  scoreDelta: z.coerce.number().int().optional(),
  evidences: z.array(z.string()).optional(),
  sourceComplaintId: z.string().optional().nullable(),
  overallScore: z.coerce.number().int().optional(),
  items: z.array(
    z.object({
      status: z.enum(['pass', 'fail', 'na'], {
        errorMap: () => ({ message: "Trạng thái hạng mục phải là 'pass', 'fail' hoặc 'na'" })
      }),
      title: z.string().optional().nullable(),
      k: z.string().optional().nullable(),
      notes: z.string().optional().nullable(),
      severity: z.string().optional().nullable(),
    })
  ).optional(),
});

export const createInspection = async (req, res, next) => {
  try {
    const validatedData = createInspectionSchema.safeParse(req.body);
    if (!validatedData.success) {
      const { message, fieldErrors } = formatZodError(validatedData.error);
      return errorResponse(res, message, 400, fieldErrors);
    }
    const { siteId, inspectorId, inspector, findings, actionTaken, scoreDelta, evidences, items, sourceComplaintId } = validatedData.data;

    // Determine findings string with enriched JSON payload
    let findingsData = {};
    if (findings) {
      if (typeof findings === 'string') {
        try {
          findingsData = JSON.parse(findings);
        } catch {
          findingsData = { text: findings };
        }
      } else if (typeof findings === 'object' && findings !== null) {
        findingsData = { ...findings };
      }
    }

    if (items && Array.isArray(items)) {
      if (typeof findingsData === 'object' && !Array.isArray(findingsData)) {
        findingsData.items = items;
        if (!findingsData.checklist) {
          const checklistMap = {};
          items.forEach(it => { if (it.k) checklistMap[it.k] = it.status; });
          findingsData.checklist = checklistMap;
        }
      } else {
        findingsData = { items, checklist: findingsData };
      }
    }

    const findingsString = JSON.stringify(findingsData);

    const inspection = await prisma.$transaction(async (tx) => {
      // 0. Verify site existence to prevent orphan inspection records
      const site = await tx.site.findFirst({
        where: {
          OR: [{ id: siteId }, { code: siteId }],
          deletedAt: null
        }
      });
      if (!site) {
        const err = new Error(`Không tìm thấy công trường với mã ${siteId}`);
        err.status = 404;
        throw err;
      }

      const effectiveInspectorId = (req.user?.role === 'admin' && (inspectorId || inspector))
        ? (inspectorId || inspector)
        : (req.user?.id || req.user?.fullName || req.user?.name || inspectorId || inspector || 'system-inspector');

      // 1. Create the inspection record
      const inspectionRecord = await tx.inspection.create({
        data: {
          siteId: site.id,
          inspectorId: effectiveInspectorId,
          findings: findingsString,
          actionTaken: actionTaken || 'Nhắc nhở và lập biên bản',
          scoreDelta: Number(scoreDelta || 0),
          sourceComplaintId: sourceComplaintId || null,
          evidences: evidences && evidences.length > 0 ? {
            create: evidences.map(url => ({
              url,
              type: 'IMAGE'
            }))
          } : undefined
        },
        include: {
          evidences: true,
          site: true
        }
      });

      // 1.5. If there is an active Case associated with the site, link the inspection to that Case
      const activeCase = await tx.case.findFirst({
        where: {
          siteId,
          status: {
            notIn: ['CLOSED', 'COMPLETED']
          }
        },
        orderBy: { createdAt: 'desc' }
      });

      if (activeCase) {
        await tx.case.update({
          where: { id: activeCase.id },
          data: {
            inspectionId: inspectionRecord.id
          }
        });

        // Log the inspection link event to the Case timeline
        await tx.caseTimeline.create({
          data: {
            caseId: activeCase.id,
            eventType: 'INSPECTION_LINKED',
            eventTitle: 'Liên kết biên bản kiểm tra',
            eventDescription: `Biên bản kiểm tra hiện trường (Mã: ${inspectionRecord.id}) đã được lập bởi ${req.user?.fullName || req.user?.name || 'Cán bộ'} và liên kết với vụ việc này.`,
            actorId: req.user?.id || null,
            actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
            actorRole: req.user?.role || 'staff'
          }
        });

        // Nếu có checklist bị lỗi: log vào timeline để cán bộ xem xét, KHÔNG tự động kết luận vi phạm.
        // Việc chuyển trạng thái VIOLATED phải do cán bộ có thẩm quyền thực hiện thủ công.
        if (items && Array.isArray(items)) {
          const failedItems = items.filter(item => item.status === 'fail');
          if (failedItems.length > 0) {
            const failedKeys = failedItems.map(item => item.k || item.title).filter(Boolean);

            const legalSegments = await tx.legalSegment.findMany({
              where: { checklistKey: { in: failedKeys } }
            });
            const legalNotes = legalSegments.map(s => `- ${s.citation}: ${s.content}`).join('\n');

            await tx.caseTimeline.create({
              data: {
                caseId: activeCase.id,
                eventType: 'INSPECTION_FAIL_DETECTED',
                eventTitle: 'Phát hiện hạng mục không đạt — chờ cán bộ xác nhận vi phạm',
                eventDescription: `Biên bản kiểm tra ghi nhận ${failedItems.length} hạng mục không đạt: ${failedKeys.join(', ')}.\nCăn cứ pháp lý tham chiếu:\n${legalNotes || 'Không có'}\n\nCán bộ cần xem xét và chuyển trạng thái vụ việc nếu xác nhận vi phạm.`,
                actorId: req.user?.id || null,
                actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
                actorRole: req.user?.role || 'staff'
              }
            });
          }
        }
      }

      // 2. If there were failed checklist items, automatically create corrective Actions!
      if (items && Array.isArray(items)) {
        const failedItems = items.filter(item => item.status === 'fail');
        for (const item of failedItems) {
          await tx.action.create({
            data: {
              title: `Khắc phục vi phạm: ${item.title || item.k}`,
              description: item.notes || `Yêu cầu khắc phục hạng mục ${item.title || item.k} không đạt tiêu chuẩn.`,
              status: 'PENDING',
              siteId,
              inspectionId: inspectionRecord.id,
              assignee: 'Nhà thầu chính',
              dueDate: new Date(Date.now() + 48 * 60 * 60 * 1000) // 48h deadline
            }
          });
        }
      }

      // 3. Update source complaint to PROCESSING (not RESOLVED — complaint is only resolved when case is fully closed)
      if (sourceComplaintId) {
        await tx.complaint.update({
          where: { id: sourceComplaintId },
          data: { status: 'PROCESSING' }
        }).catch(err => {
          logger.error('Failed to update source complaint status', { error: err.message });
        });
      }

      return inspectionRecord;
    }, { timeout: 15000 });

    // 4. Recalculate Site risk score using Risk Engine outside the interactive transaction
    try {
      await recalculateSiteRisk(inspection.siteId, prisma);
    } catch (riskErr) {
      logger.error('Error recalculating site risk during inspection', { error: riskErr.message });
    }

    // Log audit event for inspection creation
    await logAuditEvent({
      action: 'INSPECTION_CREATE',
      details: {
        inspectionId: inspection.id,
        siteId: inspection.siteId,
        findings: findingsString,
        actionTaken: inspection.actionTaken,
      }
    }, req);

    const responseData = {
      ...inspection,
      findings: safeJsonParse(inspection.findings)
    };

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');
    clearCache('inspections:');

    return successResponse(res, responseData, 'Tạo kiểm tra thành công', 201);
  } catch (error) {
    next(error);
  }
};

export const getInspections = async (req, res, next) => {
  try {
    const { siteId } = req.query;
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 20, 100);
    const where = { deletedAt: null };
    if (siteId) where.siteId = siteId;
    
    const [total, inspections] = await Promise.all([
      prisma.inspection.count({ where }),
      prisma.inspection.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          evidences: {
            where: { deletedAt: null }
          },
          site: {
            select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
          }
        }
      })
    ]);
    
    const parsedInspections = inspections.map(ins => ({
      ...ins,
      findings: safeJsonParse(ins.findings)
    }));
    
    return successResponse(res, {
      items: parsedInspections,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách kiểm tra');
  } catch (error) {
    next(error);
  }
};


export const getInspectionById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const ins = await prisma.inspection.findFirst({
      where: { id, deletedAt: null },
      include: {
        evidences: {
          where: { deletedAt: null }
        },
        site: {
          select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
        }
      }
    });
    if (!ins) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy biên bản kiểm tra' });
    }
    return successResponse(res, { ...ins, findings: safeJsonParse(ins.findings) }, 'Chi tiết biên bản kiểm tra');
  } catch (error) {
    next(error);
  }
};

export const aiAssistInspection = async (req, res, next) => {
  try {
    const { id } = req.params;
    const inspection = await prisma.inspection.findFirst({
      where: { id, deletedAt: null },
      include: {
        site: {
          select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
        }
      }
    });

    if (!inspection) {
      return res.status(404).json({ status: 'error', message: 'Không tìm thấy biên bản kiểm tra' });
    }

    const findings = safeJsonParse(inspection.findings, []);
    const failedItems = Array.isArray(findings) 
      ? findings.filter(f => f && (f.status === 'fail' || f.status === 'violated'))
      : [];

    const suggestions = [];
    if (failedItems.length > 0) {
      failedItems.forEach(item => {
        suggestions.push(`Khắc phục vi phạm hạng mục [${item.title || item.k || 'Kiểm soát bụi'}]: ${item.notes || 'Không đạt yêu cầu kỹ thuật'}`);
      });
    }

    if (inspection.site?.dustRiskScore > 100) {
      suggestions.push(`Công trường có điểm rủi ro bụi cao (${inspection.site.dustRiskScore}), yêu cầu tăng tần suất tưới nước và kích hoạt hệ thống rửa lốp xe.`);
    }

    if (suggestions.length === 0) {
      suggestions.push('Công trình đạt các tiêu chuẩn cơ bản. Duy trì giám sát định kỳ và rửa đường xe ra vào.');
    }

    return successResponse(res, {
      inspectionId: id,
      siteName: inspection.site?.name,
      failedCount: failedItems.length,
      suggestions
    }, 'Gợi ý xử lý thực tế cho biên bản kiểm tra');
  } catch (error) {
    next(error);
  }
};

/**
 * PUT / PATCH /api/inspections/:id
 * Cập nhật biên bản kiểm tra
 */
export const updateInspection = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { actionTaken, findings, scoreDelta } = req.body || {};

    const existing = await prisma.inspection.findFirst({
      where: { id, deletedAt: null }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy biên bản kiểm tra', 404);
    }

    const updateData = {};
    if (actionTaken !== undefined) updateData.actionTaken = actionTaken;
    if (scoreDelta !== undefined) updateData.scoreDelta = Number(scoreDelta);
    if (findings !== undefined) {
      updateData.findings = typeof findings === 'string' ? findings : JSON.stringify(findings);
    }

    const updated = await prisma.inspection.update({
      where: { id },
      data: updateData,
      include: {
        evidences: { where: { deletedAt: null } },
        site: { select: { name: true, address: true, riskLevel: true, dustRiskScore: true } }
      }
    });

    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('inspections:');

    return successResponse(res, { ...updated, findings: safeJsonParse(updated.findings) }, 'Cập nhật biên bản kiểm tra thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/inspections/:id
 * Xóa / Hủy biên bản kiểm tra (Soft delete)
 */
export const deleteInspection = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.inspection.findFirst({
      where: { id, deletedAt: null }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy biên bản kiểm tra để xóa', 404);
    }

    await prisma.inspection.update({
      where: { id },
      data: { deletedAt: new Date() }
    });

    // Recalculate site risk
    try {
      await recalculateSiteRisk(existing.siteId, prisma);
    } catch (riskErr) {
      logger.error('Error recalculating site risk after inspection deletion', { error: riskErr.message });
    }

    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('inspections:');

    return successResponse(res, { id, deleted: true }, 'Xóa biên bản kiểm tra thành công');
  } catch (error) {
    next(error);
  }
};


