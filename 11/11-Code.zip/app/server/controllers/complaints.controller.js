import { z } from 'zod';
import crypto from 'crypto';
import { callConfiguredLLM } from '../lib/aiService.js';
import { recalculateSiteRisk } from '../lib/riskEngine.js';
import { successResponse, errorResponse, parsePaginationParams } from '../lib/response.js';
import { logAuditEvent } from '../lib/auditLogger.js';

import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';
import { createCaseFromComplaint } from '../services/case.service.js';
import { clearCache } from '../lib/cache.js';
import { validateComplaintTransition, normalizeComplaintStatus } from '../domain/complaints/complaint.rules.js';
import { parseCoordinates, calculateHaversineDistanceMeters } from '../../src/lib/spatial/geo-utils.js';
import { analyzeSensitiveZoneBuffer } from '../../src/lib/spatial/spatial-clustering.js';

// Spatial Clustering & Sensitive Zone Intelligence Engine (SSOT)
// Bán kính gom cụm phản ánh trùng lặp (Tránh loãng nguồn lực cán bộ thanh tra khi
// nhiều người dân cùng chụp ảnh 1 điểm bụi).
const CLUSTER_RADIUS_METERS = 100;
// Chỉ gom cụm với các phản ánh còn "sống" (chưa xử lý xong) trong 72h gần nhất.
const CLUSTER_LOOKBACK_MS = 72 * 60 * 60 * 1000;
const RISK_LEVEL_RANK = { LOW: 0, MEDIUM: 1, HIGH: 2, CRITICAL: 3 };

/**
 * Tìm phản ánh "gốc" (chưa bị gộp) gần nhất trong bán kính CLUSTER_RADIUS_METERS để gom cụm.
 * @param {{lat:number,lng:number}} coords Tọa độ phản ánh mới
 * @returns {Promise<{id:string,code:string,siteId:string|null}|null>}
 */
async function findClusterPrimaryComplaint(coords) {
  const candidates = await prisma.complaint.findMany({
    where: {
      deletedAt: null,
      mergedInto: null,
      status: { in: ['PENDING', 'PROCESSING'] },
      latitude: { not: null },
      longitude: { not: null },
      createdAt: { gte: new Date(Date.now() - CLUSTER_LOOKBACK_MS) }
    },
    select: { id: true, code: true, siteId: true, latitude: true, longitude: true },
    take: 200
  });

  let nearest = null;
  let nearestDistance = Infinity;
  for (const candidate of candidates) {
    const dist = calculateHaversineDistanceMeters(coords.lat, coords.lng, candidate.latitude, candidate.longitude);
    if (Number.isFinite(dist) && dist <= CLUSTER_RADIUS_METERS && dist < nearestDistance) {
      nearestDistance = dist;
      nearest = candidate;
    }
  }
  return nearest;
}



function extractWard(address) {
  if (!address) return null;
  const addressLower = address.toLowerCase();
  const wards = ['Trung Hòa', 'Dịch Vọng Hậu', 'Dịch Vọng', 'Yên Hòa', 'Mai Dịch', 'Nghĩa Tân', 'Nghĩa Đô', 'Quan Hoa'];
  for (const w of wards) {
    if (addressLower.includes(w.toLowerCase())) {
      return w;
    }
  }
  return null;
}

function mapComplaintToFrontend(complaint, user = null) {
  if (!complaint) return null;
  let status = 'new';
  if (complaint.status) {
    const s = complaint.status.toLowerCase();
    if (s === 'pending' || s === 'new') status = 'new';
    else if (s === 'linked') status = 'linked';
    else if (s === 'processing' || s === 'investigating') status = 'investigating';
    else if (s === 'resolved') status = 'resolved';
    else if (s === 'rejected') status = 'rejected';
  }

  const userRole = (user?.role || user?.primaryRole || '').toLowerCase();
  const userRoles = (user?.roles || [userRole]).map(r => r.toLowerCase());
  const isStaffOrAdmin = user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].some(r => userRoles.includes(r) || userRole === r);

  const dateStr = complaint.createdAt ? new Date(complaint.createdAt).toLocaleString('vi-VN') : '';

  const rawPhone = complaint.reporterPhone || '';
  const maskedPhone = rawPhone ? (rawPhone.length > 6 ? rawPhone.slice(0, 3) + '***' + rawPhone.slice(-3) : rawPhone.slice(0, 3) + '***') : null;

  return {
    id: complaint.id,
    code: complaint.code,
    trackingCode: complaint.code,
    siteId: complaint.siteId,
    ward: complaint.ward,
    address: complaint.address,
    description: complaint.description,
    reporterName: isStaffOrAdmin ? complaint.reporterName : null,
    reporterPhone: isStaffOrAdmin ? complaint.reporterPhone : null,
    status: status,
    createdAt: complaint.createdAt,
    updatedAt: complaint.updatedAt,
    site: complaint.site ? {
      name: complaint.site.name,
      address: complaint.site.address,
      riskLevel: complaint.site.riskLevel,
      dustRiskScore: complaint.site.dustRiskScore
    } : null,
    
    desc: complaint.description,
    citizen: isStaffOrAdmin ? (complaint.reporterName || 'Công dân') : 'Công dân',
    phone: isStaffOrAdmin ? (complaint.reporterPhone || 'Không cung cấp') : (maskedPhone || 'Không cung cấp'),
    loc: complaint.address,
    date: dateStr,
    photo: complaint.evidences && complaint.evidences.length > 0,
    photoCount: complaint.evidences ? complaint.evidences.length : 0,
    
    priority: complaint.priority || 'low',
    dueAt: complaint.dueAt,
    triageNote: isStaffOrAdmin ? (complaint.triageNote || '') : null,
    assignedTo: complaint.assignedTo || '',
    contactedAt: complaint.contactedAt,
    closedAt: complaint.closedAt,
    mergedInto: complaint.mergedInto || null,
    latitude: complaint.latitude ?? null,
    longitude: complaint.longitude ?? null,
    isNearSensitiveZone: complaint.isNearSensitiveZone ?? undefined,
    nearestLandmark: complaint.nearestLandmark ?? undefined,
    clusterSize: complaint.clusterSize ?? undefined,
  };
}

const submitComplaintSchema = z.object({
  siteId: z.string().optional().nullable(),
  ward: z.string({ required_error: 'Phường/Xã là bắt buộc' }).min(1, 'Phường/Xã không được để trống'),
  address: z.string({ required_error: 'Địa chỉ là bắt buộc' }).min(1, 'Địa chỉ không được để trống'),
  description: z.string({ required_error: 'Mô tả phản ánh là bắt buộc' }).min(1, 'Mô tả không được để trống'),
  reporterName: z.string().optional().nullable(),
  reporterPhone: z.string().optional().nullable(),
  evidences: z.array(z.string()).optional(),
  latitude: z.union([z.number(), z.string()]).optional().nullable(),
  longitude: z.union([z.number(), z.string()]).optional().nullable(),
});

export const updateComplaintSchema = z.object({
  status: z.string().optional().nullable(),
  assignedTo: z.string().optional().nullable(),
  triageNote: z.string().optional().nullable(),
  priority: z.string().optional().nullable(),
  dueAt: z.union([z.string(), z.date()]).optional().nullable(),
  closedAt: z.union([z.string(), z.date()]).optional().nullable(),
  resolution: z.string().optional().nullable(),
});

// Triage logic for citizen complaints
export const submitComplaint = async (req, res, next) => {
  try {
    const raw = req.body;
    const normalizedData = {
      siteId: raw.siteId || null,
      ward: raw.ward || (raw.loc ? (extractWard(raw.loc) || 'Dịch Vọng Hậu') : 'Dịch Vọng Hậu'),
      address: raw.address || raw.loc || '',
      description: raw.description || raw.desc || '',
      reporterName: raw.reporterName || raw.citizen || null,
      reporterPhone: raw.reporterPhone || raw.phone || null,
      evidences: raw.evidences || (raw.photo ? [raw.photo] : [])
    };

    const validatedData = submitComplaintSchema.parse(normalizedData);
    const { siteId, ward, address, description, reporterName, reporterPhone, evidences, latitude, longitude } = validatedData;

    // 1. Generate unique code (fixed 4-hex digits with DB loop check to avoid P2002 collisions)
    let code;
    let codeExists = true;
    let attempts = 0;
    while (codeExists && attempts < 10) {
      const randomHex = crypto.randomBytes(2).toString('hex').toUpperCase();
      code = `DG-2026-${randomHex}`;
      const existingCode = await prisma.complaint.findUnique({
        where: { code },
        select: { id: true }
      });
      if (!existingCode) {
        codeExists = false;
      }
      attempts++;
    }

    // 2. Call AI Triage Engine
    const prompt = `Bạn là hệ thống Triage AI của DustGuard VN (Nền tảng giám sát rủi ro bụi công trường).
Nhiệm vụ của bạn là phân tích phản ánh của người dân để chấm điểm rủi ro và xác định mức độ nghiêm trọng.

Nội dung phản ánh:
- Phường: ${ward}
- Địa chỉ: ${address}
- Mô tả của người dân: "${description}"

Hãy phân tích các yếu tố sau:
1. Có nguy cơ ảnh hưởng đến khu dân cư đông đúc, trường học, hoặc bệnh viện không? (dựa vào từ khóa trong mô tả và địa chỉ).
2. Tình trạng bụi có dày đặc, cản trở giao thông hoặc kéo dài không?
3. Đề xuất Dust Risk Score (từ 0 đến 100). Dưới 40 là LOW, 40-70 là MEDIUM, trên 70 là HIGH. Trên 90 là CRITICAL.

Trả về duy nhất 1 JSON hợp lệ, không có code block markdown:
{
  "dustRiskScore": 85,
  "riskLevel": "HIGH",
  "analysis": "Lý do đánh giá ngắn gọn"
}`;

    let triageResult = { dustRiskScore: 50, riskLevel: 'MEDIUM', analysis: 'Phân tích tự động (Chưa cấu hình API Key)' };

    try {
      const result = await callConfiguredLLM([{ role: 'user', content: prompt }], { maxTokens: 800 });
      if (result && result.content) {
        const cleaned = result.content.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
        const parsed = JSON.parse(cleaned);
        triageResult = {
          dustRiskScore: parsed.dustRiskScore || triageResult.dustRiskScore,
          riskLevel: parsed.riskLevel || triageResult.riskLevel,
          analysis: parsed.analysis || triageResult.analysis,
        };
      }
    } catch (aiError) {
      logger.error('AI Triage Error, using fallback', { error: aiError.message });
      const descLower = description.toLowerCase();
      if (descLower.includes('trường học') || descLower.includes('bệnh viện') || descLower.includes('mù mịt')) {
        triageResult = { dustRiskScore: 85, riskLevel: 'HIGH', analysis: 'Phát hiện từ khóa nhạy cảm (trường học/bệnh viện/mù mịt).' };
      }
    }

    // 3. Resolve siteId if provided (match by ID or code)
    let resolvedSiteId = null;
    let resolvedSite = null;
    if (siteId) {
      const existingSite = await prisma.site.findFirst({
        where: {
          OR: [{ id: siteId }, { code: siteId }],
          deletedAt: null
        }
      });
      if (existingSite) {
        resolvedSiteId = existingSite.id;
        resolvedSite = existingSite;
      }
    }

    // 3b. Resolve effective WGS84 coordinates of this report: ưu tiên GPS công dân
    // gửi trực tiếp từ thiết bị, nếu không có thì dùng tọa độ công trình đã liên kết.
    const effectiveCoords = parseCoordinates(
      (latitude !== undefined && latitude !== null && longitude !== undefined && longitude !== null)
        ? { lat: latitude, lng: longitude }
        : resolvedSite?.coordinates,
      { allowNull: true }
    );

    // 3c. Sensitive Zone Buffer Analysis: tự động phát hiện công trình/điểm phản ánh
    // nằm gần Trường học / Bệnh viện (bán kính 200m) để nâng mức ưu tiên lên KHẨN CẤP.
    let sensitiveZone = null;
    if (effectiveCoords) {
      sensitiveZone = analyzeSensitiveZoneBuffer(effectiveCoords);
      if (sensitiveZone.isInsideSensitiveZone) {
        const escalatedLevel = sensitiveZone.distanceMeters <= 100 ? 'CRITICAL' : 'HIGH';
        if ((RISK_LEVEL_RANK[triageResult.riskLevel] ?? 0) < RISK_LEVEL_RANK[escalatedLevel]) {
          triageResult.riskLevel = escalatedLevel;
          triageResult.dustRiskScore = Math.max(triageResult.dustRiskScore, escalatedLevel === 'CRITICAL' ? 90 : 75);
        }
        triageResult.analysis = `${triageResult.analysis} ${sensitiveZone.reason}`.trim();
      }
    }

    // 3d. Spatial Clustering: gom cụm phản ánh trùng lặp trong bán kính 100m để tránh
    // loãng nguồn lực cán bộ khi nhiều người dân cùng chụp ảnh 1 điểm bụi.
    let clusterPrimary = null;
    if (effectiveCoords) {
      clusterPrimary = await findClusterPrimaryComplaint(effectiveCoords);
      if (clusterPrimary && !resolvedSiteId && clusterPrimary.siteId) {
        // Kế thừa liên kết công trình từ phản ánh gốc trong cùng cụm, nếu phản ánh mới chưa gán site.
        resolvedSiteId = clusterPrimary.siteId;
      }
    }

    // 4. Save to database
    const complaint = await prisma.complaint.create({
      data: {
        code,
        siteId: resolvedSiteId,
        ward,
        address,
        description,
        reporterName,
        reporterPhone,
        status: 'PENDING',
        priority: triageResult.riskLevel,
        latitude: effectiveCoords ? effectiveCoords.lat : null,
        longitude: effectiveCoords ? effectiveCoords.lng : null,
        mergedInto: clusterPrimary ? clusterPrimary.id : null,
        evidences: evidences && evidences.length > 0 ? {
          create: evidences.map(url => ({
            url,
            type: 'IMAGE'
          }))
        } : undefined
      },
      include: {
        evidences: true
      }
    });

    // Log complaint submission
    await logAuditEvent({
      action: 'COMPLAINT_SUBMIT',
      details: {
        complaintId: complaint.id,
        code: complaint.code,
        siteId: complaint.siteId,
        ward: complaint.ward,
        address: complaint.address,
      }
    });

    // Log AI Triage execution
    await logAuditEvent({
      action: 'AI_TRIAGE',
      details: {
        complaintId: complaint.id,
        code: complaint.code,
        dustRiskScore: triageResult.dustRiskScore,
        riskLevel: triageResult.riskLevel,
        analysis: triageResult.analysis,
      }
    });

    // 5. If linked to a site, update site risk score using Risk Engine and automatically spawn a Case.
    // Nếu phản ánh này đã được gom vào một cụm (mergedInto), KHÔNG tạo Case riêng để tránh
    // chồng chéo hồ sơ — cụm phản ánh sẽ chỉ củng cố tín hiệu cộng đồng cho Case đã có.
    if (resolvedSiteId) {
      try {
        await recalculateSiteRisk(resolvedSiteId, prisma);
      } catch (err) {
        logger.error('Recalculate site risk error', { error: err.message });
      }

      if (!clusterPrimary) {
        const actorObj = req.user ? {
          id: req.user.id,
          name: req.user.fullName || req.user.name,
          role: req.user.role
        } : {
          id: 'citizen',
          name: reporterName || 'Công dân nặc danh',
          role: 'citizen'
        };

        try {
          await createCaseFromComplaint(complaint.id, actorObj, null, null, { priority: triageResult.riskLevel });
        } catch (err) {
          logger.error('Case creation from complaint error', { error: err.message });
        }
      }
    }

    // 6. Đếm số phản ánh trong cụm (bao gồm phản ánh gốc + các phản ánh đã gộp) để trả về
    // banner "Đã có N người cùng gửi phản ánh" cho công dân.
    let clusterInfo = { merged: false, mergedInto: null, mergedIntoCode: null, clusterSize: 1 };
    if (clusterPrimary) {
      const clusterSize = await prisma.complaint.count({
        where: {
          deletedAt: null,
          OR: [{ id: clusterPrimary.id }, { mergedInto: clusterPrimary.id }]
        }
      });
      clusterInfo = {
        merged: true,
        mergedInto: clusterPrimary.id,
        mergedIntoCode: clusterPrimary.code,
        clusterSize
      };
    }

    // Clear cache
    clearCache('dashboard:');
    clearCache('map:');

    return successResponse(res, {
      code: complaint.code,
      trackingCode: complaint.code,
      id: complaint.id,
      complaint: mapComplaintToFrontend(complaint),
      triage: triageResult,
      cluster: clusterInfo,
      sensitiveZone: sensitiveZone ? {
        isInsideSensitiveZone: sensitiveZone.isInsideSensitiveZone,
        nearestLandmark: sensitiveZone.nearestLandmark,
        distanceMeters: sensitiveZone.distanceMeters,
        reason: sensitiveZone.reason
      } : null,
      message: clusterInfo.merged
        ? `Khu vực này đã có ${clusterInfo.clusterSize} người cùng gửi phản ánh trong ${Math.round(CLUSTER_LOOKBACK_MS / 3600000)}h qua. Hệ thống đã tự động gộp vào hồ sơ giám sát chung ${clusterInfo.mergedIntoCode}.`
        : undefined
    }, 'Gửi phản ánh thành công', 201);

  } catch (error) {
    next(error);
  }
};

export const listComplaints = async (req, res, next) => {
  try {
    const { siteId, status } = req.query;
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 20, 100);
    const where = { deletedAt: null };
    if (siteId) where.siteId = siteId;
    if (status) {
      // Normalize frontend status values to DB values
      const s = status.toLowerCase();
      if (s === 'new') where.status = 'PENDING';
      else if (s === 'linked') where.status = 'LINKED';
      else if (s === 'investigating') where.status = 'PROCESSING';
      else if (s === 'resolved') where.status = 'RESOLVED';
      else if (s === 'rejected') where.status = 'REJECTED';
      else where.status = status.toUpperCase();
    }

    const [total, complaints] = await Promise.all([
      prisma.complaint.count({ where }),
      prisma.complaint.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          site: {
            select: { name: true, riskLevel: true, dustRiskScore: true }
          },
          evidences: {
            where: { deletedAt: null }
          }
        }
      })
    ]);
    const formatted = complaints.map(c => mapComplaintToFrontend(c, req.user));
    return successResponse(res, {
      items: formatted,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Danh sách phản ánh');
  } catch (error) {
    next(error);
  }
};


export const getComplaintByCode = async (req, res, next) => {
  try {
    const { code } = req.params;
    const complaint = await prisma.complaint.findFirst({
      where: {
        OR: [
          { code: code.trim().toUpperCase() },
          { id: code.trim() }
        ],
        deletedAt: null
      },
      include: {
        site: {
          select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
        },
        evidences: {
          where: { deletedAt: null }
        }
      }
    });

    if (!complaint) {
      const error = new Error('Không tìm thấy mã phản ánh này.');
      error.status = 404;
      throw error;
    }

    const mapped = mapComplaintToFrontend(complaint, req.user);
    return successResponse(res, mapped, 'Chi tiết phản ánh');
  } catch (error) {
    next(error);
  }
};

export const updateComplaint = async (req, res, next) => {
  try {
    const { id } = req.params;
    const validatedData = updateComplaintSchema.parse(req.body);

    const existing = await prisma.complaint.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy phản ánh này.', 404);
    }

    let status = existing.status;
    if (validatedData.status) {
      const s = validatedData.status.toLowerCase();
      if (s === 'new') status = 'PENDING';
      else if (s === 'linked') status = 'LINKED';
      else if (s === 'investigating') status = 'PROCESSING';
      else if (s === 'resolved') status = 'RESOLVED';
      else if (s === 'rejected') status = 'REJECTED';
      else status = validatedData.status.toUpperCase();
    }

    // State Machine guard validation
    if (status !== existing.status) {
      try {
        validateComplaintTransition(existing.status, status, {
          role: req.user?.role || 'staff',
          siteId: existing.siteId,
          reason: validatedData.triageNote || validatedData.resolution,
          resolution: validatedData.resolution,
          triageNote: validatedData.triageNote
        });
      } catch (smErr) {
        return errorResponse(res, smErr.message, 400);
      }
    }

    // Whitelist: only these fields may be written via this endpoint.
    const updateData = {};
    if (status !== existing.status) {
      updateData.status = status;
      if (status === 'RESOLVED' && !validatedData.closedAt && !existing.closedAt) {
        updateData.closedAt = new Date();
      }
    }
    if (validatedData.assignedTo !== undefined) updateData.assignedTo = validatedData.assignedTo;
    if (validatedData.triageNote !== undefined) updateData.triageNote = validatedData.triageNote;
    if (validatedData.priority !== undefined) updateData.priority = validatedData.priority;
    if (validatedData.dueAt !== undefined) updateData.dueAt = validatedData.dueAt ? new Date(validatedData.dueAt) : null;
    if (validatedData.closedAt !== undefined) updateData.closedAt = validatedData.closedAt ? new Date(validatedData.closedAt) : null;
    if (validatedData.resolution !== undefined) updateData.resolution = validatedData.resolution;

    const updated = await prisma.complaint.update({
      where: { id: existing.id },
      data: updateData,
      include: {
        site: {
          select: { name: true, riskLevel: true, dustRiskScore: true }
        },
        evidences: {
          where: { deletedAt: null }
        }
      }
    });

    await logAuditEvent({
      action: 'COMPLAINT_UPDATE',
      userId: req.user?.id || null,
      details: {
        complaintId: updated.id,
        code: updated.code,
        changes: Object.keys(updateData)
      }
    });

    if (updated.siteId) {
      try {
        await recalculateSiteRisk(updated.siteId, prisma);
      } catch (err) {
        logger.error('Recalculate site risk error', { error: err.message });
      }
    }

    // Clear cache
    clearCache('dashboard:');
    clearCache('map:');
    clearCache('complaints:');

    return successResponse(res, { complaint: mapComplaintToFrontend(updated) }, 'Cập nhật phản ánh thành công');
  } catch (error) {
    next(error);
  }
};

export const updateComplaintStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const validatedData = updateComplaintSchema.parse(req.body);
    const rawStatus = validatedData.status;

    if (!rawStatus) {
      return errorResponse(res, 'Trạng thái là bắt buộc.', 400);
    }

    const existing = await prisma.complaint.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy phản ánh này.', 404);
    }

    let status = existing.status;
    if (rawStatus) {
      const s = rawStatus.toLowerCase();
      if (s === 'new') status = 'PENDING';
      else if (s === 'linked') status = 'LINKED';
      else if (s === 'investigating') status = 'PROCESSING';
      else if (s === 'resolved') status = 'RESOLVED';
      else if (s === 'rejected') status = 'REJECTED';
      else status = rawStatus.toUpperCase();
    }

    // Enforce Complaint Domain State Machine
    try {
      validateComplaintTransition(existing.status, status, {
        role: req.user?.role || 'staff',
        siteId: existing.siteId,
        reason: req.body?.reason || req.body?.triageNote || req.body?.resolution,
        resolution: req.body?.resolution,
        triageNote: req.body?.triageNote
      });
    } catch (smErr) {
      return errorResponse(res, smErr.message, 400);
    }

    const updateData = { status };
    if (status === 'RESOLVED' && !existing.closedAt) {
      updateData.closedAt = new Date();
    }

    const updated = await prisma.complaint.update({
      where: { id: existing.id },
      data: updateData,
      include: {
        site: {
          select: { name: true, riskLevel: true, dustRiskScore: true }
        },
        evidences: {
          where: { deletedAt: null }
        }
      }
    });

    await logAuditEvent({
      action: 'COMPLAINT_STATUS_UPDATE',
      userId: req.user?.id || null,
      details: {
        complaintId: updated.id,
        code: updated.code,
        oldStatus: existing.status,
        newStatus: status
      }
    });

    // Clear cache
    clearCache('dashboard:');
    clearCache('map:');
    clearCache('complaints:');

    return successResponse(res, { complaint: mapComplaintToFrontend(updated) }, 'Cập nhật trạng thái phản ánh thành công');
  } catch (error) {
    next(error);
  }
};

export const verifyComplaint = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isSatisfied, feedback } = req.body || {};

    const existing = await prisma.complaint.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });

    const action = req.body?.action || (isSatisfied === false ? 'REOPEN_REQUEST' : 'CONFIRM_RESOLVED');
    const now = new Date();

    if (action === 'REOPEN_REQUEST' || isSatisfied === false) {
      const updated = await prisma.complaint.update({
        where: { id: existing.id },
        data: {
          triageNote: feedback || 'Người dân yêu cầu kiểm tra lại hiện trường (REOPEN_REQUEST)'
        }
      });

      await logAuditEvent({
        action: 'COMPLAINT_REOPEN_REQUESTED',
        userId: req.user?.id || null,
        details: {
          complaintId: updated.id,
          code: updated.code,
          feedback: feedback || 'Chưa cải thiện ô nhiễm bụi'
        }
      });

      return successResponse(res, { complaint: mapComplaintToFrontend(updated), action: 'REOPEN_REQUESTED' }, 'Đã tiếp nhận yêu cầu kiểm tra lại của bạn. Cán bộ thanh tra sẽ xem xét.');
    }

    const newStatus = 'RESOLVED';
    const updated = await prisma.complaint.update({
      where: { id: existing.id },
      data: {
        status: newStatus,
        closedAt: now,
        triageNote: feedback || 'Đã xác nhận hoàn thành bởi người dân'
      }
    });

    await logAuditEvent({
      action: 'COMPLAINT_CITIZEN_VERIFY',
      userId: req.user?.id || null,
      details: {
        complaintId: updated.id,
        code: updated.code,
        isSatisfied: Boolean(isSatisfied),
        newStatus
      }
    });

    return successResponse(res, {
      id: updated.id,
      code: updated.code,
      status: newStatus,
      isSatisfied: Boolean(isSatisfied),
      verifiedAt: now.toISOString()
    }, isSatisfied ? 'Xác nhận xử lý thành công (+30 điểm cộng đồng)' : 'Đã chuyển yêu cầu tái kiểm hiện trường');
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/complaints/:id
 * Xóa / Lưu trữ phản ánh (Soft delete)
 */
export const deleteComplaint = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.complaint.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!existing) {
      return errorResponse(res, 'Không tìm thấy phản ánh để xóa.', 404);
    }

    const updated = await prisma.complaint.update({
      where: { id: existing.id },
      data: { deletedAt: new Date(), status: 'REJECTED' }
    });

    clearCache('complaints:');
    clearCache('dashboard:');
    clearCache('map:');

    await logAuditEvent({
      action: 'COMPLAINT_DELETE',
      userId: req.user?.id || null,
      details: { complaintId: existing.id, code: existing.code }
    });

    return successResponse(res, { id: existing.id, code: existing.code, deleted: true }, 'Xóa phản ánh thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/complaints/:id/convert-to-case
 * Chuyển phản ánh người dân thành Hồ sơ Vụ việc (Case) chính thức
 */
export const convertComplaintToCase = async (req, res, next) => {
  try {
    const { id } = req.params;
    const complaint = await prisma.complaint.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!complaint) {
      return errorResponse(res, 'Không tìm thấy phản ánh tương ứng.', 404);
    }

    const actor = req.user ? {
      id: req.user.id,
      name: req.user.fullName || req.user.name || 'Cán bộ Thanh tra',
      role: req.user.role || 'staff'
    } : {
      id: 'staff-system',
      name: 'Hệ thống Quản lý Vụ việc',
      role: 'staff'
    };

    const newCase = await createCaseFromComplaint(complaint.id, actor);

    clearCache('cases:');
    clearCache('complaints:');
    clearCache('dashboard:');

    return successResponse(res, { case: newCase }, 'Chuyển phản ánh thành hồ sơ vụ việc thành công', 201);
  } catch (error) {
    next(error);
  }
};



