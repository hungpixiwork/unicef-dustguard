import { z } from 'zod';
import { recalculateSiteRisk, LEGAL_MAPPING } from '../lib/riskEngine.js';
import { successResponse, errorResponse, formatZodError, parsePaginationParams } from '../lib/response.js';
import { safeJsonParse } from '../lib/jsonHelper.js';
import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';
import { clearCache } from '../lib/cache.js';

const createActionSchema = z.object({
  siteId: z.string({ required_error: 'siteId là bắt buộc' }).min(1, 'siteId không được để trống'),
  title: z.string({ required_error: 'Tiêu đề là bắt buộc' }).min(1, 'Tiêu đề không được để trống'),
  description: z.string().optional().nullable(),
  assignee: z.string().optional().nullable(),
  dueDate: z.string().optional().nullable(),
  inspectionId: z.string().optional().nullable(),
});

const confirmDraftActionsSchema = z.object({
  draft_actions: z.array(z.object({
    site_id: z.string({ required_error: 'site_id là bắt buộc' }),
    inspection_id: z.string().optional().nullable(),
    title: z.string({ required_error: 'Tiêu đề là bắt buộc' }),
    required_fix: z.string().optional().nullable(),
    reason: z.string().optional().nullable(),
    legal_basis_summary: z.string().optional().nullable(),
    deadline: z.string().optional().nullable(),
    checklist_item_id: z.string().optional().nullable(),
  }))
});

const updateActionSchema = z.object({
  status: z.enum(['PENDING', 'PENDING_VERIFICATION', 'COMPLETED', 'VERIFIED']).optional(),
  description: z.string().optional().nullable(),
  assignee: z.string().optional().nullable(),
  dueDate: z.string().optional().nullable(),
  evidenceUrl: z.string().optional().nullable()
});

const draftActionsFromInspectionSchema = z.object({
  inspection_id: z.string({ required_error: 'inspection_id là bắt buộc' }).min(1, 'inspection_id không được để trống'),
  selected_checklist_item_ids: z.array(z.string()).optional()
});

import { validateActionTransition } from '../domain/actions/action.rules.js';

export const getActions = async (req, res, next) => {
  try {
    const { siteId, status, assignee, overdue } = req.query;
    const { limit, offset, page } = parsePaginationParams(req, 20, 100);
    
    const where = {};
    if (siteId) where.siteId = siteId;
    if (status) where.status = status;
    if (assignee) where.assignee = assignee;
    
    if (overdue === 'true') {
      where.dueDate = { lt: new Date() };
      where.status = { notIn: ['COMPLETED', 'PENDING_VERIFICATION', 'VERIFIED'] };
    }

    const [total, actions] = await Promise.all([
      prisma.action.count({ where }),
      prisma.action.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          site: {
            select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
          }
        }
      })
    ]);

    return successResponse(res, { 
      items: actions,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Lấy danh sách hành động thành công');
  } catch (error) {
    next(error);
  }
};

export const getAction = async (req, res, next) => {
  try {
    const { id } = req.params;
    const action = await prisma.action.findUnique({
      where: { id },
      include: {
        site: true
      }
    });
    
    if (!action) {
      return errorResponse(res, 'Không tìm thấy hành động', 404);
    }
    
    return successResponse(res, action, 'Lấy thông tin hành động thành công');
  } catch (error) {
    next(error);
  }
};

export const createAction = async (req, res, next) => {
  try {
    const validatedData = createActionSchema.safeParse(req.body);
    if (!validatedData.success) {
      const { message, fieldErrors } = formatZodError(validatedData.error);
      return errorResponse(res, message, 400, fieldErrors);
    }
    
    const { siteId, title, description, assignee, dueDate, inspectionId } = validatedData.data;

    // Entity Integrity Guard: verify site exists to prevent orphan action records
    const site = await prisma.site.findFirst({
      where: {
        OR: [{ id: siteId }, { code: siteId }],
        deletedAt: null
      }
    });
    if (!site) {
      return errorResponse(res, `Không tìm thấy công trường với mã ${siteId}`, 404);
    }

    // If inspectionId provided, verify inspection exists
    if (inspectionId) {
      const inspection = await prisma.inspection.findFirst({
        where: { id: inspectionId, deletedAt: null }
      });
      if (!inspection) {
        return errorResponse(res, `Không tìm thấy biên bản kiểm tra với mã ${inspectionId}`, 404);
      }
    }

    const action = await prisma.action.create({
      data: {
        siteId: site.id,
        title,
        description,
        assignee: assignee || 'Nhà thầu chính',
        dueDate: dueDate ? new Date(dueDate) : new Date(Date.now() + 48 * 60 * 60 * 1000), // default 48h
        inspectionId: inspectionId || null
      }
    });

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, action, 'Tạo hành động thành công', 201);
  } catch (error) {
    next(error);
  }
};

export const updateAction = async (req, res, next) => {
  try {
    const { id } = req.params;
    const validatedData = updateActionSchema.safeParse(req.body);
    if (!validatedData.success) {
      const { message, fieldErrors } = formatZodError(validatedData.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const currentAction = await prisma.action.findUnique({ where: { id } });
    if (!currentAction) {
      return errorResponse(res, 'Không tìm thấy hành động', 404);
    }

    const { status, description, assignee, dueDate, evidenceUrl } = validatedData.data;

    // Enforce State Machine rules and transition guards if status change requested
    if (status && status !== currentAction.status) {
      try {
        validateActionTransition(currentAction.status, status, {
          role: req.user?.role,
          evidenceUrl: evidenceUrl || currentAction.evidenceUrl,
          reason: req.body.reason || req.body.notes
        });
      } catch (smErr) {
        return errorResponse(res, smErr.message, 400);
      }
    }

    const action = await prisma.action.update({
      where: { id },
      data: {
        status,
        description,
        assignee,
        dueDate: dueDate ? new Date(dueDate) : undefined,
        evidenceUrl
      }
    });

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, action, 'Cập nhật hành động thành công');
  } catch (error) {
    next(error);
  }
};

export const verifyAction = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { notes } = req.body || {};

    // 1. Get the current action details to prevent ReferenceError when updating description
    const currentAction = await prisma.action.findUnique({ where: { id } });
    if (!currentAction) {
      return errorResponse(res, 'Không tìm thấy hành động', 404);
    }

    // Enforce state transition safety through Action Domain State Machine
    try {
      validateActionTransition(currentAction.status, 'VERIFIED', {
        role: req.user?.role || 'staff',
        reason: notes
      });
    } catch (smErr) {
      return errorResponse(res, smErr.message, 400);
    }

    // 2. Mark action as verified
    const action = await prisma.action.update({
      where: { id },
      data: {
        status: 'VERIFIED',
        description: notes ? `${currentAction.description || ''}\nVerification Notes: ${notes}` : undefined
      }
    });

    // 3. Recalculate Site risk score using Risk Engine
    try {
      await recalculateSiteRisk(action.siteId, prisma);
    } catch (riskErr) {
      logger.error('Error recalculating site risk after verification', { error: riskErr.message });
    }

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, action, 'Xác minh hành động thành công');
  } catch (error) {
    next(error);
  }
};

export const uploadActionEvidence = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { url, explanation } = req.body || {};
    
    const fileUrl = req.file ? `/uploads/${req.file.filename}` : (url || req.body?.evidenceUrl || req.body?.url);

    if (!fileUrl) {
      return errorResponse(res, 'Vui lòng cung cấp minh chứng khắc phục (tệp tải lên hoặc URL).', 400);
    }

    const currentAction = await prisma.action.findUnique({ where: { id } });
    if (!currentAction) {
      return errorResponse(res, 'Không tìm thấy hành động', 404);
    }

    // Validate State Machine transition to PENDING_VERIFICATION
    try {
      validateActionTransition(currentAction.status, 'PENDING_VERIFICATION', {
        role: req.user?.role,
        evidenceUrl: fileUrl,
        reason: explanation
      });
    } catch (smErr) {
      return errorResponse(res, smErr.message, 400);
    }

    const updatedDescription = explanation
      ? `${currentAction.description || ''}\n\n[Giải trình khắc phục của Nhà thầu]: ${explanation}`
      : currentAction.description;

    const action = await prisma.action.update({
      where: { id },
      data: {
        status: 'PENDING_VERIFICATION',
        evidenceUrl: fileUrl,
        description: updatedDescription
      }
    });

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, action, 'Tải lên minh chứng thành công');
  } catch (error) {
    next(error);
  }
};

// 100% verified legal mappings dynamically loaded from single source of truth (LEGAL_MAPPING)
const VIETNAMESE_LEGAL_MAP = Object.keys(LEGAL_MAPPING).reduce((acc, key) => {
  const item = LEGAL_MAPPING[key];
  acc[key] = {
    clause: item.clause,
    standard: item.standard,
    fine: item.fine,
    fix: item.fix
  };
  return acc;
}, {});

export const draftActionsFromInspection = async (req, res, next) => {
  try {
    const validatedData = draftActionsFromInspectionSchema.safeParse(req.body);
    if (!validatedData.success) {
      const { message, fieldErrors } = formatZodError(validatedData.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { inspection_id, selected_checklist_item_ids } = validatedData.data;

    const inspection = await prisma.inspection.findUnique({
      where: { id: inspection_id },
      include: { site: true }
    });

    if (!inspection) {
      return errorResponse(res, 'Không tìm thấy biên bản kiểm tra tương ứng.', 404);
    }

    let failedKeys = [];
    let itemNotes = {};

    // 1. Try parsing findings as JSON
    try {
      const parsedFindings = safeJsonParse(inspection.findings);
      if (Array.isArray(parsedFindings)) {
        parsedFindings.forEach(item => {
          if (item.status === 'fail') {
            failedKeys.push(item.k);
            itemNotes[item.k] = item.notes;
          }
        });
      }
    } catch (e) {
      // Ignore parse errors
    }

    // 2. If no keys found yet, look up actions created for this inspection
    if (failedKeys.length === 0) {
      const existingActions = await prisma.action.findMany({
        where: { inspectionId: inspection_id }
      });
      existingActions.forEach(action => {
        const keyMatch = action.title.match(/Khắc phục vi phạm:\s*(.+)$/);
        if (keyMatch) {
          const key = keyMatch[1].trim();
          failedKeys.push(key);
          itemNotes[key] = action.description;
        }
      });
    }

    // 3. Fallback to checking text findings for keywords
    if (failedKeys.length === 0) {
      const findingsText = (typeof inspection.findings === 'string'
        ? inspection.findings
        : JSON.stringify(inspection.findings || '')).toLowerCase();
      Object.keys(VIETNAMESE_LEGAL_MAP).forEach(k => {
        if (findingsText.includes(k) || findingsText.includes(VIETNAMESE_LEGAL_MAP[k].standard.toLowerCase())) {
          failedKeys.push(k);
        }
      });
    }

    // Default fallback if we still don't have anything
    if (failedKeys.length === 0) {
      failedKeys.push('barrier'); // Default
    }

    // Filter by selected ids if provided
    if (selected_checklist_item_ids && Array.isArray(selected_checklist_item_ids) && selected_checklist_item_ids.length > 0) {
      failedKeys = failedKeys.filter(k => selected_checklist_item_ids.includes(k));
    }

    // Build the deterministic, verifiable draft action items
    const draft_actions = failedKeys.map(k => {
      const legal = VIETNAMESE_LEGAL_MAP[k] || {
        clause: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
        standard: 'Quy chuẩn bảo vệ môi trường xây dựng',
        fine: 'Xem xét xử lý theo quy định',
        fix: 'Yêu cầu rà soát và khắc phục toàn bộ vi phạm.'
      };
      
      const title = `Khắc phục vi phạm: ${k}`;
      const reason = `Hạng mục "${k}" không đạt quy chuẩn bảo vệ môi trường đô thị. Căn cứ pháp lý: ${legal.clause} (${legal.standard}). Khung phạt đề xuất: ${legal.fine}.`;
      const required_fix = legal.fix;
      const legal_basis_summary = `${legal.clause} - ${legal.standard}`;
      
      return {
        id: `draft-${k}-${inspection_id}`,
        site_id: inspection.siteId,
        inspection_id: inspection.id,
        checklist_item_id: k,
        title,
        reason,
        legal_basis_summary,
        required_fix,
        deadline: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString().slice(0, 10), // 3 days
        evidence_required: ['Ảnh chụp hiện trường sau khắc phục', 'Biên bản kiểm tra nội bộ'],
        priority: 'medium'
      };
    });

    return successResponse(res, { inspection_id, draft_actions }, 'Tạo dự thảo hành động khắc phục thành công');
  } catch (error) {
    next(error);
  }
};

export const confirmDraftActions = async (req, res, next) => {
  try {
    const validatedData = confirmDraftActionsSchema.safeParse(req.body);
    if (!validatedData.success) {
      const { message, fieldErrors } = formatZodError(validatedData.error);
      return errorResponse(res, message, 400, fieldErrors);
    }
    
    const { draft_actions } = validatedData.data;

    const created_actions = await prisma.$transaction(async (tx) => {
      const createdActionsList = [];

      // Lấy tất cả site_ids và inspection_ids của danh sách nháp để truy vấn 1 lần duy nhất
      const siteIds = [...new Set(draft_actions.map(d => d.site_id).filter(Boolean))];
      const inspectionIds = [...new Set(draft_actions.map(d => d.inspection_id).filter(Boolean))];

      // Chỉ truy vấn DB khi có dữ liệu
      const existingActions = (siteIds.length > 0 || inspectionIds.length > 0)
        ? await tx.action.findMany({
            where: {
              siteId: siteIds.length > 0 ? { in: siteIds } : undefined,
              inspectionId: inspectionIds.length > 0 ? { in: inspectionIds } : undefined
            }
          })
        : [];

      // Tạo Map lưu vết các bản ghi hiện tại để đối chiếu nhanh trong bộ nhớ (RAM)
      const existingMap = new Map();
      for (const a of existingActions) {
        const key = `${a.siteId}::${a.inspectionId || ''}::${a.title}`;
        existingMap.set(key, a);
      }

      for (const draft of draft_actions) {
        const compositeKey = `${draft.site_id}::${draft.inspection_id || ''}::${draft.title}`;
        const existing = existingMap.get(compositeKey);

        if (existing) {
          createdActionsList.push(existing);
          continue;
        }

        const action = await tx.action.create({
          data: {
            siteId: draft.site_id,
            inspectionId: draft.inspection_id,
            title: draft.title || `Khắc phục vi phạm: ${draft.checklist_item_id}`,
            description: `${draft.required_fix || ''}\n\n[CƠ SỞ PHÁP LÝ PHÁT HIỆN]:\n- Căn cứ: ${draft.legal_basis_summary || ''}\n- Chi tiết: ${draft.reason || ''}`,
            status: 'PENDING',
            assignee: 'Nhà thầu chính',
            dueDate: draft.deadline ? new Date(draft.deadline) : new Date(Date.now() + 72 * 60 * 60 * 1000)
          }
        });
        
        createdActionsList.push(action);

        // Cập nhật lại Map để tránh trùng lặp trong chính danh sách nháp gửi lên
        const newKey = `${action.siteId}::${action.inspectionId || ''}::${action.title}`;
        existingMap.set(newKey, action);
      }

      return createdActionsList;
    });

    // Clear caches
    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, { created_actions }, 'Xác nhận danh sách hành động khắc phục thành công', 201);
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/actions/:id
 * Xóa hành động khắc phục
 */
export const deleteAction = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.action.findUnique({ where: { id } });
    if (!existing) {
      return errorResponse(res, 'Không tìm thấy hành động để xóa', 404);
    }

    await prisma.action.delete({ where: { id } });

    // Recalculate site risk
    try {
      await recalculateSiteRisk(existing.siteId, prisma);
    } catch (riskErr) {
      logger.error('Error recalculating site risk after action deletion', { error: riskErr.message });
    }

    clearCache('dashboard:');
    clearCache('sites:');
    clearCache('map:');
    clearCache('alerts:');

    return successResponse(res, { id, deleted: true }, 'Xóa hành động khắc phục thành công');
  } catch (error) {
    next(error);
  }
};



