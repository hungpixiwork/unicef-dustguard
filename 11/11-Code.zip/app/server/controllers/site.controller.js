import { z } from 'zod';
import crypto from 'node:crypto';
import { successResponse, errorResponse, parsePaginationParams } from '../lib/response.js';

import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';
import { SEED_SITES } from '../../src/lib/seedData.js';
import { getCached, setCached, clearCache } from '../lib/cache.js';
import { DustRiskEngine } from '../domain/risk/dust-risk-engine.js';
import { parseCoordinates, serializeCoordinates } from '../domain/spatial/spatial-adapter.js';

const CHECKLIST_KEYS = ['barrier', 'spray', 'cover', 'wheel', 'spill', 'demo', 'hours', 'gate', 'height', 'signage'];

/**
 * Chuẩn hóa và bảo vệ tọa độ địa lý GPS lat/lng
 */
export function normalizeCoordinates(coords) {
  if (!coords || typeof coords !== 'string') return null;
  const parts = coords.split(',').map(p => parseFloat(p.trim()));
  if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
    const lat = Math.max(-90, Math.min(90, parts[0]));
    const lng = Math.max(-180, Math.min(180, parts[1]));
    return `${lat.toFixed(6)},${lng.toFixed(6)}`;
  }
  return null;
}

/**
 * Tính toán checklist trong bộ nhớ từ thông tin công trường, đợt kiểm tra cuối và các hành động đã xác minh.
 */
function computeChecklistForSite(site, latestInspection, verifiedActions) {
  let baseChecklist = Object.fromEntries(CHECKLIST_KEYS.map(k => [k, 'pass']));
  
  const seedSite = SEED_SITES.find(s => 
    s.name === site.name || 
    site.name.includes(s.name) || 
    s.addr === site.address || 
    site.address.includes(s.addr)
  );
  if (seedSite && seedSite.checklist) {
    baseChecklist = { ...seedSite.checklist };
  }

  const checklist = { ...baseChecklist };
  if (latestInspection && latestInspection.findings) {
    try {
      const parsed = JSON.parse(latestInspection.findings);
      if (Array.isArray(parsed)) {
        for (const item of parsed) {
          const key = item.key || item.k;
          if (key && CHECKLIST_KEYS.includes(key)) {
            checklist[key] = item.status || item.result || 'fail';
          }
        }
      } else if (typeof parsed === 'object' && parsed !== null) {
        for (const [key, value] of Object.entries(parsed)) {
          if (CHECKLIST_KEYS.includes(key)) {
            checklist[key] = typeof value === 'string' ? value : (value?.status || 'fail');
          }
        }
      }
    } catch (parseErr) {
      // Bỏ qua lỗi parse
    }

    if (verifiedActions && verifiedActions.length > 0) {
      const matchedActions = verifiedActions.filter(a => a.inspectionId === latestInspection.id);
      for (const action of matchedActions) {
        const match = action.title.match(/Khắc phục vi phạm:\s*(.+)$/);
        if (match) {
          const key = match[1].trim();
          if (CHECKLIST_KEYS.includes(key)) {
            checklist[key] = 'pass';
          }
        }
      }
    }
  }
  return checklist;
}

/**
 * Xây dựng checklist cho một công trường bằng 1 truy vấn duy nhất thay vì 3 truy vấn tuần tự.
 */
async function buildChecklistForSite(siteId) {
  try {
    const site = await prisma.site.findFirst({
      where: {
        OR: [
          { id: siteId },
          { code: siteId }
        ],
        deletedAt: null
      },
      include: {
        inspections: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'desc' },
          take: 1
        },
        actions: {
          where: { status: 'VERIFIED', deletedAt: null }
        }
      }
    });
    if (!site) return Object.fromEntries(CHECKLIST_KEYS.map(k => [k, 'pass']));
    const latestInspection = site.inspections[0] || null;
    return computeChecklistForSite(site, latestInspection, site.actions);
  } catch (err) {
    logger.warn('Failed to build checklist for site', { siteId, error: err.message });
    return Object.fromEntries(CHECKLIST_KEYS.map(k => [k, 'pass']));
  }
}

const createSiteSchema = z.object({
  code: z.string().optional().nullable(),
  name: z.string({ required_error: 'Tên công trình là bắt buộc' }).min(1, 'Tên công trình không được để trống'),
  address: z.string({ required_error: 'Địa chỉ là bắt buộc' }).min(1, 'Địa chỉ không được để trống'),
  ward: z.string({ required_error: 'Phường/Xã là bắt buộc' }).min(1, 'Phường/Xã không được để trống'),
  province: z.string().optional().nullable(),
  coordinates: z.string().optional().nullable(),
  dustRiskScore: z.coerce.number().int().min(0).max(100).optional(),
  riskLevel: z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']).optional(),
  status: z.enum(['ACTIVE', 'SUSPENDED', 'COMPLETED']).optional(),
  investorName: z.string().optional().nullable(),
  contractorName: z.string().optional().nullable(),
  licenseNumber: z.string().optional().nullable(),
  managerName: z.string().optional().nullable(),
  managerPhone: z.string().optional().nullable(),
  managerEmail: z.string().optional().nullable(),
});

const updateSiteSchema = createSiteSchema.partial().extend({
  deletedAt: z.union([z.string(), z.date(), z.null()]).optional(),
  isDeleted: z.boolean().optional(),
});

export const getSites = async (req, res, next) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 20, 100);
    const { search, ward, riskLevel, status } = req.query || {};
    const cacheKey = `sites:list:${page}:${limit}:${search || ''}:${ward || ''}:${riskLevel || ''}:${status || ''}`;
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Danh sách công trường (cached)');
    }

    const where = { deletedAt: null };
    if (search && search.trim()) {
      const q = search.trim();
      where.OR = [
        { name: { contains: q } },
        { address: { contains: q } },
        { code: { contains: q } }
      ];
    }
    if (ward && ward.trim()) {
      where.ward = { contains: ward.trim() };
    }
    if (riskLevel && riskLevel.trim()) {
      where.riskLevel = riskLevel.trim().toUpperCase();
    }
    if (status && status.trim()) {
      where.status = status.trim().toUpperCase();
    }

    const [total, sites] = await Promise.all([
      prisma.site.count({ where }),
      prisma.site.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          cases: {
            where: { deletedAt: null },
            orderBy: { createdAt: 'desc' },
            take: 1
          },
          inspections: {
            where: { deletedAt: null },
            orderBy: { createdAt: 'desc' },
            take: 1
          },
          actions: {
            where: {
              status: 'VERIFIED',
              deletedAt: null
            }
          }
        }
      })
    ]);

    const items = sites.map((site) => {
      const latestInspection = site.inspections[0] || null;
      const checklist = computeChecklistForSite(site, latestInspection, site.actions);
      
      const siteCopy = { ...site };
      delete siteCopy.inspections;
      delete siteCopy.actions;

      const dustRiskScore = siteCopy.dustRiskScore ?? 50;
      const priorityScore = dustRiskScore;
      const riskLevel = siteCopy.riskLevel || (dustRiskScore >= 80 ? 'CRITICAL' : dustRiskScore >= 70 ? 'HIGH' : dustRiskScore >= 40 ? 'MEDIUM' : 'LOW');
      const priorityLevel = riskLevel;
      const priorityTier = dustRiskScore >= 70 ? 'red' : dustRiskScore >= 40 ? 'amber' : 'green';
      const gaugeData = {
        pm25: siteCopy.currentPm25 || (dustRiskScore >= 80 ? 82 : dustRiskScore >= 50 ? 55 : 32),
        score: priorityScore,
        priorityScore,
        status: priorityLevel,
        color: dustRiskScore >= 80 ? '#9f241f' : dustRiskScore >= 50 ? '#d97706' : '#0d6f64'
      };

      return {
        ...siteCopy,
        priorityScore,
        priorityLevel,
        priorityTier,
        dustRiskScore,
        riskLevel,
        checklist,
        gaugeData,
        gauge: gaugeData
      };
    });

    const responsePayload = {
      items,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    };

    setCached(cacheKey, responsePayload, 3000); // cache 3 giây
    return successResponse(res, responsePayload, 'Danh sách công trường');
  } catch (error) {
    if (error.code === 'P2025') {
      return errorResponse(res, 'Không tìm thấy dữ liệu công trường', 404);
    }
    next(error);
  }
};


export const getSiteById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const cacheKey = `sites:detail:${id}`;
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Chi tiết công trường (cached)');
    }

    const site = await prisma.site.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      },
      include: {
        complaints: {
          where: { deletedAt: null }
        },
        inspections: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'desc' }
        },
        actions: {
          where: {
            status: 'VERIFIED',
            deletedAt: null
          }
        },
        cases: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    });

    if (!site) {
      logger.warn('Site not found by identifier', {
        requestId: req.id,
        siteIdentifier: id,
        userId: req.user?.id || 'guest',
        role: req.user?.role || 'guest',
        status: 404,
        errorType: 'ERR-SITE-404'
      });
      const error = new Error(`Không tìm thấy công trình với mã hoặc ID "${id}"`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    logger.info('Site detail retrieved successfully', {
      requestId: req.id,
      siteId: site.id,
      siteCode: site.code,
      userId: req.user?.id || 'guest',
      role: req.user?.role || 'guest',
      status: 200
    });

    const latestInspection = site.inspections[0] || null;
    const checklist = computeChecklistForSite(site, latestInspection, site.actions);
    const dustRiskScore = site.dustRiskScore ?? 50;
    const priorityScore = dustRiskScore;
    const riskLevel = site.riskLevel || (dustRiskScore >= 80 ? 'CRITICAL' : dustRiskScore >= 70 ? 'HIGH' : dustRiskScore >= 40 ? 'MEDIUM' : 'LOW');
    const priorityLevel = riskLevel;
    const priorityTier = dustRiskScore >= 70 ? 'red' : dustRiskScore >= 40 ? 'amber' : 'green';
    const gaugeData = {
      pm25: site.currentPm25 || (dustRiskScore >= 80 ? 82 : dustRiskScore >= 50 ? 55 : 32),
      score: priorityScore,
      priorityScore,
      status: priorityLevel,
      color: dustRiskScore >= 80 ? '#9f241f' : dustRiskScore >= 50 ? '#d97706' : '#0d6f64'
    };

    const parsedInspections = (site.inspections || []).map(ins => ({
      ...ins,
      findings: typeof ins.findings === 'string' ? safeJsonParse(ins.findings) : ins.findings
    }));

    const isStaffOrAdmin = req.user && ['staff', 'inspector', 'admin', 'executive', 'demo_admin', 'super_admin'].includes((req.user.role || '').toLowerCase());
    const isSiteContractor = req.user && (req.user.role === 'contractor' || req.user.role === 'demo_contractor') &&
      (req.user.id === site.contractorId || req.user.email === site.managerEmail || req.user.name === site.contractorName || req.user.fullName === site.contractorName);

    const isPrivileged = isStaffOrAdmin || isSiteContractor;

    const result = {
      ...site,
      inspections: isPrivileged ? parsedInspections : [],
      managerPhone: isPrivileged ? site.managerPhone : null,
      managerEmail: isPrivileged ? site.managerEmail : null,
      priorityScore,
      priorityLevel,
      priorityTier,
      dustRiskScore,
      riskLevel,
      checklist,
      gaugeData,
      gauge: gaugeData
    };
    setCached(cacheKey, result, 3000); // cache 3 giây
    return successResponse(res, result, 'Chi tiết công trường');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error(`Không tìm thấy công trình với mã hoặc ID "${req.params.id}"`);
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

export const createSite = async (req, res, next) => {
  try {
    const validatedData = createSiteSchema.parse(req.body);
    if (!validatedData.code) {
      validatedData.code = `BD-${crypto.randomInt(1000, 10000)}`;
    }
    if (validatedData.coordinates) {
      validatedData.coordinates = normalizeCoordinates(validatedData.coordinates);
    } else {
      validatedData.coordinates = null;
    }
    const site = await prisma.site.create({
      data: validatedData
    });
    
    // Clear cache
    clearCache('sites:');
    clearCache('map:');
    clearCache('dashboard:');
    
    return successResponse(res, site, 'Tạo công trường thành công', 201);
  } catch (error) {
    if (error.code === 'P2025') {
      return errorResponse(res, 'Không tìm thấy dữ liệu liên quan để tạo công trường', 404);
    }
    next(error);
  }
};

export const updateSite = async (req, res, next) => {
  try {
    const { id } = req.params;
    const validatedData = updateSiteSchema.parse(req.body);
    
    const existingSite = await prisma.site.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!existingSite) {
      const error = new Error(`Không tìm thấy công trình để cập nhật (Mã/ID: "${id}")`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const dataToUpdate = { ...validatedData };
    if (dataToUpdate.coordinates !== undefined && dataToUpdate.coordinates !== null) {
      dataToUpdate.coordinates = normalizeCoordinates(dataToUpdate.coordinates);
    }
    if (dataToUpdate.isDeleted === true) {
      dataToUpdate.deletedAt = new Date();
      delete dataToUpdate.isDeleted;
    } else if (dataToUpdate.isDeleted === false) {
      dataToUpdate.deletedAt = null;
      delete dataToUpdate.isDeleted;
    }

    const updatedSite = await prisma.site.update({
      where: { id: existingSite.id },
      data: dataToUpdate
    });
    
    // Clear cache
    clearCache('sites:');
    clearCache('map:');
    clearCache('dashboard:');
    
    return successResponse(res, updatedSite, 'Cập nhật công trường thành công');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error(`Không tìm thấy công trình để cập nhật (Mã/ID: "${req.params.id}")`);
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

export const deleteSite = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existingSite = await prisma.site.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!existingSite) {
      const error = new Error(`Không tìm thấy công trình để xóa (Mã/ID: "${id}")`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    await prisma.site.update({
      where: { id: existingSite.id },
      data: { deletedAt: new Date() }
    });
    
    // Clear cache
    clearCache('sites:');
    clearCache('map:');
    clearCache('dashboard:');
    
    return successResponse(res, null, 'Xóa công trường thành công (Soft Delete)');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error(`Không tìm thấy công trình để xóa (Mã/ID: "${req.params.id}")`);
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

export const getSiteSensors = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const site = await prisma.site.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });
    
    if (!site) {
      const error = new Error('Không tìm thấy công trường');
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const sensors = await prisma.sensor.findMany({
      where: { siteId: site.id },
      orderBy: { createdAt: 'desc' }
    });

    return successResponse(res, { items: sensors }, 'Danh sách cảm biến của công trường');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error('Không tìm thấy công trường');
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

export const getSiteReadings = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { sensorId, limit } = req.query;

    const site = await prisma.site.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });
    
    if (!site) {
      const error = new Error('Không tìm thấy công trường');
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const maxLimit = limit ? parseInt(limit, 10) : 100;
    if (limit !== undefined && (isNaN(maxLimit) || maxLimit < 1)) {
      return errorResponse(res, 'Tham số limit không hợp lệ', 400);
    }

    const whereClause = sensorId 
      ? { sensorId, sensor: { siteId: site.id } }
      : { sensor: { siteId: site.id } };

    const readings = await prisma.sensorReading.findMany({
      where: whereClause,
      orderBy: { timestamp: 'desc' },
      take: maxLimit,
      include: {
        sensor: true
      }
    });

    return successResponse(res, { items: readings }, 'Lịch sử đo đạc của trạm cảm biến');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error('Không tìm thấy công trường');
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

export const assignInspector = async (req, res, next) => {
  try {
    const { id } = req.params;
    const assignSchema = z.object({
      inspectorId: z.string().optional().nullable(),
      inspectorName: z.string({ required_error: 'Tên cán bộ/Đội thanh tra là bắt buộc' }).min(1),
      slaHours: z.coerce.number().int().positive().default(48),
      note: z.string().optional().nullable(),
    });

    const validatedData = assignSchema.parse(req.body);
    const { inspectorId, inspectorName, slaHours, note } = validatedData;

    let site = await prisma.site.findFirst({
      where: {
        OR: [
          { id },
          { code: id }
        ],
        deletedAt: null
      }
    });

    if (!site && (id === 'site-default' || !id)) {
      site = await prisma.site.findFirst({
        where: { deletedAt: null },
        orderBy: { createdAt: 'asc' }
      });
    }

    if (!site) {
      const error = new Error(`Không tìm thấy công trình với mã hoặc ID "${id}"`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const dueDate = new Date(Date.now() + slaHours * 3600 * 1000);

    // 1. Permanently create Action entry in D1 database
    const createdAction = await prisma.action.create({
      data: {
        title: `Phân công kiểm tra: ${inspectorName}`,
        description: note ? `Chỉ đạo Lãnh đạo: ${note}` : `Yêu cầu kiểm tra thực địa tại ${site.name} (SLA: ${slaHours}h)`,
        status: 'PENDING',
        siteId: site.id,
        assignee: inspectorName,
        dueDate: dueDate
      }
    });

    // 2. Permanently record AuditLog entry in D1
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id || null,
        actorId: req.user?.id || 'executive_user',
        actorName: req.user?.fullName || req.user?.name || 'Lãnh đạo cơ quan',
        actorRole: req.user?.role || 'executive',
        action: 'INSPECTOR_ASSIGNMENT',
        targetId: site.id,
        details: JSON.stringify({
          siteId: site.id,
          siteName: site.name,
          inspectorId: inspectorId || 'insp-01',
          inspectorName,
          slaHours,
          note: note || '',
          actionId: createdAction.id,
          dueDate: dueDate.toISOString()
        })
      }
    });

    // 3. Update active Cases for this site with new SLA deadline & timeline record
    const activeCases = await prisma.case.findMany({
      where: {
        siteId: site.id,
        deletedAt: null,
        status: { notIn: ['COMPLETED', 'CLOSED'] }
      }
    });

    for (const c of activeCases) {
      await prisma.case.update({
        where: { id: c.id },
        data: { slaDeadline: dueDate }
      });

      await prisma.caseTimeline.create({
        data: {
          caseId: c.id,
          eventTitle: 'Phân công cán bộ / Đội thanh tra',
          eventDescription: `Lãnh đạo phân công ${inspectorName} phụ trách với thời hạn SLA ${slaHours}h. ${note ? `Chỉ đạo: ${note}` : ''}`,
          eventType: 'ASSIGNMENT',
          actorId: req.user?.id || 'executive_user',
          actorName: req.user?.fullName || req.user?.name || 'Lãnh đạo cơ quan',
          actorRole: req.user?.role || 'executive'
        }
      });
    }

    clearCache('sites:');
    clearCache('dashboard:');
    clearCache('actions:');

    logger.info('Inspector assigned successfully', {
      siteId: site.id,
      inspectorName,
      slaHours,
      actionId: createdAction.id
    });

    return successResponse(res, {
      siteId: site.id,
      siteName: site.name,
      inspectorId: inspectorId || 'insp-01',
      inspectorName,
      slaHours,
      dueDate: dueDate.toISOString(),
      actionId: createdAction.id,
      note: note || ''
    }, 'Phân công cán bộ thanh tra thành công');
  } catch (error) {
    if (error.code === 'P2025') {
      const err = new Error(`Không tìm thấy công trình để phân công (Mã/ID: "${req.params.id}")`);
      err.status = 404;
      err.code = 'ERR-SITE-404';
      return next(err);
    }
    next(error);
  }
};

/**
 * Phân tích chỉ số rủi ro CPS (0–100 điểm) và 4 trọng số giải trình
 */
export const getSiteRiskAnalysis = async (req, res, next) => {
  try {
    const { id } = req.params;
    const site = await prisma.site.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      },
      include: {
        sensors: {
          include: {
            readings: {
              orderBy: { timestamp: 'desc' },
              take: 5
            }
          }
        },
        inspections: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'desc' },
          take: 1
        },
        actions: {
          where: { status: 'VERIFIED', deletedAt: null }
        },
        complaints: {
          where: { deletedAt: null }
        }
      }
    });

    if (!site) {
      const error = new Error(`Không tìm thấy công trình với mã hoặc ID "${id}"`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const latestInspection = site.inspections[0] || null;
    const checklist = computeChecklistForSite(site, latestInspection, site.actions);

    const seedSite = SEED_SITES.find(s => 
      s.name === site.name || 
      site.name.includes(s.name) || 
      s.addr === site.address || 
      site.address.includes(s.addr)
    );
    const near = seedSite ? seedSite.near : [];

    const activeSensors = (site.sensors || []).filter(s => s.status === 'ACTIVE');
    const primarySensor = activeSensors[0] || site.sensors?.[0] || null;
    const latestReading = primarySensor?.readings?.[0] || null;

    const pm10 = latestReading?.pm10 ?? (site.currentPm10 || (site.dustRiskScore >= 80 ? 145 : site.dustRiskScore >= 50 ? 95 : 45));
    const pm25 = latestReading?.pm25 ?? (site.currentPm25 || (site.dustRiskScore >= 80 ? 82 : site.dustRiskScore >= 50 ? 55 : 32));

    const riskAnalysis = DustRiskEngine.calculate({
      telemetry: {
        pm10,
        pm25,
        lastReadingAt: latestReading?.timestamp || site.updatedAt || site.createdAt,
        history: primarySensor?.readings || []
      },
      sensors: site.sensors || [],
      observationCount: (site.complaints || []).length || 1,
      unresolvedCount: (site.complaints || []).filter(c => c.status === 'PENDING').length,
      sensitiveReceptors: near.length > 0 ? near.map(n => n.t === 'school' ? 'SCHOOL' : n.t === 'hospital' ? 'HOSPITAL' : 'RESIDENTIAL') : ['SCHOOL'],
      complianceChecklist: checklist
    });

    return successResponse(res, {
      siteId: site.id,
      siteCode: site.code,
      siteName: site.name,
      ...riskAnalysis
    }, 'Phân tích chỉ số rủi ro và các trọng số giải trình');
  } catch (error) {
    next(error);
  }
};

/**
 * Lịch sử thay đổi chỉ số ưu tiên / rủi ro của công trình
 */
export const getSitePriorityHistory = async (req, res, next) => {
  try {
    const { id } = req.params;
    const site = await prisma.site.findFirst({
      where: {
        OR: [{ id }, { code: id }],
        deletedAt: null
      }
    });

    if (!site) {
      const error = new Error(`Không tìm thấy công trình với mã hoặc ID "${id}"`);
      error.status = 404;
      error.code = 'ERR-SITE-404';
      throw error;
    }

    const auditEvents = await prisma.auditLog.findMany({
      where: {
        targetId: site.id,
        action: {
          in: ['PRIORITY_SCORE_RECALCULATED', 'SITE_RISK_SCORE_CHANGED', 'INSPECTOR_ASSIGNMENT', 'SENSOR_ALERT_TRIGGER']
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 20
    });

    const formattedHistory = auditEvents.map(evt => {
      let details = {};
      try {
        details = typeof evt.details === 'string' ? JSON.parse(evt.details) : evt.details;
      } catch (e) {}
      return {
        id: evt.id,
        action: evt.action,
        actorName: evt.actorName,
        actorRole: evt.actorRole,
        previousScore: details?.previousScore,
        newScore: details?.newScore ?? site.dustRiskScore,
        previousLevel: details?.previousLevel,
        newLevel: details?.newLevel ?? site.riskLevel,
        reasons: details?.reasons || [],
        createdAt: evt.createdAt
      };
    });

    return successResponse(res, {
      siteId: site.id,
      siteCode: site.code,
      siteName: site.name,
      currentScore: site.dustRiskScore,
      currentLevel: site.riskLevel,
      items: formattedHistory
    }, 'Lịch sử thay đổi chỉ số ưu tiên và can thiệp');
  } catch (error) {
    next(error);
  }
};



