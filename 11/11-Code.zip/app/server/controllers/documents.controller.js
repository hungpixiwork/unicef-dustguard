import path from 'path';
import { fileURLToPath } from 'url';
import { z } from 'zod';
import crypto from 'crypto';
import { successResponse, errorResponse, formatZodError, parsePaginationParams } from '../lib/response.js';

import { safeJsonParse } from '../lib/jsonHelper.js';
import { logAuditEvent } from '../lib/auditLogger.js';
import { callConfiguredLLM } from '../lib/aiService.js';
import { CHECKLIST_ITEMS, LEGAL_MAPPING } from '../../src/lib/riskEngine.js';
import { buildOfficialDocumentModel, generateOfficialDocx } from '../services/official-document.service.js';
import { prisma } from '../shared/db.js';
import { transitionCaseStatus } from '../services/case.service.js';
import { clearCache } from '../lib/cache.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 100% verified legal mappings dynamically loaded from single source of truth (LEGAL_MAPPING)
const VIETNAMESE_LEGAL_MAP = Object.keys(LEGAL_MAPPING).reduce((acc, key) => {
  const item = LEGAL_MAPPING[key];
  acc[key] = {
    clause: item.clause,
    standard: item.standard,
    fine: item.fine,
    fix: item.fix
  };
  return acc;
}, {});

// Generate structured legal basis text deterministically based on checked items
function buildDeterministicLegalContent(items, docKind) {
  const failedItems = items.filter(item => item.status === 'fail');
  
  if (failedItems.length === 0) {
    return 'Không phát hiện hành vi vi phạm quy định bảo vệ môi trường trong thi công xây dựng tại thời điểm kiểm tra.';
  }

  let text = 'Đoàn kiểm tra ghi nhận các hành vi vi phạm quy định về bảo vệ môi trường, kiểm soát bụi như sau:\n\n';
  
  failedItems.forEach((item, index) => {
    const legal = VIETNAMESE_LEGAL_MAP[item.k] || {
      clause: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
      standard: 'Quy chuẩn bảo vệ môi trường xây dựng',
      fine: 'Xem xét xử lý theo quy định',
      fix: 'Khắc phục ngay vi phạm.'
    };
    const checklistMeta = CHECKLIST_ITEMS.find(c => c.k === item.k) || { label: item.title || item.k, desc: '' };
    
    text += `${index + 1}. **Hành vi vi phạm:** Không đảm bảo quy định về "${checklistMeta.label}" tại công trường.\n`;
    text += `   - *Hiện trạng:* ${item.notes || 'Chưa thực hiện đầy đủ biện pháp bảo vệ môi trường.'}\n`;
    text += `   - *Căn cứ pháp lý:* Vi phạm quy định tại **${legal.clause}** (áp dụng tiêu chuẩn **${legal.standard}**).\n`;
    text += `   - *Mức xử phạt đề xuất:* Khung phạt **${legal.fine}** theo Nghị định 45/2022/NĐ-CP.\n`;
    text += `   - *Yêu cầu khắc phục:* ${legal.fix}\n\n`;
  });

  return text;
}

// Zod validation schemas
export const createDraftDocumentSchema = z.object({
  siteId: z.string({ required_error: 'siteId là bắt buộc' }).min(1, 'siteId không được để trống'),
  caseId: z.string().optional().nullable(),
  inspectionId: z.string().optional().nullable(),
  alertId: z.string().optional().nullable(),
  documentKind: z.string().optional(),
  mode: z.string().optional(),
  items: z.any().optional(),
  tone: z.string().optional(),
  metadata: z.any().optional()
});

export const updateDraftDocumentSchema = z.object({
  title: z.string().min(1, 'Tiêu đề không được để trống').optional(),
  content: z.string().min(1, 'Nội dung không được để trống').optional(),
  status: z.string().optional(),
  metadata: z.any().optional()
});

export const exportDraftDocumentSchema = z.object({
  format: z.enum(['docx', 'pdf']).default('docx'),
  official_template: z.string().optional(),
  organization: z.object({
    parent: z.string().optional(),
    name: z.string().optional(),
    document_number: z.string().optional(),
    location: z.string().optional()
  }).optional(),
  officer: z.object({
    name: z.string().optional(),
    title: z.string().optional(),
    signer: z.string().optional(),
    signer_title: z.string().optional()
  }).optional(),
  metadata: z.record(z.unknown()).optional()
}).strict();

export const exportToDocxSchema = z.object({
  title: z.string().optional(),
  content: z.string({ required_error: 'Nội dung văn bản là bắt buộc' }).min(1, 'Nội dung không được để trống'),
  documentType: z.string().optional(),
  organization: z.object({
    parent: z.string().optional(),
    name: z.string().optional()
  }).optional(),
  officer: z.object({
    name: z.string().optional(),
    title: z.string().optional()
  }).optional(),
  metadata: z.any().optional()
});

async function syncCaseStatusFromDocument(draftDoc, actor) {
  try {
    if (!draftDoc.caseId) return;

    const caseRecord = await prisma.case.findUnique({
      where: { id: draftDoc.caseId }
    });

    if (!caseRecord) return;

    const currentStatus = caseRecord.status;

    if (draftDoc.status === 'SIGNED' || draftDoc.status === 'APPROVED') {
      if (draftDoc.documentType === 'quyet-dinh-kiem-tra') {
        if (currentStatus === 'DECISION_ISSUED' || currentStatus === 'PREPARING' || currentStatus === 'SCREENING') {
          await transitionCaseStatus(draftDoc.caseId, 'ON_SITE', actor, {
            note: `Hệ thống tự động chuyển sang bước ON_SITE sau khi Quyết định kiểm tra #${draftDoc.id} được phê duyệt/ký số.`
          });
        }
      } else if (draftDoc.documentType === 'bien-ban-vphc' || draftDoc.documentType === 'bien-ban-kiem-tra') {
        if (currentStatus === 'ON_SITE' || currentStatus === 'PROCESSING' || currentStatus === 'PENDING') {
          await transitionCaseStatus(draftDoc.caseId, 'REPORTING', actor, {
            note: `Hệ thống tự động chuyển trạng thái sang REPORTING sau khi biên bản VPHC #${draftDoc.id} được ký phê duyệt/đóng dấu đỏ.`
          });
        }
      } else if (draftDoc.documentType === 'quyet-dinh-xu-phat' || draftDoc.documentType === 'corrective_notice') {
        if (currentStatus === 'REPORTING' || currentStatus === 'APPRAISING' || currentStatus === 'VIOLATED' || currentStatus === 'EXPLAINING' || currentStatus === 'PROCESSING' || currentStatus === 'SANCTIONED') {
          await transitionCaseStatus(draftDoc.caseId, 'COMPLETED', actor, {
            note: `Hệ thống tự động chuyển trạng thái sang COMPLETED sau khi thông báo khắc phục/Quyết định xử phạt #${draftDoc.id} được phê duyệt.`
          });
        }
      }
    }
  } catch (err) {
    console.error('Failed to sync case status from document:', err.message);
  }
}

// 1. Create Legal Document Draft
export const createDraftDocument = async (req, res, next) => {
  try {
    const resultValidation = createDraftDocumentSchema.safeParse(req.body);
    if (!resultValidation.success) {
      const { message, fieldErrors } = formatZodError(resultValidation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { siteId, caseId: inputCaseId, inspectionId, alertId, documentKind, mode, items, tone, metadata } = resultValidation.data;
    
    const targetSiteId = siteId;
    const targetInspectionId = inspectionId || null;
    const targetKind = documentKind || mode || 'corrective_notice';

    const site = await prisma.site.findUnique({
      where: { id: targetSiteId }
    });

    if (!site) {
      return errorResponse(res, 'Không tìm thấy công trình tương ứng.', 404);
    }

    const docTypeLabel = targetKind === 'bien-ban-vphc' 
      ? 'BIÊN BẢN VI PHẠM HÀNH CHÍNH' 
      : targetKind === 'bien-ban-kiem-tra' 
      ? 'BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG'
      : targetKind === 'quyet-dinh-kiem-tra'
      ? 'QUYẾT ĐỊNH KIỂM TRA'
      : targetKind === 'quyet-dinh-xu-phat'
      ? 'QUYẾT ĐỊNH XỬ PHẠT VI PHẠM HÀNH CHÍNH'
      : 'THÔNG BÁO YÊU CẦU KHẮC PHỤC VI PHẠM';

    const orgParent = metadata?.organization?.parent || 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG';
    const orgName = metadata?.organization?.name || 'ĐOÀN THANH TRA LIÊN NGÀNH';
    const officerName = metadata?.officer?.name || 'Nguyễn Văn An';
    const officerTitle = metadata?.officer?.title || 'Thanh tra viên môi trường';
    const docLocation = metadata?.location || 'Hà Nội';
    const docDate = metadata?.date || new Date().toLocaleDateString('vi-VN');
    const recipient = metadata?.recipient || site.investorName || 'Đơn vị thi công/chủ đầu tư công trình';
    const docNum = metadata?.docNum || '.....';
    const customObservations = metadata?.customObservations || '';
    const opinions = metadata?.opinions || '';
    const caseDraft = metadata?.caseDraft || null;

    let checklistList = [];
    if (items && Array.isArray(items)) {
      checklistList = items;
    } else if (items && Array.isArray(items.issues)) {
      checklistList = items.issues;
    } else {
      const actions = await prisma.action.findMany({
        where: { siteId: targetSiteId, status: 'PENDING' }
      });
      checklistList = actions.map(act => {
        const keyMatch = act.title.match(/Khắc phục vi phạm:\s*(.+)$/);
        return {
          k: keyMatch ? keyMatch[1].trim() : 'barrier',
          status: 'fail',
          notes: act.description
        };
      });
    }

    const deterministicLegalText = buildDeterministicLegalContent(checklistList, targetKind);

    let caseBuilderPrompt = '';
    if (caseDraft) {
      caseBuilderPrompt = `
BỔ SUNG THÔNG TIN HỒ SƠ VI PHẠM (Từ Trợ lý AI):
- Đánh giá hồ sơ vi phạm: ${caseDraft.summary || ''}
- Độ mạnh chứng cứ: ${caseDraft.strength || ''}
- Các hành vi vi phạm thực tế bổ sung:
${Array.isArray(caseDraft.violations) ? caseDraft.violations.map(v => `  + ${v}`).join('\n') : ''}
- Bằng chứng hiện có:
${caseDraft.evidence?.has ? caseDraft.evidence.has.map(e => `  + ${e}`).join('\n') : ''}
`;
    }

    const prompt = `Bạn là trợ lý pháp lý của cơ quan Thanh tra Môi trường Việt Nam.
Nhiệm vụ của bạn là soạn thảo bản dự thảo văn bản hành chính theo chuẩn Nghị định 30/2020/NĐ-CP.

HÃY SỬ DỤNG CHÍNH XÁC CÁC THÔNG TIN VÀ CĂN CỨ PHÁP LÝ SAU, TUYỆT ĐỐI KHÔNG HÀ LƯU, KHÔNG TỰ BỊA CĂN CỨ KHÁC:

Thông tin chung:
- Tên văn bản: ${docTypeLabel}
- Số văn bản: ${docNum}
- Địa điểm: ${docLocation}
- Ngày tháng năm: ${docDate}
- Cơ quan lập: ${orgParent} - ${orgName}
- Cán bộ lập: ${officerName} - ${officerTitle}
- Đối tượng được kiểm tra: ${recipient}

Thông tin công trường:
- Tên công trình: ${site.name}
- Địa chỉ: ${site.address}
${customObservations ? `- Ý kiến ghi nhận bổ sung của Cán bộ: ${customObservations}` : ''}
${opinions ? `- Ý kiến trình bày của Đại diện cơ sở: ${opinions}` : ''}
${caseBuilderPrompt}

Kết quả ghi nhận và Căn cứ pháp lý xử lý vi phạm (BẮT BUỘC TRÍCH NGUYÊN VĂN):
${deterministicLegalText}

Định dạng yêu cầu:
- Trả về văn bản dưới dạng Markdown chuẩn hành chính Việt Nam.
- Bao gồm đầy đủ các mục: I. Thành phần tham gia, II. Kết quả ghi nhận thực tế, III. Căn cứ pháp lý áp dụng, IV. Yêu cầu khắc phục và xử lý, V. Kết luận biên bản.
- Chỉ trả về duy nhất text Markdown văn bản, không giải thích gì thêm.`;

    let generatedContent = '';
    let providerName = 'system_fallback';
    let modelName = 'deterministic_template';

    try {
      const result = await callConfiguredLLM([
        { role: 'user', content: prompt }
      ], { maxTokens: 2500 });

      if (result && result.content) {
        generatedContent = result.content;
        providerName = result.provider;
        modelName = result.model;
      }
    } catch (aiError) {
      console.warn('AI generator failed, falling back to fully deterministic template:', aiError.message);
    }

    if (!generatedContent) {
      const failedItemsText = checklistList.filter(i => i.status === 'fail')
        .map((i, idx) => `  ${idx + 1}. Hạng mục "${i.title || i.k}" không đạt quy chuẩn. Ghi chú: ${i.notes || 'Chưa lắp đặt/thiết lập đầy đủ.'}`)
        .join('\n');

      generatedContent = `
# ${docTypeLabel}
## Về việc tuân thủ bảo vệ môi trường và kiểm soát bụi xây dựng tại công trường

Hôm nay, ngày ${docDate}, tại công trình: ${site.name} (${site.address}).
Đoàn thanh tra liên ngành tiến hành kiểm tra công tác kiểm soát bụi và khí thải xây dựng.

**I. THÀNH PHẦN THAM GIA:**
1. Ông **${officerName}** — Chức vụ: ${officerTitle} (Trưởng đoàn).
2. Đại diện đơn vị được kiểm tra: Ông **Phan Văn Dũng** — Chức vụ: Chỉ huy trưởng công trường.

**II. KẾT QUẢ GHI NHẬN HIỆN TRƯỜNG:**
Đoàn thanh tra tiến hành kiểm tra thực tế hiện trường và lập biên bản các vi phạm sau:
${failedItemsText || '  Không ghi nhận vi phạm nghiêm trọng nào tại thời điểm kiểm tra.'}
${customObservations ? `\nGhi nhận bổ sung: ${customObservations}` : ''}
${opinions ? `\nÝ kiến đối tượng kiểm tra: ${opinions}` : ''}

**III. CĂN CỨ PHÁP LÝ VÀ HÌNH THỨC XỬ PHẠT:**
${deterministicLegalText}

**IV. YÊU CẦU BIỆN PHÁP KHẮC PHỤC:**
1. Yêu cầu Ban chỉ huy công trình dừng ngay các hoạt động phát tán bụi diện rộng chưa được che chắn.
2. Thực hiện nghiêm túc các biện pháp khắc phục được chi tiết tại Mục III đối với từng vi phạm.
3. Thời hạn hoàn thành khắc phục và gửi báo cáo kết quả kèm minh chứng hình ảnh: Trước 17h00 ngày tiếp theo.

**V. KẾT LUẬN VÀ CHỮ KÝ CÁC BÊN:**
Biên bản này được lập thành 02 bản có giá trị pháp lý như nhau, đã được đọc lại cho các bên cùng nghe và ký tên xác nhận dưới đây.
`;
    }

    let activeCase = null;
    if (inputCaseId) {
      activeCase = await prisma.case.findUnique({ where: { id: inputCaseId } });
    }

    if (!activeCase) {
      activeCase = await prisma.case.findFirst({
        where: {
          siteId: targetSiteId,
          status: {
            notIn: ['COMPLETED']
          }
        },
        orderBy: { createdAt: 'desc' }
      });
    }

    if (!activeCase) {
      try {
        if (alertId) {
          const { createCaseFromAlert } = await import('../services/case.service.js');
          activeCase = await createCaseFromAlert(alertId, {
            id: req.user?.id || 'system',
            name: req.user?.fullName || req.user?.name || 'Cán bộ',
            role: req.user?.role || 'staff'
          });
        } else {
          const year = new Date().getFullYear();
          const code = `CASE-${year}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
          activeCase = await prisma.case.create({
            data: {
              code,
              title: `Vụ việc kiểm tra & xử lý - ${site.name}`,
              description: `Vụ việc được thiết lập tự động khi khởi tạo dự thảo văn bản pháp lý ${docTypeLabel}.`,
              siteId: targetSiteId,
              inspectionId: targetInspectionId,
              status: 'SCREENING'
            }
          });
          
          await prisma.caseTimeline.create({
            data: {
              caseId: activeCase.id,
              eventType: 'STATUS_SCREENING',
              eventTitle: 'Khởi tạo vụ việc tự động',
              eventDescription: `Vụ việc tự động thiết lập với trạng thái SCREENING để liên thông xử lý văn bản ${docTypeLabel}.`,
              actorId: req.user?.id || null,
              actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
              actorRole: req.user?.role || 'staff'
            }
          });
        }
      } catch (err) {
        console.warn('Failed to auto-create case', err.message);
      }
    } else if (alertId) {
      try {
        await prisma.alert.update({
          where: { id: alertId },
          data: { status: 'IN_PROGRESS' }
        });
        
        await prisma.caseTimeline.create({
          data: {
            caseId: activeCase.id,
            eventType: 'ALERT_LINKED',
            eventTitle: 'Liên kết cảnh báo cảm biến bổ sung',
            eventDescription: `Cảnh báo cảm biến (Alert ID: ${alertId}) được liên kết thêm vào vụ việc hiện tại.`,
            actorId: req.user?.id || null,
            actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
            actorRole: req.user?.role || 'staff'
          }
        });
      } catch (err) {
        console.warn('Failed to link existing alert to case', err.message);
      }
    }

    const draftDoc = await prisma.draftDocument.create({
      data: {
        siteId: targetSiteId,
        caseId: activeCase ? activeCase.id : null,
        inspectionId: targetInspectionId,
        documentType: targetKind,
        title: `${docTypeLabel} - ${site.name}`,
        content: generatedContent,
        status: 'DRAFT',
        metadata: JSON.stringify({
          organization: { parent: orgParent, name: orgName },
          officer: { name: officerName, title: officerTitle },
          location: docLocation,
          recipient: recipient,
          date: docDate,
          docNum: docNum,
          customObservations,
          opinions,
          caseDraft
        })
      }
    });

    if (activeCase) {
      try {
        await prisma.caseTimeline.create({
          data: {
            caseId: activeCase.id,
            eventType: 'DOCUMENT_DRAFTED',
            eventTitle: 'Khởi tạo dự thảo văn bản',
            eventDescription: `Dự thảo văn bản "${docTypeLabel} - ${site.name}" (Mã: ${draftDoc.id}) đã được tạo bởi hệ thống hỗ trợ nghiệp vụ AI.`,
            actorId: req.user?.id || null,
            actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
            actorRole: req.user?.role || 'staff'
          }
        });
      } catch (timelineErr) {
        console.warn('Failed to add case timeline for drafting', timelineErr.message);
      }
    }

    await logAuditEvent({
      action: 'DOCUMENT_CREATE',
      details: {
        documentId: draftDoc.id,
        siteId: draftDoc.siteId,
        title: draftDoc.title,
        documentType: draftDoc.documentType,
        status: draftDoc.status
      }
    }, req);

    clearCache('dashboard:');

    return successResponse(res, {
      draft_id: draftDoc.id,
      id: draftDoc.id,
      title: draftDoc.title,
      body_markdown: draftDoc.content,
      content: draftDoc.content,
      document_type: draftDoc.documentType,
      status: draftDoc.status,
      revision_number: 1,
      provider: providerName,
      model: modelName
    }, 'Tạo bản nháp văn bản thành công', 201);

  } catch (error) {
    next(error);
  }
};

// 2. List All Legal Document Drafts
export const listDraftDocuments = async (req, res, next) => {
  try {
    const { siteId } = req.query;
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    const where = { deletedAt: null };
    if (siteId) where.siteId = siteId;

    const [total, drafts] = await Promise.all([
      prisma.draftDocument.count({ where }),
      prisma.draftDocument.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          site: {
            select: { name: true, address: true, riskLevel: true, dustRiskScore: true }
          }
        }
      })
    ]);

    const parsedDrafts = drafts.map(d => ({
      ...d,
      metadata: safeJsonParse(d.metadata, {})
    }));

    return successResponse(res, {
      drafts: parsedDrafts,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Lấy danh sách bản nháp văn bản thành công');
  } catch (error) {
    next(error);
  }
};


// 3. Get Single Document Draft
export const getDraftDocument = async (req, res, next) => {
  try {
    const { id } = req.params;
    const draft = await prisma.draftDocument.findFirst({
      where: { id, deletedAt: null },
      include: { site: true }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản.', 404);
    }

    const parsedDraft = {
      ...draft,
      metadata: safeJsonParse(draft.metadata, {})
    };

    return successResponse(res, { draft: parsedDraft }, 'Lấy chi tiết bản nháp văn bản thành công');
  } catch (error) {
    next(error);
  }
};

// 4. Update A Document Draft
export const updateDraftDocument = async (req, res, next) => {
  try {
    const { id } = req.params;
    const resultValidation = updateDraftDocumentSchema.safeParse(req.body);
    if (!resultValidation.success) {
      const { message, fieldErrors } = formatZodError(resultValidation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { title, content, status, metadata } = resultValidation.data;

    if (status && (status === 'APPROVED' || status === 'SIGNED')) {
      const userRole = req.user?.role;
      if (!['executive', 'admin', 'demo_admin'].includes(userRole)) {
        return errorResponse(res, 'Chỉ lãnh đạo (Executive/Admin) mới có quyền phê duyệt hoặc ký duyệt văn bản.', 403);
      }
    }

    const currentDraft = await prisma.draftDocument.findFirst({
      where: { id, deletedAt: null },
      include: { revisions: true }
    });

    if (!currentDraft) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản.', 404);
    }

    const contentChanged = content !== undefined && content !== currentDraft.content;
    const titleChanged = title !== undefined && title !== currentDraft.title;
    
    if (contentChanged || titleChanged) {
      const nextRevNum = currentDraft.revisions.length + 1;
      await prisma.documentRevision.create({
        data: {
          documentId: id,
          title: currentDraft.title,
          content: currentDraft.content,
          metadata: currentDraft.metadata,
          revisionNumber: nextRevNum,
          updatedById: req.user?.id || null,
          updatedByName: req.user?.fullName || req.user?.name || null
        }
      });
      console.log(`[Document Versioning] Created revision #${nextRevNum} for Draft ${id}`);
    }

    const draft = await prisma.draftDocument.update({
      where: { id },
      data: {
        title,
        content,
        status,
        metadata: metadata ? (typeof metadata === 'object' ? JSON.stringify(metadata) : metadata) : undefined
      }
    });

    if (status) {
      await syncCaseStatusFromDocument(draft, {
        id: req.user?.id,
        name: req.user?.fullName || req.user?.name,
        role: req.user?.role
      });

      let actionType = 'DOCUMENT_UPDATE';
      if (status === 'PENDING_SIGN' || status === 'PENDING_APPROVAL' || status === 'SUBMITTED') {
        actionType = 'DOCUMENT_SUBMIT_SIGN';
      } else if (status === 'APPROVED' || status === 'SIGNED') {
        actionType = 'DOCUMENT_APPROVE_SIGN';
      }
      await logAuditEvent({
        action: actionType,
        details: {
          documentId: draft.id,
          title: draft.title,
          status: draft.status
        }
      }, req);
    } else {
      await logAuditEvent({
        action: 'DOCUMENT_UPDATE',
        details: {
          documentId: draft.id,
          title: draft.title
        }
      }, req);
    }

    clearCache('dashboard:');

    return successResponse(res, { draft }, 'Cập nhật bản nháp văn bản thành công');
  } catch (error) {
    next(error);
  }
};

// 5. Export persistent draft document to official DOCX binary
export const exportDraftDocument = async (req, res, next) => {
  try {
    if (process.env.ENABLE_EXPORT_GENERATION === 'false') {
      return res.status(503).json({
        status: 'error',
        code: 'KILL_SWITCH_ACTIVE',
        message: 'Export generation is temporarily disabled by kill switch.'
      });
    }

    const { id } = req.params;
    const resultValidation = exportDraftDocumentSchema.safeParse(req.body || {});

    if (!resultValidation.success) {
      const { message, fieldErrors } = formatZodError(resultValidation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { organization, officer, metadata } = resultValidation.data;

    const draft = await prisma.draftDocument.findUnique({
      where: { id }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản tương ứng.', 404);
    }

    const parsedMetadata = safeJsonParse(draft.metadata, {});

    const draft_document = {
      document_type: draft.documentType,
      content: draft.content,
      title: draft.title,
      status: draft.status
    };

    const model = buildOfficialDocumentModel({
      mode: draft.documentType,
      draft_document,
      organization: organization || parsedMetadata.organization || { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
      officer: officer || parsedMetadata.officer || {
        name: parsedMetadata.approvalInfo?.approvedByName || parsedMetadata.officer?.name || 'Nguyễn Văn An',
        title: parsedMetadata.officer?.title || 'Thanh tra viên môi trường'
      },
      metadata: metadata || {
        location: parsedMetadata.location || 'Hà Nội',
        recipient: parsedMetadata.recipient || 'Đơn vị thi công/chủ đầu tư công trình',
        issue_date: draft.signedAt ? draft.signedAt.toISOString() : new Date().toISOString()
      }
    });

    const buffer = await generateOfficialDocx(model);

    if (draft.status === 'DRAFT') {
      await prisma.draftDocument.update({
        where: { id },
        data: { status: 'EXPORTED' }
      });
    }

    clearCache('dashboard:');

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="dustguard-official-${draft.documentType || 'document'}-${id}.docx"`);
    res.send(buffer);

  } catch (error) {
    next(error);
  }
};

// Legacy generic export to DOCX
export const exportToDocx = async (req, res, next) => {
  try {
    const resultValidation = exportToDocxSchema.safeParse(req.body);
    if (!resultValidation.success) {
      const { message, fieldErrors } = formatZodError(resultValidation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { title, content, documentType, organization, officer, metadata } = resultValidation.data;

    const draft_document = {
      document_type: documentType || 'corrective_notice',
      content: content,
      title: title || 'Biên bản xử lý vi phạm'
    };

    const model = buildOfficialDocumentModel({
      mode: documentType || 'corrective_notice',
      draft_document,
      organization: organization || { parent: 'ỦY BAN NHÂN DÂN QUẬN', name: 'ỦY BAN NHÂN DÂN PHƯỜNG' },
      officer: officer || { name: 'Nguyễn Văn An', title: 'Thanh tra viên' },
      metadata: metadata || { location: 'Hà Nội' }
    });

    const buffer = await generateOfficialDocx(model);

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="dustguard-official-${documentType || 'doc'}.docx"`);
    res.send(buffer);

  } catch (error) {
    next(error);
  }
};

// Upload signed copy
export const uploadSignedDocument = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!req.file) {
      return errorResponse(res, 'Vui lòng tải lên 1 tệp văn bản ký đóng dấu.', 400);
    }

    const draft = await prisma.draftDocument.findUnique({ where: { id } });
    const inspection = await prisma.inspection.findUnique({ where: { id } });

    if (!draft && !inspection) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản hoặc biên bản kiểm tra tương ứng.', 404);
    }

    const fileUrl = `/uploads/${req.file.filename}`;

    if (draft) {
      const updatedDraft = await prisma.draftDocument.update({
        where: { id },
        data: {
          status: 'SIGNED',
          signedUrl: fileUrl
        }
      });

      if (updatedDraft.caseId) {
        try {
          await prisma.caseTimeline.create({
            data: {
              caseId: updatedDraft.caseId,
              eventType: 'DOCUMENT_SIGNED',
              eventTitle: 'Tải lên văn bản đã ký đóng dấu',
              eventDescription: `Bản quét văn bản đã ký đóng dấu của "${updatedDraft.title}" đã được tải lên bởi cán bộ ${req.user?.fullName || req.user?.name || ''}. Văn bản chính thức được lưu trữ và có hiệu lực thi hành.`,
              actorId: req.user?.id || null,
              actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
              actorRole: req.user?.role || 'staff'
            }
          });
        } catch (timelineErr) {
          console.warn('Failed to add case timeline for upload signed', timelineErr.message);
        }
      }

      await syncCaseStatusFromDocument(updatedDraft, {
        id: req.user?.id,
        name: req.user?.fullName || req.user?.name,
        role: req.user?.role
      });
    }

    if (inspection) {
      await prisma.evidence.create({
        data: {
          url: fileUrl,
          type: 'DOCUMENT',
          inspectionId: id
        }
      });
    }

    clearCache('dashboard:');

    return successResponse(res, { url: fileUrl }, 'Tải lên văn bản ký đóng dấu thành công!');
  } catch (error) {
    next(error);
  }
};

// Submit document for signing
export const submitDraftDocument = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const draft = await prisma.draftDocument.findUnique({
      where: { id }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản.', 404);
    }

    if (draft.status !== 'DRAFT') {
      return errorResponse(res, 'Tài liệu không ở trạng thái Bản nháp để trình ký.', 400);
    }

    const updatedDraft = await prisma.draftDocument.update({
      where: { id },
      data: {
        status: 'SUBMITTED',
        submittedById: req.user?.id || null
      }
    });

    if (updatedDraft.caseId) {
      try {
        await prisma.caseTimeline.create({
          data: {
            caseId: updatedDraft.caseId,
            eventType: 'DOCUMENT_SUBMITTED',
            eventTitle: 'Trình duyệt văn bản hành chính',
            eventDescription: `Bản nháp văn bản "${updatedDraft.title}" đã được trình lên người có thẩm quyền phê duyệt bởi cán bộ ${req.user?.fullName || req.user?.name || ''}.`,
            actorId: req.user?.id || null,
            actorName: req.user?.fullName || req.user?.name || 'Cán bộ',
            actorRole: req.user?.role || 'staff'
          }
        });
      } catch (timelineErr) {
        console.warn('Failed to add case timeline for document submission', timelineErr.message);
      }
    }

    clearCache('dashboard:');

    return successResponse(res, { draft: updatedDraft }, 'Trình ký bản nháp văn bản thành công');
  } catch (error) {
    next(error);
  }
};

// Approve document (Executive/Leader only)
export const approveDraftDocument = async (req, res, next) => {
  try {
    const { id } = req.params;

    const draft = await prisma.draftDocument.findUnique({
      where: { id }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy bản nháp văn bản.', 404);
    }

    if (draft.status !== 'SUBMITTED') {
      return errorResponse(res, 'Tài liệu phải ở trạng thái Đã trình ký để được phê duyệt.', 400);
    }

    const ipAddress = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || req.ip || '127.0.0.1';
    const signedAt = new Date();
    const approvedById = req.user?.id || 'system-approver';

    // Secure signature hashing based on content digest & approval metadata
    const contentHash = crypto.createHash('sha256').update(draft.content).digest('hex');
    const signData = {
      documentId: draft.id,
      contentHash,
      approvedById,
      signedAt: signedAt.toISOString(),
      ipAddress
    };
    
    const secret = process.env.HMAC_SECRET || process.env.JWT_SECRET || process.env.SIGNATURE_SECRET || process.env.AUTH_SECRET || process.env.BETTER_AUTH_SECRET || 'dustguard-signature-secret-fallback';
    const hash = crypto.createHmac('sha256', secret)
      .update(JSON.stringify(signData))
      .digest('hex');

    const parsedMetadata = safeJsonParse(draft.metadata, {});

    const updatedMetadata = {
      ...parsedMetadata,
      approvalInfo: {
        approvedById,
        approvedByName: req.user?.fullName || req.user?.name || 'Lãnh đạo phê duyệt',
        approvedByEmail: req.user?.email || '',
        signedAt: signedAt.toISOString(),
        ipAddress,
        signatureHash: hash
      }
    };

    const approvedDraft = await prisma.draftDocument.update({
      where: { id },
      data: {
        status: 'APPROVED',
        approvedById,
        signedAt,
        hash,
        metadata: JSON.stringify(updatedMetadata)
      }
    });

    if (approvedDraft.caseId) {
      try {
        await prisma.caseTimeline.create({
          data: {
            caseId: approvedDraft.caseId,
            eventType: 'DOCUMENT_APPROVED',
            eventTitle: 'Phê duyệt & Ký số văn bản',
            eventDescription: `Văn bản hành chính "${approvedDraft.title}" (Mã: ${approvedDraft.id}) đã được phê duyệt và ký số bởi Lãnh đạo ${req.user?.fullName || req.user?.name || ''}. Chữ ký điện tử đã được xác thực mã hóa: ${hash.slice(0, 16)}...`,
            actorId: req.user?.id || null,
            actorName: req.user?.fullName || req.user?.name || 'Lãnh đạo',
            actorRole: req.user?.role || 'executive'
          }
        });
      } catch (timelineErr) {
        console.warn('Failed to add case timeline for approval', timelineErr.message);
      }
    }

    await syncCaseStatusFromDocument(approvedDraft, {
      id: req.user?.id,
      name: req.user?.fullName || req.user?.name,
      role: req.user?.role
    });

    clearCache('dashboard:');

    return successResponse(
      res, 
      { 
        draft: approvedDraft,
        approval: {
          ipAddress,
          signedAt,
          hash
        }
      }, 
      'Phê duyệt và ký số văn bản thành công'
    );
  } catch (error) {
    next(error);
  }
};

// 6. List revisions for a draft document
export const listDraftRevisions = async (req, res, next) => {
  try {
    const { id } = req.params;
    const revisions = await prisma.documentRevision.findMany({
      where: { documentId: id },
      orderBy: { revisionNumber: 'desc' }
    });
    return successResponse(res, { revisions }, 'Lấy danh sách lịch sử phiên bản thành công');
  } catch (error) {
    next(error);
  }
};

// 7. Restore a specific revision for a draft document
export const restoreDraftRevision = async (req, res, next) => {
  try {
    const { id, revisionId } = req.params;
    
    const revision = await prisma.documentRevision.findUnique({
      where: { id: revisionId }
    });

    if (!revision || revision.documentId !== id) {
      return errorResponse(res, 'Không tìm thấy phiên bản lịch sử tương ứng để khôi phục.', 404);
    }

    const currentDraft = await prisma.draftDocument.findUnique({
      where: { id },
      include: { revisions: true }
    });

    const nextRevNum = currentDraft.revisions.length + 1;
    await prisma.documentRevision.create({
      data: {
        documentId: id,
        title: currentDraft.title,
        content: currentDraft.content,
        metadata: currentDraft.metadata,
        revisionNumber: nextRevNum,
        updatedById: req.user?.id || null,
        updatedByName: req.user?.fullName || req.user?.name || null
      }
    });

    const updatedDraft = await prisma.draftDocument.update({
      where: { id },
      data: {
        title: revision.title,
        content: revision.content,
        metadata: revision.metadata || undefined
      }
    });

    await logAuditEvent({
      action: 'DOCUMENT_RESTORE_REVISION',
      details: {
        documentId: id,
        revisionId: revision.id,
        revisionNumber: revision.revisionNumber
      }
    }, req);

    clearCache('dashboard:');

    return successResponse(res, { draft: updatedDraft }, `Khôi phục thành công về phiên bản #${revision.revisionNumber}`);
  } catch (error) {
    next(error);
  }
};

// 8. Verify digital signature of an approved document
export const verifyDraftDocument = async (req, res, next) => {
  try {
    const { id } = req.params;

    const draft = await prisma.draftDocument.findUnique({
      where: { id }
    });

    if (!draft) {
      return errorResponse(res, 'Không tìm thấy văn bản để xác thực chữ ký.', 404);
    }

    if (!draft.hash && draft.status !== 'APPROVED' && draft.status !== 'SIGNED' && draft.status !== 'EXPORTED') {
      return successResponse(res, {
        verified: false,
        documentId: draft.id,
        title: draft.title,
        status: draft.status,
        message: 'Văn bản chưa được phê duyệt hoặc ký số điện tử.'
      });
    }

    const parsedMetadata = safeJsonParse(draft.metadata, {});
    const approvalInfo = parsedMetadata.approvalInfo || {};

    const contentHash = crypto.createHash('sha256').update(draft.content).digest('hex');
    const signedAt = approvalInfo.signedAt || (draft.signedAt ? draft.signedAt.toISOString() : '');
    const approvedById = approvalInfo.approvedById || draft.approvedById || '';
    const ipAddress = approvalInfo.ipAddress || '127.0.0.1';

    const signData = {
      documentId: draft.id,
      contentHash,
      approvedById,
      signedAt,
      ipAddress
    };

    const secret = process.env.HMAC_SECRET || process.env.JWT_SECRET || process.env.SIGNATURE_SECRET || process.env.AUTH_SECRET || process.env.BETTER_AUTH_SECRET || 'dustguard-signature-secret-fallback';
    const expectedHash = crypto.createHmac('sha256', secret)
      .update(JSON.stringify(signData))
      .digest('hex');

    // Timing-safe signature validation: Hash in database must match the recomputed HMAC derived from current content
    let signatureMatches = false;
    if (draft.hash && expectedHash) {
      try {
        const bufA = Buffer.from(draft.hash, 'hex');
        const bufB = Buffer.from(expectedHash, 'hex');
        if (bufA.length === bufB.length) {
          signatureMatches = crypto.timingSafeEqual(bufA, bufB);
        }
      } catch (e) {
        signatureMatches = false;
      }
    }

    if (signatureMatches) {
      return successResponse(res, {
        verified: true,
        documentId: draft.id,
        title: draft.title,
        documentType: draft.documentType,
        status: draft.status,
        signedAt: draft.signedAt || approvalInfo.signedAt,
        approvedByName: approvalInfo.approvedByName || 'Lãnh đạo có thẩm quyền',
        signatureHash: draft.hash,
        contentHash,
        signerEmail: approvalInfo.approvedByEmail || null
      }, 'Chữ ký số hợp lệ và toàn vẹn.');
    } else {
      return successResponse(res, {
        verified: false,
        documentId: draft.id,
        title: draft.title,
        status: draft.status,
        signatureHash: draft.hash,
        expectedHash,
        message: 'Cảnh báo: Nội dung văn bản hoặc chữ ký số không hợp lệ (có thể đã bị chỉnh sửa sau khi ký).'
      });
    }
  } catch (error) {
    next(error);
  }
};
