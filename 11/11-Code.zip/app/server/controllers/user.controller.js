import { z } from 'zod';
import { successResponse, errorResponse, formatZodError, parsePaginationParams } from '../lib/response.js';
import { prisma } from '../shared/db.js';
import { auth } from '../auth.js';

const createUserSchema = z.object({
  email: z.string({ required_error: 'Email là bắt buộc' }).email('Email không đúng định dạng'),
  password: z.string({ required_error: 'Mật khẩu là bắt buộc' }).min(8, 'Mật khẩu phải chứa ít nhất 8 ký tự'),
  role: z.enum(['citizen', 'staff', 'executive', 'admin', 'contractor']).default('citizen'),
  profile: z.object({
    fullName: z.string().min(1, 'Họ và tên không được để trống'),
    phoneNumber: z.string().optional(),
    avatarUrl: z.string().optional(),
    department: z.string().optional()
  }).optional()
});

const updateUserProfileSchema = z.object({
  fullName: z.string().min(1, 'Họ và tên không được để trống').optional(),
  phoneNumber: z.string().optional(),
  avatarUrl: z.string().optional(),
  department: z.string().optional()
});

export const getUsers = async (req, res, next) => {
  try {
    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    const { role, status, search } = req.query;

    const where = {};
    if (role && role !== 'ALL') where.role = role;
    if (status && status !== 'ALL') where.status = status;
    if (search) {
      where.OR = [
        { fullName: { contains: search } },
        { email: { contains: search } }
      ];
    }

    const [total, users] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.findMany({
        where,
        skip: offset,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { profile: true }
      })
    ]);
    return successResponse(res, {
      items: users,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    }, 'Lấy danh sách người dùng thành công');
  } catch (error) {
    next(error);
  }
};

export const updateUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    if (!status || !['ACTIVE', 'INACTIVE', 'DISABLED'].includes(status)) {
      return errorResponse(res, 'Trạng thái không hợp lệ (ACTIVE, INACTIVE, DISABLED)', 400);
    }
    const updatedUser = await prisma.user.update({
      where: { id },
      data: { status },
      include: { profile: true }
    });
    return successResponse(res, updatedUser, 'Cập nhật trạng thái người dùng thành công');
  } catch (error) {
    next(error);
  }
};


export const getUserById = async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      include: { profile: true }
    });
    if (!user) {
      return errorResponse(res, 'Không tìm thấy người dùng', 404);
    }
    return successResponse(res, user, 'Lấy thông tin người dùng thành công');
  } catch (error) {
    next(error);
  }
};

export const createUser = async (req, res, next) => {
  try {
    const result = createUserSchema.safeParse(req.body);
    if (!result.success) {
      const { message, fieldErrors } = formatZodError(result.error);
      return errorResponse(res, message, 400, fieldErrors);
    }
    
    const { email, password, role, profile } = result.data;
    
    // Register user via better-auth api to hash password and set up account
    const signUpResult = await auth.api.signUpEmail({
      body: {
        email,
        password,
        name: profile?.fullName || email.split('@')[0],
      }
    });
    
    const userId = signUpResult.user.id;
    
    // Update the role and profile
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        role,
        profile: profile ? {
          create: {
            fullName: profile.fullName,
            phoneNumber: profile.phoneNumber,
            avatarUrl: profile.avatarUrl,
            department: profile.department
          }
        } : undefined
      },
      include: { profile: true }
    });
    
    return successResponse(res, updatedUser, 'Tạo người dùng thành công', 201);
  } catch (error) {
    next(error);
  }
};

export const updateUserProfile = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (req.user.id !== id && req.user.role !== 'admin') {
      return errorResponse(res, 'Bạn không có quyền chỉnh sửa hồ sơ này.', 403);
    }
    const result = updateUserProfileSchema.safeParse(req.body);
    if (!result.success) {
      const { message, fieldErrors } = formatZodError(result.error);
      return errorResponse(res, message, 400, fieldErrors);
    }
    
    const { fullName, phoneNumber, avatarUrl, department } = result.data;
    
    // Retrieve the existing user/profile to handle defaults and avoid nullable violations on create
    const user = await prisma.user.findUnique({
      where: { id },
      include: { profile: true }
    });
    if (!user) {
      return errorResponse(res, 'Không tìm thấy người dùng', 404);
    }

    const finalFullName = fullName || user.profile?.fullName || user.fullName || '';

    const updatedProfile = await prisma.profile.upsert({
      where: { userId: id },
      update: { 
        fullName: fullName || undefined, 
        phoneNumber: phoneNumber !== undefined ? phoneNumber : undefined, 
        avatarUrl: avatarUrl !== undefined ? avatarUrl : undefined, 
        department: department !== undefined ? department : undefined 
      },
      create: { 
        userId: id, 
        fullName: finalFullName, 
        phoneNumber: phoneNumber || null, 
        avatarUrl: avatarUrl || null, 
        department: department || null 
      }
    });

    if (fullName) {
      await prisma.user.update({
        where: { id },
        data: { fullName }
      });
    }
    
    return successResponse(res, updatedProfile, 'Cập nhật thông tin cá nhân thành công');
  } catch (error) {
    next(error);
  }
};

const citizenProfileSchema = z.object({
  fullName: z.string().optional(),
  nickname: z.string().optional(),
  organization: z.string().optional(),
  identityMode: z.enum(['anonymous', 'nickname', 'organization', 'ANONYMOUS', 'NICKNAME', 'ORGANIZATION']).default('anonymous'),
  notifyWebPush: z.boolean().default(true),
  notifyEmail: z.boolean().default(false),
  phoneNumber: z.string().optional(),
  avatarUrl: z.string().optional()
});

export const getCitizenProfile = async (req, res, next) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return errorResponse(res, 'Vui lòng đăng nhập để truy cập hồ sơ.', 401);
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true }
    });

    if (!user) {
      return errorResponse(res, 'Không tìm thấy thông tin tài khoản.', 404);
    }

    let preferences = {};
    if (user.profile?.department && user.profile.department.startsWith('{')) {
      try {
        preferences = JSON.parse(user.profile.department);
      } catch {}
    }

    const data = {
      id: user.id,
      email: user.email,
      fullName: user.profile?.fullName || user.fullName || '',
      phoneNumber: user.profile?.phoneNumber || '',
      avatarUrl: user.profile?.avatarUrl || user.image || '',
      nickname: preferences.nickname || user.profile?.fullName || user.fullName || '',
      organization: preferences.organization || (!preferences.nickname ? user.profile?.department : '') || '',
      identityMode: (preferences.identityMode || 'anonymous').toLowerCase(),
      notifyWebPush: preferences.notifyWebPush !== undefined ? Boolean(preferences.notifyWebPush) : true,
      notifyEmail: preferences.notifyEmail !== undefined ? Boolean(preferences.notifyEmail) : false
    };

    return successResponse(res, data, 'Lấy thông tin hồ sơ thành công');
  } catch (error) {
    next(error);
  }
};

export const updateCitizenProfile = async (req, res, next) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return errorResponse(res, 'Vui lòng đăng nhập để lưu cài đặt hồ sơ.', 401);
    }

    const result = citizenProfileSchema.safeParse(req.body);
    if (!result.success) {
      const { message, fieldErrors } = formatZodError(result.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const {
      fullName,
      nickname,
      organization,
      identityMode: rawMode,
      notifyWebPush,
      notifyEmail,
      phoneNumber,
      avatarUrl
    } = result.data;

    const normalizedMode = (rawMode || 'anonymous').toLowerCase();

    // Mode-specific validation rules
    if (normalizedMode === 'nickname') {
      if (!nickname || !nickname.trim() || nickname.trim().length < 2) {
        return res.status(400).json({
          status: 'error',
          statusCode: 400,
          code: 'VALIDATION_ERROR',
          field: 'nickname',
          message: 'Vui lòng nhập Nickname (tối thiểu 2 ký tự) khi chọn chế độ Công khai Nickname.',
          error: 'Vui lòng nhập Nickname (tối thiểu 2 ký tự) khi chọn chế độ Công khai Nickname.'
        });
      }
    }

    if (normalizedMode === 'organization') {
      if (!organization || !organization.trim() || organization.trim().length < 2) {
        return res.status(400).json({
          status: 'error',
          statusCode: 400,
          code: 'VALIDATION_ERROR',
          field: 'organization',
          message: 'Vui lòng nhập Trường học / CLB khi chọn chế độ Thành viên Tổ chức.',
          error: 'Vui lòng nhập Trường học / CLB khi chọn chế độ Thành viên Tổ chức.'
        });
      }
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true }
    });

    if (!user) {
      return errorResponse(res, 'Không tìm thấy người dùng.', 404);
    }

    const cleanNickname = nickname ? nickname.trim() : '';
    const cleanOrganization = organization ? organization.trim() : '';
    const preferencesPayload = JSON.stringify({
      nickname: cleanNickname,
      organization: cleanOrganization,
      identityMode: normalizedMode,
      notifyWebPush: Boolean(notifyWebPush),
      notifyEmail: Boolean(notifyEmail)
    });

    const finalFullName = fullName?.trim() || cleanNickname || user.profile?.fullName || user.fullName || 'Người dân';

    const updatedProfile = await prisma.profile.upsert({
      where: { userId },
      update: {
        fullName: finalFullName,
        phoneNumber: phoneNumber !== undefined ? (phoneNumber?.trim() || null) : undefined,
        avatarUrl: avatarUrl !== undefined ? avatarUrl : undefined,
        department: preferencesPayload
      },
      create: {
        userId,
        fullName: finalFullName,
        phoneNumber: phoneNumber?.trim() || null,
        avatarUrl: avatarUrl || null,
        department: preferencesPayload
      }
    });

    if (fullName) {
      await prisma.user.update({
        where: { id: userId },
        data: { fullName: finalFullName }
      });
    }

    const responseData = {
      id: userId,
      email: user.email,
      fullName: finalFullName,
      phoneNumber: updatedProfile.phoneNumber || '',
      avatarUrl: updatedProfile.avatarUrl || '',
      nickname: cleanNickname || finalFullName,
      organization: cleanOrganization,
      identityMode: normalizedMode,
      notifyWebPush: Boolean(notifyWebPush),
      notifyEmail: Boolean(notifyEmail)
    };

    return successResponse(res, responseData, 'Cập nhật hồ sơ và cài đặt thành công');
  } catch (error) {
    next(error);
  }
};

export const deleteUser = async (req, res, next) => {
  try {
    const updatedUser = await prisma.user.update({
      where: { id: req.params.id },
      data: { status: 'DISABLED' }
    });
    return successResponse(res, updatedUser, 'Vô hiệu hóa người dùng thành công');
  } catch (error) {
    next(error);
  }
};

const updateUserRoleSchema = z.object({
  role: z.enum(['citizen', 'staff', 'executive', 'admin', 'contractor', 'youth_member', 'inspector', 'super_admin', 'demo_admin'], {
    required_error: 'Vai trò (role) là bắt buộc',
    invalid_type_error: 'Vai trò không hợp lệ'
  })
});

export const updateUserRole = async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = updateUserRoleSchema.safeParse(req.body);
    if (!result.success) {
      const { message, fieldErrors } = formatZodError(result.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { role } = result.data;
    const user = await prisma.user.findUnique({
      where: { id },
      include: { profile: true }
    });
    if (!user) {
      return errorResponse(res, 'Không tìm thấy người dùng', 404);
    }

    const updatedUser = await prisma.user.update({
      where: { id },
      data: { role },
      include: { profile: true }
    });

    return successResponse(res, updatedUser, 'Cập nhật vai trò người dùng thành công');
  } catch (error) {
    next(error);
  }
};

