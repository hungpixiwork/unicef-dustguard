import { createHash, randomUUID } from 'node:crypto';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const pdf = require('pdf-parse');
import mammoth from 'mammoth';
import { z } from 'zod';
import { successResponse, errorResponse, formatZodError, parsePaginationParams } from '../lib/response.js';

import { safeJsonParse } from '../lib/jsonHelper.js';
import {
  extractLegalObligationsWithAI,
  extractLegalObligations,
  extractPdfTextWithConfiguredAI,
  getAiCapabilities
} from '../lib/aiService.js';
import { LEGAL_SOURCE_SEEDS } from '../lib/legal-source-seeds.js';
import { prisma } from '../shared/db.js';
import logger from '../lib/logger.js';
import { getCached, setCached, clearCache } from '../lib/cache.js';

const MAX_UPLOAD_SIZE = 40 * 1024 * 1024;
const MAX_TEXT_LENGTH = 500000;
const MAX_AI_EXTRACTION_TEXT_LENGTH = 120000;
const MIN_MEANINGFUL_TEXT_LENGTH = 40;
const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
const PDF_MIME = 'application/pdf';

// Helper: checksum
function checksum(buffer) {
  return buffer ? createHash('sha256').update(buffer).digest('hex') : null;
}

// Helper: build reference preview text
function buildReferenceText(doc) {
  return [
    `${doc.code} - ${doc.title}`,
    `Loại văn bản: ${doc.document_type}`,
    `Cơ quan ban hành: ${doc.issuer}`,
    `Ngày ban hành: ${doc.issued_date || 'Đang cập nhật'}`,
    `Ngày hiệu lực: ${doc.effective_date || 'Đang cập nhật'}`,
    `Nguồn: ${doc.source_url || 'manual-seed'}`,
    '',
    doc.text
  ].join('\n');
}

// Helper: infer doc type
function inferDocumentType(text = '', filename = '') {
  const value = `${filename} ${text.slice(0, 500)}`.toLowerCase();
  if (value.includes('thông tư')) return 'Thông tư';
  if (value.includes('nghị quyết')) return 'Nghị quyết';
  if (value.includes('nghị định')) return 'Nghị định';
  if (value.includes('quyết định')) return 'Quyết định';
  if (value.includes('qcvn') || value.includes('quy chuẩn')) return 'Quy chuẩn';
  return 'Khác';
}

// Helper: infer doc code
function inferCode(text = '', filename = '') {
  const source = `${filename}\n${text.slice(0, 1200)}`;
  const match = source.match(/(?:NĐ|QĐ|TT|QCVN|TCVN|NQ)?\s*\d+[\w.:/-]*(?:NĐ-CP|QĐ-UBND|TT-[A-ZĐ]+|BTNMT|BXD|NQ-[A-ZĐ]+)?/i);
  return match ? match[0].replace(/\s+/g, ' ').trim() : null;
}

// Helper: normalize text formatting
function normalizeText(raw = '') {
  return String(raw).replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
}

// Helper: detect likely scan PDF
function isLikelyScanPdf(text) {
  const cleaned = String(text || '').replace(/\s+/g, ' ').trim();
  return cleaned.length < MIN_MEANINGFUL_TEXT_LENGTH;
}

// Helper: ensure all seed legal documents and obligations exist in SQLite
async function checkAndSeed() {
  try {
    for (const seed of LEGAL_SOURCE_SEEDS) {
      const docChecksum = checksum(Buffer.from(seed.text || '', 'utf8'));
      
      // Upsert Document
      await prisma.legalDocument.upsert({
        where: { id: seed.id },
        update: {
          text: seed.text,
          code: seed.code || null,
          title: seed.title || null,
          issuer: seed.issuer || null,
          issuedDate: seed.issued_date || null,
          effectiveDate: seed.effective_date || null,
          documentType: seed.document_type || null,
        },
        create: {
          id: seed.id,
          text: seed.text,
          sourceType: seed.source_type || 'seed_reference',
          status: seed.status || 'extracted_seed',
          code: seed.code || null,
          title: seed.title || null,
          issuer: seed.issuer || null,
          issuedDate: seed.issued_date || null,
          effectiveDate: seed.effective_date || null,
          sourceUrl: seed.source_url || null,
          documentType: seed.document_type || null,
          checksum: docChecksum
        }
      });

      // Upsert Obligations
      if (Array.isArray(seed.obligations) && seed.obligations.length) {
        for (const ob of seed.obligations) {
          const oblId = ob.obligation_id || `obl_${seed.id}_${ob.checklist_item || 'gen'}`;
          const existingObl = await prisma.legalObligation.findFirst({
            where: { docId: seed.id, obligationId: oblId }
          });

          if (!existingObl) {
            await prisma.legalObligation.create({
              data: {
                id: `obl_${randomUUID()}`,
                docId: seed.id,
                obligationId: oblId,
                subject: ob.subject || null,
                action: ob.action || null,
                condition: ob.condition || null,
                deadline: ob.deadline || null,
                legalBasis: typeof ob.legal_basis === 'string' ? ob.legal_basis : JSON.stringify(ob.legal_basis || {}),
                evidenceRequired: typeof ob.evidence_required === 'string' ? ob.evidence_required : JSON.stringify(ob.evidence_required || []),
                riskLevel: ob.risk_level || 'medium',
                checklistItem: ob.checklist_item || null,
                recommendedAction: ob.recommended_action || null,
                confidenceScore: ob.confidence_score || 0.7,
                status: 'approved' // Automatically approved for seeds
              }
            });
          }
        }
      }
    }
    logger.info('LEGAL_SOURCE_SEEDS verified and seeded in SQLite database.');
  } catch (error) {
    logger.error('Error seeding legal documents in SQLite', { error: error.message, stack: error.stack });
  }
}

// 1. List Legal Documents
export const listLegalDocuments = async (req, res, next) => {
  try {
    await checkAndSeed();

    const { limit, offset, page, pageSize } = parsePaginationParams(req, 50, 100);
    const cacheKey = `legal:documents:list:${page}:${limit}`;
    const cached = getCached(cacheKey);
    if (cached) {
      return successResponse(res, cached, 'Danh sách văn bản pháp lý (cached)');
    }

    const [total, docs] = await Promise.all([
      prisma.legalDocument.count(),
      prisma.legalDocument.findMany({
        orderBy: { updatedAt: 'desc' },
        skip: offset,
        take: limit
      })
    ]);

    const items = docs.map(doc => ({
      id: doc.id,
      code: doc.code || inferCode(doc.text, doc.filename),
      title: doc.title || doc.filename || 'Văn bản pháp lý chưa đặt tên',
      issuer: doc.issuer,
      issued_date: doc.issuedDate,
      effective_date: doc.effectiveDate,
      document_type: doc.documentType || inferDocumentType(doc.text, doc.filename),
      status: doc.status,
      source_status: doc.sourceUrl?.startsWith('manual-seed:')
        ? 'Seed nội bộ — chờ PDF chính thức'
        : doc.sourceUrl?.startsWith('local-pdf:')
          ? 'PDF chính thức lưu cục bộ'
          : doc.sourceUrl
            ? 'Có nguồn đối chiếu'
            : 'Thiếu nguồn đối chiếu'
    }));

    const responsePayload = {
      items,
      pagination: {
        total,
        page,
        limit,
        pageSize: limit,
        totalPages: Math.ceil(total / limit)
      }
    };

    setCached(cacheKey, responsePayload, 15000); // cache 15s
    return successResponse(res, responsePayload);
  } catch (error) {
    next(error);
  }
};


// 2. List Legal Reference Seeds
export const getLegalReferenceDocs = async (req, res, next) => {
  try {
    const items = LEGAL_SOURCE_SEEDS.map(item => ({
      id: item.id,
      code: item.code,
      title: item.title,
      issued_date: item.issued_date,
      effective_date: item.effective_date,
      issuer: item.issuer,
      summary: `${item.obligations.length} nghĩa vụ seed cho checklist DustGuard`,
      document_type: item.document_type,
      source_status: 'Nguồn seed nội bộ',
      preview_text: buildReferenceText(item)
    }));
    return successResponse(res, { items });
  } catch (error) {
    next(error);
  }
};

// 3. Get Legal Document File Data (For inline Preview)
export const getLegalDocumentFile = async (req, res, next) => {
  try {
    const doc = await prisma.legalDocument.findUnique({
      where: { id: req.params.id },
      select: { id: true, filename: true, mimeType: true, fileSize: true, fileData: true }
    });

    if (!doc || !doc.fileData) {
      return errorResponse(res, 'Không tìm thấy tệp PDF để xem trước.', 404);
    }

    res.setHeader('Content-Type', doc.mimeType || 'application/pdf');
    res.setHeader('Content-Length', doc.fileSize || doc.fileData.length);
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(doc.filename || 'legal-document.pdf')}"`);
    res.send(doc.fileData);
  } catch (error) {
    next(error);
  }
};

// 4. Upload Legal Document
export const uploadLegalDocument = async (req, res, next) => {
  try {
    const contentType = req.headers['content-type'] || '';

    // Handle File Upload via multipart/form-data
    if (contentType.includes('multipart/form-data')) {
      const file = req.file;
      if (!file) return errorResponse(res, 'Thiếu tệp tải lên.', 400);

      const extension = (file.originalname || '').split('.').pop()?.toLowerCase();
      const isPdf = extension === 'pdf' || file.mimetype === PDF_MIME;
      const isDocx = extension === 'docx' || file.mimetype === DOCX_MIME;

      if (!isPdf && !isDocx) {
        return errorResponse(res, 'Chỉ hỗ trợ tệp PDF hoặc DOCX.', 400);
      }
      if (file.size > MAX_UPLOAD_SIZE) {
        return errorResponse(res, `Kích thước tệp vượt quá ${Math.floor(MAX_UPLOAD_SIZE / (1024 * 1024))}MB.`, 400);
      }

      let text = '';
      let sourceType = isPdf ? 'pdf' : 'docx';
      let extractionMode = '';
      let aiProvider = null;
      let aiModel = null;

      if (isPdf) {
        try {
          const parsed = await pdf(file.buffer);
          text = normalizeText(parsed.text || '');
          extractionMode = 'pdf_parse';
        } catch (err) {
          logger.error('pdf-parse failed, checking for direct PDF capabilities', { error: err.message, stack: err.stack });
        }

        // Handle Scan PDF if text is too short
        if (isLikelyScanPdf(text)) {
          const capabilities = getAiCapabilities();
          if (!capabilities.directPdf) {
            return errorResponse(
              res,
              'PDF dạng scan/ảnh chưa có OCR. Cấu hình OPENROUTER_API_KEY hoặc bật AI_PROVIDER=gemini với GEMINI_API_KEY để AI đọc PDF trực tiếp, hoặc OCR tài liệu trước khi tải lên.',
              400
            );
          }

          try {
            const extracted = await extractPdfTextWithConfiguredAI(file.buffer, {
              filename: file.originalname,
              mimeType: PDF_MIME
            });
            text = normalizeText(extracted.text);
            sourceType = `${extracted.provider}_direct_pdf`;
            extractionMode = extracted.mode;
            aiProvider = extracted.provider;
            aiModel = extracted.model;
          } catch (error) {
            return errorResponse(
              res,
              `AI direct PDF không khả dụng với provider/model hiện tại: ${error.message || error}`,
              400
            );
          }
        }
      } else if (isDocx) {
        try {
          const parsed = await mammoth.extractRawText({ buffer: file.buffer });
          text = normalizeText(parsed.value || '');
          if (!text) return errorResponse(res, 'Không đọc được nội dung DOCX. Vui lòng kiểm tra lại tệp.', 400);
          extractionMode = 'docx_parse';
        } catch (err) {
          return errorResponse(res, `Lỗi đọc file DOCX: ${err.message}`, 400);
        }
      }

      if (!text) return errorResponse(res, 'Không trích xuất được nội dung văn bản từ tệp.', 400);
      if (text.length > MAX_TEXT_LENGTH) {
        return errorResponse(res, 'Nội dung văn bản quá dài, vui lòng chia nhỏ tài liệu.', 400);
      }

      const id = `doc_${randomUUID()}`;
      const doc = await prisma.legalDocument.create({
        data: {
          id,
          text,
          sourceType,
          status: 'pending',
          filename: file.originalname,
          mimeType: file.mimetype,
          fileSize: file.size,
          fileData: file.buffer,
          code: inferCode(text, file.originalname),
          title: file.originalname.split('.')[0] || 'Văn bản pháp lý mới',
          documentType: inferDocumentType(text, file.originalname),
          checksum: checksum(file.buffer)
        }
      });

      clearCache('legal:');

      return successResponse(res, {
        document: {
          id: doc.id,
          title: doc.title,
          code: doc.code,
          document_type: doc.documentType,
          status: doc.status,
          source_type: doc.sourceType
        },
        extraction: {
          mode: extractionMode,
          provider: aiProvider,
          model: aiModel
        }
      }, 'Tải lên tài liệu thành công');
    }

    // Handle Plain Text Upload via JSON body
    const bodySchema = z.object({
      text: z.string().trim().min(1, 'Nội dung văn bản không được để trống'),
      source_type: z.string().optional(),
      code: z.string().optional(),
      title: z.string().optional(),
      documentType: z.string().optional(),
      document_type: z.string().optional(),
      issuer: z.string().optional(),
      issuedDate: z.string().optional(),
      issued_date: z.string().optional(),
      effectiveDate: z.string().optional(),
      effective_date: z.string().optional(),
    });

    const validationResult = bodySchema.safeParse(req.body);
    if (!validationResult.success) {
      const { message, fieldErrors } = formatZodError(validationResult.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const {
      text,
      source_type,
      code,
      title,
      documentType,
      document_type,
      issuer,
      issuedDate,
      issued_date,
      effectiveDate,
      effective_date
    } = validationResult.data;

    if (text.length > MAX_TEXT_LENGTH) {
      return errorResponse(res, 'Nội dung văn bản quá dài, vui lòng chia nhỏ tài liệu.', 400);
    }

    const id = `doc_${randomUUID()}`;
    const doc = await prisma.legalDocument.create({
      data: {
        id,
        text,
        sourceType: source_type || 'text',
        status: 'pending',
        code: code || inferCode(text, ''),
        title: title || `Văn bản dán_${id.substring(4, 8)}`,
        issuer: issuer || 'Cơ quan thẩm quyền',
        issuedDate: issuedDate || issued_date || new Date().toISOString().split('T')[0],
        effectiveDate: effectiveDate || effective_date || new Date().toISOString().split('T')[0],
        documentType: documentType || document_type || inferDocumentType(text, '')
      }
    });

    clearCache('legal:');

    return successResponse(res, {
      document: {
        id: doc.id,
        title: doc.title,
        code: doc.code,
        document_type: doc.documentType,
        status: doc.status,
        source_type: doc.sourceType,
        issuer: doc.issuer,
        issued_date: doc.issuedDate,
        effective_date: doc.effectiveDate
      }
    }, 'Lưu văn bản dán thành công');

  } catch (error) {
    next(error);
  }
};

// 5. Run Full AI Extraction Pipeline
export const runLegalPipeline = async (req, res, next) => {
  try {
    const docId = req.params.id;
    const doc = await prisma.legalDocument.findUnique({
      where: { id: docId }
    });

    if (!doc) return errorResponse(res, 'Không tìm thấy tài liệu.', 404);

    // Check if obligations are already reviewed to prevent overwrites
    const reviewedCount = await prisma.legalObligation.count({
      where: {
        docId,
        status: { in: ['approved', 'rejected'] }
      }
    });

    if (reviewedCount > 0) {
      return errorResponse(res, 'Tài liệu đã có nghĩa vụ được duyệt. Không thể chạy lại pipeline.', 409);
    }

    if (doc.text.length > MAX_AI_EXTRACTION_TEXT_LENGTH) {
      return errorResponse(res, 'Nội dung văn bản quá dài để AI trích nghĩa vụ trong một lượt. Vui lòng chia nhỏ tài liệu.', 400);
    }

    try {
      logger.info('Calling LLM API via aiService to extract obligations', { title: doc.title, id: doc.id });
      const result = await extractLegalObligationsWithAI(doc.text);

      // Clean existing obligations for this doc
      await prisma.legalObligation.deleteMany({
        where: { docId }
      });

      // Insert new ones
      for (const ob of result.obligations) {
        await prisma.legalObligation.create({
          data: {
            id: `obl_${randomUUID()}`,
            docId,
            obligationId: ob.obligation_id || `obl_${randomUUID()}`,
            subject: ob.subject || null,
            action: ob.action || null,
            condition: ob.condition || null,
            deadline: ob.deadline || null,
            legalBasis: ob.legal_basis || {},
            evidenceRequired: ob.evidence_required || [],
            riskLevel: ob.risk_level || 'medium',
            checklistItem: ob.checklist_item || null,
            recommendedAction: ob.recommended_action || null,
            confidenceScore: ob.confidence_score || 0.7,
            status: 'pending'
          }
        });
      }

      await prisma.legalDocument.update({
        where: { id: docId },
        data: { status: 'extracted' }
      });
      clearCache('legal:');

      const dbObligations = await prisma.legalObligation.findMany({
        where: { docId }
      });

      const normalizedObligations = dbObligations.map(ob => {
        const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
        return {
          ...ob,
          legal_basis: legalBasisParsed,
          evidence_required: safeJsonParse(ob.evidenceRequired, []),
          ref: [legalBasisParsed.document_name, [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')].filter(Boolean).join(' — ')
        };
      });

      return successResponse(res, {
        summary: result.summary,
        obligations: normalizedObligations,
        status: 'extracted',
        provider: result.provider,
        model: result.model,
        timestamp: result.timestamp
      }, 'Trích xuất nghĩa vụ thành công qua AI');

    } catch (error) {
      console.warn('AI pipeline extraction failed, using keyword fallback:', error);
      
      const fallback = extractLegalObligations(doc.text);

      await prisma.legalObligation.deleteMany({
        where: { docId }
      });

      for (const ob of fallback.obligations) {
        await prisma.legalObligation.create({
          data: {
            id: `obl_${randomUUID()}`,
            docId,
            obligationId: ob.obligation_id || `obl_${randomUUID()}`,
            subject: ob.subject || null,
            action: ob.action || null,
            condition: ob.condition || null,
            deadline: ob.deadline || null,
            legalBasis: ob.legal_basis || {},
            evidenceRequired: ob.evidence_required || [],
            riskLevel: ob.risk_level || 'medium',
            checklistItem: ob.checklist_item || null,
            recommendedAction: ob.recommended_action || null,
            confidenceScore: ob.confidence_score || 0.7,
            status: 'pending'
          }
        });
      }

      await prisma.legalDocument.update({
        where: { id: docId },
        data: { status: 'extracted_mock' }
      });
      clearCache('legal:');

      const dbObligations = await prisma.legalObligation.findMany({
        where: { docId }
      });

      const normalizedObligations = dbObligations.map(ob => {
        const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
        return {
          ...ob,
          legal_basis: legalBasisParsed,
          evidence_required: safeJsonParse(ob.evidenceRequired, []),
          ref: [legalBasisParsed.document_name, [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')].filter(Boolean).join(' — ')
        };
      });

      return successResponse(res, {
        summary: fallback.summary,
        obligations: normalizedObligations,
        status: 'extracted_mock',
        provider: 'mock',
        warning: `AI extraction failed; using keyword fallback. ${error.message || error}`,
        timestamp: fallback.timestamp
      }, 'Trích xuất nghĩa vụ thành công (Fall-back chế độ từ khóa)');
    }

  } catch (error) {
    next(error);
  }
};

// 6. Get Legal Obligations
export const getLegalObligations = async (req, res, next) => {
  try {
    const docId = req.query.documentId || req.params.id;
    if (!docId) return errorResponse(res, 'Thiếu documentId.', 400);

    const rows = await prisma.legalObligation.findMany({
      where: { docId }
    });

    const obligationIds = rows.map(ob => ob.id);
    const mappings = await prisma.obligationChecklistMapping.findMany({
      where: {
        obligationId: { in: obligationIds }
      }
    });

    const obligations = rows.map(ob => {
      const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
      const evidenceRequiredParsed = safeJsonParse(ob.evidenceRequired, []);
      
      const obMappings = mappings.filter(m => m.obligationId === ob.id).map(m => ({
        id: m.id,
        checklist_item_key: m.checklistItemId,
        status: 'staff_confirmed',
        ai_confidence_score: Math.round((ob.confidenceScore || 0.8) * 100)
      }));

      // Add a virtual mapping if no mapping in DB exists yet but we have checklist_item suggested
      if (obMappings.length === 0 && ob.checklistItem) {
        obMappings.push({
          id: `virtual_${ob.id}`,
          checklist_item_key: ob.checklistItem,
          status: 'ai_suggested',
          ai_confidence_score: Math.round((ob.confidenceScore || 0.8) * 100)
        });
      }

      return {
        id: ob.id,
        docId: ob.docId,
        obligation_id: ob.obligationId,
        subject: ob.subject,
        action: ob.action,
        condition: ob.condition,
        deadline: ob.deadline,
        legal_basis: legalBasisParsed,
        evidence_required: evidenceRequiredParsed,
        risk_level: ob.riskLevel,
        checklist_item: ob.checklistItem,
        recommended_action: ob.recommendedAction,
        confidence_score: ob.confidenceScore,
        status: ob.status,
        mappings: obMappings,
        // Frontend convenience values
        obligation: ob.action || 'Nghĩa vụ tuân thủ',
        checklist: ob.checklistItem,
        evidence: evidenceRequiredParsed.join('; ') || 'Chưa xác định',
        ref: [
          legalBasisParsed.document_name,
          [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')
        ].filter(Boolean).join(' — ') || 'Đang cập nhật căn cứ pháp lý'
      };
    });

    return successResponse(res, { obligations });
  } catch (error) {
    next(error);
  }
};

// 7. Review Obligation Status
export const reviewObligation = async (req, res, next) => {
  try {
    const { id } = req.params;
    const bodySchema = z.object({
      status: z.enum(['approved', 'rejected', 'pending'])
    });

    const validation = bodySchema.safeParse(req.body);
    if (!validation.success) {
      const { message, fieldErrors } = formatZodError(validation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const { status } = validation.data;

    const current = await prisma.legalObligation.findUnique({
      where: { id }
    });

    if (!current) {
      return errorResponse(res, 'Không tìm thấy nghĩa vụ cần cập nhật.', 404);
    }

    // Prevent revert from final states if designed that way
    if ((current.status === 'approved' || current.status === 'rejected') && status === 'pending') {
      return errorResponse(res, 'Không thể khôi phục nghĩa vụ đã duyệt/từ chối về trạng thái chờ.', 400);
    }

    const ob = await prisma.legalObligation.update({
      where: { id },
      data: { status }
    });

    clearCache('legal:');

    const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
    const evidenceRequiredParsed = safeJsonParse(ob.evidenceRequired, []);

    return successResponse(res, {
      obligation: {
        id: ob.id,
        docId: ob.docId,
        obligation_id: ob.obligationId,
        subject: ob.subject,
        action: ob.action,
        condition: ob.condition,
        deadline: ob.deadline,
        legal_basis: legalBasisParsed,
        evidence_required: evidenceRequiredParsed,
        risk_level: ob.riskLevel,
        checklist_item: ob.checklistItem,
        recommended_action: ob.recommendedAction,
        confidence_score: ob.confidenceScore,
        status: ob.status,
        obligation: ob.action || 'Nghĩa vụ tuân thủ',
        checklist: ob.checklistItem,
        evidence: evidenceRequiredParsed.join('; ') || 'Chưa xác định',
        ref: [
          legalBasisParsed.document_name,
          [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')
        ].filter(Boolean).join(' — ') || 'Đang cập nhật căn cứ pháp lý'
      }
    }, 'Cập nhật trạng thái nghĩa vụ thành công');

  } catch (error) {
    next(error);
  }
};

// 8. Generate Checklist Draft From Obligations
export const generateChecklistFromObligations = async (req, res, next) => {
  try {
    const { documentId } = req.body;
    if (!documentId) return errorResponse(res, 'Thiếu documentId.', 400);

    const rows = await prisma.legalObligation.findMany({
      where: {
        docId: documentId,
        status: { in: ['approved', 'pending'] }
      }
    });

    const checklistDraft = rows.map(ob => {
      const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
      const evidenceRequiredParsed = safeJsonParse(ob.evidenceRequired, []);
      return {
        id: ob.id,
        docId: ob.docId,
        obligation_id: ob.obligationId,
        subject: ob.subject,
        action: ob.action,
        condition: ob.condition,
        deadline: ob.deadline,
        legal_basis: legalBasisParsed,
        evidence_required: evidenceRequiredParsed,
        risk_level: ob.riskLevel,
        checklist_item: ob.checklistItem,
        recommended_action: ob.recommendedAction,
        confidence_score: ob.confidenceScore,
        status: ob.status,
        obligation: ob.action || 'Nghĩa vụ tuân thủ',
        checklist: ob.checklistItem,
        evidence: evidenceRequiredParsed.join('; ') || 'Chưa xác định',
        ref: [
          legalBasisParsed.document_name,
          [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')
        ].filter(Boolean).join(' — ') || 'Đang cập nhật căn cứ pháp lý'
      };
    });

    return successResponse(res, { checklistDraft });
  } catch (error) {
    next(error);
  }
};

// 9. Activate Checklist
export const activateChecklist = async (req, res, next) => {
  try {
    const docId = req.params.id;
    const doc = await prisma.legalDocument.findUnique({
      where: { id: docId }
    });

    if (!doc) return errorResponse(res, 'Không tìm thấy tài liệu để kích hoạt checklist.', 404);

    await prisma.legalDocument.update({
      where: { id: docId },
      data: { status: 'compiled' }
    });

    clearCache('legal:');

    return successResponse(res, { success: true, activeChecklistId: docId }, 'Kích hoạt Checklist thành công');
  } catch (error) {
    next(error);
  }
};

// 10. Create Manual Legal Obligation & Map Checklist
export const createLegalObligation = async (req, res, next) => {
  try {
    const bodySchema = z.object({
      docId: z.string().min(1, 'Thiếu docId'),
      action: z.string().min(1, 'Hành động nghĩa vụ không được để trống'),
      subject: z.string().optional(),
      condition: z.string().optional(),
      deadline: z.string().optional(),
      legalBasis: z.any().optional(),
      legal_basis: z.any().optional(),
      evidenceRequired: z.any().optional(),
      evidence_required: z.any().optional(),
      riskLevel: z.string().optional(),
      risk_level: z.string().optional(),
      checklistItem: z.string().optional(),
      checklist_item: z.string().optional(),
      recommendedAction: z.string().optional(),
      recommended_action: z.string().optional(),
      confidenceScore: z.number().optional(),
      status: z.string().optional(),
    });

    const validation = bodySchema.safeParse(req.body);
    if (!validation.success) {
      const { message, fieldErrors } = formatZodError(validation.error);
      return errorResponse(res, message, 400, fieldErrors);
    }

    const data = validation.data;
    const doc = await prisma.legalDocument.findUnique({ where: { id: data.docId } });
    if (!doc) return errorResponse(res, 'Không tìm thấy văn bản pháp lý.', 404);

    const id = `obl_${randomUUID()}`;
    const obligationId = `obl_manual_${randomUUID().substring(0, 8)}`;
    const checklistKey = data.checklistItem || data.checklist_item || null;
    const risk = data.riskLevel || data.risk_level || 'medium';
    const recAction = data.recommendedAction || data.recommended_action || null;
    const basisInput = data.legalBasis || data.legal_basis;
    const evidenceInput = data.evidenceRequired || data.evidence_required;

    const legalBasisStr = typeof basisInput === 'object'
      ? JSON.stringify(basisInput)
      : (typeof basisInput === 'string' && basisInput.trim() ? basisInput : JSON.stringify({ document_name: doc.title || doc.code }));

    const evidenceStr = Array.isArray(evidenceInput)
      ? JSON.stringify(evidenceInput)
      : (typeof evidenceInput === 'string' ? JSON.stringify([evidenceInput]) : JSON.stringify([]));

    const ob = await prisma.legalObligation.create({
      data: {
        id,
        docId: data.docId,
        obligationId,
        subject: data.subject || 'Nhà thầu thi công/chủ đầu tư',
        action: data.action,
        condition: data.condition || null,
        deadline: data.deadline || null,
        legalBasis: legalBasisStr,
        evidenceRequired: evidenceStr,
        riskLevel: risk,
        checklistItem: checklistKey,
        recommendedAction: recAction,
        confidenceScore: data.confidenceScore || 1.0,
        status: data.status || 'approved',
      }
    });

    if (checklistKey) {
      try {
        const existingMap = await prisma.obligationChecklistMapping.findFirst({
          where: { obligationId: id, checklistItemId: checklistKey }
        });
        if (!existingMap) {
          await prisma.obligationChecklistMapping.create({
            data: {
              obligationId: id,
              checklistItemId: checklistKey,
              notes: 'Tạo thủ công bởi cán bộ'
            }
          });
        }
      } catch (err) {
        logger.warn('Failed to insert obligationChecklistMapping', { error: err.message });
      }
    }

    clearCache('legal:');

    const legalBasisParsed = safeJsonParse(ob.legalBasis, {});
    const evidenceRequiredParsed = safeJsonParse(ob.evidenceRequired, []);

    return successResponse(res, {
      obligation: {
        id: ob.id,
        docId: ob.docId,
        obligation_id: ob.obligationId,
        subject: ob.subject,
        action: ob.action,
        condition: ob.condition,
        deadline: ob.deadline,
        legal_basis: legalBasisParsed,
        evidence_required: evidenceRequiredParsed,
        risk_level: ob.riskLevel,
        checklist_item: ob.checklistItem,
        recommended_action: ob.recommendedAction,
        confidence_score: ob.confidenceScore,
        status: ob.status,
        obligation: ob.action,
        checklist: ob.checklistItem,
        evidence: evidenceRequiredParsed.join('; ') || 'Chưa xác định',
        ref: [
          legalBasisParsed.document_name,
          [legalBasisParsed.article, legalBasisParsed.clause].filter(Boolean).join(' ')
        ].filter(Boolean).join(' — ') || doc.title || doc.code
      }
    }, 'Thêm nghĩa vụ pháp lý thủ công thành công');
  } catch (error) {
    next(error);
  }
};

export const getLegalDocumentById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const doc = await prisma.legalDocument.findUnique({
      where: { id },
      include: { obligations: true }
    });
    if (!doc) {
      const seed = LEGAL_SOURCE_SEEDS.find(s => s.id === id || s.code === id);
      if (seed) {
        return successResponse(res, {
          id: seed.id,
          code: seed.code,
          title: seed.title,
          text: seed.text,
          document_type: seed.document_type,
          issuer: seed.issuer,
          issued_date: seed.issued_date,
          effective_date: seed.effective_date,
          status: seed.status || 'extracted_seed',
          obligations: seed.obligations
        }, 'Lấy chi tiết văn bản pháp lý thành công');
      }
      return errorResponse(res, 'Không tìm thấy văn bản pháp lý.', 404);
    }
    return successResponse(res, {
      ...doc,
      document_type: doc.documentType,
      issued_date: doc.issuedDate,
      effective_date: doc.effectiveDate,
      source_type: doc.sourceType
    }, 'Lấy chi tiết văn bản pháp lý thành công');
  } catch (error) {
    next(error);
  }
};

export const getActiveLegalContextSummary = async (req, res, next) => {
  try {
    const { itemKey, documentKind } = req.query;
    return successResponse(res, {
      legalDocument: 'Nghị định 45/2022/NĐ-CP',
      clause: 'Điều 43 - Vi phạm quy định về bảo vệ môi trường trong hoạt động xây dựng',
      standard: 'QCVN 05:2023/BTNMT - Quy chuẩn kỹ thuật quốc gia về chất lượng không khí',
      itemKey: itemKey || 'general',
      documentKind: documentKind || 'corrective_notice',
      timestamp: new Date().toISOString()
    }, 'Lấy ngữ cảnh pháp lý hiện hành');
  } catch (error) {
    next(error);
  }
};

export const updateLegalDocumentMetadata = async (req, res, next) => {
  try {
    const { id } = req.params;
    const body = req.body || {};
    const doc = await prisma.legalDocument.findUnique({ where: { id } });
    if (!doc) return errorResponse(res, 'Không tìm thấy văn bản.', 404);
    const updated = await prisma.legalDocument.update({
      where: { id },
      data: {
        title: body.title !== undefined ? body.title : undefined,
        code: body.code !== undefined ? body.code : undefined,
        issuer: body.issuer !== undefined ? body.issuer : undefined,
        documentType: body.document_type || body.documentType || undefined
      }
    });
    return successResponse(res, { document: updated }, 'Cập nhật metadata văn bản thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/legal/segments
 * Lấy danh sách các đoạn trích & điều khoản pháp luật
 */
export const getLegalSegments = async (req, res, next) => {
  try {
    let segments = [];
    try {
      if (prisma.legalSegment && typeof prisma.legalSegment.findMany === 'function') {
        segments = await prisma.legalSegment.findMany();
      }
    } catch (e) {
      segments = [];
    }

    if (!segments || segments.length === 0) {
      // Fallback canonical segments from LEGAL_SOURCE_SEEDS
      segments = [
        {
          id: 'seg_nd45_43',
          documentCode: 'NĐ 45/2022/NĐ-CP',
          documentTitle: 'Nghị định 45/2022/NĐ-CP về xử phạt vi phạm hành chính lĩnh vực BVMT',
          article: 'Điều 43',
          clause: 'Khoản 1',
          citation: 'Điều 43.1 Nghị định 45/2022/NĐ-CP',
          content: 'Hành vi không thực hiện biện pháp che chắn, để vật liệu rơi vãi phát tán bụi trong thi công xây dựng bị phạt tiền từ 10.000.000 đến 25.000.000 đồng.',
          summary: 'Phạt tiền từ 10 - 25 triệu đồng đối với hành vi để bụi phát tán',
          checklistKey: 'cover',
          sourceUrl: 'uploads/legal/nd_45_2022_ndcp.pdf'
        },
        {
          id: 'seg_qcvn18_21',
          documentCode: 'QCVN 18:2021/BXD',
          documentTitle: 'Quy chuẩn Kỹ thuật Quốc gia về An toàn trong Xây dựng',
          article: 'Mục 2.1',
          clause: 'Khoản 2.1.1',
          citation: 'Mục 2.1 QCVN 18:2021/BXD',
          content: 'Công trường xây dựng tiếp giáp khu dân cư, đường giao thông phải lắp đặt hàng rào bao che kiên cố có chiều cao tối thiểu 2.0m.',
          summary: 'Yêu cầu lắp hàng rào che chắn tối thiểu 2.0m',
          checklistKey: 'barrier',
          sourceUrl: 'uploads/legal/qcvn_18_2021_bxd.pdf'
        },
        {
          id: 'seg_qcvn18_23',
          documentCode: 'QCVN 18:2021/BXD',
          documentTitle: 'Quy chuẩn Kỹ thuật Quốc gia về An toàn trong Xây dựng',
          article: 'Mục 2.3',
          clause: 'Khoản 2.3.4',
          citation: 'Mục 2.3 QCVN 18:2021/BXD',
          content: 'Phải bố trí cầu rửa xe hoặc trạm xịt rửa áp lực cao tại tất cả các cổng ra của công trường để làm sạch lốp xe tải trước khi lưu thông ra đường.',
          summary: 'Bắt buộc rửa lốp xe tải trước khi rời công trường',
          checklistKey: 'wheel',
          sourceUrl: 'uploads/legal/qcvn_18_2021_bxd.pdf'
        },
        {
          id: 'seg_qd48_24',
          documentCode: 'QĐ 48/2024/QĐ-UBND',
          documentTitle: 'Quyết định số 48/2024/QĐ-UBND Hà Nội về quản lý vệ sinh môi trường',
          article: 'Điều 5',
          clause: 'Khoản 2',
          citation: 'Điều 5.2 QĐ 48/2024/QĐ-UBND',
          content: 'Khu vực thi công đào đắp đất đá, phá dỡ phải vận hành liên tục hệ thống béc phun sương hoặc xe tưới nước dập bụi giảm thiểu phát tán vào không khí.',
          summary: 'Phun ẩm liên tục khi phá dỡ và đào đắp đất đá',
          checklistKey: 'spray',
          sourceUrl: 'uploads/legal/qd_48_2024_ubnd.pdf'
        }
      ];
    }

    return successResponse(res, { items: segments, count: segments.length }, 'Lấy danh sách điều khoản pháp luật thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * GET / POST /api/legal/search
 * Tìm kiếm điều khoản và tư vấn pháp lý
 */
export const searchLegal = async (req, res, next) => {
  try {
    const query = req.query?.q || req.query?.query || req.body?.query || req.body?.q || '';
    const context = req.query?.context || req.body?.context || '';

    if (!query || query.trim().length === 0) {
      return errorResponse(res, 'Vui lòng cung cấp từ khóa tìm kiếm (query).', 400);
    }

    const result = await searchWithAI(query, { context });
    return successResponse(res, result, 'Tìm kiếm điều khoản pháp lý thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/legal/documents/:id or DELETE /api/legal/:id
 * Xóa văn bản pháp lý
 */
export const deleteLegalDocument = async (req, res, next) => {
  try {
    const { id } = req.params;
    const doc = await prisma.legalDocument.findUnique({ where: { id } });
    if (!doc) {
      return errorResponse(res, 'Không tìm thấy văn bản pháp lý để xóa.', 404);
    }

    // Delete obligations & mappings first
    const obligations = await prisma.legalObligation.findMany({ where: { docId: id } });
    const oblIds = obligations.map(o => o.id);
    if (oblIds.length > 0) {
      await prisma.obligationChecklistMapping.deleteMany({ where: { obligationId: { in: oblIds } } }).catch(() => {});
      await prisma.legalObligation.deleteMany({ where: { docId: id } });
    }

    await prisma.legalDocument.delete({ where: { id } });
    clearCache('legal:');

    return successResponse(res, { id, deleted: true }, 'Xóa văn bản pháp lý thành công');
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/legal/obligations/:id
 * Xóa nghĩa vụ pháp lý
 */
export const deleteLegalObligation = async (req, res, next) => {
  try {
    const { id } = req.params;
    const obligation = await prisma.legalObligation.findUnique({ where: { id } });
    if (!obligation) {
      return errorResponse(res, 'Không tìm thấy nghĩa vụ pháp lý để xóa.', 404);
    }

    await prisma.obligationChecklistMapping.deleteMany({ where: { obligationId: id } }).catch(() => {});
    await prisma.legalObligation.delete({ where: { id } });
    clearCache('legal:');

    return successResponse(res, { id, deleted: true }, 'Xóa nghĩa vụ pháp lý thành công');
  } catch (error) {
    next(error);
  }
};




