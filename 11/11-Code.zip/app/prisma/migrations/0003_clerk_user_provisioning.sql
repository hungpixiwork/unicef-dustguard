-- Cloudflare D1 Migration (SSOT): 0003_clerk_user_provisioning.sql
-- Description: Add clerk_user_id column to users table and create unique + performance indexes for idempotent Clerk provisioning

ALTER TABLE "users" ADD COLUMN "clerk_user_id" TEXT;

-- Create unique index to guarantee 1-to-1 identity mapping and prevent race condition duplicates
CREATE UNIQUE INDEX IF NOT EXISTS "users_clerk_user_id_key" ON "users"("clerk_user_id");

-- Create performance lookup index for high-velocity edge query
CREATE INDEX IF NOT EXISTS "idx_users_clerk_id" ON "users"("clerk_user_id");
