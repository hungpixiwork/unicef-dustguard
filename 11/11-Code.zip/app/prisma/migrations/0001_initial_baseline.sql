-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "full_name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "email_verified" BOOLEAN NOT NULL,
    "image" TEXT,
    "role" TEXT NOT NULL DEFAULT 'citizen',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "profiles" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "phoneNumber" TEXT,
    "avatarUrl" TEXT,
    "department" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "session" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "expiresAt" DATETIME NOT NULL,
    "token" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "userId" TEXT NOT NULL,
    CONSTRAINT "session_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "account" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "accountId" TEXT NOT NULL,
    "providerId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "accessToken" TEXT,
    "refreshToken" TEXT,
    "idToken" TEXT,
    "accessTokenExpiresAt" DATETIME,
    "refreshTokenExpiresAt" DATETIME,
    "scope" TEXT,
    "password" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "account_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "verification" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "identifier" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "sites" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "ward" TEXT NOT NULL,
    "province" TEXT,
    "coordinates" TEXT,
    "dustRiskScore" INTEGER NOT NULL DEFAULT 0,
    "riskLevel" TEXT NOT NULL DEFAULT 'LOW',
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "investorName" TEXT,
    "contractorName" TEXT,
    "licenseNumber" TEXT,
    "managerName" TEXT,
    "managerPhone" TEXT,
    "managerEmail" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "complaints" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "code" TEXT NOT NULL,
    "siteId" TEXT,
    "ward" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "reporterName" TEXT,
    "reporterPhone" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "priority" TEXT,
    "dueAt" DATETIME,
    "triageNote" TEXT,
    "assignedTo" TEXT,
    "contactedAt" DATETIME,
    "closedAt" DATETIME,
    "mergedInto" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "complaints_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "inspections" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "siteId" TEXT NOT NULL,
    "inspectorId" TEXT,
    "findings" TEXT NOT NULL,
    "actionTaken" TEXT NOT NULL,
    "scoreDelta" INTEGER NOT NULL DEFAULT 0,
    "sourceComplaintId" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "inspections_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "evidences" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "url" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'IMAGE',
    "complaintId" TEXT,
    "inspectionId" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "evidences_complaintId_fkey" FOREIGN KEY ("complaintId") REFERENCES "complaints" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "evidences_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspections" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "actions" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "siteId" TEXT NOT NULL,
    "inspectionId" TEXT,
    "assignee" TEXT,
    "dueDate" DATETIME,
    "evidenceUrl" TEXT,
    "caseId" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "actions_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "actions_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "cases" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "draft_documents" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "siteId" TEXT NOT NULL,
    "inspectionId" TEXT,
    "documentType" TEXT NOT NULL DEFAULT 'corrective_notice',
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "metadata" TEXT,
    "signedUrl" TEXT,
    "submittedById" TEXT,
    "approvedById" TEXT,
    "signedAt" DATETIME,
    "hash" TEXT,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "caseId" TEXT,
    CONSTRAINT "draft_documents_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "draft_documents_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "cases" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT,
    "actor_id" TEXT,
    "actor_name" TEXT,
    "actor_role" TEXT,
    "action" TEXT NOT NULL,
    "targetId" TEXT,
    "details" TEXT,
    "ipAddress" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "legal_documents" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "text" TEXT NOT NULL,
    "source_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "filename" TEXT,
    "mime_type" TEXT,
    "file_size" INTEGER,
    "file_data" BLOB,
    "code" TEXT,
    "title" TEXT,
    "issuer" TEXT,
    "issued_date" TEXT,
    "effective_date" TEXT,
    "source_url" TEXT,
    "document_type" TEXT,
    "checksum" TEXT
);

-- CreateTable
CREATE TABLE "legal_obligations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "docId" TEXT NOT NULL,
    "obligation_id" TEXT NOT NULL,
    "subject" TEXT,
    "action" TEXT,
    "condition" TEXT,
    "deadline" TEXT,
    "legal_basis" TEXT,
    "evidence_required" TEXT,
    "risk_level" TEXT NOT NULL DEFAULT 'medium',
    "checklist_item" TEXT,
    "recommended_action" TEXT,
    "confidence_score" REAL NOT NULL DEFAULT 0.7,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "legal_obligations_docId_fkey" FOREIGN KEY ("docId") REFERENCES "legal_documents" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "obligation_checklist_mappings" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "obligation_id" TEXT NOT NULL,
    "checklist_item_id" TEXT NOT NULL,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "legal_segments" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "document_code" TEXT NOT NULL,
    "document_title" TEXT NOT NULL,
    "article" TEXT NOT NULL,
    "clause" TEXT,
    "content" TEXT NOT NULL,
    "summary" TEXT,
    "citation" TEXT NOT NULL,
    "source_url" TEXT,
    "checklist_key" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "sensors" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "sensors_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "sensor_readings" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sensorId" TEXT NOT NULL,
    "pm10" REAL NOT NULL,
    "pm25" REAL NOT NULL,
    "timestamp" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "sensor_readings_sensorId_fkey" FOREIGN KEY ("sensorId") REFERENCES "sensors" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "alerts" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "siteId" TEXT NOT NULL,
    "sensorId" TEXT,
    "pm10Value" REAL NOT NULL,
    "triggeredAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "slaDeadline" DATETIME NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "resolvedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "alerts_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "alerts_sensorId_fkey" FOREIGN KEY ("sensorId") REFERENCES "sensors" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "alert_notifications" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "alertId" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "recipientName" TEXT,
    "recipientRole" TEXT,
    "message" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "errorMessage" TEXT,
    "sentAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "alert_notifications_alertId_fkey" FOREIGN KEY ("alertId") REFERENCES "alerts" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "cases" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "code" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "sourceType" TEXT,
    "sourceId" TEXT,
    "slaDeadline" DATETIME,
    "siteId" TEXT NOT NULL,
    "complaintId" TEXT,
    "inspectionId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "cases_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "sites" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "cases_complaintId_fkey" FOREIGN KEY ("complaintId") REFERENCES "complaints" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "cases_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspections" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "case_timelines" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "caseId" TEXT NOT NULL,
    "eventTitle" TEXT NOT NULL,
    "eventDescription" TEXT,
    "eventType" TEXT NOT NULL,
    "actorId" TEXT,
    "actorName" TEXT,
    "actorRole" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "case_timelines_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "cases" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "contractor_explanations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "caseId" TEXT NOT NULL,
    "contractorId" TEXT NOT NULL,
    "explanation" TEXT NOT NULL,
    "evidenceUrls" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "submittedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "contractor_explanations_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "cases" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "sanction_decisions" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "caseId" TEXT NOT NULL,
    "decisionNumber" TEXT NOT NULL,
    "documentUrl" TEXT,
    "penaltyAmount" REAL,
    "remedialMeasures" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "issuedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "sanction_decisions_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "cases" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "document_revisions" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "documentId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "metadata" TEXT,
    "revisionNumber" INTEGER NOT NULL,
    "updatedById" TEXT,
    "updatedByName" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "document_revisions_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "draft_documents" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "administrative_regions" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "name_en" TEXT NOT NULL,
    "code_name" TEXT,
    "code_name_en" TEXT
);

-- CreateTable
CREATE TABLE "administrative_units" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "full_name" TEXT,
    "full_name_en" TEXT,
    "short_name" TEXT,
    "short_name_en" TEXT,
    "code_name" TEXT,
    "code_name_en" TEXT
);

-- CreateTable
CREATE TABLE "provinces" (
    "code" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "name_en" TEXT,
    "full_name" TEXT NOT NULL,
    "full_name_en" TEXT,
    "code_name" TEXT,
    "administrative_unit_id" INTEGER,
    CONSTRAINT "provinces_administrative_unit_id_fkey" FOREIGN KEY ("administrative_unit_id") REFERENCES "administrative_units" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "wards" (
    "code" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "name_en" TEXT,
    "full_name" TEXT,
    "full_name_en" TEXT,
    "code_name" TEXT,
    "province_code" TEXT,
    "administrative_unit_id" INTEGER,
    CONSTRAINT "wards_province_code_fkey" FOREIGN KEY ("province_code") REFERENCES "provinces" ("code") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "wards_administrative_unit_id_fkey" FOREIGN KEY ("administrative_unit_id") REFERENCES "administrative_units" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "profiles_userId_key" ON "profiles"("userId");

-- CreateIndex
CREATE INDEX "profiles_userId_idx" ON "profiles"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "session_token_key" ON "session"("token");

-- CreateIndex
CREATE UNIQUE INDEX "complaints_code_key" ON "complaints"("code");

-- CreateIndex
CREATE INDEX "complaints_siteId_idx" ON "complaints"("siteId");

-- CreateIndex
CREATE INDEX "inspections_siteId_idx" ON "inspections"("siteId");

-- CreateIndex
CREATE INDEX "evidences_complaintId_idx" ON "evidences"("complaintId");

-- CreateIndex
CREATE INDEX "evidences_inspectionId_idx" ON "evidences"("inspectionId");

-- CreateIndex
CREATE INDEX "actions_siteId_idx" ON "actions"("siteId");

-- CreateIndex
CREATE INDEX "actions_caseId_idx" ON "actions"("caseId");

-- CreateIndex
CREATE INDEX "draft_documents_siteId_idx" ON "draft_documents"("siteId");

-- CreateIndex
CREATE INDEX "draft_documents_caseId_idx" ON "draft_documents"("caseId");

-- CreateIndex
CREATE UNIQUE INDEX "obligation_checklist_mappings_obligation_id_checklist_item_id_key" ON "obligation_checklist_mappings"("obligation_id", "checklist_item_id");

-- CreateIndex
CREATE UNIQUE INDEX "sensors_code_key" ON "sensors"("code");

-- CreateIndex
CREATE INDEX "sensor_readings_sensorId_timestamp_idx" ON "sensor_readings"("sensorId", "timestamp");

-- CreateIndex
CREATE UNIQUE INDEX "cases_code_key" ON "cases"("code");

-- CreateIndex
CREATE UNIQUE INDEX "sanction_decisions_decisionNumber_key" ON "sanction_decisions"("decisionNumber");

-- CreateIndex
CREATE UNIQUE INDEX "document_revisions_documentId_revisionNumber_key" ON "document_revisions"("documentId", "revisionNumber");

-- CreateIndex
CREATE INDEX "idx_provinces_unit" ON "provinces"("administrative_unit_id");

-- CreateIndex
CREATE INDEX "idx_wards_province" ON "wards"("province_code");

-- CreateIndex
CREATE INDEX "idx_wards_unit" ON "wards"("administrative_unit_id");

-- Additive Tables for Community Action Domain
CREATE TABLE IF NOT EXISTS "communities" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'UNIVERSITY_CLUB',
    "ward" TEXT,
    "city" TEXT DEFAULT 'Hà Nội',
    "avatar_url" TEXT,
    "description" TEXT,
    "member_count" INTEGER NOT NULL DEFAULT 1,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "community_members" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "community_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'MEMBER',
    "joined_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "community_members_comm_fkey" FOREIGN KEY ("community_id") REFERENCES "communities" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "campaigns" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "code" TEXT NOT NULL UNIQUE,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "topic" TEXT NOT NULL DEFAULT 'SCHOOL_ZONE_DUST',
    "ward" TEXT,
    "city" TEXT DEFAULT 'Hà Nội',
    "start_date" DATETIME NOT NULL,
    "end_date" DATETIME NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "participant_count" INTEGER NOT NULL DEFAULT 0,
    "observation_count" INTEGER NOT NULL DEFAULT 0,
    "created_by" TEXT,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "campaign_members" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "campaign_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "joined_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "campaign_members_camp_fkey" FOREIGN KEY ("campaign_id") REFERENCES "campaigns" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "observations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "code" TEXT NOT NULL UNIQUE,
    "category" TEXT NOT NULL DEFAULT 'CONSTRUCTION_DUST',
    "latitude" REAL,
    "longitude" REAL,
    "address" TEXT NOT NULL,
    "ward" TEXT NOT NULL,
    "city" TEXT DEFAULT 'Hà Nội',
    "description" TEXT NOT NULL,
    "reporter_type" TEXT NOT NULL DEFAULT 'INDIVIDUAL',
    "reporter_name" TEXT,
    "reporter_phone" TEXT,
    "community_id" TEXT,
    "campaign_id" TEXT,
    "site_id" TEXT,
    "status" TEXT NOT NULL DEFAULT 'RECORDED',
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "observations_comm_fkey" FOREIGN KEY ("community_id") REFERENCES "communities" ("id") ON DELETE SET NULL,
    CONSTRAINT "observations_camp_fkey" FOREIGN KEY ("campaign_id") REFERENCES "campaigns" ("id") ON DELETE SET NULL,
    CONSTRAINT "observations_site_fkey" FOREIGN KEY ("site_id") REFERENCES "sites" ("id") ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS "observation_evidence" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "observation_id" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'IMAGE',
    "sha256" TEXT,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "obs_evidence_obs_fkey" FOREIGN KEY ("observation_id") REFERENCES "observations" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "follow_ups" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "observation_id" TEXT,
    "case_id" TEXT,
    "performed_by" TEXT,
    "outcome_status" TEXT NOT NULL DEFAULT 'UNCHANGED',
    "notes" TEXT,
    "evidence_url" TEXT,
    "evidence_sha256" TEXT,
    "verified_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "follow_ups_obs_fkey" FOREIGN KEY ("observation_id") REFERENCES "observations" ("id") ON DELETE CASCADE,
    CONSTRAINT "follow_ups_case_fkey" FOREIGN KEY ("case_id") REFERENCES "cases" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "handoffs" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "case_id" TEXT,
    "observation_id" TEXT,
    "recipient_unit" TEXT NOT NULL,
    "recipient_contact" TEXT,
    "channel" TEXT NOT NULL DEFAULT 'EMAIL',
    "status" TEXT NOT NULL DEFAULT 'PREPARED',
    "summary_markdown" TEXT,
    "dossier_url" TEXT,
    "hash" TEXT,
    "sent_at" DATETIME,
    "acknowledged_at" DATETIME,
    "closed_at" DATETIME,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "handoffs_case_fkey" FOREIGN KEY ("case_id") REFERENCES "cases" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "impact_events" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "community_id" TEXT,
    "user_id" TEXT,
    "event_type" TEXT NOT NULL,
    "points_earned" INTEGER NOT NULL DEFAULT 10,
    "volunteer_hours" REAL NOT NULL DEFAULT 0.5,
    "metadata_json" TEXT,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "observations_category_idx" ON "observations"("category");
CREATE INDEX IF NOT EXISTS "observations_ward_idx" ON "observations"("ward");
CREATE INDEX IF NOT EXISTS "observations_community_idx" ON "observations"("community_id");
CREATE INDEX IF NOT EXISTS "observations_campaign_idx" ON "observations"("campaign_id");
CREATE INDEX IF NOT EXISTS "follow_ups_observation_idx" ON "follow_ups"("observation_id");
CREATE INDEX IF NOT EXISTS "follow_ups_case_idx" ON "follow_ups"("case_id");
CREATE INDEX IF NOT EXISTS "handoffs_case_idx" ON "handoffs"("case_id");
CREATE INDEX IF NOT EXISTS "impact_events_user_idx" ON "impact_events"("user_id");

-- 1. Idempotency Protection Store
CREATE TABLE IF NOT EXISTS "idempotency_keys" (
  "key" TEXT NOT NULL PRIMARY KEY,
  "request_hash" TEXT,
  "response_json" TEXT NOT NULL,
  "status_code" INTEGER NOT NULL DEFAULT 200,
  "expires_at" DATETIME NOT NULL,
  "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "idx_idempotency_expires" ON "idempotency_keys"("expires_at");

-- 2. Audit Events SSOT
CREATE TABLE IF NOT EXISTS "audit_events" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "aggregate_type" TEXT NOT NULL,
  "aggregate_id" TEXT NOT NULL,
  "event_type" TEXT NOT NULL,
  "actor_id" TEXT,
  "actor_name" TEXT,
  "actor_role" TEXT,
  "payload_json" TEXT,
  "previous_state" TEXT,
  "new_state" TEXT,
  "request_id" TEXT,
  "integrity_hash" TEXT,
  "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "idx_audit_events_agg" ON "audit_events"("aggregate_type", "aggregate_id", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_events_actor" ON "audit_events"("actor_id", "created_at" DESC);

-- 3. Environmental Categories Domain Model
CREATE TABLE IF NOT EXISTS "environmental_categories" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "code" TEXT NOT NULL UNIQUE,
  "name_vi" TEXT NOT NULL,
  "name_en" TEXT NOT NULL,
  "description" TEXT,
  "icon" TEXT,
  "default_severity" TEXT NOT NULL DEFAULT 'HIGH',
  "evidence_requirements" TEXT,
  "regulations" TEXT,
  "active" INTEGER NOT NULL DEFAULT 1,
  "version" INTEGER NOT NULL DEFAULT 1,
  "effective_from" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "effective_to" DATETIME,
  "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Youth Activities & Validated Participation
CREATE TABLE IF NOT EXISTS "youth_activities" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "user_id" TEXT NOT NULL,
  "activity_type" TEXT NOT NULL,
  "campaign_id" TEXT,
  "observation_id" TEXT,
  "minutes" INTEGER NOT NULL DEFAULT 30,
  "evidence_url" TEXT,
  "validated_by" TEXT,
  "validation_status" TEXT NOT NULL DEFAULT 'VALIDATED',
  "occurred_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "youth_activities_camp_fkey" FOREIGN KEY ("campaign_id") REFERENCES "campaigns"("id") ON DELETE SET NULL,
  CONSTRAINT "youth_activities_obs_fkey" FOREIGN KEY ("observation_id") REFERENCES "observations"("id") ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS "idx_youth_activities_user" ON "youth_activities"("user_id", "validation_status");

-- 5. Youth Certificates SSOT
CREATE TABLE IF NOT EXISTS "youth_certificates" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "certificate_code" TEXT NOT NULL UNIQUE,
  "user_id" TEXT NOT NULL,
  "student_name" TEXT NOT NULL,
  "university" TEXT NOT NULL,
  "student_id" TEXT,
  "eligible_minutes" INTEGER NOT NULL DEFAULT 0,
  "credit_value" REAL NOT NULL DEFAULT 0,
  "policy_version" TEXT NOT NULL DEFAULT 'v1.0',
  "payload_hash" TEXT NOT NULL,
  "signature" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "revoked_at" DATETIME,
  "revoked_reason" TEXT,
  "issued_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "issued_by" TEXT NOT NULL DEFAULT 'DustGuard VN System'
);
CREATE INDEX IF NOT EXISTS "idx_youth_cert_code" ON "youth_certificates"("certificate_code");
CREATE INDEX IF NOT EXISTS "idx_youth_cert_user" ON "youth_certificates"("user_id");

-- Comprehensive Cloudflare D1 Query & Guardrail Indexes (SSOT)
-- Users & Auth
CREATE INDEX IF NOT EXISTS "users_role_idx" ON "users"("role");
CREATE INDEX IF NOT EXISTS "users_status_idx" ON "users"("status");
CREATE INDEX IF NOT EXISTS "users_createdAt_idx" ON "users"("createdAt");
CREATE INDEX IF NOT EXISTS "session_userId_idx" ON "session"("userId");
CREATE INDEX IF NOT EXISTS "session_expiresAt_idx" ON "session"("expiresAt");
CREATE INDEX IF NOT EXISTS "session_userId_expiresAt_idx" ON "session"("userId", "expiresAt");
CREATE INDEX IF NOT EXISTS "account_userId_idx" ON "account"("userId");
CREATE INDEX IF NOT EXISTS "verification_identifier_idx" ON "verification"("identifier");

-- Sites
CREATE INDEX IF NOT EXISTS "sites_status_idx" ON "sites"("status");
CREATE INDEX IF NOT EXISTS "sites_riskLevel_idx" ON "sites"("riskLevel");
CREATE INDEX IF NOT EXISTS "sites_ward_idx" ON "sites"("ward");
CREATE INDEX IF NOT EXISTS "sites_province_idx" ON "sites"("province");
CREATE INDEX IF NOT EXISTS "sites_dustRiskScore_idx" ON "sites"("dustRiskScore" DESC);
CREATE INDEX IF NOT EXISTS "sites_deletedAt_idx" ON "sites"("deletedAt");
CREATE INDEX IF NOT EXISTS "sites_createdAt_idx" ON "sites"("createdAt");
CREATE INDEX IF NOT EXISTS "idx_sites_del_status_score" ON "sites"("deletedAt", "status", "dustRiskScore" DESC);
CREATE INDEX IF NOT EXISTS "idx_sites_ward_status" ON "sites"("ward", "status");

-- Complaints
CREATE INDEX IF NOT EXISTS "complaints_status_idx" ON "complaints"("status");
CREATE INDEX IF NOT EXISTS "complaints_ward_idx" ON "complaints"("ward");
CREATE INDEX IF NOT EXISTS "complaints_createdAt_idx" ON "complaints"("createdAt");
CREATE INDEX IF NOT EXISTS "complaints_deletedAt_idx" ON "complaints"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_complaints_status_created" ON "complaints"("status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_complaints_site_created" ON "complaints"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_complaints_del_status_created" ON "complaints"("deletedAt", "status", "createdAt" DESC);

-- Inspections
CREATE INDEX IF NOT EXISTS "inspections_inspectorId_idx" ON "inspections"("inspectorId");
CREATE INDEX IF NOT EXISTS "inspections_sourceComplaintId_idx" ON "inspections"("sourceComplaintId");
CREATE INDEX IF NOT EXISTS "inspections_createdAt_idx" ON "inspections"("createdAt");
CREATE INDEX IF NOT EXISTS "inspections_deletedAt_idx" ON "inspections"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_inspections_site_created" ON "inspections"("siteId", "createdAt" DESC);

-- Evidences
CREATE INDEX IF NOT EXISTS "evidences_caseId_idx" ON "evidences"("caseId");
CREATE INDEX IF NOT EXISTS "evidences_createdAt_idx" ON "evidences"("createdAt");
CREATE INDEX IF NOT EXISTS "evidences_deletedAt_idx" ON "evidences"("deletedAt");
CREATE INDEX IF NOT EXISTS "evidences_type_idx" ON "evidences"("type");

-- Actions
CREATE INDEX IF NOT EXISTS "actions_status_idx" ON "actions"("status");
CREATE INDEX IF NOT EXISTS "actions_inspectionId_idx" ON "actions"("inspectionId");
CREATE INDEX IF NOT EXISTS "actions_createdAt_idx" ON "actions"("createdAt");
CREATE INDEX IF NOT EXISTS "actions_deletedAt_idx" ON "actions"("deletedAt");
CREATE INDEX IF NOT EXISTS "actions_dueDate_idx" ON "actions"("dueDate");
CREATE INDEX IF NOT EXISTS "idx_actions_site_status" ON "actions"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_actions_case_status" ON "actions"("caseId", "status");
CREATE INDEX IF NOT EXISTS "idx_actions_status_created" ON "actions"("status", "createdAt" DESC);

-- Draft Documents
CREATE INDEX IF NOT EXISTS "draft_documents_status_idx" ON "draft_documents"("status");
CREATE INDEX IF NOT EXISTS "draft_documents_documentType_idx" ON "draft_documents"("documentType");
CREATE INDEX IF NOT EXISTS "draft_documents_createdAt_idx" ON "draft_documents"("createdAt");
CREATE INDEX IF NOT EXISTS "draft_documents_deletedAt_idx" ON "draft_documents"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_draft_docs_site_created" ON "draft_documents"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "document_revisions_documentId_idx" ON "document_revisions"("documentId");

-- Audit Logs
CREATE INDEX IF NOT EXISTS "audit_logs_userId_idx" ON "audit_logs"("userId");
CREATE INDEX IF NOT EXISTS "audit_logs_actor_id_idx" ON "audit_logs"("actor_id");
CREATE INDEX IF NOT EXISTS "audit_logs_action_idx" ON "audit_logs"("action");
CREATE INDEX IF NOT EXISTS "audit_logs_targetId_idx" ON "audit_logs"("targetId");
CREATE INDEX IF NOT EXISTS "audit_logs_createdAt_idx" ON "audit_logs"("createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_actor_created" ON "audit_logs"("actor_id", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_action_created" ON "audit_logs"("action", "createdAt" DESC);

-- Legal Documents & Obligations
CREATE INDEX IF NOT EXISTS "legal_documents_status_idx" ON "legal_documents"("status");
CREATE INDEX IF NOT EXISTS "legal_documents_code_idx" ON "legal_documents"("code");
CREATE INDEX IF NOT EXISTS "legal_documents_source_type_idx" ON "legal_documents"("source_type");
CREATE INDEX IF NOT EXISTS "legal_documents_createdAt_idx" ON "legal_documents"("createdAt");
CREATE INDEX IF NOT EXISTS "legal_obligations_docId_idx" ON "legal_obligations"("docId");
CREATE INDEX IF NOT EXISTS "legal_obligations_status_idx" ON "legal_obligations"("status");
CREATE INDEX IF NOT EXISTS "legal_obligations_risk_level_idx" ON "legal_obligations"("risk_level");
CREATE INDEX IF NOT EXISTS "legal_obligations_checklist_item_idx" ON "legal_obligations"("checklist_item");
CREATE INDEX IF NOT EXISTS "legal_segments_document_code_idx" ON "legal_segments"("document_code");
CREATE INDEX IF NOT EXISTS "legal_segments_checklist_key_idx" ON "legal_segments"("checklist_key");

-- Sensors & Sensor Readings
CREATE INDEX IF NOT EXISTS "sensors_siteId_idx" ON "sensors"("siteId");
CREATE INDEX IF NOT EXISTS "sensors_status_idx" ON "sensors"("status");
CREATE INDEX IF NOT EXISTS "idx_sensors_site_status" ON "sensors"("siteId", "status");
CREATE INDEX IF NOT EXISTS "sensor_readings_timestamp_idx" ON "sensor_readings"("timestamp" DESC);
CREATE INDEX IF NOT EXISTS "idx_sensor_readings_sensor_time_desc" ON "sensor_readings"("sensorId", "timestamp" DESC);

-- Alerts & Notifications
CREATE INDEX IF NOT EXISTS "alerts_siteId_idx" ON "alerts"("siteId");
CREATE INDEX IF NOT EXISTS "alerts_sensorId_idx" ON "alerts"("sensorId");
CREATE INDEX IF NOT EXISTS "alerts_status_idx" ON "alerts"("status");
CREATE INDEX IF NOT EXISTS "alerts_triggeredAt_idx" ON "alerts"("triggeredAt" DESC);
CREATE INDEX IF NOT EXISTS "alerts_slaDeadline_idx" ON "alerts"("slaDeadline" ASC);
CREATE INDEX IF NOT EXISTS "idx_alerts_site_status" ON "alerts"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_alerts_status_sla" ON "alerts"("status", "slaDeadline");
CREATE INDEX IF NOT EXISTS "idx_alerts_status_triggered" ON "alerts"("status", "triggeredAt" DESC);
CREATE INDEX IF NOT EXISTS "alert_notifications_alertId_idx" ON "alert_notifications"("alertId");
CREATE INDEX IF NOT EXISTS "alert_notifications_status_idx" ON "alert_notifications"("status");
CREATE INDEX IF NOT EXISTS "alert_notifications_recipient_idx" ON "alert_notifications"("recipient");

-- Cases & Timelines & Histories
CREATE INDEX IF NOT EXISTS "cases_siteId_idx" ON "cases"("siteId");
CREATE INDEX IF NOT EXISTS "cases_status_idx" ON "cases"("status");
CREATE INDEX IF NOT EXISTS "cases_complaintId_idx" ON "cases"("complaintId");
CREATE INDEX IF NOT EXISTS "cases_inspectionId_idx" ON "cases"("inspectionId");
CREATE INDEX IF NOT EXISTS "cases_createdAt_idx" ON "cases"("createdAt");
CREATE INDEX IF NOT EXISTS "cases_deletedAt_idx" ON "cases"("deletedAt");
CREATE INDEX IF NOT EXISTS "cases_slaDeadline_idx" ON "cases"("slaDeadline");
CREATE INDEX IF NOT EXISTS "idx_cases_status_created" ON "cases"("status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_cases_site_status" ON "cases"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_cases_site_created" ON "cases"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_cases_del_status_created" ON "cases"("deletedAt", "status", "createdAt" DESC);

CREATE INDEX IF NOT EXISTS "case_timelines_caseId_idx" ON "case_timelines"("caseId");
CREATE INDEX IF NOT EXISTS "idx_case_timelines_case_created" ON "case_timelines"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "case_status_history_caseId_idx" ON "case_status_history"("caseId");
CREATE INDEX IF NOT EXISTS "idx_case_status_history_case_created" ON "case_status_history"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "priority_score_history_siteId_idx" ON "priority_score_history"("siteId");
CREATE INDEX IF NOT EXISTS "priority_score_history_caseId_idx" ON "priority_score_history"("caseId");
CREATE INDEX IF NOT EXISTS "idx_priority_score_history_site_created" ON "priority_score_history"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "contractor_explanations_caseId_idx" ON "contractor_explanations"("caseId");
CREATE INDEX IF NOT EXISTS "contractor_explanations_status_idx" ON "contractor_explanations"("status");
CREATE INDEX IF NOT EXISTS "idx_contractor_expl_case_created" ON "contractor_explanations"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "sanction_decisions_caseId_idx" ON "sanction_decisions"("caseId");
CREATE INDEX IF NOT EXISTS "sanction_decisions_status_idx" ON "sanction_decisions"("status");
CREATE INDEX IF NOT EXISTS "idx_sanction_decisions_case_status" ON "sanction_decisions"("caseId", "status");

-- Community, Observations, Follow-ups, Handoffs, Youth
CREATE INDEX IF NOT EXISTS "communities_type_idx" ON "communities"("type");
CREATE INDEX IF NOT EXISTS "communities_member_count_idx" ON "communities"("member_count" DESC);
CREATE UNIQUE INDEX IF NOT EXISTS "idx_community_members_unique" ON "community_members"("community_id", "user_id");

CREATE INDEX IF NOT EXISTS "campaigns_status_idx" ON "campaigns"("status");
CREATE INDEX IF NOT EXISTS "campaigns_topic_idx" ON "campaigns"("topic");
CREATE INDEX IF NOT EXISTS "campaigns_ward_idx" ON "campaigns"("ward");
CREATE INDEX IF NOT EXISTS "idx_campaigns_status_created" ON "campaigns"("status", "created_at" DESC);
CREATE UNIQUE INDEX IF NOT EXISTS "idx_campaign_members_unique" ON "campaign_members"("campaign_id", "user_id");

CREATE INDEX IF NOT EXISTS "observations_site_id_idx" ON "observations"("site_id");
CREATE INDEX IF NOT EXISTS "observations_status_idx" ON "observations"("status");
CREATE INDEX IF NOT EXISTS "observations_created_at_idx" ON "observations"("created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_status_created" ON "observations"("status", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_site_created" ON "observations"("site_id", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_ward_category" ON "observations"("ward", "category");
CREATE INDEX IF NOT EXISTS "observation_evidence_obs_idx" ON "observation_evidence"("observation_id");

CREATE INDEX IF NOT EXISTS "follow_ups_outcome_idx" ON "follow_ups"("outcome_status");
CREATE INDEX IF NOT EXISTS "follow_ups_created_at_idx" ON "follow_ups"("created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_follow_ups_obs_created" ON "follow_ups"("observation_id", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "handoffs_obs_idx" ON "handoffs"("observation_id");
CREATE INDEX IF NOT EXISTS "handoffs_status_idx" ON "handoffs"("status");
CREATE INDEX IF NOT EXISTS "handoffs_recipient_idx" ON "handoffs"("recipient_unit");
CREATE INDEX IF NOT EXISTS "idx_handoffs_case_status" ON "handoffs"("case_id", "status");
CREATE INDEX IF NOT EXISTS "idx_handoffs_status_created" ON "handoffs"("status", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "impact_events_comm_idx" ON "impact_events"("community_id");
CREATE INDEX IF NOT EXISTS "idx_impact_events_type_created" ON "impact_events"("event_type", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "youth_activities_camp_idx" ON "youth_activities"("campaign_id");
CREATE INDEX IF NOT EXISTS "youth_activities_obs_idx" ON "youth_activities"("observation_id");
CREATE INDEX IF NOT EXISTS "youth_certificates_status_idx" ON "youth_certificates"("status");
CREATE INDEX IF NOT EXISTS "idx_youth_cert_user_status" ON "youth_certificates"("user_id", "status");



