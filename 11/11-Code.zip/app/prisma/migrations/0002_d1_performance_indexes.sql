
-- Cloudflare D1 High-Velocity Query & Index Optimization Migration (SSOT)
-- Guardrails for Scale-to-Zero & 10k+ Active Users

-- Users & Auth
CREATE INDEX IF NOT EXISTS "users_role_idx" ON "users"("role");
CREATE INDEX IF NOT EXISTS "users_status_idx" ON "users"("status");
CREATE INDEX IF NOT EXISTS "users_createdAt_idx" ON "users"("createdAt");
CREATE INDEX IF NOT EXISTS "session_userId_idx" ON "session"("userId");
CREATE INDEX IF NOT EXISTS "session_expiresAt_idx" ON "session"("expiresAt");
CREATE INDEX IF NOT EXISTS "session_userId_expiresAt_idx" ON "session"("userId", "expiresAt");
CREATE INDEX IF NOT EXISTS "account_userId_idx" ON "account"("userId");
CREATE INDEX IF NOT EXISTS "verification_identifier_idx" ON "verification"("identifier");

-- Sites
CREATE INDEX IF NOT EXISTS "sites_status_idx" ON "sites"("status");
CREATE INDEX IF NOT EXISTS "sites_riskLevel_idx" ON "sites"("riskLevel");
CREATE INDEX IF NOT EXISTS "sites_ward_idx" ON "sites"("ward");
CREATE INDEX IF NOT EXISTS "sites_province_idx" ON "sites"("province");
CREATE INDEX IF NOT EXISTS "sites_dustRiskScore_idx" ON "sites"("dustRiskScore" DESC);
CREATE INDEX IF NOT EXISTS "sites_deletedAt_idx" ON "sites"("deletedAt");
CREATE INDEX IF NOT EXISTS "sites_createdAt_idx" ON "sites"("createdAt");
CREATE INDEX IF NOT EXISTS "idx_sites_del_status_score" ON "sites"("deletedAt", "status", "dustRiskScore" DESC);
CREATE INDEX IF NOT EXISTS "idx_sites_ward_status" ON "sites"("ward", "status");

-- Complaints
CREATE INDEX IF NOT EXISTS "complaints_status_idx" ON "complaints"("status");
CREATE INDEX IF NOT EXISTS "complaints_ward_idx" ON "complaints"("ward");
CREATE INDEX IF NOT EXISTS "complaints_createdAt_idx" ON "complaints"("createdAt");
CREATE INDEX IF NOT EXISTS "complaints_deletedAt_idx" ON "complaints"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_complaints_status_created" ON "complaints"("status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_complaints_site_created" ON "complaints"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_complaints_del_status_created" ON "complaints"("deletedAt", "status", "createdAt" DESC);

-- Inspections
CREATE INDEX IF NOT EXISTS "inspections_inspectorId_idx" ON "inspections"("inspectorId");
CREATE INDEX IF NOT EXISTS "inspections_sourceComplaintId_idx" ON "inspections"("sourceComplaintId");
CREATE INDEX IF NOT EXISTS "inspections_createdAt_idx" ON "inspections"("createdAt");
CREATE INDEX IF NOT EXISTS "inspections_deletedAt_idx" ON "inspections"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_inspections_site_created" ON "inspections"("siteId", "createdAt" DESC);

-- Evidences
CREATE INDEX IF NOT EXISTS "evidences_caseId_idx" ON "evidences"("caseId");
CREATE INDEX IF NOT EXISTS "evidences_createdAt_idx" ON "evidences"("createdAt");
CREATE INDEX IF NOT EXISTS "evidences_deletedAt_idx" ON "evidences"("deletedAt");
CREATE INDEX IF NOT EXISTS "evidences_type_idx" ON "evidences"("type");

-- Actions
CREATE INDEX IF NOT EXISTS "actions_status_idx" ON "actions"("status");
CREATE INDEX IF NOT EXISTS "actions_inspectionId_idx" ON "actions"("inspectionId");
CREATE INDEX IF NOT EXISTS "actions_createdAt_idx" ON "actions"("createdAt");
CREATE INDEX IF NOT EXISTS "actions_deletedAt_idx" ON "actions"("deletedAt");
CREATE INDEX IF NOT EXISTS "actions_dueDate_idx" ON "actions"("dueDate");
CREATE INDEX IF NOT EXISTS "idx_actions_site_status" ON "actions"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_actions_case_status" ON "actions"("caseId", "status");
CREATE INDEX IF NOT EXISTS "idx_actions_status_created" ON "actions"("status", "createdAt" DESC);

-- Draft Documents
CREATE INDEX IF NOT EXISTS "draft_documents_status_idx" ON "draft_documents"("status");
CREATE INDEX IF NOT EXISTS "draft_documents_documentType_idx" ON "draft_documents"("documentType");
CREATE INDEX IF NOT EXISTS "draft_documents_createdAt_idx" ON "draft_documents"("createdAt");
CREATE INDEX IF NOT EXISTS "draft_documents_deletedAt_idx" ON "draft_documents"("deletedAt");
CREATE INDEX IF NOT EXISTS "idx_draft_docs_site_created" ON "draft_documents"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "document_revisions_documentId_idx" ON "document_revisions"("documentId");

-- Audit Logs
CREATE INDEX IF NOT EXISTS "audit_logs_userId_idx" ON "audit_logs"("userId");
CREATE INDEX IF NOT EXISTS "audit_logs_actor_id_idx" ON "audit_logs"("actor_id");
CREATE INDEX IF NOT EXISTS "audit_logs_action_idx" ON "audit_logs"("action");
CREATE INDEX IF NOT EXISTS "audit_logs_targetId_idx" ON "audit_logs"("targetId");
CREATE INDEX IF NOT EXISTS "audit_logs_createdAt_idx" ON "audit_logs"("createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_actor_created" ON "audit_logs"("actor_id", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_action_created" ON "audit_logs"("action", "createdAt" DESC);

-- Legal Documents & Obligations
CREATE INDEX IF NOT EXISTS "legal_documents_status_idx" ON "legal_documents"("status");
CREATE INDEX IF NOT EXISTS "legal_documents_code_idx" ON "legal_documents"("code");
CREATE INDEX IF NOT EXISTS "legal_documents_source_type_idx" ON "legal_documents"("source_type");
CREATE INDEX IF NOT EXISTS "legal_documents_createdAt_idx" ON "legal_documents"("createdAt");
CREATE INDEX IF NOT EXISTS "legal_obligations_docId_idx" ON "legal_obligations"("docId");
CREATE INDEX IF NOT EXISTS "legal_obligations_status_idx" ON "legal_obligations"("status");
CREATE INDEX IF NOT EXISTS "legal_obligations_risk_level_idx" ON "legal_obligations"("risk_level");
CREATE INDEX IF NOT EXISTS "legal_obligations_checklist_item_idx" ON "legal_obligations"("checklist_item");
CREATE INDEX IF NOT EXISTS "legal_segments_document_code_idx" ON "legal_segments"("document_code");
CREATE INDEX IF NOT EXISTS "legal_segments_checklist_key_idx" ON "legal_segments"("checklist_key");

-- Sensors & Sensor Readings
CREATE INDEX IF NOT EXISTS "sensors_siteId_idx" ON "sensors"("siteId");
CREATE INDEX IF NOT EXISTS "sensors_status_idx" ON "sensors"("status");
CREATE INDEX IF NOT EXISTS "idx_sensors_site_status" ON "sensors"("siteId", "status");
CREATE INDEX IF NOT EXISTS "sensor_readings_timestamp_idx" ON "sensor_readings"("timestamp" DESC);
CREATE INDEX IF NOT EXISTS "idx_sensor_readings_sensor_time_desc" ON "sensor_readings"("sensorId", "timestamp" DESC);

-- Alerts & Notifications
CREATE INDEX IF NOT EXISTS "alerts_siteId_idx" ON "alerts"("siteId");
CREATE INDEX IF NOT EXISTS "alerts_sensorId_idx" ON "alerts"("sensorId");
CREATE INDEX IF NOT EXISTS "alerts_status_idx" ON "alerts"("status");
CREATE INDEX IF NOT EXISTS "alerts_triggeredAt_idx" ON "alerts"("triggeredAt" DESC);
CREATE INDEX IF NOT EXISTS "alerts_slaDeadline_idx" ON "alerts"("slaDeadline" ASC);
CREATE INDEX IF NOT EXISTS "idx_alerts_site_status" ON "alerts"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_alerts_status_sla" ON "alerts"("status", "slaDeadline");
CREATE INDEX IF NOT EXISTS "idx_alerts_status_triggered" ON "alerts"("status", "triggeredAt" DESC);
CREATE INDEX IF NOT EXISTS "alert_notifications_alertId_idx" ON "alert_notifications"("alertId");
CREATE INDEX IF NOT EXISTS "alert_notifications_status_idx" ON "alert_notifications"("status");
CREATE INDEX IF NOT EXISTS "alert_notifications_recipient_idx" ON "alert_notifications"("recipient");

-- Cases & Timelines & Histories
CREATE INDEX IF NOT EXISTS "cases_siteId_idx" ON "cases"("siteId");
CREATE INDEX IF NOT EXISTS "cases_status_idx" ON "cases"("status");
CREATE INDEX IF NOT EXISTS "cases_complaintId_idx" ON "cases"("complaintId");
CREATE INDEX IF NOT EXISTS "cases_inspectionId_idx" ON "cases"("inspectionId");
CREATE INDEX IF NOT EXISTS "cases_createdAt_idx" ON "cases"("createdAt");
CREATE INDEX IF NOT EXISTS "cases_deletedAt_idx" ON "cases"("deletedAt");
CREATE INDEX IF NOT EXISTS "cases_slaDeadline_idx" ON "cases"("slaDeadline");
CREATE INDEX IF NOT EXISTS "idx_cases_status_created" ON "cases"("status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_cases_site_status" ON "cases"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_cases_site_created" ON "cases"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_cases_del_status_created" ON "cases"("deletedAt", "status", "createdAt" DESC);

CREATE INDEX IF NOT EXISTS "case_timelines_caseId_idx" ON "case_timelines"("caseId");
CREATE INDEX IF NOT EXISTS "idx_case_timelines_case_created" ON "case_timelines"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "case_status_history_caseId_idx" ON "case_status_history"("caseId");
CREATE INDEX IF NOT EXISTS "idx_case_status_history_case_created" ON "case_status_history"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "priority_score_history_siteId_idx" ON "priority_score_history"("siteId");
CREATE INDEX IF NOT EXISTS "priority_score_history_caseId_idx" ON "priority_score_history"("caseId");
CREATE INDEX IF NOT EXISTS "idx_priority_score_history_site_created" ON "priority_score_history"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "contractor_explanations_caseId_idx" ON "contractor_explanations"("caseId");
CREATE INDEX IF NOT EXISTS "contractor_explanations_status_idx" ON "contractor_explanations"("status");
CREATE INDEX IF NOT EXISTS "idx_contractor_expl_case_created" ON "contractor_explanations"("caseId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "sanction_decisions_caseId_idx" ON "sanction_decisions"("caseId");
CREATE INDEX IF NOT EXISTS "sanction_decisions_status_idx" ON "sanction_decisions"("status");
CREATE INDEX IF NOT EXISTS "idx_sanction_decisions_case_status" ON "sanction_decisions"("caseId", "status");

-- Community, Observations, Follow-ups, Handoffs, Youth
CREATE INDEX IF NOT EXISTS "communities_type_idx" ON "communities"("type");
CREATE INDEX IF NOT EXISTS "communities_member_count_idx" ON "communities"("member_count" DESC);
CREATE UNIQUE INDEX IF NOT EXISTS "idx_community_members_unique" ON "community_members"("community_id", "user_id");

CREATE INDEX IF NOT EXISTS "campaigns_status_idx" ON "campaigns"("status");
CREATE INDEX IF NOT EXISTS "campaigns_topic_idx" ON "campaigns"("topic");
CREATE INDEX IF NOT EXISTS "campaigns_ward_idx" ON "campaigns"("ward");
CREATE INDEX IF NOT EXISTS "idx_campaigns_status_created" ON "campaigns"("status", "created_at" DESC);
CREATE UNIQUE INDEX IF NOT EXISTS "idx_campaign_members_unique" ON "campaign_members"("campaign_id", "user_id");

CREATE INDEX IF NOT EXISTS "observations_site_id_idx" ON "observations"("site_id");
CREATE INDEX IF NOT EXISTS "observations_status_idx" ON "observations"("status");
CREATE INDEX IF NOT EXISTS "observations_created_at_idx" ON "observations"("created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_status_created" ON "observations"("status", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_site_created" ON "observations"("site_id", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_ward_category" ON "observations"("ward", "category");
CREATE INDEX IF NOT EXISTS "observation_evidence_obs_idx" ON "observation_evidence"("observation_id");

CREATE INDEX IF NOT EXISTS "follow_ups_outcome_idx" ON "follow_ups"("outcome_status");
CREATE INDEX IF NOT EXISTS "follow_ups_created_at_idx" ON "follow_ups"("created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_follow_ups_obs_created" ON "follow_ups"("observation_id", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "handoffs_obs_idx" ON "handoffs"("observation_id");
CREATE INDEX IF NOT EXISTS "handoffs_status_idx" ON "handoffs"("status");
CREATE INDEX IF NOT EXISTS "handoffs_recipient_idx" ON "handoffs"("recipient_unit");
CREATE INDEX IF NOT EXISTS "idx_handoffs_case_status" ON "handoffs"("case_id", "status");
CREATE INDEX IF NOT EXISTS "idx_handoffs_status_created" ON "handoffs"("status", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "impact_events_comm_idx" ON "impact_events"("community_id");
CREATE INDEX IF NOT EXISTS "idx_impact_events_type_created" ON "impact_events"("event_type", "created_at" DESC);

CREATE INDEX IF NOT EXISTS "youth_activities_camp_idx" ON "youth_activities"("campaign_id");
CREATE INDEX IF NOT EXISTS "youth_activities_obs_idx" ON "youth_activities"("observation_id");
CREATE INDEX IF NOT EXISTS "youth_certificates_status_idx" ON "youth_certificates"("status");
CREATE INDEX IF NOT EXISTS "idx_youth_cert_user_status" ON "youth_certificates"("user_id", "status");
