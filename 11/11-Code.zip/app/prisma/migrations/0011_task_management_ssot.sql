-- 0011_task_management_ssot.sql
-- DustGuard VN: Task Management & Field Community Actions Lifecycle Schema

CREATE TABLE IF NOT EXISTS "tasks" (
  "id" TEXT PRIMARY KEY,
  "code" TEXT UNIQUE,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "task_type" TEXT NOT NULL DEFAULT 'field_verification',
  "source_type" TEXT DEFAULT 'none',
  "source_id" TEXT,
  "campaign_id" TEXT,
  "case_id" TEXT,
  "site_id" TEXT,
  "observation_id" TEXT,
  "location_text" TEXT NOT NULL,
  "latitude" REAL,
  "longitude" REAL,
  "start_at" DATETIME,
  "due_at" DATETIME,
  "assignment_type" TEXT NOT NULL DEFAULT 'open',
  "assigned_profile_id" TEXT,
  "club_id" TEXT,
  "max_participants" INTEGER DEFAULT 10,
  "status" TEXT DEFAULT 'OPEN',
  "priority" TEXT DEFAULT 'MEDIUM',
  "points" INTEGER DEFAULT 20,
  "contribution_minutes" INTEGER DEFAULT 30,
  "evidence_instructions" TEXT,
  "created_by" TEXT,
  "created_at" DATETIME DEFAULT CURRENT_TIMESTAMP,
  "updated_at" DATETIME DEFAULT CURRENT_TIMESTAMP,
  "archived_at" DATETIME,
  "deleted_at" DATETIME
);

CREATE TABLE IF NOT EXISTS "task_participants" (
  "id" TEXT PRIMARY KEY,
  "task_id" TEXT NOT NULL,
  "profile_id" TEXT NOT NULL,
  "user_id" TEXT,
  "club_id" TEXT,
  "status" TEXT DEFAULT 'joined',
  "joined_at" DATETIME DEFAULT CURRENT_TIMESTAMP,
  "started_at" DATETIME,
  "submitted_at" DATETIME,
  "completed_at" DATETIME,
  "revision_notes" TEXT
);

CREATE TABLE IF NOT EXISTS "task_submissions" (
  "id" TEXT PRIMARY KEY,
  "task_id" TEXT NOT NULL,
  "participant_id" TEXT NOT NULL,
  "user_id" TEXT NOT NULL,
  "image_url" TEXT,
  "image_hash" TEXT,
  "outcome" TEXT DEFAULT 'BETTER',
  "notes" TEXT,
  "latitude" REAL,
  "longitude" REAL,
  "status" TEXT DEFAULT 'submitted',
  "review_note" TEXT,
  "reviewed_by" TEXT,
  "reviewed_at" DATETIME,
  "submitted_at" DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "task_timelines" (
  "id" TEXT PRIMARY KEY,
  "task_id" TEXT NOT NULL,
  "event_type" TEXT NOT NULL,
  "actor_id" TEXT,
  "actor_name" TEXT,
  "actor_role" TEXT,
  "description" TEXT,
  "metadata_json" TEXT,
  "created_at" DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "idx_tasks_status" ON "tasks"("status");
CREATE INDEX IF NOT EXISTS "idx_tasks_assignment" ON "tasks"("assignment_type", "assigned_profile_id", "club_id");
CREATE INDEX IF NOT EXISTS "idx_tasks_case" ON "tasks"("case_id");
CREATE INDEX IF NOT EXISTS "idx_tasks_campaign" ON "tasks"("campaign_id");
CREATE INDEX IF NOT EXISTS "idx_tasks_site" ON "tasks"("site_id");
CREATE INDEX IF NOT EXISTS "idx_tasks_due" ON "tasks"("due_at");
CREATE INDEX IF NOT EXISTS "idx_task_participants_task" ON "task_participants"("task_id", "status");
CREATE INDEX IF NOT EXISTS "idx_task_participants_user" ON "task_participants"("profile_id", "user_id");
CREATE INDEX IF NOT EXISTS "idx_task_submissions_task" ON "task_submissions"("task_id", "status");
CREATE INDEX IF NOT EXISTS "idx_task_timelines_task" ON "task_timelines"("task_id", "created_at" DESC);
