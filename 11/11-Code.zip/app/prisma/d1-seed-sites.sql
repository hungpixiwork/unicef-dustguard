INSERT INTO "sites" ("id", "name", "address", "ward", "province", "dustRiskScore", "riskLevel", "status", "investorName", "contractorName", "managerName", "managerPhone", "managerEmail", "createdAt", "updatedAt") 
VALUES 
('site-vd1', 'Công trường dự án đường vành đai 3', 'Đường vành đai 3, Phường Mai Dịch', 'Mai Dịch', 'Hà Nội', 92, 'CRITICAL', 'ACTIVE', 'BQL Dự án Giao thông', 'Tổng công ty XD số 1', 'Nguyễn Văn Cương', '0912345678', 'cuongnv.site@example.com', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('site-tx1', 'Khu dân cư Thanh Xuân', 'Ngõ 12 Khuất Duy Tiến, Phường Thanh Xuân Bắc', 'Thanh Xuân Bắc', 'Hà Nội', 45, 'LOW', 'ACTIVE', 'Cộng đồng', 'Không có', 'Trần Thanh Hải', '0905678901', 'haitransite@example.com', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('site-cc1', 'Dự án Chung cư Xanh', 'Lô A1, Phường Cầu Diễn', 'Cầu Diễn', 'Hà Nội', 85, 'MEDIUM', 'ACTIVE', 'Tập đoàn ABC', 'Công ty XD Hoa Binh', 'Lê Hoàng Nam', '0987654321', 'namlh.site@example.com', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO "sensors" ("id", "name", "code", "siteId", "status", "createdAt", "updatedAt")
VALUES
('sen-vd1', 'Cảm biến Bụi Vành Đai - Trạm Phía Bắc', 'SEN-VD1', 'site-vd1', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('sen-cc1', 'Cảm biến Bụi Chung Cư Xanh', 'SEN-CC1', 'site-cc1', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
