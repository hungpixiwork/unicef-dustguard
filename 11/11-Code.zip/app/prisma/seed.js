import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Bắt đầu seed dữ liệu mẫu...');

  // 1. Tạo demo sites với mã công trình chuẩn (SSOT)
  const sites = [
    {
      code: 'BD-0001',
      name: 'Công trường dự án đường vành đai',
      address: 'Đường vành đai 3, Phường Mai Dịch',
      ward: 'Mai Dịch',
      province: 'TP. Hà Nội',
      dustRiskScore: 94,
      riskLevel: 'CRITICAL',
      status: 'ACTIVE',
      investorName: 'BQL Dự án Giao thông',
      contractorName: 'Tổng công ty XD số 1',
      licenseNumber: 'GP-2024/0011',
      managerName: 'Nguyễn Văn Cương',
      managerPhone: '0912345678',
      managerEmail: 'cuongnv.site@example.com',
      coordinates: '21.0385, 105.7782'
    },
    {
      code: 'BD-0002',
      name: 'Khu dân cư Thanh Xuân',
      address: 'Ngõ 12 Khuất Duy Tiến, Phường Thanh Xuân Bắc',
      ward: 'Thanh Xuân Bắc',
      province: 'TP. Hà Nội',
      dustRiskScore: 45,
      riskLevel: 'LOW',
      status: 'ACTIVE',
      investorName: 'Cộng đồng',
      contractorName: 'Không có',
      licenseNumber: 'GP-2025/9981',
      managerName: 'Trần Thanh Hải',
      managerPhone: '0905678901',
      managerEmail: 'haitransite@example.com',
      coordinates: '20.9985, 105.7982'
    },
    {
      code: 'BD-0003',
      name: 'Dự án Chung cư Xanh',
      address: 'Lô A1, Phường Cầu Diễn',
      ward: 'Cầu Diễn',
      province: 'TP. Hà Nội',
      dustRiskScore: 85,
      riskLevel: 'HIGH',
      status: 'ACTIVE',
      investorName: 'Tập đoàn ABC',
      contractorName: 'Công ty XD Hoa Binh',
      licenseNumber: 'GP-2025/3341',
      managerName: 'Lê Hoàng Nam',
      managerPhone: '0987654321',
      managerEmail: 'namlh.site@example.com',
      coordinates: '21.0365, 105.7612'
    },
    {
      code: 'BD-0237',
      name: 'Dự án Tòa nhà Landmark Cầu Giấy',
      address: 'Phường Trung Hòa, Quận Cầu Giấy',
      ward: 'Trung Hòa',
      province: 'TP. Hà Nội',
      dustRiskScore: 87,
      riskLevel: 'CRITICAL',
      status: 'ACTIVE',
      investorName: 'Tập đoàn Đầu tư Cầu Giấy',
      contractorName: 'Công ty Cổ phần Xây dựng Hà Nội',
      licenseNumber: 'GP-2025/1192',
      managerName: 'Nguyễn Văn Anh',
      managerPhone: '0912999888',
      managerEmail: 'nguyenvana@caugiaygroup.vn',
      coordinates: '21.0085, 105.7942'
    },
    {
      code: 'BD-0198',
      name: 'Khu biệt thự liền kề Mộ Lao',
      address: 'Phường Mộ Lao, Quận Hà Đông',
      ward: 'Mộ Lao',
      province: 'TP. Hà Nội',
      dustRiskScore: 74,
      riskLevel: 'MEDIUM',
      status: 'ACTIVE',
      investorName: 'Công ty Đầu tư Mộ Lao',
      contractorName: 'Công ty Xây dựng Mộ Lao',
      licenseNumber: 'GP-2025/0841',
      managerName: 'Trần Thị Bình',
      managerPhone: '0913888777',
      managerEmail: 'tranb@molaoinvestment.vn',
      coordinates: '20.9835, 105.7842'
    },
    {
      code: 'BD-0305',
      name: 'Tòa nhà Văn phòng Dịch Vọng',
      address: 'Đường Nguyễn Văn Huyên, Phường Dịch Vọng, Quận Cầu Giấy',
      ward: 'Dịch Vọng',
      province: 'TP. Hà Nội',
      dustRiskScore: 63,
      riskLevel: 'MEDIUM',
      status: 'ACTIVE',
      investorName: 'Tổng công ty Phát triển Hà Nội',
      contractorName: 'Công ty Xây dựng Dịch Vọng',
      licenseNumber: 'GP-2024/0012',
      managerName: 'Lê Hoàng Cường',
      managerPhone: '0904777666',
      managerEmail: 'lehc@dichvongcorp.vn',
      coordinates: '21.0325, 105.7882'
    },
    {
      code: 'BD-0495',
      name: 'Công trình Metro Nhổn - Ga Hà Nội',
      address: 'Đường Láng, Quận Đống Đa',
      ward: 'Láng Thượng',
      province: 'TP. Hà Nội',
      dustRiskScore: 42,
      riskLevel: 'LOW',
      status: 'ACTIVE',
      investorName: 'Ban Quản lý Đường sắt Đô thị',
      contractorName: 'Liên danh Nhà thầu Metro Nhổn',
      licenseNumber: 'GP-2023/9910',
      managerName: 'Phạm Minh Dung',
      managerPhone: '0935666555',
      managerEmail: 'phamd@metroline.vn',
      coordinates: '21.0185, 105.8082'
    },
    {
      code: 'BD-0420',
      name: 'Khu phức hợp Yên Hòa',
      address: 'Phường Yên Hòa, Quận Cầu Giấy',
      ward: 'Yên Hòa',
      province: 'TP. Hà Nội',
      dustRiskScore: 91,
      riskLevel: 'CRITICAL',
      status: 'ACTIVE',
      investorName: 'Tập đoàn Phát triển Đô thị Yên Hòa',
      contractorName: 'Công ty Xây dựng Yên Hòa',
      licenseNumber: 'GP-2026/0045',
      managerName: 'Hoàng Vũ Em',
      managerPhone: '0888654321',
      managerEmail: 'hoangvue@yenhoagroup.vn',
      coordinates: '21.0215, 105.7912'
    }
  ];

  for (const siteData of sites) {
    let site = await prisma.site.findFirst({
      where: {
        OR: [
          { code: siteData.code },
          { name: siteData.name }
        ]
      }
    });
    if (!site) {
      site = await prisma.site.create({ data: siteData });
      console.log(`✅ Created site: [${siteData.code}] ${siteData.name}`);
    } else {
      site = await prisma.site.update({
        where: { id: site.id },
        data: {
          code: siteData.code,
          name: siteData.name,
          address: siteData.address,
          ward: siteData.ward,
          province: siteData.province,
          contractorName: siteData.contractorName,
          licenseNumber: siteData.licenseNumber,
          managerName: siteData.managerName,
          managerPhone: siteData.managerPhone,
          managerEmail: siteData.managerEmail,
          coordinates: siteData.coordinates,
          dustRiskScore: siteData.dustRiskScore,
          riskLevel: siteData.riskLevel
        }
      });
      console.log(`ℹ️ Updated site details for: [${siteData.code}] ${siteData.name}`);
    }
  }

  // 1b. Tạo Sensors và SensorReadings mẫu
  console.log('🌱 Bắt đầu seed dữ liệu cảm biến (Sensors & Readings)...');
  const dbSites = await prisma.site.findMany();
  const sensorsData = [
    {
      code: 'SEN-VD1',
      name: 'Cảm biến Bụi Vành Đai - Trạm Phía Bắc',
      siteName: 'Công trường dự án đường vành đai',
      status: 'ACTIVE'
    },
    {
      code: 'SEN-VD2',
      name: 'Cảm biến Bụi Vành Đai - Trạm Phía Nam',
      siteName: 'Công trường dự án đường vành đai',
      status: 'ACTIVE'
    },
    {
      code: 'SEN-CC1',
      name: 'Cảm biến Bụi Chung Cư Xanh',
      siteName: 'Dự án Chung cư Xanh',
      status: 'ACTIVE'
    },
    {
      code: 'SEN-TX1',
      name: 'Cảm biến Bụi Khu dân cư Thanh Xuân',
      siteName: 'Khu dân cư Thanh Xuân',
      status: 'ACTIVE'
    }
  ];

  for (const sens of sensorsData) {
    const site = dbSites.find(s => s.name === sens.siteName);
    if (site) {
      let sensor = await prisma.sensor.findUnique({ where: { code: sens.code } });
      if (!sensor) {
        sensor = await prisma.sensor.create({
          data: {
            code: sens.code,
            name: sens.name,
            siteId: site.id,
            status: sens.status
          }
        });
        console.log(`✅ Created sensor: ${sens.code} for site ${site.name}`);

        // Seed readings cách nhau 5 phút trong 20 phút qua
        const now = new Date();
        const basePM10 = sens.code === 'SEN-VD1' ? 180 : 80;
        const basePM25 = sens.code === 'SEN-VD1' ? 95 : 35;
        
        for (let i = 0; i < 5; i++) {
          const timestamp = new Date(now.getTime() - (20 - i * 5) * 60 * 1000);
          const pm10 = basePM10 + (Math.random() - 0.5) * 10;
          const pm25 = basePM25 + (Math.random() - 0.5) * 5;
          await prisma.sensorReading.create({
            data: {
              sensorId: sensor.id,
              pm10,
              pm25,
              timestamp
            }
          });
        }
        console.log(`✅ Seeded 5 readings for sensor ${sens.code}`);
      }
    }
  }

  // 2. Seed Legal Documents, Obligations, and Segments
  console.log('🌱 Bắt đầu seed dữ liệu pháp lý (Documents, Obligations, Segments)...');
  const legalDocuments = [
    {
      id: 'seed-nd-16-2022-nd-cp',
      sourceType: 'official_pdf_seed',
      documentType: 'Nghị định',
      code: 'NĐ 16/2022/NĐ-CP',
      title: 'Quy định xử phạt vi phạm hành chính về xây dựng',
      issuer: 'Chính phủ',
      issuedDate: '2022-01-28',
      effectiveDate: '2022-01-28',
      sourceUrl: 'docs/references/ND16-2022.pdf',
      status: 'extracted_seed',
      text: 'Nghị định 16/2022/NĐ-CP quy định xử phạt vi phạm hành chính về xây dựng. Phạm vi gồm hoạt động xây dựng, sản xuất vật liệu xây dựng, quản lý công trình hạ tầng kỹ thuật, kinh doanh bất động sản, quản lý và phát triển nhà. Trọng tâm là Điều 31 về trật tự xây dựng và Điều 32 về an toàn trong thi công xây dựng công trình.',
      obligations: [
        {
          id: 'nd16-site-barrier-spill',
          obligationId: 'nd16-site-barrier-spill',
          subject: 'Nhà thầu thi công/chủ đầu tư',
          action: 'Che chắn công trình đúng quy định, không để rơi vãi vật liệu xây dựng xuống khu vực xung quanh hoặc để vật liệu không đúng nơi quy định',
          condition: 'Khi tổ chức thi công xây dựng, đặc biệt tại khu vực tiếp giáp đường, khu dân cư hoặc không gian công cộng',
          legalBasis: 'Điều 31 Khoản 1 và khoản 5 Nghị định 16/2022/NĐ-CP',
          evidenceRequired: 'Ảnh mặt ngoài che chắn công trình; Ảnh vật liệu rơi vãi/khu vực xung quanh; Biên bản ghi nhận hiện trường',
          riskLevel: 'high',
          checklistItem: 'barrier',
          recommendedAction: 'Dừng khu vực gây rơi vãi, bổ dung che chắn kín và thu dọn vật liệu khỏi khu vực xung quanh',
          confidenceScore: 0.91,
          status: 'approved'
        },
        {
          id: 'nd16-site-safety-warning',
          obligationId: 'nd16-site-safety-warning',
          subject: 'Nhà thầu thi công/chủ đầu tư',
          action: 'Có biển cảnh báo, người hướng dẫn tại vị trí nguy hiểm và biện pháp an toàn, vệ sinh môi trường trong biện pháp thi công',
          condition: 'Khi công trường có vị trí nguy hiểm, công việc nguy cơ cao hoặc đang thi công xây dựng',
          legalBasis: 'Điều 32 Khoản 2 điểm d, h; khoản 4 điểm c Nghị định 16/2022/NĐ-CP',
          evidenceRequired: 'Ảnh biển cảnh báo vị trí nguy hiểm; Ảnh người hướng dẫn/kiểm soát khu vực; Biện pháp thi công có nội dung an toàn và vệ sinh môi trường',
          riskLevel: 'high',
          checklistItem: 'signage',
          recommendedAction: 'Bổ sung biển cảnh báo, phân công người hướng dẫn và cập nhật biện pháp an toàn/vệ sinh môi trường trước khi tiếp tục thi công',
          confidenceScore: 0.90,
          status: 'approved'
        }
      ]
    },
    {
      id: 'seed-nd-45-2022-nd-cp',
      sourceType: 'official_pdf_seed',
      documentType: 'Nghị định',
      code: 'NĐ 45/2022/NĐ-CP',
      title: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      issuer: 'Chính phủ',
      issuedDate: '2022-07-07',
      effectiveDate: '2022-08-25',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      status: 'extracted_seed',
      text: 'Nghị định 45/2022/NĐ-CP quy định hành vi vi phạm hành chính, hình thức xử phạt, mức xử phạt và biện pháp khắc phục hậu quả trong lĩnh vực bảo vệ môi trường, đặc biệt tập trung bảo vệ môi trường không khí, kiểm soát bụi xây dựng và chất thải.',
      obligations: [
        {
          id: 'nd45-environment-remediation',
          obligationId: 'nd45-environment-remediation',
          subject: 'Cá nhân/tổ chức gây ô nhiễm môi trường',
          action: 'Ghi nhận hậu quả pháp lý: khi vi phạm môi trường được xác lập, chủ thể vi phạm có thể bị buộc khắc phục ô nhiễm, phục hồi môi trường và giảm thiểu tiếng ồn, độ rung đạt quy chuẩn kỹ thuật',
          condition: 'Khi hoạt động thi công hoặc vận chuyển bị xác định gây ô nhiễm, phát tán bụi, tiếng ồn, độ rung hoặc ảnh hưởng môi trường xung quanh',
          legalBasis: 'Điều 4 Khoản 3 điểm a, c; khoản 9 điểm a Nghị định 45/2022/NĐ-CP',
          evidenceRequired: 'Ảnh/clip hiện trạng bụi, bùn, tiếng ồn hoặc rung; Biên bản ghi nhận phản ánh cộng đồng; Bằng chứng đã dọn dẹp hoặc giảm thiểu tác động',
          riskLevel: 'high',
          checklistItem: 'spill',
          recommendedAction: 'Ghi nhận hiện trạng, yêu cầu khắc phục ô nhiễm và lưu bằng chứng trước/sau để phục vụ xử lý nếu có vi phạm',
          confidenceScore: 0.86,
          status: 'approved'
        },
        {
          id: 'nd45-waste-safe-management',
          obligationId: 'nd45-waste-safe-management',
          subject: 'Cá nhân/tổ chức phát sinh chất thải',
          action: 'Ghi nhận hậu quả pháp lý: khi vi phạm về chất thải được xác lập, chủ thể vi phạm có thể bị buộc thu gom, lưu giữ, quản lý an toàn và chuyển giao chất thải cho đơn vị có chức năng xử lý',
          condition: 'Khi công trường phát sinh chất thải, vật liệu thải, bùn đất hoặc chất có nguy cơ gây ô nhiễm',
          legalBasis: 'Điều 4 Khoản 3 điểm i, k Nghị định 45/2022/NĐ-CP',
          evidenceRequired: 'Ảnh khu vực tập kết chất thải/vật liệu thải; Chứng từ chuyển giao chất thải nếu có; Ảnh che chắn và lưu giữ an toàn',
          riskLevel: 'high',
          checklistItem: 'cover',
          recommendedAction: 'Thu gom vật liệu/chất thải về điểm lưu giữ an toàn và chuẩn bị chứng cứ chuyển giao xử lý khi cần',
          confidenceScore: 0.82,
          status: 'approved'
        }
      ]
    },
    {
      id: 'seed-tt-16-2021-tt-bxd',
      sourceType: 'official_pdf_seed',
      documentType: 'Thông tư',
      code: 'TT 16/2021/TT-BXD',
      title: 'Ban hành QCVN 18:2021/BXD Quy chuẩn kỹ thuật quốc gia về an toàn trong thi công xây dựng',
      issuer: 'Bộ Xây dựng',
      issuedDate: '2021-12-20',
      effectiveDate: '2022-06-20',
      sourceUrl: 'docs/references/tt16-bxd.pdf',
      status: 'extracted_seed',
      text: 'Thông tư 16/2021/TT-BXD ban hành kèm theo QCVN 18:2021/BXD Quy chuẩn kỹ thuật quốc gia về an toàn trong thi công xây dựng. QCVN 18:2021/BXD là nguồn kỹ thuật chính về tổ chức công trường, vệ sinh môi trường, che chắn, kiểm soát khu vực nguy hiểm, lưu giữ vật liệu/chất thải và phá dỡ công trình.',
      obligations: [
        {
          id: 'tt16-qcvn18-site-environment',
          obligationId: 'tt16-qcvn18-site-environment',
          subject: 'Người sử dụng lao động/nhà thầu thi công',
          action: 'Lập và thực hiện chương trình, kế hoạch, biện pháp vệ sinh môi trường trên công trường và khu vực lân cận; thường xuyên làm vệ sinh, thu gom phế thải và xử lý chất thải',
          condition: 'Trong suốt quá trình tổ chức thi công xây dựng',
          legalBasis: 'QCVN 18:2021/BXD mục 2.1.3 Khoản 2.1.3.1, 2.1.3.2 điểm b, đ',
          evidenceRequired: 'Nhật ký vệ sinh công trường; Ảnh thu gom phế thải/chất thải; Ảnh khu vực xung quanh sau khi vệ sinh',
          riskLevel: 'high',
          checklistItem: 'spill',
          recommendedAction: 'Thiết lập lịch vệ sinh, thu gom phế thải và lưu bằng chứng trước/sau tại các điểm phát sinh bụi/bùn/chất thải',
          confidenceScore: 0.92,
          status: 'approved'
        },
        {
          id: 'tt16-qcvn18-material-storage',
          obligationId: 'tt16-qcvn18-material-storage',
          subject: 'Người sử dụng lao động/nhà thầu thi công',
          action: 'Bố trí kho, bãi lưu giữ phù hợp cho vật liệu, cấu kiện, sản phẩm và thiết bị; đặt vật liệu chưa sử dụng gọn để không ảnh hưởng công việc, giao thông trong công trường và khu vực xung quanh',
          condition: 'Khi lưu trữ, bốc dỡ hoặc sử dụng vật liệu, cấu kiện, phế thải trên công trường',
          legalBasis: 'QCVN 18:2021/BXD mục 2.1.3 Khoản 2.1.3.2 điểm a, c',
          evidenceRequired: 'Ảnh kho/bãi vật liệu; Ảnh vật liệu đã che phủ/sắp xếp gọn; Sơ đồ hoặc vị trí tập kết vật liệu',
          riskLevel: 'medium',
          checklistItem: 'cover',
          recommendedAction: 'Sắp xếp vật liệu rời vào khu vực tập kết, che phủ và tách khỏi lối đi/khu vực giáp dân cư',
          confidenceScore: 0.90,
          status: 'approved'
        },
        {
          id: 'tt16-qcvn18-emission-shielding',
          obligationId: 'tt16-qcvn18-emission-shielding',
          subject: 'Người sử dụng lao động/nhà thầu thi công',
          action: 'Thực hiện che chắn hoặc biện pháp hiệu quả khác để hạn chế phát thải, tiếng ồn, rung động và tác động khác không vượt giới hạn pháp luật về môi trường',
          condition: 'Khi thi công phát sinh bụi, tiếng ồn, rung động hoặc ảnh hưởng khu vực xung quanh',
          legalBasis: 'QCVN 18:2021/BXD mục 2.1.3 Khoản 2.1.3.2 điểm e',
          evidenceRequired: 'Ảnh che chắn/phun nước/phun sương/hút bụi; Nhật ký vận hành biện pháp giảm bụi; Kết quả đo/ghi nhận phản ánh nếu có',
          riskLevel: 'high',
          checklistItem: 'spray',
          recommendedAction: 'Áp dụng biện pháp giảm phát tán phù hợp như che chắn, phun nước/phun sương hoặc hút bụi và ghi nhật ký vận hành',
          confidenceScore: 0.93,
          status: 'approved'
        }
      ]
    }
  ];

  const legalSegments = [
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 1',
      content: 'Xử phạt đối với hành vi thi công xây dựng công trình không che chắn hoặc có che chắn nhưng để rò rỉ, phát tán bụi, khí thải không qua xử lý vượt quy chuẩn kỹ thuật ra môi trường xung quanh.',
      summary: 'Thi công xây dựng công trình không che chắn hoặc che chắn rách/hở gây phát tán bụi mịn từ công trường. Phạt tiền từ 20.000.000 đến 30.000.000 đồng đối với tổ chức. Buộc thực hiện che chắn bảo vệ môi trường theo quy định.',
      citation: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'barrier'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 2',
      content: 'Không thực hiện các biện pháp giảm bụi mịn và khí thải gồm phun nước dập bụi, tưới ẩm định kỳ tại các vị trí thi công đào đất, phá dỡ, cắt bê tông có nguy cơ phát tán bụi cao.',
      summary: 'Không phun nước dập bụi tại công trường gây phát tán ô nhiễm bụi mịn ra không khí. Phạt tiền từ 15.000.000 đến 25.000.000 đồng đối với tổ chức. Buộc áp dụng biện pháp tưới nước dập bụi.',
      citation: 'Khoản 2 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'spray'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 1',
      content: 'Không che phủ bạt hoặc che phủ không kín đối với vật liệu xây dựng dạng rời (cát, đá, xi măng) hoặc chất thải rắn xây dựng có khả năng phát tán bụi mịn để ngoài trời gây ô nhiễm.',
      summary: 'Các bãi chứa vật liệu xây dựng dạng rời không che phủ bạt gây gió cuốn phát tán bụi mịn. Phạt tiền từ 10.000.000 đến 20.000.000 đồng đối với tổ chức. Buộc che phủ kín bằng bạt.',
      citation: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'cover'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 3',
      content: 'Không thiết lập trạm rửa xe hoặc không rửa sạch bùn đất dính vào bánh xe, gầm xe của phương tiện vận chuyển trước khi rời khỏi khu vực công trường gây ô nhiễm lòng đường.',
      summary: 'Không rửa lốp xe vận chuyển bùn đất trước khi rời công trường kéo bùn đất ra đường bộ gây ô nhiễm. Phạt tiền từ 25.000.000 đến 35.000.000 đồng đối với tổ chức. Buộc rửa sạch phương tiện.',
      citation: 'Khoản 3 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'wheel'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 20',
      clause: 'Khoản 1',
      content: 'Hành vi vận chuyển nguyên liệu, vật liệu, chất thải không che phủ hoặc để rơi vãi, tràn ra đường bộ trong quá trình vận chuyển gây ô nhiễm môi trường.',
      summary: 'Để vật liệu rơi vãi hoặc tràn chất thải ra đường bộ gây ô nhiễm môi trường. Phạt tiền từ 30.000.000 đến 50.000.000 đồng đối với tổ chức. Buộc thu dọn lập tức và khắc phục ô nhiễm.',
      citation: 'Khoản 1 Điều 20 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'spill'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 2',
      content: 'Không áp dụng các biện pháp kiểm soát bụi chuyên dụng như cắt ướt, thu hồi bụi trực tiếp hoặc phun sương trong suốt quá trình phá dỡ công trình cũ hoặc cắt bê tông cấu kiện.',
      summary: 'Khi thực hiện phá dỡ hoặc cắt bê tông không có thiết bị dập bụi làm phát tán bụi mù mịt. Phạt tiền từ 20.000.000 đến 40.000.000 đồng đối với tổ chức. Buộc áp dụng cắt ướt dập bụi.',
      citation: 'Khoản 2 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'demo'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 18',
      clause: 'Khoản 1',
      content: 'Thi công các hạng mục công trình phát sinh tiếng ồn lớn, độ rung và bụi mịn ngoài khung giờ cho phép (từ 21h00 tối đến 06h00 sáng hôm sau) gây ảnh hưởng nghiêm trọng khu dân cư.',
      summary: 'Thi công gây tiếng ồn lớn và phát tán bụi trong khu dân cư vào ban đêm ngoài khung giờ cho phép (6h-21h). Phạt tiền từ 15.000.000 đến 30.000.000 đồng đối với tổ chức. Buộc ngừng hoạt động ngoài giờ.',
      citation: 'Điều 18 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'hours'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 1',
      content: 'Không bố trí cổng công trường kín hoặc không đóng cổng trong suốt thời gian thi công, để bụi mịn phát tán tự do qua cổng ra khu vực dân cư lân cận.',
      summary: 'Không giữ cổng công trường đóng kín trong khi thi công làm phát tán lượng lớn bụi mịn theo luồng gió ra ngoài. Phạt tiền từ 10.000.000 đến 20.000.000 đồng đối với tổ chức.',
      citation: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'gate'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 2',
      content: 'Không lắp dựng lưới chắn bụi bao che tầng cao chuyên dụng bao phủ toàn bộ bề mặt bên ngoài đối với công trình xây dựng có chiều cao từ 3 tầng trở lên.',
      summary: 'Thiếu lưới bao che tầng cao tại công trình xây dựng từ 3 tầng trở lên gây bụi mịn phát tán diện rộng. Phạt tiền từ 15.000.000 đến 25.000.000 đồng đối với tổ chức.',
      citation: 'Khoản 2 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'height'
    },
    {
      documentCode: 'NĐ 45/2022/NĐ-CP',
      documentTitle: 'Quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường',
      article: 'Điều 15',
      clause: 'Khoản 1',
      content: 'Không niêm yết, công khai thông tin bảo vệ môi trường tại bảng thông tin công trình đặt tại cổng chính hoặc bảng thông tin không đầy đủ theo quy định.',
      summary: 'Thiếu bảng công bố thông tin công trình, thông tin liên hệ phản ánh ô nhiễm môi trường tại cổng chính. Phạt tiền từ 5.000.000 đến 10.000.000 đồng đối với tổ chức.',
      citation: 'Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP',
      sourceUrl: 'docs/references/nd45-2022.pdf',
      checklistKey: 'signage'
    }
  ];

  await prisma.legalObligation.deleteMany({});
  await prisma.legalDocument.deleteMany({});
  await prisma.legalSegment.deleteMany({});

  for (const doc of legalDocuments) {
    const { obligations, ...docData } = doc;
    await prisma.legalDocument.create({ data: docData });
    for (const obl of obligations) {
      await prisma.legalObligation.create({
        data: {
          ...obl,
          docId: doc.id
        }
      });
    }
  }

  for (const segment of legalSegments) {
    await prisma.legalSegment.create({ data: segment });
  }

  console.log(`✅ Seeded ${legalDocuments.length} legal documents and ${legalSegments.length} segments successfully.`);

  // 3. Seed DraftDocuments
  console.log('🌱 Bắt đầu seed dữ liệu DraftDocument...');
  const mainSite = await prisma.site.findFirst({ where: { name: 'Công trường dự án đường vành đai' } });
  const altSite = await prisma.site.findFirst({ where: { name: 'Dự án Chung cư Xanh' } });

  if (mainSite) {
    const draftCount = await prisma.draftDocument.count();
    if (draftCount === 0) {
      await prisma.draftDocument.createMany({
        data: [
          {
            siteId: mainSite.id,
            documentType: 'bien-ban-vphc',
            title: `BIÊN BẢN VI PHẠM HÀNH CHÍNH - ${mainSite.name}`,
            content: `
# BIÊN BẢN VI PHẠM HÀNH CHÍNH
## Về việc tuân thủ bảo vệ môi trường và kiểm soát bụi xây dựng tại công trường

Đoàn thanh tra liên ngành tiến hành kiểm tra công tác kiểm soát bụi và khí thải xây dựng tại dự án: **${mainSite.name}**.

**I. KẾT QUẢ GHI NHẬN HIỆN TRƯỜNG:**
1. Không lắp đặt rào chắn, che chắn bụi khu vực thi công mặt tiền giáp đường giao thông.
2. Không thực hiện phun nước dập bụi khi thi công đào đất san lấp.
3. Để bùn đất bám dính bánh xe vận chuyển kéo ra lòng đường gây ô nhiễm nghiêm trọng.

**II. CĂN CỨ PHÁP LÝ VÀ HÌNH THỨC XỬ PHẠT ĐỀ XUẤT:**
- Vi phạm Khoản 1, Khoản 2, Khoản 3 Điều 15 Nghị định 45/2022/NĐ-CP về bảo vệ môi trường xây dựng.
- Đề xuất phạt tiền khung trung bình: **65.000.000 đồng**.
            `,
            status: 'DRAFT',
            metadata: JSON.stringify({
              organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
              officer: { name: 'Nguyễn Văn An', title: 'Thanh tra viên môi trường' },
              location: 'Hà Nội'
            })
          },
          {
            siteId: mainSite.id,
            documentType: 'corrective_notice',
            title: `THÔNG BÁO YÊU CẦU KHẮC PHỤC VI PHẠM - ${mainSite.name}`,
            content: `
# THÔNG BÁO YÊU CẦU KHẮC PHỤC
Yêu cầu Ban chỉ huy công trình **${mainSite.name}** lập tức bổ sung bạt che phủ bạt kín toàn bộ cát, đá, vật liệu xây dựng lộ thiên hoặc đóng bao lưu giữ trước 17h00 ngày hôm nay.
            `,
            status: 'DRAFT',
            metadata: JSON.stringify({
              organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
              officer: { name: 'Trần Văn Cường', title: 'Cán bộ giám sát' },
              location: 'Hà Nội'
            })
          }
        ]
      });
      console.log('✅ Seeded DraftDocuments successfully.');
    }
  }

  if (altSite) {
    const draftCount = await prisma.draftDocument.count({ where: { siteId: altSite.id } });
    if (draftCount === 0) {
      await prisma.draftDocument.create({
        data: {
          siteId: altSite.id,
          documentType: 'bien-ban-kiem-tra',
          title: `BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG - ${altSite.name}`,
          content: `
# BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG
Ghi nhận công trường **${altSite.name}** cơ bản chấp hành các quy định về dập bụi, trạm rửa bánh xe hoạt động tốt. Góp ý bổ sung thêm biển cảnh báo an toàn.
          `,
          status: 'DRAFT',
          metadata: JSON.stringify({
            organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
            officer: { name: 'Nguyễn Văn An', title: 'Thanh tra viên' },
            location: 'Hà Nội'
          })
        }
      });
      console.log('✅ Seeded site draft document successfully.');
    }
  }

  // 4. Seed AuditLogs
  console.log('🌱 Bắt đầu seed dữ liệu AuditLog...');
  const logCount = await prisma.auditLog.count();
  if (logCount <= 1) { // 1 because of our previous check test
    await prisma.auditLog.createMany({
      data: [
        {
          userId: 'seed-staff-1',
          action: 'INSPECTION_CREATE',
          details: JSON.stringify({
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            siteName: 'Công trường dự án đường vành đai',
            inspectionId: 'mock-insp-1'
          })
        },
        {
          userId: 'seed-staff-1',
          action: 'ACTION_CREATE',
          details: JSON.stringify({
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            siteName: 'Công trường dự án đường vành đai',
            actionTitle: 'Lắp lưới rào che chắn mặt tiền'
          })
        },
        {
          userId: 'seed-staff-2',
          action: 'COMPLAINT_STATUS_UPDATE',
          details: JSON.stringify({
            actorName: 'Trần Văn Cường',
            actorRole: 'staff',
            complaintCode: 'DG-2026-X01',
            status: 'PROCESSING'
          })
        },
        {
          userId: 'seed-leader-1',
          action: 'LEADER_SIGN_DOCUMENT',
          details: JSON.stringify({
            actorName: 'Phạm Phú Hưng',
            actorRole: 'executive',
            documentTitle: 'BIÊN BẢN VI PHẠM HÀNH CHÍNH - Dự án Chung cư Xanh'
          })
        }
      ]
    });
    console.log('✅ Seeded AuditLogs successfully.');
  }

  // 5. Seed Inspections & Actions for contractor portal testing
  console.log('🌱 Bắt đầu seed dữ liệu Inspection và Action cho Công trường...');
  if (mainSite) {
    const inspectionCount = await prisma.inspection.count({ where: { siteId: mainSite.id } });
    if (inspectionCount === 0) {
      const inspection = await prisma.inspection.create({
        data: {
          siteId: mainSite.id,
          findings: JSON.stringify([
            { k: 'barrier', status: 'fail', notes: 'Hệ thống lưới chắn bụi mặt tiền bị rách, không kín che chắn.' },
            { k: 'wheel', status: 'fail', notes: 'Trạm rửa xe tải không hoạt động, kéo bùn ra đường.' },
            { k: 'cover', status: 'fail', notes: 'Bãi cát đá lộ thiên không được phủ bạt che chắn.' }
          ]),
          actionTaken: 'Yêu cầu khắc phục vi phạm môi trường và lập lưới chắn bụi',
          scoreDelta: 45
        }
      });
      console.log('✅ Seeded initial inspection for mainSite');

      await prisma.action.createMany({
        data: [
          {
            siteId: mainSite.id,
            inspectionId: inspection.id,
            title: 'Khắc phục vi phạm: barrier',
            description: 'Yêu cầu lắp đặt toàn bộ lưới, rào chắn bụi kín mặt tiền và các tầng cao của công trình.',
            status: 'PENDING',
            assignee: 'Nhà thầu chính',
            dueDate: new Date(Date.now() + 48 * 60 * 60 * 1000)
          },
          {
            siteId: mainSite.id,
            inspectionId: inspection.id,
            title: 'Khắc phục vi phạm: wheel',
            description: 'Thiết lập trạm rửa xe và bắt buộc rửa sạch bùn đất trên bánh xe trước khi di chuyển ra đường công cộng.',
            status: 'PENDING',
            assignee: 'Nhà thầu chính',
            dueDate: new Date(Date.now() + 48 * 60 * 60 * 1000)
          },
          {
            siteId: mainSite.id,
            inspectionId: inspection.id,
            title: 'Khắc phục vi phạm: cover',
            description: 'Che phủ bạt kín toàn bộ cát, đá, xi măng, vật liệu xây dựng lộ thiên hoặc đóng bao lưu giữ.',
            status: 'PENDING',
            assignee: 'Nhà thầu chính',
            dueDate: new Date(Date.now() + 72 * 60 * 60 * 1000)
          }
        ]
      });
      console.log('✅ Seeded initial actions for mainSite');
    }
  }

  // 6. Seed Cases cho quy trình 7 bước mới
  console.log('🌱 Bắt đầu seed dữ liệu Case (Quy trình 7 bước)...');

  // Xóa sạch dữ liệu cũ liên quan đến Case và Complaint để chạy idempotent
  await prisma.caseTimeline.deleteMany({});
  await prisma.contractorExplanation.deleteMany({});
  await prisma.sanctionDecision.deleteMany({});
  await prisma.case.deleteMany({});
  await prisma.complaint.deleteMany({});

  if (!mainSite || !altSite) {
    console.error('❌ Không tìm thấy mainSite hoặc altSite để seed Cases.');
    return;
  }

  // --- BƯỚC 1: SCREENING (Tiếp nhận sàng lọc) ---
  const complaint1 = await prisma.complaint.create({
    data: {
      code: 'DG-2026-C01',
      siteId: mainSite.id,
      ward: mainSite.ward,
      address: 'Đầu ngõ giáp công trường vành đai 3',
      description: 'Bụi phát tán mù mịt từ hoạt động múc cát đá tại công trường mà không có hệ thống phun sương hay tưới nước dập bụi, gió thổi bay hết vào nhà dân.',
      reporterName: 'Nguyễn Thị Lan',
      reporterPhone: '0988123456',
      status: 'PENDING',
      priority: 'MEDIUM',
    }
  });

  const case1 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0001',
      title: 'Sàng lọc phản ánh ô nhiễm bụi tại Dự án đường vành đai',
      description: 'Tiếp nhận phản ánh từ người dân về tình trạng phát tán bụi mịn do hoạt động thi công không che chắn và dập bụi tại đường vành đai 3.',
      status: 'SCREENING',
      sourceType: 'COMPLAINT',
      sourceId: complaint1.id,
      siteId: mainSite.id,
      complaintId: complaint1.id,
      timeline: {
        create: [
          {
            eventTitle: 'Tiếp nhận phản ánh từ công dân',
            eventDescription: 'Công dân Nguyễn Thị Lan gửi phản ánh mã số DG-2026-C01 kèm bằng chứng hình ảnh khói bụi phát tán.',
            eventType: 'CREATION',
            actorName: 'Nguyễn Thị Lan',
            actorRole: 'citizen',
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Khởi tạo hồ sơ vụ việc',
            eventDescription: 'Hệ thống tự động khởi tạo hồ sơ xử lý vụ việc ở trạng thái Sàng lọc (SCREENING).',
            eventType: 'SYSTEM',
            actorName: 'Hệ thống',
            actorRole: 'system',
            createdAt: new Date(Date.now() - 23 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // --- BƯỚC 2: PREPARING (Chuẩn bị thanh tra) ---
  const case2 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0002',
      title: 'Chuẩn bị thanh tra đột xuất tại Dự án Chung cư Xanh',
      description: 'Cảm biến bụi PM10 ghi nhận vượt ngưỡng liên tục trong 3 giờ qua. Đoàn thanh tra chuẩn bị hồ sơ thanh tra đột xuất.',
      status: 'PREPARING',
      sourceType: 'SENSOR',
      siteId: altSite.id,
      timeline: {
        create: [
          {
            eventTitle: 'Cảnh báo ô nhiễm không khí',
            eventDescription: 'Cảm biến SEN-CC1 tại Dự án Chung cư Xanh ghi nhận chỉ số PM10 đạt 185 µg/m³ (vượt ngưỡng cho phép).',
            eventType: 'CREATION',
            actorName: 'Hệ thống',
            actorRole: 'system',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Lập hồ sơ chuẩn bị thanh tra',
            eventDescription: 'Cán bộ Nguyễn Văn An đề xuất kế hoạch thanh tra đột xuất và chuẩn bị dự thảo Quyết định thanh tra.',
            eventType: 'PREPARATION',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // Tạo dự thảo Quyết định thanh tra liên kết với Case 2
  await prisma.draftDocument.create({
    data: {
      siteId: altSite.id,
      caseId: case2.id,
      documentType: 'corrective_notice',
      title: 'Dự thảo Quyết định thanh tra đột xuất - Dự án Chung cư Xanh',
      content: `
# QUYẾT ĐỊNH
## Về việc thanh tra đột xuất công tác bảo vệ môi trường xây dựng

Căn cứ Luật Bảo vệ Môi trường và Nghị định 45/2022/NĐ-CP.
Thành lập đoàn thanh tra đột xuất đối với **${altSite.name}** tại địa chỉ ${altSite.address}.

**Thành phần đoàn thanh tra:**
1. Ông Nguyễn Văn An - Thanh tra viên (Trưởng đoàn)
2. Bà Trần Thị Bình - Chuyên viên phòng Môi trường

Quyết định này có hiệu lực kể từ ngày ký.
      `,
      status: 'DRAFT',
      metadata: JSON.stringify({
        organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'PHÒNG THANH TRA' },
        officer: { name: 'Nguyễn Văn An', title: 'Thanh tra viên' },
        location: 'Hà Nội'
      })
    }
  });

  // --- BƯỚC 3: DECISION_ISSUED (Ban hành quyết định) ---
  const case3 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0003',
      title: 'Kiểm tra ô nhiễm bụi tại Dự án đường vành đai',
      description: 'Lãnh đạo đã ban hành Quyết định kiểm tra đột xuất số 45/QĐ-STNMT. Đang chuyển giao quyết định và lên lịch kiểm tra thực địa.',
      status: 'DECISION_ISSUED',
      sourceType: 'COMPLAINT',
      siteId: mainSite.id,
      timeline: {
        create: [
          {
            eventTitle: 'Tiếp nhận phản ánh',
            eventDescription: 'Hệ thống tiếp nhận phản ánh vương vãi bùn đất từ công trường.',
            eventType: 'CREATION',
            actorName: 'Hệ thống',
            actorRole: 'system',
            createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Đề xuất thanh tra',
            eventDescription: 'Lập tờ trình chuẩn bị hồ sơ thanh tra đột xuất công trường.',
            eventType: 'PREPARATION',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Ban hành Quyết định kiểm tra',
            eventDescription: 'Lãnh đạo Sở TNMT ký ban hành Quyết định kiểm tra đột xuất số 45/QĐ-STNMT.',
            eventType: 'DECISION_ISSUED',
            actorName: 'Phạm Phú Hưng',
            actorRole: 'executive',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // Tạo Quyết định kiểm tra đã ký liên kết với Case 3
  await prisma.draftDocument.create({
    data: {
      siteId: mainSite.id,
      caseId: case3.id,
      documentType: 'bien-ban-kiem-tra',
      title: 'Quyết định kiểm tra đột xuất số 45/QĐ-STNMT',
      content: `
# QUYẾT ĐỊNH KIỂM TRA ĐỘT XUẤT
## Số: 45/QĐ-STNMT

Giám đốc Sở Tài nguyên và Môi trường quyết định tiến hành kiểm tra đột xuất công tác bảo vệ môi trường, hạn chế bụi mịn tại dự án: **${mainSite.name}**.
Yêu cầu nhà thầu chuẩn bị hồ sơ pháp lý về môi trường, nhật ký vận hành trạm rửa xe và báo cáo biện pháp thi công.
      `,
      status: 'APPROVED',
      metadata: JSON.stringify({
        organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
        officer: { name: 'Phạm Phú Hưng', title: 'Giám đốc Sở' },
        location: 'Hà Nội'
      })
    }
  });

  // --- BƯỚC 4: ON_SITE (Đến cơ sở) ---
  const case4 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0004',
      title: 'Kiểm tra thực tế hiện trường Dự án Chung cư Xanh',
      description: 'Đoàn thanh tra đang có mặt tại hiện trường để tiến hành kiểm tra thực tế các biện pháp bảo vệ môi trường.',
      status: 'ON_SITE',
      sourceType: 'SENSOR',
      siteId: altSite.id,
      timeline: {
        create: [
          {
            eventTitle: 'Hệ thống báo động bụi mịn',
            eventDescription: 'Chỉ số PM10 vượt ngưỡng đỏ liên tục.',
            eventType: 'CREATION',
            actorName: 'Hệ thống',
            actorRole: 'system',
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Ban hành Quyết định kiểm tra',
            eventDescription: 'Lãnh đạo ký ban hành Quyết định số 46/QĐ-STNMT.',
            eventType: 'DECISION_ISSUED',
            actorName: 'Phạm Phú Hưng',
            actorRole: 'executive',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Tiến hành kiểm tra thực địa',
            eventDescription: 'Đoàn thanh tra công bố quyết định tại văn phòng Ban quản lý dự án và bắt đầu đi kiểm tra các hạng mục thi công.',
            eventType: 'ON_SITE',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // --- BƯỚC 5: REPORTING (Báo cáo kết quả/ dự thảo kết quả) ---
  const inspection5 = await prisma.inspection.create({
    data: {
      siteId: mainSite.id,
      findings: JSON.stringify([
        { k: 'barrier', status: 'pass', notes: 'Có rào chắn tôn bao quanh công trình.' },
        { k: 'wheel', status: 'fail', notes: 'Không rửa lốp xe vận chuyển bùn đất trước khi rời công trường.' },
        { k: 'cover', status: 'fail', notes: 'Bãi cát san lấp rộng khoảng 100m2 lộ thiên không được phủ bạt.' }
      ]),
      actionTaken: 'Lập Biên bản vi phạm hành chính, đề xuất xử phạt hành vi không rửa lốp xe và thiếu che chắn bãi vật liệu rời.',
      scoreDelta: 35
    }
  });

  const case5 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0005',
      title: 'Lập dự thảo kết quả kiểm tra tại Dự án đường vành đai',
      description: 'Đoàn kiểm tra đã hoàn thành công tác hiện trường và đang soạn thảo Báo cáo kết quả kiểm tra cùng dự thảo Biên bản vi phạm hành chính.',
      status: 'REPORTING',
      sourceType: 'COMPLAINT',
      siteId: mainSite.id,
      inspectionId: inspection5.id,
      timeline: {
        create: [
          {
            eventTitle: 'Ban hành quyết định kiểm tra',
            eventType: 'DECISION_ISSUED',
            actorName: 'Phạm Phú Hưng',
            actorRole: 'executive',
            createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Kiểm tra hiện trường',
            eventDescription: 'Thực hiện đo đạc và ghi nhận vi phạm tại thực địa công trường.',
            eventType: 'ON_SITE',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Lập biên bản kiểm tra hiện trường',
            eventDescription: 'Ghi nhận lỗi vi phạm vệ sinh bánh xe và che phủ bãi vật liệu.',
            eventType: 'INSPECTION_COMPLETED',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Soạn thảo dự thảo Biên bản vi phạm hành chính',
            eventDescription: 'Đoàn thanh tra đang hoàn thiện báo cáo kết quả kiểm tra và soạn thảo biên bản VPHC số 88/BB-VPHC.',
            eventType: 'REPORTING',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // Tạo dự thảo biên bản VPHC liên kết với Case 5
  await prisma.draftDocument.create({
    data: {
      siteId: mainSite.id,
      caseId: case5.id,
      inspectionId: inspection5.id,
      documentType: 'bien-ban-vphc',
      title: 'Biên bản vi phạm hành chính số 88/BB-VPHC',
      content: `
# DỰ THẢO BIÊN BẢN VI PHẠM HÀNH CHÍNH
## Về lĩnh vực bảo vệ môi trường xây dựng

Hôm nay, Đoàn thanh tra đã lập biên bản vi phạm đối với:
- Đơn vị vi phạm: **${mainSite.contractorName}**
- Người đại diện: Ông Nguyễn Văn Cương - Chỉ huy trưởng

**Hành vi vi phạm:**
1. Không rửa sạch bánh xe phương tiện vận chuyển trước khi ra khỏi công trường (Vi phạm Khoản 3 Điều 15 Nghị định 45/2022/NĐ-CP).
2. Không che phủ bạt bãi cát đá xây dựng lộ thiên gây phát tán bụi (Vi phạm Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP).

**Đề xuất biện pháp xử lý:**
- Phạt tiền 40.000.000 đồng đối với tổ chức.
- Buộc rửa sạch phương tiện và che phủ toàn bộ bạt trước ngày 15/06/2026.
      `,
      status: 'DRAFT',
      metadata: JSON.stringify({
        organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA' },
        officer: { name: 'Nguyễn Văn An', title: 'Thanh tra viên' },
        location: 'Hà Nội'
      })
    }
  });

  // --- BƯỚC 6: APPRAISING (Thẩm định) ---
  const inspection6 = await prisma.inspection.create({
    data: {
      siteId: mainSite.id,
      findings: JSON.stringify([
        { k: 'barrier', status: 'fail', notes: 'Lưới chắn bụi tầng cao rách nhiều nơi.' },
        { k: 'wheel', status: 'pass', notes: 'Có trạm rửa lốp xe hoạt động.' },
        { k: 'cover', status: 'fail', notes: 'Không có bạt che phủ bãi cát lớn.' }
      ]),
      actionTaken: 'Lập Biên bản VPHC số 89/BB-VPHC trình thẩm định hồ sơ xử phạt.',
      scoreDelta: 40
    }
  });

  const case6 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0006',
      title: 'Thẩm định hồ sơ xử phạt vi phạm hành chính tại Dự án đường vành đai',
      description: 'Phòng Pháp chế đang tiến hành thẩm định hồ sơ vi phạm hành chính và văn bản giải trình của nhà thầu trước khi ra Quyết định xử phạt chính thức.',
      status: 'APPRAISING',
      sourceType: 'COMPLAINT',
      siteId: mainSite.id,
      inspectionId: inspection6.id,
      timeline: {
        create: [
          {
            eventTitle: 'Kiểm tra hiện trường & Lập Biên bản VPHC',
            eventDescription: 'Đoàn kiểm tra đã ký Biên bản VPHC số 89/BB-VPHC với đại diện nhà thầu.',
            eventType: 'REPORT_SUBMITTED',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Nhà thầu gửi văn bản giải trình',
            eventDescription: 'Chỉ huy trưởng gửi văn bản giải trình lý do hệ thống lưới rách do giông lốc đêm hôm trước và đang đợi vận chuyển lưới mới để thay thế.',
            eventType: 'EXPLANATION_SUBMITTED',
            actorName: 'Nguyễn Văn Cương',
            actorRole: 'contractor',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Thẩm định hồ sơ pháp lý',
            eventDescription: 'Hồ sơ được chuyển sang phòng Pháp chế tiến hành thẩm định tính pháp lý và các tình tiết giảm nhẹ.',
            eventType: 'APPRAISAL_START',
            actorName: 'Trần Văn Cường',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // Tạo Biên bản VPHC chính thức liên kết với Case 6
  await prisma.draftDocument.create({
    data: {
      siteId: mainSite.id,
      caseId: case6.id,
      inspectionId: inspection6.id,
      documentType: 'bien-ban-vphc',
      title: 'Biên bản vi phạm hành chính số 89/BB-VPHC',
      content: `
# BIÊN BẢN VI PHẠM HÀNH CHÍNH
## Mã số: 89/BB-VPHC-MT

Căn cứ kết quả kiểm tra thực tế ngày 06/06/2026.
Đoàn thanh tra xác định hành vi vi phạm của **${mainSite.contractorName}**:
1. Không thực hiện bao che chắn bụi tầng cao chuyên dụng đầy đủ (Vi phạm Khoản 2 Điều 15 Nghị định 45/2022/NĐ-CP).
2. Không che phủ bạt bãi cát dự trữ xây dựng (Vi phạm Khoản 1 Điều 15 Nghị định 45/2022/NĐ-CP).

Đoàn thanh tra đã bàn giao biên bản cho nhà thầu để thực hiện quyền giải trình theo quy định pháp luật.
      `,
      status: 'SUBMITTED',
      metadata: JSON.stringify({
        organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA' },
        officer: { name: 'Nguyễn Văn An', title: 'Thanh tra viên' },
        location: 'Hà Nội'
      })
    }
  });

  // Tạo Contractor Explanation cho Case 6
  await prisma.contractorExplanation.create({
    data: {
      caseId: case6.id,
      contractorId: 'seed-contractor-user',
      explanation: 'Chúng tôi thừa nhận việc lưới chắn bị rách do trận giông bão lớn vào đêm 05/06/2026. Ngay sau khi giông bão tan, chúng tôi đã liên hệ đơn vị cung cấp lưới để lắp lại. Do lưới chuyên dụng khổ lớn cần vận chuyển từ kho xa nên chưa kịp hoàn thiện khi đoàn kiểm tra đến. Kính mong đoàn thanh tra xem xét tình tiết khách quan này giảm nhẹ mức phạt.',
      evidenceUrls: '/uploads/evidences/storm-damage.jpg',
      status: 'PENDING',
      submittedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
    }
  });

  // --- BƯỚC 7: COMPLETED (Ban hành kết quả công khai xử lý) ---
  const inspection7 = await prisma.inspection.create({
    data: {
      siteId: altSite.id,
      findings: JSON.stringify([
        { k: 'barrier', status: 'fail', notes: 'Che chắn tôn bị hở chân phía dưới.' },
        { k: 'wheel', status: 'fail', notes: 'Bùn đất dính bánh xe trôi ra đường phụ.' },
        { k: 'cover', status: 'fail', notes: 'Bãi thải phế liệu không có bạt phủ.' }
      ]),
      actionTaken: 'Xử phạt hành chính và yêu cầu khắc phục triệt để.',
      scoreDelta: 50
    }
  });

  const case7 = await prisma.case.create({
    data: {
      code: 'CASE-2026-0007',
      title: 'Hoàn thành xử lý vi phạm phát tán bụi tại Dự án Chung cư Xanh',
      description: 'Nhà thầu đã chấp hành Quyết định xử phạt 102/QĐ-XPHC, nộp phạt 25.000.000đ và hoàn tất khắc phục toàn bộ các lỗi che chắn, vệ sinh bánh xe. Hồ sơ đã được nghiệm thu và đóng công khai.',
      status: 'COMPLETED',
      sourceType: 'SENSOR',
      siteId: altSite.id,
      inspectionId: inspection7.id,
      timeline: {
        create: [
          {
            eventTitle: 'Lập Biên bản vi phạm hành chính',
            eventType: 'REPORT_SUBMITTED',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Ban hành Quyết định xử phạt',
            eventDescription: 'Ban hành Quyết định xử phạt số 102/QĐ-XPHC-TNMT với mức phạt 25.000.000 đồng.',
            eventType: 'DECISION_ISSUED',
            actorName: 'Phạm Phú Hưng',
            actorRole: 'executive',
            createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Nhà thầu nộp tiền phạt',
            eventDescription: 'Đại diện nhà thầu gửi biên lai nộp tiền vào tài khoản Kho bạc nhà nước.',
            eventType: 'SANCTION_PAID',
            actorName: 'Lê Hoàng Nam',
            actorRole: 'contractor',
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Nghiệm thu công tác khắc phục',
            eventDescription: 'Đoàn kiểm tra quay lại hiện trường xác nhận nhà thầu đã gia cố rào chắn tôn, rửa sạch bánh xe và che bạt bãi thải.',
            eventType: 'REMEDY_VERIFIED',
            actorName: 'Nguyễn Văn An',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
          },
          {
            eventTitle: 'Đóng hồ sơ vụ việc',
            eventDescription: 'Hoàn thành toàn bộ nghĩa vụ và khắc phục. Vụ việc chính thức khép lại và công khai kết quả xử lý.',
            eventType: 'CLOSED',
            actorName: 'Trần Văn Cường',
            actorRole: 'staff',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
          }
        ]
      }
    }
  });

  // Tạo Quyết định xử phạt đã hoàn thành liên kết với Case 7
  await prisma.sanctionDecision.create({
    data: {
      caseId: case7.id,
      decisionNumber: '102/QĐ-XPHC-TNMT',
      penaltyAmount: 25000000,
      remedialMeasures: '1. Gia cố chân rào chắn tôn chống rò rỉ bụi cát. 2. Làm sạch bùn đất trên lốp xe trước khi xuất xưởng. 3. Phủ bạt kín bãi thải xây dựng.',
      status: 'COMPLETED',
      issuedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
    }
  });

  // Tạo các Action đã hoàn thành liên kết với Case 7
  await prisma.action.createMany({
    data: [
      {
        siteId: altSite.id,
        caseId: case7.id,
        inspectionId: inspection7.id,
        title: 'Khắc phục vi phạm: barrier (Đã nghiệm thu)',
        description: 'Yêu cầu gia cố chân rào chắn tôn chống rò rỉ bụi cát.',
        status: 'VERIFIED',
        assignee: altSite.contractorName,
        dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        evidenceUrl: '/uploads/evidences/barrier-remedied.jpg'
      },
      {
        siteId: altSite.id,
        caseId: case7.id,
        inspectionId: inspection7.id,
        title: 'Khắc phục vi phạm: wheel (Đã nghiệm thu)',
        description: 'Vệ sinh sạch bánh xe trước khi rời khỏi khu vực công trường.',
        status: 'VERIFIED',
        assignee: altSite.contractorName,
        dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        evidenceUrl: '/uploads/evidences/wheel-remedied.jpg'
      }
    ]
  });

  console.log('✅ Seeded 7 Cases for the new 7-step process successfully.');

  console.log('🎉 Seed dữ liệu thành công!');
}


main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
