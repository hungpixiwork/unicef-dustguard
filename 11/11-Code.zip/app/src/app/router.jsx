import React, { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import { staffRoutes } from '../apps/staff/routes.jsx';
import { citizenRoutes } from '../apps/citizen/routes.jsx';
import { contractorRoutes } from '../apps/contractor/routes.jsx';
import { adminRoutes } from '../apps/admin/routes.jsx';
import { communityRoutes } from '../apps/community/routes.jsx';
import { executiveRoutes } from '../apps/executive/routes.jsx';
import { publicRoutes } from '../apps/public/routes.jsx';

// Document Studio & LegalTech Pages
const DocumentsListPage = lazy(() => import('../modules/documents/DocumentsListPage'));
const TemplatesGalleryPage = lazy(() => import('../modules/documents/TemplatesGalleryPage'));
const DocumentEditorPage = lazy(() => import('../modules/documents/DocumentEditorPage'));
const DocumentPreviewPage = lazy(() => import('../modules/documents/DocumentPreviewPage'));
const PolicyIntelligencePage = lazy(() => import('../components/PolicyIntelligence/PolicyIntelligencePage'));

const PageLoader = () => (
  <div className="flex h-screen w-full items-center justify-center bg-[#FDFBF7]" aria-live="polite" role="status">
    <div className="h-10 w-10 animate-spin rounded-full border-4 border-seal-200 border-t-seal-600" aria-hidden="true"></div>
    <span className="sr-only">Đang tải trang...</span>
  </div>
);

export function AppRouter() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* 1. Citizen Flow */}
        {citizenRoutes}

        {/* 2. Staff Flow (Core Operations) */}
        {staffRoutes}

        {/* 3. Contractor Flow */}
        {contractorRoutes}

        {/* 4. Admin Flow */}
        {adminRoutes}

        {/* 5. Community Flow (Mạng lưới Quan sát Cộng đồng) */}
        {communityRoutes}

        {/* 6. Executive Command Center Flow */}
        {executiveRoutes}

        {/* 7. Document Studio & Decree 30/2020 Form Flow */}
        <Route path="/documents" element={<DocumentsListPage />} />
        <Route path="/documents/templates" element={<TemplatesGalleryPage />} />
        <Route path="/templates" element={<TemplatesGalleryPage />} />
        <Route path="/documents/new" element={<DocumentEditorPage />} />
        <Route path="/documents/:id/edit" element={<DocumentEditorPage />} />
        <Route path="/documents/editor/:id" element={<DocumentEditorPage />} />
        <Route path="/documents/:id/preview" element={<DocumentPreviewPage />} />
        <Route path="/documents/preview/:id" element={<DocumentPreviewPage />} />

        {/* 8. Policy Intelligence & Environmental Legal DB */}
        <Route path="/policy" element={<PolicyIntelligencePage />} />
        <Route path="/policy/intelligence" element={<PolicyIntelligencePage />} />

        {/* Legacy redirects */}
        <Route path="/app/*" element={<Navigate to="/staff" replace />} />

        {/* 8. Public & Auth Flow */}
        {publicRoutes}
      </Routes>
    </Suspense>
  );
}
