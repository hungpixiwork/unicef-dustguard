/**
 * DustGuard VN - Centralized Permissions & Role Helpers (SSOT)
 * 5 Standard Roles: 'public' | 'citizen' | 'staff' | 'contractor' | 'admin'
 */

export const ROLES = {
  PUBLIC: 'public',
  CITIZEN: 'citizen',
  STAFF: 'staff',
  CONTRACTOR: 'contractor',
  ADMIN: 'admin',
};

/**
 * Normalizes any legacy or external role string to one of the 5 canonical roles
 * @param {string} role 
 * @returns {'public' | 'citizen' | 'staff' | 'contractor' | 'admin'}
 */
export function normalizeRole(role) {
  if (!role) return ROLES.PUBLIC;
  const clean = String(role).toLowerCase().trim();

  // Citizen & Youth mappings
  if (['citizen', 'community', 'youth_member', 'volunteer', 'clb', 'student'].includes(clean)) {
    return ROLES.CITIZEN;
  }

  // Staff & Inspector & Executive mappings
  if (['staff', 'inspector', 'executive', 'officer'].includes(clean)) {
    return ROLES.STAFF;
  }

  // Contractor mapping
  if (['contractor', 'builder', 'site_manager'].includes(clean)) {
    return ROLES.CONTRACTOR;
  }

  // Admin mapping
  if (['admin', 'demo_admin', 'super_admin', 'system_admin'].includes(clean)) {
    return ROLES.ADMIN;
  }

  return ROLES.PUBLIC;
}

/**
 * Centralized Permission Evaluation Helpers
 */
export const permissions = {
  // Cases
  canViewCase: (user, caseItem) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    if (role === ROLES.ADMIN || role === ROLES.STAFF) return true;
    if (role === ROLES.CITIZEN) return caseItem?.reporterId === user.id || caseItem?.createdBy === user.id;
    if (role === ROLES.CONTRACTOR) return caseItem?.contractorId === user.id || caseItem?.contractorName === user.organization;
    return false;
  },

  canCreateCase: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.CITIZEN, ROLES.STAFF, ROLES.ADMIN].includes(role);
  },

  canAssignCase: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.STAFF, ROLES.ADMIN].includes(role);
  },

  canResolveCase: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.STAFF, ROLES.ADMIN].includes(role);
  },

  // Tasks
  canManageTasks: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.STAFF, ROLES.ADMIN].includes(role);
  },

  canSubmitTaskEvidence: (user, task) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    if (role === ROLES.ADMIN || role === ROLES.STAFF) return true;
    if (role === ROLES.CONTRACTOR) return task?.assigneeId === user.id || task?.contractorId === user.id;
    return false;
  },

  // Admin & System
  canManageUsers: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return role === ROLES.ADMIN;
  },

  canManageSites: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.STAFF, ROLES.ADMIN].includes(role);
  },

  canViewReports: (user) => {
    if (!user) return false;
    const role = normalizeRole(user.role);
    return [ROLES.STAFF, ROLES.ADMIN, ROLES.CONTRACTOR].includes(role);
  }
};

/**
 * Returns default home route for a given user role
 * @param {string} role 
 * @returns {string}
 */
export function getDefaultRouteForRole(role) {
  const normalized = normalizeRole(role);
  switch (normalized) {
    case ROLES.STAFF:
      return '/staff';
    case ROLES.CONTRACTOR:
      return '/contractor';
    case ROLES.ADMIN:
      return '/admin';
    case ROLES.CITIZEN:
      return '/citizen';
    case ROLES.PUBLIC:
    default:
      return '/';
  }
}
