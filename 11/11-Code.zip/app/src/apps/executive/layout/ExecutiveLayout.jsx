import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { BrandLogo } from '../../../shared/components/BrandLogo';

export default function ExecutiveLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // 5 Core Navigation Items for Executive Command Center
  const navItems = [
    { to: '/executive', end: true, label: 'Tổng quan điều hành' },
    { to: '/executive/cases', label: 'Hồ sơ trọng điểm' },
    { to: '/executive/approvals', label: 'Phê duyệt & Ký số' },
    { to: '/executive/heatmap', label: 'Bản đồ điểm nóng' },
    { to: '/executive/reports', label: 'Báo cáo điều hành' },
  ];

  const displayName = user?.fullName || user?.full_name || user?.name || 'Lãnh đạo Ban Giám đốc';
  const userInitials = displayName.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'LĐ';

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#1C1917] flex flex-col antialiased">
      {/* Top Header */}
      <header className="bg-white border-b border-[#E7E5E4] sticky top-0 z-30 h-16 flex items-center justify-between px-4 sm:px-6 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden px-3 py-2 rounded-xl border border-[#E7E5E4] bg-[#F5F5F4] text-[#1C1917] hover:bg-[#FEF2F2] hover:text-[#991B1B] min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer font-bold text-xs transition"
            aria-label="Mở menu điều hành"
          >
            {mobileMenuOpen ? '✕ Đóng' : '☰ Menu'}
          </button>

          <div className="flex items-center gap-2">
            <BrandLogo to="/executive" variant="compact" size="md" />
            <span className="hidden sm:inline-block px-2.5 py-1 rounded-md text-[11px] font-black uppercase tracking-wider bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]">
              Lãnh Đạo
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-[#1C1917] truncate max-w-[200px]">{displayName}</span>
            <span className="text-[11px] text-[#0d6f64] font-bold">Ban Giám đốc Sở TN&MT / UBND TP</span>
          </div>

          <div className="w-8 h-8 rounded-full bg-[#FEF2F2] text-[#B91C1C] flex items-center justify-center font-black text-xs shrink-0 border border-[#FECACA]">
            {userInitials}
          </div>

          <button
            type="button"
            onClick={() => {
              if (logout) logout();
              navigate('/login');
            }}
            className="px-3.5 py-2 text-xs font-bold text-[#57534E] hover:text-[#B91C1C] bg-[#FAFAF9] hover:bg-[#FEF2F2] border border-[#E7E5E4] hover:border-[#FECACA] rounded-xl transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
          >
            <span>Đăng xuất</span>
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-[#1C1917]/40 flex flex-col pt-16">
          <div className="bg-white border-b border-[#E7E5E4] p-4 shadow-xl flex flex-col gap-2 max-h-[calc(100vh-4rem)] overflow-y-auto">
            <div className="text-[11px] font-extrabold text-[#78716C] uppercase tracking-wider px-3 py-1">
              Trung Tâm Chỉ Đạo & Điều Hành
            </div>
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition min-h-[44px] ${
                    isActive
                      ? 'bg-[#B91C1C] text-white shadow-xs'
                      : 'text-[#1C1917] bg-[#F5F5F4] hover:bg-[#FEF2F2] hover:text-[#991B1B]'
                  }`
                }
              >
                <span>{item.label}</span>
              </NavLink>
            ))}

            <div className="pt-3 mt-2 border-t border-[#E7E5E4] flex flex-col gap-1 px-3 text-xs text-[#78716C]">
              <div className="font-bold text-[#1C1917]">{displayName}</div>
              <div>Căn cứ Nghị định 30/2020/NĐ-CP & QCVN 05:2023</div>
            </div>
          </div>
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Desktop */}
        <aside className="hidden lg:flex w-56 xl:w-60 bg-white border-r border-[#E7E5E4] flex-col p-4 gap-2 shrink-0">
          <div className="text-[11px] font-extrabold text-[#78716C] uppercase tracking-wider px-3 mb-1">
            Trung Tâm Chỉ Đạo
          </div>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-3 rounded-xl font-bold text-xs transition min-h-[44px] ${
                  isActive
                    ? 'bg-[#B91C1C] text-white shadow-xs'
                    : 'text-[#57534E] hover:bg-[#FEF2F2] hover:text-[#991B1B]'
                }`
              }
            >
              <span>{item.label}</span>
            </NavLink>
          ))}

          <div className="mt-auto pt-4 border-t border-[#E7E5E4] text-[11px] text-[#78716C] px-3 space-y-0.5">
            <div className="font-bold text-[#1C1917]">Cổng Chỉ Đạo Cấp Sở</div>
            <div>Ký số xác thực SHA-256</div>
            <div>Giám sát chỉ số ô nhiễm D1</div>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
