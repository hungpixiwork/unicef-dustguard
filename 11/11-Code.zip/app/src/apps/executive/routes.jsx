import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const ExecutiveLayout = lazy(() => import('./layout/ExecutiveLayout'));
const ExecutiveDashboardPage = lazy(() => import('../../modules/executive/ExecutiveDashboardPage'));
const ExecutiveApprovals = lazy(() => import('../../modules/executive/ExecutiveApprovals'));
const ExecutiveReports = lazy(() => import('../../modules/executive/ExecutiveReports'));
const ExecutiveHeatmap = lazy(() => import('../../modules/executive/ExecutiveHeatmap'));
const ExecutiveCases = lazy(() => import('../../modules/executive/ExecutiveCases'));

export const executiveRoutes = (
  <Route path="/executive" element={<ExecutiveLayout />}>
    <Route index element={<ExecutiveDashboardPage />} />
    <Route path="dashboard" element={<Navigate to="/executive" replace />} />
    <Route path="approvals" element={<ExecutiveApprovals />} />
    <Route path="reports" element={<ExecutiveReports />} />
    <Route path="heatmap" element={<ExecutiveHeatmap />} />
    <Route path="cases" element={<ExecutiveCases />} />
    <Route path="map" element={<Navigate to="/executive/heatmap" replace />} />
  </Route>
);
