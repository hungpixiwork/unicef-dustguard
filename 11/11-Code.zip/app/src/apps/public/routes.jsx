import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const LandingPage = lazy(() => import('../../modules/public/LandingPage'));
const CitizenMap = lazy(() => import('../../modules/citizen/CitizenMap'));
const SensorGuide = lazy(() => import('../../modules/public/SensorGuide'));
const DemoHub = lazy(() => import('../../modules/public/DemoHub'));
const IoTDemo = lazy(() => import('../../modules/public/IoTDemo'));
const SamsungCoverScreen = lazy(() => import('../../modules/iot/SamsungCoverScreen'));
const IoTDashboard = lazy(() => import('../../modules/iot/IoTDashboard'));
const YouthCredits = lazy(() => import('../../modules/youth/YouthCredits'));
const YouthCertificate = lazy(() => import('../../modules/youth/YouthCertificate'));
const Login = lazy(() => import('../../modules/auth/Login'));
const NotFound = lazy(() => import('../../modules/public/NotFound'));

export const publicRoutes = (
  <>
    <Route path="/" element={<LandingPage />} />
    <Route path="/sic" element={<SamsungCoverScreen />} />
    <Route path="/iot" element={<IoTDashboard />} />
    <Route path="/landing" element={<Navigate to="/" replace />} />
    <Route path="/demo" element={<DemoHub />} />
    <Route path="/demo/iot" element={<IoTDemo />} />
    <Route path="/demo/accounts" element={<Navigate to="/demo" replace />} />
    <Route path="/youth" element={<YouthCredits />} />
    <Route path="/youth/credits" element={<YouthCredits />} />
    <Route path="/youth/leaderboard" element={<YouthCredits />} />
    <Route path="/certificate" element={<YouthCertificate />} />
    <Route path="/certificate/:id" element={<YouthCertificate />} />
    <Route path="/verify-cert/:id" element={<YouthCertificate />} />
    <Route path="/track/:id" element={<Navigate to="/citizen/reports" replace />} />
    <Route path="/map" element={<CitizenMap />} />
    <Route path="/guide" element={<SensorGuide />} />
    <Route path="/docs/sensor-guide" element={<Navigate to="/guide" replace />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Login />} />
    <Route path="*" element={<NotFound />} />
  </>
);
