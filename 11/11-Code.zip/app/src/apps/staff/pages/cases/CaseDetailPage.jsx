import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import SafeImage from '../../../../shared/components/SafeImage.jsx';
import { NeedsAttentionReasons } from '../../../../shared/components/NeedsAttentionReasons.jsx';
import { NextActionPanel } from '../../../../shared/components/NextActionPanel.jsx';

// 10 Tiêu chí kiểm soát phát tán bụi công trình theo QCVN 18:2021/BXD & QĐ 48/2021/QĐ-UBND
const DEFAULT_QCVN_CHECKLIST = [
  { id: 'qcvn-1', code: 'TC-01', title: '1. Hàng rào & Lưới che chắn bụi', standard: 'QCVN 18:2021/BXD', desc: 'Hàng rào cứng cao tối thiểu 2.5m, lưới bao che kín toàn bộ mặt ngoài tiếp giáp khu dân cư và trục đường giao thông.', status: 'Chưa đạt', notes: 'Lưới chắn bụi rách 30% diện tích mặt tiền tiếp giáp đường chính.' },
  { id: 'qcvn-2', code: 'TC-02', title: '2. Cầu rửa xe áp lực cao & Hố lắng', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Bố trí cầu rửa xe xịt rửa gầm/bánh xe áp lực cao và hố lắng gom bùn trước khi xe vận tải ra khỏi cổng.', status: 'Chưa đạt', notes: 'Chưa bố trí cầu rửa xe áp lực cao, nước rửa chảy tràn ra vỉa hè.' },
  { id: 'qcvn-3', code: 'TC-03', title: '3. Phun sương dập bụi tự động', standard: 'QCVN 05:2023/BTNMT', desc: 'Lắp đặt giàn phun sương tự động dọc chu vi hàng rào hoặc xe bồn tưới nước dập bụi định kỳ tối thiểu 3 lần/ngày.', status: 'Cần cải thiện', notes: 'Hệ thống phun sương hoạt động ngắt quãng vào giờ cao điểm.' },
  { id: 'qcvn-4', code: 'TC-04', title: '4. Che phủ bãi tập kết vật liệu rời', standard: 'QCVN 18:2021/BXD', desc: 'Bãi cát, đá, xi măng, xỉ than, đất đào tập kết trong khuôn viên phải được phủ bạt kín 100% chống phát tán.', status: 'Đạt', notes: 'Bãi cát đá đã phủ bạt bọc kín chống gió cuốn.' },
  { id: 'qcvn-5', code: 'TC-05', title: '5. Phủ bạt kín thùng xe chuyên chở', standard: 'Nghị định 45/2022/NĐ-CP', desc: 'Xe vận chuyển vật liệu xây dựng, đất phế thải phải có bạt che phủ kín thùng, không cơi nới, không chở quá tải.', status: 'Cần cải thiện', notes: 'Vẫn còn hiện tượng đất rơi vãi tại cổng số 2.' },
  { id: 'qcvn-6', code: 'TC-06', title: '6. Vệ sinh mặt đường tiếp giáp (≤50m)', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Nhà thầu phải bố trí công nhân quét dọn, rửa sạch mặt đường giao thông công cộng tiếp giáp cổng công trình.', status: 'Chưa đạt', notes: 'Bùn đất bám dày 2cm trên mặt đường dài 40m.' },
  { id: 'qcvn-7', code: 'TC-07', title: '7. Trạm quan trắc bụi PM2.5/PM10', standard: 'QCVN 05:2023/BTNMT', desc: 'Lắp đặt cảm biến quan trắc tự động kết nối truyền dữ liệu về hệ thống giám sát môi trường đô thị.', status: 'Đạt', notes: 'Trạm cảm biến DustGuard Station 01 đang truyền dữ liệu ổn định.' },
  { id: 'qcvn-8', code: 'TC-08', title: '8. Quản lý và đổ thải phế thải xây dựng', standard: 'Nghị định 08/2022/NĐ-CP', desc: 'Thu gom, phân loại phế thải tại nguồn, có hợp đồng vận chuyển và đổ thải tại bãi chôn lấp hợp pháp.', status: 'Đạt', notes: 'Có hợp đồng vận chuyển phế thải với Công ty Môi trường Đô thị.' },
  { id: 'qcvn-9', code: 'TC-09', title: '9. Giờ thi công hạn chế bụi/tiếng ồn', standard: 'QCVN 26:2010/BTNMT', desc: 'Không thực hiện các công đoạn phát tán bụi lớn vào giờ cao điểm giao thông (6h-8h, 17h-19h) và ban đêm (22h-6h).', status: 'Đạt', notes: 'Nhà thầu tuân thủ giờ vận chuyển đất ban đêm theo giấy phép.' },
  { id: 'qcvn-10', code: 'TC-10', title: '10. Biển báo & Đường dây nóng phản ánh', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Niêm yết công khai biển báo thông tin dự án, số điện thoại chỉ huy trưởng và đường dây nóng tiếp nhận phản ánh.', status: 'Đạt', notes: 'Đã gắn biển thông tin và mã QR tiếp nhận phản ánh công dân.' }
];

// 7 Bước tác nghiệp DAG chuẩn
const WORKFLOW_STEPS = [
  { step: 1, key: 'RECORDED', label: '1. Tiếp nhận', desc: 'Ghi nhận phản ánh & cảm biến' },
  { step: 2, key: 'VERIFIED', label: '2. Xác minh', desc: 'Kiểm tra tọa độ & hình ảnh' },
  { step: 3, key: 'NOTICE_SENT', label: '3. Thông báo', desc: 'Gửi yêu cầu tới nhà thầu' },
  { step: 4, key: 'INSPECTION', label: '4. Khảo sát', desc: 'Đoàn thanh tra kiểm tra thực địa' },
  { step: 5, key: 'ACTION_PROPOSED', label: '5. Đề xuất', desc: 'Lập phương án khắc phục & xử lý' },
  { step: 6, key: 'REMEDIATION', label: '6. Thẩm định', desc: 'Đối chứng Before/After nghiệm thu' },
  { step: 7, key: 'COMPLETED', label: '7. Hoàn tất', desc: 'Đóng hồ sơ & lưu trữ pháp lý' }
];

// Preset photos for quick 1-click testing & field simulation
const SAMPLE_PRESET_PHOTOS = [
  { label: 'Xe tải không che bạt', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=600' },
  { label: 'Bụi mù mịt cổng chính', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600' },
  { label: 'Chưa có cầu rửa xe', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600' },
  { label: 'Đã lắp cầu rửa xe áp lực', type: 'AFTER', url: 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?w=600' },
  { label: 'Đã phủ bạt che cát đá', type: 'AFTER', url: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600' },
  { label: 'Đã tưới nước dập bụi', type: 'AFTER', url: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=600' }
];

export default function CaseDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [caseData, setCaseData] = useState(null);
  const [officers, setOfficers] = useState([]);
  const [activeTab, setActiveTab] = useState('INFO'); // INFO | PHOTOS | TIMELINE | SURVEY | REMEDIATION | DOSSIER
  
  // Assign Modal States
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [assignedOfficer, setAssignedOfficer] = useState('');
  const [assignDueDate, setAssignDueDate] = useState(() => {
    const d = new Date(Date.now() + 48 * 3600 * 1000);
    return d.toISOString().split('T')[0];
  });
  const [assignNotes, setAssignNotes] = useState('Yêu cầu kiểm tra thực địa trong vòng 24 giờ theo quy trình SLA.');
  
  // Upload Evidence Modal States
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadPhotoType, setUploadPhotoType] = useState('BEFORE');
  const [uploadUrl, setUploadUrl] = useState('');
  const [uploadCaption, setUploadCaption] = useState('Ghi nhận hiện trạng phát tán bụi tại cổng công trình');
  const [uploadPreview, setUploadPreview] = useState('');
  const [uploadFileObj, setUploadFileObj] = useState(null);
  
  // Complete Case Modal States
  const [completeModalOpen, setCompleteModalOpen] = useState(false);
  const [completeNotes, setCompleteNotes] = useState('Đã nghiệm thu hiện trường đạt chuẩn môi trường theo QCVN 18:2021/BXD.');
  
  // Other States
  const [actionLoading, setActionLoading] = useState(false);
  const [checklistItems, setChecklistItems] = useState(DEFAULT_QCVN_CHECKLIST);
  const [printPreviewOpen, setPrintPreviewOpen] = useState(false);
  const [photoZoom, setPhotoZoom] = useState({ open: false, url: '', title: '', hash: '' });
  const [successToast, setSuccessToast] = useState(null);

  const showToast = (msg) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  const fetchOfficers = useCallback(async () => {
    try {
      const res = await request('/staff/officers');
      if (res?.data?.items && res.data.items.length > 0) {
        setOfficers(res.data.items);
        if (!assignedOfficer) {
          setAssignedOfficer(res.data.items[0].fullName || res.data.items[0].email);
        }
      }
    } catch {}
  }, [assignedOfficer]);

  const fetchDetail = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request(`/staff/cases/${id || 'case-01'}/detail`);
      if (res?.data) {
        setCaseData(res.data);
      }
    } catch (err) {
      setError(err.message || 'Không thể tải chi tiết hồ sơ từ CSDL D1');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchDetail();
    fetchOfficers();
  }, [fetchDetail, fetchOfficers]);

  // Khóa cuộn màn hình và bắt phím Escape đóng modal
  useEffect(() => {
    const isAnyModalOpen = assignModalOpen || uploadModalOpen || completeModalOpen || printPreviewOpen || photoZoom.open;
    if (!isAnyModalOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        setAssignModalOpen(false);
        setUploadModalOpen(false);
        setUploadPreview('');
        setCompleteModalOpen(false);
        setPrintPreviewOpen(false);
        setPhotoZoom({ open: false, url: '', title: '', hash: '' });
      }
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [assignModalOpen, uploadModalOpen, completeModalOpen, printPreviewOpen, photoZoom.open]);

  const handleAssignSubmit = async (e) => {
    e.preventDefault();
    try {
      setActionLoading(true);
      await request(`/staff/cases/${caseData.id}/assign`, {
        method: 'POST',
        body: JSON.stringify({
          assignedTo: assignedOfficer,
          dueDate: assignDueDate,
          notes: assignNotes
        })
      });
      setAssignModalOpen(false);
      await fetchDetail();
      showToast('✓ Đã phân công cán bộ xử lý hồ sơ thành công vào CSDL D1!');
    } catch (err) {
      alert('Lỗi phân công: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSetQuickSla = (hours, label) => {
    const d = new Date(Date.now() + hours * 3600 * 1000);
    setAssignDueDate(d.toISOString().split('T')[0]);
    setAssignNotes(`Yêu cầu xử lý theo thời hạn SLA ${label}.`);
  };

  const handleCompleteCaseSubmit = async (e) => {
    e?.preventDefault();
    try {
      setActionLoading(true);
      await request(`/staff/cases/${caseData.id}/complete`, {
        method: 'POST',
        body: JSON.stringify({ notes: completeNotes })
      });
      setCompleteModalOpen(false);
      await fetchDetail();
      showToast('✓ Đã duyệt hoàn tất và đóng hồ sơ thành công!');
    } catch (err) {
      alert('Lỗi đóng hồ sơ: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Handle File Input from Device / Camera
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadFileObj(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result;
        setUploadPreview(base64);
        setUploadUrl(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPresetPhoto = (preset) => {
    setUploadUrl(preset.url);
    setUploadPreview(preset.url);
    setUploadPhotoType(preset.type);
    setUploadCaption(preset.label);
  };

  const handleUploadEvidenceSubmit = async (e) => {
    e.preventDefault();
    const finalUrl = uploadPreview || uploadUrl.trim();
    if (!finalUrl) {
      alert('Vui lòng chọn tệp ảnh từ máy hoặc bấm chọn một ảnh mẫu.');
      return;
    }
    try {
      setActionLoading(true);
      await request(`/staff/cases/${caseData.id}/evidences`, {
        method: 'POST',
        body: JSON.stringify({
          url: finalUrl,
          photoType: uploadPhotoType,
          phase: uploadPhotoType,
          caption: uploadCaption
        })
      });
      setUploadModalOpen(false);
      setUploadUrl('');
      setUploadPreview('');
      setUploadFileObj(null);
      await fetchDetail();
      showToast('✓ Đã tải lên và lưu trữ ảnh minh chứng thành công!');
    } catch (err) {
      alert('Lỗi tải ảnh: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleInspectionSave = async () => {
    try {
      setActionLoading(true);
      const passedCount = checklistItems.filter(i => i.status === 'Đạt').length;
      const findings = `Đoàn kiểm tra ghi nhận ${passedCount}/10 tiêu chí đạt chuẩn QCVN 18:2021/BXD.`;
      await request(`/staff/cases/${caseData.id}/inspection`, {
        method: 'POST',
        body: JSON.stringify({
          findings,
          recommendations: 'Yêu cầu nhà thầu khắc phục các tiêu chí Chưa đạt trong vòng 48 giờ.',
          scoreDelta: passedCount >= 8 ? 0 : -15
        })
      });
      await fetchDetail();
      showToast(`✓ Đã lưu biên bản khảo sát (${passedCount}/10 đạt chuẩn) và chuyển bước hồ sơ!`);
    } catch (err) {
      alert('Lỗi lưu biên bản khảo sát: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleChecklistStatus = (itemId, newStatus) => {
    setChecklistItems(prev => prev.map(item => item.id === itemId ? { ...item, status: newStatus } : item));
  };

  const handleQuickAllPass = () => {
    setChecklistItems(prev => prev.map(item => ({ ...item, status: 'Đạt' })));
    showToast('✓ Đã đánh dấu tất cả 10 tiêu chí Đạt chuẩn!');
  };

  const handleExportPdf = () => {
    window.print();
  };

  if (loading) return <LoadingState message="Đang nạp chi tiết hồ sơ vụ việc từ CSDL D1/SQLite..." />;
  if (error) {
    return (
      <div className="bg-white border border-[#E7E5E4] rounded-3xl p-8 max-w-lg mx-auto text-center space-y-4 my-8 shadow-2xs">
        <div className="w-12 h-12 bg-[#FEF2F2] text-[#B91C1C] rounded-full flex items-center justify-center mx-auto text-xl font-bold">
          ⚠️
        </div>
        <div>
          <h2 className="text-lg font-black text-[#1C1917]">Lỗi tải hồ sơ</h2>
          <p className="text-xs text-[#78716C] mt-1">{error}</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
          <button
            onClick={fetchDetail}
            className="w-full sm:w-auto px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs min-h-[44px] cursor-pointer"
          >
            Thử lại
          </button>
          <Link
            to="/staff/cases"
            className="w-full sm:w-auto px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs min-h-[44px] flex items-center justify-center"
          >
            Quay lại danh sách hồ sơ
          </Link>
          <Link
            to="/staff/cases/case-01"
            className="w-full sm:w-auto px-4 py-2.5 bg-[#F0FDF4] border border-[#DCFCE7] hover:bg-[#DCFCE7] text-[#16A34A] font-bold text-xs rounded-xl min-h-[44px] flex items-center justify-center"
          >
            Mở hồ sơ HS-25-00081
          </Link>
        </div>
      </div>
    );
  }
  if (!caseData) return null;

  const beforePhotos = Array.isArray(caseData?.evidencePhotos?.before)
    ? caseData.evidencePhotos.before
    : (Array.isArray(caseData?.beforePhotos) ? caseData.beforePhotos : ['/images/dust-before-01.jpg', '/images/dust-before-02.jpg']);
  const afterPhotos = Array.isArray(caseData?.evidencePhotos?.after)
    ? caseData.evidencePhotos.after
    : (Array.isArray(caseData?.afterPhotos) ? caseData.afterPhotos : ['/images/dust-after-01.jpg', '/images/dust-after-02.jpg']);

  // Xác định bước hiện tại trong 7 bước
  const currentStepNum = caseData.status === 'Đã đóng' ? 7 : caseData.currentStepNumber || (caseData.currentStep?.includes('Khảo sát') ? 4 : caseData.currentStep?.includes('nhà thầu') ? 5 : 3);

  return (
    <div className="space-y-5">
      
      {/* 1. Header & Top Action Bar (Mockup 7) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="text-xs font-semibold text-[#78716C]">
            <Link to="/staff" className="hover:text-[#B91C1C]">Trang chính</Link> / <Link to="/staff/cases" className="hover:text-[#B91C1C]">Hồ sơ</Link> / {caseData.code}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight mt-0.5">
            Hồ sơ vụ việc
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Theo dõi thông tin, bằng chứng, khảo sát và khắc phục theo quy trình 7 bước.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setAssignModalOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>👤</span>
            <span>Phân công</span>
          </button>

          <button
            onClick={() => setPrintPreviewOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>🖨️</span>
            <span>In biên bản A4</span>
          </button>

          <button
            onClick={handleExportPdf}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>📄</span>
            <span>Xuất PDF</span>
          </button>

          <button
            onClick={() => setUploadModalOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>📷</span>
            <span>Thêm ảnh &gt;</span>
          </button>

          <button
            onClick={() => setCompleteModalOpen(true)}
            disabled={actionLoading || caseData.status === 'Đã đóng'}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-[#16A34A] hover:bg-[#15803D] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer disabled:opacity-50"
          >
            <span>✓</span>
            <span>{caseData.status === 'Đã đóng' ? 'Đã hoàn tất' : 'Duyệt đóng'}</span>
          </button>
        </div>
      </div>

      {/* Floating Success Toast */}
      {successToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#15803D] text-white px-5 py-3 rounded-2xl shadow-xl font-bold text-xs flex items-center gap-2 animate-bounce">
          <span>✨</span>
          <span>{successToast}</span>
        </div>
      )}

      {/* 2. Metadata Bar (Mockup 7) */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 text-xs">
          
          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Mã hồ sơ</div>
            <div className="font-black text-sm text-[#1C1917] mt-0.5">{caseData.code}</div>
            <div className="text-[9px] text-[#78716C] mt-0.5">Dữ liệu D1 SQLite</div>
          </div>

          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Trạng thái</div>
            <span className={`inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-black uppercase ${
              caseData.status === 'Đã đóng' ? 'bg-[#F0FDF4] text-[#16A34A]' : 'bg-[#FFF7ED] text-[#EA580C]'
            }`}>
              {caseData.status}
            </span>
          </div>

          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Mức ưu tiên</div>
            <div className="font-bold text-xs text-[#B91C1C] mt-0.5">{caseData.priority}</div>
            <div className="text-[9px] text-[#78716C] mt-0.5">Điểm: {caseData.dustRiskScore || 75} / 100</div>
          </div>

          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Hạn xử lý</div>
            <div className="font-bold text-xs text-[#B91C1C] mt-0.5">📅 {caseData.deadline}</div>
            <div className="text-[9px] text-[#B91C1C] mt-0.5">SLA Quy định 48h</div>
          </div>

          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Cán bộ phụ trách</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-5 h-5 rounded-full bg-[#B91C1C] text-white text-[9px] font-black flex items-center justify-center shrink-0">
                {caseData.assigneeInitials || 'TL'}
              </span>
              <span className="font-bold text-xs text-[#1C1917] truncate">{caseData.assigneeName}</span>
            </div>
          </div>

          <div>
            <div className="text-[10px] text-[#78716C] font-semibold">Việc cần làm tiếp</div>
            <div className="font-bold text-[11px] text-[#1C1917] mt-0.5 leading-snug break-words">
              {caseData.nextAction || 'Khảo sát thực địa và lập biên bản'}
            </div>
            <button onClick={() => setActiveTab('INFO')} className="text-[9px] font-bold text-[#B91C1C] hover:underline mt-0.5">
              Xem chi tiết ➔
            </button>
          </div>

        </div>
      </div>

      {/* 3. Tiến trình xử lý vụ việc trực quan */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs">
        <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#B91C1C]" />
            <span className="font-black text-xs sm:text-sm text-[#1C1917] uppercase tracking-wider">Tiến trình xử lý vụ việc</span>
          </div>
          <span className="text-[11px] font-bold text-[#0D9488] bg-[#F0FDFA] border border-[#CCFBF1] px-2.5 py-0.5 rounded-full">
            Bước hiện tại: {currentStepNum}/7
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 pt-4">
          {WORKFLOW_STEPS.map((step) => {
            const isCompleted = step.step < currentStepNum;
            const isCurrent = step.step === currentStepNum;
            return (
              <div
                key={step.step}
                className={`p-2.5 rounded-xl border flex flex-col justify-between min-h-[72px] transition ${
                  isCurrent
                    ? 'bg-[#FEF2F2] border-[#B91C1C] text-[#B91C1C] shadow-2xs ring-1 ring-[#B91C1C]'
                    : isCompleted
                    ? 'bg-[#F0FDF4] border-[#DCFCE7] text-[#16A34A]'
                    : 'bg-[#FAFAF9] border-[#E7E5E4] text-[#78716C] opacity-75'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`w-5 h-5 rounded-full text-[10px] font-black flex items-center justify-center shrink-0 ${
                    isCurrent ? 'bg-[#B91C1C] text-white' : isCompleted ? 'bg-[#16A34A] text-white' : 'bg-[#E7E5E4] text-[#57534E]'
                  }`}>
                    {isCompleted ? '✓' : step.step}
                  </span>
                  <span className="text-[9px] font-bold uppercase tracking-wider">
                    {isCurrent ? 'Đang thực hiện' : isCompleted ? 'Hoàn thành' : 'Chờ xử lý'}
                  </span>
                </div>
                <div className="mt-1">
                  <div className="font-black text-xs leading-tight">{step.label}</div>
                  <div className="text-[9px] mt-0.5 opacity-80 leading-snug line-clamp-1">{step.desc}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. 6 Tabs Navigation + AI Suggestion Badge (Mockup 7) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-[#E7E5E4] pb-2">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          {[
            { id: 'INFO', label: 'Thông tin' },
            { id: 'PHOTOS', label: 'Ảnh' },
            { id: 'TIMELINE', label: 'Theo dõi' },
            { id: 'SURVEY', label: 'Khảo sát' },
            { id: 'REMEDIATION', label: 'Khắc phục' },
            { id: 'DOSSIER', label: 'Hồ sơ' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 text-xs font-bold transition whitespace-nowrap cursor-pointer min-h-[44px] flex items-center justify-center ${
                activeTab === tab.id
                  ? 'text-[#B91C1C] border-b-2 border-[#B91C1C] pb-1 font-black bg-[#FEF2F2] rounded-t-xl'
                  : 'text-[#78716C] hover:text-[#1C1917] hover:bg-[#FAFAF9] rounded-t-xl'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#0D6F64] bg-[#F0FDFA] border border-[#CCFBF1] px-3 py-1.5 rounded-full" title="Hệ thống hỗ trợ tổng hợp dữ kiện và đối chiếu quy định. Cán bộ thẩm tra phê duyệt.">
          <span>🛡️</span>
          <span>Hỗ trợ thẩm tra hồ sơ • Cán bộ phê duyệt</span>
        </div>
      </div>

      {/* 5. Tab 1: Thông tin chi tiết */}
      {activeTab === 'INFO' && (
        <div className="space-y-5">
          {/* Top Row: Lý do cần chú ý & Việc cần làm tiếp theo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <NeedsAttentionReasons 
              priority={caseData.priority || 'HIGH'}
              pm25Value={caseData.pm25 || 142}
              distanceToSchool={85}
              reportCount={4}
              hasAssignee={!!caseData.assignedTo}
            />
            <NextActionPanel
              actionTitle={
                caseData.status === 'REMEDIATION_SUBMITTED' 
                  ? 'Tái kiểm thực địa & đo lại PM2.5'
                  : caseData.status === 'ASSIGNED' 
                    ? 'Khảo sát thực địa và lập biên bản 10 tiêu chí'
                    : 'Yêu cầu nhà thầu dập bụi và nộp ảnh After'
              }
              assignee={caseData.assignedTo || 'Cán bộ Thanh tra địa bàn'}
              deadline={caseData.slaDeadline ? `Hạn SLA: ${caseData.slaDeadline}` : 'Trong vòng 24 giờ'}
              isUrgent={caseData.priority === 'URGENT' || caseData.priority === 'HIGH'}
              onAction={() => setActiveTab('CHECKLIST')}
              actionButtonLabel="Mở kiểm tra hiện trường"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
            <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-2.5 text-xs">
              <div className="flex items-center justify-between pb-1.5 border-b border-[#E7E5E4]">
                <span className="font-black text-sm text-[#1C1917]">Thông tin chung</span>
              </div>
              <div>
                <span className="text-[#78716C] block text-[10px]">Công trình</span>
                <span className="font-bold text-[#1C1917] break-words">{caseData.siteName}</span>
              </div>
              <div>
                <span className="text-[#78716C] block text-[10px]">Địa chỉ</span>
                <span className="font-medium text-[#1C1917] break-words">{caseData.address}</span>
              </div>
              <div>
                <span className="text-[#78716C] block text-[10px]">Loại vi phạm</span>
                <span className="font-bold text-[#B91C1C]">{caseData.violationType || 'Phát tán bụi vượt quy chuẩn'}</span>
              </div>
              <div>
                <span className="text-[#78716C] block text-[10px]">Nguồn phát sinh</span>
                <span className="font-medium text-[#1C1917]">{caseData.emissionSource || 'Xe ra vào & bãi vật liệu'}</span>
              </div>
              <div>
                <span className="text-[#78716C] block text-[10px]">Mô tả vụ việc</span>
                <p className="text-[11px] text-[#57534E] leading-relaxed break-words">{caseData.description || 'Ghi nhận nồng độ bụi PM2.5 tăng đột biến trong các khung giờ cao điểm xe chở vật liệu ra vào không qua rửa bánh.'}</p>
              </div>
            </div>

            <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-2.5 text-xs">
              <div className="font-black text-sm text-[#1C1917] pb-1.5 border-b border-[#E7E5E4]">
                Bằng chứng cần bổ sung
              </div>
              <div className="space-y-2">
                {(caseData.missingEvidences || [
                  { id: 'ev-1', type: 'photo', title: 'Ảnh chụp trạm rửa xe cổng chính', action: 'Bổ sung' },
                  { id: 'ev-2', type: 'document', title: 'Giấy phép xả thải & vận chuyển đất', action: 'Yêu cầu nộp' },
                  { id: 'ev-3', type: 'sensor', title: 'Dữ liệu đo bụi 24h trạm DustGuard', action: 'Trích xuất' }
                ]).map(item => (
                  <div key={item.id} className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4] min-h-[50px]">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span className="text-sm shrink-0">{item.type === 'photo' ? '📷' : item.type === 'document' ? '📄' : '📊'}</span>
                      <span className="font-bold text-[11px] text-[#1C1917] leading-tight break-words">{item.title}</span>
                    </div>
                    <button
                      onClick={() => setActiveTab('PHOTOS')}
                      className="px-3 py-1.5 rounded-xl border border-[#E7E5E4] bg-white text-xs font-bold text-[#1C1917] hover:bg-[#FAFAF9] cursor-pointer shrink-0 min-h-[44px] flex items-center justify-center"
                    >
                      {item.action}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-2.5 text-xs">
              <div className="font-black text-sm text-[#1C1917] pb-1.5 border-b border-[#E7E5E4]">
                Lịch sử theo dõi
              </div>
              <div className="space-y-3 relative pl-3 border-l-2 border-[#E7E5E4] ml-1.5">
                {(caseData.timeline || [
                  { time: '08:30 02/09', actor: 'Hệ thống tự động', title: 'Cảnh báo phát tán bụi', desc: 'Ghi nhận chỉ số PM2.5 vượt ngưỡng 85 µg/m³.' },
                  { time: '09:15 02/09', actor: 'Thanh tra quận', title: 'Tiếp nhận hồ sơ', desc: 'Phân công đồng chí Lan kiểm tra hiện trường.' },
                  { time: '10:00 02/09', actor: 'Đoàn kiểm tra', title: 'Lập biên bản khảo sát', desc: 'Phát hiện trạm rửa xe không hoạt động.' }
                ]).map((t, idx) => (
                  <div key={idx} className="relative space-y-0.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#B91C1C] absolute -left-[19px] top-1 border-2 border-white" />
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-[#78716C]">{t.time}</span>
                      <span className="text-[9px] font-bold text-[#78716C] bg-[#F5F5F4] px-1 rounded">{t.actor}</span>
                    </div>
                    <div className="font-bold text-xs text-[#1C1917] break-words">{t.title}</div>
                    <div className="text-[10px] text-[#57534E] break-words">{t.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            <div className="lg:col-span-6 bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
                <span className="font-black text-xs sm:text-sm text-[#1C1917]">Danh sách việc cần làm</span>
                <button
                  onClick={() => navigate('/staff/tasks')}
                  className="px-3 py-1.5 bg-[#B91C1C] text-white rounded-xl text-xs font-bold hover:bg-[#991B1B] cursor-pointer min-h-[44px] flex items-center justify-center"
                >
                  + Thêm việc
                </button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#E7E5E4]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#FAFAF9] border-b border-[#E7E5E4] text-[#57534E] text-[11px] uppercase font-black tracking-wider">
                      <th className="py-2.5 px-3">Việc cần làm</th>
                      <th className="py-2.5 px-3 whitespace-nowrap">Hạn hoàn thành</th>
                      <th className="py-2.5 px-3 text-center whitespace-nowrap">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F5F5F4] bg-white">
                    {(caseData.todoTasks && caseData.todoTasks.length > 0) ? (
                      caseData.todoTasks.map(task => (
                        <tr key={task.id} className="hover:bg-[#FDFBF7]">
                          <td className="py-3 px-3 font-bold text-[#1C1917] break-words">{task.title}</td>
                          <td className="py-3 px-3 font-mono text-[11px] text-[#78716C] whitespace-nowrap">{task.deadline || task.dueAt || 'Trong ngày'}</td>
                          <td className="py-3 px-3 text-center whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                              task.status === 'COMPLETED' || task.status === 'Đã xong' ? 'bg-[#F0FDF4] text-[#16A34A]' : 'bg-[#FFF7ED] text-[#EA580C]'
                            }`}>
                              {task.status === 'COMPLETED' ? 'Đã xong' : task.status || 'Chưa làm'}
                            </span>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="3" className="py-4 px-3 text-center text-[#78716C] italic">
                          Chưa có việc cần làm nào được gán cho hồ sơ này.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
                <span className="font-black text-xs sm:text-sm text-[#1C1917]">Ảnh hiện trạng (Trước / Sau)</span>
                <button onClick={() => setActiveTab('PHOTOS')} className="text-xs font-bold text-[#78716C] hover:text-[#B91C1C] flex items-center gap-1 cursor-pointer min-h-[44px]">
                  <span>Xem tất cả</span> <span>➔</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <div className="font-bold text-xs text-[#B91C1C] flex items-center gap-1">
                    <span>🔴</span> <span>Trước</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {beforePhotos.slice(0, 2).map((img, i) => (
                      <SafeImage
                        key={i}
                        src={img}
                        alt="Ảnh trước khắc phục"
                        className="w-full h-24 rounded-xl object-cover border border-[#E7E5E4] cursor-pointer hover:opacity-90 transition"
                        onClick={() => setPhotoZoom({ open: true, url: img, title: `Bằng chứng trước khắc phục #${i+1}`, hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' })}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="font-bold text-xs text-[#16A34A] flex items-center gap-1">
                    <span>🟢</span> <span>Sau</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {afterPhotos.slice(0, 2).map((img, i) => (
                      <SafeImage
                        key={i}
                        src={img}
                        alt="Ảnh sau khắc phục"
                        className="w-full h-24 rounded-xl object-cover border border-[#E7E5E4] cursor-pointer hover:opacity-90 transition"
                        onClick={() => setPhotoZoom({ open: true, url: img, title: `Minh chứng sau khắc phục #${i+1}`, hash: 'a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0' })}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. Tab 2: Ảnh Bằng chứng hiện trường (Before / After) */}
      {activeTab === 'PHOTOS' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-[#E7E5E4]">
            <div>
              <h3 className="font-black text-sm sm:text-base text-[#1C1917]">Bằng chứng hiện trường (Trước / Sau)</h3>
              <p className="text-xs text-[#78716C]">Tệp được lưu trữ nguyên vẹn, đối chứng tự động khi nghiệm thu</p>
            </div>
            <button
              onClick={() => { setUploadPhotoType('BEFORE'); setUploadModalOpen(true); }}
              className="px-4 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer min-h-[44px] flex items-center justify-center gap-1.5"
            >
              <span>📷</span>
              <span>+ Tải ảnh minh chứng</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-[#B91C1C] uppercase tracking-wider flex items-center gap-1.5">
                  <span>🔴</span> Ảnh trước khắc phục ({beforePhotos.length})
                </h4>
                <button
                  onClick={() => { setUploadPhotoType('BEFORE'); setUploadModalOpen(true); }}
                  className="text-[11px] font-bold text-[#B91C1C] hover:underline"
                >
                  + Thêm ảnh Before
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {beforePhotos.map((img, i) => (
                  <div key={i} className="space-y-1.5 p-2 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4]">
                    <SafeImage
                      src={img}
                      alt="Trước khắc phục"
                      className="w-full h-36 rounded-lg object-cover border border-[#E7E5E4] cursor-pointer hover:scale-[1.02] transition"
                      onClick={() => setPhotoZoom({ open: true, url: img, title: `Bằng chứng trước khắc phục #${i+1}`, hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' })}
                    />
                    <div className="flex items-center justify-between text-[10px] text-[#78716C]">
                      <span className="font-mono font-bold">Bằng chứng #{i + 1}</span>
                      <span className="text-[#B91C1C] font-semibold">Chưa dập bụi</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-[#16A34A] uppercase tracking-wider flex items-center gap-1.5">
                  <span>🟢</span> Ảnh sau khắc phục ({afterPhotos.length})
                </h4>
                <button
                  onClick={() => { setUploadPhotoType('AFTER'); setUploadModalOpen(true); }}
                  className="text-[11px] font-bold text-[#16A34A] hover:underline"
                >
                  + Thêm ảnh After
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {afterPhotos.map((img, i) => (
                  <div key={i} className="space-y-1.5 p-2 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4]">
                    <SafeImage
                      src={img}
                      alt="Sau khắc phục"
                      className="w-full h-36 rounded-lg object-cover border border-[#E7E5E4] cursor-pointer hover:scale-[1.02] transition"
                      onClick={() => setPhotoZoom({ open: true, url: img, title: `Nghiệm thu sau khắc phục #${i+1}`, hash: 'a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0' })}
                    />
                    <div className="flex items-center justify-between text-[10px] text-[#78716C]">
                      <span className="font-mono font-bold">Nghiệm thu #{i + 1}</span>
                      <span className="text-[#16A34A] font-semibold">Đã khắc phục</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. Tab 3: Quy trình theo dõi 7 bước */}
      {activeTab === 'TIMELINE' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-2xs space-y-4">
          <div className="pb-3 border-b border-[#E7E5E4]">
            <h3 className="font-black text-sm sm:text-base text-[#1C1917]">Quy trình xử lý hồ sơ 7 bước</h3>
            <p className="text-xs text-[#78716C]">Tiếp nhận ➔ Xác minh ➔ Thông báo ➔ Khảo sát ➔ Đề xuất ➔ Thẩm định ➔ Hoàn tất</p>
          </div>

          <div className="space-y-4 pl-4 border-l-2 border-[#B91C1C] ml-2">
            {(caseData.timeline || [
              { time: '08:00 02/09', actor: 'Trạm quan trắc', title: '1. Tiếp nhận cảnh báo tự động', desc: 'Chỉ số PM2.5 vượt 85 µg/m³ tại tọa độ công trình.' },
              { time: '08:45 02/09', actor: 'Cán bộ trực ban', title: '2. Xác minh dữ liệu & Đối soát', desc: 'Xác định khớp dữ liệu camera và cảm biến đo bụi.' },
              { time: '09:30 02/09', actor: 'Hệ thống thông báo', title: '3. Gửi thông báo đến Chỉ huy trưởng', desc: 'Gửi yêu cầu kiểm soát phát tán bụi qua cổng nhà thầu.' },
              { time: '10:15 02/09', actor: 'Đoàn kiểm tra liên ngành', title: '4. Khảo sát hiện trường thực địa', desc: 'Kiểm tra 10 tiêu chí theo QCVN 18:2021/BXD.' }
            ]).map((evt, idx) => (
              <div key={idx} className="relative pl-3 space-y-1">
                <span className="w-3 h-3 rounded-full bg-[#B91C1C] absolute -left-[23px] top-1.5 border-2 border-white ring-2 ring-[#B91C1C]/30" />
                <div className="flex items-center gap-2">
                  <span className="font-black text-xs text-[#1C1917]">{evt.title}</span>
                  <span className="text-[10px] font-bold text-[#78716C] bg-[#F5F5F4] px-1.5 py-0.5 rounded">{evt.actor}</span>
                  <span className="font-mono text-[10px] text-[#A8A29E]">{evt.time}</span>
                </div>
                <p className="text-xs text-[#57534E] leading-relaxed break-words">{evt.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 8. Tab 4: Biên bản khảo sát thực địa (Checklist 10 Tiêu chuẩn QCVN 18/QĐ 48) */}
      {activeTab === 'SURVEY' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-2xs space-y-4">
          <div className="pb-3 border-b border-[#E7E5E4] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="font-black text-sm sm:text-base text-[#1C1917]">Biên bản khảo sát thực địa</h3>
              <p className="text-xs text-[#78716C]">Kiểm tra 10 tiêu chí phát tán bụi theo chuẩn thanh tra (QCVN 18:2021/BXD & QĐ 48/2021/QĐ-UBND)</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleQuickAllPass}
                className="px-3 py-2 bg-[#F0FDF4] border border-[#DCFCE7] hover:bg-[#DCFCE7] text-[#16A34A] font-bold text-xs rounded-xl min-h-[44px] cursor-pointer flex items-center gap-1"
              >
                <span>✓</span>
                <span>Đạt tất cả (10/10)</span>
              </button>
              <button
                onClick={() => setPrintPreviewOpen(true)}
                className="px-3.5 py-2 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl min-h-[44px] cursor-pointer flex items-center gap-1.5"
              >
                <span>🖨️</span>
                <span>In biên bản A4</span>
              </button>
              <button
                onClick={handleInspectionSave}
                disabled={actionLoading}
                className="px-4 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer min-h-[44px] flex items-center justify-center disabled:opacity-50"
              >
                {actionLoading ? 'Đang lưu...' : 'Lưu biên bản'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {checklistItems.map((item) => (
              <div key={item.id} className="p-4 rounded-xl border border-[#E7E5E4] bg-[#FAFAF9] space-y-2.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-black text-[#1C1917] text-xs leading-snug">{item.title}</span>
                    <span className="text-[9px] font-mono font-bold text-[#78716C] bg-white px-1.5 py-0.5 rounded border border-[#E7E5E4]">
                      {item.code}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#78716C] mt-1 leading-relaxed">{item.desc}</p>
                  {item.notes && (
                    <div className="mt-2 text-[11px] font-medium text-[#B91C1C] bg-[#FEF2F2] border border-[#FECACA] p-2 rounded-lg">
                      <strong>Hiện trạng: </strong>{item.notes}
                    </div>
                  )}
                </div>

                {/* Tùy chọn đánh giá 3 mức */}
                <div className="pt-2 border-t border-[#E7E5E4] flex items-center justify-between gap-1.5">
                  <span className="text-[10px] font-bold text-[#78716C]">Đánh giá:</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleToggleChecklistStatus(item.id, 'Đạt')}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer min-h-[36px] ${
                        item.status === 'Đạt'
                          ? 'bg-[#16A34A] text-white font-black shadow-2xs'
                          : 'bg-white border border-[#E7E5E4] text-[#16A34A] hover:bg-[#F0FDF4]'
                      }`}
                    >
                      ✓ Đạt
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleChecklistStatus(item.id, 'Cần cải thiện')}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer min-h-[36px] ${
                        item.status === 'Cần cải thiện'
                          ? 'bg-[#EA580C] text-white font-black shadow-2xs'
                          : 'bg-white border border-[#E7E5E4] text-[#EA580C] hover:bg-[#FFF7ED]'
                      }`}
                    >
                      ⚠ Cần sửa
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleChecklistStatus(item.id, 'Chưa đạt')}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer min-h-[36px] ${
                        item.status === 'Chưa đạt'
                          ? 'bg-[#B91C1C] text-white font-black shadow-2xs'
                          : 'bg-white border border-[#E7E5E4] text-[#B91C1C] hover:bg-[#FEF2F2]'
                      }`}
                    >
                      ✕ Chưa đạt
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 9. Tab 5: Biện pháp khắc phục */}
      {activeTab === 'REMEDIATION' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-2xs space-y-4">
          <div className="pb-3 border-b border-[#E7E5E4]">
            <h3 className="font-black text-sm sm:text-base text-[#1C1917]">Kế hoạch khắc phục của Nhà thầu</h3>
            <p className="text-xs text-[#78716C]">Thời hạn cam kết hoàn tất theo SLA 48 giờ kể từ khi nhận biên bản</p>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl border border-[#E7E5E4] bg-[#FAFAF9] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-black text-sm text-[#1C1917]">Biện pháp 1: Lắp đặt trạm rửa xe tự động áp lực cao</span>
                <span className="px-2 py-0.5 rounded bg-[#F0FDF4] text-[#16A34A] text-[10px] font-bold">Đã hoàn thành</span>
              </div>
              <p className="text-[#57534E] leading-relaxed">Nhà thầu đã thi công xong hố lắng 3 ngăn và vòi xịt áp lực cao tại cổng số 1.</p>
            </div>

            <div className="p-4 rounded-xl border border-[#E7E5E4] bg-[#FAFAF9] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-black text-sm text-[#1C1917]">Biện pháp 2: Thay mới toàn bộ lưới bao che mặt đường chính</span>
                <span className="px-2 py-0.5 rounded bg-[#FFF7ED] text-[#EA580C] text-[10px] font-bold">Đang triển khai</span>
              </div>
              <p className="text-[#57534E] leading-relaxed">Đang căng lại lưới chắn bụi mật độ cao tại mặt hướng Tây tiếp giáp khu dân cư.</p>
            </div>
          </div>
        </div>
      )}

      {/* 10. Tab 6: Hồ sơ pháp lý */}
      {activeTab === 'DOSSIER' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-2xs space-y-4">
          <div className="pb-3 border-b border-[#E7E5E4] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="font-black text-sm sm:text-base text-[#1C1917]">Hồ sơ pháp lý & Quyết định xử lý</h3>
              <p className="text-xs text-[#78716C]">Áp dụng Nghị định 45/2022/NĐ-CP & Thể thức văn bản NĐ 30/2020/NĐ-CP</p>
            </div>
            <button
              onClick={() => setPrintPreviewOpen(true)}
              className="px-4 py-2 bg-[#1C1917] hover:bg-black text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer min-h-[44px] flex items-center justify-center gap-1.5"
            >
              <span>🖨️</span>
              <span>Xem & In biên bản A4</span>
            </button>
          </div>

          <div className="p-4 rounded-xl border border-[#E7E5E4] bg-[#FAFAF9] space-y-3 text-xs">
            <div className="font-black text-sm text-[#1C1917]">Dự thảo quyết định xử phạt vi phạm hành chính</div>
            <p className="text-[#57534E] leading-relaxed">
              Căn cứ Điểm b Khoản 2 Điều 15 Nghị định số 45/2022/NĐ-CP ngày 07/07/2022 của Chính phủ quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường đối với hành vi không thực hiện biện pháp dập bụi tại công trình xây dựng.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3 border-t border-[#E7E5E4]">
              <span className="font-bold text-[#B91C1C]">Mức phạt đề xuất: 25.000.000 VNĐ</span>
              <span className="text-[#78716C]">• Biện pháp khắc phục: Buộc thực hiện ngay các biện pháp giảm thiểu bụi</span>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Phân công cán bộ (Giao việc thông minh) */}
      {assignModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setAssignModalOpen(false)} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Phân công cán bộ phụ trách hồ sơ</h3>
                <p className="text-xs text-[#78716C]">Gán nhiệm vụ thanh tra và thiết lập thời hạn xử lý SLA</p>
              </div>
              <button
                type="button"
                onClick={() => setAssignModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAssignSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Cán bộ thụ lý *</label>
                <select
                  value={assignedOfficer}
                  onChange={(e) => setAssignedOfficer(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C] min-h-[44px]"
                >
                  {officers.length > 0 ? (
                    officers.map(o => (
                      <option key={o.id} value={o.fullName || o.email}>
                        {o.fullName || o.email} ({o.role || 'Cán bộ'}) - {o.openTasksCount || 0} việc đang xử lý
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="Nguyễn Thị Lan (Thanh tra quận)">Nguyễn Thị Lan (Thanh tra quận)</option>
                      <option value="Lê Văn Minh (Tổ phản ứng nhanh)">Lê Văn Minh (Tổ phản ứng nhanh)</option>
                      <option value="Phạm Tuấn Anh (Cán bộ môi trường)">Phạm Tuấn Anh (Cán bộ môi trường)</option>
                      <option value="Trần Hoàng Nam (Giám sát viên)">Trần Hoàng Nam (Giám sát viên)</option>
                    </>
                  )}
                </select>
              </div>

              {/* Nút chọn nhanh hạn SLA */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-[#1C1917]">Thời hạn cam kết xử lý (SLA) *</label>
                  <span className="text-[10px] text-[#78716C]">Chọn nhanh:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => handleSetQuickSla(24, '24 Giờ (Khẩn cấp)')}
                    className="py-2.5 px-2 bg-[#FEF2F2] hover:bg-[#FEE2E2] text-[#B91C1C] font-bold rounded-xl border border-[#FECACA] text-[11px] min-h-[44px] cursor-pointer"
                  >
                    ⚡ 24 Giờ
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickSla(48, '48 Giờ (Chuẩn SLA)')}
                    className="py-2.5 px-2 bg-[#F0FDF4] hover:bg-[#DCFCE7] text-[#16A34A] font-bold rounded-xl border border-[#DCFCE7] text-[11px] min-h-[44px] cursor-pointer"
                  >
                    ⏱ 48 Giờ
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickSla(72, '72 Giờ')}
                    className="py-2.5 px-2 bg-[#FFF7ED] hover:bg-[#FFEDD5] text-[#EA580C] font-bold rounded-xl border border-[#FFEDD5] text-[11px] min-h-[44px] cursor-pointer"
                  >
                    📅 3 Ngày
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickSla(168, '7 Ngày')}
                    className="py-2.5 px-2 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#57534E] font-bold rounded-xl border border-[#E7E5E4] text-[11px] min-h-[44px] cursor-pointer"
                  >
                    🗓 7 Ngày
                  </button>
                </div>
                <input
                  type="date"
                  required
                  value={assignDueDate}
                  onChange={(e) => setAssignDueDate(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C] min-h-[44px]"
                />
              </div>

              {/* Gợi ý chỉ đạo nhanh */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-[#1C1917]">Chỉ đạo & Ghi chú nhiệm vụ</label>
                  <span className="text-[10px] text-[#78716C]">Gợi ý nhanh:</span>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {[
                    'Khảo sát hiện trường khẩn cấp',
                    'Yêu cầu nhà thầu dừng thi công dập bụi',
                    'Tái kiểm tra sau 24h'
                  ].map((tip, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setAssignNotes(tip)}
                      className="px-2.5 py-1 bg-[#FAFAF9] border border-[#E7E5E4] hover:bg-white text-[10px] font-semibold text-[#57534E] rounded-md cursor-pointer"
                    >
                      {tip}
                    </button>
                  ))}
                </div>
                <textarea
                  rows={3}
                  value={assignNotes}
                  onChange={(e) => setAssignNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:outline-none focus:border-[#B91C1C]"
                  placeholder="Nhập yêu cầu kiểm tra hiện trường..."
                />
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setAssignModalOpen(false)}
                  className="px-4 py-2.5 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50 min-h-[44px] shadow-xs"
                >
                  {actionLoading ? 'Đang lưu...' : 'Gán nhiệm vụ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 1.5: Tải Lên Ảnh Minh Chứng Tiện Dụng (File / Presets / Camera) */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => { setUploadModalOpen(false); setUploadPreview(''); }} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Tải lên ảnh minh chứng hiện trường</h3>
                <p className="text-xs text-[#78716C]">Chọn tệp từ máy hoặc chọn ảnh mẫu hiện trường nhanh</p>
              </div>
              <button
                type="button"
                onClick={() => { setUploadModalOpen(false); setUploadPreview(''); }}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUploadEvidenceSubmit} className="space-y-4 text-xs">
              
              {/* Chọn giai đoạn Before / Inspection / After */}
              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">Giai đoạn đối chứng *</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setUploadPhotoType('BEFORE')}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs transition cursor-pointer min-h-[44px] flex flex-col items-center justify-center ${
                      uploadPhotoType === 'BEFORE'
                        ? 'bg-[#FEF2F2] border-[#B91C1C] text-[#B91C1C] ring-1 ring-[#B91C1C]'
                        : 'bg-[#FAFAF9] border-[#E7E5E4] text-[#78716C]'
                    }`}
                  >
                    <span className="block text-sm mb-0.5">🔴</span>
                    <span>Trước dập bụi</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadPhotoType('INSPECTION')}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs transition cursor-pointer min-h-[44px] flex flex-col items-center justify-center ${
                      uploadPhotoType === 'INSPECTION'
                        ? 'bg-[#FFF7ED] border-[#EA580C] text-[#EA580C] ring-1 ring-[#EA580C]'
                        : 'bg-[#FAFAF9] border-[#E7E5E4] text-[#78716C]'
                    }`}
                  >
                    <span className="block text-sm mb-0.5">🟡</span>
                    <span>Khảo sát</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadPhotoType('AFTER')}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs transition cursor-pointer min-h-[44px] flex flex-col items-center justify-center ${
                      uploadPhotoType === 'AFTER'
                        ? 'bg-[#F0FDF4] border-[#16A34A] text-[#16A34A] ring-1 ring-[#16A34A]'
                        : 'bg-[#FAFAF9] border-[#E7E5E4] text-[#78716C]'
                    }`}
                  >
                    <span className="block text-sm mb-0.5">🟢</span>
                    <span>Sau dập bụi</span>
                  </button>
                </div>
              </div>

              {/* Khu vực Chọn Tệp từ Máy / Camera */}
              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">1. Chọn tệp từ máy hoặc chụp ảnh</label>
                <label className="border-2 border-dashed border-[#D6D3D1] hover:border-[#B91C1C] bg-[#FAFAF9] hover:bg-[#FEF2F2]/30 rounded-2xl p-4 flex flex-col items-center justify-center gap-1.5 cursor-pointer transition min-h-[90px]">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <span className="text-2xl">📸</span>
                  <span className="font-bold text-xs text-[#1C1917]">Bấm để chọn tệp hoặc chụp ảnh</span>
                  <span className="text-[10px] text-[#78716C]">Hỗ trợ JPG, PNG, WEBP (Tự động tối ưu dung lượng và ghi nhận trạng thái tệp)</span>
                </label>
              </div>

              {/* Ảnh mẫu hiện trường nhanh (1-Click Presets) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-[#1C1917]">2. Hoặc chọn nhanh ảnh mẫu hiện trường</label>
                  <span className="text-[10px] text-[#0D9488] font-bold">1-Click tiện dụng</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SAMPLE_PRESET_PHOTOS.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectPresetPhoto(p)}
                      className="p-2 rounded-xl border border-[#E7E5E4] bg-white hover:bg-[#FAFAF9] text-left transition cursor-pointer flex items-center gap-2 min-h-[44px]"
                    >
                      <img src={p.url} alt={p.label} className="w-9 h-9 rounded-lg object-cover shrink-0 border border-[#E7E5E4]" />
                      <div className="min-w-0">
                        <div className="font-bold text-[10px] text-[#1C1917] truncate">{p.label}</div>
                        <span className={`text-[9px] font-bold ${p.type === 'BEFORE' ? 'text-[#B91C1C]' : 'text-[#16A34A]'}`}>
                          {p.type === 'BEFORE' ? '🔴 Trước' : '🟢 Sau'}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Preview ảnh được chọn */}
              {uploadPreview && (
                <div className="p-2.5 rounded-2xl bg-[#FAFAF9] border border-[#E7E5E4] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#1C1917]">
                    <span>Ảnh đã chọn:</span>
                    <button
                      type="button"
                      onClick={() => { setUploadPreview(''); setUploadUrl(''); setUploadFileObj(null); }}
                      className="text-[#B91C1C] hover:underline text-[10px] min-h-[32px] flex items-center cursor-pointer"
                    >
                      Xóa ảnh
                    </button>
                  </div>
                  <img src={uploadPreview} alt="Preview" className="w-full h-36 object-cover rounded-xl border border-[#E7E5E4]" />
                </div>
              )}

              {/* Mô tả ngắn */}
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Mô tả vị trí & hiện trạng</label>
                <input
                  type="text"
                  value={uploadCaption}
                  onChange={(e) => setUploadCaption(e.target.value)}
                  placeholder="VD: Cổng số 1, giáp đường Khuất Duy Tiến..."
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-medium bg-white focus:outline-none focus:border-[#B91C1C] min-h-[44px]"
                />
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => { setUploadModalOpen(false); setUploadPreview(''); }}
                  className="px-4 py-2.5 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50 min-h-[44px] shadow-xs"
                >
                  {actionLoading ? 'Đang lưu...' : 'Lưu ảnh vào hồ sơ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 1.8: Duyệt Hoàn Tất Và Đóng Hồ Sơ (Completion Modal) */}
      {completeModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setCompleteModalOpen(false)} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-[#F0FDF4] text-[#16A34A] flex items-center justify-center font-bold text-base">
                  ✓
                </span>
                <div>
                  <h3 className="text-base font-black text-[#1C1917]">Nghiệm thu & Duyệt đóng hồ sơ</h3>
                  <p className="text-xs text-[#78716C]">Xác nhận kết quả xử lý vi phạm môi trường đô thị</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCompleteModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCompleteCaseSubmit} className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-[#F0FDF4] border border-[#DCFCE7] space-y-1.5">
                <div className="font-bold text-[#16A34A] text-xs">Điều kiện nghiệm thu hoàn tất:</div>
                <ul className="list-disc pl-4 space-y-1 text-[#15803D] text-[11px]">
                  <li>Đã đối chứng ảnh Before/After ({beforePhotos.length} ảnh trước, {afterPhotos.length} ảnh sau).</li>
                  <li>Biên bản khảo sát 10 tiêu chí theo QCVN 18:2021/BXD đã được ghi nhận.</li>
                  <li>Nhà thầu đã hoàn tất các biện pháp giảm thiểu phát tán bụi.</li>
                </ul>
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Kết luận nghiệm thu của Cán bộ thụ lý *</label>
                <textarea
                  rows={3}
                  required
                  value={completeNotes}
                  onChange={(e) => setCompleteNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:outline-none focus:border-[#16A34A] font-medium"
                />
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setCompleteModalOpen(false)}
                  className="px-4 py-2.5 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Quay lại
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2.5 bg-[#16A34A] hover:bg-[#15803D] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50 min-h-[44px] shadow-xs"
                >
                  {actionLoading ? 'Đang duyệt...' : 'Xác nhận duyệt đóng hồ sơ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Xem Trước Bản In Biên Bản A4 Chuẩn Hành Chính */}
      {printPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/75 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setPrintPreviewOpen(false)} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] max-w-3xl w-full p-5 sm:p-8 shadow-2xl space-y-4 sm:space-y-6 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <span className="font-bold text-xs text-[#78716C]">Xem trước văn bản chuẩn A4 (NĐ 30/2020/NĐ-CP)</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportPdf}
                  className="px-4 py-2 bg-[#B91C1C] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer min-h-[44px] flex items-center gap-1.5"
                >
                  <span>🖨️</span>
                  <span>In ngay</span>
                </button>
                <button
                  onClick={() => setPrintPreviewOpen(false)}
                  className="p-2 text-[#78716C] hover:text-[#1C1917] font-bold min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Khổ giấy A4 */}
            <div className="border border-[#D6D3D1] bg-[#FDFBF7] p-4 sm:p-8 rounded-2xl space-y-4 text-xs text-[#1C1917] leading-relaxed overflow-x-auto">
              <div className="text-center space-y-1">
                <div className="font-black text-xs sm:text-sm uppercase tracking-wider">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div>
                <div className="font-bold text-xs underline underline-offset-4">Độc lập - Tự do - Hạnh phúc</div>
              </div>

              <div className="flex justify-between items-start pt-2">
                <div>
                  <div className="font-bold text-[11px] uppercase">ĐOÀN KIỂM TRA MÔI TRƯỜNG ĐÔ THỊ</div>
                  <div className="text-[10px] text-[#57534E]">Số: {caseData.code}/BB-KTMT</div>
                </div>
                <div className="text-right text-[10px] italic text-[#57534E]">
                  Hà Nội, ngày 02 tháng 09 năm 2026
                </div>
              </div>

              <div className="text-center py-2">
                <h2 className="font-black text-sm sm:text-base uppercase text-[#1C1917]">BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG</h2>
                <div className="font-semibold text-xs text-[#57534E]">(V/v thực hiện các biện pháp giảm thiểu phát tán bụi xây dựng)</div>
              </div>

              <div className="space-y-1.5">
                <p><strong>1. Công trình kiểm tra:</strong> {caseData.siteName}</p>
                <p><strong>2. Địa điểm:</strong> {caseData.address}</p>
                <p><strong>3. Thành phần kiểm tra:</strong></p>
                <ul className="list-disc pl-5 space-y-0.5 text-[11px]">
                  <li>Đồng chí: {caseData.assigneeName} - Cán bộ thanh tra môi trường (Trưởng đoàn)</li>
                  <li>Đại diện Ban Chỉ huy công trình / Nhà thầu thi công</li>
                </ul>
              </div>

              <div className="space-y-1.5 pt-2">
                <strong className="block">4. Kết quả kiểm tra đối chiếu 10 tiêu chuẩn QCVN 18/QĐ 48:</strong>
                <div className="divide-y divide-[#E7E5E4] border border-[#E7E5E4] rounded-lg bg-white p-2 space-y-1">
                  {checklistItems.slice(0, 5).map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-[11px] py-1">
                      <span className="truncate pr-2">{item.title}</span>
                      <span className={`font-bold shrink-0 ${item.status === 'Đạt' ? 'text-[#16A34A]' : 'text-[#B91C1C]'}`}>
                        {item.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1 pt-2">
                <p><strong>5. Kết luận & Cam kết:</strong> Yêu cầu nhà thầu hoàn thành khắc phục các tiêu chí Chưa đạt trong thời hạn <strong>48 giờ (trước ngày 04/09/2026)</strong>.</p>
              </div>

              <div className="grid grid-cols-2 text-center pt-6 text-xs">
                <div>
                  <div className="font-bold uppercase">ĐẠI DIỆN NHÀ THẦU</div>
                  <div className="text-[10px] text-[#78716C] mt-1">(Ký, ghi rõ họ tên)</div>
                </div>
                <div>
                  <div className="font-bold uppercase">TRƯỞNG ĐOÀN KIỂM TRA</div>
                  <div className="text-[10px] text-[#78716C] mt-1">(Ký, ghi rõ họ tên)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Zoom Ảnh Bằng Chứng Hiện Trường */}
      {photoZoom.open && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/85 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setPhotoZoom({ open: false, url: '', title: '', hash: '' })} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] max-w-xl w-full p-5 shadow-2xl space-y-3 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
              <div className="min-w-0 flex-1">
                <h3 className="font-black text-sm text-[#1C1917] truncate">{photoZoom.title}</h3>
                <span className="text-[10px] text-[#15803D] font-bold block mt-0.5">✓ Tệp không thay đổi kể từ khi lưu</span>
                <span className="text-[9px] font-mono text-[#78716C] truncate block" title="Mã kiểm tra giúp xác nhận tệp khớp với bản lưu ban đầu">Mã đối chứng tệp: {photoZoom.hash}</span>
              </div>
              <button
                type="button"
                onClick={() => setPhotoZoom({ open: false, url: '', title: '', hash: '' })}
                className="p-1 text-[#78716C] hover:text-[#1C1917] font-bold min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden border border-[#E7E5E4] bg-black">
              <img src={photoZoom.url} alt={photoZoom.title} className="w-full h-80 object-cover" />
            </div>

            <div className="flex flex-col-reverse sm:flex-row justify-end pt-2">
              <button
                type="button"
                onClick={() => setPhotoZoom({ open: false, url: '', title: '', hash: '' })}
                className="w-full sm:w-auto px-4 py-2.5 bg-[#1C1917] text-white text-xs font-bold rounded-xl min-h-[44px] cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

