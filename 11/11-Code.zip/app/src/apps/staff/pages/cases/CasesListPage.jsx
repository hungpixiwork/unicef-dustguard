import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import {
  AlertTriangle,
  Clock,
  Search,
  Plus,
  Download,
  ChevronRight,
  MapPin,
  User,
  Filter,
  RefreshCw,
  FolderOpen,
  ArrowRight,
  Flame
} from 'lucide-react';

export default function CasesListPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter & Pagination States
  const [activeTab, setActiveTab] = useState('ALL'); // ALL | NEW | IN_PROGRESS | CONTRACTOR | VERIFICATION | CLOSED
  const [searchQuery, setSearchQuery] = useState('');
  const [stepFilter, setStepFilter] = useState('ALL');
  const [assigneeFilter, setAssigneeFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCasesCount, setTotalCasesCount] = useState(0);

  // Data States
  const [kpis, setKpis] = useState({
    openCases: 38,
    nearDeadlineCount: 11,
    pendingInspectionCount: 9,
    pendingVerificationCount: 7,
    countsByTab: { all: 38, new: 8, inProgress: 18, contractor: 6, verification: 7, closed: 42 }
  });
  const [cases, setCases] = useState([]);
  const [priorities, setPriorities] = useState([]);

  // Modals & Action States
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Form State for Creating Case
  const [newCaseForm, setNewCaseForm] = useState({
    title: '',
    siteName: '',
    address: 'Thanh Xuân, Hà Nội',
    priority: 'HIGH',
    assignedTo: 'Thanh tra Môi trường',
    dueDays: 2,
    description: ''
  });

  // Escape key listener & body lock for modal
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') setCreateModalOpen(false);
    };
    if (createModalOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [createModalOpen]);

  // 1. Fetch Summary KPIs
  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/cases/summary');
      if (res?.data) {
        setKpis({
          openCases: res.data.openCases ?? 38,
          nearDeadlineCount: res.data.nearDeadlineCount ?? 11,
          pendingInspectionCount: res.data.pendingInspectionCount ?? 9,
          pendingVerificationCount: res.data.pendingVerificationCount ?? 7,
          countsByTab: res.data.countsByTab || { all: 38, new: 8, inProgress: 18, contractor: 6, verification: 7, closed: 42 }
        });
      }
    } catch (err) {
      console.error('Error fetching cases summary:', err);
    }
  }, []);

  // 2. Fetch Priority Today
  const fetchPriorities = useCallback(async () => {
    try {
      const res = await request('/staff/cases/priorities');
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setPriorities(res.data.items);
      } else {
        setPriorities([
          {
            id: 'case_001',
            code: 'CASE-2026-001',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            address: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
            deadline: '16:00 Hôm nay',
            status: 'Gần đến hạn'
          },
          {
            id: 'case_002',
            code: 'CASE-2026-002',
            siteName: 'Chung cư Discovery Complex Cầu Giấy',
            address: '302 Cầu Giấy, Hà Nội',
            deadline: '09:00 Ngày mai',
            status: 'Đang xử lý'
          },
          {
            id: 'case_003',
            code: 'CASE-2026-003',
            siteName: 'Cầu Vĩnh Tuy giai đoạn 2',
            address: 'Long Biên, Hà Nội',
            deadline: '18:00 03/09',
            status: 'Chờ nghiệm thu'
          }
        ]);
      }
    } catch (err) {
      console.error('Error fetching priorities:', err);
    }
  }, []);

  // 3. Fetch Cases List
  const fetchCases = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        tab: activeTab,
        search: searchQuery,
        step: stepFilter,
        page: String(currentPage),
        limit: '10'
      });
      if (assigneeFilter && assigneeFilter !== 'ALL') {
        params.set('assignee', assigneeFilter);
      }
      const res = await request(`/staff/cases/list?${params.toString()}`);
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setCases(res.data.items);
        setTotalCasesCount(res.data.pagination?.total ?? res.data.items.length);
      } else {
        setCases([
          {
            id: 'case_001',
            code: 'CASE-2026-001',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            address: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
            currentStep: 'Kiểm tra hiện trường',
            assigneeName: 'Nguyễn Thị Lan',
            assigneeInitials: 'NL',
            deadline: '16:00 Hôm nay',
            status: 'Gần đến hạn',
            priority: 'HIGH'
          },
          {
            id: 'case_002',
            code: 'CASE-2026-002',
            siteName: 'Chung cư Discovery Complex Cầu Giấy',
            address: '302 Cầu Giấy, Hà Nội',
            currentStep: 'Chờ nhà thầu khắc phục',
            assigneeName: 'Lê Văn Minh',
            assigneeInitials: 'LM',
            deadline: '09:00 Ngày mai',
            status: 'Đang xử lý',
            priority: 'MEDIUM'
          },
          {
            id: 'case_003',
            code: 'CASE-2026-003',
            siteName: 'Cầu Vĩnh Tuy giai đoạn 2',
            address: 'Long Biên, Hà Nội',
            currentStep: 'Chờ nghiệm thu',
            assigneeName: 'Phạm Tuấn Anh',
            assigneeInitials: 'PA',
            deadline: '18:00 03/09',
            status: 'Chờ nghiệm thu',
            priority: 'LOW'
          }
        ]);
        setTotalCasesCount(3);
      }
    } catch (err) {
      console.error('Error fetching cases list:', err);
    }
  }, [activeTab, searchQuery, stepFilter, assigneeFilter, currentPage]);

  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchPriorities(), fetchCases()]);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách hồ sơ');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchPriorities, fetchCases]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  useEffect(() => {
    fetchCases();
  }, [fetchCases]);

  // Submit new case
  const handleSubmitCreateCase = async (e) => {
    e.preventDefault();
    if (!newCaseForm.title) {
      alert('Vui lòng nhập tiêu đề hồ sơ');
      return;
    }
    try {
      setActionLoading(true);
      await request('/cases', {
        method: 'POST',
        body: JSON.stringify({
          title: newCaseForm.title,
          siteName: newCaseForm.siteName,
          address: newCaseForm.address,
          priority: newCaseForm.priority,
          assignedTo: newCaseForm.assignedTo,
          dueAt: new Date(Date.now() + newCaseForm.dueDays * 24 * 3600 * 1000).toISOString(),
          description: newCaseForm.description
        })
      });
      setCreateModalOpen(false);
      setNewCaseForm({
        title: '',
        siteName: '',
        address: 'Thanh Xuân, Hà Nội',
        priority: 'HIGH',
        assignedTo: 'Thanh tra Môi trường',
        dueDays: 2,
        description: ''
      });
      await loadAllData();
      alert('Đã tạo hồ sơ vụ việc thành công!');
    } catch (err) {
      alert(`Lỗi: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState message="Đang tải danh sách hồ sơ vụ việc…" />;
  if (error) return <ErrorState title="Lỗi tải hồ sơ" message={error} onRetry={loadAllData} />;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 1. Page Header (Mockup 6) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight">
            Hồ sơ đang xử lý
          </h1>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            Theo dõi tiến độ, phân công và 7 bước tác nghiệp đa bên.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => setCreateModalOpen(true)}
            className="dg-btn dg-btn-primary min-h-[44px] flex items-center gap-1.5"
            style={{ padding: '8px 16px', fontSize: 13 }}
          >
            <Plus size={15} />
            <span>Tạo hồ sơ</span>
          </button>

          <button
            onClick={() => alert('Đang xuất danh sách hồ sơ vụ việc...')}
            className="dg-btn dg-btn-secondary min-h-[44px] flex items-center gap-1.5"
            style={{ padding: '8px 12px', fontSize: 13 }}
            title="Xuất dữ liệu"
          >
            <Download size={15} />
            <span className="hidden sm:inline">Xuất danh sách</span>
          </button>
        </div>
      </div>

      {/* 2. Top Summary 4 KPI Strip (Mockup 6) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Hồ sơ mở
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {kpis.openCases}
            </span>
            <span className="text-xs text-[#7E7771]">vụ việc</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#9F241F] uppercase tracking-wider block">
            Gần đến hạn SLA
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#9F241F]">
              {kpis.nearDeadlineCount}
            </span>
            <span className="text-xs text-[#9F241F]/80">cần xử lý</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Chờ kiểm tra
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {kpis.pendingInspectionCount}
            </span>
            <span className="text-xs text-[#7E7771]">vụ việc</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Chờ nghiệm thu
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#1B7A4B]">
              {kpis.pendingVerificationCount}
            </span>
            <span className="text-xs text-[#7E7771]">vụ việc</span>
          </div>
        </div>

      </div>

      {/* 3. Filter 6 Tabs Toolbar (Mockup 6) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {[
          { label: 'Tất cả', val: 'ALL', count: kpis.countsByTab.all },
          { label: 'Mới tạo', val: 'NEW', count: kpis.countsByTab.new },
          { label: 'Đang xử lý', val: 'IN_PROGRESS', count: kpis.countsByTab.inProgress },
          { label: 'Chờ nhà thầu', val: 'CONTRACTOR', count: kpis.countsByTab.contractor },
          { label: 'Chờ nghiệm thu', val: 'VERIFICATION', count: kpis.countsByTab.verification },
          { label: 'Đã hoàn tất', val: 'CLOSED', count: kpis.countsByTab.closed }
        ].map(tab => (
          <button
            key={tab.val}
            onClick={() => { setActiveTab(tab.val); setCurrentPage(1); }}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 min-h-[44px] ${
              activeTab === tab.val
                ? 'bg-[#161313] text-white shadow-xs'
                : 'bg-white text-[#5C5550] border border-[#161313]/10 hover:bg-[#F7F6F3]'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
              activeTab === tab.val ? 'bg-white/20 text-white' : 'bg-[#F7F6F3] text-[#7E7771]'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* 4. Main Body: 75% Table + 25% Priority Panel (xl:w-[310px] Responsive Layout) */}
      <div className="flex flex-col xl:flex-row gap-5 items-start">
        
        {/* Left Column: Filter Controls Strip + Dense 7-Column Table */}
        <div className="flex-1 min-w-0 w-full space-y-4">
          
          {/* Filter Controls Strip */}
          <div className="bg-white border border-[#161313]/10 rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[240px]">
              <Search size={15} className="text-[#7E7771] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm kiếm mã hồ sơ, công trình, địa điểm..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="w-full pl-9 pr-3.5 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl text-xs text-[#161313] focus:outline-none focus:border-[#9F241F] min-h-[40px] font-medium"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <select
                value={stepFilter}
                onChange={(e) => { setStepFilter(e.target.value); setCurrentPage(1); }}
                className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[40px] cursor-pointer"
              >
                <option value="ALL">Bước: Tất cả bước</option>
                <option value="INSPECTION">Kiểm tra hiện trường</option>
                <option value="CONTRACTOR">Chờ nhà thầu khắc phục</option>
                <option value="SURVEY">Khảo sát bổ sung</option>
                <option value="VERIFICATION">Chờ nghiệm thu</option>
              </select>

              <select
                value={assigneeFilter}
                onChange={(e) => { setAssigneeFilter(e.target.value); setCurrentPage(1); }}
                className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[40px] cursor-pointer"
              >
                <option value="ALL">Phụ trách: Tất cả</option>
                <option value="Nguyễn Thị Lan">Nguyễn Thị Lan</option>
                <option value="Lê Văn Minh">Lê Văn Minh</option>
                <option value="Phạm Tuấn Anh">Phạm Tuấn Anh</option>
              </select>
            </div>
          </div>

          {/* Dense 7-Column Table */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl shadow-xs overflow-hidden">
            {cases.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#F7F6F3] text-[#7E7771] flex items-center justify-center mx-auto">
                  <FolderOpen size={22} />
                </div>
                <strong className="text-sm text-[#161313] block">Không tìm thấy hồ sơ nào phù hợp</strong>
                <p className="text-xs text-[#5C5550]">Hãy thử đổi từ khóa tìm kiếm hoặc chọn lại bộ lọc trạng thái.</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveTab('ALL');
                    setStepFilter('ALL');
                    setAssigneeFilter('ALL');
                  }}
                  className="dg-btn dg-btn-secondary"
                  style={{ minHeight: 36, padding: '6px 14px', fontSize: 12 }}
                >
                  <span>Xóa bộ lọc</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-[#161313]/5">
                {cases.map((c) => {
                  const isOverdue = c.status === 'Quá hạn' || c.status === 'Gần đến hạn';
                  return (
                    <div
                      key={c.id}
                      onClick={() => navigate(`/staff/cases/${c.id}`)}
                      className="p-4 sm:p-5 transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer hover:bg-[#FDFBF7]"
                    >
                      {/* 1. Code & Site & Address */}
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <span className="text-xs font-mono font-bold px-2 py-1 bg-[#F7F6F3] border border-[#161313]/10 rounded-lg shrink-0 mt-0.5 text-[#161313]">
                          {c.code}
                        </span>

                        <div className="min-w-0 space-y-1">
                          <strong className="text-sm sm:text-base font-bold text-[#161313] leading-snug block break-words">
                            {c.siteName}
                          </strong>
                          <div className="flex items-center gap-1.5 text-xs text-[#7E7771]">
                            <MapPin size={12} className="shrink-0" />
                            <span className="truncate">{c.address}</span>
                          </div>
                        </div>
                      </div>

                      {/* 2. Step, Assignee, Deadline */}
                      <div className="flex flex-wrap items-center gap-4 sm:gap-6 shrink-0 py-1 md:py-0 border-t md:border-t-0 border-[#161313]/5 w-full md:w-auto justify-between md:justify-start text-xs">
                        
                        {/* Current Step */}
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-bold text-[#7E7771] uppercase block">Bước hiện tại</span>
                          <span className="inline-block px-2.5 py-1 rounded-lg bg-[#F7F6F3] border border-[#161313]/10 font-bold text-[#161313]">
                            {c.currentStep}
                          </span>
                        </div>

                        {/* Assignee */}
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-bold text-[#7E7771] uppercase block">Phụ trách</span>
                          <div className="flex items-center gap-1.5 font-medium text-[#161313]">
                            <span className="w-5 h-5 rounded-full bg-[#F2EFE9] text-[#161313] text-[10px] font-black flex items-center justify-center shrink-0">
                              {c.assigneeInitials || 'CB'}
                            </span>
                            <span>{c.assigneeName}</span>
                          </div>
                        </div>

                        {/* Deadline */}
                        <div className="space-y-0.5 text-right min-w-[90px]">
                          <span className="text-[10px] font-bold text-[#7E7771] uppercase block">Hạn xử lý</span>
                          <span className={`font-mono font-bold text-xs ${isOverdue ? 'text-[#9F241F]' : 'text-[#161313]'}`}>
                            {c.deadline}
                          </span>
                        </div>

                      </div>

                      {/* 3. Status & Chevron */}
                      <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                          c.status === 'Quá hạn' || c.status === 'Gần đến hạn'
                            ? 'bg-[#FDF2F1] text-[#9F241F] border-[#F8D3D1]'
                            : c.status === 'Đã đóng'
                            ? 'bg-[#EDF7F2] text-[#1B7A4B] border-[#A3E6C5]'
                            : 'bg-[#FEF9EE] text-[#B45309] border-[#FDE68A]'
                        }`}>
                          {c.status}
                        </span>
                        <ChevronRight size={16} className="text-[#A8A29E] hidden md:block" />
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* Footer Pagination */}
            <div className="p-4 bg-[#FDFBF7] border-t border-[#161313]/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C5550]">
              <div>
                Hiển thị <strong>{cases.length}</strong> / <strong>{totalCasesCount}</strong> hồ sơ vụ việc
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] flex items-center justify-center cursor-pointer"
                >
                  ← Trang trước
                </button>
                <button
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={cases.length < 10}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] flex items-center justify-center cursor-pointer"
                >
                  Trang tiếp →
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Priority Panel "Ưu tiên hôm nay" (Mockup 6 Fixed xl:w-[310px]) */}
        <div className="w-full xl:w-[310px] xl:shrink-0 bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-2xs space-y-4">
          
          <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#9F241F] animate-pulse" />
              <h3 className="font-black text-sm text-[#161313] uppercase tracking-wider">
                Ưu tiên hôm nay
              </h3>
            </div>
            <span className="text-[11px] font-bold text-[#9F241F] bg-[#FDF2F1] px-2 py-0.5 rounded-full">
              {priorities.length} hồ sơ gấp
            </span>
          </div>

          <p className="text-xs text-[#5C5550] leading-relaxed">
            Các hồ sơ có nguy cơ quá hạn SLA hoặc mức độ phát tán bụi nghiêm trọng cần thanh tra ưu tiên xử lý trong ngày.
          </p>

          <div className="space-y-3">
            {priorities.length === 0 ? (
              <div className="text-xs text-[#7E7771] italic py-2">
                Không có hồ sơ nào quá hạn hoặc cần xử lý khẩn cấp hôm nay.
              </div>
            ) : (
              priorities.map((p) => (
                <div
                  key={p.id}
                  onClick={() => navigate(`/staff/cases/${p.id}`)}
                  className="p-3.5 rounded-2xl bg-[#F7F6F3] border border-[#161313]/10 hover:border-[#9F241F]/40 transition cursor-pointer space-y-2 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-black text-[#9F241F]">
                      {p.code}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#FDF2F1] text-[#9F241F] border border-[#F8D3D1]">
                      {p.status}
                    </span>
                  </div>

                  <strong className="text-xs font-bold text-[#161313] line-clamp-2 leading-snug group-hover:text-[#9F241F] transition">
                    {p.siteName}
                  </strong>

                  <div className="flex items-center justify-between text-[11px] text-[#7E7771] pt-1 border-t border-[#161313]/5">
                    <span className="font-mono">⏱ {p.deadline}</span>
                    <span className="text-xs font-bold text-[#9F241F] flex items-center gap-0.5">
                      Mở <ArrowRight size={12} />
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => { setActiveTab('NEW'); }}
            className="w-full py-2.5 px-3 rounded-xl border border-[#161313]/10 hover:bg-[#F7F6F3] text-xs font-bold text-[#5C5550] hover:text-[#161313] transition text-center flex items-center justify-center cursor-pointer min-h-[44px]"
          >
            Xem tất cả hồ sơ cần xử lý ➔
          </button>

        </div>

      </div>

      {/* Modal: Tạo hồ sơ mới */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setCreateModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">Tạo hồ sơ vụ việc mới</h3>
              <button 
                type="button" 
                onClick={() => setCreateModalOpen(false)} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitCreateCase} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Tiêu đề vụ việc *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Bụi phát tán từ công trường Vành đai 3..."
                  value={newCaseForm.title}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Công trình liên quan *</label>
                <input
                  type="text"
                  required
                  placeholder="Tên công trình xây dựng..."
                  value={newCaseForm.siteName}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, siteName: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Địa điểm *</label>
                <input
                  type="text"
                  required
                  placeholder="Địa chỉ công trình..."
                  value={newCaseForm.address}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#161313] mb-1">Mức độ ưu tiên</label>
                  <select
                    value={newCaseForm.priority}
                    onChange={(e) => setNewCaseForm(prev => ({ ...prev, priority: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                  >
                    <option value="CRITICAL">🔴 Rất cao (Khẩn cấp)</option>
                    <option value="HIGH">🟠 Cao (SLA 24h)</option>
                    <option value="MEDIUM">🟡 Trung bình</option>
                    <option value="LOW">🟢 Thấp</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#161313] mb-1">Thời hạn (ngày)</label>
                  <input
                    type="number"
                    min="1"
                    max="14"
                    value={newCaseForm.dueDays}
                    onChange={(e) => setNewCaseForm(prev => ({ ...prev, dueDays: Number(e.target.value) }))}
                    className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                  />
                </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-[#161313]/15 font-bold text-[#5C5550] hover:bg-[#F7F6F3] min-h-[44px] cursor-pointer flex items-center justify-center"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2.5 rounded-xl bg-[#9F241F] hover:bg-[#831815] text-white font-black min-h-[44px] cursor-pointer flex items-center justify-center shadow-xs"
                >
                  {actionLoading ? 'Đang tạo...' : 'Tạo hồ sơ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
