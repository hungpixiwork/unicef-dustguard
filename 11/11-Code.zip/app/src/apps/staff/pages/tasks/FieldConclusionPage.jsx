import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';

export default function FieldConclusionPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [conclusion, setConclusion] = useState('ACTION_REQUIRED'); // 'NO_VIOLATION' | 'ACTION_REQUIRED' | 'VIOLATION'
  const [remediationRequirements, setRemediationRequirements] = useState(
    'Yêu cầu nhà thầu che bạt 100% bãi cát đá tập kết, vận hành cầu rửa xe áp lực cao trước khi xe ra khỏi cổng, quét rửa mặt đường tiếp giáp.'
  );
  const [slaHours, setSlaHours] = useState(48);
  const [submitting, setSubmitting] = useState(false);
  const [checklistSummary, setChecklistSummary] = useState({ pass: 3, fail: 3 });
  const [evidenceCount, setEvidenceCount] = useState(2);

  const [taskData, setTaskData] = useState(null);

  useEffect(() => {
    async function loadTaskInfo() {
      try {
        const res = await request(`/staff/tasks/${id}/detail`).catch(() => request(`/staff/tasks/${id}`));
        const data = res?.data || res?.task || res;
        setTaskData(data);
      } catch (err) {
        console.warn('Cannot load task detail:', err);
      }
    }
    loadTaskInfo();
  }, [id]);

  useEffect(() => {
    try {
      const rawChecklist = localStorage.getItem(`inspection_checklist_${id}`);
      if (rawChecklist) {
        const parsed = JSON.parse(rawChecklist);
        const evals = Object.values(parsed.evaluations || {});
        setChecklistSummary({
          pass: evals.filter(v => v === 'PASS').length,
          fail: evals.filter(v => v === 'FAIL').length
        });
      }
      const rawEvidence = localStorage.getItem(`inspection_evidence_${id}`);
      if (rawEvidence) {
        const parsed = JSON.parse(rawEvidence);
        setEvidenceCount(parsed.photosCount || 2);
      }
    } catch {}
  }, [id]);

  const handleSubmitConclusion = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const caseId = taskData?.caseId || taskData?.case_id;

      // 1. Hoàn tất nhiệm vụ kiểm tra trên D1
      await request(`/staff/tasks/${id}/complete`, {
        method: 'POST',
        body: JSON.stringify({
          notes: remediationRequirements,
          conclusion,
          slaHours
        })
      });

      // 2. Cập nhật hồ sơ ca vụ tương ứng nếu có
      if (caseId) {
        await request(`/cases/${caseId}`, {
          method: 'PATCH',
          body: JSON.stringify({
            status: conclusion === 'NO_VIOLATION' ? 'RESOLVED' : 'IN_PROGRESS',
            priority: conclusion === 'VIOLATION' ? 'CRITICAL' : 'HIGH'
          })
        }).catch((err) => console.warn('[Case update notice]', err));
      }

      // 3. Xóa cache đệm tạm
      try {
        localStorage.removeItem(`inspection_checklist_${id}`);
        localStorage.removeItem(`inspection_evidence_${id}`);
      } catch {}

      alert('Đã lưu kết luận kiểm tra và hoàn tất nhiệm vụ thành công!');
      navigate('/staff');
    } catch (err) {
      console.error('[Submit Conclusion Error]', err);
      alert(err.message || 'Không thể lưu kết luận kiểm tra. Vui lòng kiểm tra lại kết nối và thử lại.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 max-w-lg mx-auto w-full pb-28 sm:pb-32">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          type="button"
          onClick={() => navigate(`/staff/tasks/${id}/evidence`)}
          className="text-xs font-bold text-[#57534E] hover:text-[#1C1917] min-h-[44px] flex items-center gap-1 cursor-pointer"
        >
          <span>← Quay lại Bằng chứng</span>
        </button>
        <span className="text-[11px] font-black uppercase text-[#0D6F64] bg-[#F0FDFA] px-2.5 py-1 rounded-lg border border-[#CCFBF1]">
          Bước 3 / 3
        </span>
      </div>

      <div>
        <span className="text-[11px] font-black uppercase tracking-wider text-[#9F241F]">
          Quyết Định Hiện Trường
        </span>
        <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
          Kết Luận Kiểm Tra
        </h1>
        <p className="text-xs text-[#57534E] mt-0.5">
          Tổng hợp kết quả checklist, bằng chứng số và thời hạn khắc phục của nhà thầu.
        </p>
      </div>

      {/* 1. Tóm tắt Kiểm Tra */}
      <div className="bg-[#FAFAF9] border border-[#E7E5E4] rounded-2xl p-4 grid grid-cols-3 gap-2 text-center">
        <div className="bg-white p-2.5 rounded-xl border border-[#E7E5E4]">
          <span className="text-xs font-bold text-[#15803D] block">Tiêu chí Đạt</span>
          <span className="text-xl font-black text-[#15803D]">{checklistSummary.pass}</span>
        </div>

        <div className="bg-white p-2.5 rounded-xl border border-[#E7E5E4]">
          <span className="text-xs font-bold text-[#9F241F] block">Chưa Đạt</span>
          <span className="text-xl font-black text-[#9F241F]">{checklistSummary.fail}</span>
        </div>

        <div className="bg-white p-2.5 rounded-xl border border-[#E7E5E4]">
          <span className="text-xs font-bold text-[#0D6F64] block">Ảnh Bằng Chứng</span>
          <span className="text-xl font-black text-[#0D6F64]">{evidenceCount}</span>
        </div>
      </div>

      {/* 2. Chọn Kết Quả Kiểm Tra */}
      <form onSubmit={handleSubmitConclusion} className="flex flex-col gap-4">
        <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-4 shadow-xs space-y-3">
          <label className="text-xs font-black text-[#1C1917] uppercase tracking-wider block">
            Kết quả kiểm tra thực địa *
          </label>

          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => setConclusion('NO_VIOLATION')}
              className={`p-3.5 rounded-xl border-2 text-left flex items-center justify-between cursor-pointer transition min-h-[52px] ${
                conclusion === 'NO_VIOLATION'
                  ? 'border-[#15803D] bg-[#F0FDF4] text-[#15803D] font-black shadow-xs ring-1 ring-[#15803D]'
                  : 'border-[#E7E5E4] bg-white text-[#57534E]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-base">🟢</span>
                <div>
                  <div className="text-xs font-bold">Không vi phạm quy chuẩn</div>
                  <div className="text-[11px] text-[#78716C]">Nhà thầu tuân thủ đầy đủ các biện pháp che chắn</div>
                </div>
              </div>
              {conclusion === 'NO_VIOLATION' && <span className="text-sm font-black">✓</span>}
            </button>

            <button
              type="button"
              onClick={() => setConclusion('ACTION_REQUIRED')}
              className={`p-3.5 rounded-xl border-2 text-left flex items-center justify-between cursor-pointer transition min-h-[52px] ${
                conclusion === 'ACTION_REQUIRED'
                  ? 'border-[#B45309] bg-[#FFFBEB] text-[#B45309] font-black shadow-xs ring-1 ring-[#B45309]'
                  : 'border-[#E7E5E4] bg-white text-[#57534E]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-base">🟡</span>
                <div>
                  <div className="text-xs font-bold">Cần khắc phục (Nhắc nhở)</div>
                  <div className="text-[11px] text-[#78716C]">Có lỗi nhỏ, yêu cầu khắc phục có thời hạn đối chứng</div>
                </div>
              </div>
              {conclusion === 'ACTION_REQUIRED' && <span className="text-sm font-black">✓</span>}
            </button>

            <button
              type="button"
              onClick={() => setConclusion('VIOLATION')}
              className={`p-3.5 rounded-xl border-2 text-left flex items-center justify-between cursor-pointer transition min-h-[52px] ${
                conclusion === 'VIOLATION'
                  ? 'border-[#9F241F] bg-[#FEF2F2] text-[#9F241F] font-black shadow-xs ring-1 ring-[#9F241F]'
                  : 'border-[#E7E5E4] bg-white text-[#57534E]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-base">🔴</span>
                <div>
                  <div className="text-xs font-bold">Vi phạm quy chuẩn môi trường</div>
                  <div className="text-[11px] text-[#78716C]">Lập biên bản vi phạm và kiến nghị xử phạt hành chính</div>
                </div>
              </div>
              {conclusion === 'VIOLATION' && <span className="text-sm font-black">✓</span>}
            </button>
          </div>
        </div>

        {/* 3. Yêu Cầu Khắc Phục & Thời Hạn SLA */}
        {conclusion !== 'NO_VIOLATION' && (
          <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-4 shadow-xs space-y-3">
            <div>
              <label className="text-xs font-black text-[#1C1917] block mb-1">
                Nội dung yêu cầu nhà thầu thực hiện *
              </label>
              <textarea
                rows={3}
                value={remediationRequirements}
                onChange={(e) => setRemediationRequirements(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-[#D6D3D1] bg-[#FAFAF9] text-[#1C1917] focus:outline-hidden focus:ring-1 focus:ring-[#9F241F]"
                required
              />
            </div>

            <div>
              <label className="text-xs font-black text-[#1C1917] block mb-1">
                Thời hạn cam kết khắc phục (SLA) *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { hours: 24, label: '24 giờ', note: 'Khẩn cấp' },
                  { hours: 48, label: '48 giờ', note: 'Tiêu chuẩn' },
                  { hours: 72, label: '72 giờ', note: 'Gia hạn' }
                ].map((opt) => (
                  <button
                    key={opt.hours}
                    type="button"
                    onClick={() => setSlaHours(opt.hours)}
                    className={`py-2.5 px-3 rounded-xl border transition cursor-pointer min-h-[48px] flex sm:flex-col items-center justify-between sm:justify-center gap-1 ${
                      slaHours === opt.hours
                        ? 'bg-[#9F241F] text-white border-[#9F241F] shadow-xs'
                        : 'bg-[#FAFAF9] text-[#57534E] border-[#E7E5E4] hover:bg-[#F5F5F4]'
                    }`}
                  >
                    <span className="text-xs font-black">{opt.label}</span>
                    <span className={`text-[10px] ${slaHours === opt.hours ? 'text-white/90' : 'text-[#78716C]'}`}>({opt.note})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Sticky Bottom Bar with Submit CTA */}
        <div className="sticky bottom-0 z-20 bg-white/95 border-t border-[#E7E5E4] py-3 -mx-4 px-4 sm:mx-0 sm:px-0 pb-safe">
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 px-5 bg-[#15803D] hover:bg-[#166534] active:bg-[#14532d] text-white font-black text-sm rounded-xl shadow-xs transition min-h-[50px] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <span>✓</span>
            <span>{submitting ? 'Đang lưu vào D1 SSOT & tạo Audit Log…' : 'Hoàn tất kiểm tra'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
