import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import SafeImage from '../../../../shared/components/SafeImage.jsx';
import {
  CheckCircle,
  AlertTriangle,
  Clock,
  MapPin,
  FileText,
  Camera,
  Printer,
  ChevronRight,
  ArrowLeft,
  ShieldCheck,
  UploadCloud,
  X,
  ExternalLink,
  Plus
} from 'lucide-react';

// 10 Tiêu chí kiểm soát phát tán bụi công trình theo QCVN 18:2021/BXD & QĐ 48/2021/QĐ-UBND
const DEFAULT_QCVN_CHECKLIST = [
  { id: 'tc-01', code: 'TC-01', title: '1. Hàng rào & Lưới che chắn bụi', standard: 'QCVN 18:2021/BXD', desc: 'Hàng rào cứng cao tối thiểu 2.5m, lưới bao che kín toàn bộ mặt ngoài tiếp giáp khu dân cư và trục đường giao thông.', status: 'Chưa đạt', notes: 'Lưới chắn bụi rách 30% diện tích mặt tiền tiếp giáp đường chính.' },
  { id: 'tc-02', code: 'TC-02', title: '2. Cầu rửa xe áp lực cao & Hố lắng', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Bố trí cầu rửa xe xịt rửa gầm/bánh xe áp lực cao và hố lắng gom bùn trước khi xe vận tải ra khỏi cổng.', status: 'Chưa đạt', notes: 'Chưa bố trí cầu rửa xe áp lực cao, nước rửa chảy tràn ra vỉa hè.' },
  { id: 'tc-03', code: 'TC-03', title: '3. Phun sương dập bụi tự động', standard: 'QCVN 05:2023/BTNMT', desc: 'Lắp đặt giàn phun sương tự động dọc chu vi hàng rào hoặc xe bồn tưới nước dập bụi định kỳ tối thiểu 3 lần/ngày.', status: 'Cần cải thiện', notes: 'Hệ thống phun sương hoạt động ngắt quãng vào giờ cao điểm.' },
  { id: 'tc-04', code: 'TC-04', title: '4. Che phủ bãi tập kết vật liệu rời', standard: 'QCVN 18:2021/BXD', desc: 'Bãi cát, đá, xi măng, xỉ than, đất đào tập kết trong khuôn viên phải được phủ bạt kín 100% chống phát tán.', status: 'Đạt', notes: 'Bãi cát đá đã phủ bạt bọc kín chống gió cuốn.' },
  { id: 'tc-05', code: 'TC-05', title: '5. Phủ bạt kín thùng xe chuyên chở', standard: 'Nghị định 45/2022/NĐ-CP', desc: 'Xe vận chuyển vật liệu xây dựng, đất phế thải phải có bạt che phủ kín thùng, không cơi nới, không chở quá tải.', status: 'Cần cải thiện', notes: 'Vẫn còn hiện tượng đất rơi vãi tại cổng số 2.' },
  { id: 'tc-06', code: 'TC-06', title: '6. Vệ sinh mặt đường tiếp giáp (≤50m)', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Nhà thầu phải bố trí công nhân quét dọn, rửa sạch mặt đường giao thông công cộng tiếp giáp cổng công trình.', status: 'Chưa đạt', notes: 'Bùn đất bám dày 2cm trên mặt đường dài 40m.' },
  { id: 'tc-07', code: 'TC-07', title: '7. Trạm quan trắc bụi PM2.5/PM10', standard: 'QCVN 05:2023/BTNMT', desc: 'Lắp đặt cảm biến quan trắc tự động kết nối truyền dữ liệu về hệ thống giám sát môi trường đô thị.', status: 'Đạt', notes: 'Trạm cảm biến DustGuard Station 01 đang truyền dữ liệu ổn định.' },
  { id: 'tc-08', code: 'TC-08', title: '8. Quản lý và đổ thải phế thải xây dựng', standard: 'Nghị định 08/2022/NĐ-CP', desc: 'Thu gom, phân loại phế thải tại nguồn, có hợp đồng vận chuyển và đổ thải tại bãi chôn lấp hợp pháp.', status: 'Đạt', notes: 'Có hợp đồng vận chuyển phế thải với Công ty Môi trường Đô thị.' },
  { id: 'tc-09', code: 'TC-09', title: '9. Giờ thi công hạn chế bụi/tiếng ồn', standard: 'QCVN 26:2010/BTNMT', desc: 'Không thực hiện các công đoạn phát tán bụi lớn vào giờ cao điểm giao thông (6h-8h, 17h-19h) và ban đêm (22h-6h).', status: 'Đạt', notes: 'Nhà thầu tuân thủ giờ vận chuyển đất ban đêm theo giấy phép.' },
  { id: 'tc-10', code: 'TC-10', title: '10. Biển báo & Đường dây nóng phản ánh', standard: 'QĐ 48/2021/QĐ-UBND', desc: 'Niêm yết công khai biển báo thông tin dự án, số điện thoại chỉ huy trưởng và đường dây nóng tiếp nhận phản ánh.', status: 'Đạt', notes: 'Đã gắn biển thông tin và mã QR tiếp nhận phản ánh công dân.' }
];

const SAMPLE_PRESET_PHOTOS = [
  { label: 'Xe tải không che bạt chở đất', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=600' },
  { label: 'Bụi mù mịt tại cổng chính', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600' },
  { label: 'Chưa bố trí cầu rửa xe', type: 'BEFORE', url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600' },
  { label: 'Đã lắp cầu rửa xe áp lực', type: 'AFTER', url: 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?w=600' },
  { label: 'Đã phủ bạt che chắn bãi cát', type: 'AFTER', url: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600' },
  { label: 'Đã bố trí xe bồn tưới nước', type: 'AFTER', url: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=600' }
];

export default function TaskDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [task, setTask] = useState(null);
  const [checklist, setChecklist] = useState(DEFAULT_QCVN_CHECKLIST);
  const [actionLoading, setActionLoading] = useState(false);
  const [successToast, setSuccessToast] = useState(null);

  // Upload Evidence Modal States
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadPhotoType, setUploadPhotoType] = useState('BEFORE');
  const [uploadUrl, setUploadUrl] = useState('');
  const [uploadCaption, setUploadCaption] = useState('Khảo sát thực tế hiện trạng công trình');
  const [uploadPreview, setUploadPreview] = useState('');

  // Complete Task Modal States
  const [completeModalOpen, setCompleteModalOpen] = useState(false);
  const [completeNotes, setCompleteNotes] = useState('Đã kiểm tra hiện trường và đánh giá 10 tiêu chí theo QCVN 18:2021/BXD.');

  // Escape key listener & body lock for modals
  useEffect(() => {
    const isAnyModalOpen = uploadModalOpen || completeModalOpen;
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setUploadModalOpen(false);
        setCompleteModalOpen(false);
      }
    };

    if (isAnyModalOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [uploadModalOpen, completeModalOpen]);

  const showToast = (msg) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  const fetchTaskDetail = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request(`/staff/tasks/${id || 'tsk-1'}/detail`);
      if (res?.data) {
        setTask(res.data);
      }
    } catch (err) {
      setError(err.message || 'Không thể tải chi tiết nhiệm vụ từ CSDL D1');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchTaskDetail();
  }, [fetchTaskDetail]);

  const handleToggleChecklist = (itemId, newStatus) => {
    setChecklist(prev => prev.map(item => item.id === itemId ? { ...item, status: newStatus } : item));
  };

  const handleQuickAllPass = () => {
    setChecklist(prev => prev.map(item => ({ ...item, status: 'Đạt' })));
    showToast('✓ Đã đánh dấu tất cả 10 tiêu chí Đạt chuẩn!');
  };

  const handleSaveChecklist = async () => {
    try {
      setActionLoading(true);
      const passedCount = checklist.filter(i => i.status === 'Đạt').length;
      await request(`/staff/tasks/${task.id}/checklist`, {
        method: 'POST',
        body: JSON.stringify({
          checklist,
          passedCount,
          notes: `Ghi nhận ${passedCount}/10 tiêu chí đạt chuẩn QCVN 18:2021/BXD.`
        })
      });
      await fetchTaskDetail();
      showToast(`✓ Đã lưu biên bản kiểm tra (${passedCount}/10 đạt chuẩn) vào CSDL D1!`);
    } catch (err) {
      alert('Lỗi lưu checklist: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result;
        setUploadPreview(base64);
        setUploadUrl(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadEvidence = async (e) => {
    e.preventDefault();
    const finalUrl = uploadPreview || uploadUrl.trim();
    if (!finalUrl) {
      alert('Vui lòng chọn tệp ảnh từ máy hoặc chọn ảnh mẫu.');
      return;
    }
    try {
      setActionLoading(true);
      await request(`/staff/tasks/${task.id}/evidence`, {
        method: 'POST',
        body: JSON.stringify({
          url: finalUrl,
          photoType: uploadPhotoType,
          caption: uploadCaption
        })
      });
      setUploadModalOpen(false);
      setUploadUrl('');
      setUploadPreview('');
      await fetchTaskDetail();
      showToast('✓ Đã tải lên và lưu trữ ảnh minh chứng kèm mã băm SHA-256 thành công!');
    } catch (err) {
      alert('Lỗi tải ảnh: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleCompleteTask = async (e) => {
    e?.preventDefault();
    try {
      setActionLoading(true);
      await request(`/staff/tasks/${task.id}/complete`, {
        method: 'POST',
        body: JSON.stringify({ notes: completeNotes })
      });
      setCompleteModalOpen(false);
      await fetchTaskDetail();
      showToast('✓ Đã hoàn tất nhiệm vụ và đồng bộ tiến độ hồ sơ vụ việc thành công!');
    } catch (err) {
      alert('Lỗi hoàn thành nhiệm vụ: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState message="Đang nạp chi tiết nhiệm vụ từ CSDL SQLite..." />;
  if (error) {
    return (
      <div className="bg-white border border-[#E7E5E4] rounded-3xl p-8 max-w-lg mx-auto text-center space-y-4 my-8 shadow-2xs">
        <div className="w-12 h-12 bg-[#FEF2F2] text-[#B91C1C] rounded-full flex items-center justify-center mx-auto text-xl font-bold">
          ⚠️
        </div>
        <div>
          <h2 className="text-lg font-black text-[#1C1917]">Lỗi tải nhiệm vụ</h2>
          <p className="text-xs text-[#78716C] mt-1">{error}</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
          <button
            onClick={fetchTaskDetail}
            className="w-full sm:w-auto px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs min-h-[44px] cursor-pointer"
          >
            Thử lại
          </button>
          <Link
            to="/staff/tasks"
            className="w-full sm:w-auto px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs min-h-[44px] flex items-center justify-center"
          >
            Quay lại danh sách nhiệm vụ
          </Link>
        </div>
      </div>
    );
  }
  if (!task) return null;

  const passedCount = checklist.filter(i => i.status === 'Đạt').length;
  const beforePhotos = task.evidences?.before || [];
  const afterPhotos = task.evidences?.after || [];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#161313] text-white px-5 py-3 rounded-2xl shadow-2xl border border-white/20 text-xs font-bold animate-slide-up flex items-center gap-2">
          <span>{successToast}</span>
        </div>
      )}

      {/* 1. Header & Navigation Breadcrumb */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="text-xs font-semibold text-[#78716C] flex items-center gap-1.5 flex-wrap">
            <Link to="/staff" className="hover:text-[#B91C1C]">Trang chính</Link>
            <ChevronRight size={12} />
            <Link to="/staff/tasks" className="hover:text-[#B91C1C]">Nhiệm vụ</Link>
            <ChevronRight size={12} />
            <span className="font-mono text-[#1C1917]">{task.code}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight mt-1">
            {task.title}
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Kiểm tra hiện trường, thẩm định 10 tiêu chí QCVN và đối chứng minh chứng SHA-256.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Link
            to="/staff/tasks"
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs flex items-center justify-center gap-1.5 min-h-[44px]"
          >
            <ArrowLeft size={14} />
            <span>Danh sách</span>
          </Link>

          <button
            type="button"
            onClick={() => navigate(`/staff/tasks/${task.id || id}/checklist`)}
            className="flex-1 sm:flex-none px-5 py-2.5 bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>📋</span>
            <span>Bắt đầu kiểm tra</span>
          </button>

          <button
            onClick={() => window.print()}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <Printer size={14} />
            <span>In biên bản A4</span>
          </button>

          <button
            onClick={() => navigate(`/staff/tasks/${task.id || id}/evidence`)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <Camera size={14} />
            <span>Ghi nhận ảnh</span>
          </button>

          {task.status !== 'Đã xong' ? (
            <button
              onClick={() => navigate(`/staff/tasks/${task.id || id}/conclusion`)}
              disabled={actionLoading}
              className="flex-1 sm:flex-none px-5 py-2.5 bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
            >
              <CheckCircle size={15} />
              <span>Kết luận kiểm tra</span>
            </button>
          ) : (
            <div className="px-4 py-2.5 bg-[#F0FDF4] border border-[#DCFCE7] text-[#16A34A] font-extrabold text-xs rounded-xl flex items-center gap-1.5 min-h-[44px]">
              <CheckCircle size={15} />
              <span>Đã hoàn thành</span>
            </div>
          )}
        </div>
      </div>

      {/* 2. Overview Metadata Strip (Mockup standard) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Card 1: Công trình */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-[#78716C] uppercase tracking-wider flex items-center gap-1">
            <MapPin size={13} className="text-[#B91C1C]" />
            <span>Công trình kiểm tra</span>
          </div>
          <div className="text-sm font-black text-[#1C1917] leading-snug break-words">
            {task.siteName}
          </div>
          <div className="text-xs text-[#57534E] break-words">
            {task.siteAddress}
          </div>
        </div>

        {/* Card 2: Hồ sơ vụ việc liên quan */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-[#78716C] uppercase tracking-wider flex items-center gap-1">
            <FileText size={13} className="text-[#2563EB]" />
            <span>Hồ sơ liên quan</span>
          </div>
          <div className="text-sm font-black text-[#1C1917] leading-snug">
            {task.caseCode}
          </div>
          <Link
            to={`/staff/cases/${task.caseId || 'case-01'}`}
            className="text-xs font-bold text-[#2563EB] hover:underline flex items-center gap-1"
          >
            <span>Xem hồ sơ 7 bước</span>
            <ExternalLink size={12} />
          </Link>
        </div>

        {/* Card 3: Thời hạn SLA 48h */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-[#78716C] uppercase tracking-wider flex items-center gap-1">
            <Clock size={13} className="text-[#EA580C]" />
            <span>Thời hạn SLA</span>
          </div>
          <div className="text-sm font-black text-[#1C1917]">
            {task.deadline}
          </div>
          <div className="text-[11px] font-bold text-[#EA580C]">
            Khảo sát hiện trường & hoàn tất trong 48h
          </div>
        </div>

        {/* Card 4: Trạng thái & Phụ trách */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-[#78716C] uppercase tracking-wider flex items-center gap-1">
            <ShieldCheck size={13} className="text-[#16A34A]" />
            <span>Cán bộ phụ trách</span>
          </div>
          <div className="text-sm font-black text-[#1C1917]">
            {task.assigneeName}
          </div>
          <div>
            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black ${
              task.status === 'Đã xong' ? 'bg-[#F0FDF4] text-[#16A34A]' : 'bg-[#EFF6FF] text-[#2563EB]'
            }`}>
              {task.status}
            </span>
          </div>
        </div>

      </div>

      {/* 3. Main Body: 10 QCVN Criteria Checklist + Evidence Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Col (7/12): Checklist 10 Tiêu chí QCVN 18:2021/BXD */}
        <div className="lg:col-span-7 bg-white border border-[#E7E5E4] rounded-3xl p-5 sm:p-6 shadow-2xs space-y-5">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#E7E5E4]">
            <div>
              <h2 className="text-base font-black text-[#1C1917] flex items-center gap-2">
                <span>📋</span>
                <span>Checklist 10 Tiêu chí Kiểm soát bụi (QCVN 18:2021)</span>
              </h2>
              <p className="text-xs text-[#78716C] mt-0.5">
                Đánh giá mức độ tuân thủ quy chuẩn kỹ thuật quốc gia về an toàn môi trường xây dựng.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-full text-xs font-black border ${
                passedCount >= 8 ? 'bg-[#F0FDF4] text-[#16A34A] border-[#DCFCE7]' : 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]'
              }`}>
                {passedCount}/10 Đạt chuẩn
              </span>
              <button
                type="button"
                onClick={handleQuickAllPass}
                className="px-3 py-1.5 bg-[#FAFAF9] hover:bg-[#E7E5E4] border border-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl min-h-[36px] cursor-pointer"
              >
                Đạt tất cả
              </button>
            </div>
          </div>

          <div className="space-y-3.5">
            {checklist.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition ${
                  item.status === 'Đạt'
                    ? 'bg-[#FAFAF9] border-[#E7E5E4]'
                    : item.status === 'Cần cải thiện'
                    ? 'bg-[#FFFBEB] border-[#FDE68A]'
                    : 'bg-[#FEF2F2] border-[#FECACA]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-[10px] font-black px-1.5 py-0.5 rounded bg-white border border-[#E7E5E4] text-[#1C1917]">
                        {item.code}
                      </span>
                      <span className="font-bold text-xs sm:text-sm text-[#1C1917]">
                        {item.title}
                      </span>
                      <span className="text-[10px] font-semibold text-[#78716C] bg-white/80 px-2 py-0.5 rounded border border-[#E7E5E4]">
                        {item.standard}
                      </span>
                    </div>
                    <p className="text-xs text-[#57534E] leading-relaxed">
                      {item.desc}
                    </p>
                    {item.notes && (
                      <div className="text-[11px] font-medium text-[#B91C1C] pt-1">
                        ⚠️ Ghi nhận: {item.notes}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-start">
                    <button
                      type="button"
                      onClick={() => handleToggleChecklist(item.id, 'Đạt')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition min-h-[36px] cursor-pointer ${
                        item.status === 'Đạt'
                          ? 'bg-[#16A34A] text-white shadow-xs'
                          : 'bg-white text-[#57534E] border border-[#E7E5E4] hover:bg-[#FAFAF9]'
                      }`}
                    >
                      Đạt
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleChecklist(item.id, 'Cần cải thiện')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition min-h-[36px] cursor-pointer ${
                        item.status === 'Cần cải thiện'
                          ? 'bg-[#D97706] text-white shadow-xs'
                          : 'bg-white text-[#57534E] border border-[#E7E5E4] hover:bg-[#FAFAF9]'
                      }`}
                    >
                      Cải thiện
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleChecklist(item.id, 'Chưa đạt')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition min-h-[36px] cursor-pointer ${
                        item.status === 'Chưa đạt'
                          ? 'bg-[#B91C1C] text-white shadow-xs'
                          : 'bg-white text-[#57534E] border border-[#E7E5E4] hover:bg-[#FAFAF9]'
                      }`}
                    >
                      Chưa đạt
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-[#E7E5E4] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleSaveChecklist}
              disabled={actionLoading}
              className="px-6 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-extrabold text-xs rounded-xl shadow-xs min-h-[44px] cursor-pointer flex items-center gap-1.5"
            >
              <CheckCircle size={15} />
              <span>Lưu biên bản kiểm tra 10 tiêu chí</span>
            </button>
          </div>

        </div>

        {/* Right Col (5/12): Minh chứng Before / After & SHA-256 Hashes */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Card: Minh chứng Hiện trường Before/After */}
          <div className="bg-white border border-[#E7E5E4] rounded-3xl p-5 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div className="flex items-center gap-2">
                <span className="text-base">📸</span>
                <h3 className="text-sm font-black text-[#1C1917]">Minh chứng Đối chứng Trước / Sau</h3>
              </div>
              <button
                type="button"
                onClick={() => setUploadModalOpen(true)}
                className="text-xs font-bold text-[#B91C1C] hover:underline flex items-center gap-1 min-h-[36px] cursor-pointer"
              >
                <Plus size={13} />
                <span>Thêm ảnh</span>
              </button>
            </div>

            {/* Before Photos */}
            <div className="space-y-2">
              <span className="text-xs font-black text-[#B91C1C] uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#B91C1C]" />
                <span>Trước khắc phục (Before)</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {beforePhotos.map((photo, idx) => (
                  <div key={idx} className="space-y-1.5 bg-[#FAFAF9] p-2.5 rounded-2xl border border-[#E7E5E4]">
                    <div className="aspect-4/3 rounded-xl overflow-hidden bg-[#E7E5E4]">
                      <SafeImage
                        src={photo.url}
                        alt={photo.title || 'Ảnh Trước'}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="text-[11px] font-bold text-[#1C1917] leading-snug break-words">
                      {photo.title || 'Hiện trạng phát tán bụi'}
                    </div>
                    <div className="font-mono text-[9px] text-[#78716C] truncate bg-white px-1.5 py-0.5 rounded border border-[#E7E5E4]" title={photo.sha256}>
                      SHA: {photo.sha256 ? `${photo.sha256.slice(0, 16)}...` : 'Chưa có hash'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* After Photos */}
            <div className="space-y-2 pt-2 border-t border-[#E7E5E4]">
              <span className="text-xs font-black text-[#16A34A] uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#16A34A]" />
                <span>Sau khắc phục (After)</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {afterPhotos.map((photo, idx) => (
                  <div key={idx} className="space-y-1.5 bg-[#FAFAF9] p-2.5 rounded-2xl border border-[#E7E5E4]">
                    <div className="aspect-4/3 rounded-xl overflow-hidden bg-[#E7E5E4]">
                      <SafeImage
                        src={photo.url}
                        alt={photo.title || 'Ảnh Sau'}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="text-[11px] font-bold text-[#1C1917] leading-snug break-words">
                      {photo.title || 'Đã khắc phục xong'}
                    </div>
                    <div className="font-mono text-[9px] text-[#78716C] truncate bg-white px-1.5 py-0.5 rounded border border-[#E7E5E4]" title={photo.sha256}>
                      SHA: {photo.sha256 ? `${photo.sha256.slice(0, 16)}...` : 'Chưa có hash'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Card: Pháp lý & Kiểm định tính toàn vẹn */}
          <div className="bg-[#FDFBF7] border border-[#E7E5E4] rounded-3xl p-5 shadow-2xs space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck size={18} className="text-[#0D6F64]" />
              <h3 className="text-sm font-black text-[#1C1917]">Kiểm định Tính toàn vẹn Bằng chứng</h3>
            </div>
            <p className="text-xs text-[#57534E] leading-relaxed">
              Toàn bộ ảnh chụp hiện trường và biên bản kiểm tra được gắn mã băm SHA-256 Web Crypto và dấu thời gian, phục vụ công tác thanh tra và xử lý vi phạm hành chính.
            </p>
            <div className="bg-white p-3 rounded-2xl border border-[#E7E5E4] text-[11px] space-y-1">
              <div className="flex justify-between font-bold">
                <span className="text-[#78716C]">Quy chuẩn áp dụng:</span>
                <span className="text-[#1C1917]">QCVN 18:2021/BXD</span>
              </div>
              <div className="flex justify-between font-bold">
                <span className="text-[#78716C]">Thời hạn khắc phục:</span>
                <span className="text-[#1C1917]">48 giờ (SLA)</span>
              </div>
              <div className="flex justify-between font-bold">
                <span className="text-[#78716C]">Tính toàn vẹn:</span>
                <span className="text-[#16A34A]">✓ Đã đối chứng D1 SSOT</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Upload Evidence Modal */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setUploadModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Tải lên ảnh minh chứng hiện trường</h3>
                <p className="text-xs text-[#78716C]">Lưu trữ vào CSDL D1 và tạo mã băm SHA-256</p>
              </div>
              <button
                type="button"
                onClick={() => setUploadModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleUploadEvidence} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">Loại ảnh minh chứng</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUploadPhotoType('BEFORE')}
                    className={`py-2 px-3 rounded-xl font-black text-xs border min-h-[44px] cursor-pointer ${
                      uploadPhotoType === 'BEFORE'
                        ? 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]'
                        : 'bg-white text-[#57534E] border-[#E7E5E4]'
                    }`}
                  >
                    Trước khắc phục (Before)
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadPhotoType('AFTER')}
                    className={`py-2 px-3 rounded-xl font-black text-xs border min-h-[44px] cursor-pointer ${
                      uploadPhotoType === 'AFTER'
                        ? 'bg-[#F0FDF4] text-[#16A34A] border-[#DCFCE7]'
                        : 'bg-white text-[#57534E] border-[#E7E5E4]'
                    }`}
                  >
                    Sau khắc phục (After)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">Mô tả hiện trường</label>
                <input
                  type="text"
                  value={uploadCaption}
                  onChange={e => setUploadCaption(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]"
                  placeholder="Ghi nhận hiện trạng phát tán bụi..."
                />
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">Chọn ảnh từ thiết bị</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="w-full text-xs text-[#57534E] file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-[#B91C1C] file:text-white hover:file:bg-[#991B1B] cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1.5">Hoặc chọn ảnh mẫu kiểm tra nhanh</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {SAMPLE_PRESET_PHOTOS.filter(p => p.type === uploadPhotoType).map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setUploadUrl(preset.url);
                        setUploadPreview(preset.url);
                        setUploadCaption(preset.label);
                      }}
                      className="p-2 text-left rounded-xl border border-[#E7E5E4] hover:border-[#B91C1C] bg-[#FAFAF9] text-[11px] font-medium text-[#1C1917] truncate min-h-[44px]"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {uploadPreview && (
                <div className="aspect-16/9 rounded-xl overflow-hidden bg-[#E7E5E4] border border-[#E7E5E4]">
                  <img src={uploadPreview} alt="Preview" className="w-full h-full object-cover" />
                </div>
              )}

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]"
                >
                  Lưu ảnh minh chứng
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Complete Task Modal */}
      {completeModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setCompleteModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Hoàn tất nhiệm vụ kiểm tra</h3>
                <p className="text-xs text-[#78716C]">Xác nhận kết quả và đồng bộ trạng thái về hồ sơ vụ việc</p>
              </div>
              <button
                type="button"
                onClick={() => setCompleteModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCompleteTask} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Ghi chú hoàn tất & Nghiệm thu</label>
                <textarea
                  value={completeNotes}
                  onChange={e => setCompleteNotes(e.target.value)}
                  rows={4}
                  required
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#16A34A] focus:outline-none"
                />
              </div>

              <div className="p-3 bg-[#F0FDF4] border border-[#DCFCE7] rounded-xl text-[11px] text-[#16A34A] font-medium space-y-1">
                <div>✓ Nhiệm vụ sẽ được cập nhật sang trạng thái Hoàn thành.</div>
                <div>✓ Lịch sử xử lý sẽ được ghi vào tiến trình hồ sơ vụ việc {task.caseCode}.</div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setCompleteModalOpen(false)}
                  className="px-4 py-2 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2 bg-[#16A34A] hover:bg-[#15803D] text-white rounded-xl font-extrabold cursor-pointer shadow-xs min-h-[44px]"
                >
                  Xác nhận hoàn thành
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}