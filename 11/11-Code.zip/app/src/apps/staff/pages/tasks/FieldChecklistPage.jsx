import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';

const STANDARD_FIELD_CRITERIA = [
  {
    id: 'crit-1',
    title: 'Hàng rào & Lưới che chắn bụi',
    desc: 'Lưới bao che kín tối thiểu 2.5m mặt tiền tiếp giáp khu dân cư và đường giao thông.'
  },
  {
    id: 'crit-2',
    title: 'Phun nước / Phun sương dập bụi',
    desc: 'Có giàn phun sương hoặc xe bồn tưới nước ẩm đường nội bộ định kỳ.'
  },
  {
    id: 'crit-3',
    title: 'Cầu rửa xe & Hố lắng bánh xe',
    desc: 'Xe chở vật liệu trước khi ra đường phải qua vòi xịt rửa bùn đất sạch bánh.'
  },
  {
    id: 'crit-4',
    title: 'Che phủ bạt bãi vật liệu rời',
    desc: 'Bãi cát, đá, xi măng tập kết phải được phủ bạt kín 100% chống gió cuốn.'
  },
  {
    id: 'crit-5',
    title: 'Thùng xe vận chuyển che bạt kín',
    desc: 'Xe chở đất đá phế thải phủ bạt kín thùng, không chở quá tải làm rơi vãi.'
  },
  {
    id: 'crit-6',
    title: 'Vệ sinh mặt đường tiếp giáp cổng',
    desc: 'Mặt đường công cộng 50m quanh cổng công trình không bị dính bùn đất trơn trượt.'
  }
];

export default function FieldChecklistPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  // State: item id -> 'PASS' | 'FAIL' | 'NA'
  const [evaluations, setEvaluations] = useState({
    'crit-1': 'FAIL',
    'crit-2': 'PASS',
    'crit-3': 'FAIL',
    'crit-4': 'PASS',
    'crit-5': 'FAIL',
    'crit-6': 'FAIL'
  });

  const [notes, setNotes] = useState({
    'crit-1': 'Lưới bao che rách ở đoạn cổng phụ số 2.',
    'crit-3': 'Chưa vận hành vòi xịt gầm xe lúc cao điểm.',
    'crit-5': 'Xe tải chở đất có bạt nhưng che hở 30cm phía sau.'
  });

  const [saving, setSaving] = useState(false);

  const handleSelectStatus = (critId, status) => {
    setEvaluations(prev => ({ ...prev, [critId]: status }));
  };

  const handleNoteChange = (critId, text) => {
    setNotes(prev => ({ ...prev, [critId]: text }));
  };

  const handleProceedToEvidence = async () => {
    setSaving(true);
    const passCount = Object.values(evaluations).filter(v => v === 'PASS').length;
    const payload = {
      taskId: id,
      evaluations,
      notes,
      passedCount: passCount,
      totalCount: STANDARD_FIELD_CRITERIA.length,
      updatedAt: new Date().toISOString()
    };

    // 1. Cache to localStorage for offline resilience
    try {
      localStorage.setItem(`inspection_checklist_${id}`, JSON.stringify(payload));
    } catch {}

    // 2. Persist to D1 SSOT via Worker API
    try {
      await request(`/staff/tasks/${id}/checklist`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.warn('[FieldChecklist] Saved locally, D1 error:', err);
    } finally {
      setSaving(false);
      navigate(`/staff/tasks/${id}/evidence`);
    }
  };

  const passCount = Object.values(evaluations).filter(v => v === 'PASS').length;
  const failCount = Object.values(evaluations).filter(v => v === 'FAIL').length;

  return (
    <div className="flex flex-col gap-4 max-w-lg mx-auto w-full pb-28 sm:pb-32">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          type="button"
          onClick={() => navigate(`/staff/tasks/${id}`)}
          className="text-xs font-bold text-[#57534E] hover:text-[#1C1917] min-h-[44px] flex items-center gap-1 cursor-pointer"
        >
          <span>← Quay lại nhiệm vụ</span>
        </button>
        <span className="text-[11px] font-black uppercase text-[#0D6F64] bg-[#F0FDFA] px-2.5 py-1 rounded-lg border border-[#CCFBF1]">
          Bước 1 / 3
        </span>
      </div>

      <div>
        <span className="text-[11px] font-black uppercase tracking-wider text-[#9F241F]">
          QCVN 18:2021/BXD • QĐ 48/2021
        </span>
        <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
          Checklist Hiện Trường
        </h1>
        <p className="text-xs text-[#57534E] mt-0.5">
          Thao tác nhanh 1 chạm ngoài hiện trường: {passCount} Đạt • {failCount} Chưa đạt.
        </p>
      </div>

      {/* Checklist items list */}
      <div className="flex flex-col gap-3">
        {STANDARD_FIELD_CRITERIA.map((crit, idx) => {
          const currentVal = evaluations[crit.id] || 'PASS';
          return (
            <div
              key={crit.id}
              className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col gap-3"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#1C1917] text-white text-[10px] font-black flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <h2 className="font-black text-sm text-[#1C1917] leading-snug">
                    {crit.title}
                  </h2>
                </div>
                <p className="text-[11px] text-[#57534E] mt-1 pl-7 leading-snug">
                  {crit.desc}
                </p>
              </div>

              {/* 3 Large Touch Buttons: Pass / Fail / NA */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleSelectStatus(crit.id, 'PASS')}
                  className={`py-3 px-2 rounded-xl text-xs font-black transition min-h-[46px] flex items-center justify-center gap-1 cursor-pointer border ${
                    currentVal === 'PASS'
                      ? 'bg-[#15803D] text-white border-[#15803D] shadow-xs'
                      : 'bg-[#FAFAF9] text-[#57534E] border-[#E7E5E4] hover:bg-[#F5F5F4]'
                  }`}
                >
                  <span>✓</span>
                  <span>Đạt</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectStatus(crit.id, 'FAIL')}
                  className={`py-3 px-2 rounded-xl text-xs font-black transition min-h-[46px] flex items-center justify-center gap-1 cursor-pointer border ${
                    currentVal === 'FAIL'
                      ? 'bg-[#9F241F] text-white border-[#9F241F] shadow-xs'
                      : 'bg-[#FAFAF9] text-[#57534E] border-[#E7E5E4] hover:bg-[#F5F5F4]'
                  }`}
                >
                  <span>✕</span>
                  <span>Chưa đạt</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectStatus(crit.id, 'NA')}
                  className={`py-3 px-2 rounded-xl text-xs font-bold transition min-h-[46px] flex items-center justify-center gap-1 cursor-pointer border ${
                    currentVal === 'NA'
                      ? 'bg-[#57534E] text-white border-[#57534E] shadow-xs'
                      : 'bg-[#FAFAF9] text-[#78716C] border-[#E7E5E4] hover:bg-[#F5F5F4]'
                  }`}
                >
                  <span>-</span>
                  <span>K.áp dụng</span>
                </button>
              </div>

              {/* Quick Note if FAIL */}
              {currentVal === 'FAIL' && (
                <div className="pt-1">
                  <input
                    type="text"
                    value={notes[crit.id] || ''}
                    onChange={(e) => handleNoteChange(crit.id, e.target.value)}
                    placeholder="Ghi chú nhanh lỗi hiện trường…"
                    className="w-full text-xs px-3 py-2.5 rounded-xl border border-[#FCA5A5] bg-[#FEF2F2]/40 text-[#1C1917] placeholder-[#A8A29E] focus:outline-hidden focus:ring-1 focus:ring-[#9F241F] min-h-[44px]"
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sticky Bottom Bar with CTA */}
      <div className="sticky bottom-0 z-20 bg-white/95 border-t border-[#E7E5E4] py-3 -mx-4 px-4 sm:mx-0 sm:px-0 pb-safe">
        <button
          type="button"
          onClick={handleProceedToEvidence}
          className="w-full py-3.5 px-5 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-sm rounded-xl shadow-xs transition min-h-[50px] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Chụp ảnh bằng chứng (Bước 2)</span>
          <span>➔</span>
        </button>
      </div>
    </div>
  );
}
