import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { computeImageHash } from '../../../../lib/image-integrity.js';
import { compressImage } from '../../../../lib/image-compressor.js';
import { request } from '../../../../lib/api/request.js';

export default function FieldEvidencePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [photos, setPhotos] = useState([
    {
      id: 'ph-1',
      url: 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=600',
      caption: 'Xe ben không rửa bánh trước khi ra khỏi cổng số 1.',
      isViolation: true,
      time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      hash: '9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a',
      coords: '21.0313°B, 105.7831°Đ'
    }
  ]);

  const [currentCoords, setCurrentCoords] = useState('21.0313°B, 105.7831°Đ');
  const [capturing, setCapturing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const [currentNote, setCurrentNote] = useState('');
  const [currentIsViolation, setCurrentIsViolation] = useState(true);

  // Auto-acquire GPS
  useEffect(() => {
    if (navigator?.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const { latitude, longitude } = pos.coords;
        setCurrentCoords(`${latitude.toFixed(4)}°B, ${longitude.toFixed(4)}°Đ`);
      }, () => {});
    }
  }, []);

  const handleCapturePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setCapturing(true);
      const compressed = await compressImage(file, { maxSizeKB: 400, maxWidthOrHeight: 1600 }).catch(() => file);
      const buffer = await file.arrayBuffer();
      const hash = await computeImageHash(buffer).catch(() => 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
      const dataUrl = compressed.dataUrl || URL.createObjectURL(file);

      const newPhoto = {
        id: `ph-${Date.now()}`,
        url: dataUrl,
        rawBase64: compressed.dataUrl || null,
        caption: currentNote.trim() || 'Ghi nhận hiện trường thực địa vi phạm bụi.',
        isViolation: currentIsViolation,
        time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        hash: hash.slice(0, 32),
        coords: currentCoords
      };

      setPhotos(prev => [newPhoto, ...prev]);
      setCurrentNote('');
    } catch {
      alert('Không thể xử lý ảnh hiện trường.');
    } finally {
      setCapturing(false);
    }
  };

  const handleVoiceToggle = () => {
    if (voiceListening) {
      setVoiceListening(false);
      return;
    }

    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Trình duyệt hiện tại không hỗ trợ nhận diện giọng nói trực tiếp. Vui lòng gõ ghi chú bằng bàn phím.');
      return;
    }

    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'vi-VN';
      recognition.onstart = () => setVoiceListening(true);
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setCurrentNote(prev => prev ? `${prev} ${transcript}` : transcript);
      };
      recognition.onend = () => setVoiceListening(false);
      recognition.start();
    } catch {
      setVoiceListening(false);
    }
  };

  const handleProceedToConclusion = async () => {
    setSubmitting(true);
    const uploadedPhotos = [];

    for (const p of photos) {
      let finalUrl = p.url;
      // If photo is newly captured with base64 dataUrl, upload to R2
      if (p.rawBase64 && p.rawBase64.startsWith('data:')) {
        try {
          const uploadRes = await request('/upload', {
            method: 'POST',
            body: JSON.stringify({
              fileName: `field_ev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.jpg`,
              mimeType: 'image/jpeg',
              fileData: p.rawBase64,
              category: 'field_evidence'
            })
          });
          if (uploadRes?.data?.url) {
            finalUrl = uploadRes.data.url;
          }
        } catch (err) {
          console.warn('[FieldEvidence] Upload R2 error, keeping dataUrl:', err);
        }
      }

      // Persist evidence record into D1
      try {
        await request(`/staff/tasks/${id}/evidence`, {
          method: 'POST',
          body: JSON.stringify({
            url: finalUrl,
            fileUrl: finalUrl,
            photoType: p.isViolation ? 'BEFORE' : 'AFTER',
            caption: p.caption,
            sha256: p.hash
          })
        });
      } catch (err) {
        console.warn('[FieldEvidence] D1 evidence sync error:', err);
      }

      uploadedPhotos.push({
        ...p,
        url: finalUrl
      });
    }

    const payload = {
      taskId: id,
      photosCount: uploadedPhotos.length,
      violationPhotosCount: uploadedPhotos.filter(p => p.isViolation).length,
      photos: uploadedPhotos.map(p => ({
        url: p.url,
        caption: p.caption,
        isViolation: p.isViolation,
        hash: p.hash,
        time: p.time,
        coords: p.coords
      }))
    };

    try {
      localStorage.setItem(`inspection_evidence_${id}`, JSON.stringify(payload));
    } catch {}

    setSubmitting(false);
    navigate(`/staff/tasks/${id}/conclusion`);
  };

  return (
    <div className="flex flex-col gap-4 max-w-lg mx-auto w-full pb-28 sm:pb-32">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          type="button"
          onClick={() => navigate(`/staff/tasks/${id}/checklist`)}
          className="text-xs font-bold text-[#57534E] hover:text-[#1C1917] min-h-[44px] flex items-center gap-1 cursor-pointer"
        >
          <span>← Quay lại Checklist</span>
        </button>
        <span className="text-[11px] font-black uppercase text-[#0D6F64] bg-[#F0FDFA] px-2.5 py-1 rounded-lg border border-[#CCFBF1]">
          Bước 2 / 3
        </span>
      </div>

      <div>
        <span className="text-[11px] font-black uppercase tracking-wider text-[#9F241F]">
          Camera-First • Định danh SHA-256
        </span>
        <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
          Ghi Nhận Bằng Chứng
        </h1>
        <p className="text-xs text-[#57534E] mt-0.5">
          Ảnh lưu trữ kèm thời gian thực, tọa độ GPS và băm mật mã toàn vẹn.
        </p>
      </div>

      {/* Camera Capture Section */}
      <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col gap-3">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleCapturePhoto}
          className="hidden"
        />

        {/* Big Touch Button to Take Photo */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={capturing}
          className="w-full py-4 px-4 bg-[#9F241F] hover:bg-[#7F1D1D] active:bg-[#681717] text-white font-black text-sm rounded-xl shadow-xs transition min-h-[54px] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span className="text-xl">📷</span>
          <span>{capturing ? 'Đang xử lý ảnh…' : 'Chụp ảnh hiện trường mới'}</span>
        </button>

        {/* Note input + Voice to text button */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={currentNote}
            onChange={(e) => setCurrentNote(e.target.value)}
            placeholder="Ghi chú ảnh hoặc bấm mic nói…"
            className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-[#D6D3D1] bg-[#FAFAF9] text-[#1C1917] placeholder-[#A8A29E] focus:outline-hidden focus:ring-1 focus:ring-[#9F241F] min-h-[44px]"
          />
          <button
            type="button"
            onClick={handleVoiceToggle}
            className={`px-3 py-2.5 rounded-xl border text-xs font-bold transition min-h-[44px] flex items-center gap-1 cursor-pointer ${
              voiceListening
                ? 'bg-[#FEF2F2] border-[#FCA5A5] text-[#9F241F] animate-pulse'
                : 'bg-[#FAFAF9] border-[#D6D3D1] text-[#57534E] hover:bg-[#F5F5F4]'
            }`}
            title="Nhập giọng nói voice-to-text"
          >
            <span>🎙️</span>
            <span>{voiceListening ? 'Đang nghe…' : 'Mic'}</span>
          </button>
        </div>

        {/* Checkbox: Mark as Violation Evidence */}
        <label className="flex items-center gap-2 p-2.5 bg-[#FEF2F2] border border-[#FCA5A5]/60 rounded-xl cursor-pointer select-none">
          <input
            type="checkbox"
            checked={currentIsViolation}
            onChange={(e) => setCurrentIsViolation(e.target.checked)}
            className="w-4 h-4 text-[#9F241F] rounded border-[#FCA5A5] focus:ring-[#9F241F] cursor-pointer"
          />
          <span className="text-xs font-bold text-[#9F241F]">
            Đánh dấu ảnh là bằng chứng vi phạm
          </span>
        </label>
      </div>

      {/* List of Captured Photos */}
      <div className="flex flex-col gap-3">
        <div className="text-xs font-black uppercase tracking-wider text-[#78716C] px-1 flex items-center justify-between">
          <span>Ảnh đã ghi nhận ({photos.length})</span>
          <span className="text-[11px] font-mono text-[#0D6F64]">📍 {currentCoords}</span>
        </div>

        {photos.map((photo) => (
          <div
            key={photo.id}
            className="bg-white border-2 border-[#E7E5E4] rounded-2xl overflow-hidden shadow-xs flex flex-col"
          >
            <div className="relative h-44 bg-[#1C1917] overflow-hidden">
              <img src={photo.url} alt="Bằng chứng hiện trường" className="w-full h-full object-cover" />
              {photo.isViolation && (
                <div className="absolute top-2 left-2 bg-[#9F241F] text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow">
                  Bằng chứng vi phạm
                </div>
              )}
              <div className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] font-mono px-2 py-0.5 rounded">
                SHA: {photo.hash.slice(0, 12)}…
              </div>
            </div>

            <div className="p-3 text-xs space-y-1">
              <p className="font-bold text-[#1C1917] m-0 leading-snug break-words">
                {photo.caption}
              </p>
              <div className="flex items-center justify-between text-[11px] text-[#78716C] pt-1">
                <span>🕒 {photo.time}</span>
                <span>📍 {photo.coords}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Sticky Bottom Bar with CTA */}
      <div className="sticky bottom-0 z-20 bg-white/95 border-t border-[#E7E5E4] py-3 -mx-4 px-4 sm:mx-0 sm:px-0 pb-safe">
        <button
          type="button"
          onClick={handleProceedToConclusion}
          className="w-full py-3.5 px-5 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-sm rounded-xl shadow-xs transition min-h-[50px] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Lập kết luận kiểm tra (Bước 3)</span>
          <span>➔</span>
        </button>
      </div>
    </div>
  );
}
