import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

export default function TasksListPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & State
  const [activeTab, setActiveTab] = useState('ALL'); // ALL | TODAY | NEAR | OVERDUE | DONE
  const [currentPage, setCurrentPage] = useState(1);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // KPI Data from D1 API
  const [kpis, setKpis] = useState({
    todayCount: 12,
    nearDeadlineCount: 18,
    overdueCount: 7,
    doneCount: 36
  });

  // Tasks List Data from D1 API
  const [tasks, setTasks] = useState([]);
  const [totalCount, setTotalCount] = useState(0);

  // Right Side Schedule Data from D1 API
  const [scheduleToday, setScheduleToday] = useState([]);

  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/tasks/summary');
      if (res?.data) {
        setKpis(res.data);
      }
    } catch (err) {
      console.error('Error fetching tasks summary:', err);
    }
  }, []);

  const fetchTasksList = useCallback(async () => {
    try {
      const res = await request(`/staff/tasks/list?tab=${activeTab}&page=${currentPage}&limit=10`);
      if (res?.data?.items) {
        setTasks(res.data.items);
        setTotalCount(res.data.total ?? res.data.items.length);
      }
    } catch (err) {
      console.error('Error fetching tasks list:', err);
    }
  }, [activeTab, currentPage]);

  const fetchSchedule = useCallback(async () => {
    try {
      const res = await request('/staff/tasks/schedule');
      if (res?.data?.items) {
        setScheduleToday(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching schedule:', err);
    }
  }, []);

  const loadAll = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchTasksList(), fetchSchedule()]);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách nhiệm vụ từ D1/SQLite');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchTasksList, fetchSchedule]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    fetchTasksList();
  }, [fetchTasksList]);

  // Edit Modal State
  const [editModal, setEditModal] = useState({ open: false, task: null, title: '', assignee: '' });
  // Due Date Modal State
  const [dueModal, setDueModal] = useState({ open: false, task: null, dueDate: '' });
  const [actionLoading, setActionLoading] = useState(false);

  // Escape key listener & body lock for modals
  useEffect(() => {
    const isAnyModalOpen = editModal.open || dueModal.open || createModalOpen;
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setEditModal({ open: false, task: null, title: '', assignee: '' });
        setDueModal({ open: false, task: null, dueDate: '' });
        setCreateModalOpen(false);
      }
    };

    if (isAnyModalOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [editModal.open, dueModal.open, createModalOpen]);

  const handleOpenEdit = (task) => {
    setEditModal({
      open: true,
      task,
      title: task.title,
      assignee: task.assigneeName || 'Nguyễn Minh An'
    });
  };

  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!editModal.task) return;
    try {
      setActionLoading(true);
      await request(`/staff/tasks/${editModal.task.id}/update`, {
        method: 'PATCH',
        body: JSON.stringify({
          title: editModal.title,
          assignedTo: editModal.assignee
        })
      });
      setEditModal({ open: false, task: null, title: '', assignee: '' });
      await loadAll();
    } catch (err) {
      alert('Lỗi cập nhật nhiệm vụ: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenDueModal = (task) => {
    setDueModal({
      open: true,
      task,
      dueDate: new Date(Date.now() + 48 * 3600 * 1000).toISOString().split('T')[0]
    });
  };

  const handleSaveDueDate = async (e) => {
    e.preventDefault();
    if (!dueModal.task) return;
    try {
      setActionLoading(true);
      await request(`/staff/tasks/${dueModal.task.id}/update`, {
        method: 'PATCH',
        body: JSON.stringify({
          dueAt: dueModal.dueDate
        })
      });
      setDueModal({ open: false, task: null, dueDate: '' });
      await loadAll();
    } catch (err) {
      alert('Lỗi đổi hạn: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleMarkDone = async (taskId) => {
    try {
      await request(`/staff/tasks/${taskId}/complete`, {
        method: 'POST',
        body: JSON.stringify({ notes: 'Hoàn thành từ danh sách' })
      });
      await loadAll();
    } catch (err) {
      alert('Lỗi cập nhật: ' + err.message);
    }
  };

  if (loading) return <LoadingState message="Đang nạp danh sách nhiệm vụ từ CSDL SQLite..." />;
  if (error) return <ErrorState title="Lỗi tải nhiệm vụ" message={error} onRetry={loadAll} />;

  return (
    <div className="space-y-5">
      
      {/* 1. Header & Top Actions (Mockup 8) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Nhiệm vụ được giao
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Quản lý việc cần làm, thời hạn và hồ sơ liên quan.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setCreateModalOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer whitespace-nowrap"
          >
            <span className="text-sm leading-none">+</span>
            <span>Tạo nhiệm vụ</span>
          </button>

          <button
            onClick={() => alert('Mở lịch công tác tuần')}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer whitespace-nowrap"
          >
            <span>📅</span>
            <span>Xem lịch</span>
          </button>
        </div>
      </div>

      {/* 2. Top 4 Metric KPI Cards (Mockup 8) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* KPI 1: Việc hôm nay */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#EFF6FF] text-[#2563EB] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <line x1="16" y1="13" x2="8" y2="13" />
              <line x1="16" y1="17" x2="8" y2="17" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Việc hôm nay</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.todayCount}</div>
            <div className="text-[10px] font-bold text-[#2563EB] mt-0.5">Cần xử lý trong ngày</div>
          </div>
        </div>

        {/* KPI 2: Gần đến hạn */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FFF7ED] text-[#EA580C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Gần đến hạn</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.nearDeadlineCount}</div>
            <div className="text-[10px] font-bold text-[#78716C] mt-0.5">Trong 3 ngày tới</div>
          </div>
        </div>

        {/* KPI 3: Quá hạn */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FEF2F2] text-[#B91C1C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Quá hạn</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.overdueCount}</div>
            <div className="text-[10px] font-bold text-[#B91C1C] mt-0.5">Cần xử lý ngay</div>
          </div>
        </div>

        {/* KPI 4: Đã xong */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#F0FDF4] text-[#16A34A] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Đã xong</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.doneCount}</div>
            <div className="text-[10px] font-bold text-[#16A34A] mt-0.5">Hoàn thành</div>
          </div>
        </div>

      </div>

      {/* 3. Filter Tabs (Mockup 8) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { label: 'Tất cả', val: 'ALL' },
          { label: 'Hôm nay', val: 'TODAY' },
          { label: 'Gần đến hạn', val: 'NEAR' },
          { label: 'Quá hạn', val: 'OVERDUE' },
          { label: 'Đã xong', val: 'DONE' }
        ].map(tab => (
          <button
            key={tab.val}
            onClick={() => { setActiveTab(tab.val); setCurrentPage(1); }}
            className={`px-3.5 py-2 rounded-full text-xs font-bold transition whitespace-nowrap cursor-pointer min-h-[44px] flex items-center justify-center ${
              activeTab === tab.val
                ? 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]'
                : 'bg-white text-[#57534E] border border-[#E7E5E4] hover:bg-[#FAFAF9]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 4. Main Body: Optimized Layout 75% Table + 25% Schedule Panel (Mockup 8) */}
      <div className="flex flex-col xl:flex-row gap-5 items-start">
        
        {/* Main Table: Bảng danh sách nhiệm vụ */}
        <div className="flex-1 min-w-0 w-full bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-4">
          
          <div className="hidden md:block overflow-x-auto rounded-xl border border-[#E7E5E4]">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#FAFAF9] border-b border-[#E7E5E4] text-[#57534E] text-[11px] uppercase font-black tracking-wider">
                  <th className="py-3 px-3 min-w-[160px] whitespace-nowrap">Nhiệm vụ</th>
                  <th className="py-3 px-3 text-center w-24 whitespace-nowrap">Hồ sơ</th>
                  <th className="py-3 px-3 min-w-[140px] whitespace-nowrap">Công trình</th>
                  <th className="py-3 px-3 min-w-[100px] whitespace-nowrap">Hạn</th>
                  <th className="py-3 px-3 min-w-[120px] whitespace-nowrap">Phụ trách</th>
                  <th className="py-3 px-3 text-center w-28 whitespace-nowrap">Trạng thái</th>
                  <th className="py-3 px-3 text-right min-w-[180px] whitespace-nowrap">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F5F5F4] bg-white">
                {tasks.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-xs text-[#78716C]">
                      Chưa có nhiệm vụ nào trong danh mục này.
                    </td>
                  </tr>
                ) : (
                  tasks.map(t => (
                    <tr key={t.id} className="hover:bg-[#FDFBF7] transition">
                      
                      {/* 1. Nhiệm vụ */}
                      <td className="py-3.5 px-3 min-w-0 align-middle">
                        <div className="font-bold text-[#1C1917] leading-snug break-words">
                          {t.title}
                        </div>
                        <div className="text-[10px] text-[#78716C] mt-0.5 break-words">
                          {t.subtitle}
                        </div>
                      </td>

                      {/* 2. Hồ sơ Chip */}
                      <td className="py-3.5 px-3 text-center align-middle">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-[#FED7AA] bg-[#FFF7ED] text-[#EA580C] text-[10px] font-bold whitespace-nowrap">
                          <span>📁</span>
                          <span>{t.casesCount} hồ sơ</span>
                        </span>
                      </td>

                      {/* 3. Công trình */}
                      <td className="py-3.5 px-3 text-[11px] font-medium text-[#1C1917] align-middle break-words">
                        {t.siteName}
                      </td>

                      {/* 4. Hạn */}
                      <td className="py-3.5 px-3 font-mono text-[11px] whitespace-nowrap align-middle">
                        <div className={t.status === 'Quá hạn' || t.status === 'Gần đến hạn' ? 'font-bold text-[#B91C1C]' : 'text-[#78716C]'}>
                          {typeof t.deadline === 'string' ? (t.deadline.split(' ')[0] || t.deadline) : (t.deadline || '—')}
                        </div>
                        <div className="text-[9px] text-[#78716C]">{typeof t.deadline === 'string' ? (t.deadline.split(' ')[1] || '') : ''}</div>
                      </td>

                      {/* 5. Phụ trách */}
                      <td className="py-3.5 px-3 text-[11px] font-medium text-[#57534E] whitespace-nowrap align-middle">
                        {t.assigneeName}
                      </td>

                      {/* 6. Trạng thái */}
                      <td className="py-3.5 px-3 text-center align-middle">
                        <span className={`inline-block px-2.5 py-1 rounded text-[10px] font-black whitespace-nowrap ${
                          t.status === 'Quá hạn'
                            ? 'bg-[#FEF2F2] text-[#B91C1C]'
                            : t.status === 'Gần đến hạn'
                            ? 'bg-[#FFF7ED] text-[#EA580C]'
                            : t.status === 'Đã xong'
                            ? 'bg-[#F0FDF4] text-[#16A34A]'
                            : 'bg-[#EFF6FF] text-[#2563EB]'
                        }`}>
                          {t.status}
                        </span>
                      </td>

                      {/* 7. Thao tác */}
                      <td className="py-3.5 px-3 text-right whitespace-nowrap align-middle">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link
                            to={`/staff/tasks/${t.id}`}
                            className="px-3 py-1.5 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#1C1917] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer flex items-center justify-center"
                          >
                            Mở
                          </Link>
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(t)}
                            className="px-3 py-1.5 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#57534E] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer flex items-center justify-center"
                          >
                            Sửa
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenDueModal(t)}
                            className="px-3 py-1.5 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#57534E] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer flex items-center justify-center"
                          >
                            Đổi hạn
                          </button>
                          {t.status !== 'Đã xong' ? (
                            <button
                              type="button"
                              onClick={() => handleMarkDone(t.id)}
                              className="px-3.5 py-1.5 rounded-xl border border-[#DCFCE7] bg-[#F0FDF4] text-[#16A34A] text-xs font-extrabold hover:bg-[#DCFCE7] min-h-[44px] cursor-pointer flex items-center justify-center"
                            >
                              Hoàn thành
                            </button>
                          ) : (
                            <span className="px-3 py-1.5 text-xs font-bold text-[#16A34A] min-h-[44px] flex items-center justify-center">✓ Xong</span>
                          )}
                        </div>
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View (<md) */}
          <div className="md:hidden flex flex-col gap-3">
            {tasks.length === 0 ? (
              <div className="py-8 text-center text-xs text-[#78716C] bg-[#FAFAF9] rounded-xl border border-[#E7E5E4]">
                Chưa có nhiệm vụ nào trong danh mục này.
              </div>
            ) : (
              tasks.map(t => (
                <div key={t.id} className="p-4 rounded-xl border border-[#E7E5E4] bg-white shadow-2xs flex flex-col gap-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <h4 className="font-bold text-sm text-[#1C1917] leading-snug break-words">{t.title}</h4>
                      {t.subtitle && <p className="text-[11px] text-[#78716C] mt-0.5 break-words">{t.subtitle}</p>}
                    </div>
                    <span className={`inline-block px-2.5 py-1 rounded text-[10px] font-black shrink-0 ${
                      t.status === 'Quá hạn'
                        ? 'bg-[#FEF2F2] text-[#B91C1C]'
                        : t.status === 'Gần đến hạn'
                        ? 'bg-[#FFF7ED] text-[#EA580C]'
                        : t.status === 'Đã xong'
                        ? 'bg-[#F0FDF4] text-[#16A34A]'
                        : 'bg-[#EFF6FF] text-[#2563EB]'
                    }`}>
                      {t.status}
                    </span>
                  </div>

                  <div className="text-xs text-[#57534E] space-y-1 bg-[#FAFAF9] p-2.5 rounded-lg border border-[#E7E5E4]/60">
                    <div className="flex justify-between">
                      <span className="text-[#78716C]">Công trình:</span>
                      <span className="font-bold text-[#1C1917] text-right truncate ml-2">{t.siteName || '—'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#78716C]">Hạn xử lý:</span>
                      <span className="font-mono font-bold text-[#B91C1C]">{t.deadline || '—'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#78716C]">Phụ trách:</span>
                      <span className="font-semibold text-[#1C1917]">{t.assigneeName || '—'}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <Link
                      to={`/staff/tasks/${t.id}`}
                      className="px-3 py-2 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#1C1917] hover:bg-[#FAFAF9] min-h-[44px] flex items-center justify-center text-center"
                    >
                      Mở chi tiết
                    </Link>
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(t)}
                      className="px-3 py-2 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#57534E] hover:bg-[#FAFAF9] min-h-[44px] flex items-center justify-center cursor-pointer"
                    >
                      Sửa
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenDueModal(t)}
                      className="px-3 py-2 rounded-xl border border-[#E7E5E4] text-xs font-bold text-[#57534E] hover:bg-[#FAFAF9] min-h-[44px] flex items-center justify-center cursor-pointer"
                    >
                      Đổi hạn
                    </button>
                    {t.status !== 'Đã xong' ? (
                      <button
                        type="button"
                        onClick={() => handleMarkDone(t.id)}
                        className="px-3 py-2 rounded-xl border border-[#DCFCE7] bg-[#F0FDF4] text-[#16A34A] text-xs font-extrabold hover:bg-[#DCFCE7] min-h-[44px] flex items-center justify-center cursor-pointer"
                      >
                        Hoàn thành
                      </button>
                    ) : (
                      <span className="px-3 py-2 text-xs font-bold text-[#16A34A] min-h-[44px] flex items-center justify-center">
                        ✓ Xong
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Pagination Footer */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-3 border-t border-[#E7E5E4] text-xs">
            <div className="text-[#78716C] text-[11px]">
              Hiển thị {tasks.length > 0 ? (currentPage - 1) * 10 + 1 : 0}–{Math.min(currentPage * 10, totalCount)} trên tổng số {totalCount} nhiệm vụ
            </div>

            <div className="flex items-center gap-1.5 font-bold">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-2 rounded-xl border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#78716C] disabled:opacity-40 min-h-[44px] cursor-pointer flex items-center justify-center"
              >
                &lt;
              </button>
              {Array.from({ length: Math.max(1, Math.ceil(totalCount / 10)) }, (_, i) => i + 1).map(p => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer ${
                    currentPage === p
                      ? 'bg-[#B91C1C] text-white shadow-xs'
                      : 'border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917]'
                  }`}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(p => Math.min(Math.max(1, Math.ceil(totalCount / 10)), p + 1))}
                disabled={currentPage >= Math.ceil(totalCount / 10)}
                className="px-3 py-2 rounded-xl border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#78716C] disabled:opacity-40 min-h-[44px] cursor-pointer flex items-center justify-center"
              >
                &gt;
              </button>
            </div>
          </div>

        </div>

        {/* Right Side: Khối "Lịch hôm nay" (cố định 310px - Mockup 8) */}
        <div className="w-full xl:w-[310px] xl:shrink-0 bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-3.5">
          
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-[#1C1917]">
              <span>📅</span>
              <span>Lịch hôm nay</span>
            </div>
          </div>

          <div className="space-y-3">
            {scheduleToday.length === 0 ? (
              <div className="text-xs text-[#78716C] italic py-2">Không có lịch trình hôm nay.</div>
            ) : (
              scheduleToday.map((s, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs p-2 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4]">
                  <span className="w-2 h-2 rounded-full bg-[#2563EB] shrink-0 mt-1.5" />
                  <div className="min-w-0 space-y-0.5">
                    <span className="font-mono text-[10px] font-bold text-[#2563EB]">{s.time}</span>
                    <div className="font-bold text-xs text-[#1C1917] leading-snug break-words">{s.title}</div>
                    <div className="text-[10px] text-[#78716C] break-words">{s.site}</div>
                    <div className="text-[9px] font-medium text-[#57534E]">{s.assignee}</div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => setActiveTab('TODAY')}
            className="text-xs font-bold text-[#78716C] hover:text-[#B91C1C] pt-2 flex items-center gap-1 transition cursor-pointer min-h-[44px]"
          >
            <span>Xem lịch chi tiết</span>
            <span>➔</span>
          </button>

        </div>

      </div>

      {/* Modal Sửa Nhiệm Vụ */}
      {editModal.open && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setEditModal({ open: false, task: null, title: '', assignee: '' })} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Sửa nhiệm vụ</h3>
                <p className="text-xs text-[#78716C]">Cập nhật tiêu đề và phân công cán bộ</p>
              </div>
              <button
                type="button"
                onClick={() => setEditModal({ open: false, task: null, title: '', assignee: '' })}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Tên nhiệm vụ <span className="text-[#B91C1C]">*</span></label>
                <input
                  type="text"
                  required
                  value={editModal.title}
                  onChange={e => setEditModal(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]"
                />
              </div>
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Cán bộ phụ trách</label>
                <input
                  type="text"
                  value={editModal.assignee}
                  onChange={e => setEditModal(prev => ({ ...prev, assignee: e.target.value }))}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]"
                />
              </div>
              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setEditModal({ open: false, task: null, title: '', assignee: '' })}
                  className="px-4 py-2 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]"
                >
                  Lưu thay đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Đổi Hạn Nhiệm Vụ */}
      {dueModal.open && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setDueModal({ open: false, task: null, dueDate: '' })} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Đổi thời hạn nhiệm vụ</h3>
                <p className="text-xs text-[#78716C]">Gia hạn hoặc điều chỉnh hạn chót xử lý theo SLA</p>
              </div>
              <button
                type="button"
                onClick={() => setDueModal({ open: false, task: null, dueDate: '' })}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleSaveDueDate} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Hạn xử lý mới <span className="text-[#B91C1C]">*</span></label>
                <input
                  type="date"
                  required
                  value={dueModal.dueDate}
                  onChange={e => setDueModal(prev => ({ ...prev, dueDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]"
                />
              </div>
              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button
                  type="button"
                  onClick={() => setDueModal({ open: false, task: null, dueDate: '' })}
                  className="px-4 py-2 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]"
                >
                  Lưu hạn mới
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Tạo Nhiệm Vụ */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setCreateModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#E7E5E4] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Tạo nhiệm vụ mới</h3>
                <p className="text-xs text-[#78716C]">Giao việc và thời hạn xử lý vào CSDL D1</p>
              </div>
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>
            <form onSubmit={async (e) => {
              e.preventDefault();
              const form = e.target;
              const title = form.title.value;
              const assignedTo = form.assignedTo.value;
              const description = form.description.value;
              try {
                await request('/staff/tasks/create', {
                  method: 'POST',
                  body: JSON.stringify({ title, assignedTo, description })
                });
                setCreateModalOpen(false);
                await loadAll();
                alert('Tạo nhiệm vụ thành công!');
              } catch (err) {
                alert('Lỗi tạo nhiệm vụ: ' + err.message);
              }
            }} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Tên nhiệm vụ <span className="text-[#B91C1C]">*</span></label>
                <input name="title" type="text" required placeholder="VD: Khảo sát thực địa bạt che bụi" className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]" />
              </div>
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Cán bộ phụ trách</label>
                <select name="assignedTo" className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl bg-white focus:border-[#B91C1C] focus:outline-none min-h-[44px]">
                  <option value="Nguyễn Minh An">Nguyễn Minh An (Thanh tra quận)</option>
                  <option value="Trần Thị Lan">Trần Thị Lan (Cán bộ phụ trách)</option>
                  <option value="Lê Hoàng Nam">Lê Hoàng Nam (Giám sát viên)</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Mô tả công việc</label>
                <textarea name="description" rows={3} placeholder="Ghi chú chi tiết yêu cầu..." className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none" />
              </div>
              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#E7E5E4]">
                <button type="button" onClick={() => setCreateModalOpen(false)} className="px-4 py-2 border border-[#E7E5E4] rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] min-h-[44px] cursor-pointer">Hủy</button>
                <button type="submit" className="px-5 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]">Lưu nhiệm vụ</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
