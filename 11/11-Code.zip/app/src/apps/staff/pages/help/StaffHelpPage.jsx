import React from 'react';

export default function StaffHelpPage() {
  const guides = [
    {
      title: '1. Quy trình xử lý vi phạm 7 bước',
      desc: 'Tuân thủ Nghị định 30/2020 & 45/2022/NĐ-CP: Tiếp nhận -> Khảo sát -> Lập biên bản -> Đề xuất -> Ký duyệt -> Khắc phục -> Hoàn tất.'
    },
    {
      title: '2. Tiêu chuẩn kiểm tra 10 tiêu chí công trình',
      desc: 'Bao gồm: Trạm rửa xe tự động, Bạt che phủ bãi cát, Lưới bao che giàn giáo, Phun sương dập bụi, Vận chuyển kín khít, Quan trắc bụi.'
    },
    {
      title: '3. Quy chuẩn ngưỡng nồng độ bụi tham chiếu',
      desc: 'Áp dụng QCVN 05:2023/BTNMT: Bụi PM2.5 trung bình 24h không vượt quá 50 µg/m³, Bụi PM10 không vượt quá 100 µg/m³.'
    },
    {
      title: '4. Kiểm tra mã băm minh chứng SHA-256',
      desc: 'Mọi tệp hình ảnh và biên bản A4 xuất ra đều được gắn mã băm xác thực Web Crypto SHA-256 chống làm giả.'
    }
  ];

  return (
    <div className="flex flex-col gap-6 max-w-4xl">
      {/* Header */}
      <div className="bg-white border border-cream-200 rounded-2xl p-5 shadow-xs">
        <h1 className="text-xl font-black text-ink-950 tracking-tight">Cẩm Nang Tác Nghiệp & Trợ Giúp</h1>
        <p className="text-xs text-ink-500 mt-0.5">
          Hướng dẫn nghiệp vụ kiểm tra hiện trường, quy chuẩn pháp lý và thông tin liên hệ hỗ trợ.
        </p>
      </div>

      {/* Guide Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {guides.map((g, idx) => (
          <div key={idx} className="bg-white border border-cream-200 rounded-2xl p-5 shadow-xs flex flex-col gap-2">
            <h3 className="font-bold text-xs text-ink-950">{g.title}</h3>
            <p className="text-xs text-ink-600 leading-relaxed">{g.desc}</p>
          </div>
        ))}
      </div>

      {/* Support Box */}
      <div className="bg-[#FEF2F2]/60 border border-[#FECACA] rounded-2xl p-5 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <div className="text-xs font-bold text-[#1C1917]">Tổng đài hỗ trợ kỹ thuật DustGuard VN</div>
          <div className="text-xs text-[#57534E] mt-0.5">Hỗ trợ cán bộ thanh tra trực tuyến 24/7</div>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3.5 py-2 bg-white border border-[#FECACA] rounded-xl text-xs font-black text-[#B91C1C]">
            Hotline: 1900 6868
          </span>
        </div>
      </div>
    </div>
  );
}
