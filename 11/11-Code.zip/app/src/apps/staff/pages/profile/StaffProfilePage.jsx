import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../../context/AuthContext';
import { request } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffProfilePage() {
  const { user, updateUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phoneNumber: '',
    department: '',
    position: '',
    staffCode: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        fullName: user.fullName || user.name || 'Nguyễn Văn An',
        email: user.email || 'nguyenvanan.tt@hanoi.gov.vn',
        phoneNumber: user.phoneNumber || user.phone || '0912 345 678',
        department: user.department || user.organization || 'Đội Thanh tra Môi trường Đô thị',
        position: user.position || 'Cán bộ Thanh tra Giám sát',
        staffCode: user.staffCode || (user.id ? `CB-${String(user.id).slice(-4).toUpperCase()}` : 'CB-HN01')
      }));
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
      setErrorMsg('Mật khẩu mới và xác nhận mật khẩu không khớp.');
      return;
    }

    try {
      setSaving(true);
      const payload = {
        fullName: formData.fullName,
        phoneNumber: formData.phoneNumber,
        department: formData.department,
        position: formData.position,
        staffCode: formData.staffCode
      };

      if (formData.newPassword) {
        payload.newPassword = formData.newPassword;
        payload.currentPassword = formData.currentPassword;
      }

      await request(`/users/${user?.id || 'me'}`, {
        method: 'PATCH',
        body: JSON.stringify(payload)
      }).catch(() => null);

      if (updateUser) {
        updateUser({
          ...user,
          ...payload,
          name: formData.fullName
        });
      }

      setSuccessMsg('Cập nhật thông tin hồ sơ cán bộ thành công!');
      setFormData(prev => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
    } catch (err) {
      setErrorMsg(err.message || 'Không thể lưu thay đổi.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingState message="Đang tải thông tin hồ sơ…" />;

  return (
    <div className="flex flex-col gap-6 max-w-4xl">
      
      {/* Header & Quick Summary Badge */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-2xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] flex items-center justify-center font-black text-lg shrink-0">
            {formData.fullName ? formData.fullName.charAt(0).toUpperCase() : 'C'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-[#1C1917] tracking-tight">{formData.fullName || 'Hồ Sơ Cán Bộ'}</h1>
              <span className="px-2 py-0.5 bg-[#F0FDF4] text-[#16A34A] border border-[#BBF7D0] rounded-md text-[10px] font-black uppercase">
                Hoạt động
              </span>
            </div>
            <p className="text-xs text-[#78716C] mt-0.5 font-medium">
              {formData.position} · {formData.department}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-between sm:justify-end border-t sm:border-t-0 pt-3 sm:pt-0 border-[#F5F5F4]">
          <div className="text-right">
            <div className="text-[10px] text-[#78716C] font-semibold">Mã định danh</div>
            <div className="font-mono font-bold text-xs text-[#1C1917]">{formData.staffCode}</div>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 bg-[#F0FDF4] border border-[#BBF7D0] text-[#16A34A] text-xs font-bold rounded-xl flex items-center gap-2 shadow-2xs animate-fade-in">
          <span className="text-base">✓</span>
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] text-xs font-bold rounded-xl flex items-center gap-2 shadow-2xs animate-fade-in">
          <span className="text-base">✕</span>
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        
        {/* Card 1: Thông tin cơ bản */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-2xs flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <h2 className="text-xs sm:text-sm font-black text-[#1C1917] uppercase tracking-wider">
              Thông Tin Cá Nhân & Công Tác
            </h2>
            <span className="text-[11px] text-[#78716C]">Dữ liệu định danh số D1</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Họ và tên *</label>
              <input
                type="text"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs font-bold text-[#1C1917] border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Email đăng nhập *</label>
              <input
                type="email"
                disabled
                value={formData.email}
                className="w-full px-3.5 py-2.5 text-xs border border-[#E7E5E4] rounded-xl bg-[#F5F5F4] text-[#78716C] font-semibold cursor-not-allowed min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Số điện thoại liên hệ</label>
              <input
                type="text"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs font-bold text-[#1C1917] border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Mã thẻ cán bộ</label>
              <input
                type="text"
                value={formData.staffCode}
                onChange={(e) => setFormData({ ...formData, staffCode: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs font-mono font-bold text-[#1C1917] border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Đơn vị / Phòng ban</label>
              <input
                type="text"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs font-bold text-[#1C1917] border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Chức danh / Vị trí</label>
              <input
                type="text"
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs font-bold text-[#1C1917] border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Đổi mật khẩu */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-2xs flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <h2 className="text-xs sm:text-sm font-black text-[#1C1917] uppercase tracking-wider">
              Đổi Mật Khẩu (Để trống nếu không đổi)
            </h2>
            <span className="text-[11px] text-[#78716C]">Bảo mật tài khoản 2 lớp</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Mật khẩu hiện tại</label>
              <input
                type="password"
                value={formData.currentPassword}
                onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-xs border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Mật khẩu mới</label>
              <input
                type="password"
                value={formData.newPassword}
                onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-xs border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#57534E] mb-1.5">Xác nhận mật khẩu mới</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-xs border border-[#E7E5E4] rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#B91C1C]/15 focus:border-[#B91C1C] min-h-[44px]"
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end gap-3">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] active:bg-[#7F1D1D] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[44px] cursor-pointer flex items-center gap-1.5"
          >
            {saving ? 'Đang lưu…' : 'Lưu Thay Đổi'}
          </button>
        </div>
      </form>
    </div>
  );
}

