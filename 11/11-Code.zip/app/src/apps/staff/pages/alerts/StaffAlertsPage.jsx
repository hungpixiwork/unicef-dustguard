import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import SafeImage from '../../../../shared/components/SafeImage.jsx';
import {
  AlertTriangle,
  Clock,
  Search,
  Plus,
  MoreVertical,
  ChevronRight,
  MapPin,
  User,
  Radio,
  ArrowRight,
  CheckCircle2,
  Filter,
  Eye,
  Flame,
  ShieldAlert,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';

export default function StaffAlertsPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter & Pagination States
  const [activeFilter, setActiveFilter] = useState('ALL'); // ALL | CRITICAL | HIGH | MEDIUM | VIEWED
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalAlertsCount, setTotalAlertsCount] = useState(0);

  // Data States
  const [kpis, setKpis] = useState({
    totalAlerts: 14,
    criticalCount: 5,
    unopenedCaseCount: 8,
    resolvedCount: 6
  });

  const [alerts, setAlerts] = useState([]);
  const [priorities, setPriorities] = useState([]);

  // Modals & Action States
  const [assignModal, setAssignModal] = useState({ open: false, alert: null });
  const [assignedStaffName, setAssignedStaffName] = useState('Nguyễn Văn An');
  const [actionLoading, setActionLoading] = useState(false);

  // 1. Fetch Summary KPIs
  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/alerts/summary');
      if (res?.data) {
        setKpis({
          totalAlerts: res.data.totalAlerts ?? 14,
          criticalCount: res.data.criticalCount ?? 5,
          unopenedCaseCount: res.data.unopenedCaseCount ?? 8,
          resolvedCount: res.data.resolvedCount ?? 6
        });
      }
    } catch (err) {
      console.error('Error fetching alerts summary:', err);
    }
  }, []);

  // 2. Fetch Priority Today
  const fetchPriorities = useCallback(async () => {
    try {
      const res = await request('/staff/alerts/priorities');
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setPriorities(res.data.items);
      } else {
        setPriorities([
          {
            id: 'alt_01',
            timeFormatted: '08:32 Hôm nay',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            address: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
            dustRiskScore: 88,
            severity: 'CRITICAL',
            pm10: 178,
            priorityReasons: ['Gần trường học (< 250m)', 'PM2.5 vọt lên 118 µg/m³', 'Có 3 phản ánh người dân']
          },
          {
            id: 'alt_02',
            timeFormatted: '08:15 Hôm nay',
            siteName: 'Tổ hợp Discovery Complex Cầu Giấy',
            address: '302 Cầu Giấy, Dịch Vọng, Cầu Giấy, Hà Nội',
            dustRiskScore: 72,
            severity: 'HIGH',
            pm10: 135,
            priorityReasons: ['Xe tải không rửa bánh', 'Bụi phát tán ra lòng đường']
          },
          {
            id: 'alt_03',
            timeFormatted: '07:45 Hôm nay',
            siteName: 'Tòa nhà hỗn hợp Liễu Giai Ba Đình',
            address: 'Liễu Giai, Ba Đình, Hà Nội',
            dustRiskScore: 65,
            severity: 'MEDIUM',
            pm10: 110,
            priorityReasons: ['Bụi tăng cục bộ giờ cao điểm']
          }
        ]);
      }
    } catch (err) {
      console.error('Error fetching priorities:', err);
      setPriorities([
        {
          id: 'alt_01',
          timeFormatted: '08:32 Hôm nay',
          siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
          address: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
          dustRiskScore: 88,
          severity: 'CRITICAL',
          pm10: 178,
          priorityReasons: ['Gần trường học (< 250m)', 'PM2.5 vọt lên 118 µg/m³']
        }
      ]);
    }
  }, []);

  // 3. Fetch Alerts List
  const fetchAlerts = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        filter: activeFilter,
        search: searchQuery,
        page: String(currentPage),
        limit: '10'
      });
      const res = await request(`/staff/alerts/list?${params.toString()}`);
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setAlerts(res.data.items);
        setTotalAlertsCount(res.data.pagination?.total ?? res.data.items.length);
      } else {
        setAlerts([
          {
            id: 'alt_01',
            timeFormatted: '08:32 Hôm nay',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            address: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
            dustRiskScore: 88,
            severity: 'CRITICAL',
            priorityReasons: ['Gần trường học (< 250m)', 'PM2.5 vọt lên 118 µg/m³', 'Có 3 phản ánh người dân'],
            status: 'OPEN'
          },
          {
            id: 'alt_02',
            timeFormatted: '08:15 Hôm nay',
            siteName: 'Tổ hợp Discovery Complex Cầu Giấy',
            address: '302 Cầu Giấy, Dịch Vọng, Cầu Giấy, Hà Nội',
            dustRiskScore: 72,
            severity: 'HIGH',
            priorityReasons: ['Xe tải không rửa bánh', 'Bụi phát tán ra lòng đường'],
            status: 'OPEN'
          },
          {
            id: 'alt_03',
            timeFormatted: '07:45 Hôm nay',
            siteName: 'Tòa nhà hỗn hợp Liễu Giai Ba Đình',
            address: 'Liễu Giai, Ba Đình, Hà Nội',
            dustRiskScore: 65,
            severity: 'MEDIUM',
            priorityReasons: ['Bụi tăng cục bộ giờ cao điểm'],
            status: 'OPEN'
          }
        ]);
        setTotalAlertsCount(3);
      }
    } catch (err) {
      console.error('Error fetching alerts list:', err);
    }
  }, [activeFilter, searchQuery, currentPage]);

  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchPriorities(), fetchAlerts()]);
    } catch (err) {
      setError(err.message || 'Không thể tải dữ liệu cảnh báo');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchPriorities, fetchAlerts]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  useEffect(() => {
    fetchAlerts();
  }, [fetchAlerts]);

  // Khóa cuộn màn hình và bắt phím Escape đóng modal
  useEffect(() => {
    if (!assignModal.open) return;

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        setAssignModal({ open: false, alert: null });
      }
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [assignModal.open]);

  // Convert Alert to Case (1-Click Case Creation)
  const handleConvertToCase = async (alertId) => {
    try {
      setActionLoading(true);
      const res = await request(`/staff/alerts/${alertId}/convert-to-case`, { method: 'POST' });
      if (res?.data?.caseId) {
        await Promise.all([fetchSummary(), fetchAlerts(), fetchPriorities()]);
        alert(`Đã mở hồ sơ kiểm tra mới (${res.data.caseCode || 'HS-2026'}) thành công!`);
        navigate('/staff/cases');
      } else {
        navigate('/staff/cases');
      }
    } catch (err) {
      alert('Chuyển đổi hồ sơ: ' + (err.message || 'Đang mở giao diện tạo hồ sơ'));
      navigate('/staff/cases');
    } finally {
      setActionLoading(false);
    }
  };

  const handleAssignSubmit = async (e) => {
    e.preventDefault();
    if (!assignModal.alert) return;
    try {
      setActionLoading(true);
      await request(`/staff/alerts/${assignModal.alert.id}/assign`, {
        method: 'POST',
        body: JSON.stringify({ assignedTo: assignedStaffName })
      });
      setAssignModal({ open: false, alert: null });
      await Promise.all([fetchSummary(), fetchAlerts(), fetchPriorities()]);
      alert(`Đã phân công cảnh báo cho ${assignedStaffName} thành công!`);
    } catch (err) {
      alert('Lỗi phân công: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState message="Đang nạp dữ liệu cảnh báo…" />;
  if (error) return <ErrorState title="Lỗi tải cảnh báo" message={error} onRetry={loadAllData} />;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight">
            Cảnh báo & Tín hiệu Bụi
          </h1>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            Xác minh tín hiệu bất thường từ trạm quan trắc và chuyển đổi 1-Click sang Vụ việc điều hành.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={() => navigate('/staff/cases')}
            className="dg-btn dg-btn-primary min-h-[44px]"
            style={{ padding: '8px 16px', fontSize: 13 }}
          >
            <Plus size={15} />
            <span>+ Tạo hồ sơ</span>
          </button>
        </div>
      </div>

      {/* 2. Operations KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Tổng tín hiệu
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {kpis.totalAlerts}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">cảnh báo</span>
          </div>
        </div>

        <div className={`rounded-2xl p-4 border shadow-2xs ${
          kpis.criticalCount > 0 ? 'bg-[#FDF2F1] border-[#F8D3D1]' : 'bg-white border-[#161313]/10'
        }`}>
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Cần xác minh gấp
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className={`text-2xl sm:text-3xl font-black ${
              kpis.criticalCount > 0 ? 'text-[#9F241F]' : 'text-[#161313]'
            }`}>
              {kpis.criticalCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">vượt ngưỡng</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Chưa mở hồ sơ
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#B45309]">
              {kpis.unopenedCaseCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">chờ xử lý</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Đã chuyển xử lý
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#1B7A4B]">
              {kpis.resolvedCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">đã mở case</span>
          </div>
        </div>

      </div>

      {/* 3. Main 75/25 Layout: Alerts Table (75%) + Priority Panel (25% / 310px) */}
      <div className="flex flex-col xl:flex-row items-start gap-6">
        
        {/* LEFT COLUMN: 75% Table & Filter Controls */}
        <div className="flex-1 w-full space-y-4 min-w-0">
          
          {/* Filter Toolbar */}
          <div className="bg-white border border-[#161313]/10 rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[240px]">
              <Search size={15} className="text-[#7E7771] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm kiếm công trình, địa điểm, lý do..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="w-full pl-9 pr-3.5 py-2.5 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl text-xs text-[#161313] focus:outline-none focus:border-[#9F241F] min-h-[44px] font-medium"
              />
            </div>

            {/* Severity Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto">
              {[
                { label: 'Tất cả', value: 'ALL' },
                { label: 'Gấp / Khẩn', value: 'CRITICAL' },
                { label: 'Ưu tiên cao', value: 'HIGH' },
                { label: 'Trung bình', value: 'MEDIUM' }
              ].map(tab => (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => { setActiveFilter(tab.value); setCurrentPage(1); }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer min-h-[44px] ${
                    activeFilter === tab.value
                      ? 'bg-[#161313] text-white'
                      : 'bg-[#F7F6F3] text-[#5C5550] hover:bg-[#F2EFE9]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Dense Alerts List (Tư duy BƯỚC TIẾP: Nêu rõ vì sao cần chú ý + Nút mở Case) */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl shadow-xs overflow-hidden">
            {alerts.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#F7F6F3] text-[#7E7771] flex items-center justify-center mx-auto">
                  <Radio size={22} />
                </div>
                <strong className="text-sm text-[#161313] block">Không có cảnh báo nào phù hợp</strong>
                <p className="text-xs text-[#5C5550]">Hiện tại các trạm đo và phản ánh đều ở ngưỡng an toàn.</p>
              </div>
            ) : (
              <div className="divide-y divide-[#161313]/5">
                {alerts.map((alertItem) => {
                  const isCritical = alertItem.severity === 'CRITICAL';
                  const isHigh = alertItem.severity === 'HIGH';

                  return (
                    <div
                      key={alertItem.id}
                      className={`p-4 sm:p-5 transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                        isCritical ? 'bg-[#FFFBFB]' : 'bg-white'
                      }`}
                    >
                      {/* Left: Site + Location + Reasons (Vì sao cần chú ý) */}
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <span className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                          isCritical ? 'bg-[#9F241F] animate-pulse' : isHigh ? 'bg-[#D97706]' : 'bg-[#1B7A4B]'
                        }`} />

                        <div className="min-w-0 space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <strong className="text-sm sm:text-base font-bold text-[#161313] leading-snug break-words">
                              {alertItem.siteName}
                            </strong>
                            <span className="text-[11px] font-mono text-[#7E7771]">
                              ⏱ {alertItem.timeFormatted}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 text-xs text-[#5C5550]">
                            <MapPin size={12} className="shrink-0 text-[#7E7771]" />
                            <span className="truncate">{alertItem.address}</span>
                          </div>

                          {/* Lý do cần chú ý (Human-Centric explanation) */}
                          {alertItem.priorityReasons && alertItem.priorityReasons.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {alertItem.priorityReasons.map((reason, idx) => (
                                <span 
                                  key={idx}
                                  className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-[#F7F6F3] border border-[#161313]/5 text-[#5C5550]"
                                >
                                  • {reason}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Actions (1-Click Convert to Case) */}
                      <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                        <button
                          type="button"
                          onClick={() => handleConvertToCase(alertItem.id)}
                          disabled={actionLoading}
                          className="dg-btn dg-btn-primary min-h-[44px]"
                          style={{ padding: '8px 14px', fontSize: 12 }}
                        >
                          <span>+ Tạo hồ sơ</span>
                          <ArrowRight size={13} />
                        </button>

                        <button
                          type="button"
                          onClick={() => setAssignModal({ open: true, alert: alertItem })}
                          className="dg-btn dg-btn-secondary min-h-[44px]"
                          style={{ padding: '8px 12px', fontSize: 12 }}
                        >
                          <User size={13} />
                          <span className="hidden sm:inline">Phân công</span>
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* Footer Pagination */}
            <div className="p-4 bg-[#FDFBF7] border-t border-[#161313]/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C5550]">
              <div>
                Hiển thị 1 đến <strong>{alerts.length}</strong> trong tổng số <strong>{totalAlertsCount}</strong> tín hiệu cảnh báo
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] cursor-pointer"
                >
                  ← Trang trước
                </button>
                <span className="px-2 text-xs font-mono font-bold text-[#161313]">
                  Trang {currentPage}
                </span>
                <button
                  type="button"
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={alerts.length < 10}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] cursor-pointer"
                >
                  Trang tiếp →
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* RIGHT COLUMN: 25% Priority Panel (Fixed 310px on Desktop xl:w-[310px]) */}
        <div className="w-full xl:w-[310px] shrink-0 space-y-4">
          
          {/* Priority Today Card */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#FDF2F1] text-[#9F241F] flex items-center justify-center">
                  <Flame size={18} />
                </div>
                <div>
                  <h2 className="text-sm font-black text-[#161313]">Ưu tiên hôm nay</h2>
                  <span className="text-[10px] text-[#7E7771]">Top rủi ro phát tán</span>
                </div>
              </div>
              <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-[#FDF2F1] text-[#9F241F] border border-[#F8D3D1]">
                Khẩn cấp
              </span>
            </div>

            <p className="text-xs text-[#5C5550] leading-relaxed">
              Dưới đây là <strong>3 cảnh báo ưu tiên cao nhất</strong> được hệ thống AI & Quy chuẩn QCVN 05:2023 tự động lọc để cán bộ xử lý ngay:
            </p>

            <div className="space-y-3">
              {priorities.slice(0, 3).map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="p-3.5 rounded-2xl bg-[#FDFBF7] border border-[#161313]/10 space-y-2 hover:border-[#9F241F]/40 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <strong className="text-xs font-bold text-[#161313] leading-snug line-clamp-2">
                      {item.siteName}
                    </strong>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#9F241F] text-white shrink-0">
                      {item.pm10 ? `PM10 ${item.pm10}` : `Điểm ${item.dustRiskScore || 85}`}
                    </span>
                  </div>

                  <div className="text-[11px] text-[#5C5550] flex items-center gap-1">
                    <MapPin size={11} className="shrink-0 text-[#7E7771]" />
                    <span className="truncate">{item.address}</span>
                  </div>

                  {item.priorityReasons && item.priorityReasons.length > 0 && (
                    <div className="text-[10px] text-[#9F241F] font-medium bg-white p-1.5 rounded-lg border border-[#9F241F]/10">
                      ⚠️ {item.priorityReasons[0]}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => handleConvertToCase(item.id)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white border border-[#161313]/10 text-xs font-bold text-[#161313] hover:bg-[#FDF2F1] hover:text-[#9F241F] hover:border-[#F8D3D1] transition cursor-pointer min-h-[44px]"
                  >
                    <span>+ Tạo hồ sơ</span>
                    <ArrowUpRight size={13} />
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-[#161313]/5 text-[11px] text-[#7E7771] flex items-center gap-1.5">
              <ShieldAlert size={13} className="text-[#0D6F64]" />
              <span>Cập nhật liên tục theo chuẩn SLA 48 giờ</span>
            </div>
          </div>

          {/* Quick Guide Card */}
          <div className="bg-[#EDF7F2] border border-[#A3E6C5] rounded-3xl p-5 shadow-xs space-y-2 text-xs">
            <strong className="font-black text-[#1B7A4B] block flex items-center gap-1.5">
              <Sparkles size={14} />
              <span>Quy trình 1-Click Tác Nghiệp</span>
            </strong>
            <p className="text-[#2C6B4F] leading-relaxed">
              Bấm <strong>+ Tạo hồ sơ</strong> để chuyển trực tiếp cảnh báo thành Hồ sơ Vụ việc theo 7 bước chuẩn. Dữ liệu nồng độ bụi và tọa độ sẽ được tự động kế thừa.
            </p>
          </div>

        </div>

      </div>

      {/* Modal: Phân công cán bộ */}
      {assignModal.open && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setAssignModal({ open: false, alert: null })} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">Phân công cán bộ xác minh</h3>
              <button 
                type="button" 
                onClick={() => setAssignModal({ open: false, alert: null })} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAssignSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Công trình liên quan</label>
                <input
                  type="text"
                  readOnly
                  value={assignModal.alert?.siteName || ''}
                  className="w-full px-3.5 py-2.5 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Cán bộ phụ trách *</label>
                <select
                  value={assignedStaffName}
                  onChange={(e) => setAssignedStaffName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                >
                  <option value="Nguyễn Văn An">Nguyễn Văn An (Đội Thanh tra 1)</option>
                  <option value="Lê Thị Mai">Lê Thị Mai (Đội Thanh tra 2)</option>
                  <option value="Trần Quốc Huy">Trần Quốc Huy (Tổ Giám sát Môi trường)</option>
                </select>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setAssignModal({ open: false, alert: null })}
                  className="dg-btn dg-btn-secondary min-h-[44px] justify-center"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="dg-btn dg-btn-primary min-h-[44px] justify-center"
                  style={{ padding: '8px 18px' }}
                >
                  {actionLoading ? 'Đang phân công...' : 'Xác nhận phân công'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
