import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffTodayPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);

  const [summary, setSummary] = useState(null);

  useEffect(() => {
    async function loadTodayTasks() {
      try {
        setLoading(true);
        const [tasksRes, summaryRes] = await Promise.all([
          request('/staff/tasks').catch(() => []),
          request('/staff/tasks/summary').catch(() => null)
        ]);

        const taskList = normalizeList(tasksRes);
        setTasks(taskList);
        if (summaryRes?.data) {
          setSummary(summaryRes.data);
        }
      } catch (err) {
        console.error('[StaffTodayPage Error]', err);
        setTasks([]);
      } finally {
        setLoading(false);
      }
    }
    loadTodayTasks();
  }, []);

  if (loading) {
    return <LoadingState message="Đang tải nhiệm vụ hôm nay…" />;
  }

  // Calculate summary metrics from real tasks or summary API
  const needInspectionCount = summary?.pending || tasks.filter(t => t.type === 'INSPECTION' || !t.type || t.status === 'PENDING').length;
  const needRecheckCount = summary?.recheck || tasks.filter(t => t.type === 'RECHECK' || t.status === 'IN_PROGRESS').length;
  const overdueCount = summary?.overdue || tasks.filter(t => t.type === 'OVERDUE' || t.priority === 'CRITICAL' || t.isOverdue).length;

  return (
    <div className="flex flex-col gap-4 max-w-lg mx-auto w-full pb-10">
      {/* 1. Header Cực Ngắn Cho Cán Bộ Ngoài Hiện Trường */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Hôm nay của tôi
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Nhiệm Vụ Thực Địa
          </h1>
        </div>
        <button
          type="button"
          onClick={() => navigate('/staff/tasks')}
          className="text-xs font-bold text-[#0D6F64] hover:underline min-h-[44px] flex items-center gap-1 cursor-pointer"
        >
          <span>Tất cả nhiệm vụ</span>
          <span>→</span>
        </button>
      </div>

      {/* 2. Ba Thẻ Tóm Tắt Trạng Thái (Zero biểu đồ phức tạp) */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-[#FEF2F2] border border-[#FCA5A5]/60 rounded-xl p-3 text-center flex flex-col justify-center min-h-[76px]">
          <span className="text-2xl font-black text-[#9F241F] leading-none">{overdueCount}</span>
          <span className="text-[10px] font-bold text-[#9F241F] mt-1 leading-tight">Quá hạn SLA</span>
        </div>

        <div className="bg-[#FFFBEB] border border-[#FDE68A] rounded-xl p-3 text-center flex flex-col justify-center min-h-[76px]">
          <span className="text-2xl font-black text-[#B45309] leading-none">{needRecheckCount}</span>
          <span className="text-[10px] font-bold text-[#B45309] mt-1 leading-tight">Cần tái kiểm</span>
        </div>

        <div className="bg-[#F0FDFA] border border-[#CCFBF1] rounded-xl p-3 text-center flex flex-col justify-center min-h-[76px]">
          <span className="text-2xl font-black text-[#0D6F64] leading-none">{needInspectionCount}</span>
          <span className="text-[10px] font-bold text-[#0D6F64] mt-1 leading-tight">Cần kiểm tra</span>
        </div>
      </div>

      {/* 3. Danh Sách Card Nhiệm Vụ Lớn (Dễ chạm 1 tay ngoài trời) */}
      <div className="flex flex-col gap-3 pt-1">
        <div className="text-xs font-black uppercase tracking-wider text-[#78716C] px-1">
          Ưu tiên xử lý ngay
        </div>

        {tasks.map((task) => {
          const isOverdue = task.type === 'OVERDUE' || task.priority === 'CRITICAL';
          const isRecheck = task.type === 'RECHECK';

          const badgeBg = isOverdue ? 'bg-[#FEF2F2] text-[#9F241F] border-[#FCA5A5]' :
                          isRecheck ? 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]' :
                          'bg-[#F0FDFA] text-[#0D6F64] border-[#CCFBF1]';

          const badgeText = isOverdue ? 'Quá hạn' : isRecheck ? 'Tái kiểm tra' : 'Kiểm tra mới';

          return (
            <div
              key={task.id}
              onClick={() => navigate(`/staff/tasks/${task.id}`)}
              className="bg-white border-2 border-[#E7E5E4] hover:border-[#0D6F64] active:bg-[#FAFAF9] rounded-2xl p-4 shadow-xs flex flex-col gap-3 cursor-pointer transition min-h-[140px] select-none"
            >
              {/* Top Row: Badge & Distance */}
              <div className="flex items-center justify-between">
                <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-lg border uppercase ${badgeBg}`}>
                  {badgeText}
                </span>
                <span className="text-xs font-bold text-[#78716C] flex items-center gap-1">
                  📍 <span>Cách {task.distance || '500m'}</span>
                </span>
              </div>

              {/* Title & Address */}
              <div>
                <h2 className="font-black text-base text-[#1C1917] leading-snug break-words">
                  {task.siteName}
                </h2>
                <p className="text-xs text-[#57534E] mt-1 leading-snug break-words">
                  {task.address}
                </p>
              </div>

              {/* Bottom Row: Risk Score & Action */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#E7E5E4]/80 mt-auto">
                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 min-w-0 flex-1">
                  <span className="text-[11px] text-[#78716C]">Điểm ưu tiên:</span>
                  <span className="text-xs font-black text-[#9F241F] bg-[#FEF2F2] px-2 py-0.5 rounded border border-[#FCA5A5]/30 shrink-0">
                    {task.riskScore}/100
                  </span>
                  {task.deadlineText && (
                    <span className="text-[11px] text-[#78716C] break-words">• {task.deadlineText}</span>
                  )}
                </div>

                <div className="text-xs font-black text-[#0D6F64] flex items-center gap-0.5 shrink-0 min-h-[44px]">
                  <span>Mở</span>
                  <span>➔</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
