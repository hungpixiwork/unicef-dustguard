import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffNotificationsPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // States
  const [activeTab, setActiveTab] = useState('ALL'); // ALL | UNREAD | TODAY | SYSTEM | CASE
  const [kpis, setKpis] = useState({
    unreadCount: 12,
    todayCount: 8,
    nearDeadlineCount: 9,
    urgentCount: 5
  });
  const [notifications, setNotifications] = useState([]);
  const [urgentItems, setUrgentItems] = useState([]);

  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/notifications/summary');
      if (res?.data) {
        setKpis(res.data);
      }
    } catch (err) {
      console.error('Error fetching notifications summary:', err);
    }
  }, []);

  const fetchList = useCallback(async () => {
    try {
      const res = await request(`/staff/notifications/list?tab=${activeTab}`);
      if (res?.data?.items) {
        setNotifications(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching notifications list:', err);
    }
  }, [activeTab]);

  const fetchUrgent = useCallback(async () => {
    try {
      const res = await request('/staff/notifications/urgent');
      if (res?.data?.items) {
        setUrgentItems(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching urgent events:', err);
    }
  }, []);

  const loadAll = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchList(), fetchUrgent()]);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách thông báo từ D1/SQLite');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchList, fetchUrgent]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const handleMarkAllRead = async () => {
    try {
      await request('/staff/notifications/mark-all-read', { method: 'POST' });
      setNotifications(notifications.map(n => ({ ...n, isRead: true })));
      setKpis(prev => ({ ...prev, unreadCount: 0 }));
      alert('Đã đánh dấu tất cả thông báo là đã đọc!');
    } catch (err) {
      alert('Lỗi: ' + err.message);
    }
  };

  const handleMarkRead = async (id) => {
    try {
      await request(`/staff/notifications/${id}/read`, { method: 'POST' });
      setNotifications(notifications.map(n => n.id === id ? { ...n, isRead: true } : n));
      setKpis(prev => ({ ...prev, unreadCount: Math.max(0, prev.unreadCount - 1) }));
    } catch (err) {
      console.error('Error marking notification read:', err);
    }
  };

  const handleMute = async (id) => {
    try {
      await request(`/staff/notifications/${id}/mute`, { method: 'POST' });
      setNotifications(notifications.filter(n => n.id !== id));
      alert('Đã tắt thông báo này thành công.');
    } catch (err) {
      alert('Lỗi ẩn thông báo: ' + err.message);
    }
  };

  if (loading) return <LoadingState message="Đang nạp thông báo từ CSDL SQLite..." />;
  if (error) return <ErrorState title="Lỗi tải thông báo" message={error} onRetry={loadAll} />;

  return (
    <div className="space-y-5">
      
      {/* 1. Header & Top Actions (Mockup 10) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="text-xs font-semibold text-[#78716C]">
            <Link to="/staff" className="hover:text-[#B91C1C]">Trang chính</Link> / Thông báo
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight mt-0.5">
            Thông báo
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Theo dõi cảnh báo mới, hạn xử lý hồ sơ và nhiệm vụ cần làm.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleMarkAllRead}
            className="flex-1 sm:flex-none px-3.5 py-2 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[38px] cursor-pointer whitespace-nowrap"
          >
            <span>✓</span>
            <span>Đánh dấu đã đọc</span>
          </button>

          <button
            onClick={() => navigate('/staff/settings')}
            className="flex-1 sm:flex-none px-3.5 py-2 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer whitespace-nowrap"
          >
            <span>⚙️</span>
            <span>Cài đặt thông báo</span>
          </button>
        </div>
      </div>

      {/* 2. Top 4 Metric KPI Cards (Mockup 10) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* KPI 1: Chưa đọc */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FEF2F2] text-[#B91C1C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Chưa đọc</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.unreadCount}</div>
            <div className="text-[10px] font-bold text-[#B91C1C] mt-0.5">↑ 3 so với hôm qua</div>
          </div>
        </div>

        {/* KPI 2: Hôm nay */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#EFF6FF] text-[#2563EB] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Hôm nay</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.todayCount}</div>
            <div className="text-[10px] font-bold text-[#2563EB] mt-0.5">Trong ngày hôm nay</div>
          </div>
        </div>

        {/* KPI 3: Gần đến hạn */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FFF7ED] text-[#EA580C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Gần đến hạn</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.nearDeadlineCount}</div>
            <div className="text-[10px] font-bold text-[#78716C] mt-0.5">Trong 3 ngày tới</div>
          </div>
        </div>

        {/* KPI 4: Quan trọng */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FEF2F2] text-[#B91C1C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Quan trọng</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.urgentCount}</div>
            <div className="text-[10px] font-bold text-[#B91C1C] mt-0.5">Cần chú ý ngay</div>
          </div>
        </div>

      </div>

      {/* 3. Filter Tabs (Mockup 10) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { label: 'Tất cả', val: 'ALL' },
          { label: 'Chưa đọc', val: 'UNREAD' },
          { label: 'Hạn hôm nay', val: 'TODAY' },
          { label: 'Hệ thống', val: 'SYSTEM' },
          { label: 'Hồ sơ', val: 'CASE' }
        ].map(tab => (
          <button
            key={tab.val}
            onClick={() => { setActiveTab(tab.val); }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              activeTab === tab.val
                ? 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]'
                : 'bg-white text-[#57534E] border border-[#E7E5E4] hover:bg-[#FAFAF9]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 4. Main Body: Optimized Layout 75% Notifications + 25% Urgent Panel (Mockup 10) */}
      <div className="flex flex-col xl:flex-row gap-5 items-start">
        
        {/* Main Notifications List */}
        <div className="flex-1 min-w-0 w-full space-y-2.5">
          {notifications.length === 0 ? (
            <div className="bg-white border border-[#E7E5E4] rounded-2xl p-8 text-center text-xs text-[#78716C]">
              Không có thông báo nào trong danh mục này.
            </div>
          ) : (
            notifications.map(n => (
              <div
                key={n.id}
                className={`bg-white border rounded-2xl p-4 shadow-2xs transition flex flex-col sm:flex-row justify-between sm:items-center gap-3 ${
                  n.isRead ? 'border-[#E7E5E4]' : 'border-[#FECACA] bg-[#FEF2F2]/30'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="text-xl shrink-0 mt-0.5">{n.icon}</div>
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      {!n.isRead && <span className="w-2 h-2 rounded-full bg-[#B91C1C] shrink-0" />}
                      <span className="font-bold text-xs text-[#1C1917] leading-snug break-words">{n.title}</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#F5F5F4] text-[#57534E] shrink-0">{n.tagLabel}</span>
                    </div>
                    <p className="text-[11px] text-[#57534E] leading-relaxed break-words">{n.message}</p>
                    <div className="text-[10px] text-[#78716C] font-mono pt-0.5">{n.createdAt}</div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => {
                      if (n.type.includes('CASE')) navigate('/staff/cases');
                      else if (n.type.includes('ALERT')) navigate('/staff/alerts');
                      else if (n.type.includes('REPORT')) navigate('/staff/reports');
                      else navigate('/staff/tasks');
                    }}
                    className="px-3 py-1.5 bg-white border border-[#E7E5E4] rounded-xl text-xs font-bold text-[#1C1917] hover:bg-[#FAFAF9] cursor-pointer min-h-[36px]"
                  >
                    Mở
                  </button>
                  <button
                    onClick={() => navigate(`/staff/tasks?title=${encodeURIComponent(n.title || 'Nhiệm vụ từ thông báo')}&desc=${encodeURIComponent(n.message || '')}`)}
                    className="px-3 py-1.5 bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] rounded-xl text-xs font-bold hover:bg-[#FEE2E2] cursor-pointer min-h-[36px]"
                  >
                    Tạo việc
                  </button>
                  <button
                    onClick={() => handleMute(n.id)}
                    className="px-2.5 py-1.5 bg-white border border-[#E7E5E4] rounded-xl text-xs font-bold text-[#78716C] hover:bg-[#FAFAF9] cursor-pointer min-h-[36px]"
                  >
                    Tắt nhắc
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Right Side: Khối "Việc cần chú ý" (cố định 310px - Mockup 10) */}
        <div className="w-full xl:w-[310px] xl:shrink-0 bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs space-y-3.5">
          
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-[#1C1917]">
              <span>⚠️</span>
              <span>Việc cần chú ý</span>
            </div>
            <span className="text-[10px] text-[#78716C] font-bold bg-[#F5F5F4] px-1.5 py-0.5 rounded">Khẩn cấp</span>
          </div>

          <div className="space-y-2.5">
            {urgentItems.map(item => (
              <div key={item.id} className="p-3 rounded-xl border border-[#FECACA] bg-[#FEF2F2]/50 space-y-2">
                <div className="flex items-start justify-between gap-1">
                  <div className="font-bold text-xs text-[#B91C1C] leading-snug break-words">
                    {item.title}
                  </div>
                  <span className="font-mono text-[10px] text-[#78716C]">{item.time}</span>
                </div>
                <p className="text-[10px] text-[#57534E] leading-relaxed">
                  {item.desc}
                </p>
                <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-[#FECACA]/60">
                  <button
                    onClick={() => navigate('/staff/alerts')}
                    className="py-1.5 text-center bg-white border border-[#E7E5E4] rounded-xl text-xs font-bold text-[#1C1917] hover:bg-[#FAFAF9] cursor-pointer min-h-[36px]"
                  >
                    Mở
                  </button>
                  <button
                    onClick={() => navigate(`/staff/tasks?title=${encodeURIComponent(item.title || 'Xử lý cảnh báo khẩn')}&desc=${encodeURIComponent(item.desc || '')}`)}
                    className="py-1.5 text-center bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] rounded-xl text-xs font-bold hover:bg-[#FEE2E2] cursor-pointer min-h-[36px]"
                  >
                    Tạo việc
                  </button>
                </div>
              </div>
            ))}
          </div>

          <Link
            to="/staff/alerts"
            className="text-xs font-bold text-[#78716C] hover:text-[#B91C1C] pt-2 flex items-center gap-1 transition"
          >
            <span>Xem tất cả cảnh báo</span>
            <span>➔</span>
          </Link>

        </div>

      </div>

    </div>
  );
}
