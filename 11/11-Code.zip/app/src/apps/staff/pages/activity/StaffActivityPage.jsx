import React, { useState, useEffect, useCallback } from 'react';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState, EmptyState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffActivityPage() {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const sampleActivities = [
    {
      id: 'act_1',
      actor: 'Nguyễn Văn An',
      role: 'Cán bộ Thanh tra Giám sát',
      actionType: 'STATUS_CHANGE',
      action: 'CẬP NHẬT TIẾN ĐỘ HỒ SƠ',
      target: 'Hồ sơ HS-2026-0891 (Chung cư Imperial Plaza)',
      details: 'Chuyển trạng thái từ "Đang kiểm tra" sang "Đã ban hành yêu cầu khắc phục bạt che".',
      createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString()
    },
    {
      id: 'act_2',
      actor: 'Trần Thị Bình',
      role: 'Cán bộ Đội Giám sát Cơ động',
      actionType: 'DOCUMENT_A4',
      action: 'LẬP BIÊN BẢN KIỂM TRA A4 (NĐ 30/2020)',
      target: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
      details: 'Xuất biên bản kiểm tra vi phạm không vận hành cầu rửa xe tự động, lập mã băm bảo mật SHA-256.',
      createdAt: new Date(Date.now() - 1000 * 60 * 110).toISOString()
    },
    {
      id: 'act_3',
      actor: 'Nguyễn Văn An',
      role: 'Cán bộ Thanh tra Giám sát',
      actionType: 'ALERT_DISPATCH',
      action: 'PHÁT HÀNH CẢNH BÁO MÔI TRƯỜNG',
      target: 'Trạm quan trắc TX-02 · Thanh Xuân',
      details: 'Phát hành cảnh báo mức GẤP do chỉ số bụi PM10 vượt ngưỡng 172 µg/m³ kéo dài quá 2 giờ.',
      createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString()
    },
    {
      id: 'act_4',
      actor: 'Lê Hoàng Nam',
      role: 'Tổ trưởng Kiểm tra Liên ngành',
      actionType: 'ASSIGNMENT',
      action: 'GIAO NHIỆM VỤ ĐÔN ĐỐC NHÀ THẦU',
      target: 'Nhà thầu Coteccons (Dự án Discovery Complex)',
      details: 'Phân công chỉ huy trưởng hoàn thành phun nước dập bụi và dọn sạch bùn đất trước 17:00 hôm nay.',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString()
    },
    {
      id: 'act_5',
      actor: 'Phạm Thị Mai',
      role: 'Đội phó Thanh tra Môi trường',
      actionType: 'SANCTION',
      action: 'BAN HÀNH QUYẾT ĐỊNH XỬ PHẠT VI PHẠM',
      target: 'Công ty CP Đầu tư Xây dựng HUD 3',
      details: 'Xử phạt hành chính mức 35.000.000 VNĐ theo Nghị định 45/2022/NĐ-CP do tái diễn vi phạm bụi.',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString()
    }
  ];

  const loadActivities = useCallback(async () => {
    try {
      setLoading(true);
      const res = await request('/audit-logs?limit=30').catch(() => null);
      const list = normalizeList(res);
      if (list.length > 0) {
        setActivities(list);
      } else {
        setActivities(sampleActivities);
      }
    } catch {
      setActivities(sampleActivities);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadActivities();
  }, [loadActivities]);

  const filteredActivities = activities.filter(act => {
    if (filterType !== 'ALL') {
      if (filterType === 'DOCUMENT' && act.actionType !== 'DOCUMENT_A4') return false;
      if (filterType === 'SANCTION' && act.actionType !== 'SANCTION') return false;
      if (filterType === 'ALERT' && act.actionType !== 'ALERT_DISPATCH') return false;
      if (filterType === 'STATUS' && act.actionType !== 'STATUS_CHANGE') return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchActor = (act.actor || '').toLowerCase().includes(q);
      const matchAction = (act.action || '').toLowerCase().includes(q);
      const matchTarget = (act.target || '').toLowerCase().includes(q);
      const matchDetails = (act.details || '').toLowerCase().includes(q);
      return matchActor || matchAction || matchTarget || matchDetails;
    }
    return true;
  });

  const getBadgeStyle = (actionType) => {
    switch (actionType) {
      case 'SANCTION':
        return 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]';
      case 'DOCUMENT_A4':
        return 'bg-[#EFF6FF] text-[#2563EB] border-[#BFDBFE]';
      case 'ALERT_DISPATCH':
        return 'bg-[#FFF7ED] text-[#EA580C] border-[#FED7AA]';
      case 'STATUS_CHANGE':
        return 'bg-[#F0FDF4] text-[#16A34A] border-[#BBF7D0]';
      default:
        return 'bg-[#FAFAF9] text-[#57534E] border-[#E7E5E4]';
    }
  };

  const getActionIcon = (actionType) => {
    switch (actionType) {
      case 'SANCTION':
        return '⚖️';
      case 'DOCUMENT_A4':
        return '📄';
      case 'ALERT_DISPATCH':
        return '🚨';
      case 'STATUS_CHANGE':
        return '🔄';
      case 'ASSIGNMENT':
        return '📋';
      default:
        return '📝';
    }
  };

  if (loading) return <LoadingState message="Đang tải nhật ký hoạt động từ D1/SQLite…" />;

  return (
    <div className="flex flex-col gap-6 max-w-4xl">
      
      {/* 1. Header */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-2xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Nhật Ký Hoạt Động Cán Bộ
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Lưu vết minh bạch các thao tác lập hồ sơ, phân công, xử phạt và giải quyết vi phạm.
          </p>
        </div>

        <button
          onClick={loadActivities}
          className="px-3.5 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center gap-1.5 min-h-[44px] cursor-pointer"
        >
          <span>⟳</span>
          <span>Làm mới</span>
        </button>
      </div>

      {/* 2. Filters Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        
        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { label: 'Tất cả', value: 'ALL' },
            { label: '📄 Biên bản A4', value: 'DOCUMENT' },
            { label: '⚖️ Xử phạt', value: 'SANCTION' },
            { label: '🚨 Cảnh báo', value: 'ALERT' },
            { label: '🔄 Trạng thái', value: 'STATUS' }
          ].map(tab => (
            <button
              key={tab.value}
              onClick={() => setFilterType(tab.value)}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer min-h-[40px] ${
                filterType === tab.value
                  ? 'bg-[#B91C1C] text-white shadow-2xs'
                  : 'bg-white border border-[#E7E5E4] text-[#57534E] hover:bg-[#FAFAF9]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative sm:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo cán bộ, hành động, vụ việc..."
            className="w-full pl-8 pr-3 py-2 bg-white border border-[#E7E5E4] rounded-xl text-xs text-[#1C1917] focus:outline-none focus:border-[#B91C1C] min-h-[44px]"
          />
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-[#A8A29E]">🔍</span>
        </div>

      </div>

      {/* 3. Activity Timeline List */}
      {filteredActivities.length === 0 ? (
        <EmptyState title="Không tìm thấy nhật ký" message="Không có hoạt động nào phù hợp với bộ lọc hiện tại." />
      ) : (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 sm:p-8 shadow-2xs">
          <div className="relative pl-6 sm:pl-8 border-l-2 border-[#E7E5E4] space-y-8">
            {filteredActivities.map((act) => (
              <div key={act.id} className="relative group">
                
                {/* Timeline Dot with Icon */}
                <div className="absolute -left-[37px] sm:-left-[45px] top-0.5 w-7 h-7 rounded-full bg-white border-2 border-[#B91C1C] text-xs flex items-center justify-center shadow-xs">
                  {getActionIcon(act.actionType)}
                </div>
                
                {/* Header Row: Action + Timestamp */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-md border text-[10px] font-black uppercase tracking-wider ${getBadgeStyle(act.actionType)}`}>
                      {act.action || act.eventType || 'Thao tác hệ thống'}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#78716C] font-mono font-medium">
                    {new Date(act.createdAt || act.timestamp || Date.now()).toLocaleString('vi-VN', {
                      hour: '2-digit',
                      minute: '2-digit',
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric'
                    })}
                  </span>
                </div>

                {/* Actor & Role Info */}
                <div className="mt-1.5 flex items-center gap-2 text-xs">
                  <div className="w-5 h-5 rounded-full bg-[#1C1917] text-white text-[10px] font-black flex items-center justify-center shrink-0">
                    {(act.actor || 'C').charAt(0)}
                  </div>
                  <span className="font-bold text-[#1C1917]">{act.actor || 'Cán bộ xử lý'}</span>
                  <span className="text-[#78716C] text-[11px]">({act.role || 'Thanh tra Môi trường'})</span>
                </div>

                {/* Target Entity */}
                <div className="text-xs font-bold text-[#B91C1C] mt-1 break-words">
                  🎯 Đối tượng: {act.target || act.entityName || 'Hồ sơ giám sát'}
                </div>

                {/* Details Box */}
                <div className="mt-2 p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs text-[#57534E] leading-relaxed break-words">
                  {act.details || act.description || 'Đã thực hiện cập nhật dữ liệu thành công trên hệ thống D1.'}
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

