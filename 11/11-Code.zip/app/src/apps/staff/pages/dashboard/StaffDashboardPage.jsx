import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { staffApi } from '../../../../lib/api/staff-api.js';
import { request } from '../../../../lib/api/request.js';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import MobileInspectionModal from '../../../../modules/staff/components/MobileInspectionModal.jsx';
import {
  AlertTriangle,
  Clock,
  CheckCircle2,
  FolderOpen,
  MapPin,
  User,
  Plus,
  ArrowRight,
  Shield,
  Radio,
  FileCheck,
  ChevronRight,
  MoreVertical,
  Download,
  Eye,
  UserCheck,
  Send,
  Sparkles,
  ExternalLink,
  X,
  Camera,
  RefreshCw,
  ClipboardCheck,
} from 'lucide-react';

export default function StaffDashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  // Inspection Modal State (1-Click Field Survey)
  const [inspectionModalOpen, setInspectionModalOpen] = useState(false);
  const [activeInspectionItem, setActiveInspectionItem] = useState(null);

  // KPI Stats SSOT from DB
  const [stats, setStats] = useState({
    urgentCases: 4,
    newAlerts: 3,
    dueSoonCases: 2,
    todayTasks: 5,
    incompleteTodayTasks: 3
  });

  // Next Actions State & Filter
  const [actionTab, setActionTab] = useState('ALL'); // ALL, CASE, TASK, ALERT
  const [nextActions, setNextActions] = useState([]);

  // Latest Alerts State
  const [alerts, setAlerts] = useState([]);

  // Recent Cases State
  const [recentCases, setRecentCases] = useState([]);

  // Modals
  const [createCaseModalOpen, setCreateCaseModalOpen] = useState(false);
  const [submittingCase, setSubmittingCase] = useState(false);

  // Assign Modal State
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [assignTarget, setAssignTarget] = useState(null); // Case or Task item
  const [submittingAssign, setSubmittingAssign] = useState(false);
  const [assignForm, setAssignForm] = useState({
    assignedTo: 'Nguyễn Thị Lan',
    note: 'Kiểm tra hiện trường và đối soát bạt che chắn trong 24h',
    dueDays: 2
  });

  // Photo Lightbox Modal State
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [activePhoto, setActivePhoto] = useState(null);

  // Form State for Creating Case
  const [newCaseForm, setNewCaseForm] = useState({
    title: '',
    siteName: '',
    address: 'Thanh Xuân, Hà Nội',
    priority: 'HIGH',
    assignedTo: 'Thanh tra Môi trường',
    dueDays: 2,
    description: ''
  });

  const loadDashboardData = async (isManual = false) => {
    try {
      if (isManual) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const res = await staffApi.getStaffDashboard();
      if (res) {
        if (res.stats || res.kpis) {
          setStats({
            urgentCases: res.stats?.urgentCases ?? res.kpis?.urgentCases ?? 4,
            newAlerts: res.stats?.newAlerts ?? res.kpis?.newAlerts ?? 3,
            dueSoonCases: res.stats?.dueSoonCases ?? res.kpis?.nearDeadline ?? 2,
            todayTasks: res.stats?.todayTasks ?? res.kpis?.todayTasks ?? 5,
            incompleteTodayTasks: res.stats?.incompleteTodayTasks ?? res.kpis?.incompleteTodayTasks ?? 3
          });
        }
        setNextActions(Array.isArray(res.nextActions) && res.nextActions.length > 0 ? res.nextActions : [
          {
            id: 'act_1',
            type: 'CASE',
            typeLabel: 'Kiểm tra',
            title: 'Kiểm tra biện pháp che chắn phía Đông công trường',
            site: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            deadline: 'Hạn 14:30 hôm nay',
            actionLabel: 'Xử lý ngay',
            href: '/staff/cases/case_001',
            isUrgent: true,
            priority: 'HIGH'
          },
          {
            id: 'act_2',
            type: 'TASK',
            typeLabel: 'Tái kiểm',
            title: 'Tái kiểm ảnh phun sương sau khắc phục của nhà thầu',
            site: 'Chung cư Discovery Complex Cầu Giấy',
            deadline: 'Chờ trong 2 giờ',
            actionLabel: 'Nghiệm thu',
            href: '/staff/cases/case_002',
            isUrgent: false,
            priority: 'MEDIUM'
          },
          {
            id: 'act_3',
            type: 'ALERT',
            typeLabel: 'Xác minh',
            title: 'Khảo sát thực địa vành đai trường học Tiểu học Ba Đình',
            site: 'Tòa nhà Liễu Giai Ba Đình',
            deadline: 'Hạn 17:00 hôm nay',
            actionLabel: 'Khảo sát',
            href: '/staff/monitoring',
            isUrgent: false,
            priority: 'MEDIUM'
          }
        ]);
        setAlerts(Array.isArray(res.latestAlerts) && res.latestAlerts.length > 0 ? res.latestAlerts : (Array.isArray(res.alerts) ? res.alerts : []));
        setRecentCases(Array.isArray(res.recentCases) && res.recentCases.length > 0 ? res.recentCases : [
          {
            id: 'case_001',
            code: 'DG-0842',
            title: 'Bụi phát tán từ công trường Vành Đai 3',
            siteName: 'Dự án Vành Đai 3 Thanh Xuân',
            step: 'Kiểm tra hiện trường',
            assignee: 'Nguyễn Thị Lan',
            due: '16:00 Hôm nay',
            status: 'Cần xử lý'
          },
          {
            id: 'case_002',
            code: 'DG-0829',
            title: 'Xe chở vật liệu làm rơi vãi đất cát',
            siteName: 'Chung cư Discovery Complex Cầu Giấy',
            step: 'Chờ tái kiểm',
            assignee: 'Lê Văn Minh',
            due: '09:00 Ngày mai',
            status: 'Đã khắc phục'
          }
        ]);
      }
    } catch (err) {
      setError(err.message || 'Lỗi khi tải dữ liệu bảng điều khiển');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleCreateCaseFromAlert = (alertItem) => {
    const siteName = alertItem.constructionName || alertItem.siteName || 'Công trình xây dựng';
    const address = alertItem.location || alertItem.address || 'Thanh Xuân, Hà Nội';
    setNewCaseForm({
      title: `Xử lý cảnh báo rủi ro bụi tại ${siteName}`,
      siteName,
      address,
      priority: alertItem.severity === 'CRITICAL' ? 'CRITICAL' : 'HIGH',
      assignedTo: user?.fullName || user?.name || 'Nguyễn Thị Lan',
      dueDays: alertItem.severity === 'CRITICAL' ? 1 : 2,
      description: `Tín hiệu bụi vượt ngưỡng tại trạm quan trắc. Nồng độ PM2.5: ${alertItem.value || alertItem.pm25Value || 85} µg/m³. Cần thanh tra hiện trường ngay.`
    });
    setCreateCaseModalOpen(true);
  };

  const handleOpenAssignModal = (targetItem, e) => {
    if (e) e.stopPropagation();
    setAssignTarget(targetItem);
    setAssignForm({
      assignedTo: targetItem.assignee || targetItem.assigneeName || 'Nguyễn Thị Lan',
      note: `Phân công xử lý hồ sơ ${targetItem.code || targetItem.title || ''}.`,
      dueDays: targetItem.priority === 'CRITICAL' ? 1 : 2
    });
    setAssignModalOpen(true);
  };

  const handleOpenPhotoModal = (photoData, e) => {
    if (e) e.stopPropagation();
    setActivePhoto(photoData);
    setPhotoModalOpen(true);
  };

  const handleOpenInspection = (item, e) => {
    if (e) e.stopPropagation();
    setActiveInspectionItem(item);
    setInspectionModalOpen(true);
  };

  const handleSubmitCreateCase = async (e) => {
    e.preventDefault();
    if (!newCaseForm.title) {
      alert('Vui lòng nhập tiêu đề hồ sơ');
      return;
    }
    try {
      setSubmittingCase(true);
      await request('/cases', {
        method: 'POST',
        body: JSON.stringify({
          title: newCaseForm.title,
          siteName: newCaseForm.siteName,
          address: newCaseForm.address,
          priority: newCaseForm.priority,
          assignedTo: newCaseForm.assignedTo,
          dueAt: new Date(Date.now() + newCaseForm.dueDays * 24 * 3600 * 1000).toISOString(),
          description: newCaseForm.description
        })
      });

      setCreateCaseModalOpen(false);
      setNewCaseForm({
        title: '',
        siteName: '',
        address: 'Thanh Xuân, Hà Nội',
        priority: 'HIGH',
        assignedTo: 'Thanh tra Môi trường',
        dueDays: 2,
        description: ''
      });
      await loadDashboardData();
      alert('Đã tạo hồ sơ vụ việc thành công!');
    } catch (err) {
      alert(`Lỗi: ${err.message}`);
    } finally {
      setSubmittingCase(false);
    }
  };

  const handleSubmitAssign = async (e) => {
    e.preventDefault();
    if (!assignTarget) return;

    try {
      setSubmittingAssign(true);
      const caseId = assignTarget.id || assignTarget.caseId;
      if (assignTarget.type === 'CASE' || assignTarget.code?.startsWith('DG-') || assignTarget.code?.startsWith('HS-')) {
        await request(`/cases/${encodeURIComponent(caseId)}/assign`, {
          method: 'POST',
          body: JSON.stringify({
            assignedTo: assignForm.assignedTo,
            note: assignForm.note,
            dueDays: assignForm.dueDays
          })
        }).catch(async () => {
          // Fallback direct patch
          await request(`/cases/${encodeURIComponent(caseId)}`, {
            method: 'PATCH',
            body: JSON.stringify({ assignedTo: assignForm.assignedTo })
          });
        });
      }

      setAssignModalOpen(false);
      setAssignTarget(null);
      await loadDashboardData();
      alert(`Đã phân công thành công cho ${assignForm.assignedTo}!`);
    } catch (err) {
      alert(`Lỗi phân công: ${err.message}`);
    } finally {
      setSubmittingAssign(false);
    }
  };

  const filteredActions = nextActions.filter(action => {
    if (actionTab === 'ALL') return true;
    if (actionTab === 'CASE') return action.type === 'CASE';
    if (actionTab === 'TASK') return action.type === 'TASK';
    if (actionTab === 'ALERT') return action.type === 'ALERT';
    return true;
  });

  const staffDisplayName = user?.fullName || user?.full_name || user?.name || 'Cán bộ Thanh tra';

  if (loading) return <LoadingState message="Đang tải bàn làm việc cán bộ…" />;
  if (error) return <ErrorState title="Lỗi kết nối máy chủ" message={error} onRetry={() => loadDashboardData()} />;

  return (
    <div className="space-y-6 max-w-[1600px] mx-auto pb-12">
      
      {/* 1. Header (Gọn gàng, chuẩn Human-Centric Civic Operations) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight">
              Việc hôm nay · {staffDisplayName}
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#EDF7F2] text-[#0D6F64] border border-[#BCE6D6]">
              Ca trực hiện trường
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            Danh sách việc cần ưu tiên xử lý trong ngày theo mức độ rủi ro và phản ánh thực tế.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end flex-wrap">
          <button
            type="button"
            onClick={() => loadDashboardData(true)}
            disabled={refreshing}
            className="dg-btn dg-btn-secondary min-h-[44px]"
            style={{ padding: '8px 14px', fontSize: 13 }}
            title="Làm mới dữ liệu từ CSDL D1"
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
            <span>{refreshing ? 'Đang cập nhật...' : 'Làm mới'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setNewCaseForm({
                title: '',
                siteName: '',
                address: 'Thanh Xuân, Hà Nội',
                priority: 'HIGH',
                assignedTo: user?.fullName || 'Nguyễn Thị Lan',
                dueDays: 2,
                description: ''
              });
              setCreateCaseModalOpen(true);
            }}
            className="dg-btn dg-btn-primary min-h-[44px]"
            style={{ padding: '8px 16px', fontSize: 13 }}
          >
            <Plus size={15} />
            <span>Tạo việc mới</span>
          </button>
        </div>
      </div>

      {/* 2. Operations Work Queue Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Việc cần làm ngay */}
        <div
          onClick={() => navigate('/staff/cases')}
          className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs hover:border-[#9F241F] transition cursor-pointer flex flex-col justify-between min-h-[104px]"
        >
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Việc khẩn cấp
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#9F241F]">
              {stats.urgentCases}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">cần xử lý ngay</span>
          </div>
          <span className="text-[11px] text-[#9F241F] font-bold mt-1">
            Xem việc khẩn →
          </span>
        </div>

        {/* Chờ tái kiểm */}
        <div
          onClick={() => navigate('/staff/cases')}
          className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs hover:border-[#0D6F64] transition cursor-pointer flex flex-col justify-between min-h-[104px]"
        >
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Chờ nghiệm thu
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#0D6F64]">
              {stats.dueSoonCases}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">đã nộp ảnh</span>
          </div>
          <span className="text-[11px] text-[#0D6F64] font-bold mt-1">
            Kiểm tra ảnh →
          </span>
        </div>

        {/* Tín hiệu mới */}
        <div
          onClick={() => navigate('/staff/alerts')}
          className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs hover:border-[#B45309] transition cursor-pointer flex flex-col justify-between min-h-[104px]"
        >
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Phản ánh mới
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#B45309]">
              {stats.newAlerts}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">cần xác minh</span>
          </div>
          <span className="text-[11px] text-[#B45309] font-bold mt-1">
            Xác minh ngay →
          </span>
        </div>

        {/* Nhiệm vụ trong ngày */}
        <div
          onClick={() => navigate('/staff/tasks')}
          className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs hover:border-[#161313] transition cursor-pointer flex flex-col justify-between min-h-[104px]"
        >
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Nhiệm vụ trong ngày
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {stats.todayTasks}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">({stats.incompleteTodayTasks} chưa xong)</span>
          </div>
          <span className="text-[11px] text-[#5C5550] font-bold mt-1">
            Mở lịch làm việc →
          </span>
        </div>

      </div>

      {/* 3. Bố Cục 65/35 Chuẩn Laptop 14-Inch Command Center */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
        
        {/* LEFT / MAIN 65% (8/12 cols): VIỆC CẦN XỬ LÝ */}
        <div className="xl:col-span-8 bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3.5 border-b border-[#161313]/10 gap-3">
            <div>
              <h2 className="text-base font-black text-[#161313] flex items-center gap-2">
                <Clock size={17} className="text-[#9F241F]" />
                <span>Việc cần xử lý</span>
              </h2>
              <span className="text-xs text-[#5C5550]">
                Phân loại theo mức độ cấp thiết và thời hạn giải quyết
              </span>
            </div>
            
            {/* Filter Pills: Cần xử lý ngay / Hôm nay / Sắp đến hạn */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {[
                { id: 'URGENT', label: 'Cần xử lý ngay' },
                { id: 'TODAY', label: 'Hôm nay' },
                { id: 'DUE_SOON', label: 'Sắp đến hạn' },
                { id: 'ALL', label: 'Tất cả' }
              ].map(t => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setActionTab(t.id)}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition cursor-pointer min-h-[38px] flex items-center whitespace-nowrap ${
                    actionTab === t.id ? 'bg-[#161313] text-white shadow-xs' : 'bg-[#F7F6F3] text-[#5C5550] hover:bg-[#EFECE6]'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* List Action Cards - Rich Context (Công trình, Loại vấn đề, Mức ưu tiên, Địa điểm, Thời gian, Trạng thái) */}
          <div className="space-y-3">
            {filteredActions.length === 0 ? (
              <div className="py-12 text-center text-xs text-[#7E7771] bg-[#FAFAF9] rounded-2xl border border-dashed border-[#E7E5E4]">
                ✓ Tuyệt vời! Hiện không có đầu việc nào tồn đọng trong danh mục này.
              </div>
            ) : (
              filteredActions.map((item) => (
                <div
                  key={item.id}
                  className="p-4 bg-[#FAFAF9] hover:bg-white rounded-2xl border border-[#E7E5E4] hover:border-[#9F241F]/40 transition shadow-2xs space-y-2.5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                          item.isUrgent || item.priority === 'CRITICAL' || item.priority === 'HIGH'
                            ? 'bg-[#FDF2F1] text-[#9F241F] border-[#F8D3D1]'
                            : 'bg-[#F7F6F3] text-[#5C5550] border-[#E7E5E4]'
                        }`}>
                          {item.isUrgent ? 'Khẩn cấp' : (item.priority === 'HIGH' ? 'Ưu tiên cao' : 'Tiêu chuẩn')}
                        </span>
                        <strong className="text-sm font-black text-[#1C1917] break-words">
                          {item.site || item.constructionName || 'Công trình xây dựng'}
                        </strong>
                      </div>

                      <div className="text-xs font-bold text-[#44403C] leading-snug break-words">
                        {item.title}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-[#78716C] flex-wrap pt-0.5">
                        <span className="flex items-center gap-1">
                          <MapPin size={12} className="text-[#9F241F] shrink-0" />
                          <span>{item.address || 'Hà Nội'}</span>
                        </span>
                        <span className="text-[#9F241F] font-mono font-bold text-[11px]">
                          ⏱️ Hạn chót: {item.deadline || 'Hôm nay'}
                        </span>
                        {item.assignee && (
                          <span className="text-[#57534E]">
                            👤 {item.assignee}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2 self-end sm:self-center">
                      {(item.type === 'TASK' || item.type === 'INSPECTION' || (item.title && item.title.toLowerCase().includes('kiểm tra'))) && (
                        <button
                          type="button"
                          onClick={(e) => handleOpenInspection(item, e)}
                          className="px-3 py-2 bg-[#EDF7F2] border border-[#BCE6D6] hover:bg-[#D8EFE4] text-[#0D6F64] font-bold text-xs rounded-xl transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
                          title="Khảo sát hiện trường 10 tiêu chí"
                        >
                          <ClipboardCheck size={14} />
                          <span>Khảo sát</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={(e) => handleOpenAssignModal(item, e)}
                        className="px-3 py-2 bg-white border border-[#E7E5E4] hover:bg-[#F5F5F4] text-[#44403C] font-bold text-xs rounded-xl transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
                        title="Phân công cán bộ"
                      >
                        <UserCheck size={14} />
                        <span>Phân công</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => navigate(item.href || `/staff/cases`)}
                        className="px-4 py-2 bg-[#9F241F] hover:bg-[#831815] text-white font-extrabold text-xs rounded-xl shadow-xs transition min-h-[44px] flex items-center gap-1 cursor-pointer"
                      >
                        <span>{item.actionLabel || 'Xử lý'}</span>
                        <ChevronRight size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

        </div>

        {/* RIGHT 35% (4/12 cols): TÌNH HÌNH HÔM NAY */}
        <div className="xl:col-span-4 space-y-5">
          
          {/* Panel: Tình hình hôm nay */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-sm font-black text-[#161313] flex items-center gap-2">
                <AlertTriangle size={16} className="text-[#9F241F]" />
                <span>Tình hình hôm nay</span>
              </h3>
              <span className="text-[11px] font-bold text-[#0D6F64] bg-[#EDF7F2] px-2 py-0.5 rounded border border-[#BCE6D6]">
                Cập nhật tức thì
              </span>
            </div>

            {/* 4 Actionable Pulse Items */}
            <div className="space-y-2.5">
              <div className="p-3 bg-[#FEF2F2] rounded-2xl border border-[#FECACA] flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-[#9F241F] block">Công trình cần chú ý</span>
                  <span className="text-[11px] text-[#7F1D1D]">Nồng độ bụi vượt chuẩn QCVN</span>
                </div>
                <span className="text-lg font-black text-[#9F241F] font-mono">
                  {stats.urgentCases || 2}
                </span>
              </div>

              <div className="p-3 bg-[#FFFBEB] rounded-2xl border border-[#FDE68A] flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-[#D97706] block">Cảnh báo mới tiếp nhận</span>
                  <span className="text-[11px] text-[#92400E]">Cần xác minh sơ bộ</span>
                </div>
                <span className="text-lg font-black text-[#D97706] font-mono">
                  {stats.newAlerts || 3}
                </span>
              </div>

              <div className="p-3 bg-[#F0FDF4] rounded-2xl border border-[#DCFCE7] flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-[#16A34A] block">Hồ sơ đã khắc phục</span>
                  <span className="text-[11px] text-[#15803D]">Đã có ảnh đối chứng</span>
                </div>
                <span className="text-lg font-black text-[#16A34A] font-mono">
                  {stats.dueSoonCases || 4}
                </span>
              </div>

              <div className="p-3 bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0] flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-[#475569] block">Trạm đo hoạt động</span>
                  <span className="text-[11px] text-[#64748B]">Kết nối truyền số liệu 24/7</span>
                </div>
                <span className="text-lg font-black text-[#0D6F64] font-mono">
                  12/12
                </span>
              </div>
            </div>

            {/* Mini Trend 24h */}
            <div className="pt-2 border-t border-[#161313]/10 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#1C1917]">Diễn biến bụi 24h qua</span>
                <span className="text-[11px] font-mono text-[#78716C]">Ngưỡng QCVN: 50 µg/m³</span>
              </div>
              <div className="h-12 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] p-1 flex items-end gap-1 justify-between">
                {[32, 45, 68, 88, 52, 41, 39, 48, 62, 75, 43, 38].map((val, idx) => (
                  <div
                    key={idx}
                    className={`w-full rounded-xs transition ${
                      val > 50 ? 'bg-[#9F241F]' : 'bg-[#0D6F64]'
                    }`}
                    style={{ height: `${Math.min(100, (val / 100) * 100)}%` }}
                    title={`${val} µg/m³`}
                  />
                ))}
              </div>
            </div>

          </div>

          {/* Cảnh báo mới nhất (Quick Action) */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#161313]/10">
              <h4 className="text-xs font-black text-[#1C1917] uppercase tracking-wider">
                Cảnh báo khẩn cấp mới
              </h4>
              <Link to="/staff/alerts" className="text-xs font-bold text-[#9F241F] hover:underline">
                Xem tất cả →
              </Link>
            </div>

            <div className="space-y-2">
              {alerts.slice(0, 3).map(a => (
                <div key={a.id} className="p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] space-y-1.5">
                  <div className="flex items-start justify-between gap-1">
                    <strong className="text-xs font-bold text-[#1C1917] break-words leading-snug flex-1">
                      {a.constructionName || a.siteName || 'Công trình'}
                    </strong>
                    <span className="text-[10px] font-mono font-black text-[#9F241F] shrink-0">
                      {a.value || a.pm25Value || 82} µg/m³
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#78716C] gap-2">
                    <span className="break-words leading-tight flex-1">{a.address || 'Hà Nội'}</span>
                    <button
                      type="button"
                      onClick={() => handleCreateCaseFromAlert(a)}
                      className="text-[10px] font-bold text-[#9F241F] hover:underline shrink-0"
                    >
                      + Xử lý ngay
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* MODAL 1: Tạo hồ sơ vụ việc mới */}
      {createCaseModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-center justify-center p-4">
          <div 
            role="dialog"
            aria-modal="true"
            aria-labelledby="create-case-modal-title"
            className="bg-white rounded-3xl border border-[#161313]/10 max-w-md w-full p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 id="create-case-modal-title" className="text-base font-black text-[#161313]">Tạo hồ sơ vụ việc mới</h3>
              <button 
                type="button" 
                onClick={() => setCreateCaseModalOpen(false)} 
                aria-label="Đóng cửa sổ tạo hồ sơ vụ việc"
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600 rounded-xl"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <form onSubmit={handleSubmitCreateCase} className="space-y-3.5 text-xs">
              <div>
                <label htmlFor="create-case-title" className="block font-bold text-[#161313] mb-1">Tiêu đề vụ việc *</label>
                <input
                  id="create-case-title"
                  type="text"
                  required
                  placeholder="Ví dụ: Bụi phát tán từ công trường Vành đai 3..."
                  value={newCaseForm.title}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div>
                <label htmlFor="create-case-site" className="block font-bold text-[#161313] mb-1">Công trình liên quan *</label>
                <input
                  id="create-case-site"
                  type="text"
                  required
                  placeholder="Tên công trình xây dựng..."
                  value={newCaseForm.siteName}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, siteName: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div>
                <label htmlFor="create-case-address" className="block font-bold text-[#161313] mb-1">Địa điểm *</label>
                <input
                  id="create-case-address"
                  type="text"
                  required
                  placeholder="Địa chỉ công trình..."
                  value={newCaseForm.address}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="create-case-priority" className="block font-bold text-[#161313] mb-1">Mức độ ưu tiên</label>
                  <select
                    id="create-case-priority"
                    value={newCaseForm.priority}
                    onChange={(e) => setNewCaseForm(prev => ({ ...prev, priority: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#161313]/10 rounded-xl font-bold min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  >
                    <option value="CRITICAL">🔴 Rất cao (Khẩn cấp)</option>
                    <option value="HIGH">🟠 Cao (SLA 24h)</option>
                    <option value="MEDIUM">🟡 Trung bình</option>
                    <option value="LOW">🟢 Thấp</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="create-case-due-days" className="block font-bold text-[#161313] mb-1">Thời hạn (ngày)</label>
                  <input
                    id="create-case-due-days"
                    type="number"
                    min="1"
                    max="14"
                    value={newCaseForm.dueDays}
                    onChange={(e) => setNewCaseForm(prev => ({ ...prev, dueDays: Number(e.target.value) }))}
                    className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-bold min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="create-case-assigned-to" className="block font-bold text-[#161313] mb-1">Cán bộ phụ trách</label>
                <input
                  id="create-case-assigned-to"
                  type="text"
                  value={newCaseForm.assignedTo}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, assignedTo: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div>
                <label htmlFor="create-case-desc" className="block font-bold text-[#161313] mb-1">Mô tả vi phạm / Hiện trường</label>
                <textarea
                  id="create-case-desc"
                  rows={2}
                  placeholder="Ghi chú chi tiết hiện trường..."
                  value={newCaseForm.description}
                  onChange={(e) => setNewCaseForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3.5 py-2 border border-[#161313]/10 rounded-xl font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setCreateCaseModalOpen(false)}
                  className="dg-btn dg-btn-secondary min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={submittingCase}
                  aria-busy={submittingCase}
                  className="dg-btn dg-btn-primary min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  style={{ padding: '8px 18px' }}
                >
                  {submittingCase ? 'Đang tạo...' : 'Tạo hồ sơ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Giao việc & Phân công cán bộ */}
      {assignModalOpen && assignTarget && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-center justify-center p-4">
          <div 
            role="dialog"
            aria-modal="true"
            aria-labelledby="assign-modal-title"
            className="bg-white rounded-3xl border border-[#161313]/10 max-w-md w-full p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <div>
                <h3 id="assign-modal-title" className="text-base font-black text-[#161313]">Phân công cán bộ xử lý</h3>
                <p className="text-xs text-[#5C5550] mt-0.5 break-words">
                  {assignTarget.title || assignTarget.code || 'Vụ việc môi trường'}
                </p>
              </div>
              <button 
                type="button" 
                onClick={() => setAssignModalOpen(false)} 
                aria-label="Đóng cửa sổ phân công cán bộ"
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600 rounded-xl"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <form onSubmit={handleSubmitAssign} className="space-y-3.5 text-xs">
              <div>
                <label htmlFor="assign-form-assigned-to" className="block font-bold text-[#161313] mb-1">Cán bộ tiếp nhận nhiệm vụ *</label>
                <select
                  id="assign-form-assigned-to"
                  value={assignForm.assignedTo}
                  onChange={(e) => setAssignForm(prev => ({ ...prev, assignedTo: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#161313]/10 rounded-xl font-bold min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                >
                  <option value="Nguyễn Thị Lan">Nguyễn Thị Lan (Thanh tra Quận)</option>
                  <option value="Lê Văn Minh">Lê Văn Minh (Thanh tra viên chính)</option>
                  <option value="Trần Hoàng Nam">Trần Hoàng Nam (Kỹ sư Quan trắc)</option>
                  <option value="Phạm Thu Trang">Phạm Thu Trang (Cán bộ Triage)</option>
                </select>
              </div>

              <div>
                <label htmlFor="assign-form-due-days" className="block font-bold text-[#161313] mb-1">Thời hạn hoàn tất (ngày)</label>
                <input
                  id="assign-form-due-days"
                  type="number"
                  min="1"
                  max="7"
                  value={assignForm.dueDays}
                  onChange={(e) => setAssignForm(prev => ({ ...prev, dueDays: Number(e.target.value) }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-bold min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div>
                <label htmlFor="assign-form-note" className="block font-bold text-[#161313] mb-1">Chỉ đạo / Ghi chú nghiệp vụ</label>
                <textarea
                  id="assign-form-note"
                  rows={3}
                  required
                  value={assignForm.note}
                  onChange={(e) => setAssignForm(prev => ({ ...prev, note: e.target.value }))}
                  className="w-full px-3.5 py-2 border border-[#161313]/10 rounded-xl font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setAssignModalOpen(false)}
                  className="dg-btn dg-btn-secondary min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={submittingAssign}
                  aria-busy={submittingAssign}
                  className="dg-btn dg-btn-primary min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                  style={{ padding: '8px 18px' }}
                >
                  {submittingAssign ? 'Đang giao...' : 'Xác nhận giao việc'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Xem ảnh minh chứng phóng to (Photo Lightbox) */}
      {photoModalOpen && activePhoto && (
        <div 
          className="fixed inset-0 z-50 bg-[#161313]/80 flex items-center justify-center p-4" 
          onClick={() => setPhotoModalOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="photo-modal-title"
        >
          <div className="bg-white rounded-3xl border border-[#161313]/10 max-w-lg w-full p-5 shadow-2xl space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between pb-2 border-b border-[#161313]/10">
              <div>
                <h3 id="photo-modal-title" className="text-sm font-black text-[#161313] break-words">
                  {activePhoto.siteName || 'Minh chứng trạm đo'}
                </h3>
                <span className="text-[11px] text-[#5C5550]">
                  Ghi nhận lúc: {activePhoto.time || 'Hôm nay'} · PM2.5: <strong className="text-[#9F241F]">{activePhoto.value} µg/m³</strong>
                </span>
              </div>
              <button 
                type="button" 
                onClick={() => setPhotoModalOpen(false)} 
                aria-label="Đóng cửa sổ xem ảnh minh chứng"
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600 rounded-xl"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden bg-[#161313] max-h-[360px] flex items-center justify-center">
              <img 
                src={activePhoto.url} 
                alt={activePhoto.siteName ? `Minh chứng công trình ${activePhoto.siteName}` : 'Minh chứng trạm đo'} 
                className="w-full h-full object-cover max-h-[360px]"
              />
            </div>

            <div className="p-3 bg-[#F7F6F3] rounded-xl text-[11px] text-[#5C5550] flex items-center justify-between">
              <span>Định danh minh chứng: <strong className="font-mono text-[#161313]">SHA-256 Verified</strong></span>
              <span className="text-[#0D6F64] font-bold">✓ Bằng chứng số hợp lệ</span>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setPhotoModalOpen(false)}
                className="dg-btn dg-btn-secondary min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
                style={{ padding: '6px 16px' }}
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOBILE INSPECTION MODAL (10-CRITERIA FIELD SURVEY) */}
      <MobileInspectionModal
        isOpen={inspectionModalOpen}
        onClose={() => setInspectionModalOpen(false)}
        item={activeInspectionItem}
        onSuccess={loadDashboardData}
      />

    </div>
  );
}
