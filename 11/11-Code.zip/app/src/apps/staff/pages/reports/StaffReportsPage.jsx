import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffReportsPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // States from D1
  const [kpis, setKpis] = useState({
    weeklyCases: 128,
    completedCases: 96,
    overdueCases: 12,
    onTimeRate: 89
  });
  const [trendData, setTrendData] = useState([
    { week: 'Tuần 21', created: 85, completed: 70, overdue: 8 },
    { week: 'Tuần 22', created: 98, completed: 82, overdue: 10 },
    { week: 'Tuần 23', created: 112, completed: 89, overdue: 14 },
    { week: 'Tuần 24', created: 128, completed: 96, overdue: 12 }
  ]);
  const [reportsList, setReportsList] = useState([
    {
      id: 'rep_01',
      name: 'Báo cáo tổng hợp quan trắc & xử lý tuần 24',
      scope: 'Toàn thành phố Hà Nội',
      createdAt: '08:30 02/09/2026',
      createdBy: 'Nguyễn Văn An'
    },
    {
      id: 'rep_02',
      name: 'Báo cáo chuyên đề công trình trọng điểm quận Thanh Xuân',
      scope: 'Quận Thanh Xuân',
      createdAt: '16:45 01/09/2026',
      createdBy: 'Trần Thị Bình'
    },
    {
      id: 'rep_03',
      name: 'Báo cáo danh sách các vụ việc quá hạn xử lý',
      scope: 'Tất cả các quận',
      createdAt: '09:15 30/08/2026',
      createdBy: 'Lê Hoàng Nam'
    }
  ]);
  const [autoEmailEnabled, setAutoEmailEnabled] = useState(true);
  const [scheduleTime, setScheduleTime] = useState('08:00');
  const [scheduleDay, setScheduleDay] = useState('MON');
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [printPreviewModal, setPrintPreviewModal] = useState({ open: false, report: null });
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3000);
  };

  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/reports/summary');
      if (res?.data) {
        setKpis(res.data);
      }
    } catch (err) {
      console.error('Error fetching reports summary:', err);
    }
  }, []);

  const fetchTrend = useCallback(async () => {
    try {
      const res = await request('/staff/reports/trend');
      if (res?.data?.weeklyData && Array.isArray(res.data.weeklyData) && res.data.weeklyData.length > 0) {
        setTrendData(res.data.weeklyData);
      }
    } catch (err) {
      console.error('Error fetching trend:', err);
    }
  }, []);

  const fetchList = useCallback(async () => {
    try {
      const res = await request('/staff/reports/list');
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setReportsList(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching reports list:', err);
    }
  }, []);

  const loadAll = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchTrend(), fetchList()]);
    } catch (err) {
      setError(err.message || 'Không thể tải dữ liệu báo cáo từ D1/SQLite');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchTrend, fetchList]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleExportWord = async (reportTitle) => {
    try {
      const { exportLegalDocumentDocxBlob } = await import('../../../../legal-document-engine/renderers/renderLegalDocumentDocx.js');
      const ast = {
        standard: 'Nghị định 30/2020/NĐ-CP',
        header: {
          agency: ['ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI', 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG'],
          docNum: 'Số: 128/BC-STNMT-TT',
          motto: {
            title: 'CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM',
            text: 'Độc lập - Tự do - Hạnh phúc'
          },
          datePlace: `Hà Nội, ${new Date().toLocaleDateString('vi-VN')}`
        },
        title: 'BÁO CÁO CÔNG TÁC QUAN TRẮC VÀ XỬ LÝ VI PHẠM',
        subtitle: reportTitle,
        sections: [
          {
            title: 'I. TÌNH HÌNH QUAN TRẮC & CHỈ SỐ PHÁT TÁN BỤI',
            content: [
              'Tổng số trạm quan trắc IoT trực tuyến đang hoạt động: 18 trạm trên địa bàn 6 quận trọng điểm.',
              'Số điểm ghi nhận bụi vượt ngưỡng QCVN: 3 công trình (nồng độ PM10 cao nhất đạt 172 µg/m³).'
            ]
          },
          {
            title: 'II. KẾT QUẢ KIỂM TRA VÀ XỬ LÝ VI PHẠM',
            content: [
              `- Tổng số hồ sơ giám sát tuần này: ${kpis.weeklyCases} vụ (hoàn tất 100%).`,
              `- Số vụ việc đã xử lý khắc phục hoàn tất đúng hạn: ${kpis.completedCases} vụ (Tỷ lệ đúng hạn: ${kpis.onTimeRate}%).`,
              `- Số vụ việc quá hạn đang đôn đốc: ${kpis.overdueCases} vụ.`
            ]
          },
          {
            title: 'III. ĐỀ XUẤT VÀ KIẾN NGHỊ',
            content: [
              'Yêu cầu các chủ đầu tư và nhà thầu thi công nghiêm túc thực hiện việc che bạt kín bãi vật liệu, vận hành trạm rửa xe tự động và phun nước giảm bụi định kỳ theo quy chuẩn.'
            ]
          }
        ],
        recipients: [
          'UBND Thành phố Hà Nội (để b/c);',
          'Ban Giám đốc Sở TN&MT;',
          'UBND các quận, huyện;',
          'Lưu: VT, TT.'
        ],
        signatures: [
          {
            role: 'KT. GIÁM ĐỐC / PHÓ GIÁM ĐỐC',
            note: '(Ký, ghi rõ họ tên và đóng dấu)',
            name: 'Nguyễn Văn An'
          }
        ]
      };
      const blob = await exportLegalDocumentDocxBlob(ast, {
        statusData: {
          status: 'APPROVED',
          officer: 'Nguyễn Văn An',
          timestamp: new Date().toLocaleString('vi-VN'),
          hash: 'SHA256:8F94A1B09E2C4D6E8F0123456789ABCD'
        }
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportTitle.replace(/\s+/g, '_')}_ND30.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Lỗi xuất DOCX:', err);
      const blob = new Blob([`BÁO CÁO CÔNG TÁC QUAN TRẮC VÀ XỬ LÝ VI PHẠM PHÁT TÁN BỤI\n${reportTitle}\nThời gian: ${new Date().toLocaleDateString('vi-VN')}`], { type: 'application/msword;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportTitle.replace(/\s+/g, '_')}.doc`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleExportCsv = (reportTitle) => {
    const csvContent = `STT,Mục,Số lượng,Ghi chú\n1,Tổng số hồ sơ giám sát,${kpis.weeklyCases},Tuần hiện tại\n2,Số vụ việc đã xử lý hoàn tất,${kpis.completedCases},Đạt tỷ lệ ${kpis.onTimeRate}%\n3,Số vụ việc quá hạn,${kpis.overdueCases},Cần đôn đốc\n`;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reportTitle.replace(/\s+/g, '_')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <LoadingState message="Đang nạp dữ liệu báo cáo từ CSDL SQLite..." />;
  if (error) return <ErrorState title="Lỗi tải báo cáo" message={error} onRetry={loadAll} />;

  return (
    <div className="space-y-5">
      
      {/* 1. Header & Top Action Bar (Mockup 9) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="text-xs font-semibold text-[#78716C]">
            <Link to="/staff" className="hover:text-[#B91C1C]">Trang chính</Link> / Báo cáo
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight mt-0.5">
            Báo cáo và chia sẻ
          </h1>
          <p className="text-xs sm:text-sm text-[#78716C] mt-0.5 font-medium">
            Tạo, xuất bản và chia sẻ kết quả theo dõi định kỳ.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#7C3AED] bg-[#F5F3FF] border border-[#DDD6FE] px-3 py-1.5 rounded-full">
            <span>✨</span>
            <span>AI soạn nháp, bạn duyệt trước</span>
          </div>

          <button
            onClick={() => setCreateModalOpen(true)}
            className="px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span className="text-base leading-none">+</span>
            <span>Tạo báo cáo</span>
          </button>

          <button
            onClick={() => setScheduleModalOpen(true)}
            className="px-3.5 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs transition flex items-center gap-1.5 min-h-[44px] cursor-pointer"
          >
            <span>📅</span>
            <span>Lên lịch gửi</span>
          </button>
        </div>
      </div>

      {/* 2. Top 4 Metric KPI Cards (Mockup 9) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* KPI 1: Hồ sơ tuần này */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#EFF6FF] text-[#2563EB] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Hồ sơ tuần này</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.weeklyCases}</div>
            <div className="text-[10px] font-bold text-[#B91C1C] mt-0.5">↑ 18 so với tuần trước</div>
          </div>
        </div>

        {/* KPI 2: Đã hoàn tất */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#F0FDF4] text-[#16A34A] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Đã hoàn tất</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.completedCases}</div>
            <div className="text-[10px] font-bold text-[#16A34A] mt-0.5">↑ 14 so với tuần trước</div>
          </div>
        </div>

        {/* KPI 3: Quá hạn */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FEF2F2] text-[#B91C1C] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Quá hạn</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.overdueCases}</div>
            <div className="text-[10px] font-bold text-[#B91C1C] mt-0.5">↑ 3 so với tuần trước</div>
          </div>
        </div>

        {/* KPI 4: Tỷ lệ đúng hạn */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FAF5FF] text-[#9333EA] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#57534E] truncate">Tỷ lệ đúng hạn</div>
            <div className="text-xl sm:text-2xl font-black text-[#1C1917] leading-tight mt-0.5">{kpis.onTimeRate}%</div>
            <div className="text-[10px] font-bold text-[#16A34A] mt-0.5">↑ 6% so với tuần trước</div>
          </div>
        </div>

      </div>

      {/* 3. Middle Row: 4-Week Trend Chart + Quick Report Templates (Mockup 9) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        {/* Left: Kết quả 4 tuần gần đây (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <span className="font-black text-xs sm:text-sm text-[#1C1917]">Kết quả 4 tuần gần đây</span>
            <div className="flex items-center gap-3 text-[10px] font-bold">
              <span className="flex items-center gap-1 text-[#2563EB]"><span className="w-2 h-2 rounded-full bg-[#2563EB]" /> Tạo mới</span>
              <span className="flex items-center gap-1 text-[#16A34A]"><span className="w-2 h-2 rounded-full bg-[#16A34A]" /> Đã hoàn tất</span>
              <span className="flex items-center gap-1 text-[#B91C1C]"><span className="w-2 h-2 rounded-full bg-[#B91C1C]" /> Quá hạn</span>
            </div>
          </div>

          <div className="h-44 flex items-end justify-between gap-3 pt-6 px-2">
            {trendData.map((d, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex items-end justify-center gap-1 h-32">
                  <div style={{ height: `${(d.created / 140) * 110}px` }} className="w-2.5 bg-[#2563EB] rounded-t-sm" title={`Tạo mới: ${d.created}`} />
                  <div style={{ height: `${(d.completed / 140) * 110}px` }} className="w-2.5 bg-[#16A34A] rounded-t-sm" title={`Đã xong: ${d.completed}`} />
                  <div style={{ height: `${(d.overdue / 140) * 110}px` }} className="w-2.5 bg-[#B91C1C] rounded-t-sm" title={`Quá hạn: ${d.overdue}`} />
                </div>
                <span className="text-[10px] font-bold text-[#78716C]">{d.week}</span>
              </div>
            ))}
          </div>

          {/* Banner Tự động gửi email Thứ 2 */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4] text-xs">
            <div className="flex items-center gap-2.5">
              <span className="text-xl">⏰</span>
              <div>
                <div className="font-bold text-[#1C1917]">Tự động gửi báo cáo tuần vào 8:00 sáng Thứ 2</div>
                <div className="text-[10px] text-[#78716C]">Gửi đến ban giám đốc và các đầu mối phụ trách</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setScheduleModalOpen(true)} className="px-3 py-1.5 border border-[#E7E5E4] rounded-xl font-bold text-xs hover:bg-white min-h-[36px] cursor-pointer">
                Sửa lịch
              </button>
              <button onClick={() => {
                const nextState = !autoEmailEnabled;
                setAutoEmailEnabled(nextState);
                showToast(nextState ? 'Đã bật tự động gửi báo cáo định kỳ' : 'Đã tắt tự động gửi báo cáo');
              }} className={`px-3 py-1.5 rounded-xl font-bold text-xs min-h-[36px] cursor-pointer ${autoEmailEnabled ? 'bg-[#FEF2F2] text-[#B91C1C]' : 'bg-[#F0FDF4] text-[#16A34A]'}`}>
                {autoEmailEnabled ? 'Tắt' : 'Bật'}
              </button>
            </div>
          </div>
        </div>

        {/* Right: Báo cáo nhanh 4 mẫu (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3">
          <div className="font-black text-xs sm:text-sm text-[#1C1917] pb-2 border-b border-[#E7E5E4]">
            Báo cáo nhanh
          </div>

          <div className="space-y-2.5">
            {[
              { id: 1, title: 'Báo cáo tổng hợp tuần', desc: 'Bao gồm chỉ số, hồ sơ và danh sách công trình.' },
              { id: 2, title: 'Báo cáo các vụ việc quá hạn', desc: 'Danh sách hồ sơ chưa hoàn thành đúng hạn.' },
              { id: 3, title: 'Báo cáo theo công trình', desc: 'Chọn công trình để xuất lịch sử và hồ sơ liên quan.' },
              { id: 4, title: 'Báo cáo theo khu vực', desc: 'Tổng hợp theo phường/xã hoặc quận/huyện.' }
            ].map(m => (
              <div key={m.id} className="p-3 rounded-xl border border-[#E7E5E4] bg-[#FAFAF9] space-y-2">
                <div>
                  <div className="font-bold text-xs text-[#1C1917]">{m.title}</div>
                  <div className="text-[10px] text-[#78716C] mt-0.5">{m.desc}</div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <button
                    onClick={() => setPrintPreviewModal({
                      open: true,
                      report: {
                        name: m.title,
                        scope: 'Thành phố Hà Nội',
                        createdAt: new Date().toLocaleDateString('vi-VN'),
                        createdBy: 'Nguyễn Văn An'
                      }
                    })}
                    className="px-3 py-1.5 border border-[#B91C1C] bg-[#FEF2F2] text-[#B91C1C] rounded-xl text-[11px] font-bold hover:bg-[#FEE2E2] min-h-[36px] cursor-pointer flex items-center gap-1"
                  >
                    <span>📄</span>
                    <span>In A4 (NĐ 30)</span>
                  </button>
                  <button
                    onClick={() => handleExportWord(m.title)}
                    className="px-3 py-1.5 border border-[#E7E5E4] bg-white rounded-xl text-[11px] font-bold hover:bg-[#FAFAF9] min-h-[36px] cursor-pointer"
                  >
                    Word
                  </button>
                  <button
                    onClick={() => handleExportCsv(m.title)}
                    className="px-3 py-1.5 border border-[#E7E5E4] bg-white rounded-xl text-[11px] font-bold hover:bg-[#FAFAF9] min-h-[36px] cursor-pointer"
                  >
                    CSV/Excel
                  </button>
                  <button
                    onClick={() => {
                      if (navigator.clipboard) {
                        navigator.clipboard.writeText(`${window.location.origin}/staff/reports?share=${encodeURIComponent(m.title)}`);
                        showToast(`Đã sao chép link chia sẻ "${m.title}"!`);
                      } else {
                        showToast(`Link: ${window.location.origin}/staff/reports`);
                      }
                    }}
                    className="px-3 py-1.5 border border-[#E7E5E4] bg-white rounded-xl text-[11px] font-bold hover:bg-[#FAFAF9] min-h-[36px] cursor-pointer"
                  >
                    Link
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 4. Bottom Table: Báo cáo đã tạo (Mockup 9) */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3.5">
        <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
          <span className="font-black text-xs sm:text-sm text-[#1C1917]">Báo cáo đã tạo</span>
          <span className="text-[11px] text-[#78716C]">{reportsList.length} báo cáo</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#F5F5F4] text-[#A8A29E] text-[10px] uppercase font-bold">
                <th className="py-2.5 pr-2">Tên báo cáo</th>
                <th className="py-2.5 px-2">Phạm vi</th>
                <th className="py-2.5 px-2">Ngày tạo</th>
                <th className="py-2.5 px-2">Người tạo</th>
                <th className="py-2.5 pl-2 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F5F5F4]">
              {reportsList.map(r => (
                <tr key={r.id} className="hover:bg-[#FAFAF9] transition">
                  <td className="py-3 pr-2 font-bold text-[#1C1917] flex items-center gap-1.5">
                    <span>📕</span>
                    <span className="break-words">{r.name}</span>
                  </td>
                  <td className="py-3 px-2 text-[11px] text-[#57534E] whitespace-nowrap">{r.scope}</td>
                  <td className="py-3 px-2 font-mono text-[10px] text-[#78716C] whitespace-nowrap">{r.createdAt}</td>
                  <td className="py-3 px-2 text-[11px] font-medium text-[#1C1917] whitespace-nowrap">{r.createdBy}</td>
                  <td className="py-3 pl-2 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setPrintPreviewModal({ open: true, report: r })}
                        className="px-2.5 py-1.5 bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] rounded-lg text-[10px] font-black hover:bg-[#FEE2E2] min-h-[32px] cursor-pointer flex items-center gap-1"
                        title="Xem trước & In chuẩn Nghị định 30/2020"
                      >
                        <span>📄</span>
                        <span>In A4</span>
                      </button>
                      <button
                        onClick={() => handleExportWord(r.name)}
                        className="px-2.5 py-1.5 border border-[#E7E5E4] rounded-lg text-[10px] font-bold text-[#1C1917] hover:bg-[#FAFAF9] min-h-[32px] cursor-pointer"
                        title="Xuất tài liệu Word"
                      >
                        Word
                      </button>
                      <button
                        onClick={() => handleExportCsv(r.name)}
                        className="px-2.5 py-1.5 border border-[#E7E5E4] rounded-lg text-[10px] font-bold text-[#1C1917] hover:bg-[#FAFAF9] min-h-[32px] cursor-pointer"
                        title="Xuất bảng số liệu CSV"
                      >
                        CSV
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Xem Trước & In Báo Cáo A4 Chuẩn NĐ 30/2020 */}
      {printPreviewModal.open && printPreviewModal.report && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/70 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-[#E7E5E4] max-w-3xl w-full p-6 sm:p-8 shadow-2xl animate-scale-up space-y-6 my-auto text-[#1C1917]">
            
            {/* Header Modal Bar */}
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4] print:hidden">
              <div className="flex items-center gap-2">
                <span className="text-xl">📜</span>
                <div>
                  <h3 className="text-base font-black text-[#1C1917]">Mẫu In Văn Bản Hành Chính A4</h3>
                  <p className="text-[11px] text-[#78716C]">Thể thức theo Nghị định số 30/2020/NĐ-CP của Chính phủ</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold text-xs shadow-xs min-h-[40px] flex items-center gap-1.5 cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="6 9 6 2 18 2 18 9" />
                    <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
                    <rect x="6" y="14" width="12" height="8" />
                  </svg>
                  <span>In ngay (A4)</span>
                </button>
                <button
                  onClick={() => setPrintPreviewModal({ open: false, report: null })}
                  className="px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold text-xs text-[#78716C] hover:bg-[#FAFAF9] min-h-[40px] cursor-pointer"
                >
                  ✕ Đóng
                </button>
              </div>
            </div>

            {/* Văn bản A4 Thể thức NĐ 30/2020 */}
            <div className="p-6 sm:p-10 border border-[#E7E5E4] rounded-xl bg-white shadow-2xs font-serif text-[#1C1917] space-y-6">
              
              {/* Quốc hiệu & Cơ quan ban hành */}
              <div className="grid grid-cols-2 gap-4 items-start pb-4">
                <div className="text-center font-sans">
                  <div className="text-xs font-bold text-[#1C1917] uppercase">ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI</div>
                  <div className="text-xs font-black text-[#1C1917] uppercase">SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG</div>
                  <div className="w-24 h-0.5 bg-[#1C1917] mx-auto my-1"></div>
                  <div className="text-[11px] text-[#57534E] font-medium">Số: 128/BC-STNMT-TT</div>
                </div>

                <div className="text-center font-sans">
                  <div className="text-xs font-black text-[#1C1917] uppercase tracking-wide">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div>
                  <div className="text-xs font-bold text-[#1C1917]">Độc lập - Tự do - Hạnh phúc</div>
                  <div className="w-32 h-0.5 bg-[#1C1917] mx-auto my-1"></div>
                  <div className="text-[11px] italic text-[#57534E]">Hà Nội, ngày 02 tháng 09 năm 2026</div>
                </div>
              </div>

              {/* Tên loại văn bản & Trích yếu */}
              <div className="text-center py-2 space-y-1">
                <h2 className="text-base sm:text-lg font-black uppercase text-[#1C1917] font-sans tracking-wide">
                  BÁO CÁO
                </h2>
                <div className="text-xs sm:text-sm font-bold text-[#1C1917] italic">
                  Về kết quả quan trắc và tình hình giám sát phát tán bụi công trình xây dựng
                </div>
                <div className="text-xs text-[#57534E]">{printPreviewModal.report.name}</div>
              </div>

              {/* Nội dung báo cáo */}
              <div className="text-xs leading-relaxed space-y-3 font-sans text-[#292524]">
                <p className="font-semibold indent-6">
                  Căn cứ Luật Bảo vệ Môi trường năm 2020 và QCVN 05:2023/BTNMT về chất lượng không khí xung quanh; thực hiện chỉ đạo của Ủy ban nhân dân Thành phố về việc kiểm soát phát tán bụi công trình xây dựng đô thị, Sở Tài nguyên và Môi trường báo cáo kết quả như sau:
                </p>

                <div>
                  <h4 className="font-bold text-[#1C1917] uppercase text-[11px] mb-1">I. Tình hình quan trắc & Chỉ số phát tán bụi:</h4>
                  <p className="indent-4">
                    - Tổng số trạm quan trắc IoT trực tuyến đang hoạt động: <strong>18 trạm</strong> trên địa bàn 6 quận trọng điểm.
                  </p>
                  <p className="indent-4">
                    - Số điểm ghi nhận bụi vượt ngưỡng QCVN: <strong>3 công trình</strong> (trong đó nồng độ PM10 cao nhất đạt 172 µg/m³ tại trục Vành Đai 3).
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-[#1C1917] uppercase text-[11px] mb-1">II. Kết quả kiểm tra và xử lý vi phạm:</h4>
                  <table className="w-full border-collapse border border-[#A8A29E] text-[11px] my-2">
                    <thead>
                      <tr className="bg-[#F5F5F4] font-bold text-center">
                        <th className="border border-[#A8A29E] p-1.5">STT</th>
                        <th className="border border-[#A8A29E] p-1.5">Chỉ tiêu giám sát</th>
                        <th className="border border-[#A8A29E] p-1.5">Số lượng</th>
                        <th className="border border-[#A8A29E] p-1.5">Tỷ lệ hoàn tất</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border border-[#A8A29E] p-1.5 text-center">1</td>
                        <td className="border border-[#A8A29E] p-1.5">Hồ sơ kiểm tra thành lập</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center font-bold">{kpis.weeklyCases} vụ</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center">100%</td>
                      </tr>
                      <tr>
                        <td className="border border-[#A8A29E] p-1.5 text-center">2</td>
                        <td className="border border-[#A8A29E] p-1.5">Đã khắc phục hoàn tất đúng hạn</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center font-bold text-[#16A34A]">{kpis.completedCases} vụ</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center font-bold text-[#16A34A]">{kpis.onTimeRate}%</td>
                      </tr>
                      <tr>
                        <td className="border border-[#A8A29E] p-1.5 text-center">3</td>
                        <td className="border border-[#A8A29E] p-1.5">Vụ việc đang đôn đốc xử lý</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center font-bold text-[#B91C1C]">{kpis.overdueCases} vụ</td>
                        <td className="border border-[#A8A29E] p-1.5 text-center">-</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div>
                  <h4 className="font-bold text-[#1C1917] uppercase text-[11px] mb-1">III. Đề xuất & Kiến nghị:</h4>
                  <p className="indent-4">
                    Yêu cầu các chủ đầu tư và nhà thầu thi công nghiêm túc thực hiện việc che bạt kín bãi vật liệu, vận hành trạm rửa xe tự động và phun nước giảm bụi định kỳ theo quy chuẩn.
                  </p>
                </div>
              </div>

              {/* Phần ký duyệt & Nơi nhận */}
              <div className="grid grid-cols-2 gap-4 pt-6 font-sans">
                <div className="text-[10px] text-[#57534E] space-y-0.5">
                  <div className="font-bold text-[#1C1917] uppercase">Nơi nhận:</div>
                  <div>- UBND Thành phố Hà Nội (để b/c);</div>
                  <div>- Ban Giám đốc Sở TN&MT;</div>
                  <div>- UBND các quận, huyện;</div>
                  <div>- Đội Thanh tra Môi trường;</div>
                  <div>- Lưu: VT, TT.</div>
                </div>

                <div className="text-center">
                  <div className="text-xs font-black uppercase text-[#1C1917]">KT. GIÁM ĐỐC</div>
                  <div className="text-xs font-bold text-[#57534E]">PHÓ GIÁM ĐỐC</div>
                  <div className="h-14 flex items-center justify-center text-xs font-bold text-[#B91C1C] italic">
                    (Đã ký điện tử xác thực)
                  </div>
                  <div className="text-xs font-bold text-[#1C1917]">{printPreviewModal.report.createdBy || 'Nguyễn Văn An'}</div>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Modal Tạo Báo Cáo */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E7E5E4] max-w-md w-full p-6 shadow-2xl animate-scale-up space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Tạo báo cáo mới</h3>
                <p className="text-xs text-[#78716C]">Lưu trữ và xuất báo cáo từ CSDL D1</p>
              </div>
              <button onClick={() => setCreateModalOpen(false)} className="text-[#78716C] font-bold cursor-pointer">✕</button>
            </div>
            <form onSubmit={async (e) => {
              e.preventDefault();
              const form = e.target;
              const name = form.name.value;
              const reportType = form.reportType.value;
              try {
                await request('/staff/reports/create', {
                  method: 'POST',
                  body: JSON.stringify({ name, reportType })
                });
                setCreateModalOpen(false);
                await loadAll();
                alert('Tạo báo cáo thành công!');
              } catch (err) {
                alert('Lỗi tạo báo cáo: ' + err.message);
              }
            }} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Loại báo cáo</label>
                <select name="reportType" className="w-full px-3.5 py-2.5 border border-[#E7E5E4] rounded-xl bg-white focus:outline-none min-h-[44px]">
                  <option value="GENERAL">Báo cáo tổng hợp tuần</option>
                  <option value="OVERDUE">Báo cáo các vụ việc quá hạn</option>
                  <option value="SITE">Báo cáo theo công trình</option>
                  <option value="AREA">Báo cáo theo khu vực</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Tên báo cáo <span className="text-[#B91C1C]">*</span></label>
                <input name="name" type="text" required placeholder="VD: Báo cáo tuần 24/2025" className="w-full px-3.5 py-2.5 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]" />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-[#E7E5E4]">
                <button type="button" onClick={() => setCreateModalOpen(false)} className="px-4 py-2.5 border rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] cursor-pointer min-h-[44px]">Hủy</button>
                <button type="submit" className="px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]">Xuất báo cáo</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {scheduleModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#231b14]/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E7E5E4] max-w-md w-full p-6 shadow-2xl animate-scale-up space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <h3 className="text-base font-black text-[#1C1917]">Lên lịch gửi báo cáo định kỳ</h3>
                <p className="text-xs text-[#78716C]">Tự động tổng hợp và gửi email tới ban chỉ đạo</p>
              </div>
              <button onClick={() => setScheduleModalOpen(false)} className="text-[#78716C] font-bold cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              setAutoEmailEnabled(true);
              setScheduleModalOpen(false);
              showToast(`Đã lưu lịch gửi: ${scheduleDay === 'MON' ? 'Thứ 2' : 'Hàng ngày'} lúc ${scheduleTime}`);
            }} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Chu kỳ gửi</label>
                <select 
                  value={scheduleDay} 
                  onChange={(e) => setScheduleDay(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-[#E7E5E4] rounded-xl bg-white focus:outline-none min-h-[44px]"
                >
                  <option value="MON">Đầu tuần (Sáng Thứ 2)</option>
                  <option value="FRI">Cuối tuần (Chiều Thứ 6)</option>
                  <option value="DAILY">Hàng ngày</option>
                  <option value="MONTHLY">Đầu tháng (Ngày 1 hàng tháng)</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Thời gian gửi</label>
                <input 
                  type="time" 
                  value={scheduleTime} 
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-[#E7E5E4] rounded-xl focus:border-[#B91C1C] focus:outline-none min-h-[44px]" 
                />
              </div>
              <div className="p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-[11px] text-[#57534E]">
                Báo cáo sẽ được đính kèm file Word (NĐ 30/2020) và file CSV dữ liệu số liệu gửi tới email đã cấu hình trong Cài đặt.
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-[#E7E5E4]">
                <button type="button" onClick={() => setScheduleModalOpen(false)} className="px-4 py-2.5 border rounded-xl font-bold text-[#78716C] hover:bg-[#FAFAF9] cursor-pointer min-h-[44px]">Hủy</button>
                <button type="submit" className="px-4 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-xl font-bold cursor-pointer shadow-xs min-h-[44px]">Lưu lịch gửi</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast Notification Container */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#1C1917] text-white text-xs font-bold px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-slide-up">
          <span className="text-[#16A34A] text-sm">✓</span>
          <span>{toastMsg}</span>
        </div>
      )}

    </div>
  );
}
