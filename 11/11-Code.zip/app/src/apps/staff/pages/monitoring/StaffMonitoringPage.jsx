import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Filter,
  MoreVertical,
  Plus,
  RefreshCw,
  Search,
  SlidersHorizontal,
  ChevronRight,
  Download,
  Building2,
  MapPin,
  Radio,
  Bell,
  X,
  ArrowUpDown,
  TrendingUp,
  Map as MapIcon
} from 'lucide-react';

// Helper format human-readable relative time
function formatHumanTime(timeStr) {
  if (!timeStr) return 'Vừa cập nhật';
  if (timeStr.includes('phút') || timeStr.includes('giờ') || timeStr.includes('Hôm nay')) {
    return timeStr;
  }
  try {
    const date = new Date(timeStr);
    if (isNaN(date.getTime())) return timeStr;
    const now = new Date();
    const diffSec = Math.floor((now - date) / 1000);
    if (diffSec < 60) return 'Vừa cập nhật';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin} phút trước`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours} giờ trước`;
    return date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + ' ' + date.toLocaleDateString('vi-VN');
  } catch {
    return timeStr;
  }
}

export default function StaffMonitoringPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Sorting
  const [searchQuery, setSearchQuery] = useState('');
  const [districtFilter, setDistrictFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [sortBy, setSortBy] = useState('PRIORITY'); // PRIORITY | PM25_DESC | NEWEST
  const [currentPage, setCurrentPage] = useState(1);
  const [totalStationsCount, setTotalStationsCount] = useState(0);

  // Data States
  const [kpis, setKpis] = useState({
    activeStations: 18,
    totalStations: 22,
    normalCount: 14,
    warningCount: 5,
    alertCount: 3
  });

  const [abnormalStations, setAbnormalStations] = useState([]);
  const [stations, setStations] = useState([]);
  const [timelinePoints, setTimelinePoints] = useState([]);
  const [selectedMetric, setSelectedMetric] = useState('BOTH'); // BOTH | PM25 | PM10

  // Modals & Action States
  const [createAlertModal, setCreateAlertModal] = useState({ open: false, station: null });
  const [addStationModalOpen, setAddStationModalOpen] = useState(false);
  const [editThresholdModal, setEditThresholdModal] = useState({ open: false, station: null });
  const [activeMenuId, setActiveMenuId] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [headerMenuOpen, setHeaderMenuOpen] = useState(false);

  // New Station Form State
  const [newStationForm, setNewStationForm] = useState({
    code: '',
    name: '',
    siteName: '',
    district: 'Thanh Xuân',
    location: 'Thanh Xuân, Hà Nội'
  });

  // Threshold Form State
  const [thresholdForm, setThresholdForm] = useState({
    warningPm25: 75,
    warningPm10: 150
  });

  // 1. Fetch Summary KPIs
  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/monitoring/summary');
      if (res?.data) {
        setKpis({
          activeStations: res.data.activeStations ?? 18,
          totalStations: res.data.totalStations ?? 22,
          normalCount: res.data.normalCount ?? 14,
          warningCount: res.data.warningCount ?? 5,
          alertCount: res.data.alertCount ?? 3
        });
      }
    } catch (err) {
      console.error('Error fetching summary:', err);
    }
  }, []);

  // 2. Fetch Abnormal Stations
  const fetchAbnormal = useCallback(async () => {
    try {
      const res = await request('/staff/monitoring/abnormal');
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setAbnormalStations(res.data.items);
      } else {
        setAbnormalStations([
          {
            id: 'st_tx02',
            code: 'TX-02',
            name: 'TX-02 · Thanh Xuân',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            district: 'Thanh Xuân',
            pm25: 88,
            pm10: 172,
            status: 'ALERT',
            statusLabel: 'Cảnh báo',
            updatedAt: '08:45 Hôm nay'
          }
        ]);
      }
    } catch (err) {
      console.error('Error fetching abnormal stations:', err);
    }
  }, []);

  // 3. Fetch 24h Timeline Readings
  const fetchTimeline = useCallback(async () => {
    try {
      const res = await request('/staff/monitoring/timeline?hours=24');
      if (res?.data?.points && Array.isArray(res.data.points) && res.data.points.length > 0) {
        setTimelinePoints(res.data.points);
      } else {
        // Fallback default points for 24h curve
        setTimelinePoints([
          { time: '12:00', pm25: 42, pm10: 88 },
          { time: '15:00', pm25: 78, pm10: 165 },
          { time: '18:00', pm25: 85, pm10: 178 },
          { time: '21:00', pm25: 55, pm10: 110 },
          { time: '00:00', pm25: 38, pm10: 72 },
          { time: '03:00', pm25: 32, pm10: 58 },
          { time: '06:00', pm25: 64, pm10: 135 },
          { time: '09:00', pm25: 96, pm10: 215 },
          { time: '12:00', pm25: 52, pm10: 105 }
        ]);
      }
    } catch (err) {
      console.error('Error fetching 24h timeline:', err);
      setTimelinePoints([
        { time: '12:00', pm25: 42, pm10: 88 },
        { time: '15:00', pm25: 78, pm10: 165 },
        { time: '18:00', pm25: 85, pm10: 178 },
        { time: '21:00', pm25: 55, pm10: 110 },
        { time: '00:00', pm25: 38, pm10: 72 },
        { time: '03:00', pm25: 32, pm10: 58 },
        { time: '06:00', pm25: 64, pm10: 135 },
        { time: '09:00', pm25: 96, pm10: 215 },
        { time: '12:00', pm25: 52, pm10: 105 }
      ]);
    }
  }, []);

  // 4. Fetch Stations Table
  const fetchStations = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        search: searchQuery,
        district: districtFilter,
        status: statusFilter,
        page: String(currentPage),
        limit: '15'
      });
      const res = await request(`/staff/monitoring/stations?${params.toString()}`);
      if (res?.data?.items && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setStations(res.data.items);
        setTotalStationsCount(res.data.pagination?.total ?? res.data.items.length);
      } else {
        setStations([
          {
            id: 'st_tx02',
            code: 'TX-02',
            name: 'Trạm TX-02',
            siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân',
            district: 'Thanh Xuân',
            location: 'Khuất Duy Tiến, Thanh Xuân, Hà Nội',
            pm25: 88,
            pm10: 172,
            status: 'ALERT',
            statusLabel: 'Cảnh báo',
            updatedAt: '2 phút trước'
          },
          {
            id: 'st_cg01',
            code: 'CG-01',
            name: 'Trạm CG-01',
            siteName: 'Chung cư Discovery Complex Cầu Giấy',
            district: 'Cầu Giấy',
            location: '302 Cầu Giấy, Cầu Giấy, Hà Nội',
            pm25: 64,
            pm10: 118,
            status: 'WARNING',
            statusLabel: 'Cần theo dõi',
            updatedAt: '15 phút trước'
          },
          {
            id: 'st_bd03',
            code: 'BD-03',
            name: 'Trạm BD-03',
            siteName: 'Tòa nhà hỗn hợp Liễu Giai Ba Đình',
            district: 'Ba Đình',
            location: 'Liễu Giai, Ba Đình, Hà Nội',
            pm25: 32,
            pm10: 65,
            status: 'NORMAL',
            statusLabel: 'Bình thường',
            updatedAt: '1 giờ trước'
          },
          {
            id: 'st_hm05',
            code: 'HM-05',
            name: 'Trạm HM-05',
            siteName: 'Khu đô thị Linh Đàm mở rộng',
            district: 'Hoàng Mai',
            location: 'Bán đảo Linh Đàm, Hoàng Mai, Hà Nội',
            pm25: 41,
            pm10: 82,
            status: 'NORMAL',
            statusLabel: 'Bình thường',
            updatedAt: '35 phút trước'
          },
          {
            id: 'st_lb02',
            code: 'LB-02',
            name: 'Trạm LB-02',
            siteName: 'Cầu Vĩnh Tuy giai đoạn 2',
            district: 'Long Biên',
            location: 'Đàm Quang Trung, Long Biên, Hà Nội',
            pm25: 28,
            pm10: 55,
            status: 'NORMAL',
            statusLabel: 'Bình thường',
            updatedAt: '5 phút trước'
          }
        ]);
        setTotalStationsCount(5);
      }
    } catch (err) {
      console.error('Error fetching stations:', err);
    }
  }, [searchQuery, districtFilter, statusFilter, currentPage]);

  // Initial Full Load
  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([
        fetchSummary(),
        fetchAbnormal(),
        fetchTimeline(),
        fetchStations()
      ]);
    } catch (err) {
      setError(err.message || 'Không thể tải dữ liệu quan trắc từ D1');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchAbnormal, fetchTimeline, fetchStations]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Trigger stations reload on filter change
  useEffect(() => {
    fetchStations();
  }, [fetchStations]);

  // Khóa cuộn màn hình và bắt phím Escape đóng modal
  useEffect(() => {
    const isAnyModalOpen = createAlertModal.open || addStationModalOpen || editThresholdModal.open;
    if (!isAnyModalOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        setCreateAlertModal({ open: false, station: null });
        setAddStationModalOpen(false);
        setEditThresholdModal({ open: false, station: null });
      }
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [createAlertModal.open, addStationModalOpen, editThresholdModal.open]);

  // Sort stations based on Priority logic (Alert -> Warning -> Inactive -> Normal)
  const sortedStations = useMemo(() => {
    const list = [...stations];
    if (sortBy === 'PRIORITY') {
      const rank = { ALERT: 4, WARNING: 3, INACTIVE: 2, NORMAL: 1 };
      return list.sort((a, b) => (rank[b.status] || 0) - (rank[a.status] || 0) || (b.pm25 || 0) - (a.pm25 || 0));
    }
    if (sortBy === 'PM25_DESC') {
      return list.sort((a, b) => (b.pm25 || 0) - (a.pm25 || 0));
    }
    return list;
  }, [stations, sortBy]);

  // Highest PM2.5 in active list
  const maxPm25 = useMemo(() => {
    if (!stations.length) return 74;
    return Math.max(...stations.map(s => s.pm25 || 0), 74);
  }, [stations]);

  // 24h Timeline Chart Calculations
  const chartConfig = useMemo(() => {
    const pts = timelinePoints && timelinePoints.length > 0 ? timelinePoints : [];
    if (pts.length === 0) {
      return { pathPm25: '', pathPm10: '', points: [], maxVal: 200, pointsWithCoords: [] };
    }

    const maxVal = Math.max(220, ...pts.map(p => Math.max(Number(p.pm25 || 0), Number(p.pm10 || 0))));
    const width = 560;
    const height = 140;
    const paddingX = 30;
    const paddingY = 20;

    const usableW = width - paddingX * 2;
    const usableH = height - paddingY * 2;

    const pointsWithCoords = pts.map((p, idx) => {
      const x = paddingX + (idx / Math.max(1, pts.length - 1)) * usableW;
      const yPm25 = height - paddingY - (Number(p.pm25 || 0) / maxVal) * usableH;
      const yPm10 = height - paddingY - (Number(p.pm10 || 0) / maxVal) * usableH;
      return { ...p, x, yPm25, yPm10 };
    });

    const pathPm25 = pointsWithCoords.reduce((acc, curr, idx) => {
      return idx === 0 ? `M ${curr.x} ${curr.yPm25}` : `${acc} L ${curr.x} ${curr.yPm25}`;
    }, '');

    const pathPm10 = pointsWithCoords.reduce((acc, curr, idx) => {
      return idx === 0 ? `M ${curr.x} ${curr.yPm10}` : `${acc} L ${curr.x} ${curr.yPm10}`;
    }, '');

    // Standard threshold lines
    const yThresholdPm25 = height - paddingY - (50 / maxVal) * usableH;
    const yThresholdPm10 = height - paddingY - (100 / maxVal) * usableH;

    return {
      pathPm25,
      pathPm10,
      pointsWithCoords,
      maxVal,
      yThresholdPm25,
      yThresholdPm10,
      width,
      height
    };
  }, [timelinePoints]);

  // Mutations
  const handleCreateAlertSubmit = async (e) => {
    e.preventDefault();
    try {
      setActionLoading(true);
      await request('/staff/alerts', {
        method: 'POST',
        body: JSON.stringify({
          stationId: createAlertModal.station?.id,
          severity: 'CRITICAL',
          message: 'Bụi vượt ngưỡng nghiêm trọng từ trạm quan trắc',
          pm10Value: createAlertModal.station?.pm10 || 185
        })
      });
      setCreateAlertModal({ open: false, station: null });
      fetchSummary();
      alert('Đã phát hành cảnh báo môi trường thành công!');
    } catch (err) {
      alert('Lỗi tạo cảnh báo: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleAddStationSubmit = async (e) => {
    e.preventDefault();
    if (!newStationForm.code) {
      alert('Vui lòng nhập mã trạm');
      return;
    }
    try {
      setActionLoading(true);
      await request('/staff/monitoring/stations', {
        method: 'POST',
        body: JSON.stringify(newStationForm)
      });
      setAddStationModalOpen(false);
      setNewStationForm({ code: '', name: '', siteName: '', district: 'Thanh Xuân', location: 'Thanh Xuân, Hà Nội' });
      await Promise.all([fetchSummary(), fetchStations(), fetchAbnormal()]);
      alert(`Đã thêm trạm ${newStationForm.code} thành công!`);
    } catch (err) {
      alert('Lỗi thêm trạm: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSaveThresholds = async (e) => {
    e.preventDefault();
    if (!editThresholdModal.station) return;
    try {
      setActionLoading(true);
      await request(`/staff/monitoring/stations/${editThresholdModal.station.id}/thresholds`, {
        method: 'PATCH',
        body: JSON.stringify(thresholdForm)
      });
      setEditThresholdModal({ open: false, station: null });
      await Promise.all([fetchSummary(), fetchStations(), fetchAbnormal()]);
      alert(`Cập nhật ngưỡng cho trạm ${editThresholdModal.station.code} thành công!`);
    } catch (err) {
      alert('Lỗi cập nhật ngưỡng: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleTogglePause = async (station) => {
    try {
      const isPaused = station.status === 'INACTIVE';
      const endpoint = isPaused ? `/staff/monitoring/stations/${station.id}/resume` : `/staff/monitoring/stations/${station.id}/pause`;
      await request(endpoint, { method: 'POST' });
      await Promise.all([fetchSummary(), fetchStations()]);
    } catch (err) {
      alert('Lỗi cập nhật trạng thái: ' + err.message);
    }
  };

  const handleExportCsv = () => {
    window.open('/api/staff/monitoring/export.csv', '_blank');
  };

  // Close menus on click outside
  useEffect(() => {
    const handleGlobalClick = () => {
      setActiveMenuId(null);
      setHeaderMenuOpen(false);
    };
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  if (loading) return <LoadingState message="Đang tải dữ liệu quan trắc từ Cloudflare D1…" />;
  if (error) return <ErrorState title="Lỗi tải trạm quan trắc" message={error} onRetry={loadAllData} />;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 1. Page Header (Tinh gọn, đúng chuẩn Operations UI) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight">
            Quan trắc & Mạng lưới Cảm biến
          </h1>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            Theo dõi dữ liệu chuỗi thời gian 24h, đối chiếu ngưỡng QCVN 05:2023 và giám sát các điểm nóng.
          </p>
        </div>

        {/* Top Controls: 1 Nút làm mới + Thêm trạm + Menu phụ */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => {
              fetchSummary();
              fetchStations();
              fetchAbnormal();
              fetchTimeline();
            }}
            title="Làm mới dữ liệu"
            className="dg-btn dg-btn-secondary min-h-[44px]"
            style={{ padding: '8px 14px', fontSize: 13 }}
          >
            <RefreshCw size={14} />
            <span>Làm mới</span>
          </button>

          <button
            onClick={() => setAddStationModalOpen(true)}
            className="dg-btn dg-btn-primary min-h-[44px]"
            style={{ padding: '8px 16px', fontSize: 13 }}
          >
            <Plus size={15} />
            <span>Thêm trạm</span>
          </button>

          {/* Secondary Actions Menu */}
          <div className="relative" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setHeaderMenuOpen(!headerMenuOpen)}
              className="dg-btn dg-btn-secondary min-h-[44px]"
              style={{ padding: '8px 12px' }}
              title="Tùy chọn khác"
            >
              <MoreVertical size={16} />
            </button>

            {headerMenuOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-48 bg-white border border-[#161313]/10 rounded-2xl shadow-xl p-1.5 z-50 text-xs">
                <button
                  onClick={() => {
                    setCreateAlertModal({ open: true, station: null });
                    setHeaderMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[#FDF2F1] font-bold text-[#9F241F] flex items-center gap-2 cursor-pointer min-h-[44px]"
                >
                  <Bell size={14} />
                  <span>Tạo cảnh báo chung</span>
                </button>
                <button
                  onClick={() => {
                    handleExportCsv();
                    setHeaderMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[#F7F6F3] font-bold text-[#5C5550] flex items-center gap-2 cursor-pointer min-h-[44px]"
                >
                  <Download size={14} />
                  <span>Xuất file CSV</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Summary Strip (Compact, đọc trong 2 giây, số lớn) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Active Stations */}
        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Đang hoạt động
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {kpis.activeStations}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">
              / {kpis.totalStations} trạm
            </span>
          </div>
        </div>

        {/* Warning Stations */}
        <div className={`rounded-2xl p-4 border shadow-2xs ${
          kpis.warningCount > 0 ? 'bg-[#FEF9EE] border-[#FDE68A]' : 'bg-white border-[#161313]/10'
        }`}>
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Cần theo dõi
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className={`text-2xl sm:text-3xl font-black ${
              kpis.warningCount > 0 ? 'text-[#B45309]' : 'text-[#161313]'
            }`}>
              {kpis.warningCount}
            </span>
            <span className="text-xs text-[#7E7771]">trạm</span>
          </div>
        </div>

        {/* Alert Stations */}
        <div className={`rounded-2xl p-4 border shadow-2xs ${
          kpis.alertCount > 0 ? 'bg-[#FDF2F1] border-[#F8D3D1]' : 'bg-white border-[#161313]/10'
        }`}>
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Cảnh báo vượt ngưỡng
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className={`text-2xl sm:text-3xl font-black ${
              kpis.alertCount > 0 ? 'text-[#9F241F]' : 'text-[#161313]'
            }`}>
              {kpis.alertCount}
            </span>
            <span className="text-xs text-[#7E7771]">trạm</span>
          </div>
        </div>

        {/* Peak PM2.5 */}
        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            PM2.5 cao nhất
          </span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#9F241F]">
              {maxPm25}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">µg/m³</span>
          </div>
        </div>

      </div>

      {/* 3. Visual Section: 24h Trend Chart & GIS Map (High Impact Civic Tech) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* LEFT: 24h Trend Line Chart (7 cols on Desktop) */}
        <div className="lg:col-span-7 bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#161313]/5">
            <div>
              <h2 className="text-sm sm:text-base font-black text-[#161313] flex items-center gap-2">
                <TrendingUp size={16} className="text-[#0D6F64]" />
                <span>Diễn biến chỉ số bụi trong 24 giờ qua</span>
              </h2>
              <p className="text-[11px] text-[#5C5550] font-medium mt-0.5">
                Đối chiếu ngưỡng QCVN 05:2023/BTNMT trung bình 24 giờ.
              </p>
            </div>

            {/* Metric Toggle Chips */}
            <div className="flex items-center gap-1.5 bg-[#F7F6F3] p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setSelectedMetric('BOTH')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer min-h-[32px] ${
                  selectedMetric === 'BOTH' ? 'bg-white text-[#161313] shadow-xs' : 'text-[#7E7771]'
                }`}
              >
                Cả hai
              </button>
              <button
                type="button"
                onClick={() => setSelectedMetric('PM25')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer min-h-[32px] ${
                  selectedMetric === 'PM25' ? 'bg-[#9F241F] text-white shadow-xs' : 'text-[#7E7771]'
                }`}
              >
                PM2.5
              </button>
              <button
                type="button"
                onClick={() => setSelectedMetric('PM10')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer min-h-[32px] ${
                  selectedMetric === 'PM10' ? 'bg-[#0D6F64] text-white shadow-xs' : 'text-[#7E7771]'
                }`}
              >
                PM10
              </button>
            </div>
          </div>

          {/* SVG 24h Trend Chart */}
          <div className="w-full overflow-hidden">
            {chartConfig.pointsWithCoords.length === 0 ? (
              <div className="h-44 flex flex-col items-center justify-center text-xs text-[#7E7771] bg-[#FDFBF7] rounded-2xl border border-dashed border-[#161313]/10">
                <Activity size={24} className="mb-1 text-[#A8A29E]" />
                <span>Chưa có đủ chuỗi đo 24h từ trạm quan trắc</span>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="relative w-full aspect-[28/11] min-h-[160px]">
                  <svg
                    viewBox="0 0 560 140"
                    className="w-full h-full overflow-visible"
                    preserveAspectRatio="none"
                  >
                    {/* Grid Lines */}
                    <line x1="30" y1="20" x2="530" y2="20" stroke="#161313" strokeOpacity="0.05" strokeWidth="1" />
                    <line x1="30" y1="60" x2="530" y2="60" stroke="#161313" strokeOpacity="0.05" strokeWidth="1" />
                    <line x1="30" y1="100" x2="530" y2="100" stroke="#161313" strokeOpacity="0.05" strokeWidth="1" />
                    <line x1="30" y1="120" x2="530" y2="120" stroke="#161313" strokeOpacity="0.1" strokeWidth="1" />

                    {/* QCVN Threshold reference lines */}
                    <line
                      x1="30"
                      y1={chartConfig.yThresholdPm25}
                      x2="530"
                      y2={chartConfig.yThresholdPm25}
                      stroke="#9F241F"
                      strokeWidth="1.2"
                      strokeDasharray="4 4"
                      strokeOpacity="0.7"
                    />
                    <line
                      x1="30"
                      y1={chartConfig.yThresholdPm10}
                      x2="530"
                      y2={chartConfig.yThresholdPm10}
                      stroke="#0D6F64"
                      strokeWidth="1.2"
                      strokeDasharray="4 4"
                      strokeOpacity="0.7"
                    />

                    {/* PM10 Path (Teal) */}
                    {(selectedMetric === 'BOTH' || selectedMetric === 'PM10') && (
                      <path
                        d={chartConfig.pathPm10}
                        fill="none"
                        stroke="#0D6F64"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    )}

                    {/* PM2.5 Path (Seal Red / Amber) */}
                    {(selectedMetric === 'BOTH' || selectedMetric === 'PM25') && (
                      <path
                        d={chartConfig.pathPm25}
                        fill="none"
                        stroke="#9F241F"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    )}

                    {/* Point dots */}
                    {chartConfig.pointsWithCoords.map((pt, idx) => (
                      <g key={idx}>
                        {(selectedMetric === 'BOTH' || selectedMetric === 'PM25') && (
                          <circle
                            cx={pt.x}
                            cy={pt.yPm25}
                            r="3.5"
                            fill="#9F241F"
                            stroke="#FFFFFF"
                            strokeWidth="1.5"
                          />
                        )}
                        {(selectedMetric === 'BOTH' || selectedMetric === 'PM10') && (
                          <circle
                            cx={pt.x}
                            cy={pt.yPm10}
                            r="3.5"
                            fill="#0D6F64"
                            stroke="#FFFFFF"
                            strokeWidth="1.5"
                          />
                        )}
                      </g>
                    ))}
                  </svg>
                </div>

                {/* X-axis labels & Legend */}
                <div className="flex items-center justify-between text-[10px] text-[#7E7771] px-2 font-mono">
                  {chartConfig.pointsWithCoords.map((pt, idx) => (
                    <span key={idx}>{pt.time}</span>
                  ))}
                </div>

                {/* Chart Footnote & Legend */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#161313]/5 text-[11px]">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1.5 font-bold text-[#9F241F]">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#9F241F]" /> PM2.5 (Ngưỡng QCVN: 50 µg/m³)
                    </span>
                    <span className="flex items-center gap-1.5 font-bold text-[#0D6F64]">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#0D6F64]" /> PM10 (Ngưỡng QCVN: 100 µg/m³)
                    </span>
                  </div>
                  <span className="text-[#7E7771] italic text-[10px]">
                    Dữ liệu cập nhật chu kỳ 60 phút từ D1 SSOT
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Embedded GIS Map (5 cols on Desktop) */}
        <div className="lg:col-span-5 bg-white border border-[#161313]/10 rounded-3xl p-5 shadow-xs space-y-3 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#161313]/5">
            <div>
              <h2 className="text-sm sm:text-base font-black text-[#161313] flex items-center gap-2">
                <MapIcon size={16} className="text-[#9F241F]" />
                <span>Khu vực đo & Bản đồ phân bố</span>
              </h2>
              <p className="text-[11px] text-[#5C5550] font-medium mt-0.5">
                Không gian địa lý vị trí các trạm quan trắc đô thị.
              </p>
            </div>
            <Link
              to="/staff/sites"
              className="text-xs font-bold text-[#0D6F64] hover:underline flex items-center gap-1 shrink-0 min-h-[44px]"
            >
              <span>Xem toàn cảnh</span>
              <ChevronRight size={13} />
            </Link>
          </div>

          {/* Leaflet / OSM Clean Embed */}
          <div className="relative w-full h-[180px] sm:h-[200px] rounded-2xl overflow-hidden border border-[#161313]/10 bg-[#E5E3DF]">
            <iframe
              title="Khu vực đo trạm quan trắc"
              src="https://www.openstreetmap.org/export/embed.html?bbox=105.75%2C20.95%2C105.90%2C21.08&layer=mapnik&marker=20.9985%2C105.8142"
              className="w-full h-full border-0"
              loading="lazy"
            />
            {/* Overlay Marker Badge */}
            <div className="absolute bottom-2.5 left-2.5 bg-white/95 border border-[#161313]/15 rounded-xl px-2.5 py-1 text-[11px] font-bold text-[#161313] shadow-md flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#9F241F] animate-pulse" />
              <span>Khu vực trọng điểm Thanh Xuân - Cầu Giấy</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-[#5C5550] pt-1">
            <span>Hiển thị <strong>{stations.length}</strong> điểm quan trắc thực địa</span>
            <span className="text-[11px] text-[#7E7771]">Tọa độ WGS-84</span>
          </div>
        </div>

      </div>

      {/* 4. Optional Alert Banner (Chỉ hiện khi có trạm bất thường) */}
      {abnormalStations.length > 0 && (
        <div className="bg-[#FDF2F1] border border-[#F8D3D1] rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[#9F241F] font-bold">
            <AlertTriangle size={16} className="shrink-0" />
            <span>
              Phát hiện <strong>{abnormalStations.length} trạm</strong> có nồng độ bụi vượt quy chuẩn QCVN 05:2023.
            </span>
          </div>
          <button
            onClick={() => setStatusFilter(statusFilter === 'ALERT' ? 'ALL' : 'ALERT')}
            className="px-3 py-2 bg-white border border-[#F8D3D1] text-[#9F241F] font-extrabold rounded-xl hover:bg-[#FDF2F1] cursor-pointer shrink-0 transition min-h-[44px]"
          >
            {statusFilter === 'ALERT' ? 'Hiển thị tất cả' : 'Lọc các trạm này'}
          </button>
        </div>
      )}

      {/* 5. Filter Toolbar (Liền khối, trực quan) */}
      <div className="bg-white border border-[#161313]/10 rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search size={15} className="text-[#7E7771] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Tìm trạm, công trình, địa điểm..."
            className="w-full pl-9 pr-3.5 py-2.5 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl text-xs text-[#161313] focus:outline-none focus:border-[#9F241F] min-h-[44px] font-medium"
          />
        </div>

        {/* Filters Group */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          
          {/* District Dropdown (District Filter with Thanh Xuân, Cầu Giấy, Ba Đình, ...) */}
          <select
            value={districtFilter}
            onChange={(e) => {
              setDistrictFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[44px] cursor-pointer"
          >
            <option value="ALL">Khu vực: Tất cả</option>
            <option value="Thanh Xuân">Thanh Xuân</option>
            <option value="Cầu Giấy">Cầu Giấy</option>
            <option value="Ba Đình">Ba Đình</option>
            <option value="Long Biên">Long Biên</option>
            <option value="Hoàng Mai">Hoàng Mai</option>
            <option value="Hà Đông">Hà Đông</option>
            <option value="Đống Đa">Đống Đa</option>
            <option value="Hai Bà Trưng">Hai Bà Trưng</option>
          </select>

          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[44px] cursor-pointer"
          >
            <option value="ALL">Trạng thái: Tất cả</option>
            <option value="ALERT">Cảnh báo</option>
            <option value="WARNING">Cần theo dõi</option>
            <option value="NORMAL">Bình thường</option>
            <option value="INACTIVE">Tạm dừng</option>
          </select>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 bg-white border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[44px] cursor-pointer"
          >
            <option value="PRIORITY">Sắp xếp: Ưu tiên xử lý</option>
            <option value="PM25_DESC">PM2.5 cao nhất</option>
            <option value="NEWEST">Mới cập nhật</option>
          </select>

        </div>

      </div>

      {/* 6. Station Priority List (Dense Operations List, Không Table Phân Mảnh) */}
      <div className="bg-white border border-[#161313]/10 rounded-3xl shadow-xs overflow-hidden">
        
        {sortedStations.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#F7F6F3] text-[#7E7771] flex items-center justify-center mx-auto">
              <Radio size={22} />
            </div>
            <strong className="text-sm text-[#161313] block">Không tìm thấy trạm quan trắc phù hợp</strong>
            <p className="text-xs text-[#5C5550]">Hệ thống vẫn hoạt động bình thường kể cả khi chưa có cảm biến kết nối.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setDistrictFilter('ALL');
                setStatusFilter('ALL');
              }}
              className="dg-btn dg-btn-secondary min-h-[44px]"
              style={{ padding: '8px 16px', fontSize: 12 }}
            >
              <span>Xóa bộ lọc</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-[#161313]/5">
            {sortedStations.map((station) => {
              const isAlert = station.status === 'ALERT';
              const isWarning = station.status === 'WARNING';
              const isInactive = station.status === 'INACTIVE';
              const isMenuOpen = activeMenuId === station.id;

              return (
                <div
                  key={station.id}
                  onClick={() => navigate('/staff/sites')}
                  className={`p-4 sm:p-5 transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer hover:bg-[#FDFBF7] ${
                    isAlert ? 'bg-[#FFFBFB]' : isWarning ? 'bg-[#FFFCF7]' : 'bg-white'
                  }`}
                >
                  
                  {/* LEFT: Context Block (Station name + Project + Address) */}
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    
                    {/* Status Dot */}
                    <span className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                      isAlert ? 'bg-[#9F241F] animate-pulse' : isWarning ? 'bg-[#D97706]' : isInactive ? 'bg-[#7E7771]' : 'bg-[#1B7A4B]'
                    }`} />

                    <div className="min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <strong className="text-sm sm:text-base font-bold text-[#161313] leading-snug">
                          {station.name || station.code} · {station.district || 'Hà Nội'}
                        </strong>
                        <span className="text-[11px] font-mono font-bold text-[#7E7771] px-1.5 py-0.5 bg-[#F7F6F3] rounded">
                          {station.code}
                        </span>
                      </div>

                      <div className="text-xs sm:text-sm font-medium text-[#5C5550] break-words line-clamp-2">
                        {station.siteName || 'Công trình xây dựng đô thị'}
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-[#7E7771]">
                        <MapPin size={12} className="shrink-0" />
                        <span className="truncate">{station.location || `${station.district}, Hà Nội`}</span>
                      </div>
                    </div>

                  </div>

                  {/* CENTER: Compact Metrics (PM2.5 & PM10) */}
                  <div className="flex items-center gap-5 sm:gap-8 shrink-0 py-1 md:py-0 border-t md:border-t-0 border-[#161313]/5 w-full md:w-auto justify-between md:justify-start">
                    
                    {/* PM2.5 */}
                    <div className="text-left md:text-center">
                      <span className="text-[10px] font-bold text-[#7E7771] uppercase block">PM2.5</span>
                      <div className="flex items-baseline gap-0.5">
                        <strong className={`text-lg sm:text-xl font-black ${
                          station.pm25 > 75 ? 'text-[#9F241F]' : station.pm25 > 50 ? 'text-[#D97706]' : 'text-[#1B7A4B]'
                        }`}>
                          {station.pm25}
                        </strong>
                        <span className="text-[10px] font-medium text-[#7E7771]">µg/m³</span>
                      </div>
                    </div>

                    {/* PM10 */}
                    <div className="text-left md:text-center">
                      <span className="text-[10px] font-bold text-[#7E7771] uppercase block">PM10</span>
                      <div className="flex items-baseline gap-0.5">
                        <strong className={`text-lg sm:text-xl font-black ${
                          station.pm10 > 150 ? 'text-[#9F241F]' : station.pm10 > 100 ? 'text-[#D97706]' : 'text-[#1B7A4B]'
                        }`}>
                          {station.pm10}
                        </strong>
                        <span className="text-[10px] font-medium text-[#7E7771]">µg/m³</span>
                      </div>
                    </div>

                    {/* Status & Time */}
                    <div className="text-right min-w-[110px]">
                      <span className={`inline-block text-[11px] font-bold px-2 py-0.5 rounded-full border mb-0.5 ${
                        isAlert
                          ? 'bg-[#FDF2F1] text-[#9F241F] border-[#F8D3D1]'
                          : isWarning
                          ? 'bg-[#FEF9EE] text-[#B45309] border-[#FDE68A]'
                          : isInactive
                          ? 'bg-[#F7F6F3] text-[#7E7771] border-[#161313]/10'
                          : 'bg-[#EDF7F2] text-[#1B7A4B] border-[#A3E6C5]'
                      }`}>
                        {station.statusLabel || (isAlert ? 'Cảnh báo' : isWarning ? 'Cần theo dõi' : isInactive ? 'Tạm dừng' : 'Bình thường')}
                      </span>
                      <div className="text-[11px] text-[#7E7771]">
                        {formatHumanTime(station.updatedAt)}
                      </div>
                    </div>

                  </div>

                  {/* RIGHT: Actions (Tạo cảnh báo nếu Alert/Warning + Menu ...) */}
                  <div 
                    className="flex items-center gap-2 shrink-0 self-end md:self-center w-full md:w-auto justify-end pt-2 md:pt-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    
                    {/* Progressive Disclosure: Nút Tạo vụ việc / cảnh báo khi bất thường */}
                    {(isAlert || isWarning) && (
                      <div className="flex items-center gap-1.5">
                        <Link
                          to={`/staff/cases?site=${encodeURIComponent(station.siteName || station.name)}&source=SENSOR&pm25=${station.pm25}`}
                          className="dg-btn dg-btn-primary min-h-[44px]"
                          style={{ padding: '6px 12px', fontSize: 12 }}
                        >
                          <AlertTriangle size={13} />
                          <span>Mở vụ việc</span>
                        </Link>
                        <button
                          type="button"
                          onClick={() => setCreateAlertModal({ open: true, station })}
                          className="dg-btn dg-btn-secondary min-h-[44px]"
                          style={{ padding: '6px 10px', fontSize: 12 }}
                          title="Gửi cảnh báo nhanh"
                        >
                          <span>Cảnh báo</span>
                        </button>
                      </div>
                    )}

                    {/* Row Menu Button */}
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setActiveMenuId(isMenuOpen ? null : station.id)}
                        className="p-2.5 rounded-xl border border-[#161313]/10 text-[#5C5550] hover:text-[#161313] hover:bg-[#F7F6F3] transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
                        title="Tác vụ"
                      >
                        <MoreVertical size={15} />
                      </button>

                      {isMenuOpen && (
                        <div className="absolute right-0 top-full mt-1.5 w-40 bg-white border border-[#161313]/10 rounded-2xl shadow-xl p-1.5 z-40 text-xs">
                          <button
                            type="button"
                            onClick={() => {
                              setEditThresholdModal({ open: true, station });
                              setThresholdForm({ warningPm25: 75, warningPm10: 150 });
                              setActiveMenuId(null);
                            }}
                            className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[#F7F6F3] font-bold text-[#161313] flex items-center gap-2 cursor-pointer min-h-[44px]"
                          >
                            <SlidersHorizontal size={14} />
                            <span>Sửa ngưỡng</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              handleTogglePause(station);
                              setActiveMenuId(null);
                            }}
                            className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[#F7F6F3] font-bold text-[#5C5550] flex items-center gap-2 cursor-pointer min-h-[44px]"
                          >
                            <Radio size={14} />
                            <span>{isInactive ? 'Kích hoạt lại' : 'Tạm dừng trạm'}</span>
                          </button>
                        </div>
                      )}
                    </div>

                    <ChevronRight size={16} className="text-[#A8A29E] hidden md:block" />

                  </div>

                </div>
              );
            })}
          </div>
        )}

        {/* Footer Pagination */}
        <div className="p-4 bg-[#FDFBF7] border-t border-[#161313]/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C5550]">
          <div>
            Hiển thị 1 đến <strong>{sortedStations.length}</strong> trong tổng số <strong>{totalStationsCount}</strong> trạm quan trắc
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] cursor-pointer"
            >
              ← Trang trước
            </button>
            <span className="px-2 text-xs font-mono font-bold text-[#161313]">
              Trang {currentPage}
            </span>
            <button
              type="button"
              onClick={() => setCurrentPage(prev => prev + 1)}
              disabled={sortedStations.length < 15}
              className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] cursor-pointer"
            >
              Trang tiếp →
            </button>
          </div>
        </div>

      </div>

      {/* Modal: Tạo cảnh báo mới (D1 Mutation) */}
      {createAlertModal.open && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setCreateAlertModal({ open: false, station: null })} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">Tạo cảnh báo quan trắc</h3>
              <button 
                type="button" 
                onClick={() => setCreateAlertModal({ open: false, station: null })} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateAlertSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Trạm quan trắc</label>
                <input
                  type="text"
                  readOnly
                  value={createAlertModal.station ? `${createAlertModal.station.name} (${createAlertModal.station.code})` : 'Tất cả các trạm'}
                  className="w-full px-3.5 py-2.5 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Mức độ cảnh báo</label>
                <select className="w-full px-3.5 py-2.5 bg-white border border-[#161313]/10 rounded-xl font-bold min-h-[44px]">
                  <option value="CRITICAL">🔴 Bụi vượt ngưỡng nghiêm trọng (PM10 &gt; 150 µg/m³)</option>
                  <option value="WARNING">🟠 Cần theo dõi tăng cường (PM2.5 &gt; 75 µg/m³)</option>
                </select>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setCreateAlertModal({ open: false, station: null })}
                  className="dg-btn dg-btn-secondary min-h-[44px] justify-center"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="dg-btn dg-btn-primary min-h-[44px] justify-center"
                  style={{ padding: '8px 18px' }}
                >
                  {actionLoading ? 'Đang lưu...' : 'Phát hành cảnh báo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Thêm trạm mới (D1 Mutation) */}
      {addStationModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setAddStationModalOpen(false)} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">Thêm trạm quan trắc mới</h3>
              <button 
                type="button" 
                onClick={() => setAddStationModalOpen(false)} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddStationSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Mã trạm *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: TX-04"
                  value={newStationForm.code}
                  onChange={(e) => setNewStationForm(prev => ({ ...prev, code: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Tên công trình *</label>
                <input
                  type="text"
                  required
                  placeholder="Tên công trình xây dựng..."
                  value={newStationForm.siteName}
                  onChange={(e) => setNewStationForm(prev => ({ ...prev, siteName: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Khu vực / Quận huyện *</label>
                <select
                  value={newStationForm.district}
                  onChange={(e) => setNewStationForm(prev => ({ ...prev, district: e.target.value, location: `${e.target.value}, Hà Nội` }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-bold min-h-[44px]"
                >
                  <option value="Thanh Xuân">Thanh Xuân</option>
                  <option value="Cầu Giấy">Cầu Giấy</option>
                  <option value="Ba Đình">Ba Đình</option>
                  <option value="Long Biên">Long Biên</option>
                  <option value="Hoàng Mai">Hoàng Mai</option>
                  <option value="Hà Đông">Hà Đông</option>
                  <option value="Đống Đa">Đống Đa</option>
                </select>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setAddStationModalOpen(false)}
                  className="dg-btn dg-btn-secondary min-h-[44px] justify-center"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="dg-btn dg-btn-primary min-h-[44px] justify-center"
                  style={{ padding: '8px 18px' }}
                >
                  {actionLoading ? 'Đang lưu...' : 'Lưu vào hệ thống'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Sửa ngưỡng cảnh báo (D1 Mutation) */}
      {editThresholdModal.open && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div className="fixed inset-0 bg-transparent" onClick={() => setEditThresholdModal({ open: false, station: null })} aria-hidden="true" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">
                Sửa ngưỡng cảnh báo ({editThresholdModal.station?.code})
              </h3>
              <button 
                type="button" 
                onClick={() => setEditThresholdModal({ open: false, station: null })} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-2 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveThresholds} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Ngưỡng PM2.5 (µg/m³)</label>
                <input
                  type="number"
                  value={thresholdForm.warningPm25}
                  onChange={(e) => setThresholdForm(prev => ({ ...prev, warningPm25: Number(e.target.value) }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-mono font-bold min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Ngưỡng PM10 (µg/m³)</label>
                <input
                  type="number"
                  value={thresholdForm.warningPm10}
                  onChange={(e) => setThresholdForm(prev => ({ ...prev, warningPm10: Number(e.target.value) }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-mono font-bold min-h-[44px]"
                />
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setEditThresholdModal({ open: false, station: null })}
                  className="dg-btn dg-btn-secondary min-h-[44px] justify-center"
                  style={{ padding: '8px 16px' }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="dg-btn dg-btn-primary min-h-[44px] justify-center"
                  style={{ padding: '8px 18px' }}
                >
                  {actionLoading ? 'Đang lưu...' : 'Lưu thay đổi'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
