import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { StatusBadge, LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import {
  Building2,
  MapPin,
  Clock,
  AlertTriangle,
  FileText,
  Radio,
  ClipboardCheck,
  CheckCircle2,
  ChevronRight,
  Plus,
  Edit3,
  ExternalLink,
  Shield,
  Activity,
  FolderOpen
} from 'lucide-react';

export default function SiteDetailPage() {
  const { id, tab } = useParams();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [site, setSite] = useState(null);
  const [caseTab, setCaseTab] = useState('ALL'); // ALL | OPEN | CLOSED
  const [trendRange, setTrendRange] = useState('7days');
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editFormData, setEditFormData] = useState({
    name: '',
    address: '',
    ward: '',
    contractorName: '',
    managerName: '',
    managerPhone: '',
    dustRiskScore: 50,
    coordinates: ''
  });
  const [editLoading, setEditLoading] = useState(false);

  // Escape key listener & body lock for modal
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') setEditModalOpen(false);
    };
    if (editModalOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [editModalOpen]);

  // Active tab derived from URL param :tab or default to 'overview'
  const activeTab = tab || 'overview';

  const fetchDetail = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request(`/staff/sites/${id || 'site-vd4-02'}/detail`);
      if (res?.data) {
        setSite(res.data);
        setEditFormData({
          name: res.data.name || '',
          address: res.data.address || '',
          ward: res.data.ward || '',
          contractorName: res.data.contractorName || '',
          managerName: res.data.managerName || '',
          managerPhone: res.data.managerPhone || '',
          dustRiskScore: res.data.dustRiskScore ?? 50,
          coordinates: res.data.coordinates || ''
        });
      } else {
        throw new Error('Không tìm thấy thông tin công trình từ CSDL D1');
      }
    } catch (err) {
      setError(err.message || 'Không thể tải chi tiết công trình từ D1/SQLite');
    } finally {
      setLoading(false);
    }
  }, [id]);

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editFormData.name.trim() || !editFormData.address.trim()) {
      alert('Tên và địa chỉ công trình là bắt buộc');
      return;
    }
    try {
      setEditLoading(true);
      await request(`/staff/sites/${site.id}`, {
        method: 'PATCH',
        body: JSON.stringify(editFormData)
      });
      setEditModalOpen(false);
      await fetchDetail();
      alert('Cập nhật thông tin công trình thành công!');
    } catch (err) {
      alert('Lỗi cập nhật: ' + err.message);
    } finally {
      setEditLoading(false);
    }
  };

  const handleTabChange = (newTab) => {
    if (newTab === 'overview') {
      navigate(`/staff/sites/${site.id}`);
    } else {
      navigate(`/staff/sites/${site.id}/${newTab}`);
    }
  };

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  if (loading) return <LoadingState message="Đang tải chi tiết công trình..." />;
  if (error) return <ErrorState title="Lỗi tải chi tiết" message={error} onRetry={fetchDetail} />;
  if (!site) return null;

  const filteredCases = (site.relatedCases || []).filter(c => {
    if (caseTab === 'OPEN') return c.status === 'Mở' || c.status === 'open' || c.status === 'IN_PROGRESS';
    if (caseTab === 'CLOSED') return c.status === 'Đã đóng' || c.status === 'closed';
    return true;
  });

  const recentReadings = site.recentReadings || [
    { time: '10:45 hôm nay', sensorName: 'Trạm TX-01', metric: 'PM2.5 / PM10', value: '78 / 142', unit: 'µg/m³' },
    { time: '09:30 hôm nay', sensorName: 'Trạm TX-01', metric: 'PM2.5 / PM10', value: '82 / 155', unit: 'µg/m³' },
    { time: '08:15 hôm nay', sensorName: 'Trạm TX-01', metric: 'PM2.5 / PM10', value: '65 / 120', unit: 'µg/m³' },
    { time: '17:00 hôm qua', sensorName: 'Trạm TX-01', metric: 'PM2.5 / PM10', value: '55 / 110', unit: 'µg/m³' }
  ];

  const TABS_CONFIG = [
    { key: 'overview', label: 'Tổng quan', icon: Building2 },
    { key: 'activity', label: 'Hoạt động & Tiến trình', icon: Activity },
    { key: 'monitoring', label: 'Quan trắc & Cảm biến', icon: Radio },
    { key: 'dossier', label: 'Hồ sơ pháp lý & QCVN', icon: FileText }
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 1. Header & Top Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="min-w-0">
          <div className="text-xs font-semibold text-[#5C5550]">
            <Link to="/staff/sites" className="hover:text-[#9F241F]">Công trình</Link> / Chi tiết công trình
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight mt-0.5">
            {site.name}
          </h1>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            📍 {site.address} • Mã: <span className="font-mono">{site.code || site.id}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={() => navigate(`/staff/tasks?siteId=${site.id}&action=inspect`)}
            className="px-5 py-2.5 bg-[#9F241F] hover:bg-[#831815] text-white font-extrabold text-xs rounded-xl shadow-xs transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
          >
            <ClipboardCheck size={15} />
            <span>Kiểm tra hiện trường</span>
          </button>

          <button
            type="button"
            onClick={() => setEditModalOpen(true)}
            className="px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
          >
            <Edit3 size={14} />
            <span>Chỉnh sửa</span>
          </button>

          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(site.address || site.name)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl transition min-h-[44px] flex items-center gap-1.5"
          >
            <ExternalLink size={14} />
            <span>Google Maps</span>
          </a>
        </div>
      </div>

      {/* 2. Professional Context Strip */}
      <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-start gap-4 min-w-0 flex-1">
            <div className="w-12 h-12 rounded-2xl bg-[#EDF7F2] text-[#0D6F64] flex items-center justify-center shrink-0 border border-[#BCE6D6]">
              <Building2 size={24} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-mono font-bold text-[#7E7771] px-2 py-0.5 bg-[#F7F6F3] rounded-md">
                  {site.code || site.id}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  site.status === 'PAUSED' ? 'bg-[#FDF2F1] text-[#9F241F] border-[#F8D3D1]' : 'bg-[#EDF7F2] text-[#0D6F64] border-[#BCE6D6]'
                }`}>
                  {site.status === 'PAUSED' ? 'Tạm dừng thi công' : 'Đang thi công'}
                </span>
                <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-[#FEF9EE] text-[#B45309] border border-[#FDE68A]">
                  Rủi ro: {site.dustRiskScore ?? 50}/100
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-[#161313]/5 text-xs">
                <div>
                  <span className="text-[#7E7771] font-medium block text-[10px] uppercase">Đơn vị thi công</span>
                  <strong className="text-[#161313] font-bold">{site.contractorName || 'Công ty CP Xây dựng & Đô thị'}</strong>
                </div>
                <div>
                  <span className="text-[#7E7771] font-medium block text-[10px] uppercase">Chỉ huy trưởng</span>
                  <strong className="text-[#161313] font-bold">{site.managerName || 'Nguyễn Văn Hùng'}</strong>
                  {site.managerPhone && <span className="text-[#7E7771] ml-1.5 font-mono">📞 {site.managerPhone}</span>}
                </div>
                <div>
                  <span className="text-[#7E7771] font-medium block text-[10px] uppercase">PM2.5 gần nhất</span>
                  <strong className="text-[#9F241F] font-mono font-bold text-sm">
                    {site.recentReadings?.[0]?.value?.split(' / ')?.[0] || '68'} µg/m³
                  </strong>
                </div>
              </div>
            </div>
          </div>

          <div className="flex md:flex-col items-end justify-between w-full md:w-auto shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-[#161313]/5">
            <div className="text-right">
              <div className="text-[11px] font-bold text-[#7E7771]">Lần kiểm tra gần nhất</div>
              <div className="text-xs font-black text-[#1C1917] mt-0.5">
                {site.lastInspectionDate || '14:30 hôm qua'}
              </div>
            </div>
            <div className="text-right text-[11px] text-[#7E7771] mt-2">
              Trạng thái: <strong className="text-[#161313] font-semibold">{site.status === 'PAUSED' ? 'Tạm dừng' : 'Đang theo dõi'}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs (Overview, Activity, Monitoring, Dossier) */}
      <div className="flex border-b border-[#161313]/10 gap-1 overflow-x-auto no-scrollbar">
        {TABS_CONFIG.map(t => {
          const Icon = t.icon;
          const isActive = activeTab === t.key || (activeTab === 'cases' && t.key === 'activity') || (activeTab === 'sensors' && t.key === 'monitoring') || (activeTab === 'documents' && t.key === 'dossier') || (activeTab === 'inspections' && t.key === 'dossier');
          return (
            <button
              key={t.key}
              onClick={() => handleTabChange(t.key)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap min-h-[44px] cursor-pointer ${
                isActive
                  ? 'border-[#9F241F] text-[#9F241F] bg-[#FDF2F1]/50'
                  : 'border-transparent text-[#5C5550] hover:text-[#161313] hover:bg-[#F7F6F3]'
              }`}
            >
              <Icon size={16} />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT 1: OVERVIEW (Mockup 5 Full Specifications) */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Top 4 Metric KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            
            {/* KPI 1: Điểm rủi ro */}
            <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-[#FDF2F1] text-[#9F241F] flex items-center justify-center shrink-0 border border-[#F8D3D1]">
                <Shield size={20} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#5C5550]">Điểm rủi ro</div>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-2xl font-black text-[#9F241F] leading-none">{site.kpis?.dustRiskScore ?? site.dustRiskScore ?? 50}</span>
                  <span className="text-xs font-bold text-[#7E7771]">/100</span>
                </div>
                <div className="text-[11px] text-[#7E7771] mt-1 font-medium">Theo chuẩn QCVN 05</div>
              </div>
            </div>

            {/* KPI 2: Cảnh báo mở */}
            <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-[#FEF9EE] text-[#B45309] flex items-center justify-center shrink-0 border border-[#FDE68A]">
                <AlertTriangle size={20} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#5C5550]">Cảnh báo mở</div>
                <div className="text-2xl font-black text-[#161313] leading-none mt-0.5">{site.kpis?.openAlertsCount ?? site.openAlertsCount ?? 0}</div>
                <div className="text-[11px] text-[#7E7771] mt-1 font-medium">Chờ xác minh</div>
              </div>
            </div>

            {/* KPI 3: Hồ sơ mở */}
            <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-[#F0F7FF] text-[#2563EB] flex items-center justify-center shrink-0 border border-[#BFDBFE]">
                <FolderOpen size={20} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#5C5550]">Hồ sơ mở</div>
                <div className="text-2xl font-black text-[#161313] leading-none mt-0.5">{site.kpis?.openCasesCount ?? site.openCasesCount ?? 0}</div>
                <div className="text-[11px] text-[#7E7771] mt-1 font-medium">Đang thụ lý</div>
              </div>
            </div>

            {/* KPI 4: Trạm đo */}
            <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-[#EDF7F2] text-[#0D6F64] flex items-center justify-center shrink-0 border border-[#BCE6D6]">
                <Radio size={20} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#5C5550]">Trạm đo</div>
                <div className="text-2xl font-black text-[#161313] leading-none mt-0.5">{site.kpis?.activeSensorsCount ?? site.activeSensorsCount ?? 0}</div>
                <div className="text-[11px] text-[#0D6F64] mt-1 font-bold">Đang hoạt động</div>
              </div>
            </div>

          </div>

          {/* Middle Row: Map + Trend Chart + Missing Items */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Left: Vị trí công trình Map (4 cols) */}
            <div className="lg:col-span-4 bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3 flex flex-col">
              <div className="font-black text-xs sm:text-sm text-[#161313]">
                Vị trí công trình
              </div>
              <div className="w-full flex-1 min-h-[200px] rounded-2xl overflow-hidden border border-[#161313]/10 relative bg-[#F7F6F3]">
                {(() => {
                  let lat = 21.028511;
                  let lng = 105.804817;
                  if (site.coordinates && site.coordinates.includes(',')) {
                    const parts = site.coordinates.split(',').map(Number);
                    if (!isNaN(parts[0]) && !isNaN(parts[1])) {
                      lat = parts[0];
                      lng = parts[1];
                    }
                  }
                  const bbox = `${(lng - 0.02).toFixed(4)},${(lat - 0.02).toFixed(4)},${(lng + 0.02).toFixed(4)},${(lat + 0.02).toFixed(4)}`;
                  return (
                    <iframe
                      title="Bản đồ vị trí"
                      src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat},${lng}`}
                      className="w-full h-full border-0"
                    />
                  );
                })()}
                <div className="absolute bottom-2 left-2 bg-white/95 px-2.5 py-1 rounded-xl text-[10px] font-bold text-[#161313] shadow-xs border border-[#161313]/10 max-w-[85%] truncate">
                  📍 {site.name}
                </div>
              </div>
            </div>

            {/* Center: Xu hướng điểm rủi ro (5 cols) */}
            <div className="lg:col-span-5 bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3 flex flex-col">
              <div className="flex items-center justify-between">
                <div className="font-black text-xs sm:text-sm text-[#161313]">
                  Xu hướng điểm rủi ro
                </div>
                <select
                  value={trendRange}
                  onChange={(e) => setTrendRange(e.target.value)}
                  className="text-[11px] font-bold border border-[#161313]/10 rounded-lg px-2 py-1 bg-white cursor-pointer"
                >
                  <option value="7days">7 ngày ⌵</option>
                  <option value="30days">30 ngày</option>
                </select>
              </div>

              <div className="flex-1 min-h-[200px] flex items-end justify-between gap-2 pt-4 px-2">
                {(site.riskTrend7Days || [
                  { date: 'T2', score: 85 },
                  { date: 'T3', score: 88 },
                  { date: 'T4', score: 80 },
                  { date: 'T5', score: 90 },
                  { date: 'T6', score: 87 },
                  { date: 'T7', score: 92 },
                  { date: 'CN', score: 92 }
                ]).map((t, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 min-w-0">
                    <span className="text-[10px] font-black text-[#9F241F]">{t.score}</span>
                    <div
                      style={{ height: `${Math.max(16, (t.score / 100) * 120)}px` }}
                      className="w-full max-w-[24px] bg-[#9F241F] rounded-t-lg opacity-85 hover:opacity-100 transition"
                    />
                    <span className="text-[9px] font-bold text-[#7E7771]">{t.date}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Việc cần bổ sung (3 cols) */}
            <div className="lg:col-span-3 bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-[#161313]">
                  <span className="text-[#B45309]">⚠️</span>
                  <span>Việc cần bổ sung</span>
                </div>

                <div className="space-y-2 mt-3">
                  {(site.missingItems || [
                    { id: '1', title: 'Chưa có trạm đo bụi', action: 'Thêm trạm' }
                  ]).map(item => (
                    <div key={item.id} className="flex items-center justify-between gap-2 p-3 rounded-2xl bg-[#F7F6F3] border border-[#161313]/5">
                      <span className="text-xs font-bold text-[#161313] leading-tight">
                        {item.title}
                      </span>
                      <button
                        onClick={() => alert(`Thực hiện: ${item.action}`)}
                        className="px-3 py-1.5 rounded-xl border border-[#F8D3D1] bg-[#FDF2F1] text-[#9F241F] text-xs font-bold hover:bg-[#FEE2E2] shrink-0 cursor-pointer min-h-[44px] flex items-center justify-center"
                      >
                        {item.action}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => alert('Xem toàn bộ danh sách việc cần bổ sung')}
                className="text-xs font-bold text-[#5C5550] hover:text-[#9F241F] pt-2 flex items-center gap-1 transition min-h-[44px] cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span>➔</span>
              </button>
            </div>

          </div>

          {/* Table 1: Hồ sơ liên quan */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-[#161313]/10">
              <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-[#161313]">
                <FolderOpen size={16} className="text-[#0D6F64]" />
                <span>Hồ sơ liên quan</span>
              </div>

              <div className="flex items-center gap-1">
                {[
                  { label: 'Tất cả', val: 'ALL' },
                  { label: 'Hồ sơ mở', val: 'OPEN' },
                  { label: 'Đã đóng', val: 'CLOSED' }
                ].map(t => (
                  <button
                    key={t.val}
                    onClick={() => setCaseTab(t.val)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition min-h-[38px] flex items-center justify-center cursor-pointer ${
                      caseTab === t.val ? 'bg-[#FDF2F1] text-[#9F241F]' : 'text-[#5C5550] hover:bg-[#F7F6F3]'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#161313]/10 text-[#7E7771] font-bold">
                    <th className="py-2.5 px-3">MÃ HỒ SƠ</th>
                    <th className="py-2.5 px-3">TIÊU ĐỀ</th>
                    <th className="py-2.5 px-3">TRẠNG THÁI</th>
                    <th className="py-2.5 px-3">HẠN XỬ LÝ</th>
                    <th className="py-2.5 px-3 text-right">THAO TÁC</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCases.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-6 text-[#7E7771]">
                        Không có hồ sơ nào phù hợp bộ lọc.
                      </td>
                    </tr>
                  ) : (
                    filteredCases.map(c => (
                      <tr key={c.id} className="border-b border-[#161313]/5 hover:bg-[#FDFBF7]">
                        <td className="py-3 px-3 font-mono font-bold text-[#161313]">{c.id}</td>
                        <td className="py-3 px-3 font-semibold text-[#161313]">{c.title}</td>
                        <td className="py-3 px-3">
                          <StatusBadge status={c.status} />
                        </td>
                        <td className="py-3 px-3 text-[#7E7771]">{c.deadline || 'Trong 48h'}</td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => navigate(`/staff/cases/${c.id}`)}
                            className="px-3 py-1.5 bg-[#F7F6F3] hover:bg-[#EFECE6] text-[#161313] border border-[#161313]/10 rounded-lg font-bold text-xs cursor-pointer min-h-[36px]"
                          >
                            Chi tiết
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 2: Lịch sử đo gần đây */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-[#161313]">
                <Radio size={16} className="text-[#0D6F64]" />
                <span>Lịch sử đo gần đây</span>
              </div>
              <button
                onClick={() => handleTabChange('sensors')}
                className="text-xs font-bold text-[#5C5550] hover:text-[#9F241F] min-h-[38px] flex items-center"
              >
                Xem tất cả cảm biến →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#161313]/10 text-[#7E7771] font-bold">
                    <th className="py-2.5 px-3">THỜI GIAN</th>
                    <th className="py-2.5 px-3">TRẠM ĐO</th>
                    <th className="py-2.5 px-3">CHỈ TIÊU</th>
                    <th className="py-2.5 px-3">GIÁ TRỊ ĐO</th>
                    <th className="py-2.5 px-3">ĐƠN VỊ</th>
                  </tr>
                </thead>
                <tbody>
                  {recentReadings.map((r, idx) => (
                    <tr key={idx} className="border-b border-[#161313]/5 hover:bg-[#FDFBF7]">
                      <td className="py-3 px-3 font-medium text-[#161313]">{r.time}</td>
                      <td className="py-3 px-3 font-bold text-[#0D6F64]">{r.sensorName}</td>
                      <td className="py-3 px-3 text-[#5C5550]">{r.metric}</td>
                      <td className="py-3 px-3 font-mono font-bold text-[#9F241F]">{r.value}</td>
                      <td className="py-3 px-3 text-[#7E7771]">{r.unit}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* TAB CONTENT 2: INSPECTIONS */}
      {activeTab === 'inspections' && (
        <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
            <div>
              <h3 className="text-base font-black text-[#161313]">Lịch sử kiểm tra & Biên bản hiện trường</h3>
              <p className="text-xs text-[#5C5550]">Biên bản kiểm tra đột xuất và định kỳ theo NĐ 45/2022/NĐ-CP</p>
            </div>
            <button
              onClick={() => navigate('/staff/tasks')}
              className="dg-btn dg-btn-primary min-h-[44px]"
              style={{ padding: '8px 14px', fontSize: 13 }}
            >
              <Plus size={14} />
              <span>Lập đợt kiểm tra</span>
            </button>
          </div>

          <div className="space-y-3">
            {[
              {
                id: 'INSP-2026-08',
                date: '02/09/2026',
                inspector: 'Đội Thanh tra Số 1 (Lê Minh Tuấn)',
                result: 'Có vi phạm',
                notes: 'Xe chở phế thải không rửa lốp, bạt che rách 3 vị trí',
                fineAmount: '25.000.000 VNĐ'
              },
              {
                id: 'INSP-2026-07',
                date: '25/08/2026',
                inspector: 'Cán bộ Nguyễn Thị Lan',
                result: 'Đạt yêu cầu',
                notes: 'Hệ thống phun sương dập bụi hoạt động ổn định',
                fineAmount: '0 VNĐ'
              }
            ].map(insp => (
              <div key={insp.id} className="p-4 bg-[#F7F6F3] rounded-2xl border border-[#161313]/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[#161313]">{insp.id}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                      insp.result === 'Có vi phạm' ? 'bg-[#FDF2F1] text-[#9F241F]' : 'bg-[#EDF7F2] text-[#1B7A4B]'
                    }`}>
                      {insp.result}
                    </span>
                  </div>
                  <div className="text-xs font-medium text-[#161313]">{insp.notes}</div>
                  <div className="text-[11px] text-[#7E7771]">Ngày kiểm tra: {insp.date} · Cán bộ: {insp.inspector}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-bold text-[#9F241F]">{insp.fineAmount}</div>
                  <button 
                    onClick={() => alert(`Xem biên bản ${insp.id}`)}
                    className="text-xs text-[#0D6F64] font-bold hover:underline mt-1 block min-h-[34px]"
                  >
                    Xem biên bản →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: SENSORS */}
      {activeTab === 'sensors' && (
        <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
            <div>
              <h3 className="text-base font-black text-[#161313]">Trạm quan trắc & Cảm biến IoT</h3>
              <p className="text-xs text-[#5C5550]">Dữ liệu truyền theo thời gian thực từ các trạm quan trắc bụi</p>
            </div>
            <button
              onClick={() => alert('Mở cấu hình gắn cảm biến mới cho công trình này')}
              className="dg-btn dg-btn-primary min-h-[44px]"
              style={{ padding: '8px 14px', fontSize: 13 }}
            >
              <Plus size={14} />
              <span>Gắn cảm biến</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-[#F7F6F3] rounded-2xl border border-[#161313]/5 space-y-3">
              <div className="flex items-center justify-between">
                <strong className="text-sm font-bold text-[#161313]">Trạm quan trắc cổng phía Đông (SEN-01)</strong>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EDF7F2] text-[#1B7A4B]">Online</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-white rounded-xl border border-[#161313]/5">
                  <span className="text-[#7E7771] block">PM2.5 tức thời</span>
                  <span className="text-lg font-black text-[#9F241F]">78 µg/m³</span>
                </div>
                <div className="p-2.5 bg-white rounded-xl border border-[#161313]/5">
                  <span className="text-[#7E7771] block">PM10 tức thời</span>
                  <span className="text-lg font-black text-[#B45309]">142 µg/m³</span>
                </div>
              </div>
              <div className="text-[11px] text-[#7E7771]">Tín hiệu gửi: 2 phút trước · Pin: 98% · IP: 192.168.1.104</div>
            </div>

            <div className="p-4 bg-[#F7F6F3] rounded-2xl border border-[#161313]/5 space-y-3">
              <div className="flex items-center justify-between">
                <strong className="text-sm font-bold text-[#161313]">Trạm quan trắc cổng xe tải (SEN-02)</strong>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EDF7F2] text-[#1B7A4B]">Online</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-white rounded-xl border border-[#161313]/5">
                  <span className="text-[#7E7771] block">PM2.5 tức thời</span>
                  <span className="text-lg font-black text-[#1B7A4B]">32 µg/m³</span>
                </div>
                <div className="p-2.5 bg-white rounded-xl border border-[#161313]/5">
                  <span className="text-[#7E7771] block">PM10 tức thời</span>
                  <span className="text-lg font-black text-[#1B7A4B]">68 µg/m³</span>
                </div>
              </div>
              <div className="text-[11px] text-[#7E7771]">Tín hiệu gửi: 5 phút trước · Pin: 94% · IP: 192.168.1.105</div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: DOCUMENTS */}
      {activeTab === 'documents' && (
        <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
            <div>
              <h3 className="text-base font-black text-[#161313]">Hồ sơ pháp lý & Xử lý vi phạm</h3>
              <p className="text-xs text-[#5C5550]">Văn bản hành chính, quyết định xử phạt và giấy phép môi trường</p>
            </div>
            <button
              onClick={() => alert('Tạo quyết định / văn bản mới')}
              className="dg-btn dg-btn-primary min-h-[44px]"
              style={{ padding: '8px 14px', fontSize: 13 }}
            >
              <Plus size={14} />
              <span>Tạo văn bản A4</span>
            </button>
          </div>

          <div className="divide-y divide-[#161313]/5">
            {[
              {
                id: 'DOC-2026-042',
                title: 'Quyết định xử phạt vi phạm hành chính số 42/QĐ-XPHC',
                type: 'Quyết định xử phạt',
                date: '28/08/2026',
                status: 'Đã tống đạt'
              },
              {
                id: 'DOC-2026-038',
                title: 'Biên bản kiểm tra hiện trường công trình xây dựng số 18/BB-KT',
                type: 'Biên bản kiểm tra',
                date: '20/08/2026',
                status: 'Đã ký kết'
              },
              {
                id: 'DOC-2026-012',
                title: 'Kế hoạch bảo vệ môi trường và quản lý bụi thi công',
                type: 'Hồ sơ pháp lý',
                date: '15/01/2026',
                status: 'Đã phê duyệt'
              }
            ].map(doc => (
              <div key={doc.id} className="py-3 flex items-center justify-between gap-3 hover:bg-[#FDFBF7] px-3 rounded-2xl transition">
                <div className="space-y-0.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[#7E7771]">{doc.id}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EDF7F2] text-[#0D6F64]">
                      {doc.type}
                    </span>
                  </div>
                  <strong className="text-xs sm:text-sm font-bold text-[#161313] block break-words">
                    {doc.title}
                  </strong>
                  <span className="text-[11px] text-[#7E7771] block">Ngày ban hành: {doc.date} · Trạng thái: {doc.status}</span>
                </div>
                <button
                  onClick={() => alert(`Xem văn bản ${doc.id}`)}
                  className="px-3.5 py-2 bg-[#F7F6F3] hover:bg-[#EFECE6] text-[#161313] border border-[#161313]/10 rounded-xl font-bold text-xs cursor-pointer min-h-[44px] flex items-center justify-center"
                >
                  Xem A4
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 5: CASES */}
      {activeTab === 'cases' && (
        <div className="bg-white border border-[#161313]/10 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
            <div>
              <h3 className="text-base font-black text-[#161313]">Danh sách hồ sơ vụ việc của công trình</h3>
              <p className="text-xs text-[#5C5550]">Theo dõi tiến độ 7 bước xử lý vi phạm môi trường</p>
            </div>
            <button
              onClick={() => navigate('/staff/cases')}
              className="dg-btn dg-btn-primary min-h-[44px]"
              style={{ padding: '8px 14px', fontSize: 13 }}
            >
              <Plus size={14} />
              <span>Tạo vụ việc</span>
            </button>
          </div>

          <div className="divide-y divide-[#161313]/5">
            {(site.relatedCases || []).map(c => (
              <div 
                key={c.id} 
                onClick={() => navigate(`/staff/cases/${c.id}`)}
                className="py-3 flex items-center justify-between gap-3 hover:bg-[#FDFBF7] px-3 rounded-2xl transition cursor-pointer"
              >
                <div className="space-y-0.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[#7E7771]">{c.id}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  <strong className="text-xs sm:text-sm font-bold text-[#161313] block break-words">
                    {c.title}
                  </strong>
                  <span className="text-[11px] text-[#7E7771] block">Thời hạn xử lý: {c.deadline || 'Trong 48h'}</span>
                </div>
                <ChevronRight size={16} className="text-[#A8A29E] shrink-0" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Chỉnh sửa công trình */}
      {editModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#161313]/60 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setEditModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-lg bg-white border border-[#161313]/10 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex justify-between items-center border-b border-[#161313]/10 pb-3">
              <h3 className="font-black text-base text-[#161313]">Chỉnh sửa công trình</h3>
              <button 
                onClick={() => setEditModalOpen(false)}
                className="text-[#7E7771] hover:text-[#161313] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Tên công trình *</label>
                <input 
                  type="text"
                  required
                  value={editFormData.name}
                  onChange={e => setEditFormData({ ...editFormData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl focus:outline-none focus:border-[#9F241F] min-h-[44px]"
                />
              </div>
              <div>
                <label className="block font-bold text-[#161313] mb-1">Địa chỉ *</label>
                <input 
                  type="text"
                  required
                  value={editFormData.address}
                  onChange={e => setEditFormData({ ...editFormData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl focus:outline-none focus:border-[#9F241F] min-h-[44px]"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#161313] mb-1">Đơn vị thi công</label>
                  <input 
                    type="text"
                    value={editFormData.contractorName}
                    onChange={e => setEditFormData({ ...editFormData, contractorName: e.target.value })}
                    className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl focus:outline-none focus:border-[#9F241F] min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#161313] mb-1">Người phụ trách</label>
                  <input 
                    type="text"
                    value={editFormData.managerName}
                    onChange={e => setEditFormData({ ...editFormData, managerName: e.target.value })}
                    className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl focus:outline-none focus:border-[#9F241F] min-h-[44px]"
                  />
                </div>
              </div>
              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-[#161313]/15 font-bold text-[#5C5550] hover:bg-[#F7F6F3] min-h-[44px] cursor-pointer flex items-center justify-center"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={editLoading}
                  className="px-5 py-2.5 rounded-xl bg-[#9F241F] hover:bg-[#831815] text-white font-black min-h-[44px] cursor-pointer flex items-center justify-center shadow-xs"
                >
                  {editLoading ? 'Đang lưu...' : 'Lưu thay đổi'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

