import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';
import {
  Building2,
  MapPin,
  Search,
  Plus,
  MoreVertical,
  ChevronRight,
  Download,
  Upload,
  User,
  Shield,
  Filter
} from 'lucide-react';

export default function SitesListPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter & Pagination States
  const [searchQuery, setSearchQuery] = useState('');
  const [wardFilter, setWardFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalSitesCount, setTotalSitesCount] = useState(0);
  const [availableWards, setAvailableWards] = useState([]);

  // Data States
  const [kpis, setKpis] = useState({
    totalSites: 38,
    highRiskCount: 5,
    monitoringCount: 15,
    stableCount: 18
  });
  const [sites, setSites] = useState([]);
  const [priorities, setPriorities] = useState([]);

  // Modals & Action States
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Form State
  const [newSite, setNewSite] = useState({
    name: '',
    address: '',
    ward: 'Phường Dịch Vọng, Cầu Giấy',
    managerName: 'Nguyễn Văn An',
    contractorName: '',
    dustRiskScore: 65
  });

  // Escape key listener & body lock for modal
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') setCreateModalOpen(false);
    };
    if (createModalOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [createModalOpen]);

  // 1. Fetch Summary KPIs
  const fetchSummary = useCallback(async () => {
    try {
      const res = await request('/staff/sites/summary');
      if (res?.data) {
        setKpis({
          totalSites: res.data.totalSites ?? 38,
          highRiskCount: res.data.highRiskCount ?? 5,
          monitoringCount: res.data.monitoringCount ?? 15,
          stableCount: res.data.stableCount ?? 18
        });
      }
    } catch (err) {
      console.error('Error fetching sites summary:', err);
    }
  }, []);

  // 2. Fetch Priority Today
  const fetchPriorities = useCallback(async () => {
    try {
      const res = await request('/staff/sites/priorities');
      if (res?.data?.items) {
        setPriorities(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching priorities:', err);
    }
  }, []);

  // 3. Fetch Wards
  const fetchWards = useCallback(async () => {
    try {
      const res = await request('/staff/sites/wards');
      if (res?.data?.items && res.data.items.length > 0) {
        setAvailableWards(res.data.items);
      }
    } catch (err) {
      console.error('Error fetching wards:', err);
    }
  }, []);

  // 4. Fetch Sites List
  const fetchSites = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        search: searchQuery,
        ward: wardFilter,
        status: statusFilter,
        page: String(currentPage),
        limit: '10'
      });
      const res = await request(`/staff/sites/list?${params.toString()}`).catch(() => request('/sites'));
      if (res?.data?.items) {
        setSites(res.data.items);
        setTotalSitesCount(res.data.pagination?.total ?? res.data.items.length);
      } else {
        const items = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []);
        setSites(items);
        setTotalSitesCount(items.length);
      }
    } catch (err) {
      console.error('Error fetching sites list:', err);
      setSites([]);
      setTotalSitesCount(0);
    }
  }, [searchQuery, wardFilter, statusFilter, currentPage]);

  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await Promise.all([fetchSummary(), fetchPriorities(), fetchWards(), fetchSites()]);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách công trình');
    } finally {
      setLoading(false);
    }
  }, [fetchSummary, fetchPriorities, fetchWards, fetchSites]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  useEffect(() => {
    fetchSites();
  }, [fetchSites]);

  // Create Site Handler
  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    if (!newSite.name || !newSite.address) {
      alert('Vui lòng nhập đầy đủ tên và địa chỉ công trình');
      return;
    }
    try {
      setActionLoading(true);
      await request('/staff/sites/create', {
        method: 'POST',
        body: JSON.stringify(newSite)
      });
      setCreateModalOpen(false);
      setNewSite({
        name: '',
        address: '',
        ward: 'Phường Dịch Vọng, Cầu Giấy',
        managerName: 'Nguyễn Văn An',
        contractorName: '',
        dustRiskScore: 65
      });
      await loadAllData();
      alert('Đã thêm công trình mới thành công!');
    } catch (err) {
      alert('Lỗi thêm công trình: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState message="Đang tải sổ bộ công trình…" />;
  if (error) return <ErrorState title="Lỗi tải công trình" message={error} onRetry={loadAllData} />;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#161313] tracking-tight">
            Công trình đang theo dõi
          </h1>
          <p className="text-xs sm:text-sm text-[#5C5550] mt-0.5 font-medium">
            Sổ bộ các công trình xây dựng, tình hình kiểm tra và hồ sơ liên quan.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end flex-wrap">
          <button
            onClick={() => alert('Mẫu Excel nhập danh sách công trình đã sẵn sàng.')}
            className="dg-btn dg-btn-secondary min-h-[44px]"
            style={{ padding: '8px 12px', fontSize: 13 }}
          >
            <Upload size={15} />
            <span>Nhập Excel</span>
          </button>

          <button
            onClick={() => setCreateModalOpen(true)}
            className="dg-btn dg-btn-primary min-h-[44px]"
            style={{ padding: '8px 16px', fontSize: 13 }}
          >
            <Plus size={15} />
            <span>Thêm công trình</span>
          </button>

          <button
            onClick={() => alert('Đang xuất danh sách công trình...')}
            className="dg-btn dg-btn-secondary min-h-[44px]"
            style={{ padding: '8px 12px', fontSize: 13 }}
          >
            <Download size={15} />
            <span className="hidden sm:inline">Xuất danh sách</span>
          </button>
        </div>
      </div>

      {/* 2. Operations KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Tổng công trình
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#161313]">
              {kpis.totalSites}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">điểm giám sát</span>
          </div>
        </div>

        <div className={`rounded-2xl p-4 border shadow-2xs ${
          kpis.highRiskCount > 0 ? 'bg-[#FDF2F1] border-[#F8D3D1]' : 'bg-white border-[#161313]/10'
        }`}>
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Cần ưu tiên kiểm tra
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className={`text-2xl sm:text-3xl font-black ${
              kpis.highRiskCount > 0 ? 'text-[#9F241F]' : 'text-[#161313]'
            }`}>
              {kpis.highRiskCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">công trình</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Đang theo dõi xử lý
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#B45309]">
              {kpis.monitoringCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">công trình</span>
          </div>
        </div>

        <div className="bg-white border border-[#161313]/10 rounded-2xl p-4 shadow-2xs">
          <span className="text-[11px] font-bold text-[#5C5550] uppercase tracking-wider block">
            Tuân thủ tốt
          </span>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-2xl sm:text-3xl font-black text-[#1B7A4B]">
              {kpis.stableCount}
            </span>
            <span className="text-xs font-bold text-[#7E7771]">đạt chuẩn</span>
          </div>
        </div>

      </div>

      {/* 3. Main Content: List + Top 3 Priorities Right Panel */}
      <div className="flex flex-col xl:flex-row gap-5 items-start">
        
        {/* Left: Filter Toolbar & Dense Sites List */}
        <div className="flex-1 min-w-0 w-full space-y-4">
          
          {/* Filter Toolbar */}
          <div className="bg-white border border-[#161313]/10 rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[240px]">
              <Search size={15} className="text-[#7E7771] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm kiếm tên công trình, địa chỉ, nhà thầu..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="w-full pl-9 pr-3.5 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl text-xs text-[#161313] focus:outline-none focus:border-[#9F241F] min-h-[40px] font-medium"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <select
                value={wardFilter}
                onChange={(e) => { setWardFilter(e.target.value); setCurrentPage(1); }}
                className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[40px] cursor-pointer"
              >
                <option value="ALL">Khu vực: Tất cả</option>
                {availableWards.map(w => (
                  <option key={w} value={w}>{w}</option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
                className="px-3 py-2 bg-[#F7F6F3] border border-[#161313]/10 rounded-xl font-bold text-[#161313] focus:outline-none min-h-[40px] cursor-pointer"
              >
                <option value="ALL">Tình trạng: Tất cả</option>
                <option value="Cần kiểm tra">Cần kiểm tra</option>
                <option value="Đang theo dõi">Đang theo dõi</option>
                <option value="Tuân thủ tốt">Tuân thủ tốt</option>
              </select>
            </div>
          </div>

          {/* Sites List */}
          <div className="bg-white border border-[#161313]/10 rounded-3xl shadow-xs overflow-hidden">
            {sites.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#F7F6F3] text-[#7E7771] flex items-center justify-center mx-auto">
                  <Building2 size={22} />
                </div>
                <strong className="text-sm text-[#161313] block">Không tìm thấy công trình nào phù hợp</strong>
                <p className="text-xs text-[#5C5550]">Hãy thử đổi từ khóa tìm kiếm hoặc lọc theo khu vực khác.</p>
              </div>
            ) : (
              <div className="divide-y divide-[#161313]/5">
                {sites.map((s) => {
                  const isAlert = s.status === 'Cần kiểm tra' || s.statusColor === 'red' || (s.dustRiskScore ?? 0) >= 70;
                  const isWarning = s.status === 'Đang theo dõi' || s.statusColor === 'amber' || ((s.dustRiskScore ?? 0) >= 40 && (s.dustRiskScore ?? 0) < 70);

                  return (
                    <div
                      key={s.id}
                      onClick={() => navigate(`/staff/sites/${s.id}`)}
                      className={`p-4 sm:p-5 transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer hover:bg-[#FDFBF7] ${
                        isAlert ? 'bg-[#FFFBFB]' : 'bg-white'
                      }`}
                    >
                      {/* Left: Site name (No truncate, wrap 2 lines) + Address */}
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <span className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${
                          isAlert ? 'bg-[#9F241F] animate-pulse' : isWarning ? 'bg-[#D97706]' : 'bg-[#1B7A4B]'
                        }`} />

                        <div className="min-w-0 space-y-1">
                          <strong className="text-sm sm:text-base font-bold text-[#161313] leading-snug break-words block">
                            {s.name}
                          </strong>

                          <div className="flex items-center gap-1.5 text-xs text-[#5C5550]">
                            <MapPin size={12} className="shrink-0 text-[#7E7771]" />
                            <span className="break-words">{s.address}</span>
                          </div>

                          <div className="text-xs text-[#7E7771]">
                            Đơn vị thi công: <span className="font-medium text-[#161313]">{s.contractorName || 'Chưa cập nhật'}</span>
                          </div>
                        </div>
                      </div>

                      {/* Center: Manager & Active Cases */}
                      <div className="flex flex-wrap items-center gap-4 sm:gap-6 shrink-0 py-1 md:py-0 border-t md:border-t-0 border-[#161313]/5 w-full md:w-auto justify-between md:justify-start text-xs">
                        
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-bold text-[#7E7771] uppercase block">Cán bộ phụ trách</span>
                          <div className="flex items-center gap-1.5 font-medium text-[#161313]">
                            <User size={13} className="text-[#7E7771]" />
                            <span>{s.managerName || 'Nguyễn Văn An'}</span>
                          </div>
                        </div>

                        <div className="space-y-0.5 text-right min-w-[90px]">
                          <span className="text-[10px] font-bold text-[#7E7771] uppercase block">Hồ sơ liên quan</span>
                          <span className="font-bold text-xs text-[#161313]">
                            {s.activeCasesCount ?? s.openCasesCount ?? 0} vụ việc
                          </span>
                        </div>

                      </div>

                      {/* Right: Status badge & Chevron */}
                      <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                          isAlert
                            ? 'bg-[#FDF2F1] text-[#9F241F] border-[#F8D3D1]'
                            : isWarning
                            ? 'bg-[#FEF9EE] text-[#B45309] border-[#FDE68A]'
                            : 'bg-[#EDF7F2] text-[#1B7A4B] border-[#A3E6C5]'
                        }`}>
                          {s.status}
                        </span>
                        <ChevronRight size={16} className="text-[#A8A29E] hidden md:block" />
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* Footer Pagination */}
            <div className="p-4 bg-[#FDFBF7] border-t border-[#161313]/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C5550]">
              <div>
                Hiển thị <strong>{sites.length}</strong> / <strong>{totalSitesCount}</strong> công trình xây dựng
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] flex items-center justify-center cursor-pointer"
                >
                  ← Trang trước
                </button>
                <button
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={sites.length < 10}
                  className="px-3.5 py-2 rounded-xl border border-[#161313]/10 font-bold disabled:opacity-30 hover:bg-white transition min-h-[44px] flex items-center justify-center cursor-pointer"
                >
                  Trang tiếp →
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Right: Cần chú ý Panel (xl:w-[310px] 14-inch layout) */}
        <div className="w-full xl:w-[310px] shrink-0 space-y-4">
          <div className="bg-white border border-[#161313]/10 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between pb-2.5 border-b border-[#161313]/10">
              <h2 className="text-sm font-black text-[#161313] flex items-center gap-1.5">
                <Shield size={16} className="text-[#9F241F]" />
                <span>Cần chú ý hôm nay</span>
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FDF2F1] text-[#9F241F] border border-[#F8D3D1]">
                Top 3 rủi ro
              </span>
            </div>

            <div className="space-y-3">
              {(priorities.length > 0 ? priorities : [
                {
                  id: 'p1',
                  name: 'Dự án Vành Đai 3 - Mai Dịch',
                  address: 'Khuất Duy Tiến, Thanh Xuân',
                  dustRiskScore: 88,
                  openCasesCount: 2,
                  sensorName: 'Trạm TX-01'
                },
                {
                  id: 'p2',
                  name: 'Tổ hợp Discovery Complex Cầu Giấy',
                  address: '302 Cầu Giấy',
                  dustRiskScore: 78,
                  openCasesCount: 1,
                  sensorName: 'Trạm CG-02'
                },
                {
                  id: 'p3',
                  name: 'Khu đô thị Starlake Tây Hồ',
                  address: 'Xuân Tảo, Bắc Từ Liêm',
                  dustRiskScore: 65,
                  openCasesCount: 1,
                  sensorName: 'Chưa gắn trạm'
                }
              ]).map((p, idx) => (
                <div
                  key={p.id || idx}
                  onClick={() => navigate(`/staff/sites/${p.id}`)}
                  className="p-3 bg-[#F7F6F3] rounded-2xl border border-[#161313]/5 hover:border-[#9F241F]/30 transition cursor-pointer space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <strong className="text-xs font-black text-[#161313] block break-words leading-snug">
                      {p.name}
                    </strong>
                    <span className="text-xs font-black text-[#9F241F] font-mono shrink-0">
                      {p.dustRiskScore ?? 75}đ
                    </span>
                  </div>

                  <div className="text-[11px] text-[#5C5550] break-words">
                    📍 {p.address}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-[#7E7771] pt-1 border-t border-[#161313]/5">
                    <span>📡 {p.sensorName || 'Chưa gắn trạm'}</span>
                    <span className="font-bold text-[#9F241F]">{p.openCasesCount ?? 0} hồ sơ mở</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Modal: Thêm công trình mới */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#161313]/60 flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
          <div 
            className="fixed inset-0 bg-transparent" 
            onClick={() => setCreateModalOpen(false)} 
            aria-hidden="true" 
          />
          <div className="relative w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl border border-[#161313]/10 p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92dvh] overflow-y-auto pb-safe z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#161313]/10">
              <h3 className="text-base font-bold text-[#161313]">Thêm công trình theo dõi</h3>
              <button 
                type="button" 
                onClick={() => setCreateModalOpen(false)} 
                className="text-[#7E7771] hover:text-[#161313] font-bold p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#161313] mb-1">Tên công trình *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Tòa nhà hỗn hợp Liễu Giai..."
                  value={newSite.name}
                  onChange={(e) => setNewSite(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Địa chỉ chi tiết *</label>
                <input
                  type="text"
                  required
                  placeholder="Số nhà, đường, phường..."
                  value={newSite.address}
                  onChange={(e) => setNewSite(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#161313] mb-1">Đơn vị thi công / Nhà thầu</label>
                <input
                  type="text"
                  placeholder="Tên nhà thầu xây dựng..."
                  value={newSite.contractorName}
                  onChange={(e) => setNewSite(prev => ({ ...prev, contractorName: e.target.value }))}
                  className="w-full px-3.5 py-2.5 border border-[#161313]/10 rounded-xl font-medium min-h-[44px]"
                />
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-[#161313]/10">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-[#161313]/15 font-bold text-[#5C5550] hover:bg-[#F7F6F3] min-h-[44px] cursor-pointer flex items-center justify-center"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2.5 rounded-xl bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black min-h-[44px] cursor-pointer flex items-center justify-center shadow-xs"
                >
                  {actionLoading ? 'Đang lưu...' : 'Lưu công trình'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
