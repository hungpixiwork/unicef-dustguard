import React, { useState, useEffect } from 'react';
import { request } from '../../../../lib/api/request.js';

export default function StaffSettingsPage() {
  const [settings, setSettings] = useState({
    emailAlerts: true,
    browserNotifications: true,
    urgentSms: false,
    autoRefresh: true,
    pm25Threshold: 50,
    pm10Threshold: 100,
    slaHours: 48,
    contactEmail: 'thanh-tra.moitruong@gov.vn'
  });
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadSettings() {
      try {
        setLoading(true);
        const res = await request('/staff/settings');
        if (res?.data) {
          setSettings(prev => ({ ...prev, ...res.data }));
        }
      } catch (err) {
        console.error('Error loading settings:', err);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  const handleToggle = async (key) => {
    const updated = { ...settings, [key]: !settings[key] };
    setSettings(updated);
    try {
      await request('/staff/settings', {
        method: 'PATCH',
        body: JSON.stringify({ [key]: updated[key] })
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      alert('Lỗi lưu cài đặt: ' + err.message);
    }
  };

  const handleThresholdSave = async (e) => {
    e.preventDefault();
    try {
      await request('/staff/settings', {
        method: 'PATCH',
        body: JSON.stringify({
          pm25Threshold: Number(settings.pm25Threshold),
          pm10Threshold: Number(settings.pm10Threshold),
          slaHours: Number(settings.slaHours),
          contactEmail: settings.contactEmail
        })
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      alert('Đã lưu ngưỡng cảnh báo thành công vào CSDL D1!');
    } catch (err) {
      alert('Lỗi lưu ngưỡng: ' + err.message);
    }
  };

  return (
    <div className="flex flex-col gap-6 max-w-3xl">
      {/* Header */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs flex justify-between items-center">
        <div>
          <h1 className="text-xl font-black text-[#1C1917] tracking-tight">Cài Đặt Ứng Dụng</h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Tùy chỉnh cấu hình thông báo, ngưỡng đo và thời hạn cam kết SLA.
          </p>
        </div>
        {saved && (
          <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold animate-fade-in">
            ✓ Đã lưu CSDL D1
          </span>
        )}
      </div>

      {/* Notification Preferences */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
        <h2 className="text-sm font-black text-[#1C1917] uppercase tracking-wider pb-2 border-b border-[#E7E5E4]">
          Kênh Nhận Thông Báo
        </h2>

        <div className="flex flex-col divide-y divide-[#E7E5E4]">
          <div className="py-3.5 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-[#1C1917]">Thông báo trên trình duyệt</div>
              <div className="text-[11px] text-[#57534E]">Hiển thị popup khi có vụ việc khẩn cấp hoặc tin nhắn mới</div>
            </div>
            <button
              onClick={() => handleToggle('browserNotifications')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                settings.browserNotifications ? 'bg-[#B91C1C]' : 'bg-[#E7E5E4]'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition ${
                settings.browserNotifications ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>

          <div className="py-3.5 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-[#1C1917]">Email tổng hợp định kỳ</div>
              <div className="text-[11px] text-[#57534E]">Nhận báo cáo tổng hợp danh sách công trình vượt ngưỡng mỗi sáng</div>
            </div>
            <button
              onClick={() => handleToggle('emailAlerts')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                settings.emailAlerts ? 'bg-[#B91C1C]' : 'bg-[#E7E5E4]'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition ${
                settings.emailAlerts ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>

          <div className="py-3.5 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-[#1C1917]">Tự động làm mới dữ liệu</div>
              <div className="text-[11px] text-[#57534E]">Cập nhật chỉ số quan trắc và trạng thái vụ việc mỗi 60 giây</div>
            </div>
            <button
              onClick={() => handleToggle('autoRefresh')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                settings.autoRefresh ? 'bg-[#B91C1C]' : 'bg-[#E7E5E4]'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition ${
                settings.autoRefresh ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>
        </div>
      </div>

      {/* Thresholds & SLA Settings */}
      <form onSubmit={handleThresholdSave} className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
        <h2 className="text-sm font-black text-[#1C1917] uppercase tracking-wider pb-2 border-b border-[#E7E5E4]">
          Ngưỡng Kỹ Thuật & SLA Quy Định
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-bold text-[#1C1917] mb-1">Ngưỡng PM2.5 Cảnh Báo (µg/m³)</label>
            <input
              type="number"
              value={settings.pm25Threshold}
              onChange={(e) => setSettings({ ...settings, pm25Threshold: e.target.value })}
              className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C]"
            />
            <span className="text-[10px] text-[#78716C] mt-1 block">QCVN 05:2023/BTNM trung bình 24h là 50 µg/m³</span>
          </div>

          <div>
            <label className="block font-bold text-[#1C1917] mb-1">Ngưỡng PM10 Cảnh Báo (µg/m³)</label>
            <input
              type="number"
              value={settings.pm10Threshold}
              onChange={(e) => setSettings({ ...settings, pm10Threshold: e.target.value })}
              className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C]"
            />
            <span className="text-[10px] text-[#78716C] mt-1 block">QCVN 05:2023/BTNM trung bình 24h là 100 µg/m³</span>
          </div>

          <div>
            <label className="block font-bold text-[#1C1917] mb-1">Thời hạn SLA Xử Lý (Giờ)</label>
            <input
              type="number"
              value={settings.slaHours}
              onChange={(e) => setSettings({ ...settings, slaHours: e.target.value })}
              className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C]"
            />
            <span className="text-[10px] text-[#78716C] mt-1 block">Mặc định 48 giờ đối với cảnh báo khẩn</span>
          </div>

          <div>
            <label className="block font-bold text-[#1C1917] mb-1">Email Tiếp Nhận Thông Báo</label>
            <input
              type="email"
              value={settings.contactEmail}
              onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
              className="w-full px-3 py-2 border border-[#E7E5E4] rounded-xl font-bold bg-white focus:outline-none focus:border-[#B91C1C]"
            />
            <span className="text-[10px] text-[#78716C] mt-1 block">Địa chỉ nhận báo cáo định kỳ buổi sáng</span>
          </div>
        </div>

        <div className="flex justify-end pt-3 border-t border-[#E7E5E4]">
          <button
            type="submit"
            className="px-4 py-2 bg-[#B91C1C] hover:bg-[#991B1B] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer transition"
          >
            Lưu cấu hình kỹ thuật
          </button>
        </div>
      </form>
    </div>
  );
}
