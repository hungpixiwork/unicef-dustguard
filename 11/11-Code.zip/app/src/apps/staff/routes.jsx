import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const StaffLayout = lazy(() => import('./layout/StaffLayout'));
const StaffTodayPage = lazy(() => import('./pages/today/StaffTodayPage'));
const StaffDashboardPage = lazy(() => import('./pages/dashboard/StaffDashboardPage'));
const SitesListPage = lazy(() => import('./pages/sites/SitesListPage'));
const SiteDetailPage = lazy(() => import('./pages/sites/SiteDetailPage'));
const CasesListPage = lazy(() => import('./pages/cases/CasesListPage'));
const CaseDetailPage = lazy(() => import('./pages/cases/CaseDetailPage'));
const TasksListPage = lazy(() => import('./pages/tasks/TasksListPage'));
const TaskDetailPage = lazy(() => import('./pages/tasks/TaskDetailPage'));
const FieldChecklistPage = lazy(() => import('./pages/tasks/FieldChecklistPage'));
const FieldEvidencePage = lazy(() => import('./pages/tasks/FieldEvidencePage'));
const FieldConclusionPage = lazy(() => import('./pages/tasks/FieldConclusionPage'));
const StaffReportsPage = lazy(() => import('./pages/reports/StaffReportsPage'));
const StaffMonitoringPage = lazy(() => import('./pages/monitoring/StaffMonitoringPage'));
const StaffAlertsPage = lazy(() => import('./pages/alerts/StaffAlertsPage'));

// Legal & Document Pages
const DocumentsListPage = lazy(() => import('../../modules/documents/DocumentsListPage'));
const TemplatesGalleryPage = lazy(() => import('../../modules/documents/TemplatesGalleryPage'));
const PolicyIntelligencePage = lazy(() => import('../../components/PolicyIntelligence/PolicyIntelligencePage'));

// User Account & Support Flows
const StaffProfilePage = lazy(() => import('./pages/profile/StaffProfilePage'));
const StaffNotificationsPage = lazy(() => import('./pages/notifications/StaffNotificationsPage'));
const StaffSettingsPage = lazy(() => import('./pages/settings/StaffSettingsPage'));
const StaffActivityPage = lazy(() => import('./pages/activity/StaffActivityPage'));
const StaffHelpPage = lazy(() => import('./pages/help/StaffHelpPage'));

export const staffRoutes = (
  <Route path="/staff" element={<StaffLayout />}>
    {/* 07. Hôm nay của tôi - Mobile-First Field Dashboard */}
    <Route index element={<StaffTodayPage />} />
    <Route path="today" element={<StaffTodayPage />} />
    <Route path="dashboard" element={<StaffDashboardPage />} />
    
    {/* 08. Danh sách nhiệm vụ */}
    <Route path="tasks" element={<TasksListPage />} />
    
    {/* 09. Chi tiết công trình kiểm tra */}
    <Route path="tasks/:id" element={<TaskDetailPage />} />
    
    {/* 10. Checklist hiện trường (thao tác 1 tay) */}
    <Route path="tasks/:id/checklist" element={<FieldChecklistPage />} />
    
    {/* 11. Ghi nhận bằng chứng (camera-first) */}
    <Route path="tasks/:id/evidence" element={<FieldEvidencePage />} />
    
    {/* 12. Kết luận kiểm tra & audit log */}
    <Route path="tasks/:id/conclusion" element={<FieldConclusionPage />} />
    
    {/* Sites */}
    <Route path="sites" element={<SitesListPage />} />
    <Route path="sites/:id" element={<SiteDetailPage />} />
    <Route path="sites/:id/:tab" element={<SiteDetailPage />} />
    
    {/* Cases */}
    <Route path="cases" element={<CasesListPage />} />
    <Route path="cases/:id" element={<CaseDetailPage />} />
    
    {/* Monitoring & Alerts */}
    <Route path="monitoring" element={<StaffMonitoringPage />} />
    <Route path="alerts" element={<StaffAlertsPage />} />

    {/* Reports */}
    <Route path="reports" element={<StaffReportsPage />} />

    {/* Documents & Templates & Policy */}
    <Route path="documents" element={<DocumentsListPage />} />
    <Route path="templates" element={<TemplatesGalleryPage />} />
    <Route path="policy" element={<PolicyIntelligencePage />} />

    {/* User Account & Support Pages */}
    <Route path="profile" element={<StaffProfilePage />} />
    <Route path="notifications" element={<StaffNotificationsPage />} />
    <Route path="settings" element={<StaffSettingsPage />} />
    <Route path="activity" element={<StaffActivityPage />} />
    <Route path="help" element={<StaffHelpPage />} />

    {/* Legacy redirect mappings */}
    <Route path="operations" element={<Navigate to="/staff" replace />} />
    <Route path="map" element={<Navigate to="/staff/sites" replace />} />
    <Route path="ai" element={<Navigate to="/staff/cases" replace />} />
    <Route path="complaints" element={<Navigate to="/staff/cases" replace />} />
    <Route path="inspections" element={<Navigate to="/staff/tasks" replace />} />
  </Route>
);
