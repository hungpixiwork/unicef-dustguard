import React, { useState, useRef, useEffect } from 'react';
import { NavLink, Outlet, useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { BrandLogo } from '../../../shared/components/BrandLogo';

export default function StaffLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const userMenuRef = useRef(null);

  // 5 Core Operational Navigation Items for Staff (< 6 items per Human-Centric SSOT)
  const navItems = [
    {
      to: '/staff',
      end: true,
      label: 'Việc hôm nay',
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
        </svg>
      )
    },
    {
      to: '/staff/sites',
      label: 'Công trình',
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="16" height="20" x="4" y="2" rx="2" ry="2" />
          <path d="M9 22v-4h6v4" />
          <path d="M8 6h.01" />
          <path d="M16 6h.01" />
          <path d="M12 6h.01" />
          <path d="M12 10h.01" />
          <path d="M12 14h.01" />
          <path d="M16 10h.01" />
          <path d="M16 14h.01" />
          <path d="M8 10h.01" />
          <path d="M8 14h.01" />
        </svg>
      )
    },
    {
      to: '/staff/cases',
      label: 'Hồ sơ xử lý',
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
        </svg>
      )
    },
    {
      to: '/staff/tasks',
      label: 'Việc hiện trường',
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
          <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
          <path d="m9 14 2 2 4-4" />
        </svg>
      )
    },
    {
      to: '/staff/alerts',
      label: 'Cảnh báo',
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
          <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
        </svg>
      )
    }
  ];

  // Secondary / Advanced Tools (Progressive Disclosure)
  const advancedTools = [
    { to: '/staff/monitoring', label: 'Quan trắc môi trường', icon: '📡' },
    { to: '/staff/reports', label: 'Báo cáo định kỳ', icon: '📊' },
    { to: '/staff/documents', label: 'Văn bản NĐ 30', icon: '📑' },
    { to: '/staff/policy', label: 'Tra cứu quy định', icon: '⚖️' },
  ];

  // Breadcrumb mapping
  const getBreadcrumb = () => {
    const path = location.pathname;
    if (path === '/staff') return 'Cán bộ / Việc hôm nay';
    if (path.startsWith('/staff/sites')) return 'Cán bộ / Công trình';
    if (path.startsWith('/staff/cases')) return 'Cán bộ / Hồ sơ xử lý';
    if (path.startsWith('/staff/tasks')) return 'Cán bộ / Việc hiện trường';
    if (path.startsWith('/staff/alerts')) return 'Cán bộ / Cảnh báo';
    if (path.startsWith('/staff/monitoring')) return 'Cán bộ / Quan trắc';
    if (path.startsWith('/staff/reports')) return 'Cán bộ / Báo cáo';
    if (path.startsWith('/staff/documents')) return 'Cán bộ / Văn bản NĐ 30';
    if (path.startsWith('/staff/policy')) return 'Cán bộ / Quy định';
    if (path.startsWith('/staff/settings')) return 'Cán bộ / Cài đặt';
    if (path.startsWith('/staff/notifications')) return 'Cán bộ / Thông báo';
    return 'Cán bộ / Tổng quan';
  };

  // Close user dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Lock body scroll and handle Escape for mobile drawer
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setMobileMenuOpen(false);
        setUserMenuOpen(false);
      }
    };

    if (mobileMenuOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  const displayName = user?.fullName || user?.full_name || user?.name || (user?.role === 'staff' ? 'Cán bộ Thanh tra' : 'Thanh tra Môi trường');
  const userRoleName = user?.role === 'staff' ? 'Cán bộ Thanh tra Môi trường' : user?.role === 'admin' ? 'Quản trị viên Hệ thống' : user?.role === 'executive' ? 'Lãnh đạo Cơ quan' : 'Cán bộ Vận hành';
  const userInitials = displayName.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'TT';

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/staff/sites?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-[#FAFAF9] text-[#1C1917] flex flex-col antialiased">
      {/* Top Header */}
      <header className="bg-white border-b border-[#E7E5E4] sticky top-0 z-30 h-16 flex items-center justify-between px-4 sm:px-6 shadow-2xs">
        
        {/* Left: Mobile hamburger & Breadcrumb */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg border border-[#E7E5E4] text-[#57534E] hover:bg-[#FEF2F2] hover:text-[#B91C1C] min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer font-bold text-xs"
            aria-label="Mở menu"
          >
            {mobileMenuOpen ? 'Đóng' : 'Menu'}
          </button>
          
          <div className="hidden sm:block text-xs font-semibold text-[#78716C]">
            {getBreadcrumb()}
          </div>
        </div>

        {/* Center: Search Bar */}
        <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md mx-4 hidden md:block">
          <div className="relative">
            <svg className="w-4 h-4 text-[#A8A29E] absolute left-3.5 top-1/2 -translate-y-1/2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm công trình, hồ sơ, cảnh báo..."
              className="w-full pl-9 pr-4 py-2 bg-[#FAFAF9] border border-[#E7E5E4] rounded-full text-xs text-[#1C1917] placeholder-[#A8A29E] focus:outline-none focus:border-[#B91C1C] focus:bg-white transition"
            />
          </div>
        </form>

        {/* Right User Account & Notification Hub */}
        <div className="flex items-center gap-3">
          {/* Notification Bell with Red Badge 8 */}
          <Link
            to="/staff/notifications"
            className="p-2 rounded-full text-[#57534E] hover:bg-[#FEF2F2] hover:text-[#B91C1C] relative min-h-[44px] min-w-[44px] flex items-center justify-center transition"
            title="Thông báo"
          >
            <svg className="w-5 h-5 text-[#57534E]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#B91C1C] text-white text-[9px] font-black flex items-center justify-center">
              8
            </span>
          </Link>

          {/* User Profile Dropdown Trigger */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2.5 p-1 sm:px-2.5 sm:py-1 rounded-full hover:bg-[#F5F5F4] transition min-h-[44px] cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-[#FEE2E2] text-[#B91C1C] flex items-center justify-center font-black text-xs shrink-0">
                {userInitials}
              </div>
              <span className="hidden sm:inline-block text-xs font-bold text-[#1C1917]">
                {displayName}
              </span>
              <svg className={`w-3.5 h-3.5 text-[#78716C] transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {/* Dropdown Menu */}
            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white border border-[#E7E5E4] rounded-2xl shadow-lg p-2 z-50 flex flex-col gap-1 animate-fade-in">
                <div className="px-3 py-2 border-b border-[#E7E5E4] mb-1">
                  <div className="font-bold text-xs text-[#1C1917] truncate">{displayName}</div>
                  <div className="text-[10px] text-[#0d6f64] font-bold mt-0.5">{userRoleName}</div>
                  <div className="text-[10px] text-[#57534E] truncate">{user?.email || 'staff@dustguard.vn'}</div>
                </div>

                <Link
                  to="/staff/profile"
                  onClick={() => setUserMenuOpen(false)}
                  className="px-3 py-2 text-xs font-bold text-[#44403C] hover:bg-[#FEF2F2] hover:text-[#991B1B] rounded-xl transition flex items-center gap-2.5 min-h-[44px]"
                >
                  <span>👤 Hồ sơ cá nhân</span>
                </Link>

                <Link
                  to="/staff/settings"
                  onClick={() => setUserMenuOpen(false)}
                  className="px-3 py-2 text-xs font-bold text-[#44403C] hover:bg-[#FEF2F2] hover:text-[#991B1B] rounded-xl transition flex items-center gap-2.5 min-h-[44px]"
                >
                  <span>⚙️ Cài đặt</span>
                </Link>

                <div className="border-t border-[#E7E5E4] my-1" />

                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    if (logout) logout();
                    navigate('/login');
                  }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-[#B91C1C] hover:bg-[#FEF2F2] rounded-xl transition flex items-center gap-2.5 min-h-[44px] cursor-pointer"
                >
                  <span>🚪 Đăng xuất</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar (Desktop: 230px) */}
        <aside className="hidden lg:flex w-60 bg-white border-r border-[#E7E5E4] flex-col p-4 gap-1 shrink-0 justify-between">
          
          <div className="flex flex-col gap-1">
            {/* Logo inside sidebar */}
            <div className="flex items-center gap-3 px-3 py-2 mb-4">
              <div className="w-8 h-8 rounded-xl bg-[#B91C1C] text-white flex items-center justify-center shrink-0 shadow-2xs">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
              </div>
              <div className="flex flex-col leading-tight">
                <span className="font-black text-sm text-[#1C1917] tracking-tight">DustGuard VN</span>
                <span className="text-[9px] font-extrabold uppercase tracking-wider text-[#78716C]">CHẤM ĐIỂM RỦI RO BỤI</span>
              </div>
            </div>

            {/* Nav links */}
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] ${
                    isActive
                      ? 'bg-[#FEF2F2] text-[#B91C1C] font-extrabold'
                      : 'text-[#57534E] hover:bg-[#FAFAF9] hover:text-[#1C1917]'
                  }`
                }
              >
                <span className="shrink-0">{item.icon}</span>
                <span>{item.label}</span>
              </NavLink>
            ))}

            {/* Advanced Tools (Collapsible / Secondary) */}
            <div className="mt-3 pt-3 border-t border-[#E7E5E4]">
              <details className="group">
                <summary className="flex items-center justify-between px-3 py-2 text-[11px] font-bold text-[#78716C] hover:text-[#1C1917] cursor-pointer rounded-lg hover:bg-[#F5F5F4] transition list-none min-h-[40px]">
                  <span className="flex items-center gap-1.5">
                    <span>⚙️</span>
                    <span>Công cụ nâng cao</span>
                  </span>
                  <svg className="w-3.5 h-3.5 transition-transform group-open:rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </summary>
                <div className="flex flex-col gap-1 mt-1 pl-2">
                  {advancedTools.map((tool) => (
                    <NavLink
                      key={tool.to}
                      to={tool.to}
                      className={({ isActive }) =>
                        `flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold transition min-h-[38px] ${
                          isActive
                            ? 'bg-[#FEF2F2] text-[#B91C1C] font-bold'
                            : 'text-[#78716C] hover:text-[#1C1917] hover:bg-[#FAFAF9]'
                        }`
                      }
                    >
                      <span className="text-sm">{tool.icon}</span>
                      <span>{tool.label}</span>
                    </NavLink>
                  ))}
                </div>
              </details>
            </div>
          </div>

          {/* Bottom Disclaimer Card */}
          <div className="p-3.5 rounded-2xl bg-[#FAFAF9] border border-[#E7E5E4] flex flex-col gap-1.5 mt-auto">
            <div className="flex items-center gap-2 text-[#B91C1C]">
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span className="text-[11px] font-black leading-snug">Điểm rủi ro chỉ hỗ trợ ưu tiên</span>
            </div>
            <p className="text-[10px] text-[#78716C] leading-relaxed">
              Không thay thế kết luận thanh tra, kiểm tra.
            </p>
            <Link to="/staff/help" className="text-[10px] font-bold text-[#B91C1C] hover:underline mt-0.5">
              Tìm hiểu thêm ➔
            </Link>
          </div>

        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div 
            className="lg:hidden fixed inset-0 z-50 bg-black/50 flex transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
            aria-modal="true"
            role="dialog"
          >
            <div 
              className="w-72 max-w-[85vw] bg-white h-full p-4 flex flex-col gap-2 shadow-2xl border-r border-[#E7E5E4] overflow-y-auto pb-safe"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-[#B91C1C] text-white flex items-center justify-center font-bold text-xs">
                    DG
                  </div>
                  <span className="font-extrabold text-sm text-[#1C1917]">DustGuard Cán bộ</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-[#57534E] hover:text-[#1C1917] min-h-[44px] min-w-[44px] flex items-center justify-center font-bold text-base cursor-pointer rounded-lg hover:bg-[#F5F5F4]"
                  aria-label="Đóng menu"
                >
                  ✕
                </button>
              </div>

              {/* Core Staff Nav */}
              <div className="flex flex-col gap-1 mt-2">
                <div className="px-2 text-[10px] font-black text-[#A8A29E] uppercase tracking-wider mb-1">
                  Nghiệp vụ chính
                </div>
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3.5 py-3 rounded-xl font-bold text-xs transition min-h-[44px] ${
                        isActive
                          ? 'bg-[#FEF2F2] text-[#B91C1C] font-extrabold shadow-xs'
                          : 'text-[#57534E] hover:bg-[#FAFAF9] hover:text-[#1C1917]'
                      }`
                    }
                  >
                    <span className="shrink-0">{item.icon}</span>
                    <span>{item.label}</span>
                  </NavLink>
                ))}
              </div>

              {/* Advanced Tools on Mobile */}
              <div className="flex flex-col gap-1 mt-3 pt-3 border-t border-[#E7E5E4]">
                <div className="px-2 text-[10px] font-black text-[#A8A29E] uppercase tracking-wider mb-1">
                  Công cụ nâng cao
                </div>
                {advancedTools.map((tool) => (
                  <NavLink
                    key={tool.to}
                    to={tool.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] ${
                        isActive
                          ? 'bg-[#FEF2F2] text-[#B91C1C]'
                          : 'text-[#78716C] hover:text-[#1C1917] hover:bg-[#FAFAF9]'
                      }`
                    }
                  >
                    <span className="text-sm">{tool.icon}</span>
                    <span>{tool.label}</span>
                  </NavLink>
                ))}
              </div>

              {/* Mobile User Profile & Logout */}
              <div className="mt-auto pt-4 border-t border-[#E7E5E4] flex flex-col gap-2">
                <div className="px-2 py-1">
                  <div className="font-bold text-xs text-[#1C1917] truncate">{displayName}</div>
                  <div className="text-[11px] text-[#0d6f64] font-bold">{userRoleName}</div>
                </div>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    if (logout) logout();
                    navigate('/login');
                  }}
                  className="w-full text-left px-3.5 py-2.5 text-xs font-bold text-[#B91C1C] bg-[#FEF2F2] hover:bg-[#FEE2E2] rounded-xl transition flex items-center gap-2 min-h-[44px] cursor-pointer"
                >
                  <span>🚪 Đăng xuất</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Workspace */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6 md:p-8 max-w-[1600px] w-full mx-auto pb-safe">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
