import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function ReportConfirmPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadReport() {
      if (!id) {
        setError('Không có mã phản ánh được cung cấp.');
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        setError(null);
        const res = await request(`/complaints/${id}`);
        const data = res?.data || res?.complaint || res;
        if (!data || (!data.id && !data.code)) {
          throw new Error('Không tìm thấy thông tin phản ánh tương ứng.');
        }
        setReport(data);
      } catch (err) {
        console.error('[Load Report Confirm Error]', err);
        setError(err.message || 'Không thể tải thông tin phản ánh từ hệ thống.');
      } finally {
        setLoading(false);
      }
    }
    loadReport();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-md mx-auto py-12">
        <LoadingState message="Đang tải xác nhận hồ sơ..." />
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="flex flex-col items-center justify-center max-w-lg mx-auto w-full p-6 my-auto gap-4 text-center">
        <div className="w-16 h-16 rounded-full bg-[#FEF2F2] text-[#9F241F] flex items-center justify-center text-2xl font-bold border border-[#FCA5A5]">
          ⚠️
        </div>
        <h2 className="text-xl font-black text-[#1C1917]">Không tìm thấy hồ sơ</h2>
        <p className="text-xs sm:text-sm text-[#57534E]">
          {error || 'Mã phản ánh không tồn tại trên hệ thống dữ liệu thực D1.'}
        </p>
        <div className="flex gap-3 mt-2">
          <Link
            to="/citizen/reports"
            className="py-2.5 px-4 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] text-xs font-bold rounded-xl border border-[#D6D3D1] min-h-[44px] flex items-center"
          >
            Hồ sơ của tôi
          </Link>
          <Link
            to="/citizen/report/new"
            className="py-2.5 px-4 bg-[#9F241F] hover:bg-[#7F1D1D] text-white text-xs font-bold rounded-xl min-h-[44px] flex items-center"
          >
            Tạo phản ánh mới
          </Link>
        </div>
      </div>
    );
  }

  const code = report?.code || report?.id || id || 'DG-2026-0842';
  const photo = report?.photoUrl || (report?.evidences && report.evidences[0]?.fileUrl) || 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=600';
  const address = report?.address || 'Khu vực công trình xây dựng';
  const timeStr = report?.createdAt ? new Date(report.createdAt).toLocaleString('vi-VN', {
    hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric'
  }) : 'Vừa xong';

  return (
    <div className="flex flex-col items-center justify-center max-w-lg mx-auto w-full p-4 sm:p-6 my-auto gap-5">
      {/* 1. Tick Thành công */}
      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#15803D] text-white flex items-center justify-center shadow-md shrink-0">
        <svg className="w-8 h-8 sm:w-10 sm:h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12" />
        </svg>
      </div>

      <div className="text-center space-y-1">
        <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64] bg-[#F0FDFA] px-3 py-1 rounded-full border border-[#CCFBF1]">
          Tiếp nhận thành công
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-[#1C1917] tracking-tight">
          Đã ghi nhận phản ánh!
        </h1>
        <div className="font-mono text-base font-extrabold text-[#9F241F]">
          #{code}
        </div>
      </div>

      {/* 2. Card Tóm tắt Hồ sơ */}
      <div className="w-full bg-white border border-[#E7E5E4] rounded-2xl overflow-hidden shadow-xs">
        {/* Ảnh đại diện hiện trường */}
        {photo && (
          <div className="w-full h-44 sm:h-48 bg-[#1C1917] relative overflow-hidden">
            <img 
              src={photo} 
              alt="Ảnh hiện trường phản ánh" 
              className="w-full h-full object-cover"
              onError={(e) => { e.target.src = 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=600'; }}
            />
            <div className="absolute bottom-2 left-2 bg-black/85 text-white text-[10px] font-bold px-2 py-0.5 rounded">
              Ảnh hiện trường nộp lên
            </div>
          </div>
        )}

        <div className="p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
            <span className="text-xs text-[#78716C] font-semibold">Trạng thái xử lý</span>
            <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-[#FEF2F2] text-[#9F241F] border border-[#FCA5A5]/40">
              Đã tiếp nhận
            </span>
          </div>

          <div className="text-xs space-y-1">
            <span className="text-[#78716C] font-semibold block">Vị trí ghi nhận:</span>
            <span className="font-bold text-[#1C1917] block leading-snug">📍 {address}</span>
          </div>

          <div className="text-xs space-y-1">
            <span className="text-[#78716C] font-semibold block">Thời gian gửi:</span>
            <span className="font-mono font-medium text-[#1C1917] block">🕒 {timeStr}</span>
          </div>

          {/* 3. Khối giải thích tiếp theo hệ thống sẽ làm gì */}
          <div className="p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] text-xs text-[#57534E] leading-relaxed space-y-1">
            <div className="font-bold text-[#1C1917] flex items-center gap-1.5">
              <span>ℹ️</span>
              <span>Quy trình tiếp theo:</span>
            </div>
            <p className="text-[11px] text-[#78716C] m-0">
              1. Hệ thống tự động đối soát tọa độ và nồng độ bụi quanh khu vực.
            </p>
            <p className="text-[11px] text-[#78716C] m-0">
              2. Điều phối viên tiếp nhận và gán cán bộ thanh tra địa bàn xử lý trong 2 giờ.
            </p>
            <p className="text-[11px] text-[#78716C] m-0">
              3. Nhà thầu liên quan sẽ nhận yêu cầu dập bụi và nộp ảnh khắc phục đối chứng.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Action Buttons */}
      <div className="flex flex-col w-full gap-2.5 pt-1">
        <button
          type="button"
          onClick={() => navigate(`/citizen/reports/${code}`)}
          className="w-full py-3.5 px-5 bg-[#9F241F] hover:bg-[#7F1D1D] active:bg-[#681717] text-white font-black text-sm rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>🔍</span>
          <span>Theo dõi hồ sơ</span>
        </button>

        <button
          type="button"
          onClick={() => navigate('/citizen')}
          className="w-full py-3 px-5 bg-white hover:bg-[#FAFAF9] text-[#1C1917] border border-[#E7E5E4] font-bold text-sm rounded-xl shadow-2xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Về trang chủ</span>
        </button>
      </div>
    </div>
  );
}
