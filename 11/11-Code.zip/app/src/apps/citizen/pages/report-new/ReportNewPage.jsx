import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { compressImage } from '../../../../lib/image-compressor.js';

export default function ReportNewPage() {
  const navigate = useNavigate();

  // Current Step: 1 = Chụp ảnh | 2 = Xác nhận vị trí | 3 = Mô tả vấn đề | 4 = Kiểm tra & gửi | 5 = Gửi thành công
  const [currentStep, setCurrentStep] = useState(1);

  // Form State
  const [images, setImages] = useState([]); // Array of { dataUrl, hash, file }
  const [locationAddress, setLocationAddress] = useState('Dịch Vọng Hậu, Cầu Giấy, Hà Nội');
  const [locationDesc, setLocationDesc] = useState('');
  const [lat, setLat] = useState(21.0313);
  const [lng, setLng] = useState(105.7831);
  const [gpsLoading, setGpsLoading] = useState(false);

  // Categories & Severities
  const categories = [
    { id: 'CONSTRUCTION_DUST', label: 'Bụi công trình', icon: '🏗️' },
    { id: 'ROAD_DUST', label: 'Bụi đường', icon: '🛣️' },
    { id: 'TRANSPORT_DUST', label: 'Xe chở vật liệu', icon: '🚚' },
    { id: 'BURNING_SMOKE', label: 'Đốt rác / Khói', icon: '🔥' },
    { id: 'OTHER', label: 'Khác', icon: '•••' }
  ];
  const [selectedCategory, setSelectedCategory] = useState('CONSTRUCTION_DUST');

  const severities = ['Nhẹ', 'Nhiều', 'Rất nhiều'];
  const [selectedSeverity, setSelectedSeverity] = useState('Nhiều');

  const [description, setDescription] = useState('');
  const [isCommitted, setIsCommitted] = useState(true);

  // Submission State
  const [submitting, setSubmitting] = useState(false);
  const [submittedCode, setSubmittedCode] = useState('DG-2026-0842');
  const [createdComplaintId, setCreatedComplaintId] = useState(null);

  // File input ref for camera & gallery
  const fileInputRef = useRef(null);

  // =========================================================================
  // Helper: Thêm ảnh từ File Input
  // =========================================================================
  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const remainingSlots = 3 - images.length;
    const toProcess = files.slice(0, remainingSlots);

    for (const file of toProcess) {
      try {
        const compressed = await compressImage(file, { maxSizeKB: 300, maxWidthOrHeight: 1280 });
        setImages((prev) => [
          ...prev,
          {
            dataUrl: compressed.dataUrl || compressed.base64,
            hash: compressed.hash || '',
            file
          }
        ]);
      } catch {
        // Fallback FileReader
        const reader = new FileReader();
        reader.onload = (event) => {
          setImages((prev) => [
            ...prev,
            {
              dataUrl: event.target.result,
              hash: '',
              file
            }
          ]);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  // Nút chụp ảnh mẫu giả lập hoặc chụp nhanh
  const handleSimulateCapture = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const removeImage = (index) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  // =========================================================================
  // Helper: Lấy vị trí GPS thật
  // =========================================================================
  const handleGetGPS = () => {
    if (!navigator?.geolocation) {
      alert('Trình duyệt của bạn không hỗ trợ định vị GPS.');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setLat(latitude);
        setLng(longitude);
        setLocationAddress(`Khu vực Cầu Giấy, Hà Nội (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`);
        setGpsLoading(false);
      },
      () => {
        setGpsLoading(false);
        alert('Không thể lấy vị trí tự động. Bạn vui lòng nhập tên đường / địa chỉ.');
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  // =========================================================================
  // Helper: Gửi phản ánh lên D1 API
  // =========================================================================
  const handleSubmitReport = async () => {
    if (!isCommitted) {
      alert('Vui lòng xác nhận thông tin phản ánh đúng hiện trường trước khi gửi.');
      return;
    }

    setSubmitting(true);
    try {
      const categoryObj = categories.find((c) => c.id === selectedCategory);
      const fullDesc = description.trim()
        ? `${categoryObj?.label || 'Phản ánh bụi'}: ${description.trim()}`
        : `${categoryObj?.label || 'Phát hiện ô nhiễm bụi'} tại ${locationAddress}`;

      // Upload images to R2 storage endpoint
      const uploadedUrls = [];
      for (const img of images) {
        if (img.dataUrl) {
          try {
            const uploadRes = await request('/upload', {
              method: 'POST',
              body: JSON.stringify({
                fileName: `evidence_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.jpg`,
                mimeType: 'image/jpeg',
                fileData: img.dataUrl,
                category: 'evidence'
              })
            });
            if (uploadRes?.data?.url) {
              uploadedUrls.push(uploadRes.data.url);
            } else {
              uploadedUrls.push(img.dataUrl);
            }
          } catch {
            uploadedUrls.push(img.dataUrl);
          }
        }
      }

      const payload = {
        ward: 'Phường Dịch Vọng Hậu',
        address: locationDesc ? `${locationAddress} (${locationDesc})` : locationAddress,
        description: fullDesc,
        category: selectedCategory,
        severity: selectedSeverity,
        latitude: lat,
        longitude: lng,
        evidenceUrl: uploadedUrls[0] || null,
        evidences: uploadedUrls
      };

      const res = await request('/complaints', {
        method: 'POST',
        body: JSON.stringify(payload)
      });

      const returnedCode = res?.data?.code || res?.complaint?.code || res?.code;
      const returnedId = res?.data?.id || res?.complaint?.id || res?.id || returnedCode;

      if (!returnedCode && !returnedId) {
        throw new Error(res?.message || 'Máy chủ không phản hồi mã phản ánh hợp lệ.');
      }

      setSubmittedCode(returnedCode || returnedId);
      setCreatedComplaintId(returnedId || returnedCode);
      setCurrentStep(5); // Chuyển sang Bước 5: Gửi thành công
    } catch (err) {
      console.error('[Submit Report Error]', err);
      alert(err.message || 'Không thể gửi phản ánh. Vui lòng kiểm tra lại kết nối và thử lại.');
    } finally {
      setSubmitting(false);
    }
  };

  // =========================================================================
  // RENDER THE 5 STEPS
  // =========================================================================
  return (
    <div className="max-w-xl mx-auto bg-white border border-[#E5E7EB] rounded-2xl shadow-xs overflow-hidden flex flex-col min-h-[580px]">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFileChange}
      />

      {/* ===================================================================== */}
      {/* BƯỚC 1: CHỤP ẢNH HIỆN TRƯỜNG (Mockup Mobile 2) */}
      {/* ===================================================================== */}
      {currentStep === 1 && (
        <div className="flex flex-col flex-1">
          {/* Top Bar */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#E5E7EB]">
            <button
              onClick={() => navigate('/citizen')}
              className="w-10 h-10 flex items-center justify-center text-[#4B5563] hover:text-[#111827] rounded-full min-h-[44px] min-w-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              title="Đóng"
              aria-label="Đóng giao diện chụp ảnh"
            >
              ✕
            </button>
            <h2 className="font-extrabold text-sm sm:text-base text-[#111827]">
              Chụp hiện trường
            </h2>
            <button
              onClick={() => alert('Đèn flash đã bật')}
              className="w-10 h-10 flex items-center justify-center text-[#4B5563] hover:text-[#15803d] rounded-full min-h-[44px] min-w-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              title="Đèn flash"
              aria-label="Bật đèn flash"
            >
              ⚡
            </button>
          </div>

          {/* Camera Viewfinder Area */}
          <div className="relative flex-1 bg-[#1F2937] min-h-[320px] sm:min-h-[380px] flex items-center justify-center overflow-hidden">
            {images.length > 0 ? (
              <img
                src={images[images.length - 1].dataUrl}
                alt="Ảnh hiện trường vừa chụp"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-center p-6 text-white/80 flex flex-col items-center gap-3">
                {/* Viewfinder crosshairs frame */}
                <div className="w-56 h-56 border-2 border-dashed border-white/60 rounded-xl relative flex items-center justify-center">
                  <div className="w-4 h-4 border-t-2 border-l-2 border-white absolute top-1 left-1"></div>
                  <div className="w-4 h-4 border-t-2 border-r-2 border-white absolute top-1 right-1"></div>
                  <div className="w-4 h-4 border-b-2 border-l-2 border-white absolute bottom-1 left-1"></div>
                  <div className="w-4 h-4 border-b-2 border-r-2 border-white absolute bottom-1 right-1"></div>
                  <svg className="w-10 h-10 text-white/40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="16" />
                    <line x1="8" y1="12" x2="16" y2="12" />
                  </svg>
                </div>
              </div>
            )}

            {/* Hint overlay */}
            <div className="absolute bottom-3 left-0 right-0 text-center">
              <span className="bg-black/60 text-white text-xs px-3 py-1.5 rounded-full font-medium shadow-xs">
                Chụp 1–3 ảnh để phản ánh rõ hơn ({images.length}/3)
              </span>
            </div>
          </div>

          {/* Thumbnails of captured photos */}
          {images.length > 0 && (
            <div className="flex items-center gap-2 px-4 py-2 bg-[#F9FAFB] border-t border-[#E5E7EB] overflow-x-auto">
              {images.map((img, idx) => (
                <div key={idx} className="relative w-14 h-14 rounded-lg overflow-hidden border border-[#D1D5DB] shrink-0">
                  <img src={img.dataUrl} alt={`Ảnh hiện trường ${idx + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removeImage(idx)}
                    aria-label={`Xóa ảnh hiện trường ${idx + 1}`}
                    className="absolute top-0 right-0 p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600 z-10"
                  >
                    <span className="w-6 h-6 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-xs">×</span>
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Bottom Controls */}
          <div className="p-4 bg-white border-t border-[#E5E7EB] flex items-center justify-around gap-4">
            {/* Gallery Picker Button */}
            <button
              type="button"
              onClick={handleSimulateCapture}
              className="w-12 h-12 rounded-xl border border-[#D1D5DB] bg-[#F9FAFB] hover:bg-[#F3F4F6] flex items-center justify-center text-[#4B5563] cursor-pointer min-h-[44px] min-w-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              title="Chọn ảnh từ thư viện"
              aria-label="Chọn ảnh từ thư viện"
            >
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <polyline points="21 15 16 10 5 21" />
              </svg>
            </button>

            {/* Giant Shutter Button */}
            <button
              type="button"
              onClick={handleSimulateCapture}
              className="w-16 h-16 rounded-full border-4 border-[#15803d] p-1 flex items-center justify-center shadow-md active:scale-95 transition cursor-pointer min-h-[44px] min-w-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              title="Bấm chụp ảnh"
              aria-label="Bấm chụp ảnh"
            >
              <div className="w-full h-full bg-[#15803d] rounded-full"></div>
            </button>

            {/* Next / Proceed Button (if at least 1 image or proceed directly) */}
            {images.length > 0 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="px-4 py-2.5 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-xs rounded-xl shadow-xs transition min-h-[44px] flex items-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              >
                Tiếp tục →
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setCurrentStep(2);
                }}
                className="px-3 py-2 text-xs font-bold text-[#6B7280] hover:text-[#111827] rounded-lg min-h-[44px] flex items-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              >
                Bỏ qua ảnh →
              </button>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BƯỚC 2: XÁC NHẬN VỊ TRÍ (Mockup Mobile 3) */}
      {/* ===================================================================== */}
      {currentStep === 2 && (
        <div className="flex flex-col flex-1">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#E5E7EB]">
            <button
              onClick={() => setCurrentStep(1)}
              className="font-extrabold text-sm text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer"
            >
              ‹ Quay lại
            </button>
            <h2 className="font-extrabold text-sm sm:text-base text-[#111827]">
              Xác nhận vị trí
            </h2>
            <button
              onClick={() => setCurrentStep(3)}
              className="font-extrabold text-sm text-[#15803d] hover:text-[#166534] min-h-[44px] flex items-center cursor-pointer"
            >
              Xong
            </button>
          </div>

          <div className="p-4 sm:p-5 flex flex-col gap-4 flex-1">
            {/* Search Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#9CA3AF]">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
              </div>
              <input
                id="search-location-input"
                type="text"
                value={locationAddress}
                onChange={(e) => setLocationAddress(e.target.value)}
                placeholder="Nhập địa chỉ hoặc tuyến đường..."
                aria-label="Nhập địa chỉ hoặc tuyến đường"
                className="w-full pl-9 pr-4 py-2.5 bg-[#F9FAFB] border border-[#D1D5DB] rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:border-[#15803d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d] min-h-[44px]"
              />
            </div>

            {/* Simulated Interactive Map */}
            <div className="relative w-full h-52 bg-[#E5E7EB] rounded-2xl overflow-hidden border border-[#D1D5DB] flex items-center justify-center">
              {/* Map grid */}
              <div className="absolute inset-0 bg-[#E8F5E9]/50 flex items-center justify-center">
                <svg className="w-full h-full opacity-25 text-[#15803d]" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="grid-map-2" width="25" height="25" patternUnits="userSpaceOnUse">
                      <path d="M 25 0 L 0 0 0 25" fill="none" stroke="currentColor" strokeWidth="1" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid-map-2)" />
                </svg>
              </div>

              {/* Red Pin in the Center */}
              <div className="relative z-10 flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg animate-bounce">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                  </svg>
                </div>
                <div className="w-3 h-1.5 bg-black/30 rounded-full mt-0.5"></div>
              </div>

              {/* Floating Pill: Dùng vị trí hiện tại */}
              <div className="absolute bottom-3 z-20">
                <button
                  type="button"
                  onClick={handleGetGPS}
                  disabled={gpsLoading}
                  aria-busy={gpsLoading}
                  className="px-4 py-2 bg-white text-[#15803d] border border-[#86EFAC] rounded-full text-xs font-bold shadow-md hover:bg-[#EBF7EE] transition flex items-center gap-1.5 min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
                >
                  <span aria-hidden="true">📍</span>
                  <span>{gpsLoading ? 'Đang lấy GPS…' : 'Dùng vị trí hiện tại'}</span>
                </button>
              </div>
            </div>

            {/* Selected Location Summary & Description */}
            <div className="flex flex-col gap-2 pt-1">
              <div>
                <span className="text-xs font-bold text-[#4B5563] block">Vị trí đã chọn</span>
                <span className="text-xs sm:text-sm font-extrabold text-[#111827] block">
                  {locationAddress}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <label htmlFor="location-desc-input" className="text-xs font-bold text-[#4B5563]">
                  Mô tả vị trí (tùy chọn)
                </label>
                <input
                  id="location-desc-input"
                  type="text"
                  maxLength={100}
                  value={locationDesc}
                  onChange={(e) => setLocationDesc(e.target.value)}
                  placeholder="Ví dụ: Đối diện cổng trường, gần ngã tư..."
                  className="w-full px-3.5 py-2.5 bg-[#F9FAFB] border border-[#D1D5DB] rounded-xl text-xs sm:text-sm focus:bg-white focus:border-[#15803d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d] min-h-[44px]"
                />
                <span className="text-[10px] text-[#4B5563] text-right">
                  {locationDesc.length}/100
                </span>
              </div>
            </div>

            {/* Next Button Bottom */}
            <div className="mt-auto pt-2">
              <button
                type="button"
                onClick={() => setCurrentStep(3)}
                className="w-full py-3 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              >
                Tiếp tục sang Mô tả vấn đề →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BƯỚC 3: MÔ TẢ VẤN ĐỀ (Mockup Mobile 4) */}
      {/* ===================================================================== */}
      {currentStep === 3 && (
        <div className="flex flex-col flex-1">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#E5E7EB]">
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="font-extrabold text-sm text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            >
              ‹ Quay lại
            </button>
            <h2 className="font-extrabold text-sm sm:text-base text-[#111827]">
              Mô tả vấn đề
            </h2>
            <button
              type="button"
              onClick={() => setCurrentStep(4)}
              className="font-extrabold text-sm text-[#15803d] hover:text-[#166534] min-h-[44px] flex items-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            >
              Tiếp tục
            </button>
          </div>

          <div className="p-4 sm:p-5 flex flex-col gap-4 flex-1">
            {/* Category selection */}
            <div>
              <span className="text-xs font-extrabold text-[#374151] uppercase tracking-wider block mb-2">
                Chọn loại phản ánh
              </span>
              <div role="radiogroup" aria-label="Chọn loại phản ánh" className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {categories.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      role="radio"
                      aria-checked={isSelected}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-center min-h-[72px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d] ${
                        isSelected
                          ? 'border-[#15803d] bg-[#EBF7EE] text-[#15803d] font-black shadow-2xs'
                          : 'border-[#D1D5DB] bg-[#F9FAFB] hover:bg-white text-[#4B5563]'
                      }`}
                    >
                      <span className="text-xl" aria-hidden="true">{cat.icon}</span>
                      <span className="text-[11px] leading-tight font-bold">{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Severity selection */}
            <div>
              <span className="text-xs font-extrabold text-[#374151] uppercase tracking-wider block mb-2">
                Mức độ
              </span>
              <div role="radiogroup" aria-label="Mức độ ô nhiễm" className="grid grid-cols-3 gap-2.5">
                {severities.map((sev) => {
                  const isSelected = selectedSeverity === sev;
                  return (
                    <button
                      key={sev}
                      type="button"
                      role="radio"
                      aria-checked={isSelected}
                      onClick={() => setSelectedSeverity(sev)}
                      className={`py-2.5 rounded-xl border text-xs sm:text-sm font-extrabold transition min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d] ${
                        isSelected
                          ? 'border-[#15803d] bg-[#EBF7EE] text-[#15803d] shadow-2xs'
                          : 'border-[#D1D5DB] bg-[#F9FAFB] hover:bg-white text-[#4B5563]'
                      }`}
                    >
                      {sev}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Description textarea */}
            <div className="flex flex-col gap-1">
              <label htmlFor="report-desc-input" className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
                Mô tả bổ sung (tùy chọn)
              </label>
              <textarea
                id="report-desc-input"
                rows={3}
                maxLength={250}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Nhập mô tả chi tiết hiện trường (ví dụ: Xe chở cát không phủ bạt làm rơi vãi...)"
                className="w-full p-3 bg-[#F9FAFB] border border-[#D1D5DB] rounded-xl text-xs sm:text-sm focus:bg-white focus:border-[#15803d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              />
              <span className="text-[10px] text-[#4B5563] text-right">
                {description.length}/250
              </span>
            </div>

            {/* Next Button Bottom */}
            <div className="mt-auto pt-2">
              <button
                onClick={() => setCurrentStep(4)}
                className="w-full py-3 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[44px] cursor-pointer"
              >
                Kiểm tra thông tin →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BƯỚC 4: KIỂM TRA & GỬI (Mockup Mobile 5) */}
      {/* ===================================================================== */}
      {currentStep === 4 && (
        <div className="flex flex-col flex-1">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#E5E7EB]">
            <button
              onClick={() => setCurrentStep(3)}
              className="font-extrabold text-sm text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer"
            >
              ‹ Quay lại
            </button>
            <h2 className="font-extrabold text-sm sm:text-base text-[#111827]">
              Kiểm tra thông tin
            </h2>
            <button
              onClick={handleSubmitReport}
              disabled={submitting || !isCommitted}
              className="font-extrabold text-sm text-[#15803d] hover:text-[#166534] disabled:text-[#9CA3AF] min-h-[44px] flex items-center cursor-pointer"
            >
              {submitting ? 'Đang gửi…' : 'Gửi'}
            </button>
          </div>

          <div className="p-4 sm:p-5 flex flex-col gap-4 flex-1">
            {/* Ảnh hiện trường Preview */}
            <div>
              <span className="text-xs font-bold text-[#6B7280] block mb-2">Ảnh hiện trường</span>
              {images.length > 0 ? (
                <div className="flex items-center gap-2 overflow-x-auto">
                  {images.map((img, idx) => (
                    <div key={idx} className="w-20 h-20 rounded-xl overflow-hidden border border-[#D1D5DB] shrink-0">
                      <img src={img.dataUrl} alt={`Ảnh ${idx + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-3 bg-[#F9FAFB] rounded-xl border border-dashed border-[#D1D5DB] text-xs text-[#6B7280] text-center">
                  Chưa đính kèm ảnh (Hệ thống tiếp nhận qua tọa độ & mô tả)
                </div>
              )}
            </div>

            {/* Thông tin tóm tắt */}
            <div className="bg-[#F9FAFB] border border-[#E5E7EB] rounded-xl p-4 flex flex-col gap-3 text-xs sm:text-sm">
              <div>
                <span className="font-bold text-[#6B7280] block text-[11px]">Vị trí</span>
                <span className="font-extrabold text-[#111827]">
                  {locationAddress} {locationDesc && `• ${locationDesc}`}
                </span>
              </div>

              <div>
                <span className="font-bold text-[#6B7280] block text-[11px]">Loại phản ánh</span>
                <span className="font-extrabold text-[#111827]">
                  {categories.find((c) => c.id === selectedCategory)?.label || 'Bụi công trình'}
                </span>
              </div>

              <div>
                <span className="font-bold text-[#6B7280] block text-[11px]">Mức độ</span>
                <span className="font-extrabold text-[#15803d]">
                  {selectedSeverity}
                </span>
              </div>

              <div>
                <span className="font-bold text-[#6B7280] block text-[11px]">Mô tả</span>
                <span className="text-[#374151]">
                  {description.trim() || 'Có nhiều bụi từ khu vực, ảnh hưởng đến sinh hoạt và giao thông.'}
                </span>
              </div>
            </div>

            {/* Citizen commitment checkbox */}
            <label className="flex items-start gap-2.5 p-3 rounded-xl border border-[#D1D5DB] hover:bg-[#F9FAFB] cursor-pointer transition select-none">
              <input
                type="checkbox"
                checked={isCommitted}
                onChange={(e) => setIsCommitted(e.target.checked)}
                className="mt-0.5 w-4 h-4 text-[#15803d] rounded border-gray-300 focus:ring-[#15803d] cursor-pointer"
              />
              <span className="text-xs text-[#374151] font-medium leading-snug">
                Thông tin tôi cung cấp phản ánh đúng hiện trường thực tế.
              </span>
            </label>

            {/* Submit CTA */}
            <div className="mt-auto pt-2">
              <button
                type="button"
                onClick={handleSubmitReport}
                disabled={submitting || !isCommitted}
                aria-busy={submitting}
                className="w-full py-3.5 bg-[#15803d] hover:bg-[#166534] active:bg-[#14532d] disabled:bg-[#9CA3AF] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              >
                {submitting ? 'Đang ghi nhận vào hệ thống…' : 'Gửi phản ánh'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* BƯỚC 5: GỬI THÀNH CÔNG (Mockup Mobile 6) */}
      {/* ===================================================================== */}
      {currentStep === 5 && (
        <div
          role="status"
          aria-live="polite"
          className="p-6 sm:p-8 flex flex-col items-center justify-center text-center gap-5 flex-1 my-auto"
        >
          {/* Big Green Success Checkmark */}
          <div className="w-20 h-20 rounded-full bg-[#15803d] text-white flex items-center justify-center shadow-md" aria-hidden="true">
            <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>

          <div className="flex flex-col gap-1">
            <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              Đã ghi nhận phản ánh!
            </h2>
            <span className="text-sm font-mono font-extrabold text-[#15803d]">
              #{submittedCode}
            </span>
          </div>

          {/* Status Box */}
          <div className="w-full max-w-sm bg-[#F9FAFB] border border-[#E5E7EB] rounded-2xl p-4 text-left flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#4B5563] font-medium">Trạng thái</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#EBF7EE] text-[#15803d]">
                Đã tiếp nhận
              </span>
            </div>
            <p className="text-xs text-[#4B5563] leading-relaxed pt-1">
              Hệ thống đang đánh giá và chuyển đơn vị xử lý phù hợp trên địa bàn.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col w-full max-w-sm gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => navigate(createdComplaintId ? `/citizen/reports/${createdComplaintId}` : '/citizen/reports')}
              className="w-full py-3 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            >
              Theo dõi
            </button>
            <button
              type="button"
              onClick={() => navigate('/citizen')}
              className="w-full py-3 bg-white hover:bg-[#F9FAFB] border border-[#D1D5DB] text-[#374151] font-bold text-sm rounded-xl transition min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            >
              Về trang chủ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
