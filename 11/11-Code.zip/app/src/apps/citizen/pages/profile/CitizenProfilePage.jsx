import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../../context/AuthContext';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { calculateVolunteerHours } from '../../../../lib/youth-credits.js';
import { CitizenProfile } from '../../../../modules/citizen/CitizenProfile.jsx';

export default function CitizenProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalHours: 0,
    verifiedHours: 0,
    resolvedReportsCount: 0,
    totalReportsCount: 0
  });

  useEffect(() => {
    async function loadUserStats() {
      try {
        const res = await request('/complaints').catch(() => ({ data: [] }));
        const list = normalizeList(res);
        const calc = calculateVolunteerHours(list);
        setStats(calc);
      } catch {
        // Safe default
      }
    }
    loadUserStats();
  }, []);

  const extracurricularCredits = Number((stats.verifiedHours / 5).toFixed(1));

  return (
    <div className="flex flex-col gap-6">
      {/* Environmental Contribution Card */}
      <div className="bg-white border border-[#E7E5E4] rounded-3xl p-6 sm:p-7 shadow-xs flex flex-col gap-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="font-black text-xs sm:text-sm text-[#1C1917] uppercase tracking-wider">
              Đóng Góp Bảo Vệ Môi Trường
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Kết quả phản ánh và ghi nhận công sức giám sát hiện trường
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <button
              onClick={() => navigate('/certificate')}
              className="text-xs sm:text-sm font-bold text-[#B91C1C] hover:underline cursor-pointer min-h-[44px] flex items-center gap-1"
            >
              📜 Nhận chứng nhận số (QR)
            </button>
            <span className="text-[#D6D3D1] hidden sm:inline">•</span>
            <button
              onClick={() => navigate('/youth')}
              className="text-xs sm:text-sm font-bold text-[#0d6f64] hover:underline cursor-pointer min-h-[44px] flex items-center gap-1"
            >
              🏆 Bảng thi đua & Tín chỉ →
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 bg-[#FAFAF9] rounded-2xl border border-[#E7E5E4] flex flex-col gap-1 text-center">
            <div className="text-3xl font-black text-[#1C1917]">{extracurricularCredits}</div>
            <div className="text-xs sm:text-sm font-bold text-[#57534E]">Tín chỉ ngoại khóa đề xuất</div>
            <div className="text-[11px] text-[#78716C] mt-1">Dành cho học sinh / sinh viên</div>
          </div>

          <div className="p-5 bg-[#FAFAF9] rounded-2xl border border-[#E7E5E4] flex flex-col gap-1 text-center">
            <div className="text-3xl font-black text-[#0d6f64]">{stats.resolvedReportsCount}</div>
            <div className="text-xs sm:text-sm font-bold text-[#57534E]">Phản ánh đã khắc phục</div>
            <div className="text-[11px] text-[#78716C] mt-1">Đã hoàn thành xử lý thực tế</div>
          </div>

          <div className="p-5 bg-[#FAFAF9] rounded-2xl border border-[#E7E5E4] flex flex-col gap-1 text-center">
            <div className="text-3xl font-black text-[#B91C1C]">{stats.verifiedHours}h</div>
            <div className="text-xs sm:text-sm font-bold text-[#57534E]">Giờ tình nguyện ghi nhận</div>
            <div className="text-[11px] text-[#78716C] mt-1">Quy đổi từ các đợt giám sát</div>
          </div>
        </div>
      </div>

      {/* Main Profile Settings and Identity Modes */}
      <CitizenProfile />
    </div>
  );
}
