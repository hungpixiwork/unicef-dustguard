import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';

export default function CitizenHomePage() {
  const navigate = useNavigate();
  const [recentReports, setRecentReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCount, setActiveCount] = useState(3);

  // Real GPS & Location State
  const [coords, setCoords] = useState({ lat: 21.0313, lng: 105.7831 });
  const [locationName, setLocationName] = useState('Dịch Vọng Hậu, Cầu Giấy, Hà Nội');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [hasRealGps, setHasRealGps] = useState(false);

  // Auto-fetch real GPS on mount if user previously permitted
  useEffect(() => {
    if (navigator?.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          setCoords({ lat: latitude, lng: longitude });
          setHasRealGps(true);
          setLocationName(`Tọa độ: ${latitude.toFixed(4)}°B, ${longitude.toFixed(4)}°Đ`);
        },
        () => {
          // Keep default Hanoi location
        },
        { timeout: 5000, maximumAge: 60000 }
      );
    }
  }, []);

  // Handler: Manual GPS refresh
  const handleRefreshGps = (e) => {
    e.stopPropagation();
    if (!navigator?.geolocation) {
      alert('Trình duyệt không hỗ trợ định vị GPS.');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setCoords({ lat: latitude, lng: longitude });
        setHasRealGps(true);
        setLocationName(`Vị trí GPS: ${latitude.toFixed(4)}°B, ${longitude.toFixed(4)}°Đ`);
        setGpsLoading(false);
      },
      () => {
        setGpsLoading(false);
        alert('Không thể lấy vị trí GPS tự động. Vui lòng bật cấp quyền vị trí trên thiết bị.');
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  // Handler: Open Google Maps in new tab
  const handleOpenGoogleMaps = (e) => {
    e.stopPropagation();
    const gmapUrl = `https://www.google.com/maps/search/?api=1&query=${coords.lat},${coords.lng}`;
    window.open(gmapUrl, '_blank', 'noopener,noreferrer');
  };

  useEffect(() => {
    async function loadData() {
      try {
        const res = await request('/complaints?limit=10').catch(() => ({ data: [] }));
        const list = normalizeList(res);
        setRecentReports(list);

        const inProgressList = list.filter((r) => {
          const s = (r.status || '').toUpperCase();
          return !['RESOLVED', 'CLOSED', 'COMPLETED', 'SANCTION_ISSUED', 'DONE'].includes(s);
        });
        if (inProgressList.length > 0) {
          setActiveCount(inProgressList.length);
        }
      } catch {
        setRecentReports([]);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Helper: Format card title without ugly letter truncation
  const formatReportTitle = (report) => {
    const raw = (report.description || report.title || 'Phát hiện ô nhiễm bụi').trim();
    if (raw.includes(':')) {
      const parts = raw.split(':');
      const cat = parts[0].trim();
      const rest = parts.slice(1).join(':').trim();
      return { category: cat, detail: rest };
    }
    return { category: 'Phản ánh môi trường', detail: raw };
  };

  return (
    <div className="flex flex-col gap-5 max-w-2xl mx-auto w-full">
      {/* 0. Header Chào mừng */}
      <div className="flex flex-col gap-1">
        <h1 className="text-xl sm:text-2xl font-black text-[#1C1917]">
          Xin chào! 👋
        </h1>
        <p className="text-xs sm:text-sm text-[#57534E]">
          Cùng chung tay vì bầu không khí trong lành
        </p>
      </div>

      {/* 0.1 Thẻ AQI & Khu vực của bạn */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Thẻ AQI 38 Tốt */}
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#EBF7EE] text-[#15803D] flex items-center justify-center text-2xl shrink-0">
              😊
            </div>
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-[#15803D]">38</span>
                <span className="text-xs font-bold text-[#78716C]">AQI</span>
              </div>
              <span className="text-xs font-black text-[#15803D]">Chất lượng không khí: Tốt</span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#78716C] bg-[#FAFAF9] px-2 py-1 rounded-md border border-[#E7E5E4]">
            Hà Nội
          </span>
        </div>

        {/* Thẻ Bản đồ khu vực của bạn */}
        <div
          onClick={handleOpenGoogleMaps}
          className="bg-white border border-[#E7E5E4] hover:border-[#0D6F64] rounded-2xl p-4 shadow-2xs flex items-center justify-between cursor-pointer transition select-none"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#F0FDFA] text-[#0D6F64] border border-[#CCFBF1] flex items-center justify-center shrink-0">
              📍
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-black text-[#1C1917] truncate">Khu vực của bạn</span>
              <span className="text-[11px] text-[#78716C] truncate">{locationName}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleRefreshGps}
            title="Cập nhật GPS"
            className="text-xs text-[#0D6F64] font-bold p-1 hover:bg-[#F0FDFA] rounded min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            {gpsLoading ? '…' : '🔄'}
          </button>
        </div>
      </div>

      {/* 1. Hero Banner: Phát hiện bụi? Gửi phản ánh trong 1 phút */}
      <div className="bg-gradient-to-br from-white to-[#FDFBF7] border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-black uppercase tracking-wider text-[#9F241F] bg-[#FEF2F2] px-2.5 py-1 rounded-md w-fit border border-[#FCA5A5]/30">
            Giám sát bụi công trình
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-[#1C1917] tracking-tight leading-snug">
            Phát hiện bụi? Gửi phản ánh trong 1 phút
          </h2>
          <p className="text-xs sm:text-sm text-[#57534E] leading-relaxed">
            Chụp ảnh vị trí ô nhiễm, gửi bằng chứng số để cơ quan chức năng tiếp nhận và buộc nhà thầu dập bụi ngay.
          </p>
        </div>

        {/* Nút chính Dominant CTA: + Phản ánh mới */}
        <button
          type="button"
          onClick={() => navigate('/citizen/report/new')}
          className="w-full py-4 px-6 bg-[#9F241F] hover:bg-[#7F1D1D] active:bg-[#681717] text-white font-black text-base rounded-xl shadow-xs transition-all min-h-[52px] flex items-center justify-center gap-2 cursor-pointer select-none"
        >
          <span className="text-xl leading-none font-bold">+</span>
          <span>Phản ánh mới</span>
        </button>
      </div>

      {/* 2. Ba bước quy trình xử lý minh bạch */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 sm:p-5 shadow-2xs">
        <h2 className="text-xs font-black text-[#57534E] uppercase tracking-wider mb-3">
          Quy trình 3 bước xử lý phản ánh
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#9F241F] text-white text-xs font-black flex items-center justify-center shrink-0">1</span>
              <span className="font-bold text-xs text-[#1C1917]">Gửi hiện trường</span>
            </div>
            <p className="text-[11px] text-[#78716C] pl-8 leading-snug">
              Chụp ảnh và gửi tọa độ ô nhiễm trong 1 phút.
            </p>
          </div>

          <div className="p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#0D6F64] text-white text-xs font-black flex items-center justify-center shrink-0">2</span>
              <span className="font-bold text-xs text-[#1C1917]">Cơ quan tiếp nhận</span>
            </div>
            <p className="text-[11px] text-[#78716C] pl-8 leading-snug">
              Cán bộ thẩm định và yêu cầu nhà thầu dập bụi.
            </p>
          </div>

          <div className="p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#15803D] text-white text-xs font-black flex items-center justify-center shrink-0">3</span>
              <span className="font-bold text-xs text-[#1C1917]">Theo dõi xử lý</span>
            </div>
            <p className="text-[11px] text-[#78716C] pl-8 leading-snug">
              Xem ảnh Before/After đối chứng sau khắc phục.
            </p>
          </div>
        </div>
      </div>

      {/* 3. Khối Hồ Sơ Của Tôi */}
      <div
        onClick={() => navigate('/citizen/reports')}
        title="Xem chi tiết hồ sơ của tôi"
        className="bg-white border border-[#E7E5E4] hover:border-[#0D6F64] rounded-2xl p-4 sm:p-5 shadow-2xs flex items-center justify-between gap-3 cursor-pointer transition select-none"
      >
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="w-10 h-10 rounded-xl bg-[#F0FDFA] text-[#0D6F64] border border-[#CCFBF1] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="1" y="3" width="15" height="13" />
              <polygon points="16 8 20 8 23 11 23 16 16 16 8" />
              <circle cx="5.5" cy="18.5" r="2.5" />
              <circle cx="18.5" cy="18.5" r="2.5" />
            </svg>
          </div>
          <div className="flex flex-col min-w-0 flex-1">
            <span className="text-xs text-[#78716C] font-semibold">Hồ sơ của tôi</span>
            <span className="text-sm sm:text-base font-black text-[#1C1917] leading-tight break-words">
              {activeCount} phản ánh đang xử lý
            </span>
          </div>
        </div>

        <div className="text-xs font-bold text-[#0D6F64] bg-[#F0FDFA] px-2.5 sm:px-3 py-1.5 rounded-xl border border-[#CCFBF1] shrink-0 flex items-center gap-1 min-h-[44px]">
          <span>Xem chi tiết</span>
          <span>›</span>
        </div>
      </div>

      {/* 5. Danh Sách Phản Ánh Gần Đây Trên Địa Bàn (Hiển thị trọn nghĩa, không cắt ngang chữ) */}
      <div className="bg-white border border-[#E5E7EB] rounded-2xl p-4 sm:p-5 shadow-2xs flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
            Phản ánh mới trên địa bàn
          </h2>
          <button
            onClick={() => navigate('/citizen/reports')}
            className="text-xs font-bold text-[#15803d] hover:underline cursor-pointer min-h-[44px] flex items-center"
          >
            Xem tất cả →
          </button>
        </div>

        {loading ? (
          <div className="py-6 text-center text-xs text-[#6B7280]">Đang tải dữ liệu từ địa bàn…</div>
        ) : recentReports.length === 0 ? (
          <div className="py-6 text-center text-xs text-[#6B7280]">Chưa có phản ánh nào ghi nhận hôm nay.</div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {recentReports.slice(0, 4).map((r) => {
              const statusMap = {
                PENDING: { label: 'Mới gửi', bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
                IN_PROGRESS: { label: 'Đang xử lý', bg: 'bg-[#FFEDD5]', text: 'text-[#EA580C]' },
                PROCESSING: { label: 'Đang xử lý', bg: 'bg-[#FFEDD5]', text: 'text-[#EA580C]' },
                VERIFIED: { label: 'Đã xác minh', bg: 'bg-[#E0F2FE]', text: 'text-[#0284C7]' },
                RESOLVED: { label: 'Đã xong', bg: 'bg-[#EBF7EE]', text: 'text-[#15803d]' }
              };
              const s = (r.status || 'PENDING').toUpperCase();
              const badge = statusMap[s] || statusMap.PENDING;
              const { category, detail } = formatReportTitle(r);

              return (
                <div
                  key={r.id || r.code}
                  onClick={() => navigate(`/citizen/reports/${r.code || r.id}`)}
                  className="p-3.5 border border-[#E5E7EB] hover:border-[#86EFAC] rounded-xl flex items-center justify-between gap-3 cursor-pointer transition bg-[#F9FAFB] hover:bg-white min-h-[52px]"
                >
                  <div className="flex flex-col min-w-0 flex-1 gap-0.5">
                    <span className="text-xs font-black text-[#111827] line-clamp-1 leading-snug break-words">
                      {category}
                    </span>
                    <p className="text-[11px] text-[#4B5563] line-clamp-2 leading-snug break-words">
                      {detail}
                    </p>
                    <span className="text-[10px] text-[#9CA3AF] line-clamp-1 truncate pt-0.5">
                      📍 {r.address || 'Hà Nội'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`px-2.5 py-1 rounded-md text-[11px] font-black whitespace-nowrap ${badge.bg} ${badge.text}`}>
                      {badge.label}
                    </span>
                    <span className="text-[#9CA3AF] text-sm font-bold">›</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
