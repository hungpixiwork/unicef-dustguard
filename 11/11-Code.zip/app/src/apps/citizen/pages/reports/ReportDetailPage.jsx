import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { request, normalizeObject } from '../../../../lib/api/request.js';
import { compressImage } from '../../../../lib/image-compressor.js';

export default function ReportDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Sub-view: 'DETAIL' (Màn 3) | 'RESULT' (Màn 4: Kết quả xử lý) | 'EVALUATE' (Màn 5: Đánh giá kết quả)
  const [viewMode, setViewMode] = useState('DETAIL');

  // Evaluation Form State (Màn 5)
  // 'SATISFIED' (Đã cải thiện) | 'PARTIAL' (Chưa hoàn toàn) | 'UNSATISFIED' (Chưa xử lý)
  const [evalRating, setEvalRating] = useState('SATISFIED');
  const [evalNote, setEvalNote] = useState('');
  const [evalImage, setEvalImage] = useState(null);
  const [evalSubmitting, setEvalSubmitting] = useState(false);
  const [evalSuccessMsg, setEvalSuccessMsg] = useState(null);

  const evalFileInputRef = useRef(null);

  const loadReport = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request(`/complaints/${encodeURIComponent(id)}`).catch(() => null);
      const raw = normalizeObject(res);
      const data = raw?.complaint || raw?.item || (raw?.id ? raw : null);
      if (!data) throw new Error('Không tìm thấy thông tin phản ánh.');
      setReport(data);

      // If already resolved and user rated, can default view
    } catch (err) {
      setError(err.message || 'Không thể tải thông tin phản ánh');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) loadReport();
  }, [id]);

  // Handle image upload for evaluation
  const handleEvalImageChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file, { maxSizeKB: 300, maxWidthOrHeight: 1280 });
      setEvalImage(compressed.dataUrl || compressed.base64);
    } catch {
      const reader = new FileReader();
      reader.onload = (ev) => setEvalImage(ev.target.result);
      reader.readAsDataURL(file);
    }
  };

  // Submit Citizen Evaluation (Màn 5 -> D1 API)
  const handleSendEvaluation = async () => {
    setEvalSubmitting(true);
    setEvalSuccessMsg(null);
    try {
      const isSatisfied = evalRating === 'SATISFIED';
      const feedbackMap = {
        SATISFIED: 'Hiện trường đã được cải thiện tốt',
        PARTIAL: 'Hiện trường chưa được cải thiện hoàn toàn',
        UNSATISFIED: 'Hiện trường chưa được xử lý'
      };
      const fullFeedback = evalNote.trim()
        ? `${feedbackMap[evalRating]} - Ghi chú: ${evalNote.trim()}`
        : feedbackMap[evalRating];

      await request(`/complaints/${encodeURIComponent(report.id || id)}/verify`, {
        method: 'POST',
        body: JSON.stringify({
          isSatisfied,
          feedback: fullFeedback,
          rating: evalRating,
          evidenceUrl: evalImage || undefined
        })
      });

      setEvalSuccessMsg(
        isSatisfied
          ? 'Cảm ơn bạn! Đánh giá hài lòng đã được ghi nhận vào hồ sơ hoàn tất.'
          : 'Đã tiếp nhận đánh giá! Yêu cầu phúc tra đã được gửi tới tổ công tác địa bàn.'
      );
      loadReport();
    } catch (err) {
      alert(`Không thể gửi đánh giá: ${err.message}`);
    } finally {
      setEvalSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="py-16 text-center text-xs text-[#6B7280] bg-white rounded-2xl border border-[#E5E7EB]">
        Đang tải thông tin phản ánh…
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="p-6 text-center text-xs bg-white rounded-2xl border border-[#E5E7EB] flex flex-col items-center gap-3">
        <p className="text-red-600 font-bold">{error || 'Không tìm thấy phản ánh.'}</p>
        <button
          onClick={() => navigate('/citizen/reports')}
          className="px-4 py-2 bg-[#15803d] text-white rounded-xl text-xs font-bold"
        >
          Quay lại danh sách
        </button>
      </div>
    );
  }

  const code = report.code || report.id || 'DG-2026-0842';
  const rawStatus = (report.status || 'PENDING').toUpperCase();
  const isResolved = ['RESOLVED', 'CLOSED', 'COMPLETED', 'SANCTION_ISSUED', 'DONE'].includes(rawStatus);

  // Status mapping
  const statusBadge = isResolved
    ? { label: 'Đã xử lý', bg: 'bg-[#EBF7EE]', text: 'text-[#15803d]', border: 'border-[#BBF7D0]' }
    : ['VERIFIED', 'ON_SITE'].includes(rawStatus)
    ? { label: 'Đã xác minh', bg: 'bg-[#E0F2FE]', text: 'text-[#0284C7]', border: 'border-[#BAE6FD]' }
    : { label: 'Đang xử lý', bg: 'bg-[#FFEDD5]', text: 'text-[#EA580C]', border: 'border-[#FED7AA]' };

  // Format date
  const timeStr = (() => {
    try {
      const d = new Date(report.createdAt || Date.now());
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      return `${day}/${month}/${year} • ${hours}:${minutes}`;
    } catch {
      return '02/06/2024 • 10:15';
    }
  })();

  // Evidences
  const rawEvidences = Array.isArray(report.evidences) ? report.evidences : [];
  const beforePhotos = [
    report.evidenceUrl,
    report.evidence_url,
    ...rawEvidences.map((e) => (typeof e === 'string' ? e : e?.url || e?.fileUrl))
  ].filter(Boolean);

  const afterPhotos = [
    report.resolvedEvidenceUrl,
    report.resolved_evidence_url,
    report.afterEvidenceUrl,
    ...(Array.isArray(report.resolvedEvidences)
      ? report.resolvedEvidences.map((e) => (typeof e === 'string' ? e : e?.url || e?.fileUrl))
      : [])
  ].filter(Boolean);

  // 6 Steps Vertical Stepper for Màn 3
  const timelineSteps = [
    { title: 'Đã tiếp nhận', time: timeStr, active: true },
    { title: 'Đã xác minh', time: '02/06/2024 • 11:30', active: ['VERIFIED', 'IN_PROGRESS', 'RESOLVED', 'DONE'].includes(rawStatus) },
    { title: 'Đã chuyển đơn vị xử lý', time: '02/06/2024 • 14:30', active: ['IN_PROGRESS', 'RESOLVED', 'DONE'].includes(rawStatus) },
    { title: 'Đang xử lý', time: '03/06/2024 • 09:00', active: ['IN_PROGRESS', 'RESOLVED', 'DONE'].includes(rawStatus) },
    { title: 'Tái kiểm', time: '', active: isResolved },
    { title: 'Hoàn tất', time: '', active: isResolved }
  ];

  return (
    <div className="max-w-2xl mx-auto flex flex-col gap-4">
      {/* Hidden input for evaluation photo */}
      <input
        ref={evalFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleEvalImageChange}
      />

      {/* ===================================================================== */}
      {/* MÀN HÌNH 3: CHI TIẾT PHẢN ÁNH (Mockup Laptop 3) */}
      {/* ===================================================================== */}
      {viewMode === 'DETAIL' && (
        <div className="bg-white border border-[#E5E7EB] rounded-2xl p-4 sm:p-6 shadow-xs flex flex-col gap-5">
          {/* Top Bar with Back Button */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/citizen/reports')}
              className="text-xs sm:text-sm font-bold text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer"
            >
              ← Quay lại
            </button>
            <span className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${statusBadge.bg} ${statusBadge.text} ${statusBadge.border}`}>
              {statusBadge.label}
            </span>
          </div>

          {/* Title & Info */}
          <div className="flex flex-col gap-1">
            <h1 className="text-lg sm:text-xl font-black text-[#111827] tracking-tight">
              Chi tiết phản ánh <span className="font-mono text-base font-extrabold text-[#15803d]">#{code}</span>
            </h1>
            <div className="text-xs sm:text-sm text-[#111827] font-extrabold pt-1">
              {report.description ? report.description.split(':')[0] : 'Bụi công trình'}
            </div>
            <div className="text-xs text-[#4B5563]">
              {report.address || 'Dịch Vọng Hậu, Cầu Giấy, Hà Nội'}
            </div>
            <div className="text-[11px] text-[#6B7280]">
              {timeStr}
            </div>
          </div>

          {/* Evidence Photos Row (Thumbnails with +2 overlay) */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
              Ảnh hiện trường
            </span>
            <div className="flex items-center gap-3 overflow-x-auto pb-1">
              {beforePhotos.length > 0 ? (
                beforePhotos.slice(0, 3).map((photo, idx) => (
                  <div key={idx} className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden border border-[#D1D5DB] shrink-0 bg-[#F3F4F6]">
                    <img src={photo} alt={`Hiện trường ${idx + 1}`} className="w-full h-full object-cover" />
                    {idx === 2 && beforePhotos.length > 3 && (
                      <div className="absolute inset-0 bg-black/60 text-white flex items-center justify-center font-extrabold text-sm">
                        +{beforePhotos.length - 3}
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <div className="w-full p-4 bg-[#F9FAFB] rounded-xl border border-dashed border-[#D1D5DB] text-xs text-[#6B7280] text-center">
                  Ảnh hiện trường đang được cán bộ kiểm tra đối chứng tại chỗ.
                </div>
              )}
            </div>
          </div>

          {/* Vertical Stepper Timeline: Tiến trình xử lý */}
          <div className="flex flex-col gap-3 pt-2">
            <h2 className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
              Tiến trình xử lý
            </h2>

            <div className="flex flex-col relative pl-6 border-l-2 border-[#E5E7EB] ml-3 gap-6 my-2">
              {timelineSteps.map((step, idx) => (
                <div key={idx} className="relative flex flex-col gap-0.5">
                  {/* Step Bullet Icon */}
                  <div
                    className={`absolute -left-[31px] top-0.5 w-4 h-4 rounded-full flex items-center justify-center border-2 ${
                      step.active
                        ? 'bg-[#15803d] border-[#15803d] text-white'
                        : 'bg-white border-[#D1D5DB]'
                    }`}
                  >
                    {step.active && (
                      <svg className="w-2.5 h-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className={`text-xs sm:text-sm font-extrabold ${step.active ? 'text-[#111827]' : 'text-[#6B7280]'}`}>
                      {step.title}
                    </span>
                    {step.time && (
                      <span className="text-[11px] text-[#6B7280] font-mono">
                        {step.time}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Switch to Result / Evaluation View */}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => setViewMode('RESULT')}
              className="w-full py-3.5 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-xs transition min-h-[44px] flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Xem kết quả xử lý & Đánh giá</span>
              <span>→</span>
            </button>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MÀN HÌNH 4: KẾT QUẢ XỬ LÝ (Mockup Laptop 4) */}
      {/* ===================================================================== */}
      {viewMode === 'RESULT' && (
        <div className="bg-white border border-[#E5E7EB] rounded-2xl p-4 sm:p-6 shadow-xs flex flex-col gap-5">
          {/* Top Bar with Back Button */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setViewMode('DETAIL')}
              className="text-xs sm:text-sm font-bold text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer"
            >
              ← Quay lại
            </button>
            <span className="px-2.5 py-1 rounded-lg text-xs font-extrabold bg-[#EBF7EE] text-[#15803d] border border-[#BBF7D0]">
              Đã xử lý
            </span>
          </div>

          {/* Header Info */}
          <div className="flex flex-col gap-1">
            <h1 className="text-lg sm:text-xl font-black text-[#111827] tracking-tight">
              Kết quả xử lý <span className="font-mono text-base font-extrabold text-[#15803d]">#{code}</span>
            </h1>
            <div className="text-xs sm:text-sm text-[#111827] font-extrabold">
              {report.description ? report.description.split(':')[0] : 'Bụi công trình'}
            </div>
            <div className="text-xs text-[#4B5563]">
              {report.address || 'Dịch Vọng Hậu, Cầu Giấy, Hà Nội'} • {timeStr}
            </div>
          </div>

          {/* Before & After Photo Comparison */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Trước xử lý */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-extrabold text-[#6B7280]">Trước xử lý</span>
              <div className="w-full h-44 rounded-xl overflow-hidden border border-[#D1D5DB] bg-[#F3F4F6] relative">
                {beforePhotos[0] ? (
                  <img src={beforePhotos[0]} alt="Trước xử lý" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-[#6B7280]">
                    Ảnh ban đầu
                  </div>
                )}
                <span className="absolute bottom-2 left-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded font-bold">
                  Bụi mù mịt
                </span>
              </div>
            </div>

            {/* Sau xử lý */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-extrabold text-[#15803d]">Sau xử lý</span>
              <div className="w-full h-44 rounded-xl overflow-hidden border border-[#86EFAC] bg-[#F0FDF4] relative">
                {afterPhotos[0] || beforePhotos[0] ? (
                  <img src={afterPhotos[0] || beforePhotos[0]} alt="Sau xử lý" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-[#15803d]">
                    Ảnh đã khắc phục
                  </div>
                )}
                <span className="absolute bottom-2 left-2 bg-[#15803d] text-white text-[10px] px-2 py-0.5 rounded font-bold">
                  Đã dọn rửa
                </span>
              </div>
            </div>
          </div>

          {/* Thông tin xử lý Card */}
          <div className="bg-[#F9FAFB] border border-[#E5E7EB] rounded-xl p-4 flex flex-col gap-2.5 text-xs sm:text-sm">
            <h2 className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
              Thông tin xử lý
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <span className="text-[11px] font-bold text-[#6B7280] block">Thời gian xử lý</span>
                <span className="font-extrabold text-[#111827]">02/06/2024 – 04/06/2024</span>
              </div>
              <div>
                <span className="text-[11px] font-bold text-[#6B7280] block">Chỉ số bụi PM2.5 (trước → sau)</span>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-red-600">95 µg/m³</span>
                  <span>→</span>
                  <span className="font-extrabold text-[#15803d]">25 µg/m³</span>
                </div>
              </div>
            </div>

            <div>
              <span className="text-[11px] font-bold text-[#6B7280] block">Giải pháp khắc phục</span>
              <span className="font-medium text-[#111827]">
                Đã phun nước giảm bụi, quét dọn bùn đất và phủ bạt che chắn toàn bộ khu vực thi công.
              </span>
            </div>
          </div>

          {/* Next Button: Xác nhận kết quả */}
          <div className="pt-2">
            <button
              onClick={() => setViewMode('EVALUATE')}
              className="w-full py-3.5 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center cursor-pointer"
            >
              Xác nhận kết quả
            </button>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MÀN HÌNH 5: XÁC NHẬN & ĐÁNH GIÁ (Mockup Laptop 5) */}
      {/* ===================================================================== */}
      {viewMode === 'EVALUATE' && (
        <div className="bg-white border border-[#E5E7EB] rounded-2xl p-4 sm:p-6 shadow-xs flex flex-col gap-5">
          {/* Top Bar with Back Button */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setViewMode('RESULT')}
              className="text-xs sm:text-sm font-bold text-[#4B5563] hover:text-[#111827] min-h-[44px] flex items-center gap-1 cursor-pointer"
            >
              ← Quay lại
            </button>
            <span className="font-mono text-xs font-bold text-[#6B7280]">
              #{code}
            </span>
          </div>

          {/* Title */}
          <div>
            <h1 className="text-lg sm:text-xl font-black text-[#111827] tracking-tight">
              Đánh giá kết quả
            </h1>
            <p className="text-xs sm:text-sm text-[#4B5563] mt-1 font-bold">
              Hiện trường đã được cải thiện chưa?
            </p>
          </div>

          {/* 3 Selectable Reaction Cards: Đã cải thiện | Chưa hoàn toàn | Chưa xử lý */}
          <div role="radiogroup" aria-label="Đánh giá hiện trạng cải thiện" className="grid grid-cols-3 gap-3">
            {/* Card 1: Đã cải thiện 😊 */}
            <button
              type="button"
              role="radio"
              aria-checked={evalRating === 'SATISFIED'}
              onClick={() => setEvalRating('SATISFIED')}
              className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition cursor-pointer text-center min-h-[88px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d] ${
                evalRating === 'SATISFIED'
                  ? 'border-[#15803d] bg-[#EBF7EE] text-[#15803d] shadow-xs'
                  : 'border-[#D1D5DB] bg-[#F9FAFB] hover:bg-white text-[#4B5563]'
              }`}
            >
              <span className="text-2xl" aria-hidden="true">😊</span>
              <span className="text-xs font-extrabold leading-tight">Đã cải thiện</span>
            </button>

            {/* Card 2: Chưa hoàn toàn 😐 */}
            <button
              type="button"
              role="radio"
              aria-checked={evalRating === 'PARTIAL'}
              onClick={() => setEvalRating('PARTIAL')}
              className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition cursor-pointer text-center min-h-[88px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-600 ${
                evalRating === 'PARTIAL'
                  ? 'border-amber-500 bg-amber-50 text-amber-700 shadow-xs'
                  : 'border-[#D1D5DB] bg-[#F9FAFB] hover:bg-white text-[#4B5563]'
              }`}
            >
              <span className="text-2xl" aria-hidden="true">😐</span>
              <span className="text-xs font-extrabold leading-tight">Chưa hoàn toàn</span>
            </button>

            {/* Card 3: Chưa xử lý ☹️ */}
            <button
              type="button"
              role="radio"
              aria-checked={evalRating === 'UNSATISFIED'}
              onClick={() => setEvalRating('UNSATISFIED')}
              className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition cursor-pointer text-center min-h-[88px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600 ${
                evalRating === 'UNSATISFIED'
                  ? 'border-red-500 bg-red-50 text-red-700 shadow-xs'
                  : 'border-[#D1D5DB] bg-[#F9FAFB] hover:bg-white text-[#4B5563]'
              }`}
            >
              <span className="text-2xl" aria-hidden="true">☹️</span>
              <span className="text-xs font-extrabold leading-tight">Chưa xử lý</span>
            </button>
          </div>

          {/* Ghi chú thêm (tùy chọn) */}
          <div className="flex flex-col gap-1">
            <label htmlFor="eval-note-textarea" className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
              Ghi chú thêm (tùy chọn)
            </label>
            <textarea
              id="eval-note-textarea"
              rows={3}
              maxLength={200}
              value={evalNote}
              onChange={(e) => setEvalNote(e.target.value)}
              placeholder="Nhập ghi chú của bạn..."
              className="w-full p-3 bg-[#F9FAFB] border border-[#D1D5DB] rounded-xl text-xs sm:text-sm focus:bg-white focus:border-[#15803d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            />
            <span className="text-[10px] text-[#4B5563] text-right">
              {evalNote.length}/200
            </span>
          </div>

          {/* Chụp ảnh hiện trạng (nếu có) */}
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-extrabold text-[#374151] uppercase tracking-wider">
              Chụp ảnh hiện trạng (nếu có)
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => evalFileInputRef.current?.click()}
                aria-label="Chụp hoặc tải ảnh hiện trạng đánh giá"
                className="w-20 h-20 rounded-xl border-2 border-dashed border-[#D1D5DB] bg-[#F9FAFB] hover:bg-[#F3F4F6] flex flex-col items-center justify-center text-[#4B5563] cursor-pointer min-h-[44px] shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
              >
                <span className="text-lg leading-none" aria-hidden="true">+</span>
                <span className="text-xs" aria-hidden="true">📷</span>
              </button>

              {evalImage && (
                <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-[#D1D5DB] shrink-0">
                  <img src={evalImage} alt="Ảnh hiện trạng đánh giá" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setEvalImage(null)}
                    aria-label="Xóa ảnh đánh giá"
                    className="absolute top-0 right-0 p-1 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600 z-10"
                  >
                    <span className="w-6 h-6 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-xs">×</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Success message banner */}
          {evalSuccessMsg && (
            <div
              role="status"
              aria-live="polite"
              className="p-3 bg-[#EBF7EE] border border-[#BBF7D0] rounded-xl text-xs text-[#15803d] font-bold"
            >
              ✓ {evalSuccessMsg}
            </div>
          )}

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="button"
              onClick={handleSendEvaluation}
              disabled={evalSubmitting}
              aria-busy={evalSubmitting}
              className="w-full py-3.5 bg-[#15803d] hover:bg-[#166534] active:bg-[#14532d] disabled:bg-[#9CA3AF] text-white font-extrabold text-sm rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
            >
              {evalSubmitting ? 'Đang gửi đánh giá…' : 'Gửi đánh giá'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
