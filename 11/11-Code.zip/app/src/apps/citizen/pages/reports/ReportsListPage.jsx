import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { ErrorState, LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function ReportsListPage() {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('ALL'); // 'ALL' | 'IN_PROGRESS' | 'DONE'

  const loadReports = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request('/complaints');
      const items = normalizeList(res);
      setReports(items);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách phản ánh');
      setReports([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  const safeReports = Array.isArray(reports) ? reports : [];

  // Filter according to the 3 tabs in mockup: Tất cả | Đang xử lý | Đã xong
  const filtered = safeReports.filter((r) => {
    const s = (r.status || '').toUpperCase();
    const isDone = ['RESOLVED', 'CLOSED', 'COMPLETED', 'SANCTION_ISSUED', 'DONE'].includes(s);

    if (activeTab === 'DONE') return isDone;
    if (activeTab === 'IN_PROGRESS') return !isDone;
    return true; // 'ALL'
  });

  const tabs = [
    { key: 'ALL', label: 'Tất cả' },
    { key: 'IN_PROGRESS', label: 'Đang xử lý' },
    { key: 'DONE', label: 'Đã xong' }
  ];

  // Helper format date: DD/MM/YYYY • HH:mm
  const formatDateTime = (dateStr) => {
    if (!dateStr) return '02/06/2024 • 10:15';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return '02/06/2024 • 10:15';
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      return `${day}/${month}/${year} • ${hours}:${minutes}`;
    } catch {
      return '02/06/2024 • 10:15';
    }
  };

  // Helper format badge status
  const getStatusBadge = (status) => {
    const s = (status || 'PENDING').toUpperCase();
    if (['RESOLVED', 'CLOSED', 'COMPLETED', 'SANCTION_ISSUED', 'DONE'].includes(s)) {
      return {
        label: 'Đã xong',
        className: 'bg-[#EBF7EE] text-[#15803d] border border-[#BBF7D0]'
      };
    }
    if (['VERIFIED', 'ON_SITE', 'APPRAISING'].includes(s)) {
      return {
        label: 'Đã xác minh',
        className: 'bg-[#E0F2FE] text-[#0284C7] border border-[#BAE6FD]'
      };
    }
    return {
      label: 'Đang xử lý',
      className: 'bg-[#FFEDD5] text-[#EA580C] border border-[#FED7AA]'
    };
  };

  // Helper extract short title & location without ugly truncation
  const parseCardTitle = (item) => {
    const categoryMap = {
      CONSTRUCTION_DUST: 'Bụi công trình',
      ROAD_DUST: 'Bụi đường',
      TRANSPORT_DUST: 'Xe chở vật liệu',
      BURNING_SMOKE: 'Đốt rác / Khói',
      OTHER: 'Ô nhiễm bụi'
    };

    let baseCategory = categoryMap[item.category];
    if (!baseCategory) {
      const raw = (item.description || item.title || 'Bụi công trình').trim();
      const firstPart = raw.split(':')[0].split('•')[0].split('-')[0].trim();
      baseCategory = firstPart.length > 28 ? firstPart.slice(0, 26).replace(/\s+\S*$/, '') + '…' : firstPart;
    }

    const ward = item.ward ? item.ward.replace(/^Phường\s+/i, '').replace(/^Xã\s+/i, '') : '';
    const addrFirst = item.address ? item.address.split(',')[0].trim() : '';
    const locationTag = ward || addrFirst || 'Địa bàn';

    return `${baseCategory || 'Bụi công trình'} • ${locationTag}`;
  };

  if (loading) return <LoadingState message="Đang tải danh sách phản ánh..." />;
  if (error) return <ErrorState message={error} onRetry={loadReports} retryLabel="Thử lại" />;

  return (
    <div className="flex flex-col gap-4 max-w-2xl mx-auto">
      {/* 1. Header Tiêu Đề "Hồ sơ của tôi" */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
          Hồ sơ của tôi
        </h1>
        <button
          onClick={() => navigate('/citizen/report/new')}
          className="px-3.5 py-2 bg-[#15803d] hover:bg-[#166534] text-white font-extrabold text-xs rounded-xl transition min-h-[44px] flex items-center gap-1.5 cursor-pointer"
        >
          <span>+</span>
          <span>Báo bụi mới</span>
        </button>
      </div>

      {/* 2. Bộ Lọc Tabs Chuẩn Theo Mockup: Tất cả | Đang xử lý | Đã xong */}
      <div className="flex items-center border-b border-[#E5E7EB] gap-6" role="tablist">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              role="tab"
              aria-selected={isActive}
              onClick={() => setActiveTab(tab.key)}
              className={`pb-3 text-xs sm:text-sm font-extrabold transition-all min-h-[44px] relative cursor-pointer ${
                isActive
                  ? 'text-[#15803d]'
                  : 'text-[#6B7280] hover:text-[#111827]'
              }`}
            >
              <span>{tab.label}</span>
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#15803d] rounded-full"></div>
              )}
            </button>
          );
        })}
      </div>

      {/* 3. Danh Sách Card Hồ Sơ */}
      {loading ? (
        <div className="py-12 text-center text-xs text-[#6B7280] bg-white rounded-2xl border border-[#E5E7EB]">
          Đang tải danh sách hồ sơ…
        </div>
      ) : error ? (
        <div className="p-6 text-center text-xs text-red-600 bg-red-50 rounded-2xl border border-red-200">
          <p className="font-bold">{error}</p>
          <button
            onClick={loadReports}
            className="mt-3 px-4 py-2 bg-white border border-red-300 text-red-700 rounded-xl text-xs font-bold"
          >
            Thử lại
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-12 px-4 text-center text-xs text-[#6B7280] bg-white rounded-2xl border border-[#E5E7EB] flex flex-col items-center gap-3">
          <p className="font-medium text-[#4B5563]">
            {activeTab === 'DONE'
              ? 'Chưa có phản ánh nào đã hoàn thành.'
              : activeTab === 'IN_PROGRESS'
              ? 'Không có phản ánh nào đang xử lý.'
              : 'Bạn chưa có phản ánh môi trường nào.'}
          </p>
          <button
            onClick={() => navigate('/citizen/report/new')}
            className="px-4 py-2 bg-[#15803d] text-white rounded-xl font-bold text-xs"
          >
            Gửi phản ánh ngay
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((item) => {
            const idOrCode = item.code || item.id;
            const badge = getStatusBadge(item.status);
            const title = parseCardTitle(item);
            const timeStr = formatDateTime(item.createdAt);

            // Evidence image thumbnail or default placeholder
            const photoUrl =
              item.evidenceUrl ||
              item.evidence_url ||
              (Array.isArray(item.evidences) && (item.evidences[0]?.url || item.evidences[0]?.fileUrl || item.evidences[0])) ||
              null;

            return (
              <div
                key={idOrCode}
                role="button"
                tabIndex={0}
                onClick={() => navigate(`/citizen/reports/${idOrCode}`)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    navigate(`/citizen/reports/${idOrCode}`);
                  }
                }}
                className="bg-white border border-[#E5E7EB] hover:border-[#86EFAC] rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center justify-between gap-3 sm:gap-4 transition cursor-pointer hover:shadow-xs focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803d]"
                aria-label={`Xem chi tiết phản ánh ${title}`}
              >
                {/* Thumbnail bên trái */}
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#F3F4F6] border border-[#E5E7EB] overflow-hidden shrink-0 flex items-center justify-center">
                  {photoUrl ? (
                    <img
                      src={photoUrl}
                      alt="Ảnh hiện trường"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.style.display = 'none';
                      }}
                    />
                  ) : (
                    <span className="text-xl">🏗️</span>
                  )}
                </div>

                {/* Thông tin ở giữa */}
                <div className="flex flex-col min-w-0 flex-1 gap-1">
                  <h3 className="text-xs sm:text-sm font-black text-[#111827] truncate">
                    {title}
                  </h3>
                  <span className="text-[11px] text-[#6B7280]">
                    {timeStr}
                  </span>
                </div>

                {/* Badge trạng thái & Chevron bên phải */}
                <div className="flex items-center gap-2.5 shrink-0">
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${badge.className}`}>
                    {badge.label}
                  </span>
                  <span className="text-[#9CA3AF] text-base font-bold select-none">
                    ›
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
