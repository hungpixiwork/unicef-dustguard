import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const CitizenLayout = lazy(() => import('./layout/CitizenLayout'));
const CitizenHomePage = lazy(() => import('./pages/home/CitizenHomePage'));
const ReportNewPage = lazy(() => import('./pages/report-new/ReportNewPage'));
const ReportConfirmPage = lazy(() => import('./pages/report-new/ReportConfirmPage'));
const ReportsListPage = lazy(() => import('./pages/reports/ReportsListPage'));
const ReportDetailPage = lazy(() => import('./pages/reports/ReportDetailPage'));
const CitizenProfilePage = lazy(() => import('./pages/profile/CitizenProfilePage'));

export const citizenRoutes = (
  <Route path="/citizen" element={<CitizenLayout />}>
    <Route index element={<CitizenHomePage />} />
    <Route path="dashboard" element={<Navigate to="/citizen" replace />} />
    
    {/* Report New & Confirmation */}
    <Route path="report/new" element={<ReportNewPage />} />
    <Route path="report/confirm/:id" element={<ReportConfirmPage />} />
    <Route path="report/success" element={<ReportConfirmPage />} />
    <Route path="report" element={<Navigate to="/citizen/report/new" replace />} />
    
    {/* Reports List & Detail */}
    <Route path="reports" element={<ReportsListPage />} />
    <Route path="reports/:id" element={<ReportDetailPage />} />
    <Route path="track" element={<Navigate to="/citizen/reports" replace />} />
    <Route path="track/:id" element={<Navigate to="/citizen/reports" replace />} />
    
    {/* Profile */}
    <Route path="profile" element={<CitizenProfilePage />} />

    {/* Legacy community redirect mappings */}
    <Route path="nearby" element={<Navigate to="/citizen" replace />} />
    <Route path="map" element={<Navigate to="/map" replace />} />
    <Route path="missions" element={<Navigate to="/citizen/reports" replace />} />
    <Route path="credits" element={<Navigate to="/citizen/profile" replace />} />
    <Route path="campaigns" element={<Navigate to="/citizen" replace />} />
  </Route>
);
