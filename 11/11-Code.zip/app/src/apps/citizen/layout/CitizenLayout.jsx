import React from 'react';
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { BrandLogo } from '../../../shared/components/BrandLogo';

export default function CitizenLayout() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // 4 Core Navigation Items exactly matching the mockup
  const navItems = [
    {
      to: '/citizen',
      end: true,
      label: 'Trang chủ',
      mobileLabel: 'Trang chủ',
      icon: (
        <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      )
    },
    {
      to: '/citizen/report/new',
      label: 'Phản ánh mới',
      mobileLabel: 'Phản ánh',
      icon: (
        <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
        </svg>
      )
    },
    {
      to: '/citizen/reports',
      label: 'Hồ sơ của tôi',
      mobileLabel: 'Hồ sơ',
      icon: (
        <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <line x1="16" y1="13" x2="8" y2="13" />
          <line x1="16" y1="17" x2="8" y2="17" />
          <polyline points="10 9 9 9 8 9" />
        </svg>
      )
    },
    {
      to: '/citizen/profile',
      label: 'Cá nhân',
      mobileLabel: 'Cá nhân',
      icon: (
        <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
          <circle cx="12" cy="7" r="4" />
        </svg>
      )
    }
  ];

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-[#F9FAFB] text-[#111827] flex flex-col md:flex-row antialiased">
      {/* ========================================================================= */}
      {/* 1. DESKTOP / LAPTOP SIDEBAR (md:flex) — Sát chuẩn Mockup Laptop */}
      {/* ========================================================================= */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-[#E5E7EB] shrink-0 sticky top-0 h-screen z-30 p-5 justify-between select-none">
        <div className="flex flex-col gap-6">
          {/* Brand Logo with Green Civic Accent */}
          <div className="flex items-center gap-2.5 px-2">
            <div className="w-8 h-8 rounded-full bg-[#15803d] flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-xs">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              </svg>
            </div>
            <span className="font-extrabold text-lg text-[#111827] tracking-tight">DustGuard</span>
          </div>

          {/* Nav items list */}
          <nav className="flex flex-col gap-1.5" aria-label="Menu người dân">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-bold transition-all min-h-[44px] cursor-pointer ${
                    isActive
                      ? 'bg-[#EBF7EE] text-[#15803d] font-black'
                      : 'text-[#4B5563] hover:bg-[#F3F4F6] hover:text-[#111827]'
                  }`
                }
              >
                {item.icon}
                <span>{item.label}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Bottom Support Hotline in Sidebar */}
        <div className="pt-4 border-t border-[#E5E7EB]">
          <div className="flex items-center gap-3 px-3 py-2 text-xs text-[#4B5563]">
            <svg className="w-4 h-4 text-[#15803d] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
            </svg>
            <div>
              <div className="font-medium text-[11px] text-[#6B7280]">Hỗ trợ</div>
              <a href="tel:18001234" className="font-extrabold text-xs text-[#111827] hover:text-[#15803d]">1800 1234</a>
            </div>
          </div>
        </div>
      </aside>

      {/* ========================================================================= */}
      {/* 2. MOBILE TOPBAR (md:hidden) — Sát chuẩn Mockup Mobile 1. Trang chủ */}
      {/* ========================================================================= */}
      <header className="md:hidden bg-white border-b border-[#E5E7EB] sticky top-0 z-30 h-14 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-[#15803d] flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-xs">
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          </div>
          <span className="font-extrabold text-base text-[#111827] tracking-tight">DustGuard</span>
        </div>

        {/* Bell Notification Icon */}
        <button
          onClick={() => navigate('/citizen/reports')}
          aria-label="Thông báo phản ánh"
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#4B5563] hover:bg-[#F3F4F6] transition cursor-pointer min-h-[44px] min-w-[44px]"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
        </button>
      </header>

      {/* ========================================================================= */}
      {/* 3. MAIN CONTENT CONTAINER — Responsive chuẩn */}
      {/* ========================================================================= */}
      <main className="flex-1 flex flex-col min-w-0 pb-28 md:pb-8">
        <div className="w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 flex-1">
          <Outlet />
        </div>
      </main>

      {/* ========================================================================= */}
      {/* 4. MOBILE BOTTOM NAVIGATION (md:hidden) — Sát chuẩn Mockup Mobile 4 Tabs */}
      {/* ========================================================================= */}
      <nav aria-label="Điều hướng di động" className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#E5E7EB] flex items-center justify-around min-h-[64px] pb-safe shadow-md px-1 select-none">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 h-full min-h-[44px] py-1 transition cursor-pointer ${
                isActive
                  ? 'text-[#15803d] font-black'
                  : 'text-[#6B7280] font-semibold hover:text-[#111827]'
              }`
            }
          >
            <div className="p-1 rounded-lg">
              {item.icon}
            </div>
            <span className="text-[11px] leading-tight mt-0.5">{item.mobileLabel}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
