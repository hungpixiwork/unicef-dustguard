import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function CommunityMapPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [sites, setSites] = useState([]);
  const [selectedPoint, setSelectedPoint] = useState(null);

  useEffect(() => {
    async function loadObservationPoints() {
      try {
        setLoading(true);
        const res = await request('/sites').catch(() => []);
        const list = normalizeList(res);
        // Map to public-friendly observation points (no sensitive internal logs)
        const mapped = list.map((s, idx) => ({
          id: s.id,
          name: s.name,
          area: s.address?.split(',').slice(-2).join(', ').trim() || 'Hà Nội',
          lat: s.latitude || 21.03 + (idx * 0.005),
          lng: s.longitude || 105.78 + (idx * 0.004),
          priority: idx % 3 === 0 ? 'HIGH' : idx % 3 === 1 ? 'MEDIUM' : 'NORMAL',
          activeMission: idx % 2 === 0 ? 'Quan sát xe vận chuyển sau 17:00' : 'Ghi nhận hiện trạng che bạt bãi vật liệu',
          participantsCount: (idx + 1) * 3
        }));
        setSites(mapped);
        if (mapped.length > 0) setSelectedPoint(mapped[0]);
      } catch {
        setSites([]);
      } finally {
        setLoading(false);
      }
    }
    loadObservationPoints();
  }, []);

  if (loading) return <LoadingState message="Đang nạp bản đồ các điểm quan sát…" />;

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-16">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Bản Đồ Môi Trường Mở
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Điểm Quan Sát Cộng Đồng
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Màu sắc biểu thị mức độ ưu tiên quan sát. Mọi thông tin tuân thủ quy tắc bảo mật thông tin cộng đồng.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/community/observe')}
          className="px-4 py-2.5 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px] flex items-center gap-1.5 cursor-pointer"
        >
          <span>📷</span>
          <span>Gửi quan sát mới</span>
        </button>
      </div>

      {/* Main Grid: Map (8 cols) + Detail Panel (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Map Container */}
        <div className="lg:col-span-8 bg-white border border-[#E7E5E4] rounded-2xl overflow-hidden shadow-xs relative min-h-[450px] flex flex-col">
          {/* Real OpenStreetMap Tile Embed */}
          <iframe
            title="Bản đồ điểm quan sát cộng đồng"
            src={`https://www.openstreetmap.org/export/embed.html?bbox=105.75%2C21.01%2C105.85%2C21.07&layer=mapnik`}
            className="w-full h-full min-h-[450px] border-0"
            loading="lazy"
          />

          {/* Map Overlay Header */}
          <div className="absolute top-3 left-3 bg-white border border-[#E7E5E4] rounded-xl p-2.5 shadow-md text-xs flex items-center gap-3">
            <span className="font-bold text-[#1C1917]">Mức ưu tiên:</span>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#9F241F]" />
              <span className="text-[11px] text-[#57534E]">Cần quan sát ngay</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#B45309]" />
              <span className="text-[11px] text-[#57534E]">Đang theo dõi</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#15803D]" />
              <span className="text-[11px] text-[#57534E]">Bình thường</span>
            </div>
          </div>
        </div>

        {/* Selected Point & Mission Detail Panel */}
        <div className="lg:col-span-4 space-y-4">
          {selectedPoint ? (
            <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs space-y-4">
              <div className="space-y-1">
                <span className={`px-2.5 py-0.5 rounded text-[10px] font-black uppercase border ${
                  selectedPoint.priority === 'HIGH' ? 'bg-[#FEF2F2] text-[#9F241F] border-[#FCA5A5]' :
                  selectedPoint.priority === 'MEDIUM' ? 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]' :
                  'bg-[#F0FDF4] text-[#15803D] border-[#DCFCE7]'
                }`}>
                  {selectedPoint.priority === 'HIGH' ? 'Ưu tiên quan sát cao' :
                   selectedPoint.priority === 'MEDIUM' ? 'Theo dõi định kỳ' : 'Trạng thái ổn định'}
                </span>

                <h2 className="text-base font-black text-[#1C1917] pt-1">
                  {selectedPoint.name}
                </h2>
                <p className="text-xs text-[#57534E]">
                  📍 {selectedPoint.area}
                </p>
              </div>

              {/* Active Mission Block */}
              <div className="p-3.5 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl space-y-2 text-xs">
                <div className="font-bold text-[#0D6F64] flex items-center gap-1">
                  <span>🎯</span>
                  <span>Nhiệm vụ cộng đồng hiện hành:</span>
                </div>
                <p className="text-xs text-[#1C1917] font-medium leading-snug">
                  {selectedPoint.activeMission}
                </p>
                <div className="flex items-center justify-between text-[11px] text-[#78716C] pt-1">
                  <span>👥 {selectedPoint.participantsCount} bạn đã tham gia</span>
                  <span className="font-bold text-[#0D6F64]">+2.0 Tín chỉ Xanh</span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => navigate(`/community/observe?pointId=${selectedPoint.id}`)}
                  className="w-full py-3 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs transition min-h-[46px] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>📷 Gửi tín hiệu quan sát tại đây</span>
                </button>
                <button
                  type="button"
                  onClick={() => navigate('/community/missions')}
                  className="w-full py-2.5 bg-white hover:bg-[#FAFAF9] text-[#1C1917] border border-[#E7E5E4] font-bold text-xs rounded-xl shadow-2xs transition min-h-[44px] flex items-center justify-center cursor-pointer"
                >
                  Xem hướng dẫn an toàn
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 text-center text-xs text-[#78716C]">
              Chọn một điểm trên danh sách để xem nhiệm vụ.
            </div>
          )}

          {/* Quick List of Points */}
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs space-y-2 max-h-[300px] overflow-y-auto">
            <div className="text-xs font-black uppercase text-[#57534E]">
              Danh sách điểm ({sites.length})
            </div>
            {sites.map((s) => (
              <div
                key={s.id}
                onClick={() => setSelectedPoint(s)}
                className={`p-2.5 rounded-xl border text-xs cursor-pointer transition flex items-center justify-between ${
                  selectedPoint?.id === s.id
                    ? 'border-[#0D6F64] bg-[#F0FDFA] font-bold text-[#0D6F64]'
                    : 'border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917]'
                }`}
              >
                <span className="truncate pr-2">{s.name}</span>
                <span className="text-[10px] text-[#78716C] shrink-0">›</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
