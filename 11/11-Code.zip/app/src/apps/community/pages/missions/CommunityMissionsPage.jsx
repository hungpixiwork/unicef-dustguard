import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const COMMUNITY_MISSIONS = [
  {
    id: 'mis-1',
    title: 'Quan sát tình trạng bụi sau 17:00 tại nút giao Ga ngầm',
    location: 'Nút giao Kim Mã - Liễu Giai, Ba Đình, Hà Nội',
    timeFrame: 'Hôm nay: 17:00 - 18:30',
    participants: 14,
    credits: 2.5,
    status: 'ACTIVE',
    safetyRules: [
      'Đứng tại vỉa hè an toàn, cách tối thiểu 15 mét từ cổng công trường',
      'Đeo khẩu trang N95 hoặc khẩu trang y tế khi quan sát',
      'Tuyệt đối không tự ý bước qua hàng rào hoặc vào khu vực xe cơ giới'
    ],
    taskDesc: 'Ghi nhận hiện tượng phát tán bụi khi xe tải vận chuyển bùn đất rời công trình vào giờ tan tầm.'
  },
  {
    id: 'mis-2',
    title: 'Xác minh công trình đã che chắn bạt bãi vật liệu rời',
    location: 'Đoạn mở rộng đường gom ĐT743, Dĩ An, Bình Dương',
    timeFrame: 'Từ nay đến hết 05/09',
    participants: 22,
    credits: 3.0,
    status: 'ACTIVE',
    safetyRules: [
      'Chụp ảnh toàn cảnh từ khoảng cách an toàn bên kia đường',
      'Không dừng đỗ xe dưới lòng đường gây cản trở giao thông',
      'Ưu tiên thực hiện vào ban ngày khi đủ ánh sáng tự nhiên'
    ],
    taskDesc: 'Đối chứng xem nhà thầu đã phủ bạt kín các bãi cát đá theo khuyến cáo của cơ quan môi trường chưa.'
  },
  {
    id: 'mis-3',
    title: 'Ghi nhận cầu rửa xe áp lực cao trước cổng phụ số 2',
    location: 'Cụm công trình KCN Sóng Thần 2, Dĩ An',
    timeFrame: 'Thứ Bảy, 08:00 - 11:30',
    participants: 9,
    credits: 2.0,
    status: 'UPCOMING',
    safetyRules: [
      'Đi theo nhóm từ 2 người trở lên',
      'Tránh xa các vũng nước đọng và bánh xe tải lớn',
      'Bật định vị GPS chính xác trên điện thoại'
    ],
    taskDesc: 'Quan sát xem các xe ben có được xịt rửa sạch bùn đất dính bánh xe trước khi lưu thông ra đường lớn hay không.'
  }
];

export default function CommunityMissionsPage() {
  const navigate = useNavigate();
  const [selectedMission, setSelectedMission] = useState(COMMUNITY_MISSIONS[0]);

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Chiến Dịch Tình Nguyện Xanh
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Nhiệm Vụ Quan Sát Cộng Đồng
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Tham gia ghi nhận tín hiệu môi trường an toàn, bảo đảm khách quan và nhận Tín chỉ Xanh.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/community/credits')}
          className="px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs min-h-[44px] flex items-center gap-1.5 cursor-pointer"
        >
          <span>🏆</span>
          <span>Tín chỉ của tôi</span>
        </button>
      </div>

      {/* Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Missions List (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="text-xs font-black uppercase text-[#57534E] tracking-wider">
            Các nhiệm vụ đang mở ({COMMUNITY_MISSIONS.length})
          </div>

          {COMMUNITY_MISSIONS.map((m) => {
            const isSelected = selectedMission.id === m.id;
            return (
              <div
                key={m.id}
                onClick={() => setSelectedMission(m)}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition space-y-3 ${
                  isSelected
                    ? 'border-[#0D6F64] bg-[#F0FDFA]/60 shadow-xs'
                    : 'border-[#E7E5E4] bg-white hover:bg-[#FAFAF9]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase text-[#0D6F64] bg-white px-2.5 py-1 rounded-md border border-[#CCFBF1]">
                    +{m.credits} Tín chỉ Xanh
                  </span>
                  <span className="text-xs font-bold text-[#78716C]">
                    🕒 {m.timeFrame}
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-black text-[#1C1917] leading-snug">
                    {m.title}
                  </h3>
                  <p className="text-xs text-[#57534E] mt-1">
                    📍 {m.location}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs pt-2 border-t border-[#E7E5E4]/60">
                  <span className="text-[#78716C]">👥 {m.participants} bạn đã đăng ký</span>
                  <span className="font-bold text-[#0D6F64]">{isSelected ? 'Đang xem chi tiết' : 'Xem chi tiết →'}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Mission Details & Safety Guidelines (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase text-[#9F241F] bg-[#FEF2F2] px-2.5 py-1 rounded-md border border-[#FCA5A5]/40">
                Chi tiết nhiệm vụ
              </span>
              <h2 className="text-lg font-black text-[#1C1917] pt-1 leading-snug">
                {selectedMission.title}
              </h2>
              <p className="text-xs text-[#57534E]">
                📍 {selectedMission.location}
              </p>
            </div>

            <div className="text-xs text-[#1C1917] leading-relaxed p-3 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4]">
              <b>Mục tiêu ghi nhận: </b>
              {selectedMission.taskDesc}
            </div>

            {/* Mandatory Safety Rules */}
            <div className="space-y-2 p-3.5 bg-[#FFFBEB] border border-[#FDE68A] rounded-xl text-xs text-[#92400E]">
              <div className="font-black uppercase text-[11px] flex items-center gap-1.5 text-[#B45309]">
                <span>⚠️</span>
                <span>Hướng dẫn an toàn bắt buộc:</span>
              </div>
              <ul className="space-y-1.5 pl-4 list-disc text-[11px] leading-snug">
                {selectedMission.safetyRules.map((rule, idx) => (
                  <li key={idx}>{rule}</li>
                ))}
              </ul>
            </div>

            {/* Action CTA */}
            <div className="pt-2 space-y-2">
              <button
                type="button"
                onClick={() => navigate(`/community/observe?missionId=${selectedMission.id}`)}
                className="w-full py-3.5 px-4 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📷</span>
                <span>Gửi ảnh quan sát nhiệm vụ này</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
