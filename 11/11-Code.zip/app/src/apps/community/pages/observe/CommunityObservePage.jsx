import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { compressImage } from '../../../../lib/image-compressor.js';

export default function CommunityObservePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const fileInputRef = useRef(null);

  const [images, setImages] = useState([]);
  const [address, setAddress] = useState('Khu vực nút giao Ga ngầm Kim Mã, Ba Đình, Hà Nội');
  const [condition, setCondition] = useState('DUSTY'); // 'GOOD' | 'DUSTY' | 'HEAVY'
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Auto-acquire GPS
  useEffect(() => {
    if (navigator?.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const { latitude, longitude } = pos.coords;
        setAddress(`Tọa độ thực địa: ${latitude.toFixed(4)}°B, ${longitude.toFixed(4)}°Đ`);
      }, () => {});
    }
  }, []);

  const handleImagePick = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const compressed = await compressImage(file, { maxSizeKB: 300, maxWidthOrHeight: 1200 }).catch(() => file);
      const dataUrl = compressed.dataUrl || URL.createObjectURL(file);
      setImages(prev => [...prev, dataUrl]);
    } catch {
      alert('Không thể xử lý ảnh tải lên.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (images.length === 0) {
      alert('Vui lòng chụp hoặc đính kèm tối thiểu 1 ảnh quan sát.');
      return;
    }

    try {
      setSubmitting(true);
      // Upload evidence photo to R2
      const uploadedUrls = [];
      for (const img of images) {
        if (img && img.startsWith('data:')) {
          try {
            const upRes = await request('/upload', {
              method: 'POST',
              body: JSON.stringify({
                fileName: `obs_${Date.now()}.jpg`,
                mimeType: 'image/jpeg',
                fileData: img,
                category: 'community_observation'
              })
            });
            if (upRes?.data?.url) {
              uploadedUrls.push(upRes.data.url);
            } else {
              uploadedUrls.push(img);
            }
          } catch {
            uploadedUrls.push(img);
          }
        } else if (img) {
          uploadedUrls.push(img);
        }
      }

      // Post observation to backend complaints
      const res = await request('/complaints', {
        method: 'POST',
        body: JSON.stringify({
          title: `[Tín hiệu cộng đồng] Quan sát hiện trường: ${condition}`,
          description: notes.trim() || 'Tín hiệu ghi nhận từ tình nguyện viên CLB Môi trường.',
          category: 'COMMUNITY_SIGNAL',
          address,
          severity: condition === 'HEAVY' ? 'HIGH' : condition === 'DUSTY' ? 'MEDIUM' : 'LOW',
          evidenceUrl: uploadedUrls[0] || null,
          evidences: uploadedUrls
        })
      });

      if (!res || (res.status === 'error' && !res.data)) {
        throw new Error(res?.message || 'Lỗi gửi tín hiệu quan sát.');
      }

      setSuccess(true);
    } catch (err) {
      console.error('[Submit Observation Error]', err);
      alert(err.message || 'Không thể gửi tín hiệu quan sát. Vui lòng kiểm tra lại kết nối và thử lại.');
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div role="status" aria-live="polite" className="max-w-md mx-auto py-12 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-[#0D6F64] text-white flex items-center justify-center mx-auto text-2xl font-bold shadow-sm" aria-hidden="true">
          ✓
        </div>
        <div className="space-y-1">
          <span className="text-[11px] font-black uppercase text-[#0D6F64] bg-[#F0FDFA] px-3 py-1 rounded-full border border-[#CCFBF1]">
            Ghi nhận thành công
          </span>
          <h1 className="text-xl font-black text-[#1C1917]">
            Cảm ơn đóng góp của bạn!
          </h1>
          <p className="text-xs text-[#57534E] leading-relaxed">
            Tín hiệu quan sát của bạn đã được lưu vào hệ thống và đóng góp <b>+1.5 Tín chỉ Xanh</b> vào tài khoản tình nguyện.
          </p>
        </div>

        <div className="pt-3 space-y-2">
          <button
            type="button"
            onClick={() => navigate('/community/credits')}
            className="w-full py-3 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs transition min-h-[46px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64]"
          >
            Xem Tín chỉ Xanh của tôi →
          </button>
          <button
            type="button"
            onClick={() => {
              setSuccess(false);
              setImages([]);
              setNotes('');
            }}
            className="w-full py-2.5 bg-white hover:bg-[#FAFAF9] text-[#1C1917] border border-[#E7E5E4] font-bold text-xs rounded-xl transition min-h-[44px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64]"
          >
            Gửi thêm quan sát khác
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-lg mx-auto pb-16">
      {/* Header */}
      <div>
        <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
          Dành Cho CLB & Sinh Viên Tình Nguyện
        </span>
        <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
          Gửi Tín Hiệu Quan Sát
        </h1>
        <p className="text-xs text-[#57534E] mt-0.5">
          Quy trình gọn nhẹ, nhanh chóng, phục vụ mạng lưới giám sát không khí mở.
        </p>
      </div>

      {/* Mandatory Civic Disclaimer Banner */}
      <div className="p-3.5 bg-[#F0FDFA] border border-[#CCFBF1] rounded-2xl flex items-start gap-2.5 text-xs text-[#0D6F64] leading-relaxed">
        <span className="text-base shrink-0" aria-hidden="true">ℹ️</span>
        <div>
          <b>Lưu ý khách quan: </b>
          Dữ liệu bạn gửi là <b>Tín hiệu cộng đồng (Community Signal)</b> phục vụ công tác cảnh báo sớm, chưa phải kết luận xử phạt vi phạm hành chính.
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs space-y-4" aria-busy={submitting}>
        {/* Photo Upload */}
        <div className="space-y-2">
          <label className="text-xs font-black text-[#1C1917] uppercase tracking-wider block">
            1. Ảnh hiện trường quan sát *
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImagePick}
            className="hidden"
          />

          <div className="flex items-center gap-3 overflow-x-auto pb-1">
            {images.map((img, idx) => (
              <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-[#E7E5E4] shrink-0 bg-[#FAFAF9]">
                <img src={img} alt={`Ảnh quan sát ${idx + 1}`} className="w-full h-full object-cover" />
              </div>
            ))}

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              aria-label="Chụp ảnh hiện trường quan sát"
              className="w-20 h-20 rounded-xl border-2 border-dashed border-[#0D6F64]/40 hover:border-[#0D6F64] bg-[#F0FDFA]/40 hover:bg-[#F0FDFA] flex flex-col items-center justify-center text-xs font-bold text-[#0D6F64] shrink-0 cursor-pointer transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64]"
            >
              <span className="text-lg leading-none" aria-hidden="true">+</span>
              <span className="text-[10px] mt-1">Chụp ảnh</span>
            </button>
          </div>
        </div>

        {/* Observation Condition Buttons */}
        <div className="space-y-2">
          <span className="text-xs font-black text-[#1C1917] uppercase tracking-wider block">
            2. Tình trạng quan sát được *
          </span>
          <div role="radiogroup" aria-label="Tình trạng quan sát được" className="grid grid-cols-3 gap-2">
            {[
              { key: 'GOOD', label: 'Che chắn tốt', icon: '🟢', border: 'border-emerald-600', bg: 'bg-emerald-50 text-emerald-800' },
              { key: 'DUSTY', label: 'Bụi nhẹ', icon: '🟡', border: 'border-amber-600', bg: 'bg-amber-50 text-amber-800' },
              { key: 'HEAVY', label: 'Phát tán nhiều', icon: '🔴', border: 'border-rose-600', bg: 'bg-rose-50 text-rose-800' }
            ].map((opt) => (
              <button
                key={opt.key}
                type="button"
                role="radio"
                aria-checked={condition === opt.key}
                onClick={() => setCondition(opt.key)}
                className={`py-2.5 px-2 rounded-xl text-xs font-black border-2 transition min-h-[46px] flex flex-col items-center justify-center gap-0.5 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64] ${
                  condition === opt.key
                    ? `${opt.border} ${opt.bg} shadow-xs`
                    : 'border-[#E7E5E4] bg-white text-[#57534E] hover:bg-[#FAFAF9]'
                }`}
              >
                <span aria-hidden="true">{opt.icon}</span>
                <span className="text-[11px]">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Location Input */}
        <div className="space-y-1">
          <label htmlFor="obs-address-input" className="text-xs font-black text-[#1C1917] block">
            3. Vị trí quan sát:
          </label>
          <input
            id="obs-address-input"
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-[#D6D3D1] bg-[#FAFAF9] text-[#1C1917] focus:outline-hidden focus:ring-1 focus:ring-[#0D6F64] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64] min-h-[44px]"
            required
          />
        </div>

        {/* Optional Note */}
        <div className="space-y-1">
          <label htmlFor="obs-notes-textarea" className="text-xs font-black text-[#1C1917] block">
            4. Ghi chú thêm (không bắt buộc):
          </label>
          <textarea
            id="obs-notes-textarea"
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Ví dụ: Xe tải vừa đi qua làm bụi bay về phía trường học…"
            className="w-full text-xs p-3 rounded-xl border border-[#D6D3D1] bg-[#FAFAF9] text-[#1C1917] focus:outline-hidden focus:ring-1 focus:ring-[#0D6F64] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64]"
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={submitting}
          aria-busy={submitting}
          className="w-full py-3.5 px-5 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D6F64]"
        >
          <span aria-hidden="true">✓</span>
          <span>{submitting ? 'Đang gửi dữ liệu…' : 'Gửi tín hiệu quan sát (+1.5 Tín chỉ)'}</span>
        </button>
      </form>
    </div>
  );
}
