import React from 'react';
import { useNavigate } from 'react-router-dom';

const COMMUNITY_CLUBS = [
  {
    id: 'club-01',
    name: 'CLB Môi Trường Xanh — ĐHQG Hà Nội',
    leadOrg: 'Đoàn Trường ĐH Khoa học Tự nhiên',
    observedZones: 6,
    verifiedSignals: 64,
    totalHours: 180,
    mainActivities: 'Khảo sát bụi mịn học đường, đối chứng che chắn công trình Ga S9.',
    badge: 'Tích cực xuất sắc'
  },
  {
    id: 'club-02',
    name: 'Đội Thanh Niên Tình Nguyện Cầu Giấy',
    leadOrg: 'Quận Đoàn Cầu Giấy',
    observedZones: 4,
    verifiedSignals: 42,
    totalHours: 125,
    mainActivities: 'Tuần tra không khí sạch tuyến đường Trần Thái Tông - Dịch Vọng.',
    badge: 'Đóng góp bền bỉ'
  },
  {
    id: 'club-03',
    name: 'Nhóm Hành Động Không Khí Sạch Dĩ An',
    leadOrg: 'Liên hiệp Thanh niên TP Dĩ An',
    observedZones: 5,
    verifiedSignals: 38,
    totalHours: 95,
    mainActivities: 'Giám sát xe tải chở bùn đất và bãi vật liệu dọc đường ĐT743.',
    badge: 'Tiên phong thực địa'
  },
  {
    id: 'club-04',
    name: 'CLB Sinh Viên Xanh — ĐH Bách Khoa',
    leadOrg: 'Đoàn Thanh niên ĐH Bách Khoa',
    observedZones: 3,
    verifiedSignals: 29,
    totalHours: 80,
    mainActivities: 'Hỗ trợ hiệu chuẩn cảm biến đo bụi và tuyên truyền giảm bụi giao thông.',
    badge: 'Công nghệ & Xã hội'
  }
];

export default function CommunityImpactPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Tác Động Tích Cực
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Bảng Tác Động Cộng Đồng
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Tôn vinh các tập thể, CLB và trường học chung tay vì môi trường trong sạch.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/community/observe')}
          className="px-4 py-2.5 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px] flex items-center gap-1.5 cursor-pointer"
        >
          <span>📷</span>
          <span>Gửi quan sát mới</span>
        </button>
      </div>

      {/* Summary Impact Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-3xl p-6 shadow-xs grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        <div>
          <span className="text-xs font-bold text-[#78716C] uppercase block">Tổng CLB tham gia</span>
          <span className="text-3xl font-black text-[#1C1917] mt-1 block">18</span>
          <span className="text-[11px] text-[#0D6F64] font-bold mt-1 block">Trường học & Đoàn thể</span>
        </div>

        <div>
          <span className="text-xs font-bold text-[#78716C] uppercase block">Khu vực được quan sát</span>
          <span className="text-3xl font-black text-[#0D6F64] mt-1 block">24</span>
          <span className="text-[11px] text-[#0D6F64] font-bold mt-1 block">Đô thị & Ngoại thành</span>
        </div>

        <div>
          <span className="text-xs font-bold text-[#78716C] uppercase block">Giờ tình nguyện</span>
          <span className="text-3xl font-black text-[#9F241F] mt-1 block">680h</span>
          <span className="text-[11px] text-[#9F241F] font-bold mt-1 block">Tích lũy thực tế</span>
        </div>

        <div>
          <span className="text-xs font-bold text-[#78716C] uppercase block">Dữ liệu được xác minh</span>
          <span className="text-3xl font-black text-[#15803D] mt-1 block">340</span>
          <span className="text-[11px] text-[#15803D] font-bold mt-1 block">Hỗ trợ chính quyền</span>
        </div>
      </div>

      {/* Impact Table of Active Groups */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
        <h2 className="text-xs font-black uppercase tracking-wider text-[#1C1917] pb-2 border-b border-[#E7E5E4]">
          Các CLB và Đội Nhóm Đóng Góp Nổi Bật
        </h2>

        <div className="space-y-4">
          {COMMUNITY_CLUBS.map((club) => (
            <div
              key={club.id}
              className="p-4 sm:p-5 rounded-2xl border-2 border-[#E7E5E4] hover:border-[#0D6F64] transition bg-[#FAFAF9] hover:bg-white flex flex-col md:flex-row justify-between gap-4 shadow-2xs"
            >
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-black text-base text-[#1C1917]">
                    {club.name}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-[#F0FDFA] text-[#0D6F64] border border-[#CCFBF1]">
                    {club.badge}
                  </span>
                </div>
                <p className="text-xs text-[#57534E]">
                  Trực thuộc: <b>{club.leadOrg}</b>
                </p>
                <p className="text-xs text-[#78716C] leading-snug pt-1 italic">
                  "{club.mainActivities}"
                </p>
              </div>

              {/* Club Metrics */}
              <div className="grid grid-cols-3 gap-2 shrink-0 md:w-80 text-center self-stretch md:self-center border-t md:border-t-0 md:border-l border-[#E7E5E4] pt-3 md:pt-0 md:pl-4">
                <div className="bg-white p-2 rounded-xl border border-[#E7E5E4]">
                  <span className="text-[10px] text-[#78716C] block">Khu vực</span>
                  <span className="font-black text-sm text-[#1C1917]">{club.observedZones}</span>
                </div>
                <div className="bg-white p-2 rounded-xl border border-[#E7E5E4]">
                  <span className="text-[10px] text-[#78716C] block">Tín hiệu</span>
                  <span className="font-black text-sm text-[#0D6F64]">{club.verifiedSignals}</span>
                </div>
                <div className="bg-white p-2 rounded-xl border border-[#E7E5E4]">
                  <span className="text-[10px] text-[#78716C] block">Giờ công</span>
                  <span className="font-black text-sm text-[#9F241F]">{club.totalHours}h</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
