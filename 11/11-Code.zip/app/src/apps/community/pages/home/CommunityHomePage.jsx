import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function CommunityHomePage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    observedZones: 12,
    openMissions: 5,
    verifiedObservations: 148,
    volunteerHours: 320
  });

  const [activeMissions, setActiveMissions] = useState([
    {
      id: 'mis-01',
      title: 'Quan sát tình trạng bụi quanh cổng công trường Ga ngầm S9',
      zone: 'Khu vực Kim Mã - Cầu Giấy, Hà Nội',
      target: 'Ghi nhận thời điểm xe ben chở bùn đất ra vào giờ cao điểm',
      activeVolunteers: 8,
      status: 'OPEN',
      deadline: 'Hôm nay 18:00',
      credits: 2.0
    },
    {
      id: 'mis-02',
      title: 'Xác minh hiện trạng che bạt tại khu vực đường gom ĐT743',
      zone: 'Phường Dĩ An, Bình Dương',
      target: 'Chụp ảnh đối chứng các bãi tập kết vật liệu rời sau khi có nhắc nhở',
      activeVolunteers: 12,
      status: 'OPEN',
      deadline: 'Đến hết ngày mai',
      credits: 3.0
    }
  ]);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const res = await request('/complaints').catch(() => []);
        const list = normalizeList(res);
        setStats(prev => ({
          ...prev,
          verifiedObservations: list.filter(i => i.status === 'RESOLVED' || i.status === 'VERIFIED').length || 148
        }));
      } catch {} finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) return <LoadingState message="Đang nạp không gian cộng đồng…" />;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* 1. Hero Truyền Cảm Hứng & Thực Tế (Không gamification thái quá) */}
      <div className="bg-gradient-to-br from-white to-[#FDFBF7] border border-[#E7E5E4] rounded-3xl p-6 sm:p-8 shadow-xs space-y-4">
        <div className="space-y-2">
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64] bg-[#F0FDFA] px-3 py-1 rounded-full border border-[#CCFBF1]">
            Quan Sát Môi Trường Vì Sức Khỏe Cộng Đồng
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#1C1917] tracking-tight leading-snug">
            Cùng Hành Động Vì Bầu Không Khí Trong Lành
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] max-w-2xl leading-relaxed">
            Nền tảng kết nối các CLB tình nguyện, sinh viên và học sinh tham gia ghi nhận tín hiệu môi trường, đối chứng che chắn bụi công trình và tích lũy Tín chỉ Xanh ngoại khóa.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate('/community/observe')}
            className="px-5 py-3 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-black text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center gap-2 cursor-pointer"
          >
            <span>📷</span>
            <span>Gửi quan sát hiện trường</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('/community/missions')}
            className="px-5 py-3 bg-white hover:bg-[#FAFAF9] text-[#1C1917] border border-[#E7E5E4] font-bold text-xs rounded-xl shadow-2xs transition min-h-[48px] flex items-center gap-2 cursor-pointer"
          >
            <span>🎯</span>
            <span>Xem chiến dịch quan sát</span>
          </button>
        </div>
      </div>

      {/* 2. 4 Tác Động Cộng Đồng Đạt Được */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs text-center">
          <span className="text-[11px] font-bold text-[#78716C] uppercase block">Khu vực cần quan sát</span>
          <span className="text-2xl sm:text-3xl font-black text-[#1C1917] mt-1 block">{stats.observedZones}</span>
          <span className="text-[10px] text-[#0D6F64] font-bold mt-1 block">Tập trung trọng điểm</span>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs text-center">
          <span className="text-[11px] font-bold text-[#78716C] uppercase block">Hoạt động đang mở</span>
          <span className="text-2xl sm:text-3xl font-black text-[#9F241F] mt-1 block">{stats.openMissions}</span>
          <span className="text-[10px] text-[#9F241F] font-bold mt-1 block">Cần người tham gia</span>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs text-center">
          <span className="text-[11px] font-bold text-[#78716C] uppercase block">Tín hiệu xác minh</span>
          <span className="text-2xl sm:text-3xl font-black text-[#0D6F64] mt-1 block">{stats.verifiedObservations}</span>
          <span className="text-[10px] text-[#0D6F64] font-bold mt-1 block">Dữ liệu có giá trị</span>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs text-center">
          <span className="text-[11px] font-bold text-[#78716C] uppercase block">Giờ tình nguyện</span>
          <span className="text-2xl sm:text-3xl font-black text-[#1C1917] mt-1 block">{stats.volunteerHours}h</span>
          <span className="text-[10px] text-[#78716C] font-bold mt-1 block">Quy đổi Tín chỉ Xanh</span>
        </div>
      </div>

      {/* 3. Danh Sách Nhiệm Vụ Đang Mở */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#E7E5E4]">
          <div>
            <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
              Nhiệm Vụ Quan Sát Cộng Đồng Đang Mở
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Chọn một điểm gần bạn để tham gia ghi nhận tín hiệu môi trường an toàn.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/community/missions')}
            className="text-xs font-bold text-[#0D6F64] hover:underline"
          >
            Tất cả nhiệm vụ →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeMissions.map((m) => (
            <div
              key={m.id}
              onClick={() => navigate('/community/missions')}
              className="p-4 rounded-xl border border-[#E7E5E4] hover:border-[#0D6F64] transition bg-[#FAFAF9] hover:bg-white flex flex-col justify-between gap-3 cursor-pointer shadow-2xs"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase text-[#0D6F64] bg-[#F0FDFA] px-2 py-0.5 rounded border border-[#CCFBF1]">
                    +{m.credits} Tín chỉ
                  </span>
                  <span className="text-[11px] text-[#9F241F] font-bold">
                    ⏳ {m.deadline}
                  </span>
                </div>
                <h3 className="font-black text-sm text-[#1C1917] leading-snug">
                  {m.title}
                </h3>
                <p className="text-xs text-[#57534E]">
                  📍 {m.zone}
                </p>
                <p className="text-[11px] text-[#78716C] italic leading-snug">
                  "{m.target}"
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#E7E5E4]/80 text-xs">
                <span className="text-[#78716C]">👥 {m.activeVolunteers} tình nguyện viên</span>
                <span className="font-bold text-[#0D6F64]">Tham gia →</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
