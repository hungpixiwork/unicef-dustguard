import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { calculateVolunteerHours } from '../../../../lib/youth-credits.js';

export default function CommunityCreditsPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    verifiedHours: 15,
    resolvedReportsCount: 6,
    totalReportsCount: 8
  });

  useEffect(() => {
    async function loadStats() {
      try {
        const res = await request('/complaints').catch(() => []);
        const list = normalizeList(res);
        const calc = calculateVolunteerHours(list);
        setStats(calc);
      } catch {}
    }
    loadStats();
  }, []);

  const totalCredits = (stats.verifiedHours / 5).toFixed(1);

  const historyItems = [
    {
      date: '03/09/2026',
      activity: 'Quan sát che chắn bãi vật liệu Ga ngầm Kim Mã',
      hours: 2.0,
      credits: 0.4,
      status: 'VERIFIED'
    },
    {
      date: '01/09/2026',
      activity: 'Ghi nhận hiện trạng xịt rửa bánh xe công trường ĐT743',
      hours: 3.0,
      credits: 0.6,
      status: 'VERIFIED'
    },
    {
      date: '28/08/2026',
      activity: 'Khảo sát nồng độ bụi quanh trường Tiểu học Dịch Vọng',
      hours: 4.0,
      credits: 0.8,
      status: 'VERIFIED'
    }
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Ghi Nhận Hoạt Động Xã Hội
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Tín Chỉ Xanh & Giờ Tình Nguyện
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Quy đổi công sức giám sát hiện trường thành tín chỉ ngoại khóa và chứng nhận chính thức.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/certificate')}
          className="px-4 py-2.5 bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px] flex items-center gap-1.5 cursor-pointer"
        >
          <span>📜</span>
          <span>Chứng nhận số (QR)</span>
        </button>
      </div>

      {/* Big 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs text-center space-y-1">
          <span className="text-xs font-bold text-[#0D6F64] uppercase tracking-wider">
            Tín Chỉ Xanh Đề Xuất
          </span>
          <div className="text-4xl font-black text-[#0D6F64] pt-1">
            {totalCredits}
          </div>
          <span className="text-[11px] text-[#78716C] block">
            Quy đổi: 5 giờ = 1.0 tín chỉ
          </span>
        </div>

        <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs text-center space-y-1">
          <span className="text-xs font-bold text-[#1C1917] uppercase tracking-wider">
            Giờ Hoạt Động Thực Tế
          </span>
          <div className="text-4xl font-black text-[#1C1917] pt-1">
            {stats.verifiedHours}h
          </div>
          <span className="text-[11px] text-[#78716C] block">
            Được đối chứng qua tọa độ GPS
          </span>
        </div>

        <div className="bg-white border-2 border-[#E7E5E4] rounded-2xl p-5 shadow-xs text-center space-y-1">
          <span className="text-xs font-bold text-[#15803D] uppercase tracking-wider">
            Lượt Quan Sát Xác Minh
          </span>
          <div className="text-4xl font-black text-[#15803D] pt-1">
            {stats.resolvedReportsCount}
          </div>
          <span className="text-[11px] text-[#78716C] block">
            Dữ liệu hỗ trợ cơ quan dập bụi
          </span>
        </div>
      </div>

      {/* Progress towards Semester Certificate */}
      <div className="bg-[#F0FDFA] border border-[#CCFBF1] rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-[#0D6F64]">
            Tiến độ hoàn thành chứng nhận học kỳ (Mục tiêu: 20 giờ = 4.0 tín chỉ)
          </span>
          <span className="font-black text-[#0D6F64]">{stats.verifiedHours} / 20h</span>
        </div>
        <div className="w-full bg-white h-3 rounded-full overflow-hidden border border-[#CCFBF1]">
          <div
            className="bg-[#0D6F64] h-full transition-all rounded-full"
            style={{ width: `${Math.min(100, (stats.verifiedHours / 20) * 100)}%` }}
          />
        </div>
        <div className="text-[11px] text-[#57534E] leading-relaxed">
          Đạt mốc 20 giờ tình nguyện: Nhận Giấy chứng nhận Đoàn Thanh niên / Trường Đại học hỗ trợ xét học bổng và điểm rèn luyện.
        </div>
      </div>

      {/* History of Contributions */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-xs space-y-3">
        <h2 className="text-xs font-black uppercase tracking-wider text-[#1C1917] pb-2 border-b border-[#E7E5E4]">
          Lịch sử hoạt động được ghi nhận
        </h2>

        <div className="divide-y divide-[#E7E5E4]">
          {historyItems.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5 min-w-0">
                <span className="font-bold text-[#1C1917] block truncate">
                  {item.activity}
                </span>
                <span className="text-[11px] text-[#78716C]">
                  🕒 {item.date} • {item.hours} giờ tham gia
                </span>
              </div>
              <div className="text-right shrink-0">
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-[#F0FDF4] text-[#15803D] border border-[#DCFCE7]">
                  +{item.credits} Tín chỉ
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
