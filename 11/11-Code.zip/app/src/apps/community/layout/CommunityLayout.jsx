import React, { useState } from 'react';
import { Outlet, NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext.jsx';
import SafeImage from '../../../shared/components/SafeImage.jsx';

export default function CommunityLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // 5 Navigation items for Community
  const navItems = [
    { to: '/community', end: true, label: 'Trang chủ' },
    { to: '/community/map', label: 'Bản đồ quan sát' },
    { to: '/community/missions', label: 'Nhiệm vụ' },
    { to: '/community/observe', label: 'Gửi quan sát' },
    { to: '/community/credits', label: 'Tín chỉ Xanh' },
    { to: '/community/impact', label: 'Bảng tác động' },
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1C1917] flex flex-col antialiased">
      {/* Header */}
      <header className="bg-white border-b border-[#E7E5E4] sticky top-0 z-30 h-16 flex items-center justify-between px-4 sm:px-6 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#57534E] hover:text-[#1C1917] rounded-xl hover:bg-[#FAFAF9] min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
            aria-label="Mở menu"
          >
            <span className="text-xl">☰</span>
          </button>

          <Link to="/community" className="flex items-center gap-2.5 group">
            <SafeImage
              src="/images/logo/dustguard-shield-logo.webp"
              alt="DustGuard VN Logo"
              className="w-8 h-8 rounded-lg object-contain"
            />
            <div className="flex flex-col">
              <span className="font-black text-sm tracking-tight text-[#1C1917] leading-none group-hover:text-[#0D6F64] transition">
                DustGuard <span className="text-[#0D6F64]">Community</span>
              </span>
              <span className="text-[10px] text-[#78716C] font-semibold mt-0.5">
                Mạng Lưới Quan Sát Môi Trường Trẻ
              </span>
            </div>
          </Link>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `px-3.5 py-2 rounded-xl text-xs font-bold transition min-h-[44px] flex items-center ${
                  isActive
                    ? 'bg-[#F0FDFA] text-[#0D6F64] border border-[#CCFBF1]'
                    : 'text-[#57534E] hover:text-[#1C1917] hover:bg-[#FAFAF9]'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* User / Portal Switcher */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => navigate('/citizen')}
            className="hidden sm:flex px-3 py-1.5 text-xs font-bold text-[#9F241F] bg-[#FEF2F2] border border-[#FCA5A5]/50 hover:bg-[#FEE2E2] rounded-xl transition min-h-[40px] items-center"
          >
            Chế độ Người dân
          </button>
          <button
            type="button"
            onClick={() => {
              if (logout) logout();
              navigate('/login');
            }}
            className="px-3 py-1.5 text-xs font-bold text-[#57534E] hover:text-[#1C1917] hover:bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl transition min-h-[40px] flex items-center"
          >
            Đăng xuất
          </button>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[#E7E5E4] px-4 py-3 space-y-1 shadow-md">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setMobileMenuOpen(false)}
              className={({ isActive }) =>
                `block px-4 py-2.5 rounded-xl text-xs font-bold min-h-[44px] flex items-center ${
                  isActive
                    ? 'bg-[#F0FDFA] text-[#0D6F64] font-black'
                    : 'text-[#57534E] hover:bg-[#FAFAF9]'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <div className="pt-2 border-t border-[#E7E5E4] flex gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                navigate('/citizen');
              }}
              className="flex-1 py-2 text-xs font-bold text-[#9F241F] bg-[#FEF2F2] rounded-xl border border-[#FCA5A5]/40 text-center min-h-[44px]"
            >
              Chuyển sang Người dân
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 md:p-8">
        <Outlet />
      </main>
    </div>
  );
}
