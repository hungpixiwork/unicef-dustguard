import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const CommunityLayout = lazy(() => import('./layout/CommunityLayout'));
const CommunityHomePage = lazy(() => import('./pages/home/CommunityHomePage'));
const CommunityMapPage = lazy(() => import('./pages/map/CommunityMapPage'));
const CommunityMissionsPage = lazy(() => import('./pages/missions/CommunityMissionsPage'));
const CommunityObservePage = lazy(() => import('./pages/observe/CommunityObservePage'));
const CommunityCreditsPage = lazy(() => import('./pages/credits/CommunityCreditsPage'));
const CommunityImpactPage = lazy(() => import('./pages/impact/CommunityImpactPage'));

export const communityRoutes = (
  <Route path="/community" element={<CommunityLayout />}>
    {/* 25. Community Home */}
    <Route index element={<CommunityHomePage />} />
    <Route path="home" element={<Navigate to="/community" replace />} />
    <Route path="discover" element={<Navigate to="/community" replace />} />
    <Route path="observations" element={<Navigate to="/community/observe" replace />} />
    <Route path="cases" element={<Navigate to="/community" replace />} />
    <Route path="actions" element={<Navigate to="/community/missions" replace />} />
    <Route path="follow-ups" element={<Navigate to="/community/observe" replace />} />
    
    {/* 26. Bản đồ cộng đồng */}
    <Route path="map" element={<CommunityMapPage />} />
    
    {/* 27. Nhiệm vụ cộng đồng */}
    <Route path="missions" element={<CommunityMissionsPage />} />
    
    {/* 28. Gửi quan sát (Tín hiệu cộng đồng) */}
    <Route path="observe" element={<CommunityObservePage />} />
    
    {/* 29. Tín chỉ Xanh */}
    <Route path="credits" element={<CommunityCreditsPage />} />
    
    {/* 30. Bảng tác động cộng đồng */}
    <Route path="impact" element={<CommunityImpactPage />} />
  </Route>
);
