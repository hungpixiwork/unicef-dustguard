import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const AdminLayout = lazy(() => import('./layout/AdminLayout'));
const AdminDashboardPage = lazy(() => import('./pages/dashboard/AdminDashboardPage'));
const AdminDispatchPage = lazy(() => import('./pages/dispatch/AdminDispatchPage'));
const StaffAssignmentPage = lazy(() => import('./pages/dispatch/StaffAssignmentPage'));
const CasesListPage = lazy(() => import('../staff/pages/cases/CasesListPage'));
const CaseDetailPage = lazy(() => import('../staff/pages/cases/CaseDetailPage'));
const UsersPage = lazy(() => import('./pages/users/UsersPage'));
const SitesListPage = lazy(() => import('../staff/pages/sites/SitesListPage'));
const SiteDetailPage = lazy(() => import('../staff/pages/sites/SiteDetailPage'));
const SettingsPage = lazy(() => import('./pages/settings/SettingsPage'));

export const adminRoutes = (
  <Route path="/admin" element={<AdminLayout />}>
    <Route index element={<AdminDashboardPage />} />
    <Route path="dashboard" element={<Navigate to="/admin" replace />} />
    
    {/* Dispatch & Complaints */}
    <Route path="dispatch" element={<AdminDispatchPage />} />
    <Route path="dispatch/assign" element={<StaffAssignmentPage />} />
    <Route path="assignment" element={<StaffAssignmentPage />} />

    {/* Cases Management */}
    <Route path="cases" element={<CasesListPage />} />
    <Route path="cases/:id" element={<CaseDetailPage />} />

    {/* Users */}
    <Route path="users" element={<UsersPage />} />
    
    {/* Sites */}
    <Route path="sites" element={<SitesListPage />} />
    <Route path="sites/:id" element={<SiteDetailPage />} />
    <Route path="sites/:id/:tab" element={<SiteDetailPage />} />
    
    {/* Settings */}
    <Route path="settings" element={<SettingsPage />} />

    {/* Legacy redirects */}
    <Route path="complaints" element={<Navigate to="/admin/dispatch" replace />} />
    <Route path="system" element={<Navigate to="/admin/settings" replace />} />
    <Route path="data-management" element={<Navigate to="/admin/settings" replace />} />
    <Route path="standalone" element={<Navigate to="/admin" replace />} />
  </Route>
);
