import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { BrandLogo } from '../../../shared/components/BrandLogo';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core Navigation Items for Admin
  const navItems = [
    { to: '/admin', end: true, label: 'Tổng quan' },
    { to: '/admin/dispatch', label: 'Điều phối Phản ánh' },
    { to: '/admin/dispatch/assign', label: 'Phân công Cán bộ' },
    { to: '/admin/cases', label: 'Quản lý Vụ việc' },
    { to: '/admin/sites', label: 'Quản lý Công trình' },
    { to: '/admin/users', label: 'Người dùng & Quyền' },
    { to: '/admin/settings', label: 'Cấu hình Hệ thống' },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#1C1917] flex flex-col antialiased">
      {/* Header */}
      <header className="bg-white border-b border-[#E7E5E4] sticky top-0 z-30 h-16 flex items-center justify-between px-4 sm:px-6 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden px-3 py-2 rounded-xl border border-[#E7E5E4] bg-[#F5F5F4] text-[#1C1917] hover:bg-[#FEF2F2] hover:text-[#991B1B] min-h-[48px] min-w-[48px] flex items-center justify-center cursor-pointer font-bold text-xs transition"
            aria-label="Mở menu quản trị"
          >
            {mobileMenuOpen ? '✕ Đóng' : '☰ Menu'}
          </button>

          <div className="flex items-center gap-2">
            <BrandLogo to="/admin" variant="compact" size="md" />
            <span className="hidden sm:inline-block px-2.5 py-1 rounded-md text-[11px] font-black uppercase tracking-wider bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]">
              Quản Trị
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-[#1C1917] break-words">{user?.fullName || 'Quản trị viên'}</span>
            <span className="text-[11px] text-[#B91C1C] font-bold">Toàn quyền hệ thống</span>
          </div>

          <button
            type="button"
            onClick={() => {
              if (logout) logout();
              navigate('/login');
            }}
            className="px-3.5 py-2 text-xs font-bold text-[#57534E] hover:text-[#B91C1C] bg-[#FAFAF9] hover:bg-[#FEF2F2] border border-[#E7E5E4] hover:border-[#FECACA] rounded-xl transition min-h-[48px] flex items-center gap-1.5 cursor-pointer"
          >
            <span>Đăng xuất</span>
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-[#1C1917]/40 flex flex-col pt-16">
          <div className="bg-white border-b border-[#E7E5E4] p-4 shadow-xl flex flex-col gap-2 max-h-[calc(100vh-4rem)] overflow-y-auto">
            <div className="text-[11px] font-extrabold text-[#78716C] uppercase tracking-wider px-3 py-1">
              Danh Mục Quản Trị Hệ Thống
            </div>
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition min-h-[48px] ${
                    isActive
                      ? 'bg-[#B91C1C] text-white shadow-xs'
                      : 'text-[#1C1917] bg-[#F5F5F4] hover:bg-[#FEF2F2] hover:text-[#991B1B]'
                  }`
                }
              >
                <span>{item.label}</span>
              </NavLink>
            ))}

            <div className="pt-3 mt-2 border-t border-[#E7E5E4] flex flex-col gap-1 px-3 text-xs text-[#78716C]">
              <div className="font-bold text-[#1C1917]">{user?.fullName || 'Quản trị viên'}</div>
              <div>Hạ tầng Cloudflare D1 & R2 Vault</div>
            </div>
          </div>
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Desktop */}
        <aside className="hidden lg:flex w-56 xl:w-60 bg-white border-r border-[#E7E5E4] flex-col p-4 gap-2 shrink-0">
          <div className="text-[11px] font-extrabold text-[#78716C] uppercase tracking-wider px-3 mb-1">
            Quản Trị & Cấu Hình
          </div>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-3 rounded-xl font-bold text-xs transition min-h-[48px] ${
                  isActive
                    ? 'bg-[#B91C1C] text-white shadow-xs'
                    : 'text-[#57534E] hover:bg-[#FEF2F2] hover:text-[#991B1B]'
                }`
              }
            >
              <span>{item.label}</span>
            </NavLink>
          ))}

          <div className="mt-auto pt-4 border-t border-[#E7E5E4] text-[11px] text-[#78716C] px-3 space-y-0.5">
            <div className="font-bold text-[#1C1917]">Quản trị phân quyền 5 roles</div>
            <div>Bảo mật & Kiểm toán D1</div>
            <div>Giám sát QCVN 05:2023</div>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
