import React, { useState, useEffect } from 'react';
import { request } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('settings'); // 'settings' | 'stats' | 'trash' | 'danger'
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successToast, setSuccessToast] = useState('');

  // QCVN 05:2023/BTNMT Standard Settings (D1 SSOT)
  const [settings, setSettings] = useState({
    pm25Limit24h: 50,
    pm25Limit1h: 100,
    pm10Limit24h: 100,
    tspLimit24h: 300,
    so2Limit1h: 350,
    no2Limit1h: 200,
    coLimit1h: 30000,
    geofenceBufferMeters: 50,
    slaEmergencyHours: 24,
    slaStandardHours: 48,
    zaloWebhookUrl: 'https://openapi.zalo.me/v3.0/oa/message/transaction',
    telegramBotToken: 'bot812938472:AAFH89s-dustguard-alert',
    telegramChatId: '-1002384719283',
    d1AutoBackup: true,
    r2EvidenceRetentionDays: 365
  });

  // Data Management States
  const [systemStats, setSystemStats] = useState(null);
  const [trashData, setTrashData] = useState(null);
  const [showResetModal, setShowResetModal] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [resetMode, setResetMode] = useState('EMPTY'); // EMPTY, RESET_AND_SEED
  const [deleteFiles, setDeleteFiles] = useState(false);
  const [typedConfirmation, setTypedConfirmation] = useState('');
  const [resetting, setResetting] = useState(false);

  const loadAll = async () => {
    try {
      setLoading(true);
      setError(null);
      const [settingsRes, statsRes, trashRes] = await Promise.all([
        request('/admin/settings').catch(() => request('/settings')).catch(() => null),
        request('/admin/system/data-stats').catch(() => null),
        request('/admin/trash').catch(() => null)
      ]);

      if (settingsRes) {
        const cfg = settingsRes.data || settingsRes;
        if (cfg && (cfg.pm25Limit24h !== undefined || cfg.geofenceBufferMeters !== undefined)) {
          setSettings((prev) => ({ ...prev, ...cfg }));
        }
      }

      if (statsRes && statsRes.data) {
        setSystemStats(statsRes.data);
      } else {
        setSystemStats({
          database: { provider: 'cloudflare-d1', status: 'HEALTHY', ssot: true },
          counts: { sites: 3, complaints: 2, cases: 1, evidences: 1, inspections: 0, actions: 0, sensors: 5, sensorReadings: 40, auditLogs: 12 }
        });
      }

      if (trashRes && trashRes.data) {
        setTrashData(trashRes.data);
      }
    } catch (err) {
      console.warn('Lỗi tải dữ liệu cấu hình D1:', err);
      setError(err.message || 'Lỗi tải dữ liệu cấu hình');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleChange = (field, value) => {
    setSettings((prev) => ({
      ...prev,
      [field]: typeof value === 'number' || !isNaN(Number(value)) ? (value === '' ? '' : Number(value)) : value
    }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await request('/admin/settings', {
        method: 'PUT',
        body: JSON.stringify(settings)
      }).catch(async () => {
        return request('/settings', {
          method: 'PUT',
          body: JSON.stringify(settings)
        });
      });

      if (res) {
        const saved = res.data || res;
        setSettings((prev) => ({ ...prev, ...saved }));
      }
      setSuccessToast('Đã lưu cấu hình quy chuẩn QCVN 05:2023 và hệ thống vào D1 SQLite SSOT thành công!');
      setTimeout(() => setSuccessToast(''), 4000);
    } catch (err) {
      alert(err.message || 'Lỗi lưu cấu hình vào D1 SQLite');
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefault = async () => {
    try {
      setSaving(true);
      const res = await request('/admin/settings/reset', { method: 'POST' }).catch(() => null);
      if (res && (res.data || res.pm25Limit24h)) {
        const cfg = res.data || res;
        setSettings((prev) => ({ ...prev, ...cfg }));
      } else {
        setSettings({
          pm25Limit24h: 50,
          pm25Limit1h: 100,
          pm10Limit24h: 100,
          tspLimit24h: 300,
          so2Limit1h: 350,
          no2Limit1h: 200,
          coLimit1h: 30000,
          geofenceBufferMeters: 50,
          slaEmergencyHours: 24,
          slaStandardHours: 48,
          zaloWebhookUrl: 'https://openapi.zalo.me/v3.0/oa/message/transaction',
          telegramBotToken: 'bot812938472:AAFH89s-dustguard-alert',
          telegramChatId: '-1002384719283',
          d1AutoBackup: true,
          r2EvidenceRetentionDays: 365
        });
      }
      setSuccessToast('Đã khôi phục các giá trị mặc định theo quy chuẩn QCVN 05:2023!');
      setTimeout(() => setSuccessToast(''), 4000);
    } catch (err) {
      alert(err.message || 'Lỗi khôi phục mặc định');
    } finally {
      setSaving(false);
    }
  };

  // Trash actions
  const handleRestore = async (entity, id) => {
    try {
      await request(`/admin/trash/${entity}/${id}/restore`, { method: 'POST' });
      setSuccessToast('Đã khôi phục thực thể thành công!');
      setTimeout(() => setSuccessToast(''), 4000);
      await loadAll();
    } catch (e) {
      alert('Lỗi khi khôi phục: ' + e.message);
    }
  };

  const handlePermanentDelete = async (entity, id) => {
    if (!window.confirm('CẢNH BÁO: Hành động này sẽ xóa vĩnh viễn dữ liệu khỏi D1 SQLite SSOT và không thể hoàn tác. Bạn có chắc chắn muốn tiếp tục?')) {
      return;
    }
    try {
      await request(`/admin/trash/${entity}/${id}/permanent`, { method: 'DELETE' });
      setSuccessToast('Đã xóa vĩnh viễn thực thể khỏi hệ thống.');
      setTimeout(() => setSuccessToast(''), 4000);
      await loadAll();
    } catch (e) {
      alert('Lỗi khi xóa vĩnh viễn: ' + e.message);
    }
  };

  // Reset & Seed actions
  const handleOpenResetModal = async () => {
    try {
      const res = await request('/admin/system/reset-data/preview', { method: 'POST' }).catch(() => null);
      if (res && res.data) {
        setPreviewData(res.data);
      }
      setShowResetModal(true);
      setTypedConfirmation('');
    } catch (e) {
      alert('Lỗi tải thông tin xem trước: ' + e.message);
    }
  };

  const handleExecuteReset = async () => {
    if (typedConfirmation.trim() !== 'RESET DUSTGUARD DATA') {
      alert('Chuỗi xác nhận chưa chính xác. Vui lòng nhập đúng "RESET DUSTGUARD DATA"');
      return;
    }

    setResetting(true);
    try {
      await request('/admin/system/reset-data', {
        method: 'POST',
        body: JSON.stringify({
          mode: resetMode,
          deleteStoredFiles: deleteFiles,
          confirmation: typedConfirmation.trim()
        })
      });

      setShowResetModal(false);
      setSuccessToast(`Thiết lập lại dữ liệu thành công! Chế độ: ${resetMode}`);
      setTimeout(() => setSuccessToast(''), 4000);
      await loadAll();
    } catch (e) {
      alert('Thao tác reset thất bại: ' + (e.message || 'Lỗi không xác định'));
    } finally {
      setResetting(false);
    }
  };

  const handleSeedCanonicalDemo = async () => {
    if (!window.confirm('Nạp bộ dữ liệu mẫu chuẩn hóa (Canonical Dataset) vào hệ thống D1?')) return;
    try {
      setSaving(true);
      await request('/admin/system/seed-demo', { method: 'POST' });
      setSuccessToast('Đã khởi tạo bộ dữ liệu mẫu chuẩn hóa vào D1 SQLite SSOT thành công!');
      setTimeout(() => setSuccessToast(''), 4000);
      await loadAll();
    } catch (e) {
      alert('Lỗi nạp dữ liệu mẫu: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingState message="Đang tải cấu hình và trạng thái hệ thống…" />;
  if (error) return <ErrorState title="Lỗi kết nối" message={error} onRetry={loadAll} />;

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Toast Notification */}
      {successToast && (
        <div className="p-3.5 bg-[#E6F4F1] border border-[#0D6F64] rounded-xl text-xs font-bold text-[#0D6F64] shadow-xs flex items-center justify-between animate-in fade-in">
          <span>✓ {successToast}</span>
          <button type="button" onClick={() => setSuccessToast('')} className="p-1 cursor-pointer">✕</button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#991B1B] bg-[#FEF2F2] px-2.5 py-1 rounded-md border border-[#FECACA]">
            Quản Trị Hệ Thống • D1 SQLite SSOT
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Cấu Hình Quy Chuẩn Bụi & Quản Trị Dữ Liệu
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Thiết lập ngưỡng QCVN 05:2023, tham số Geofence/SLA, quản lý thực thể D1, thùng rác và nạp dữ liệu mẫu.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          {activeTab === 'settings' && (
            <>
              <button
                type="button"
                onClick={handleResetDefault}
                className="flex-1 sm:flex-initial px-4 py-3 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl border border-[#D6D3D1] transition min-h-[48px] flex items-center justify-center cursor-pointer"
              >
                <span>Khôi phục mặc định</span>
              </button>
              <button
                type="submit"
                form="settings-form"
                disabled={saving}
                className="flex-1 sm:flex-initial px-6 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{saving ? 'Đang lưu…' : '💾 Lưu cấu hình'}</span>
              </button>
            </>
          )}
          {activeTab === 'danger' && (
            <button
              type="button"
              onClick={handleSeedCanonicalDemo}
              disabled={saving}
              className="px-5 py-3 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>🌱 Nạp bộ dữ liệu mẫu chuẩn</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-2 shadow-xs flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setActiveTab('settings')}
          className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-[#991B1B] text-white shadow-xs'
              : 'text-[#57534E] hover:bg-[#F5F5F4]'
          }`}
        >
          ⚙️ Quy Chuẩn QCVN 05 & Vận Hành
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('stats')}
          className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] cursor-pointer ${
            activeTab === 'stats'
              ? 'bg-[#991B1B] text-white shadow-xs'
              : 'text-[#57534E] hover:bg-[#F5F5F4]'
          }`}
        >
          📊 Thống Kê Thực Thể D1
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('trash')}
          className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'trash'
              ? 'bg-[#991B1B] text-white shadow-xs'
              : 'text-[#57534E] hover:bg-[#F5F5F4]'
          }`}
        >
          <span>🗑️ Thùng Rác & Khôi Phục</span>
          {trashData?.total > 0 && (
            <span className="px-1.5 py-0.5 text-[10px] bg-red-600 text-white rounded-full font-bold">
              {trashData.total}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('danger')}
          className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-bold text-xs transition min-h-[44px] cursor-pointer ${
            activeTab === 'danger'
              ? 'bg-[#991B1B] text-white shadow-xs'
              : 'text-[#991B1B] hover:bg-[#FEF2F2]'
          }`}
        >
          ⚠️ Vùng Nguy Hiểm (Danger Zone)
        </button>
      </div>

      {/* TAB 1: SETTINGS FORM */}
      {activeTab === 'settings' && (
        <form id="settings-form" onSubmit={handleSave} className="flex flex-col gap-6">
          {/* Form Section 1: QCVN 05:2023/BTNMT Environmental Limits */}
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
            <div className="pb-3 border-b border-[#E7E5E4]">
              <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
                1. Ngưỡng Giới Hạn Bụi & Khí Thải (QCVN 05:2023/BTNMT)
              </h2>
              <p className="text-xs text-[#57534E] mt-0.5">
                Hệ thống tự động phát lệnh kiểm tra và yêu cầu nhà thầu dập bụi khi vượt các ngưỡng sau.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Bụi PM2.5 trung bình 24 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={500}
                  value={settings.pm25Limit24h}
                  onChange={(e) => handleChange('pm25Limit24h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn QCVN: <strong>50 µg/m³</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Bụi PM2.5 cảnh báo 1 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={1000}
                  value={settings.pm25Limit1h}
                  onChange={(e) => handleChange('pm25Limit1h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Kích hoạt cảnh báo khẩn: <strong>100 µg/m³</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Bụi PM10 trung bình 24 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={500}
                  value={settings.pm10Limit24h}
                  onChange={(e) => handleChange('pm10Limit24h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn QCVN: <strong>100 µg/m³</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Tổng bụi lơ lửng TSP 24 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={1000}
                  value={settings.tspLimit24h}
                  onChange={(e) => handleChange('tspLimit24h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn QCVN: <strong>300 µg/m³</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Khí SO2 giới hạn 1 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={settings.so2Limit1h}
                  onChange={(e) => handleChange('so2Limit1h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn QCVN: <strong>350 µg/m³</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Khí NO2 giới hạn 1 giờ (µg/m³)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={settings.no2Limit1h}
                  onChange={(e) => handleChange('no2Limit1h', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn QCVN: <strong>200 µg/m³</strong></span>
              </div>
            </div>
          </div>

          {/* Form Section 2: Operational Geofence & SLA */}
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
            <div className="pb-3 border-b border-[#E7E5E4]">
              <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
                2. Tham Số Geofence GPS & Thời Hạn SLA Khắc Phục
              </h2>
              <p className="text-xs text-[#57534E] mt-0.5">
                Quy định bán kính hợp lệ khi nhà thầu nộp ảnh chụp minh chứng và hạn chót xử lý vụ việc.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Bán kính Geofence hợp lệ (mét)</label>
                <input
                  type="number"
                  required
                  min={10}
                  max={500}
                  value={settings.geofenceBufferMeters}
                  onChange={(e) => handleChange('geofenceBufferMeters', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Chuẩn SSOT: <strong>50 mét</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">SLA Vụ Việc Khẩn Cấp (giờ)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={72}
                  value={settings.slaEmergencyHours}
                  onChange={(e) => handleChange('slaEmergencyHours', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Xử lý dập bụi ngay trong <strong>24 giờ</strong></span>
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">SLA Vụ Việc Tiêu Chuẩn (giờ)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={168}
                  value={settings.slaStandardHours}
                  onChange={(e) => handleChange('slaStandardHours', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-black text-base focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
                <span className="text-[11px] text-[#57534E]">Khảo sát & báo cáo trong <strong>48 giờ</strong></span>
              </div>
            </div>
          </div>

          {/* Form Section 3: Webhooks & Cloudflare Infrastructure */}
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
            <div className="pb-3 border-b border-[#E7E5E4]">
              <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
                3. Kênh Thông Báo Tự Động (Zalo / Telegram / Webhook)
              </h2>
              <p className="text-xs text-[#57534E] mt-0.5">
                Tự động gửi tin nhắn SMS / Zalo ZNS / Telegram Bot tới Chỉ huy trưởng khi có vi phạm.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Zalo OA Webhook Endpoint</label>
                <input
                  type="url"
                  value={settings.zaloWebhookUrl}
                  onChange={(e) => handleChange('zaloWebhookUrl', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-mono text-xs focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
              </div>

              <div className="p-4 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex flex-col gap-1.5">
                <label className="font-bold text-[#1C1917]">Telegram Bot Alert Token</label>
                <input
                  type="text"
                  value={settings.telegramBotToken}
                  onChange={(e) => handleChange('telegramBotToken', e.target.value)}
                  className="w-full px-3 py-2 border border-[#D6D3D1] rounded-lg bg-white text-[#1C1917] font-mono text-xs focus:ring-2 focus:ring-[#991B1B] focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Save Bar */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full sm:w-auto px-8 py-3.5 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{saving ? 'Đang lưu cấu hình…' : 'Xác Nhận & Lưu Cấu Hình Hệ Thống'}</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: SYSTEM DATA STATS */}
      {activeTab === 'stats' && systemStats && (
        <div className="flex flex-col gap-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Công trình (Sites)</div>
              <div className="text-2xl font-black text-[#0D6F64] mt-1">{systemStats.counts?.sites ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Dữ liệu công trình thực địa</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Phản ánh (Complaints)</div>
              <div className="text-2xl font-black text-[#1C1917] mt-1">{systemStats.counts?.complaints ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Từ cộng đồng & thanh niên</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Hồ sơ Vi phạm (Cases)</div>
              <div className="text-2xl font-black text-[#991B1B] mt-1">{systemStats.counts?.cases ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Quy trình 7 bước xử lý</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Minh chứng (Evidences)</div>
              <div className="text-2xl font-black text-[#1C1917] mt-1">{systemStats.counts?.evidences ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Bằng chứng Before/After SHA-256</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Cảm biến IoT (Sensors)</div>
              <div className="text-2xl font-black text-[#0D6F64] mt-1">{systemStats.counts?.sensors ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Trạm quan trắc PM2.5/PM10</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Bản ghi đo (Readings)</div>
              <div className="text-2xl font-black text-[#1C1917] mt-1">{systemStats.counts?.sensorReadings ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Dữ liệu quan trắc thời gian thực</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Biên bản (Inspections)</div>
              <div className="text-2xl font-black text-[#1C1917] mt-1">{systemStats.counts?.inspections ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">QCVN 18:2021/BXD</div>
            </div>

            <div className="p-4 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs">
              <div className="text-[11px] font-bold text-[#57534E] uppercase">Nhật ký Audit Logs</div>
              <div className="text-2xl font-black text-[#0D6F64] mt-1">{systemStats.counts?.auditLogs ?? 0}</div>
              <div className="text-[11px] text-[#78716C] mt-1">Nhật ký bất biến (Append-only)</div>
            </div>
          </div>

          <div className="p-6 bg-white border border-[#E7E5E4] rounded-2xl shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-[#0D6F64] flex items-center gap-2">
              <span>🛡️ Cam Kết Kiến Trúc Dữ Liệu Chuẩn D1 SSOT</span>
            </h3>
            <ul className="text-xs space-y-2 text-[#57534E] list-disc pl-5">
              <li>Mọi thay đổi từ giao diện (Tạo, Sửa, Đổi trạng thái, Xóa) đều được đồng bộ và lưu trữ tức thời vào cơ sở dữ liệu Cloudflare D1.</li>
              <li>Khi xóa thông thường, hệ thống áp dụng cơ chế <strong>Soft Delete</strong> (đánh dấu <code>deletedAt</code>) bảo đảm an toàn dữ liệu.</li>
              <li>Mọi biến động điểm số ưu tiên (CPS) và trạng thái vụ việc đều được lưu vết trong các bảng lịch sử độc lập.</li>
            </ul>
          </div>
        </div>
      )}

      {/* TAB 3: TRASH & RESTORE */}
      {activeTab === 'trash' && (
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
          <div className="pb-3 border-b border-[#E7E5E4]">
            <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
              Danh Sách Thực Thể Trong Thùng Rác (Soft-Deleted)
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Các bản ghi đã bị xóa mềm có thể được khôi phục hoặc xóa vĩnh viễn khỏi D1 SQLite SSOT.
            </p>
          </div>

          {trashData?.total === 0 ? (
            <div className="p-12 text-center text-xs text-[#57534E] italic">
              Thùng rác hiện đang trống. Chưa có thực thể nào bị xóa mềm.
            </div>
          ) : (
            <div className="space-y-3">
              {trashData?.sites?.map((site) => (
                <div key={site.id} className="p-4 border border-[#E7E5E4] rounded-xl bg-[#FAFAF9] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <div className="font-bold text-xs text-[#1C1917]">[Công trình] {site.name} ({site.code})</div>
                    <div className="text-[11px] text-[#78716C] mt-0.5">Xóa lúc: {new Date(site.deletedAt).toLocaleString('vi-VN')}</div>
                  </div>
                  <div className="flex gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => handleRestore('sites', site.id)}
                      className="flex-1 sm:flex-initial px-3.5 py-2 bg-[#0D6F64] hover:bg-[#0A564D] text-white text-xs font-bold rounded-xl min-h-[40px] cursor-pointer"
                    >
                      Khôi phục
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePermanentDelete('sites', site.id)}
                      className="flex-1 sm:flex-initial px-3.5 py-2 bg-[#991B1B] hover:bg-[#7F1D1D] text-white text-xs font-bold rounded-xl min-h-[40px] cursor-pointer"
                    >
                      Xóa vĩnh viễn
                    </button>
                  </div>
                </div>
              ))}

              {trashData?.complaints?.map((comp) => (
                <div key={comp.id} className="p-4 border border-[#E7E5E4] rounded-xl bg-[#FAFAF9] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <div className="font-bold text-xs text-[#1C1917]">[Phản ánh] {comp.code} — {comp.ward}</div>
                    <div className="text-[11px] text-[#78716C] mt-0.5">{comp.description?.substring(0, 80)}...</div>
                  </div>
                  <div className="flex gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => handleRestore('complaints', comp.id)}
                      className="flex-1 sm:flex-initial px-3.5 py-2 bg-[#0D6F64] hover:bg-[#0A564D] text-white text-xs font-bold rounded-xl min-h-[40px] cursor-pointer"
                    >
                      Khôi phục
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePermanentDelete('complaints', comp.id)}
                      className="flex-1 sm:flex-initial px-3.5 py-2 bg-[#991B1B] hover:bg-[#7F1D1D] text-white text-xs font-bold rounded-xl min-h-[40px] cursor-pointer"
                    >
                      Xóa vĩnh viễn
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: DANGER ZONE */}
      {activeTab === 'danger' && (
        <div className="p-6 bg-white border-2 border-[#991B1B]/30 rounded-2xl shadow-xs space-y-4">
          <div className="flex items-center gap-3 text-[#991B1B]">
            <h3 className="font-black text-base">⚠️ Khu Vực Nguy Hiểm (Danger Zone)</h3>
          </div>
          <p className="text-xs text-[#57534E]">
            Chức năng cho phép người quản trị làm sạch toàn bộ dữ liệu nghiệp vụ (Công trình, phản ánh, hồ sơ vi phạm, lịch sử đo đạc) để đưa hệ thống về trạng thái ban đầu hoặc khởi tạo lại bộ dữ liệu mẫu chuẩn hóa.
          </p>
          <div className="p-4 bg-[#FEF2F2] border border-[#FECACA] rounded-xl text-xs space-y-1.5 text-[#991B1B]">
            <div>• Cấu trúc cơ sở dữ liệu (Schema) và các migration vẫn được bảo toàn nguyên vẹn.</div>
            <div>• Tài khoản người dùng Quản trị viên và dữ liệu văn bản quy chuẩn pháp luật được giữ lại an toàn.</div>
            <div>• Hành động này bắt buộc xác nhận bảo mật và được ghi nhận bất biến trong Nhật ký Audit Trail.</div>
          </div>
          <div className="flex flex-wrap gap-3 pt-2">
            <button
              type="button"
              onClick={handleOpenResetModal}
              className="px-5 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] cursor-pointer"
            >
              Xóa toàn bộ dữ liệu & Làm lại từ đầu...
            </button>
            <button
              type="button"
              onClick={handleSeedCanonicalDemo}
              disabled={saving}
              className="px-5 py-3 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] cursor-pointer"
            >
              Nạp bộ dữ liệu mẫu chuẩn hóa
            </button>
          </div>
        </div>
      )}

      {/* RESET CONFIRMATION MODAL */}
      {showResetModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#991B1B] max-w-lg w-full rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5 text-[#1C1917]">
            <div className="flex items-center gap-3 border-b border-[#E7E5E4] pb-3">
              <div>
                <h2 className="font-black text-base text-[#991B1B]">Xác nhận Xóa toàn bộ dữ liệu hệ thống</h2>
                <p className="text-xs text-[#78716C] mt-0.5">Thao tác quản trị cấp cao với dữ liệu hệ thống D1</p>
              </div>
            </div>

            {/* Mode selection */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-[#57534E]">Chọn chế độ thực thi:</label>
              <div className="grid grid-cols-2 gap-3">
                <label className={`p-3 border rounded-xl cursor-pointer text-xs flex flex-col justify-between ${
                  resetMode === 'EMPTY' ? 'border-[#0D6F64] bg-[#E6F4F1] font-bold' : 'border-[#E7E5E4]'
                }`}>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="resetMode"
                      checked={resetMode === 'EMPTY'}
                      onChange={() => setResetMode('EMPTY')}
                      className="accent-[#0D6F64]"
                    />
                    <span>Làm sạch (EMPTY)</span>
                  </div>
                  <span className="text-[11px] font-normal text-[#78716C] mt-1">Xóa toàn bộ, về trạng thái trắng</span>
                </label>
                <label className={`p-3 border rounded-xl cursor-pointer text-xs flex flex-col justify-between ${
                  resetMode === 'RESET_AND_SEED' ? 'border-[#0D6F64] bg-[#E6F4F1] font-bold' : 'border-[#E7E5E4]'
                }`}>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="resetMode"
                      checked={resetMode === 'RESET_AND_SEED'}
                      onChange={() => setResetMode('RESET_AND_SEED')}
                      className="accent-[#0D6F64]"
                    />
                    <span>Nạp mẫu (RESET_AND_SEED)</span>
                  </div>
                  <span className="text-[11px] font-normal text-[#78716C] mt-1">Tạo lại dataset mẫu chuẩn</span>
                </label>
              </div>
            </div>

            {/* Options */}
            <div className="p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl">
              <label className="flex items-center gap-2 text-xs cursor-pointer font-bold">
                <input
                  type="checkbox"
                  checked={deleteFiles}
                  onChange={(e) => setDeleteFiles(e.target.checked)}
                  className="accent-[#991B1B] w-4 h-4"
                />
                <span>Xóa toàn bộ tệp hình ảnh đính kèm trên kho lưu trữ đám mây R2</span>
              </label>
            </div>

            {/* Confirmation input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#991B1B]">
                Để xác nhận, vui lòng gõ chính xác: <span className="underline select-all font-mono">RESET DUSTGUARD DATA</span>
              </label>
              <input
                type="text"
                value={typedConfirmation}
                onChange={(e) => setTypedConfirmation(e.target.value)}
                placeholder="RESET DUSTGUARD DATA"
                className="w-full p-2.5 bg-white border-2 border-[#991B1B] rounded-xl font-mono text-xs focus:outline-none"
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-3 border-t border-[#E7E5E4]">
              <button
                type="button"
                onClick={() => setShowResetModal(false)}
                disabled={resetting}
                className="px-4 py-2.5 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl min-h-[44px] cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleExecuteReset}
                disabled={typedConfirmation.trim() !== 'RESET DUSTGUARD DATA' || resetting}
                className={`px-5 py-2.5 text-white font-bold text-xs rounded-xl min-h-[44px] transition ${
                  typedConfirmation.trim() === 'RESET DUSTGUARD DATA' && !resetting
                    ? 'bg-[#991B1B] hover:bg-[#7F1D1D] cursor-pointer'
                    : 'bg-[#991B1B]/40 cursor-not-allowed'
                }`}
              >
                {resetting ? 'Đang thực thi reset...' : 'XÁC NHẬN XÓA TOÀN BỘ'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
