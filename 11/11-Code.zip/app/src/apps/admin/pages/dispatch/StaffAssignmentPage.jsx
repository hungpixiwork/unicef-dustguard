import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function StaffAssignmentPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [cases, setCases] = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);
  const [selectedStaff, setSelectedStaff] = useState('usr-staff-01');
  const [assigning, setAssigning] = useState(false);

  // List of active inspectors with real workloads
  const staffList = [
    {
      id: 'usr-staff-01',
      name: 'Đặng Thanh Tra',
      role: 'Thanh tra Môi trường Quận',
      activeCases: 2,
      lat: 21.0362,
      lng: 105.7834,
      status: 'AVAILABLE',
      distanceText: '1.2 km (Gần nhất)',
      recommended: true
    },
    {
      id: 'usr-staff-02',
      name: 'Nguyễn Văn Cán Bộ',
      role: 'Tổ công tác QCVN 18',
      activeCases: 4,
      lat: 21.0285,
      lng: 105.8542,
      status: 'BUSY',
      distanceText: '4.8 km',
      recommended: false
    },
    {
      id: 'usr-staff-03',
      name: 'Trần Thị Giám Sát',
      role: 'Cán bộ Địa bàn ĐT743',
      activeCases: 1,
      lat: 21.0112,
      lng: 105.7981,
      status: 'AVAILABLE',
      distanceText: '2.5 km',
      recommended: false
    }
  ];

  useEffect(() => {
    async function loadUnassignedCases() {
      try {
        setLoading(true);
        const res = await request('/cases').catch(() => []);
        const list = normalizeList(res);
        setCases(list);
        if (list.length > 0) {
          setSelectedCase(list[0]);
        }
      } catch {
        setCases([]);
      } finally {
        setLoading(false);
      }
    }
    loadUnassignedCases();
  }, []);

  const handleAssignSubmit = async () => {
    if (!selectedCase) return;
    try {
      setAssigning(true);
      await request(`/cases/${selectedCase.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          assignedTo: selectedStaff,
          status: 'IN_PROGRESS'
        })
      });

      alert(`Đã phân công hồ sơ ${selectedCase.code || selectedCase.title} cho cán bộ thành công!`);
      navigate('/admin/cases');
    } catch (err) {
      console.error('[StaffAssignment Error]', err);
      alert(err.message || 'Không thể hoàn tất phân công. Vui lòng thử lại.');
    } finally {
      setAssigning(false);
    }
  };

  if (loading) return <LoadingState message="Đang nạp dữ liệu điều phối và cán bộ…" />;

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-16">
      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Điều Phối & Phân Công Nhân Sự
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Phân Công Cán Bộ Hiện Trường
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Bản đồ vị trí, tải công việc (workload) và gợi ý cán bộ gần nhất. Người quản lý toàn quyền quyết định.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => navigate('/admin/dispatch')}
            className="px-4 py-2.5 bg-white border border-[#E7E5E4] hover:bg-[#FAFAF9] text-[#1C1917] font-bold text-xs rounded-xl shadow-2xs min-h-[44px]"
          >
            ← Trung tâm phản ánh
          </button>
          <button
            type="button"
            onClick={handleAssignSubmit}
            disabled={assigning || !selectedCase}
            className="px-5 py-2.5 bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span>✓</span>
            <span>{assigning ? 'Đang phân công…' : 'Xác nhận phân công'}</span>
          </button>
        </div>
      </div>

      {/* 2. Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column (5 cols): Danh sách hồ sơ & Thông tin hồ sơ chọn */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs space-y-3">
            <div className="text-xs font-black uppercase text-[#57534E] tracking-wider">
              1. Chọn hồ sơ cần xử lý ({cases.length})
            </div>

            <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
              {cases.map((c) => {
                const isSelected = selectedCase?.id === c.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedCase(c)}
                    className={`p-3 rounded-xl border-2 cursor-pointer transition flex flex-col gap-1 ${
                      isSelected
                        ? 'border-[#9F241F] bg-[#FEF2F2]/40 shadow-xs'
                        : 'border-[#E7E5E4] bg-white hover:bg-[#FAFAF9]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-extrabold text-[#9F241F]">
                        {c.code || c.id}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#FAFAF9] border border-[#E7E5E4]">
                        {c.priority || 'MEDIUM'}
                      </span>
                    </div>
                    <div className="font-bold text-xs text-[#1C1917] line-clamp-1 leading-snug">
                      {c.title || c.site?.name || 'Vụ việc phát tán bụi'}
                    </div>
                    <div className="text-[11px] text-[#78716C] line-clamp-1">
                      📍 {c.site?.address || 'Hà Nội'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Case Quick Summary */}
          {selectedCase && (
            <div className="bg-[#FAFAF9] border border-[#E7E5E4] rounded-2xl p-4 text-xs space-y-2">
              <div className="font-black text-[#1C1917] uppercase text-[11px]">
                Chi tiết hồ sơ đang chọn
              </div>
              <div>
                <span className="text-[#78716C]">Công trình: </span>
                <span className="font-bold text-[#1C1917]">{selectedCase.site?.name || selectedCase.title}</span>
              </div>
              <div>
                <span className="text-[#78716C]">Hạn SLA: </span>
                <span className="font-bold text-[#9F241F]">📅 48 giờ (Tiêu chuẩn)</span>
              </div>
              <div>
                <span className="text-[#78716C]">Hiện trạng cán bộ: </span>
                <span className="font-bold text-[#B45309]">
                  {selectedCase.assignedTo ? 'Đã có cán bộ tiếp nhận' : 'Chưa phân công'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column (7 cols): Danh sách cán bộ & Tải công việc */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-black uppercase text-[#57534E] tracking-wider">
                2. Chọn cán bộ phụ trách thực địa
              </div>
              <span className="text-[11px] text-[#0D6F64] font-bold">
                {staffList.filter(s => s.status === 'AVAILABLE').length} cán bộ sẵn sàng
              </span>
            </div>

            <div className="space-y-3">
              {staffList.map((staff) => {
                const isSelected = selectedStaff === staff.id;
                return (
                  <div
                    key={staff.id}
                    onClick={() => setSelectedStaff(staff.id)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isSelected
                        ? 'border-[#0D6F64] bg-[#F0FDFA]/50 shadow-xs ring-1 ring-[#0D6F64]'
                        : 'border-[#E7E5E4] bg-white hover:bg-[#FAFAF9]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#1C1917] text-white flex items-center justify-center font-black text-xs shrink-0">
                        {staff.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-black text-sm text-[#1C1917]">{staff.name}</span>
                          {staff.recommended && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-[#FEF2F2] text-[#9F241F] border border-[#FCA5A5]/40">
                              ⭐ Gợi ý gần nhất
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-[#57534E] mt-0.5">{staff.role}</div>
                        <div className="text-[11px] text-[#78716C] mt-1 flex items-center gap-3">
                          <span>📍 Khoảng cách: <b>{staff.distanceText}</b></span>
                          <span>📋 Đang xử lý: <b>{staff.activeCases} vụ việc</b></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-black ${
                        staff.status === 'AVAILABLE' ? 'bg-[#F0FDF4] text-[#15803D]' : 'bg-[#FFFBEB] text-[#B45309]'
                      }`}>
                        {staff.status === 'AVAILABLE' ? 'Sẵn sàng' : 'Đang bận'}
                      </span>
                      <input
                        type="radio"
                        name="staffSelect"
                        checked={isSelected}
                        onChange={() => setSelectedStaff(staff.id)}
                        className="w-4 h-4 text-[#0D6F64] cursor-pointer"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick SLA Commitment Bar */}
          <div className="bg-[#F0FDFA] border border-[#CCFBF1] rounded-2xl p-4 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="text-base">⚡</span>
              <span className="font-bold text-[#0D6F64]">
                Sau khi phân công: Cán bộ sẽ nhận thông báo tức thời và có 24h để kiểm tra hiện trường.
              </span>
            </div>
            <button
              type="button"
              onClick={handleAssignSubmit}
              disabled={assigning}
              className="px-4 py-2 bg-[#0D6F64] hover:bg-[#0A564D] text-white font-bold rounded-xl shrink-0 cursor-pointer"
            >
              Giao việc
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
