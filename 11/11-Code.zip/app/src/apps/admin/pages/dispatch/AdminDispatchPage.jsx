import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState, StatusBadge } from '../../../../shared/components/StatusBadge.jsx';
import {
  Send,
  Building2,
  UserCheck,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Search,
  Filter,
  ArrowRight,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

const DEFAULT_STAFF_OFFICERS = [
  { id: 'usr-staff-01', fullName: 'Đặng Thanh Tra (Thanh tra Môi trường)', email: 'staff@dustguard.vn', role: 'staff' },
  { id: 'usr-staff-02', fullName: 'Nguyễn Văn Cán Bộ (Tổ công tác QCVN 18)', email: 'canbo@dustguard.vn', role: 'staff' },
  { id: 'usr-admin-01', fullName: 'Nguyễn Quản Trị (Điều phối viên)', email: 'admin@dustguard.vn', role: 'admin' }
];

export default function AdminDispatchPage() {
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [sites, setSites] = useState([]);
  const [staffUsers, setStaffUsers] = useState(DEFAULT_STAFF_OFFICERS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter & Search
  const [filterTab, setFilterTab] = useState('UNASSIGNED'); // ALL | UNASSIGNED | ASSIGNED
  const [searchQuery, setSearchQuery] = useState('');

  // Dispatch Modal State
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [dispatchModalOpen, setDispatchModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [dispatchForm, setDispatchForm] = useState({
    siteId: '',
    assignedTo: DEFAULT_STAFF_OFFICERS[0].id,
    priority: 'HIGH',
    dueHours: 48,
    note: ''
  });

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [compRes, sitesRes, usersRes] = await Promise.all([
        request('/complaints').catch(() => []),
        request('/sites').catch(() => []),
        request('/users').catch(() => [])
      ]);

      const compList = normalizeList(compRes);
      const sitesList = normalizeList(sitesRes);
      const usersList = normalizeList(usersRes);

      setComplaints(compList);
      setSites(sitesList);

      // Filter staff/inspectors
      const activeStaff = usersList.filter(u => 
        ['staff', 'inspector', 'admin'].includes((u.role || '').toLowerCase())
      );
      const finalStaff = activeStaff.length > 0 ? activeStaff : DEFAULT_STAFF_OFFICERS;
      setStaffUsers(finalStaff);

      // Set default site if available
      if (sitesList.length > 0 && !dispatchForm.siteId) {
        setDispatchForm(prev => ({ ...prev, siteId: sitesList[0].id }));
      }
      if (finalStaff.length > 0) {
        setDispatchForm(prev => ({ ...prev, assignedTo: finalStaff[0].id }));
      }
    } catch (err) {
      setError(err.message || 'Lỗi nạp dữ liệu điều phối');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Open Dispatch Modal
  const openDispatch = (complaint) => {
    setSelectedComplaint(complaint);
    setDispatchForm({
      siteId: complaint.siteId || (sites[0]?.id || ''),
      assignedTo: staffUsers[0]?.id || 'usr-staff-01',
      priority: complaint.priority || 'HIGH',
      dueHours: 48,
      note: `Điều phối từ phản ánh công dân ${complaint.code || complaint.id}`
    });
    setDispatchModalOpen(true);
  };

  // Submit Dispatch & Create Case
  const handleDispatchSubmit = async (e) => {
    e.preventDefault();
    if (!selectedComplaint) return;

    try {
      setSubmitting(true);
      const deadline = new Date(Date.now() + Number(dispatchForm.dueHours) * 3600 * 1000).toISOString();
      const staffObj = staffUsers.find(u => u.id === dispatchForm.assignedTo);
      const staffName = staffObj?.fullName || staffObj?.name || 'Cán bộ Thanh tra';

      // 1. Create Case in D1
      const casePayload = {
        siteId: dispatchForm.siteId,
        complaintId: selectedComplaint.id,
        title: `Xử lý phản ánh: ${selectedComplaint.description?.slice(0, 70) || 'Ô nhiễm bụi'}`,
        description: selectedComplaint.description,
        priority: dispatchForm.priority,
        status: 'OPEN',
        assignedTo: staffName,
        slaDeadline: deadline,
        sourceType: 'COMPLAINT',
        sourceId: selectedComplaint.id
      };

      await request('/cases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(casePayload)
      });

      // 2. Close modal & reload
      setDispatchModalOpen(false);
      setSelectedComplaint(null);
      await loadData();
    } catch (err) {
      alert(`Lỗi khi tạo hồ sơ điều phối: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // Filter complaints
  const filteredComplaints = complaints.filter(c => {
    const isAssigned = c.cases && c.cases.length > 0;
    if (filterTab === 'UNASSIGNED' && isAssigned) return false;
    if (filterTab === 'ASSIGNED' && !isAssigned) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const code = (c.code || '').toLowerCase();
      const desc = (c.description || '').toLowerCase();
      const addr = (c.address || '').toLowerCase();
      const reporter = (c.reporterName || '').toLowerCase();
      return code.includes(q) || desc.includes(q) || addr.includes(q) || reporter.includes(q);
    }
    return true;
  });

  if (loading) return <LoadingState message="Đang nạp danh sách phản ánh công dân..." />;
  if (error) return <ErrorState title="Lỗi điều phối" message={error} onRetry={loadData} />;

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64] bg-[#E6F4F1] px-2.5 py-1 rounded-md border border-[#B2DFDB]">
            Điều Phối Tác Nghiệp
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Trung Tâm Tiếp Nhận & Phân Công Vụ Việc
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Xác minh phản ánh cộng đồng, liên kết công trình xây dựng, khởi tạo hồ sơ và phân công cán bộ thanh tra hiện trường.
          </p>
        </div>

        <div className="flex gap-2 w-full sm:w-auto">
          <button
            onClick={() => navigate('/admin/cases')}
            className="px-4 py-2.5 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer min-h-[44px]"
          >
            <span>Quản lý Vụ việc</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tabs & Search Bar */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 border-b sm:border-b-0 border-[#E7E5E4] pb-2 sm:pb-0 overflow-x-auto">
          <button
            onClick={() => setFilterTab('UNASSIGNED')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition min-h-[44px] whitespace-nowrap cursor-pointer ${
              filterTab === 'UNASSIGNED'
                ? 'bg-[#991B1B] text-white'
                : 'bg-[#FAFAF9] text-[#57534E] hover:bg-[#FEF2F2] hover:text-[#991B1B]'
            }`}
          >
            Chưa điều phối ({complaints.filter(c => !(c.cases && c.cases.length > 0)).length})
          </button>
          <button
            onClick={() => setFilterTab('ASSIGNED')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition min-h-[44px] whitespace-nowrap cursor-pointer ${
              filterTab === 'ASSIGNED'
                ? 'bg-[#0D6F64] text-white'
                : 'bg-[#FAFAF9] text-[#57534E] hover:bg-[#E6F4F1] hover:text-[#0D6F64]'
            }`}
          >
            Đã lập hồ sơ vụ việc ({complaints.filter(c => c.cases && c.cases.length > 0).length})
          </button>
          <button
            onClick={() => setFilterTab('ALL')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition min-h-[44px] whitespace-nowrap cursor-pointer ${
              filterTab === 'ALL'
                ? 'bg-[#1C1917] text-white'
                : 'bg-[#FAFAF9] text-[#57534E] hover:bg-[#E7E5E4]'
            }`}
          >
            Tất cả ({complaints.length})
          </button>
        </div>

        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 text-[#78716C] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm theo mã, địa chỉ, người gửi..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs font-medium focus:outline-hidden focus:border-[#991B1B] focus:bg-white min-h-[44px]"
          />
        </div>
      </div>

      {/* Complaints List */}
      <div className="flex flex-col gap-3">
        {filteredComplaints.length === 0 ? (
          <div className="bg-white border border-[#E7E5E4] rounded-2xl p-12 text-center text-[#78716C]">
            <CheckCircle2 className="w-12 h-12 text-[#0D6F64] mx-auto mb-3 opacity-80" />
            <p className="text-sm font-bold text-[#1C1917]">Không có phản ánh nào trong danh sách</p>
            <p className="text-xs text-[#78716C] mt-1">Toàn bộ phản ánh người dân đã được điều phối xử lý kịp thời.</p>
          </div>
        ) : (
          filteredComplaints.map((item) => {
            const hasCase = item.cases && item.cases.length > 0;
            const associatedCase = hasCase ? item.cases[0] : null;

            return (
              <div
                key={item.id || item.code}
                className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:border-[#FECACA] transition"
              >
                <div className="flex flex-col gap-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-black text-[#991B1B] bg-[#FEF2F2] px-2 py-0.5 rounded border border-[#FECACA]">
                      {item.code || item.id?.slice(0, 8)}
                    </span>
                    <StatusBadge status={item.status} />
                    <span className="text-[11px] text-[#78716C]">
                      • Gửi lúc {new Date(item.createdAt || Date.now()).toLocaleString('vi-VN')}
                    </span>
                    {hasCase && (
                      <span className="bg-[#E6F4F1] text-[#0D6F64] text-[10px] font-black px-2 py-0.5 rounded border border-[#B2DFDB] flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Đã lập Case: {associatedCase.code || associatedCase.id?.slice(0, 8)}
                      </span>
                    )}
                  </div>

                  <h3 className="text-sm sm:text-base font-black text-[#1C1917] break-words">
                    {item.description || 'Ô nhiễm bụi phát tán'}
                  </h3>

                  <div className="flex items-center gap-4 text-xs text-[#57534E] flex-wrap">
                    <span>📍 <strong>Vị trí:</strong> {item.address || item.ward || 'Hà Nội'}</span>
                    <span>👤 <strong>Người báo:</strong> {item.reporterName || 'Công dân ẩn danh'} {item.reporterPhone && `(${item.reporterPhone})`}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0 self-end md:self-center">
                  {!hasCase ? (
                    <button
                      onClick={() => openDispatch(item)}
                      className="px-4 py-2.5 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer min-h-[44px]"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Điều phối & Lập Case</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => navigate(`/staff/cases/${associatedCase.id}`)}
                      className="px-4 py-2.5 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl border border-[#D6D3D1] transition flex items-center gap-1.5 cursor-pointer min-h-[44px]"
                    >
                      <span>Xem chi tiết Case</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Dispatch Modal */}
      {dispatchModalOpen && selectedComplaint && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E7E5E4] shadow-2xl max-w-lg w-full p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <span className="text-[11px] font-black uppercase tracking-wider text-[#991B1B]">
                  Xác minh & Phân công
                </span>
                <h2 className="text-base font-black text-[#1C1917] mt-0.5">
                  Điều Phối Vụ Việc Từ Phản Ánh #{selectedComplaint.code}
                </h2>
              </div>
              <button
                onClick={() => setDispatchModalOpen(false)}
                className="text-[#78716C] hover:text-[#1C1917] text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleDispatchSubmit} className="flex flex-col gap-4">
              {/* 1. Select Associated Site */}
              <div>
                <label className="block text-xs font-bold text-[#1C1917] mb-1">
                  1. Gắn vào Công trình Xây dựng liên đới *
                </label>
                <select
                  value={dispatchForm.siteId}
                  onChange={(e) => setDispatchForm({ ...dispatchForm, siteId: e.target.value })}
                  required
                  className="w-full px-3 py-2.5 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs font-medium focus:outline-hidden focus:border-[#991B1B] min-h-[44px]"
                >
                  {sites.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code || 'Chưa có mã'} - {s.ward || s.address})
                    </option>
                  ))}
                </select>
              </div>

              {/* 2. Assign Field Inspector */}
              <div>
                <label className="block text-xs font-bold text-[#1C1917] mb-1">
                  2. Phân công Cán bộ Thanh tra phụ trách *
                </label>
                <select
                  value={dispatchForm.assignedTo}
                  onChange={(e) => setDispatchForm({ ...dispatchForm, assignedTo: e.target.value })}
                  required
                  className="w-full px-3 py-2.5 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs font-medium focus:outline-hidden focus:border-[#991B1B] min-h-[44px]"
                >
                  {staffUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName || u.name} ({u.role?.toUpperCase()} - {u.email})
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Priority & SLA */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#1C1917] mb-1">
                    3. Mức độ Ưu tiên
                  </label>
                  <select
                    value={dispatchForm.priority}
                    onChange={(e) => setDispatchForm({ ...dispatchForm, priority: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs font-bold focus:outline-hidden focus:border-[#991B1B] min-h-[44px]"
                  >
                    <option value="CRITICAL">🔴 Cấp bách (PM10 cao)</option>
                    <option value="HIGH">🟠 Cao (Gần trường/viện)</option>
                    <option value="MEDIUM">🟡 Trung bình</option>
                    <option value="LOW">🟢 Thấp</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1C1917] mb-1">
                    4. Thời hạn SLA xử lý
                  </label>
                  <select
                    value={dispatchForm.dueHours}
                    onChange={(e) => setDispatchForm({ ...dispatchForm, dueHours: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl text-xs font-medium focus:outline-hidden focus:border-[#991B1B] min-h-[44px]"
                  >
                    <option value={24}>24 giờ (Khẩn cấp)</option>
                    <option value={48}>48 giờ (Tiêu chuẩn)</option>
                    <option value={72}>72 giờ</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E7E5E4] mt-2">
                <button
                  type="button"
                  onClick={() => setDispatchModalOpen(false)}
                  className="px-4 py-2.5 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl transition min-h-[44px] cursor-pointer"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2.5 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 min-h-[44px] cursor-pointer disabled:opacity-50"
                >
                  {submitting ? 'Đang khởi tạo...' : 'Xác nhận Điều phối'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
