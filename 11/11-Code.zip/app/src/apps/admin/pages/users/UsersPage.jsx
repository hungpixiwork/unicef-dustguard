import React, { useState, useEffect } from 'react';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState, ErrorState, EmptyState } from '../../../../shared/components/StatusBadge.jsx';

const ROLE_LABELS = {
  citizen: { label: 'Công dân', badge: 'bg-[#F5F5F4] text-[#57534E] border-[#E7E5E4]' },
  community: { label: 'Thanh niên', badge: 'bg-[#E6F4F1] text-[#0D6F64] border-[#B2DFDB]' },
  staff: { label: 'Cán bộ', badge: 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]' },
  contractor: { label: 'Nhà thầu', badge: 'bg-[#FEF2F2] text-[#991B1B] border-[#FECACA]' },
  executive: { label: 'Lãnh đạo', badge: 'bg-[#EDE9FE] text-[#6D28D9] border-[#DDD6FE]' },
  admin: { label: 'Quản trị', badge: 'bg-[#FEE2E2] text-[#B91C1C] border-[#FECACA]' }
};

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterRole, setFilterRole] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [updatingId, setUpdatingId] = useState(null);
  const [successToast, setSuccessToast] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New user form state
  const [newUser, setNewUser] = useState({
    fullName: '',
    email: '',
    role: 'citizen',
    organization: '',
    phone: ''
  });

  const loadUsers = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await request('/users').catch(() => []);
      const items = normalizeList(res);
      setUsers(items);
    } catch (err) {
      setError(err.message || 'Không thể tải danh sách tài khoản');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleRoleChange = async (userId, newRole) => {
    try {
      setUpdatingId(userId);
      await request(`/users/${encodeURIComponent(userId)}/role`, {
        method: 'PUT',
        body: JSON.stringify({ role: newRole })
      }).catch(async () => {
        return request(`/users/${encodeURIComponent(userId)}/role`, {
          method: 'PATCH',
          body: JSON.stringify({ role: newRole })
        });
      });

      setUsers((prev) =>
        (Array.isArray(prev) ? prev : []).map((u) =>
          u.id === userId ? { ...u, role: newRole } : u
        )
      );
      setSuccessToast(`Đã cập nhật vai trò người dùng thành "${ROLE_LABELS[newRole]?.label || newRole}" thành công!`);
      setTimeout(() => setSuccessToast(''), 4000);
    } catch (err) {
      alert(err.message || 'Không thể cập nhật quyền người dùng');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleToggleStatus = async (user) => {
    const isCurrentlyActive = (user.status || 'ACTIVE').toUpperCase() === 'ACTIVE';
    const nextStatus = isCurrentlyActive ? 'DISABLED' : 'ACTIVE';
    const actionText = isCurrentlyActive ? 'Khóa' : 'Mở khóa';

    try {
      setUpdatingId(user.id);
      await request(`/users/${encodeURIComponent(user.id)}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status: nextStatus })
      }).catch(async () => {
        return request(`/users/${encodeURIComponent(user.id)}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: nextStatus })
        });
      });

      setUsers((prev) =>
        (Array.isArray(prev) ? prev : []).map((u) =>
          u.id === user.id ? { ...u, status: nextStatus } : u
        )
      );
      setSuccessToast(`Đã ${actionText.toLowerCase()} tài khoản "${user.fullName || user.email}" thành công!`);
      setTimeout(() => setSuccessToast(''), 4000);
    } catch (err) {
      alert(err.message || 'Không thể cập nhật trạng thái tài khoản');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    try {
      const created = await request('/users', {
        method: 'POST',
        body: JSON.stringify({
          fullName: newUser.fullName.trim(),
          name: newUser.fullName.trim(),
          email: newUser.email.trim(),
          role: newUser.role,
          department: newUser.organization.trim(),
          organization: newUser.organization.trim(),
          phoneNumber: newUser.phone.trim(),
          phone: newUser.phone.trim(),
          status: 'ACTIVE'
        })
      });

      const createdUser = created?.data || created;
      setUsers((prev) => [createdUser, ...(Array.isArray(prev) ? prev : [])]);
      setShowAddModal(false);
      setNewUser({ fullName: '', email: '', role: 'citizen', organization: '', phone: '' });
      setSuccessToast(`Đã thêm tài khoản "${createdUser.fullName || createdUser.name || createdUser.email}" thành công vào D1 SSOT!`);
      setTimeout(() => setSuccessToast(''), 4000);
      await loadUsers();
    } catch (err) {
      alert(err.message || 'Lỗi khi thêm người dùng mới');
    }
  };

  if (loading) return <LoadingState message="Đang tải danh sách tài khoản…" />;
  if (error) return <ErrorState title="Lỗi tải dữ liệu" message={error} onRetry={loadUsers} />;

  const userList = Array.isArray(users) ? users : [];
  const filtered = userList.filter((u) => {
    const matchesRole = filterRole === 'ALL' || (u.role || 'citizen').toLowerCase() === filterRole.toLowerCase();
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = !query ||
      (u.fullName || u.name || '').toLowerCase().includes(query) ||
      (u.email || '').toLowerCase().includes(query) ||
      (u.organization || u.department || '').toLowerCase().includes(query);
    return matchesRole && matchesSearch;
  });

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Toast Notification */}
      {successToast && (
        <div className="p-3.5 bg-[#E6F4F1] border border-[#0D6F64] rounded-xl text-xs font-bold text-[#0D6F64] shadow-xs flex items-center justify-between animate-in fade-in">
          <span>✓ {successToast}</span>
          <button type="button" onClick={() => setSuccessToast('')} className="p-1 cursor-pointer">✕</button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#991B1B] bg-[#FEF2F2] px-2.5 py-1 rounded-md border border-[#FECACA]">
            Phân Quyền RBAC 5 Nhóm • D1 SQLite SSOT
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Quản Lý Tài Khoản & Phân Quyền Tác Nghiệp
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Thiết lập vai trò tác nghiệp trực tiếp in-place: Công dân, Thanh niên tình nguyện, Cán bộ thanh tra, Nhà thầu và Lãnh đạo.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="w-full sm:w-auto px-5 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer shrink-0"
        >
          <span>＋ Thêm tài khoản mới</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="w-full sm:w-72">
          <input
            type="text"
            placeholder="Tìm theo họ tên, email, đơn vị…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3.5 py-2.5 text-xs border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px]"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-bold text-[#57534E] shrink-0">Lọc vai trò:</span>
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="flex-1 sm:flex-initial px-3.5 py-2.5 text-xs font-bold border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px] cursor-pointer"
          >
            <option value="ALL">Tất cả vai trò ({userList.length})</option>
            <option value="citizen">Công dân (Citizen)</option>
            <option value="community">Thanh niên (Community)</option>
            <option value="staff">Cán bộ thanh tra (Staff)</option>
            <option value="contractor">Nhà thầu (Contractor)</option>
            <option value="executive">Lãnh đạo Sở (Executive)</option>
            <option value="admin">Quản trị viên (Admin)</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl shadow-xs overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#57534E]">
            Không tìm thấy tài khoản nào phù hợp với điều kiện tìm kiếm.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#1C1917] border-collapse min-w-[720px]">
              <thead>
                <tr className="bg-[#F5F5F4] border-b border-[#E7E5E4] text-[#57534E] font-extrabold uppercase text-[10px] tracking-wider">
                  <th className="py-3.5 px-4">Họ và Tên</th>
                  <th className="py-3.5 px-4">Email</th>
                  <th className="py-3.5 px-4">Vai Trò</th>
                  <th className="py-3.5 px-4">Đơn Vị Công Tác</th>
                  <th className="py-3.5 px-4 text-center">Trạng Thái</th>
                  <th className="py-3.5 px-4 text-right">Điều Chỉnh Vai Trò & Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E7E5E4]">
                {filtered.map((u) => {
                  const roleKey = (u.role || 'citizen').toLowerCase();
                  const roleCfg = ROLE_LABELS[roleKey] || ROLE_LABELS.citizen;
                  const isUpdating = updatingId === u.id;
                  const isActive = (u.status || 'ACTIVE').toUpperCase() === 'ACTIVE';

                  return (
                    <tr key={u.id} className="hover:bg-[#FAFAF9] transition">
                      <td className="py-3.5 px-4 font-bold text-[#1C1917] break-words max-w-[200px]">
                        <div>{u.fullName || u.name || 'Người dùng'}</div>
                        {u.phone && <div className="text-[11px] font-mono text-[#57534E] font-normal">{u.phone}</div>}
                      </td>
                      <td className="py-3.5 px-4 text-[#57534E] font-mono text-[11px] break-all max-w-[220px]">
                        {u.email}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-1 rounded-md text-[11px] font-bold border ${roleCfg.badge}`}>
                          {roleCfg.label}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-[#57534E] break-words max-w-[180px]">
                        {u.organization || u.department || 'Cộng đồng'}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-block px-2.5 py-1 rounded-md text-[10px] font-bold border ${
                          isActive
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-red-50 text-red-700 border-red-200'
                        }`}>
                          {isActive ? '● Đang hoạt động' : '■ Đã tạm khóa'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="inline-flex items-center gap-2 justify-end">
                          {isUpdating && <span className="text-[10px] text-[#0D6F64] font-bold animate-pulse">Lưu…</span>}
                          <select
                            value={roleKey}
                            disabled={isUpdating}
                            onChange={(e) => handleRoleChange(u.id, e.target.value)}
                            className="px-2.5 py-1.5 text-xs font-bold border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] cursor-pointer min-h-[40px] shadow-xs"
                          >
                            <option value="citizen">Công dân</option>
                            <option value="community">Thanh niên tình nguyện</option>
                            <option value="staff">Cán bộ thanh tra</option>
                            <option value="contractor">Nhà thầu thi công</option>
                            <option value="executive">Lãnh đạo Sở</option>
                            <option value="admin">Quản trị viên</option>
                          </select>
                          <button
                            type="button"
                            disabled={isUpdating}
                            onClick={() => handleToggleStatus(u)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold border min-h-[40px] cursor-pointer transition shadow-xs ${
                              isActive
                                ? 'bg-white hover:bg-red-50 text-red-700 border-red-200'
                                : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600'
                            }`}
                          >
                            {isActive ? 'Khóa' : 'Mở'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E7E5E4] rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <h3 className="font-black text-base text-[#1C1917]">Thêm Tài Khoản Người Dùng Mới</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-[#57534E] hover:text-[#1C1917] font-bold p-1 cursor-pointer text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="flex flex-col gap-3 text-xs">
              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Họ và tên *</label>
                <input
                  type="text"
                  required
                  placeholder="VD: Nguyễn Văn An"
                  value={newUser.fullName}
                  onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Email đăng nhập *</label>
                <input
                  type="email"
                  required
                  placeholder="VD: nguyenvanan@hanoi.gov.vn"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Số điện thoại</label>
                <input
                  type="tel"
                  placeholder="VD: 0988 123 456"
                  value={newUser.phone}
                  onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Vai trò tác nghiệp *</label>
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px] cursor-pointer"
                >
                  <option value="citizen">Công dân (Citizen)</option>
                  <option value="community">Thanh niên tình nguyện (Community)</option>
                  <option value="staff">Cán bộ thanh tra (Staff)</option>
                  <option value="contractor">Nhà thầu thi công (Contractor)</option>
                  <option value="executive">Lãnh đạo Sở (Executive)</option>
                  <option value="admin">Quản trị viên (Admin)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#1C1917] mb-1">Đơn vị / Cơ quan / Dự án</label>
                <input
                  type="text"
                  placeholder="VD: Sở Tài Nguyên & Môi Trường Hà Nội"
                  value={newUser.organization}
                  onChange={(e) => setNewUser({ ...newUser, organization: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#D6D3D1] rounded-xl bg-white text-[#1C1917] focus:outline-none focus:ring-2 focus:ring-[#991B1B] min-h-[44px]"
                />
              </div>

              <div className="flex gap-2 pt-3 border-t border-[#E7E5E4] mt-1">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-3 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl min-h-[48px] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl min-h-[48px] cursor-pointer shadow-xs"
                >
                  Tạo tài khoản
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
