import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function ContractorSitesPage() {
  const navigate = useNavigate();
  const [sites, setSites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadSites() {
      try {
        setLoading(true);
        const res = await request('/sites').catch(() => []);
        const list = normalizeList(res);
        setSites(list);
      } catch {
        setSites([]);
      } finally {
        setLoading(false);
      }
    }
    loadSites();
  }, []);

  if (loading) return <LoadingState message="Đang nạp danh sách công trình của nhà thầu…" />;

  return (
    <div className="space-y-5 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#9F241F]">
            Đơn Vị Thi Công & Quản Lý Dự Án
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Công Trình Của Tôi
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Theo dõi trạng thái tuân thủ bảo vệ môi trường, số yêu cầu đang mở và điểm rủi ro bụi theo công trình.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/contractor/tasks')}
          className="px-4 py-2.5 bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px] cursor-pointer"
        >
          Xem yêu cầu khắc phục →
        </button>
      </div>

      {/* Grid of Contractor Sites */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sites.map((site) => {
          const riskScore = site.dustRiskScore || 68;
          const openActions = site.actions?.filter(a => a.status !== 'DONE').length || (riskScore > 75 ? 2 : 1);
          const isCompliant = riskScore < 70;

          return (
            <div
              key={site.id}
              className="bg-white border-2 border-[#E7E5E4] hover:border-[#9F241F] rounded-2xl p-5 shadow-xs flex flex-col justify-between min-h-[220px] transition"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase border ${
                    isCompliant
                      ? 'bg-[#F0FDF4] text-[#15803D] border-[#DCFCE7]'
                      : 'bg-[#FEF2F2] text-[#9F241F] border-[#FCA5A5]'
                  }`}>
                    {isCompliant ? 'Đạt chuẩn môi trường' : 'Có yêu cầu khắc phục'}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#78716C]">
                    #{site.code || site.id.slice(0, 8)}
                  </span>
                </div>

                <h2 className="font-black text-base text-[#1C1917] leading-snug line-clamp-2">
                  {site.name}
                </h2>
                <p className="text-xs text-[#57534E] line-clamp-2">
                  📍 {site.address}
                </p>
              </div>

              {/* Stats & CTA */}
              <div className="pt-4 border-t border-[#E7E5E4] mt-3 space-y-3">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#FAFAF9] p-2 rounded-xl text-center">
                    <span className="text-[10px] text-[#78716C] block">Yêu cầu mở</span>
                    <span className="font-black text-base text-[#9F241F]">{openActions} việc</span>
                  </div>
                  <div className="bg-[#FAFAF9] p-2 rounded-xl text-center">
                    <span className="text-[10px] text-[#78716C] block">Điểm rủi ro</span>
                    <span className="font-black text-base text-[#1C1917]">{riskScore}/100</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => navigate(`/contractor/tasks?siteId=${site.id}`)}
                  className="w-full py-2.5 px-4 bg-[#FAFAF9] hover:bg-[#F5F5F4] text-[#1C1917] border border-[#D6D3D1] font-bold text-xs rounded-xl transition min-h-[44px] flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>Mở danh sách nhiệm vụ</span>
                  <span>➔</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
