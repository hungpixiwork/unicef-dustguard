import React, { useState, useEffect } from 'react';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { StatusBadge, LoadingState, ErrorState, EmptyState } from '../../../../shared/components/StatusBadge.jsx';
import SafeImage from '../../../../shared/components/SafeImage.jsx';

export default function ContractorCasesPage() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [selectedCase, setSelectedCase] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const [casesRes, actionsRes] = await Promise.all([
          request('/cases').catch(() => ({ data: { items: [] } })),
          request('/contractor/actions').catch(() => ({ data: { items: [] } }))
        ]);

        let caseList = normalizeList(casesRes);
        if (caseList.length === 0) {
          // Fallback from actions
          const actionList = normalizeList(actionsRes);
          caseList = actionList.map(a => ({
            id: a.caseId || `case_${a.id}`,
            code: a.caseCode || `VU-2026-${String(a.id).replace(/\D/g, '').slice(-4) || '0420'}`,
            title: a.title || 'Vụ việc theo dõi phát tán bụi công trình',
            description: a.description || 'Yêu cầu khắc phục hiện trường và rửa xe tải.',
            status: a.status || 'IN_PROGRESS',
            createdAt: a.createdAt || new Date().toISOString(),
            siteName: a.siteName || a.site?.name || 'Công trình xây dựng',
            beforeEvidenceUrl: 'https://images.unsplash.com/photo-1584463699026-6147743d526e?w=800&auto=format&fit=crop&q=60',
            afterEvidenceUrl: a.evidenceUrl || 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=800&auto=format&fit=crop&q=60',
            sha256: a.sha256 || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
            locationText: a.siteAddress || 'Khu vực tiếp giáp trục đường giao thông',
            remediationMeasures: 'Đã che phủ 100% bạt bãi cát đá và vận hành trạm rửa xe tự động áp lực cao.'
          }));
        }

        setCases(caseList);
      } catch (err) {
        setError(err.message || 'Lỗi tải hồ sơ vụ việc');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <LoadingState message="Đang nạp hồ sơ vụ việc công trình…" />;
  if (error) return <ErrorState title="Lỗi kết nối" message={error} onRetry={() => window.location.reload()} />;

  const filteredCases = filterStatus === 'ALL'
    ? cases
    : cases.filter(c => (c.status || '').toUpperCase() === filterStatus);

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64] bg-[#E6F4F1] px-2.5 py-1 rounded-md border border-[#B2DFDB]">
            Hồ Sơ Thực Chứng Cộng Đồng • Điểm Tích Hợp 1022 / iHanoi
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Hồ Sơ Vụ Việc & Tiến Độ Phối Hợp Xử Lý
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Theo dõi chuỗi bằng chứng Trước – Sau, đối chứng mã băm SHA-256 và biên bản làm việc giữa nhà thầu và các bên liên quan.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setFilterStatus('ALL')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px] ${
              filterStatus === 'ALL'
                ? 'bg-[#991B1B] text-white shadow-xs'
                : 'bg-[#F5F5F4] text-[#57534E] hover:bg-[#E7E5E4]'
            }`}
          >
            Tất cả ({cases.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterStatus('IN_PROGRESS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px] ${
              filterStatus === 'IN_PROGRESS'
                ? 'bg-[#991B1B] text-white shadow-xs'
                : 'bg-[#F5F5F4] text-[#57534E] hover:bg-[#E7E5E4]'
            }`}
          >
            Đang xử lý
          </button>
        </div>
      </div>

      {/* Cases List */}
      {filteredCases.length === 0 ? (
        <EmptyState title="Không có vụ việc phù hợp" message="Hiện không có hồ sơ vụ việc nào đang cần đối chứng khắc phục." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCases.map((c) => (
            <div
              key={c.id}
              className="bg-white border border-[#E7E5E4] hover:border-[#FECACA] rounded-2xl p-5 shadow-xs flex flex-col justify-between gap-4 transition"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#57534E] bg-[#F5F5F4] px-2 py-0.5 rounded border border-[#E7E5E4]">
                      {c.code || c.id}
                    </span>
                    <span className="text-[10px] font-bold text-[#0D6F64] bg-[#E6F4F1] px-2 py-0.5 rounded border border-[#B2DFDB]">
                      Điểm Tích Hợp 1022
                    </span>
                  </div>
                  <StatusBadge status={c.status} />
                </div>

                <h3 className="font-bold text-sm text-[#1C1917] mt-1">
                  {c.title || c.description}
                </h3>

                <p className="text-xs text-[#57534E] mt-1.5">
                  {c.description || 'Ghi nhận bụi phát tán gần trường học và đường giao thông trong giờ cao điểm.'}
                </p>

                <div className="mt-3 p-2.5 bg-[#FAFAF9] rounded-xl border border-[#E7E5E4] flex items-center justify-between text-[11px] text-[#57534E]">
                  <span>Địa điểm: <strong className="text-[#1C1917]">{c.siteName || 'Công trình xây dựng'}</strong></span>
                  <span className="font-mono text-[#0D6F64]">SHA-256 Verified ✓</span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E7E5E4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <span className="text-[#57534E]">
                  Ngày ghi nhận: <strong>{new Date(c.createdAt || Date.now()).toLocaleDateString('vi-VN')}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedCase(c)}
                  className="w-full sm:w-auto px-4 py-3 bg-[#FEF2F2] hover:bg-[#FEE2E2] text-[#991B1B] font-bold rounded-xl transition min-h-[48px] flex items-center justify-center cursor-pointer"
                >
                  <span>Xem chi tiết hồ sơ →</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Case Detail Modal */}
      {selectedCase && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E7E5E4] rounded-3xl p-6 max-w-xl w-full shadow-2xl flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <span className="font-mono text-xs font-bold text-[#991B1B]">
                  {selectedCase.code || selectedCase.id}
                </span>
                <h3 className="text-base font-black text-[#1C1917] mt-0.5">
                  Chi Tiết Hồ Sơ Thực Chứng Đối Thoại 1022
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCase(null)}
                className="text-[#57534E] hover:text-[#1C1917] font-bold p-2 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer text-lg"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-3 text-xs text-[#1C1917]">
              <div>
                <strong className="text-[#57534E] block">Nội dung vụ việc:</strong>
                <p className="font-medium mt-0.5 text-sm">{selectedCase.title || selectedCase.description}</p>
              </div>

              <div className="p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-[#57534E]">Điểm tích hợp công vụ:</span>
                  <span className="font-bold text-[#0D6F64]">Cổng Dịch vụ công 1022 & iHanoi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#57534E]">Mục đích đối thoại:</span>
                  <span className="font-bold text-[#1C1917]">Tạo chuỗi bằng chứng Trước – Sau minh bạch</span>
                </div>
                <div className="flex flex-col sm:flex-row justify-between gap-1">
                  <span className="text-[#57534E]">Mã toàn vẹn SHA-256:</span>
                  <span className="font-mono text-[11px] text-[#0D6F64] font-bold break-all">{selectedCase.sha256 || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}</span>
                </div>
              </div>

              {/* Before / After Evidence Grid */}
              <div>
                <strong className="text-[#57534E] block mb-2">Chuỗi bằng chứng đối chứng Trước / Sau (Before / After):</strong>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-2 bg-[#FEF2F2] rounded-xl border border-[#FECACA]">
                    <span className="text-[11px] font-bold text-[#991B1B] block mb-1">Ảnh phát hiện ban đầu (Trước)</span>
                    <SafeImage
                      src={selectedCase.beforeEvidenceUrl || 'https://images.unsplash.com/photo-1584463699026-6147743d526e?w=800&auto=format&fit=crop&q=60'}
                      alt="Ảnh Trước"
                      className="w-full h-32 object-cover rounded-lg border border-[#FECACA]"
                    />
                    <span className="text-[10px] text-[#78716C] block mt-1">Phát hiện bụi phát tán</span>
                  </div>

                  <div className="p-2 bg-[#E6F4F1] rounded-xl border border-[#B2DFDB]">
                    <span className="text-[11px] font-bold text-[#0D6F64] block mb-1">Ảnh đã khắc phục (Sau)</span>
                    <SafeImage
                      src={selectedCase.afterEvidenceUrl || selectedCase.evidenceUrl || 'https://images.unsplash.com/photo-1541888946425-d0fbb180c5f5?w=800&auto=format&fit=crop&q=60'}
                      alt="Ảnh Sau"
                      className="w-full h-32 object-cover rounded-lg border border-[#B2DFDB]"
                    />
                    <span className="text-[10px] text-[#0D6F64] font-bold block mt-1">Đã phủ bạt & dập bụi</span>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl">
                <span className="text-[#57534E] font-bold block mb-0.5">Biện pháp đã hoàn thành:</span>
                <p className="text-[#1C1917]">{selectedCase.remediationMeasures || 'Đã tổ chức quét dọn, bọc bạt kín toàn bộ bãi tập kết vật liệu rời và xịt rửa bánh xe nghiêm ngặt.'}</p>
              </div>
            </div>

            <div className="pt-2 border-t border-[#E7E5E4] flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedCase(null)}
                className="px-6 py-3 bg-[#991B1B] text-white text-xs font-bold rounded-xl min-h-[48px] cursor-pointer"
              >
                Đóng hồ sơ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
