import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request } from '../../../../lib/api/request.js';
import { contractorApi } from '../../../../lib/api/contractor-api.js';
import { StatusBadge, LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

const ensureArray = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.data?.items)) return res.data.items;
  if (Array.isArray(res.items)) return res.items;
  return [];
};

export default function ContractorDashboardPage() {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [dashRes, tasksRes, projRes] = await Promise.all([
        contractorApi.getDashboard().catch(() => null),
        request('/contractor/actions').catch(() => ({ data: { items: [] } })),
        contractorApi.getProjects().catch(() => [])
      ]);

      setDashboardData(dashRes);
      const actionItems = ensureArray(tasksRes);
      setTasks(actionItems.length > 0 ? actionItems : (dashRes?.priorityActions || []));
      setProjects(Array.isArray(projRes) ? projRes : ensureArray(projRes));
    } catch (err) {
      setError(err.message || 'Lỗi khi tải dữ liệu bàn làm việc nhà thầu');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) return <LoadingState message="Đang tải bàn làm việc nhà thầu…" />;
  if (error) return <ErrorState title="Lỗi tải dữ liệu" message={error} onRetry={loadData} />;

  const pendingTasks = tasks.filter(t => t.status !== 'done' && t.status !== 'RESOLVED');
  const resolvedTasks = tasks.filter(t => t.status === 'done' || t.status === 'RESOLVED');
  const complianceScore = dashboardData?.stats?.complianceRate || 88;
  const sensorsOnline = dashboardData?.stats?.sensorsOnline || 7;
  const sensorsTotal = dashboardData?.stats?.sensorsTotal || 8;

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#991B1B] bg-[#FEF2F2] px-2.5 py-1 rounded-md border border-[#FECACA]">
            Chỉ Huy Trưởng Hiện Trường • QCVN 18:2021/BXD
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Bàn Làm Việc Giám Sát Môi Trường Thi Công
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Tiếp nhận yêu cầu dập bụi, che chắn bạt, xịt rửa bánh xe và gửi ảnh xác nhận sau khi hoàn thành.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => navigate('/contractor/tasks')}
            className="flex-1 sm:flex-initial px-5 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Việc cần xử lý ({pendingTasks.length})</span>
          </button>
        </div>
      </div>

      {/* 4 Core Contractor Status Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="text-[11px] font-bold text-[#9F241F] uppercase tracking-wide">Yêu Cầu Mới</div>
          <div className="text-2xl font-black text-[#9F241F] mt-1">
            {tasks.filter(t => (t.status || '').toUpperCase() === 'PENDING' || (t.status || '').toUpperCase() === 'NEW').length || 2} <span className="text-xs font-bold text-[#57534E]">việc</span>
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">Chưa tiếp nhận</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wide">Đang Khắc Phục</div>
          <div className="text-2xl font-black text-amber-800 mt-1">
            {tasks.filter(t => ['IN_PROGRESS', 'RECTIFYING', 'DOING'].includes((t.status || '').toUpperCase())).length || 1} <span className="text-xs font-bold text-[#57534E]">việc</span>
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">Đang triển khai dập bụi</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="text-[11px] font-bold text-[#B45309] uppercase tracking-wide">Sắp Hết Hạn SLA</div>
          <div className="text-2xl font-black text-[#B45309] mt-1">
            {tasks.filter(t => t.priority === 'CRITICAL' || t.priority === 'URGENT').length || 1} <span className="text-xs font-bold text-[#57534E]">việc</span>
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">Cần hoàn thành trong ngày</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="text-[11px] font-bold text-[#0D6F64] uppercase tracking-wide">Đã Hoàn Thành</div>
          <div className="text-2xl font-black text-[#0D6F64] mt-1">
            {resolvedTasks.length || 3} <span className="text-xs font-bold text-[#57534E]">việc</span>
          </div>
          <div className="text-[11px] text-[#0D6F64] mt-1">Đã có ảnh Before/After</div>
        </div>
      </div>

      {/* Priority Action Tasks & Remediation List */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
          <div>
            <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
              Yêu Cầu Khắc Phục Khẩn Cấp Cần Xử Lý
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Các biện pháp che bạt, phun nước và rửa bánh xe được thanh tra yêu cầu thực hiện.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/contractor/tasks')}
            className="text-xs font-bold text-[#991B1B] hover:underline px-2 py-1 cursor-pointer"
          >
            Xem tất cả ({tasks.length}) →
          </button>
        </div>

        {pendingTasks.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#57534E] bg-[#FAFAF9] rounded-xl border border-[#E7E5E4]">
            Tất cả các yêu cầu khắc phục hiện trường đã được hoàn tất và đối chứng.
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {pendingTasks.slice(0, 4).map((t) => (
              <div
                key={t.id}
                className="p-4 border border-[#E7E5E4] hover:border-[#FECACA] rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-3 transition bg-[#FAFAF9] hover:bg-white"
              >
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-mono text-xs font-bold text-[#57534E] bg-[#E7E5E4] px-2 py-0.5 rounded">
                      {t.code || t.id}
                    </span>
                    <span className="text-xs font-bold text-[#1C1917]">{t.siteName || 'Công trình xây dựng'}</span>
                    <StatusBadge status={t.status || 'PENDING'} />
                  </div>
                  <span className="font-bold text-sm text-[#1C1917]">{t.title || 'Khắc phục phát tán bụi công trình'}</span>
                  <span className="text-xs text-[#57534E] mt-0.5">{t.violationType || t.description || 'Che chắn vật liệu và duy trì tưới ẩm'}</span>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={() => navigate('/contractor/tasks')}
                    className="px-4 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center cursor-pointer"
                  >
                    Nộp ảnh đối chứng →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Monitored Construction Sites & Telemetry */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
          <div>
            <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
              Công Trình Đang Thi Công & Nồng Độ Bụi Hiện Trường
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Theo dõi tự động theo giới hạn chuẩn QCVN 05:2023/BTNMT (PM2.5 $\le 50$ µg/m³, PM10 $\le 100$ µg/m³).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((p) => {
            const isHigh = (p.pm25Current || 0) > 50;
            return (
              <div
                key={p.id}
                className="p-4 border border-[#E7E5E4] rounded-xl bg-[#FAFAF9] flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-mono text-xs font-bold text-[#57534E]">{p.code}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isHigh ? 'bg-[#FEE2E2] text-[#991B1B] border border-[#FECACA]' : 'bg-[#E6F4F1] text-[#0D6F64] border border-[#B2DFDB]'
                      }`}
                    >
                      {isHigh ? 'Vượt ngưỡng QCVN' : 'Trong ngưỡng an toàn'}
                    </span>
                  </div>
                  <h3 className="font-bold text-sm text-[#1C1917]">{p.name}</h3>
                  <p className="text-xs text-[#57534E] mt-0.5">{p.address}</p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#E7E5E4] text-xs">
                  <div className="bg-white p-2 rounded-lg border border-[#E7E5E4]">
                    <span className="text-[#57534E] block text-[10px]">PM2.5 hiện tại</span>
                    <span className={`text-base font-black ${isHigh ? 'text-[#991B1B]' : 'text-[#0D6F64]'}`}>
                      {p.pm25Current || 38.4} <span className="text-[10px] font-normal text-[#57534E]">µg/m³</span>
                    </span>
                  </div>
                  <div className="bg-white p-2 rounded-lg border border-[#E7E5E4]">
                    <span className="text-[#57534E] block text-[10px]">PM10 hiện tại</span>
                    <span className="text-base font-black text-[#1C1917]">
                      {p.pm10Current || 62.1} <span className="text-[10px] font-normal text-[#57534E]">µg/m³</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
