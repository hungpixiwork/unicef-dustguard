import React, { useState, useEffect } from 'react';
import { request } from '../../../../lib/api/request.js';
import { contractorApi } from '../../../../lib/api/contractor-api.js';
import { StatusBadge, LoadingState, ErrorState } from '../../../../shared/components/StatusBadge.jsx';

const DEFAULT_CHECKLIST = [
  { id: 1, title: 'Hàng rào chắn bụi kín >= 2.5m bao quanh công trình', standard: 'QCXDVN 01:2021/BXD', status: 'PASS', source: 'Cán bộ kiểm tra', lastChecked: '2026-08-20' },
  { id: 2, title: 'Bạt che phủ bãi cát, đá, vật liệu rời', standard: 'QCVN 05:2023/BTNMT & NĐ 45/2022/NĐ-CP', status: 'PASS', source: 'Giám sát hiện trường', lastChecked: '2026-08-22' },
  { id: 3, title: 'Cầu rửa xe tự động và rãnh lắng bùn tại cổng ra vào', standard: 'Nghị định 16/2022/NĐ-CP (Điều 31)', status: 'PASS', source: 'Tuần tra thực địa', lastChecked: '2026-08-21' },
  { id: 4, title: 'Hệ thống phun sương dập bụi tự động cố định & cơ động', standard: 'Quy chuẩn kỹ thuật môi trường', status: 'PASS', source: 'Sensor IoT', lastChecked: '2026-08-22' },
  { id: 5, title: 'Cảm biến bụi IoT kết nối truyền tin liên tục 24/7', standard: 'Quy chuẩn DustGuard VN IoT Node', status: 'PASS', source: 'Hệ thống viễn thông', lastChecked: '2026-08-22' },
  { id: 6, title: 'Vệ sinh quét đường và tưới ẩm định kỳ >= 4 lần/ngày', standard: 'Thông tư 02/2022/TT-BTNMT', status: 'PASS', source: 'Nhật ký thi công', lastChecked: '2026-08-22' },
  { id: 7, title: 'Xe tải vận chuyển phế thải phủ bạt kín khít 100%', standard: 'Luật Giao thông đường bộ & NĐ 100/2019/NĐ-CP', status: 'PASS', source: 'Camera AI cổng', lastChecked: '2026-08-21' },
  { id: 8, title: 'Nhật ký giám sát môi trường điện tử cập nhật hàng ngày', standard: 'Thông tư 02/2022/TT-BTNMT', status: 'PASS', source: 'Tự khai báo', lastChecked: '2026-08-22' },
  { id: 9, title: 'Biển thông báo hotline phản ánh môi trường công khai', standard: 'TCVN 5308:1991', status: 'PASS', source: 'UBND Phường', lastChecked: '2026-08-15' },
  { id: 10, title: 'Kế hoạch ứng phó sự cố phát tán bụi khi gió cấp 4+', standard: 'Phương án BVMT dự án', status: 'PASS', source: 'Hồ sơ phê duyệt', lastChecked: '2026-08-10' }
];

export default function ContractorReportsPage() {
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState('ALL');
  const [complianceData, setComplianceData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showA4Modal, setShowA4Modal] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        setError(null);
        const [projRes, compRes] = await Promise.all([
          contractorApi.getProjects().catch(() => []),
          contractorApi.getProjectCompliance('site_cg_01').catch(() => null)
        ]);

        const projectList = Array.isArray(projRes) ? projRes : (projRes?.items || projRes?.data?.items || []);
        setProjects(projectList);

        if (compRes) {
          setComplianceData(compRes);
        }
      } catch (err) {
        setError(err.message || 'Lỗi khi nạp dữ liệu báo cáo tuân thủ');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleSelectProject = async (projId) => {
    setSelectedProjectId(projId);
    if (projId === 'ALL') {
      return;
    }
    try {
      const comp = await contractorApi.getProjectCompliance(projId);
      setComplianceData(comp);
    } catch {}
  };

  const checklist = complianceData?.checklist || DEFAULT_CHECKLIST;
  const complianceScore = complianceData?.complianceScore || 90;

  const passedCount = checklist.filter(c => c.status === 'PASS' || c.status === 'VALID' || c.checked).length;
  const warningCount = checklist.filter(c => c.status === 'WARNING').length;
  const failCount = checklist.length - passedCount - warningCount;

  const currentProject = projects.find(p => p.id === selectedProjectId) || projects[0] || {
    name: 'Tổ hợp Thương mại & Nhà ở Cầu Giấy Complex',
    code: 'BD-0237',
    address: '123 Xuân Thủy, Cầu Giấy, Hà Nội'
  };

  if (loading) return <LoadingState message="Đang nạp báo cáo tuân thủ môi trường…" />;
  if (error) return <ErrorState title="Lỗi tải dữ liệu" message={error} onRetry={() => window.location.reload()} />;

  return (
    <div className="flex flex-col gap-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#991B1B] bg-[#FEF2F2] px-2.5 py-1 rounded-md border border-[#FECACA]">
            QCVN 05:2023/BTNMT • QCVN 18:2021/BXD
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] mt-1.5">
            Báo Cáo Tuân Thủ Bảo Vệ Môi Trường Thi Công
          </h1>
          <p className="text-xs text-[#57534E] mt-0.5">
            Bảng theo dõi và tự động đánh giá 10 tiêu chí phòng ngừa phát tán bụi, rửa bánh xe và che chắn vật liệu.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setShowA4Modal(true)}
            className="flex-1 sm:flex-initial px-5 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white text-xs font-bold rounded-xl shadow-xs transition min-h-[48px] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>📄 Xem & In Biên Bản A4</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E7E5E4] rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-bold text-[#0D6F64] uppercase tracking-wide">Điểm Tuân Thủ Chung</div>
          <div className="text-2xl font-black text-[#0D6F64] mt-1">{complianceScore} / 100</div>
          <div className="text-[11px] text-[#57534E] mt-1">Đạt chuẩn an toàn thi công</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-bold text-emerald-700 uppercase tracking-wide">Tiêu Chí Đạt Chuẩn</div>
          <div className="text-2xl font-black text-emerald-700 mt-1">{passedCount} / {checklist.length}</div>
          <div className="text-[11px] text-emerald-700 mt-1">100% có hồ sơ thực chứng</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wide">Cần Lưu Ý / Cải Thiện</div>
          <div className="text-2xl font-black text-amber-700 mt-1">{warningCount} hạng mục</div>
          <div className="text-[11px] text-[#57534E] mt-1">Đang duy trì theo dõi</div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-bold text-[#991B1B] uppercase tracking-wide">Chưa Đạt / Quá Hạn</div>
          <div className="text-2xl font-black text-[#991B1B] mt-1">{failCount}</div>
          <div className="text-[11px] text-[#57534E] mt-1">Không có vi phạm nghiêm trọng</div>
        </div>
      </div>

      {/* Project Selector Bar */}
      {projects.length > 0 && (
        <div className="bg-white border border-[#E7E5E4] rounded-xl p-4 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <span className="text-xs font-bold text-[#1C1917]">Lọc theo công trình xây dựng:</span>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleSelectProject('ALL')}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px] ${
                selectedProjectId === 'ALL'
                  ? 'bg-[#991B1B] text-white shadow-xs'
                  : 'bg-[#F5F5F4] text-[#57534E] hover:bg-[#E7E5E4]'
              }`}
            >
              Tất cả công trình
            </button>
            {projects.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => handleSelectProject(p.id)}
                className={`px-3.5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px] ${
                  selectedProjectId === p.id
                    ? 'bg-[#991B1B] text-white shadow-xs'
                    : 'bg-[#F5F5F4] text-[#57534E] hover:bg-[#E7E5E4]'
                }`}
              >
                {p.name || p.code}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 10-Criteria Compliance Table */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-[#E7E5E4]">
          <div>
            <h2 className="text-sm sm:text-base font-black text-[#1C1917] uppercase tracking-wide">
              Bảng 10 Tiêu Chí Tuân Thủ Bảo Vệ Môi Trường (Checklist SSOT)
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Định kỳ đánh giá dựa trên cảm biến IoT, hình ảnh đối chứng Before/After và biên bản kiểm tra.
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-[#57534E] font-medium">Tỷ lệ tuân thủ: </span>
            <strong className="text-sm font-black text-[#0D6F64]">{Math.round((passedCount / checklist.length) * 100)}%</strong>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse min-w-[640px]">
            <thead>
              <tr className="bg-[#F5F5F4] text-[#57534E] font-bold uppercase text-[10px] border-b border-[#E7E5E4]">
                <th className="py-3 px-3 w-12 text-center">STT</th>
                <th className="py-3 px-4">Tiêu chí tuân thủ môi trường</th>
                <th className="py-3 px-4 hidden md:table-cell">Căn cứ quy chuẩn / Luật</th>
                <th className="py-3 px-3 text-center">Nguồn đối chứng</th>
                <th className="py-3 px-3 text-center">Lần kiểm tra</th>
                <th className="py-3 px-4 text-center w-28">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7E5E4]">
              {checklist.map((item, idx) => {
                const isPass = item.status === 'PASS' || item.status === 'VALID' || item.checked;
                const isWarn = item.status === 'WARNING';
                return (
                  <tr key={item.id || idx} className="hover:bg-[#FAFAF9] transition">
                    <td className="py-3 px-3 text-center font-bold text-[#57534E] font-mono">
                      {item.id || idx + 1}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#1C1917]">
                      {item.title}
                    </td>
                    <td className="py-3 px-4 text-[#57534E] text-[11px] hidden md:table-cell">
                      {item.standard || item.category || 'QCVN 05:2023/BTNMT'}
                    </td>
                    <td className="py-3 px-3 text-center text-[#57534E]">
                      <span className="bg-[#F5F5F4] px-2 py-0.5 rounded text-[10px] font-medium border border-[#E7E5E4]">
                        {item.source || 'Cảm biến AI / Thanh tra'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center text-[#57534E] font-mono text-[11px]">
                      {item.lastChecked || '2026-08-22'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                          isPass
                            ? 'bg-[#E6F4F1] text-[#0D6F64] border-[#B2DFDB]'
                            : isWarn
                            ? 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]'
                            : 'bg-[#FEE2E2] text-[#991B1B] border-[#FECACA]'
                        }`}
                      >
                        {isPass ? 'Đạt Chuẩn' : isWarn ? 'Cần Lưu Ý' : 'Chưa Đạt'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Remediation & Follow-up Notes */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-6 shadow-xs flex flex-col gap-3">
        <h3 className="text-sm font-black text-[#1C1917] uppercase tracking-wide">
          Ghi Chú Hành Động Khắc Phục & Cam Kết Nhà Thầu
        </h3>
        <div className="p-4 rounded-xl bg-[#FAFAF9] border border-[#E7E5E4] text-xs text-[#57534E] space-y-2 leading-relaxed">
          <p>
            • <strong>Dập bụi đường nội bộ:</strong> Vận hành xe bồn tưới ẩm 4 ca/ngày (sáng 7h00, trưa 11h30, chiều 14h00, tối 17h30) và duy trì hệ thống phun sương tự động.
          </p>
          <p>
            • <strong>Kiểm soát phương tiện rời công trường:</strong> 100% xe tải chở phế thải, đất cát được phủ kín bạt và xịt rửa bánh xe bằng vòi áp lực cao trước khi ra đường đô thị.
          </p>
          <p>
            • <strong>Lưu trữ minh chứng số:</strong> Mọi hình ảnh khắc phục được băm mã SHA-256 đối chứng toàn vẹn số, sẵn sàng chuyển giao làm việc với tổ thanh tra và chính quyền địa phương.
          </p>
        </div>
      </div>

      {/* A4 Printable Handover & Compliance Certificate Modal */}
      {showA4Modal && (
        <div className="fixed inset-0 z-50 bg-[#1C1917]/60 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-[#E7E5E4] rounded-3xl p-6 sm:p-8 max-w-3xl w-full shadow-2xl flex flex-col gap-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#E7E5E4]">
              <div>
                <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64] bg-[#E6F4F1] px-2.5 py-0.5 rounded border border-[#B2DFDB]">
                  Mẫu In Nghiệm Thu A4 • Nghị Định 45/2022/NĐ-CP
                </span>
                <h2 className="text-lg font-black text-[#1C1917] mt-1">Biên Bản Nghiệm Thu Tuân Thủ Bảo Vệ Môi Trường</h2>
              </div>
              <button
                type="button"
                onClick={() => setShowA4Modal(false)}
                className="text-[#57534E] hover:text-[#1C1917] font-bold p-2 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer text-lg"
              >
                ✕
              </button>
            </div>

            {/* Printable A4 Certificate Content */}
            <div id="printable-a4-certificate" className="bg-[#FAFAF9] border border-[#E7E5E4] rounded-2xl p-6 sm:p-8 text-xs text-[#1C1917] space-y-4">
              <div className="text-center space-y-1 pb-4 border-b border-[#E7E5E4]">
                <div className="font-bold text-xs uppercase text-[#1C1917]">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div>
                <div className="text-[11px] font-bold text-[#57534E]">Độc lập – Tự do – Hạnh phúc</div>
                <div className="text-[10px] text-[#78716C]">┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈</div>
                <h3 className="text-base font-black text-[#991B1B] uppercase mt-2">
                  BIÊN BẢN NGHIỆM THU & BÀN GIAO TUÂN THỦ MÔI TRƯỜNG THI CÔNG
                </h3>
                <div className="text-[11px] text-[#57534E]">
                  Căn cứ QCVN 05:2023/BTNMT, QCVN 18:2021/BXD & Thông tư 02/2022/TT-BTNMT
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-4 rounded-xl border border-[#E7E5E4]">
                <div>
                  <span className="text-[#57534E] block">Tên dự án / Công trình:</span>
                  <strong className="text-[#1C1917]">{currentProject.name}</strong>
                </div>
                <div>
                  <span className="text-[#57534E] block">Mã quản lý:</span>
                  <strong className="text-[#1C1917] font-mono">{currentProject.code || 'BD-0237'}</strong>
                </div>
                <div>
                  <span className="text-[#57534E] block">Địa điểm thi công:</span>
                  <span className="text-[#1C1917]">{currentProject.address}</span>
                </div>
                <div>
                  <span className="text-[#57534E] block">Kết quả đánh giá tuân thủ:</span>
                  <strong className="text-[#0D6F64] text-sm">{complianceScore}/100 — ĐẠT CHUẨN AN TOÀN</strong>
                </div>
              </div>

              <div>
                <strong className="block mb-2 text-[#1C1917]">Kết quả 10 tiêu chí kiểm tra hiện trường:</strong>
                <div className="space-y-1.5 bg-white p-3 rounded-xl border border-[#E7E5E4]">
                  {checklist.map((c, i) => (
                    <div key={c.id || i} className="flex items-center justify-between text-[11px] py-1 border-b border-[#F5F5F4] last:border-b-0">
                      <span>{i + 1}. {c.title}</span>
                      <span className="font-bold text-[#0D6F64]">✓ ĐẠT</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#E7E5E4] text-center text-xs">
                <div className="space-y-8">
                  <div>
                    <strong>ĐẠI DIỆN ĐƠN VỊ THI CÔNG</strong>
                    <div className="text-[10px] text-[#57534E]">(Ký, ghi rõ họ tên và đóng dấu)</div>
                  </div>
                  <div className="font-bold text-[#1C1917] pt-4">Kỹ sư Chỉ Huy Trưởng</div>
                </div>

                <div className="space-y-8">
                  <div>
                    <strong>ĐẠI DIỆN BAN GIÁM SÁT MÔI TRƯỜNG</strong>
                    <div className="text-[10px] text-[#57534E]">(Ký số điện tử xác thực SHA-256)</div>
                  </div>
                  <div className="font-mono text-[10px] text-[#0D6F64] font-bold pt-4">
                    SHA-256: 4b227777d4dd1fc61c6f884f48641d02b4d121d3
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex flex-col sm:flex-row justify-end gap-3 pt-2 border-t border-[#E7E5E4]">
              <button
                type="button"
                onClick={() => setShowA4Modal(false)}
                className="px-5 py-3 bg-[#F5F5F4] hover:bg-[#E7E5E4] text-[#1C1917] font-bold text-xs rounded-xl min-h-[48px] cursor-pointer"
              >
                Đóng
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-6 py-3 bg-[#991B1B] hover:bg-[#7F1D1D] text-white font-bold text-xs rounded-xl min-h-[48px] flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <span>🖨 In Biên Bản A4 Ngay</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
