import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { request, normalizeList } from '../../../../lib/api/request.js';
import { LoadingState } from '../../../../shared/components/StatusBadge.jsx';

export default function ContractorCompliancePage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  // Compliance KPIs
  const [stats, setStats] = useState({
    onTimeRemediationRate: 94.2,
    totalInspections: 18,
    totalResolved: 16,
    repeatedErrors: [
      { name: 'Chưa rửa bánh xe trước khi ra cổng', count: 4, severity: 'HIGH' },
      { name: 'Bạt phủ bãi cát đá bị rách mép', count: 3, severity: 'MEDIUM' },
      { name: 'Bùn đất vương vãi mặt đường <50m', count: 2, severity: 'HIGH' }
    ]
  });

  const [timelineEvents, setTimelineEvents] = useState([]);

  useEffect(() => {
    async function loadComplianceData() {
      try {
        setLoading(true);
        const [dashRes, evRes] = await Promise.all([
          request('/contractor/dashboard').catch(() => null),
          request('/contractor/evidence').catch(() => null)
        ]);

        if (dashRes?.data) {
          const d = dashRes.data;
          const kpis = d.kpis || {};
          setStats(prev => ({
            ...prev,
            onTimeRemediationRate: kpis.complianceRate || prev.onTimeRemediationRate,
            totalInspections: kpis.totalActions || prev.totalInspections,
            totalResolved: kpis.resolvedCount || prev.totalResolved
          }));
        }

        const evList = normalizeList(evRes);
        if (evList.length > 0) {
          const events = evList.map(item => ({
            date: item.createdAt ? new Date(item.createdAt).toLocaleString('vi-VN') : 'Gần đây',
            type: item.type || 'EVIDENCE',
            title: item.caption || item.title || 'Ghi nhận kiểm soát bụi hiện trường',
            site: item.siteName || item.siteId || 'Công trường đang quản lý',
            badge: item.status === 'APPROVED' || item.status === 'RESOLVED' ? 'Đạt chuẩn' : 'Chờ kiểm tra',
            badgeColor: item.status === 'APPROVED' || item.status === 'RESOLVED'
              ? 'bg-[#F0FDF4] text-[#15803D] border-[#DCFCE7]'
              : 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]',
            desc: item.note || item.description || `Mã định danh SHA-256: ${item.sha256 ? item.sha256.substring(0, 16) + '...' : 'Đã xác thực'}`
          }));
          setTimelineEvents(events);
        } else {
          setTimelineEvents([
            {
              date: '03/09/2026 16:30',
              type: 'VERIFIED',
              title: 'Nghiệm thu hoàn tất khắc phục cổng số 2',
              site: 'Công trường Tuyến ĐS Đô thị Metro 3',
              badge: 'Đạt chuẩn',
              badgeColor: 'bg-[#F0FDF4] text-[#15803D] border-[#DCFCE7]',
              desc: 'Cán bộ thanh tra kiểm tra thực địa, ảnh Before/After đối chứng đạt chuẩn QCVN 18:2021/BXD.'
            },
            {
              date: '02/09/2026 10:15',
              type: 'REMEDIATION_SUBMITTED',
              title: 'Nhà thầu nộp minh chứng dập bụi bãi vật liệu',
              site: 'Dự án Cải tạo Thoát nước & Đường ĐT743',
              badge: 'Chờ tái kiểm',
              badgeColor: 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]',
              desc: 'Đã phủ bạt kín 100% bãi cát và vận hành giàn phun sương tự động dọc chu vi hàng rào.'
            }
          ]);
        }
      } catch (err) {
        console.warn('[ContractorCompliance Error]', err);
      } finally {
        setLoading(false);
      }
    }
    loadComplianceData();
  }, []);

  if (loading) {
    return <LoadingState message="Đang nạp hồ sơ tuân thủ môi trường…" />;
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-[#E7E5E4] pb-4">
        <div>
          <span className="text-[11px] font-black uppercase tracking-wider text-[#0D6F64]">
            Hồ Sơ Năng Lực & Kiểm Soát Bụi
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-[#1C1917] tracking-tight">
            Lịch Sử Tuân Thủ Môi Trường
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] mt-0.5">
            Theo dõi tiến trình kiểm tra, khắc phục và thống kê các lỗi thường gặp của nhà thầu.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/contractor/tasks')}
          className="px-4 py-2.5 bg-[#9F241F] hover:bg-[#7F1D1D] text-white font-black text-xs rounded-xl shadow-xs min-h-[44px]"
        >
          Xử lý yêu cầu mở →
        </button>
      </div>

      {/* 3 Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs">
          <div className="text-xs font-bold text-[#0D6F64] uppercase tracking-wider">
            Tỷ Lệ Đúng Hạn SLA
          </div>
          <div className="text-3xl font-black text-[#0D6F64] mt-1">
            {stats.onTimeRemediationRate}%
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">
            Hoàn tất khắc phục trong 48h cam kết
          </div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs">
          <div className="text-xs font-bold text-[#15803D] uppercase tracking-wider">
            Đã Nghiệm Thu Đạt
          </div>
          <div className="text-3xl font-black text-[#15803D] mt-1">
            {stats.totalResolved} / {stats.totalInspections}
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">
            Đợt kiểm tra có bằng chứng đối chứng
          </div>
        </div>

        <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs">
          <div className="text-xs font-bold text-[#B45309] uppercase tracking-wider">
            Lỗi Cần Khắc Phục Lặp Lại
          </div>
          <div className="text-3xl font-black text-[#B45309] mt-1">
            03 nhóm lỗi
          </div>
          <div className="text-[11px] text-[#57534E] mt-1">
            Cần huấn luyện đội xe và công nhân
          </div>
        </div>
      </div>

      {/* Top Repeated Errors Alert */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 shadow-xs space-y-3">
        <h2 className="text-xs font-black uppercase tracking-wider text-[#1C1917]">
          Các lỗi hiện trường thường gặp cần phòng ngừa
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {stats.repeatedErrors.map((err, idx) => (
            <div key={idx} className="p-3 bg-[#FAFAF9] border border-[#E7E5E4] rounded-xl flex flex-col justify-between min-h-[85px]">
              <div className="font-bold text-xs text-[#1C1917] leading-snug">
                {err.name}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-[#E7E5E4]/60 mt-1">
                <span className="text-[#9F241F] font-black">{err.count} lần ghi nhận</span>
                <span className="text-[10px] uppercase font-bold text-[#78716C]">{err.severity}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline of Inspections and Remediations */}
      <div className="bg-white border border-[#E7E5E4] rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
        <h2 className="text-xs font-black uppercase tracking-wider text-[#1C1917] pb-2 border-b border-[#E7E5E4]">
          Dòng thời gian kiểm tra & khắc phục theo công trình
        </h2>

        <div className="relative pl-6 border-l-2 border-[#E7E5E4] ml-2 space-y-6 my-2">
          {timelineEvents.map((evt, idx) => (
            <div key={idx} className="relative space-y-1">
              <span className="w-3 h-3 rounded-full bg-[#0D6F64] absolute -left-[31px] top-1 border-2 border-white ring-2 ring-[#0D6F64]/30" />
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-black text-[#1C1917]">{evt.title}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${evt.badgeColor}`}>
                  {evt.badge}
                </span>
              </div>
              <div className="text-[11px] text-[#0D6F64] font-bold">
                🏢 {evt.site}
              </div>
              <p className="text-xs text-[#57534E] leading-relaxed m-0">
                {evt.desc}
              </p>
              <span className="text-[10px] font-mono text-[#78716C] block pt-0.5">
                🕒 {evt.date}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
