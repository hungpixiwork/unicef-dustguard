import React, { lazy } from 'react';
import { Route, Navigate } from 'react-router-dom';

const ContractorLayout = lazy(() => import('./layout/ContractorLayout'));
const ContractorDashboardPage = lazy(() => import('./pages/dashboard/ContractorDashboardPage'));
const ContractorSitesPage = lazy(() => import('./pages/sites/ContractorSitesPage'));
const ContractorTasksPage = lazy(() => import('./pages/tasks/ContractorTasksPage'));
const ContractorCasesPage = lazy(() => import('./pages/cases/ContractorCasesPage'));
const ContractorReportsPage = lazy(() => import('./pages/reports/ContractorReportsPage'));
const ContractorCompliancePage = lazy(() => import('./pages/compliance/ContractorCompliancePage'));

export const contractorRoutes = (
  <Route path="/contractor" element={<ContractorLayout />}>
    {/* 19. Dashboard nhà thầu */}
    <Route index element={<ContractorDashboardPage />} />
    <Route path="dashboard" element={<Navigate to="/contractor" replace />} />
    
    {/* 20. Công trình của tôi */}
    <Route path="sites" element={<ContractorSitesPage />} />
    
    {/* 21. Yêu cầu khắc phục & 22-23. Chi tiết & Gửi minh chứng */}
    <Route path="tasks" element={<ContractorTasksPage />} />
    <Route path="tasks/:id" element={<ContractorTasksPage />} />
    <Route path="actions" element={<Navigate to="/contractor/tasks" replace />} />
    <Route path="actions/:id" element={<Navigate to="/contractor/tasks" replace />} />
    
    {/* 24. Lịch sử tuân thủ */}
    <Route path="compliance" element={<ContractorCompliancePage />} />
    <Route path="history" element={<ContractorCompliancePage />} />

    {/* Cases & Reports */}
    <Route path="cases" element={<ContractorCasesPage />} />
    <Route path="projects" element={<Navigate to="/contractor/cases" replace />} />
    <Route path="reports" element={<ContractorReportsPage />} />

    {/* Legacy redirects */}
    <Route path="portal" element={<Navigate to="/contractor/tasks" replace />} />
    <Route path="evidence" element={<Navigate to="/contractor/tasks" replace />} />
    <Route path="notifications" element={<Navigate to="/contractor/tasks" replace />} />
  </Route>
);
