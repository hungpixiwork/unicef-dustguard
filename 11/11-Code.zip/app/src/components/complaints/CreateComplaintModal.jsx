import React, { useState } from 'react';
import { staffApi } from '../../lib/api/staff-api';

export default function CreateComplaintModal({ sites, onClose, onCreated }) {
    const [form, setForm] = useState({
        siteId: sites[0]?.id || '',
        citizen: '',
        phone: '',
        desc: '',
        loc: '',
    });

    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);

    // Handle Escape key & body overflow
    React.useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };
        const prevOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        window.addEventListener('keydown', handleKeyDown);

        return () => {
            document.body.style.overflow = prevOverflow;
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [onClose]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.desc.trim()) return;
        setSaving(true);
        setError(null);
        try {
            const result = await staffApi.createComplaint(form);
            onCreated(result);
        } catch (err) {
            setError(err);
        } finally {
            setSaving(false);
        }
    };

    return (
        <div 
            className="fixed inset-0 bg-black/60 z-[9999] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
            <div 
                className="bg-[#FDFBF7] dark:bg-gray-900 border border-cream-200 dark:border-gray-800 w-full max-w-lg rounded-t-2xl sm:rounded-xl shadow-2xl p-5 sm:p-6 pb-safe max-h-[92vh] sm:max-h-[90vh] overflow-y-auto"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4 pb-2 border-b border-cream-200 dark:border-gray-800">
                    <h2 className="text-lg font-bold text-[#231b14] dark:text-white m-0">Tạo phản ánh mới</h2>
                    <button
                        onClick={onClose}
                        className="flex items-center justify-center w-11 h-11 min-h-[44px] min-w-[44px] rounded-full bg-cream-100 hover:bg-cream-200 text-ink-700 dark:bg-gray-800 dark:text-gray-300 text-lg font-bold cursor-pointer transition"
                        aria-label="Đóng cửa sổ tạo phản ánh"
                    >
                        
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                    <div>
                        <label className="font-bold text-ink-900 dark:text-white block mb-1.5">Công trình liên quan</label>
                        <select 
                            value={form.siteId} 
                            onChange={e => setForm(f => ({ ...f, siteId: e.target.value }))}
                            className="w-full min-h-[44px] px-3 py-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs font-semibold text-ink-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                        >
                            {sites.map(s => <option key={s.id} value={s.id}>{s.id} — {s.name}</option>)}
                        </select>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label className="font-bold text-ink-900 dark:text-white block mb-1.5">Người phản ánh</label>
                            <input 
                                type="text"
                                value={form.citizen} 
                                onChange={e => setForm(f => ({ ...f, citizen: e.target.value }))} 
                                placeholder="Họ và tên" 
                                className="w-full min-h-[44px] px-3 py-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs text-ink-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                            />
                        </div>
                        <div>
                            <label className="font-bold text-ink-900 dark:text-white block mb-1.5">Số điện thoại</label>
                            <input 
                                type="tel"
                                inputMode="tel"
                                value={form.phone} 
                                onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} 
                                placeholder="09xx xxx xxx" 
                                className="w-full min-h-[44px] px-3 py-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs text-ink-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="font-bold text-ink-900 dark:text-white block mb-1.5">Vị trí phản ánh</label>
                        <input 
                            type="text"
                            value={form.loc} 
                            onChange={e => setForm(f => ({ ...f, loc: e.target.value }))} 
                            placeholder="Số nhà, tên đường, khu vực..." 
                            className="w-full min-h-[44px] px-3 py-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs text-ink-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                        />
                    </div>

                    <div>
                        <label className="font-bold text-ink-900 dark:text-white block mb-1.5">Nội dung phản ánh <span className="text-seal-600">*</span></label>
                        <textarea 
                            value={form.desc} 
                            onChange={e => setForm(f => ({ ...f, desc: e.target.value }))} 
                            placeholder="Mô tả chi tiết tình trạng bụi, xe tải chở vật liệu rơi vãi hoặc vi phạm môi trường..." 
                            rows={4}
                            className="w-full p-3 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs text-ink-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d6f64] resize-y"
                            required 
                        />
                    </div>

                    {error && (
                        <div className="p-3 bg-seal-50 border border-seal-200 text-seal-800 rounded-lg text-xs font-semibold">
                            ️ Không tạo được phản ánh: {error.message}
                        </div>
                    )}

                    <div className="flex gap-2.5 justify-end pt-3 border-t border-cream-200 dark:border-gray-800">
                        <button 
                            type="button" 
                            className="min-h-[44px] px-5 py-2.5 border border-cream-200 dark:border-gray-700 text-ink-700 dark:text-gray-300 font-bold rounded-lg hover:bg-cream-100 dark:hover:bg-gray-800 transition cursor-pointer" 
                            onClick={onClose} 
                            disabled={saving}
                        >
                            Hủy bỏ
                        </button>
                        <button 
                            type="submit" 
                            className="min-h-[44px] px-6 py-2.5 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50" 
                            disabled={saving}
                        >
                            {saving ? 'Đang tạo...' : ' Tạo phản ánh'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
