import React from 'react';
import StatusBadge from '../ui/StatusBadge.jsx';

/**
 * StatusChip — Unified Complaint Status Badge (SSOT delegator)
 */
export default function StatusChip({ status, className = '' }) {
  return (
    <StatusBadge
      status={status}
      size="sm"
      short={true}
      className={className}
    />
  );
}
