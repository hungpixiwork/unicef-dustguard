import React from 'react';
import { S } from '../shared';

function KV({ k, v, mono }) {
    return (
        <div>
            <span style={{ color: 'var(--ink-3)' }}>{k}: </span>
            <span className={mono ? 'mono' : ''} style={{ fontWeight: 600 }}>{v || '—'}</span>
        </div>
    );
}

export default function TriageSummary({ complaint, site }) {
    const dueText = complaint.dueAt ? new Date(complaint.dueAt).toLocaleString('vi-VN') : 'Chưa đặt hạn';
    const contactedText = complaint.contactedAt ? new Date(complaint.contactedAt).toLocaleString('vi-VN') : 'Chưa liên hệ';
    const authorityAction = site?.risk?.stakeholderActions?.authority?.[0]?.title;
    const fallbackAction = complaint.status === 'investigating'
        ? 'Thực hiện thanh tra hiện trường và ghi nhận checklist.'
        : complaint.status === 'new'
            ? 'Xác nhận công trình liên quan và quyết định ưu tiên.'
            : complaint.status === 'resolved'
                ? 'Theo dõi nếu có phản ánh mới cùng vị trí.'
                : 'Cập nhật lại nếu có bằng chứng bổ sung.';
    const nextAction = authorityAction || site?.risk?.recommendedActions?.[0] || fallbackAction;

    return (
        <div style={{ ...S.card, padding: 12, background: 'var(--panel)', marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 8 }}>Tóm tắt phân loại xử lý</div>
            <div className="triage-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, fontSize: 12 }}>
                <KV k="Ưu tiên" v={complaint.priority === '48h' ? 'Thanh tra trong 48h' : 'Chưa ưu tiên'} />
                <KV k="Hạn xử lý" v={dueText} mono />
                <KV k="Liên hệ" v={contactedText} mono />
                <KV k="Công trình" v={site?.name || 'Chưa gắn'} />
                {complaint.inspectionId && <KV k="Thanh tra" v={complaint.inspectionId} mono />}
                <KV k="Hành động tiếp" v={nextAction} />
            </div>
            {complaint.triageNote && <div style={{ marginTop: 8, padding: 8, background: 'var(--panel-2)', border: '1px solid var(--line-2)', borderRadius: 3, fontSize: 12 }}>{complaint.triageNote}</div>}
        </div>
    );
}
