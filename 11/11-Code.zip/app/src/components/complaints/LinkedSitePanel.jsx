import React from 'react';
import { RiskBadge, Chip } from '../shared';

export default function LinkedSitePanel({ complaint, site, onOpenSite }) {
    const confidence = complaint.status === 'linked' || complaint.status === 'investigating' || complaint.status === 'resolved' ? 94 : 82;
    const distance = site.near?.[0]?.d ? Math.max(35, Math.min(180, site.near[0].d)) : 75;
    return (
        <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--line-2)', borderRadius: 3, marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, marginBottom: 10 }}>
                <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 700, letterSpacing: '.05em' }}>AUTO-GEOTAG · GẮN CÔNG TRÌNH</div>
                <Chip color={confidence >= 90 ? 'var(--green)' : 'var(--amber)'}>{confidence}% khớp</Chip>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: '#fff', border: '1px solid var(--line)', borderRadius: 3, gap: 12 }}>
                <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{site.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}><span className="mono">{site.id}</span> · cách vị trí phản ánh khoảng {distance}m</div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <RiskBadge tier={site.tier} score={site.score} />
                    <button onClick={() => onOpenSite(site.id)} className="btn-secondary">Mở hồ sơ →</button>
                </div>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 10, lineHeight: 1.5 }}>
                <b>Tác động lên Dust Risk Score:</b> phản ánh này đã được tính vào điểm hiện tại. Tổng cộng <b>{site.complaints || 0}</b> phản ánh trong 7 ngày qua. Có thể xác nhận gắn công trình hoặc chuyển sang thanh tra 48h.
            </div>
        </div>
    );
}
