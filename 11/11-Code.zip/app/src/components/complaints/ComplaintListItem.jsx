import React from 'react';
import StatusChip from './StatusChip';

export default function ComplaintListItem({ complaint, site, active, onSelect }) {
    return (
        <div onClick={() => onSelect(complaint.id)} style={{
            padding: '12px 14px', borderBottom: '1px solid var(--line-2)',
            cursor: 'pointer', background: active ? 'var(--blue-bg)' : 'transparent',
            borderLeft: active ? '3px solid var(--accent)' : '3px solid transparent'
        }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span className="mono" style={{ fontSize: 11, fontWeight: 600 }}>{complaint.id}</span>
                <StatusChip status={complaint.status} />
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-2)', marginBottom: 4, lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>"{complaint.desc}"</div>
            <div style={{ fontSize: 10, color: 'var(--ink-3)' }} className="mono">{complaint.date}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-2)', marginTop: 4 }}>↳ {site?.name || 'Chưa gắn công trình'}</div>
        </div>
    );
}
