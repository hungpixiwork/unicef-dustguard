import React, { useState, useEffect } from 'react';
import { History, X, RotateCcw, Clock, User, Check, Shield } from 'lucide-react';

export default function RevisionHistoryModal({
  isOpen,
  onClose,
  documentId,
  currentRevision = 1,
  onRestoreRevision
}) {
  const [revisions, setRevisions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRevision, setSelectedRevision] = useState(null);

  useEffect(() => {
    if (!isOpen || !documentId) return;

    let isMounted = true;
    setLoading(true);

    fetch(`/api/documents/drafts/${documentId}/revisions`, {
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'
    })
      .then(res => res.json())
      .then(data => {
        if (isMounted) {
          const list = data?.data?.revisions || data?.data?.items || data?.data || [];
          setRevisions(Array.isArray(list) ? list : []);
          if (list.length > 0) {
            setSelectedRevision(list[0]);
          }
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to load revision history:', err);
        if (isMounted) {
          setRevisions([]);
          setSelectedRevision(null);
          setLoading(false);
        }
      });

    return () => { isMounted = false; };
  }, [isOpen, documentId, currentRevision]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/70 p-4 select-none">
      <div className="flex h-[600px] w-full max-w-4xl flex-col rounded-xl bg-white shadow-2xl border border-ink-200 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-cream-50/80 px-4 py-3">
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-seal-600" />
            <h3 className="font-bold text-ink-900 text-sm">
              Lịch sử phiên bản sửa đổi (Revision History)
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-ink-400 hover:bg-ink-100 hover:text-ink-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body: 2 Columns */}
        <div className="flex flex-1 min-h-0">
          {/* Left Column: Revision Timeline */}
          <div className="w-[300px] border-r border-ink-200 bg-cream-50/30 p-3 overflow-y-auto space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-ink-400 mb-2">
              Các mốc thời gian ({revisions.length})
            </div>

            {loading ? (
              <p className="py-6 text-center text-xs text-ink-400">Đang tải lịch sử...</p>
            ) : revisions.length === 0 ? (
              <p className="py-6 text-center text-xs text-ink-400 italic">Chưa có lịch sử sửa đổi.</p>
            ) : (
              revisions.map((rev, index) => {
                const isSelected = selectedRevision?.id === rev.id;
                return (
                  <div
                    key={rev.id || index}
                    onClick={() => setSelectedRevision(rev)}
                    className={`cursor-pointer rounded-lg border p-2.5 transition-all ${
                      isSelected
                        ? 'border-seal-500 bg-seal-50/50 ring-1 ring-seal-500'
                        : 'border-ink-200 bg-white hover:border-ink-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-ink-900">
                      <span>Phiên bản #{rev.revisionNumber || (revisions.length - index)}</span>
                      {index === 0 && (
                        <span className="rounded bg-teal-50 px-1.5 py-0.2 text-[10px] font-semibold text-teal-700 border border-teal-200">
                          Mới nhất
                        </span>
                      )}
                    </div>

                    <div className="mt-1 flex items-center gap-1.5 text-[11px] text-ink-500">
                      <Clock className="h-3 w-3 text-ink-400" />
                      <span>{new Date(rev.createdAt).toLocaleString('vi-VN')}</span>
                    </div>

                    <div className="mt-1 flex items-center gap-1.5 text-[11px] text-ink-600">
                      <User className="h-3 w-3 text-ink-400" />
                      <span>{rev.updatedByName || 'Cán bộ'}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right Column: Preview of Selected Revision */}
          <div className="flex-1 flex flex-col min-w-0 p-4 bg-white overflow-y-auto">
            {selectedRevision ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-ink-100 pb-3">
                  <div>
                    <h4 className="text-sm font-bold text-ink-900">
                      Chi tiết Phiên bản #{selectedRevision.revisionNumber}
                    </h4>
                    <p className="text-xs text-ink-500">
                      Ghi nhận lúc: {new Date(selectedRevision.createdAt).toLocaleString('vi-VN')} bởi {selectedRevision.updatedByName || 'Cán bộ'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (onRestoreRevision) {
                        onRestoreRevision(selectedRevision);
                        onClose();
                      }
                    }}
                    className="inline-flex items-center gap-1.5 rounded-md bg-seal-600 px-3 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-seal-700"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Khôi phục bản này</span>
                  </button>
                </div>

                {/* Content View */}
                <div className="rounded-lg border border-ink-200 bg-cream-50/30 p-4 text-xs font-serif leading-relaxed text-ink-800 max-h-[380px] overflow-y-auto whitespace-pre-wrap">
                  {typeof selectedRevision.content === 'string'
                    ? selectedRevision.content
                    : JSON.stringify(selectedRevision.content, null, 2)}
                </div>
              </div>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-ink-400">
                Chọn một phiên bản bên trái để xem trước.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
