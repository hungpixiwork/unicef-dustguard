import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableHeader } from '@tiptap/extension-table-header';
import { TableCell } from '@tiptap/extension-table-cell';
import { Underline } from '@tiptap/extension-underline';
import { Placeholder } from '@tiptap/extension-placeholder';
import { TextAlign } from '@tiptap/extension-text-align';

import { MergeField } from './extensions/MergeFieldNode';
import { PageBreak } from './extensions/PageBreakNode';
import OfficialHeaderBlock from './extensions/OfficialHeaderBlock';
import SignatureBlock from './extensions/SignatureBlock';
import EditorToolbar from './EditorToolbar';
import DocumentOutline from './DocumentOutline';
import DataBindingsPanel from './DataBindingsPanel';
import A4PageContainer from './A4PageContainer';
import RevisionHistoryModal from './RevisionHistoryModal';
import PreflightCheckModal from './PreflightCheckModal';
import { interpolateAst, buildBindingsFromDomain } from '../../lib/document-template-engine';
import { validateDocumentVariables, extractVariablesFromContent } from '../../lib/documents/variable-registry';
import { DOCUMENT_STATUS_META } from '../../lib/documents/document.types';

export default function GoogleDocsEditor({
  initialDocument,
  onSaveDocument,
  onExportDocx,
  onExportPdf,
  siteData = {},
  inspectionData = {},
  complaintData = {},
  telemetryData = {}
}) {
  const [documentState, setDocumentState] = useState(initialDocument || {
    id: 'doc-new',
    title: 'Biên bản kiểm tra hiện trường công trình',
    type: 'inspection_record',
    status: 'draft',
    revision: 1,
    content: null,
    metadata: {
      documentNumber: '.../BB-KT',
      parentAgency: 'ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI',
      issuingAgency: 'ĐOÀN KIỂM TRA LIÊN NGÀNH'
    }
  });

  const [saving, setSaving] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const [zoom, setZoom] = useState(100);
  const [wordCount, setWordCount] = useState(0);
  const [showHistory, setShowHistory] = useState(false);
  const [showBindingsPanel, setShowBindingsPanel] = useState(true);
  const [showOutlinePanel, setShowOutlinePanel] = useState(true);
  const [showPreflight, setShowPreflight] = useState(false);
  const [preflightExportType, setPreflightExportType] = useState('pdf');
  const [isTemplateMode, setIsTemplateMode] = useState(false);
  const [usedVariables, setUsedVariables] = useState([]);

  // Derive domain bindings map
  const domainBindings = useMemo(() => {
    return buildBindingsFromDomain(siteData, inspectionData, complaintData, telemetryData);
  }, [siteData, inspectionData, complaintData, telemetryData]);

  // Initialize Tiptap Editor
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] }
      }),
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph']
      }),
      Table.configure({
        resizable: true
      }),
      TableRow,
      TableHeader,
      TableCell,
      MergeField.configure({
        bindings: domainBindings,
        templateMode: isTemplateMode
      }),
      PageBreak,
      Placeholder.configure({
        placeholder: 'Bắt đầu soạn thảo văn bản hành chính theo chuẩn Nghị định 30...'
      })
    ],
    content: documentState.content || '<h1 style="text-align: center;">BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG CÔNG TRÌNH</h1><p>Nội dung đang được khởi tạo...</p>',
    autofocus: true,
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-xl focus:outline-none max-w-none text-ink-900 leading-relaxed font-serif min-h-[700px]'
      }
    }
  });

  // Keep editor extension options in sync with bindings and mode
  useEffect(() => {
    if (!editor) return;
    editor.extensionManager.extensions.forEach(ext => {
      if (ext.name === 'mergeField') {
        ext.options.bindings = domainBindings;
        ext.options.templateMode = isTemplateMode;
      }
    });
    editor.view.update(editor.view.props);
  }, [editor, domainBindings, isTemplateMode]);

  // Calculate word count & extracted variables on editor update
  useEffect(() => {
    if (!editor) return;

    const updateStats = () => {
      const text = editor.getText();
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;
      setWordCount(words);

      const json = editor.getJSON();
      const extracted = extractVariablesFromContent(json);
      setUsedVariables(extracted);
    };

    updateStats();
    editor.on('update', updateStats);
    return () => editor.off('update', updateStats);
  }, [editor]);

  // Debounced Autosave (1.5s)
  const saveTimeoutRef = useRef(null);

  const triggerAutosave = useCallback(async (contentJSON) => {
    setSaving(true);
    try {
      if (onSaveDocument) {
        await onSaveDocument({
          ...documentState,
          content: contentJSON,
          updatedAt: new Date().toISOString()
        });
      }
      setLastSavedAt(new Date());
    } catch (err) {
      console.error('Autosave error:', err);
    } finally {
      setSaving(false);
    }
  }, [documentState, onSaveDocument]);

  useEffect(() => {
    if (!editor) return;

    const handleUpdate = () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
      saveTimeoutRef.current = setTimeout(() => {
        const json = editor.getJSON();
        triggerAutosave(json);
      }, 1500);
    };

    editor.on('update', handleUpdate);
    return () => {
      editor.off('update', handleUpdate);
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, [editor, triggerAutosave]);

  // Keyboard Shortcuts (Ctrl+S for save)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        if (editor) {
          triggerAutosave(editor.getJSON());
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [editor, triggerAutosave]);

  // Insert Variable at cursor position as MergeField node
  const handleInsertVariable = (key) => {
    if (!editor) return;
    editor.chain().focus().insertContent({
      type: 'mergeField',
      attrs: { key }
    }).run();
  };

  // Apply Template
  const handleSelectTemplate = (template) => {
    if (!editor || !template?.initialContent) return;
    const resolvedContent = interpolateAst(template.initialContent, domainBindings);
    editor.commands.setContent(resolvedContent);
    setDocumentState(prev => ({
      ...prev,
      title: template.title,
      type: template.type,
      templateId: template.id
    }));
  };

  // Restore Revision
  const handleRestoreRevision = (rev) => {
    if (!editor || !rev?.content) return;
    try {
      const parsed = typeof rev.content === 'string' ? JSON.parse(rev.content) : rev.content;
      editor.commands.setContent(parsed);
    } catch {
      editor.commands.setContent(`<p>${String(rev.content)}</p>`);
    }
  };

  // Pre-flight check & export triggers
  const validationResult = useMemo(() => {
    if (!editor) return { valid: true, totalUsed: 0, missingCount: 0, missing: [], resolved: [] };
    return validateDocumentVariables(editor.getJSON(), domainBindings);
  }, [editor, domainBindings, usedVariables]);

  const handleTriggerPreflight = () => {
    setShowPreflight(true);
  };

  const handleExportPdfWithCheck = () => {
    if (!validationResult.valid) {
      setPreflightExportType('pdf');
      setShowPreflight(true);
    } else if (onExportPdf) {
      onExportPdf(editor?.getJSON());
    } else {
      window.print();
    }
  };

  const handleExportDocxWithCheck = () => {
    if (!validationResult.valid) {
      setPreflightExportType('docx');
      setShowPreflight(true);
    } else if (onExportDocx) {
      onExportDocx(editor?.getJSON());
    }
  };

  const handleProceedExportAfterPreflight = () => {
    if (preflightExportType === 'docx' && onExportDocx) {
      onExportDocx(editor?.getJSON());
    } else if (onExportPdf) {
      onExportPdf(editor?.getJSON());
    } else {
      window.print();
    }
  };

  // Status Badge Metadata
  const statusMeta = DOCUMENT_STATUS_META[documentState.status] || DOCUMENT_STATUS_META.draft;

  // Header & Footer semantic blocks
  const headerBlock = (
    <OfficialHeaderBlock
      parentAgency={documentState.metadata?.parentAgency || 'ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI'}
      issuingAgency={documentState.metadata?.issuingAgency || 'ĐOÀN KIỂM TRA LIÊN NGÀNH'}
      documentNumber={documentState.metadata?.documentNumber || '.../BB-KT'}
      location={domainBindings['doc.location'] || 'Hà Nội'}
      dateText={domainBindings['doc.date_text'] || 'ngày 26 tháng 08 năm 2026'}
    />
  );

  const footerBlock = (
    <SignatureBlock
      leftTitle="ĐẠI DIỆN ĐƠN VỊ ĐƯỢC KIỂM TRA"
      leftSubtitle="(Ký, ghi rõ họ tên và đóng dấu)"
      leftSigner={domainBindings['site.manager'] || 'Chỉ huy trưởng công trường'}
      rightTitle={domainBindings['doc.signer_title'] || 'TRƯỞNG ĐOÀN KIỂM TRA'}
      rightSubtitle="(Ký, ghi rõ họ tên và đóng dấu)"
      rightSigner={domainBindings['doc.signer_name'] || 'Trần Văn Nam'}
      isSigned={documentState.status === 'signed'}
      signHash={documentState.hash}
      signTimestamp={documentState.signedAt}
    />
  );

  return (
    <div className="flex h-screen w-full flex-col bg-cream-100 overflow-hidden font-sans">
      {/* 1. Top Fixed Toolbar */}
      <EditorToolbar
        editor={editor}
        onSave={() => editor && triggerAutosave(editor.getJSON())}
        onExportDocx={handleExportDocxWithCheck}
        onExportPdf={handleExportPdfWithCheck}
        onPrint={() => window.print()}
        onOpenHistory={() => setShowHistory(true)}
        onOpenBindings={() => setShowBindingsPanel(prev => !prev)}
        onToggleOutline={() => setShowOutlinePanel(prev => !prev)}
        onRunPreflight={handleTriggerPreflight}
        saving={saving}
        status={documentState.status}
        lastSavedAt={lastSavedAt}
        isTemplateMode={isTemplateMode}
        onToggleTemplateMode={() => setIsTemplateMode(prev => !prev)}
      />

      {/* 2. Main 3-Column Workspace */}
      <div className="flex flex-1 min-h-0 w-full overflow-hidden">
        {/* Left Column: Outline & Templates */}
        {showOutlinePanel && (
          <DocumentOutline
            editor={editor}
            onSelectTemplate={handleSelectTemplate}
            activeTemplateId={documentState.templateId}
          />
        )}

        {/* Center Column: White A4 Page Viewport */}
        <main className="flex-1 min-w-0 h-full overflow-y-auto bg-cream-200/60 p-4 md:p-8 flex justify-center custom-scrollbar">
          <A4PageContainer
            header={headerBlock}
            footer={footerBlock}
            pageNumber={1}
            totalPages={1}
            zoom={zoom}
            showRuler={true}
          >
            <EditorContent editor={editor} />
          </A4PageContainer>
        </main>

        {/* Right Column: Data Bindings Panel */}
        {showBindingsPanel && (
          <DataBindingsPanel
            onInsertVariable={handleInsertVariable}
            domainBindings={domainBindings}
            usedVariables={usedVariables}
          />
        )}
      </div>

      {/* 3. Bottom Status Bar */}
      <footer className="h-8 shrink-0 border-t border-ink-200 bg-white px-4 flex items-center justify-between text-[11px] text-ink-600 select-none print:hidden">
        <div className="flex items-center gap-4">
          <span className="font-semibold text-ink-900">Trang 1 / 1</span>
          <span>{wordCount} từ</span>
          <span className="text-ink-400">•</span>
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.color}`}>
            {statusMeta.label}
          </span>
          {lastSavedAt && (
            <span className="text-ink-400">
              Đã lưu lúc {lastSavedAt.toLocaleTimeString('vi-VN')}
            </span>
          )}
        </div>

        {/* Zoom Slider Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setZoom(prev => Math.max(50, prev - 10))}
            className="px-1.5 py-0.5 rounded hover:bg-cream-100 font-bold"
            title="Thu nhỏ"
          >
            -
          </button>
          <span className="w-12 text-center font-mono font-bold text-ink-800">{zoom}%</span>
          <button
            type="button"
            onClick={() => setZoom(prev => Math.min(150, prev + 10))}
            className="px-1.5 py-0.5 rounded hover:bg-cream-100 font-bold"
            title="Phóng to"
          >
            +
          </button>
          <button
            type="button"
            onClick={() => setZoom(100)}
            className="ml-1 text-[10px] text-seal-700 hover:underline font-semibold"
          >
            100%
          </button>
        </div>
      </footer>

      {/* 4. Revision History Modal */}
      <RevisionHistoryModal
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        documentId={documentState.id}
        currentRevision={documentState.revision}
        onRestoreRevision={handleRestoreRevision}
      />

      {/* 5. Pre-flight Check Modal */}
      <PreflightCheckModal
        isOpen={showPreflight}
        onClose={() => setShowPreflight(false)}
        validationResult={validationResult}
        onProceedExport={handleProceedExportAfterPreflight}
        exportType={preflightExportType}
      />
    </div>
  );
}
