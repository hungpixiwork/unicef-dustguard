import React, { useState, useEffect } from 'react';
import { ListTree, LayoutTemplate, FileText, ChevronRight, AlertTriangle } from 'lucide-react';
import { OFFICIAL_TEMPLATES } from '../../lib/document-template-engine';

export default function DocumentOutline({
  editor,
  onSelectTemplate,
  activeTemplateId
}) {
  const [activeTab, setActiveTab] = useState('outline'); // 'outline' | 'templates'
  const [headings, setHeadings] = useState([]);
  const [pendingTemplate, setPendingTemplate] = useState(null);

  // Extract Headings from Tiptap editor
  useEffect(() => {
    if (!editor) return;

    const updateHeadings = () => {
      const items = [];
      editor.state.doc.descendants((node, pos) => {
        if (node.type.name === 'heading') {
          items.push({
            level: node.attrs.level,
            text: node.textContent,
            pos
          });
        }
      });
      setHeadings(items);
    };

    updateHeadings();
    editor.on('update', updateHeadings);
    return () => editor.off('update', updateHeadings);
  }, [editor]);

  // Click heading to scroll into view
  const handleScrollToHeading = (pos) => {
    if (!editor) return;
    editor.commands.setTextSelection(pos);
    const domNode = editor.view.nodeDOM(pos);
    if (domNode && domNode.scrollIntoView) {
      domNode.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const handleApplyTemplate = (tmpl) => {
    setPendingTemplate(tmpl);
  };

  const confirmTemplateChange = () => {
    if (pendingTemplate && onSelectTemplate) {
      onSelectTemplate(pendingTemplate);
    }
    setPendingTemplate(null);
  };

  return (
    <aside className="flex h-full w-[270px] shrink-0 flex-col border-r border-ink-200 bg-white select-none print:hidden font-sans">
      {/* Tab Switcher */}
      <div className="flex border-b border-ink-200 bg-cream-50/80 p-1 gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('outline')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'outline'
              ? 'bg-white text-seal-700 shadow-xs border border-ink-200/80'
              : 'text-ink-500 hover:text-ink-900'
          }`}
        >
          <ListTree className="h-3.5 w-3.5" />
          <span>Cấu trúc</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('templates')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'templates'
              ? 'bg-white text-seal-700 shadow-xs border border-ink-200/80'
              : 'text-ink-500 hover:text-ink-900'
          }`}
        >
          <LayoutTemplate className="h-3.5 w-3.5" />
          <span>Mẫu văn bản</span>
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 min-h-0 overflow-y-auto p-3">
        {activeTab === 'outline' ? (
          <div className="space-y-1.5">
            <div className="text-[10px] font-bold text-ink-400 uppercase tracking-wider px-1 mb-2">
              Mục lục tự động ({headings.length})
            </div>

            {headings.length === 0 ? (
              <div className="text-center py-8 text-xs text-ink-400">
                <FileText className="h-8 w-8 mx-auto mb-2 text-ink-300 opacity-60" />
                <p>Chưa có đề mục (H1, H2, H3)</p>
                <p className="text-[10px] text-ink-400 mt-1">Đề mục thêm vào văn bản sẽ tự động hiển thị tại đây.</p>
              </div>
            ) : (
              headings.map((h, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleScrollToHeading(h.pos)}
                  className={`w-full text-left rounded-lg py-1.5 px-2 text-xs transition-colors hover:bg-cream-100 hover:text-seal-800 flex items-start gap-1.5 cursor-pointer ${
                    h.level === 1 ? 'font-black text-ink-900' :
                    h.level === 2 ? 'font-bold text-ink-800 pl-4' :
                    'font-medium text-ink-600 pl-6 text-[11px]'
                  }`}
                >
                  <span className="text-ink-300 shrink-0 mt-0.5">•</span>
                  <span className="truncate">{h.text || `[Mục ${i + 1}]`}</span>
                </button>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-[10px] font-bold text-ink-400 uppercase tracking-wider px-1">
              Thư viện mẫu chuẩn (NĐ 30/2020 & 118/2021)
            </div>

            {OFFICIAL_TEMPLATES.map((tmpl) => {
              const isActive = activeTemplateId === tmpl.id;

              return (
                <div
                  key={tmpl.id}
                  className={`rounded-xl border p-3 transition-all ${
                    isActive
                      ? 'border-seal-600 bg-seal-50/40 shadow-xs'
                      : 'border-ink-200 bg-white hover:border-seal-400'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <span className="text-[10px] font-bold uppercase text-seal-700 bg-cream-100 px-1.5 py-0.5 rounded">
                      {tmpl.category}
                    </span>
                    {isActive && (
                      <span className="text-[10px] font-bold text-teal-800 bg-teal-100 px-1.5 py-0.5 rounded">
                        Đang chọn
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-xs text-ink-900 mt-1.5 leading-snug">
                    {tmpl.title}
                  </h4>

                  <p className="text-[11px] text-ink-500 mt-1 line-clamp-2">
                    {tmpl.description}
                  </p>

                  <div className="mt-2.5 pt-2 border-t border-ink-100 flex items-center justify-between">
                    <span className="text-[10px] text-ink-400 font-mono">{tmpl.standard}</span>
                    <button
                      type="button"
                      onClick={() => handleApplyTemplate(tmpl)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-seal-700 hover:text-seal-900 cursor-pointer"
                    >
                      <span>Áp dụng</span>
                      <ChevronRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Confirmation Modal when changing template */}
      {pendingTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-ink-200 space-y-4">
            <div className="flex items-center gap-3 text-amber-700">
              <div className="p-2 rounded-xl bg-amber-100">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-ink-900">Xác nhận thay đổi mẫu</h3>
            </div>
            <p className="text-xs text-ink-600 leading-relaxed">
              Việc áp dụng mẫu <strong>"{pendingTemplate.title}"</strong> sẽ thay thế toàn bộ nội dung hiện tại bằng cấu trúc của mẫu mới. Các trường dữ liệu thật (SSOT) sẽ được tự động điền.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-ink-100">
              <button
                type="button"
                onClick={() => setPendingTemplate(null)}
                className="px-4 py-2 rounded-lg border border-ink-200 text-xs font-bold text-ink-700 hover:bg-cream-100 transition"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={confirmTemplateChange}
                className="px-4 py-2 rounded-lg bg-seal-700 text-white text-xs font-bold hover:bg-seal-800 transition"
              >
                Đồng ý áp dụng
              </button>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
