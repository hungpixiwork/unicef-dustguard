import React from 'react';
import PageRuler from './PageRuler';

/**
 * A4PageContainer — Container khổ giấy A4 chuẩn 210mm x 297mm
 * Căn lề chuẩn Nghị định 30/2020/NĐ-CP:
 * - Lề trái: 30mm (đóng ghim)
 * - Lề phải: 15mm
 * - Lề trên: 20mm
 * - Lề dưới: 20mm
 */
export default function A4PageContainer({
  children,
  header,
  footer,
  pageNumber = 1,
  totalPages = 1,
  zoom = 100,
  showRuler = true
}) {
  const zoomScale = zoom / 100;

  return (
    <div className="flex flex-col items-center w-full transition-transform origin-top" style={{ transform: `scale(${zoomScale})` }}>
      {/* Top Page Ruler */}
      {showRuler && <PageRuler />}

      {/* Main A4 White Sheet */}
      <div
        className="relative mx-auto my-4 w-full max-w-[820px] bg-white text-ink-900 shadow-lg border border-ink-200/80 rounded-xs print:m-0 print:w-full print:max-w-none print:shadow-none print:border-none"
        style={{
          minHeight: '1120px', // Standard 297mm ratio in ~96 DPI screen
          padding: '75px 56px 75px 113px', // 20mm top/bottom, 15mm right, 30mm left
          fontFamily: '"Times New Roman", Times, serif',
          fontSize: '13pt',
          lineHeight: '1.45'
        }}
      >
        {/* Visual Page Corner Indicator */}
        <div className="absolute right-4 top-3 text-[10px] font-sans font-semibold text-ink-400 select-none print:hidden flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-teal-500"></span>
          <span>Trang {pageNumber} / {totalPages} (Khổ A4)</span>
        </div>

        {/* Header Block if present */}
        {header && (
          <div className="mb-5 pb-3">
            {header}
          </div>
        )}

        {/* Main Document Content */}
        <div className="tiptap-a4-content min-h-[850px] outline-none text-ink-900 leading-relaxed font-serif">
          {children}
        </div>

        {/* Footer Block if present */}
        {footer && (
          <div className="mt-8 pt-4">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
