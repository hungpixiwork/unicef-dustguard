import React, { useState, useMemo } from 'react';
import {
  Database,
  Plus,
  Search,
  ChevronDown,
  ChevronRight,
  CheckCircle,
  Building2,
  ClipboardCheck,
  Wind,
  Scale,
  FileText,
  PenTool,
  AlertCircle
} from 'lucide-react';
import { VARIABLE_REGISTRY, VARIABLE_GROUPS } from '../../lib/documents/variable-registry';

const GROUP_ICONS = {
  site: Building2,
  inspection: ClipboardCheck,
  telemetry: Wind,
  legal: Scale,
  doc: FileText,
  signer: PenTool
};

export default function DataBindingsPanel({
  onInsertVariable,
  domainBindings = {},
  usedVariables = []
}) {
  const [search, setSearch] = useState('');
  const [copiedKey, setCopiedKey] = useState('');
  const [collapsedGroups, setCollapsedGroups] = useState({});

  const toggleGroup = (groupId) => {
    setCollapsedGroups(prev => ({ ...prev, [groupId]: !prev[groupId] }));
  };

  // Group variables
  const groupedVars = useMemo(() => {
    const query = search.trim().toLowerCase();
    const groups = {};

    Object.keys(VARIABLE_GROUPS).forEach(k => {
      const g = VARIABLE_GROUPS[k];
      groups[g.id] = { ...g, items: [] };
    });

    VARIABLE_REGISTRY.forEach(v => {
      const match = !query || 
        v.label.toLowerCase().includes(query) || 
        v.key.toLowerCase().includes(query) ||
        v.source.toLowerCase().includes(query);

      if (match && groups[v.group]) {
        groups[v.group].items.push(v);
      }
    });

    return groups;
  }, [search]);

  // Calculate quick stats
  const totalVars = VARIABLE_REGISTRY.length;
  const usedCount = usedVariables.length;
  const missingCount = usedVariables.filter(k => !domainBindings[k]).length;

  const handleInsert = (key) => {
    if (onInsertVariable) {
      onInsertVariable(key);
    }
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(''), 1500);
  };

  return (
    <aside className="flex h-full w-[290px] shrink-0 flex-col border-l border-ink-200 bg-white select-none print:hidden font-sans">
      {/* 1. Panel Header */}
      <div className="flex items-center justify-between border-b border-ink-200 bg-cream-50/80 px-3.5 py-3">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-seal-700" />
          <span className="text-xs font-bold text-ink-900 uppercase tracking-wide">Dữ Liệu Văn Bản (SSOT)</span>
        </div>
      </div>

      {/* 2. Quick Search & Stats */}
      <div className="border-b border-ink-100 p-3 space-y-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-ink-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm trường dữ liệu (PM10, công trình...)"
            className="w-full rounded-lg border border-ink-200 bg-cream-50/40 pl-8 pr-2.5 py-1.5 text-xs text-ink-900 placeholder:text-ink-400 focus:border-seal-600 focus:bg-white focus:outline-none"
          />
        </div>

        <div className="flex items-center justify-between text-[11px] px-1 font-medium">
          <span className="text-ink-500">
            Đã dùng: <strong className="text-teal-800">{usedCount}</strong>
          </span>
          {missingCount > 0 ? (
            <span className="text-rose-700 font-bold flex items-center gap-1">
              <AlertCircle className="h-3 w-3" />
              Thiếu dữ liệu: {missingCount}
            </span>
          ) : (
            <span className="text-teal-700 flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              Đầy đủ SSOT
            </span>
          )}
        </div>
      </div>

      {/* 3. Grouped Accordion List */}
      <div className="flex-1 min-h-0 overflow-y-auto p-2 space-y-2">
        {Object.values(groupedVars).map(group => {
          if (group.items.length === 0) return null;
          const isCollapsed = collapsedGroups[group.id];
          const Icon = GROUP_ICONS[group.id] || Database;

          return (
            <div key={group.id} className="rounded-xl border border-ink-200/80 bg-cream-50/30 overflow-hidden">
              {/* Group Header Button */}
              <button
                type="button"
                onClick={() => toggleGroup(group.id)}
                className="w-full flex items-center justify-between px-3 py-2 bg-cream-100/60 hover:bg-cream-100 transition text-left cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Icon className="h-3.5 w-3.5 text-seal-700" />
                  <span className="text-xs font-bold text-ink-900">{group.label}</span>
                  <span className="text-[10px] text-ink-400 font-mono">({group.items.length})</span>
                </div>
                {isCollapsed ? (
                  <ChevronRight className="h-3.5 w-3.5 text-ink-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-ink-400" />
                )}
              </button>

              {/* Group Items */}
              {!isCollapsed && (
                <div className="p-1.5 space-y-1 bg-white divide-y divide-ink-100/60">
                  {group.items.map(v => {
                    const boundValue = domainBindings[v.key];
                    const isMissing = boundValue === undefined || boundValue === null || String(boundValue).trim() === '';
                    const isCopied = copiedKey === v.key;

                    return (
                      <div
                        key={v.key}
                        className="group pt-1.5 first:pt-0 flex flex-col gap-1 rounded-md p-1.5 hover:bg-cream-50/80 transition"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex flex-col min-w-0 pr-1">
                            <span className="text-xs font-bold text-ink-900 truncate">{v.label}</span>
                            <span className="font-mono text-[10px] text-ink-400 truncate">{v.key}</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleInsert(v.key)}
                            className={`inline-flex items-center gap-1 shrink-0 rounded-md px-2 py-1 text-[10px] font-bold transition-all cursor-pointer ${
                              isCopied
                                ? 'bg-teal-700 text-white'
                                : 'bg-seal-700 text-white hover:bg-seal-800'
                            }`}
                            title="Chèn biến này vào văn bản"
                          >
                            {isCopied ? (
                              <>
                                <CheckCircle className="h-3 w-3" />
                                <span>Đã chèn</span>
                              </>
                            ) : (
                              <>
                                <Plus className="h-3 w-3" />
                                <span>Chèn</span>
                              </>
                            )}
                          </button>
                        </div>

                        {/* Resolved Value Preview */}
                        <div className="text-[11px] leading-tight truncate">
                          {isMissing ? (
                            <span className="text-rose-600 font-bold italic">Chưa có dữ liệu</span>
                          ) : (
                            <span className="text-teal-900 font-medium">{String(boundValue)}</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 4. Footer Note */}
      <div className="border-t border-ink-100 bg-cream-50/70 p-2.5 text-[11px] text-ink-500">
        <p className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-teal-600 shrink-0"></span>
          <span>Bấm <strong>Chèn</strong> để thêm trường liên kết dữ liệu thật tại vị trí con trỏ.</span>
        </p>
      </div>
    </aside>
  );
}
