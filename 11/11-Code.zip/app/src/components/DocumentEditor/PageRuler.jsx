import React from 'react';

/**
 * PageRuler — Thước đo lề trực quan chuẩn A4 (210mm)
 * Căn lề NĐ 30/2020: Lề trái 30mm (~14.3%), Lề phải 15mm (~7.1%)
 */
export default function PageRuler() {
  const marks = Array.from({ length: 22 }, (_, i) => i);

  return (
    <div className="relative mx-auto h-5 w-full max-w-[820px] bg-cream-100 border-b border-ink-200 text-[9px] font-mono text-ink-500 select-none print:hidden flex items-end px-[56px] pl-[113px]">
      {/* Vùng lề trái (30mm) */}
      <div className="absolute left-0 top-0 bottom-0 w-[113px] bg-amber-100/40 border-r border-dashed border-amber-400 flex items-center justify-center text-[8px] text-amber-700 font-sans font-bold">
        Lề trái: 30mm
      </div>

      {/* Thước chia vạch 0 - 21 cm */}
      <div className="flex-1 flex justify-between items-end h-full">
        {marks.map((cm) => (
          <div key={cm} className="flex flex-col items-center">
            <span className="text-[8px] leading-none mb-0.5">{cm}</span>
            <div className={`w-[1px] bg-ink-400 ${cm % 5 === 0 ? 'h-2.5 bg-ink-700' : 'h-1.5'}`} />
          </div>
        ))}
      </div>

      {/* Vùng lề phải (15mm) */}
      <div className="absolute right-0 top-0 bottom-0 w-[56px] bg-amber-100/40 border-l border-dashed border-amber-400 flex items-center justify-center text-[8px] text-amber-700 font-sans font-bold">
        15mm
      </div>
    </div>
  );
}
