import React, { useState } from 'react';
import {
  Undo,
  Redo,
  Bold,
  Italic,
  Underline as UnderlineIcon,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Table as TableIcon,
  Plus,
  Trash2,
  FileDown,
  Printer,
  History,
  Code,
  Scissors,
  CheckCircle2,
  ChevronDown,
  Sparkles,
  ShieldCheck,
  PanelLeft,
  PanelRight,
  Eye
} from 'lucide-react';

export default function EditorToolbar({
  editor,
  onSave,
  onExportDocx,
  onExportPdf,
  onPrint,
  onOpenHistory,
  onOpenBindings,
  onToggleOutline,
  onRunPreflight,
  saving = false,
  status = 'draft',
  lastSavedAt = null,
  isTemplateMode = false,
  onToggleTemplateMode
}) {
  const [showTableMenu, setShowTableMenu] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  if (!editor) return null;

  return (
    <header className="flex flex-col border-b border-ink-200 bg-white select-none print:hidden font-sans">
      {/* 1. Sub-Toolbar: Top Header bar */}
      <div className="flex items-center justify-between border-b border-ink-100 px-4 py-2 bg-cream-50/70">
        {/* Left: View Controls */}
        <div className="flex items-center gap-2">
          {onToggleOutline && (
            <button
              type="button"
              onClick={onToggleOutline}
              className="p-1.5 rounded-lg border border-ink-200 hover:bg-cream-100 text-ink-700 text-xs font-bold flex items-center gap-1 cursor-pointer"
              title="Ẩn/Hiện Mục lục & Mẫu"
            >
              <PanelLeft className="h-4 w-4" />
            </button>
          )}

          {onOpenBindings && (
            <button
              type="button"
              onClick={onOpenBindings}
              className="p-1.5 rounded-lg border border-ink-200 hover:bg-cream-100 text-ink-700 text-xs font-bold flex items-center gap-1 cursor-pointer"
              title="Ẩn/Hiện Panel Dữ liệu SSOT"
            >
              <PanelRight className="h-4 w-4" />
            </button>
          )}

          <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

          {/* Template Mode Switch */}
          <button
            type="button"
            onClick={onToggleTemplateMode}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
              isTemplateMode
                ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                : 'bg-white text-ink-700 border-ink-200 hover:bg-cream-100'
            }`}
            title="Chuyển đổi giữa chế độ xem văn bản thật và chế độ xem mã biến"
          >
            <Code className="h-3.5 w-3.5" />
            <span>{isTemplateMode ? 'Chế độ Mẫu (Raw)' : 'Chế độ Văn bản (Thật)'}</span>
          </button>
        </div>

        {/* Right: Actions (Pre-flight, History, Export, Save) */}
        <div className="flex items-center gap-2">
          {/* Pre-flight check button */}
          <button
            type="button"
            onClick={onRunPreflight}
            className="px-3 py-1.5 rounded-lg bg-teal-50 text-teal-800 border border-teal-200 text-xs font-bold hover:bg-teal-100 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ShieldCheck className="h-4 w-4 text-teal-700" />
            <span>Kiểm tra dữ liệu</span>
          </button>

          {/* History Button */}
          <button
            type="button"
            onClick={onOpenHistory}
            className="px-3 py-1.5 rounded-lg bg-white border border-ink-200 text-xs font-bold text-ink-700 hover:bg-cream-100 transition flex items-center gap-1.5 cursor-pointer"
          >
            <History className="h-4 w-4 text-ink-500" />
            <span>Lịch sử</span>
          </button>

          {/* Export Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowExportMenu(prev => !prev)}
              className="px-3 py-1.5 rounded-lg bg-[#231B14] text-white text-xs font-bold hover:bg-[#3D332A] transition flex items-center gap-1.5 cursor-pointer"
            >
              <FileDown className="h-4 w-4" />
              <span>Xuất ▾</span>
            </button>

            {showExportMenu && (
              <div className="absolute right-0 top-full mt-1 w-44 rounded-xl border border-ink-200 bg-white p-1.5 shadow-xl z-50 animate-in fade-in">
                <button
                  type="button"
                  onClick={() => {
                    setShowExportMenu(false);
                    if (onExportPdf) onExportPdf();
                  }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-ink-900 hover:bg-cream-100 rounded-lg flex items-center gap-2 cursor-pointer"
                >
                  <Printer className="h-4 w-4 text-seal-700" />
                  <span>Xuất PDF / In ấn</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowExportMenu(false);
                    if (onExportDocx) onExportDocx();
                  }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-ink-900 hover:bg-cream-100 rounded-lg flex items-center gap-2 cursor-pointer"
                >
                  <FileDown className="h-4 w-4 text-blue-700" />
                  <span>Xuất tệp DOCX (Word)</span>
                </button>
              </div>
            )}
          </div>

          {/* Save Button */}
          <button
            type="button"
            onClick={onSave}
            disabled={saving}
            className="px-4 py-1.5 rounded-lg bg-seal-700 text-white text-xs font-bold hover:bg-seal-800 transition disabled:opacity-50 flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            {saving && <span className="animate-spin inline-block">⏳</span>}
            <span>{saving ? 'Đang lưu...' : 'Lưu văn bản'}</span>
          </button>
        </div>
      </div>

      {/* 2. Main Formatting Toolbar */}
      <div className="flex flex-wrap items-center gap-1 px-3 py-1.5 overflow-x-auto bg-white">
        {/* Undo / Redo */}
        <button
          type="button"
          onClick={() => editor.chain().focus().undo().run()}
          disabled={!editor.can().undo()}
          className="p-1.5 rounded hover:bg-cream-100 text-ink-700 disabled:opacity-30 cursor-pointer"
          title="Hoàn tác (Ctrl+Z)"
        >
          <Undo className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().redo().run()}
          disabled={!editor.can().redo()}
          className="p-1.5 rounded hover:bg-cream-100 text-ink-700 disabled:opacity-30 cursor-pointer"
          title="Làm lại (Ctrl+Y)"
        >
          <Redo className="h-4 w-4" />
        </button>

        <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

        {/* Headings Selector */}
        <select
          value={
            editor.isActive('heading', { level: 1 }) ? 'h1' :
            editor.isActive('heading', { level: 2 }) ? 'h2' :
            editor.isActive('heading', { level: 3 }) ? 'h3' : 'p'
          }
          onChange={(e) => {
            const val = e.target.value;
            if (val === 'p') editor.chain().focus().setParagraph().run();
            else if (val === 'h1') editor.chain().focus().toggleHeading({ level: 1 }).run();
            else if (val === 'h2') editor.chain().focus().toggleHeading({ level: 2 }).run();
            else if (val === 'h3') editor.chain().focus().toggleHeading({ level: 3 }).run();
          }}
          className="rounded-lg border border-ink-200 px-2 py-1 text-xs font-bold text-ink-900 bg-white focus:outline-none cursor-pointer"
        >
          <option value="p">Văn bản thường</option>
          <option value="h1">Tiêu đề lớn (H1)</option>
          <option value="h2">Đề mục cấp 2 (H2)</option>
          <option value="h3">Đề mục cấp 3 (H3)</option>
        </select>

        <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

        {/* Bold / Italic / Underline */}
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive('bold') ? 'bg-ink-200 text-ink-900 font-black' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Đậm (Ctrl+B)"
        >
          <Bold className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive('italic') ? 'bg-ink-200 text-ink-900 font-black' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Nghiêng (Ctrl+I)"
        >
          <Italic className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive('underline') ? 'bg-ink-200 text-ink-900 font-black' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Gạch chân (Ctrl+U)"
        >
          <UnderlineIcon className="h-4 w-4" />
        </button>

        <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

        {/* Text Alignments */}
        <button
          type="button"
          onClick={() => editor.chain().focus().setTextAlign('left').run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive({ textAlign: 'left' }) ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Căn trái"
        >
          <AlignLeft className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().setTextAlign('center').run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive({ textAlign: 'center' }) ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Căn giữa"
        >
          <AlignCenter className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().setTextAlign('right').run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive({ textAlign: 'right' }) ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Căn phải"
        >
          <AlignRight className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().setTextAlign('justify').run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive({ textAlign: 'justify' }) ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Căn đều 2 bên (Justify)"
        >
          <AlignJustify className="h-4 w-4" />
        </button>

        <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

        {/* Lists */}
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive('bulletList') ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Danh sách gạch đầu dòng"
        >
          <List className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          className={`p-1.5 rounded transition cursor-pointer ${
            editor.isActive('orderedList') ? 'bg-ink-200 text-ink-900' : 'hover:bg-cream-100 text-ink-700'
          }`}
          title="Danh sách đánh số"
        >
          <ListOrdered className="h-4 w-4" />
        </button>

        <div className="h-4 w-[1px] bg-ink-200 mx-1"></div>

        {/* Table Management */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowTableMenu(prev => !prev)}
            className={`p-1.5 rounded transition flex items-center gap-1 cursor-pointer ${
              editor.isActive('table') ? 'bg-teal-100 text-teal-900 font-bold' : 'hover:bg-cream-100 text-ink-700'
            }`}
            title="Quản lý bảng biểu"
          >
            <TableIcon className="h-4 w-4" />
            <ChevronDown className="h-3 w-3" />
          </button>

          {showTableMenu && (
            <div className="absolute left-0 top-full mt-1 w-52 rounded-xl border border-ink-200 bg-white p-1.5 shadow-xl z-50 animate-in fade-in text-xs">
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-cream-100 rounded-lg font-bold"
              >
                + Chèn bảng mới (3x3)
              </button>
              <div className="my-1 border-t border-ink-100"></div>
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().addRowAfter().run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-cream-100 rounded-lg text-ink-700"
              >
                Thêm hàng phía dưới
              </button>
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().addColumnAfter().run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-cream-100 rounded-lg text-ink-700"
              >
                Thêm cột bên phải
              </button>
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().deleteRow().run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-rose-50 text-rose-700 rounded-lg"
              >
                Xóa hàng hiện tại
              </button>
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().deleteColumn().run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-rose-50 text-rose-700 rounded-lg"
              >
                Xóa cột hiện tại
              </button>
              <button
                type="button"
                onClick={() => {
                  editor.chain().focus().deleteTable().run();
                  setShowTableMenu(false);
                }}
                className="w-full text-left px-2.5 py-1.5 hover:bg-rose-100 text-rose-800 font-bold rounded-lg"
              >
                Xóa toàn bộ bảng
              </button>
            </div>
          )}
        </div>

        {/* Page Break */}
        <button
          type="button"
          onClick={() => {
            if (editor.commands.setPageBreak) {
              editor.commands.setPageBreak();
            } else {
              editor.chain().focus().insertContent('<div data-page-break="true"><hr class="page-break" /></div>').run();
            }
          }}
          className="p-1.5 rounded hover:bg-cream-100 text-ink-700 flex items-center gap-1 text-xs font-bold cursor-pointer"
          title="Ngắt trang (Page Break)"
        >
          <Scissors className="h-4 w-4" />
          <span>Ngắt trang</span>
        </button>
      </div>
    </header>
  );
}
