import React from 'react';

/**
 * OfficialHeaderBlock — Khối tiêu ngữ 2 cột chuẩn Nghị định 30/2020/NĐ-CP
 */
export default function OfficialHeaderBlock({
  parentAgency = 'ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI',
  issuingAgency = 'ĐOÀN KIỂM TRA LIÊN NGÀNH',
  documentNumber = '.../BB-KT',
  location = 'Hà Nội',
  dateText = 'ngày 26 tháng 08 năm 2026'
}) {
  return (
    <div className="grid grid-cols-2 text-center text-xs font-serif leading-snug pb-3 select-none border-b border-ink-200">
      {/* Cột trái: Cơ quan ban hành & Số hiệu */}
      <div className="border-r border-transparent pr-4">
        <p className="font-bold uppercase text-[11pt] tracking-tight">{parentAgency}</p>
        <p className="font-bold uppercase text-[11pt] text-seal-800 tracking-tight">{issuingAgency}</p>
        <div className="my-1.5 mx-auto h-[1px] w-20 bg-ink-900"></div>
        <p className="text-[10pt] italic">Số: {documentNumber}</p>
      </div>

      {/* Cột phải: Quốc hiệu, Tiêu ngữ & Ngày tháng năm */}
      <div className="pl-4">
        <p className="font-bold uppercase text-[11pt] tracking-tight">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p>
        <p className="font-bold text-[11pt]">Độc lập - Tự do - Hạnh phúc</p>
        <div className="my-1.5 mx-auto h-[1px] w-36 bg-ink-900"></div>
        <p className="text-[10pt] italic">{location}, {dateText}</p>
      </div>
    </div>
  );
}
