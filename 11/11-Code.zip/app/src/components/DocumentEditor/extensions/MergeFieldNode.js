import React, { useState } from 'react';
import { Node, mergeAttributes } from '@tiptap/core';
import { ReactNodeViewRenderer, NodeViewWrapper } from '@tiptap/react';
import { getVariableMeta } from '../../../lib/documents/variable-registry.js';

/**
 * React Component for rendering inline MergeField using React.createElement for zero-transpile compatibility
 */
export function MergeFieldView(props) {
  const { node, extension } = props;
  const { key, fallback } = node.attrs;
  const [showTooltip, setShowTooltip] = useState(false);

  // Get current domain bindings & template mode from extension options
  const bindings = extension?.options?.bindings || {};
  const isTemplateMode = extension?.options?.templateMode || false;

  const meta = getVariableMeta(key);
  const rawValue = bindings[key];
  const isMissing = rawValue === undefined || rawValue === null || String(rawValue).trim() === '' || String(rawValue).startsWith('{{');
  const displayValue = isMissing ? (fallback || meta?.label || key) : String(rawValue);

  if (isTemplateMode) {
    return React.createElement(
      NodeViewWrapper,
      { as: 'span', className: 'inline-block mx-0.5' },
      React.createElement(
        'span',
        {
          className: 'inline-flex items-center px-1.5 py-0.5 rounded font-mono text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 select-none'
        },
        `{{${key}}}`
      )
    );
  }

  return React.createElement(
    NodeViewWrapper,
    {
      as: 'span',
      className: 'relative inline-block mx-0.5',
      onMouseEnter: () => setShowTooltip(true),
      onMouseLeave: () => setShowTooltip(false)
    },
    React.createElement(
      'span',
      {
        className: `inline-flex items-center font-serif transition-colors px-1 py-0.5 rounded border select-none cursor-pointer ${
          isMissing
            ? 'bg-rose-50 text-rose-800 border-rose-300 border-dashed font-bold italic'
            : 'bg-teal-50/80 text-ink-900 border-teal-200/80 hover:border-teal-400 hover:bg-teal-100/70 font-semibold'
        }`
      },
      isMissing ? `[Thiếu: ${meta?.label || key}]` : displayValue
    ),
    showTooltip && React.createElement(
      'div',
      {
        className: 'absolute left-0 bottom-full mb-1.5 z-50 w-64 p-2.5 rounded-lg bg-ink-900 text-cream-50 text-xs shadow-xl border border-ink-700 pointer-events-none animate-in fade-in zoom-in-95 duration-100 font-sans'
      },
      React.createElement(
        'div',
        { className: 'flex items-center justify-between border-b border-ink-700 pb-1.5 mb-1.5' },
        React.createElement('span', { className: 'font-bold text-amber-400' }, meta?.label || key),
        React.createElement(
          'span',
          {
            className: `text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
              isMissing ? 'bg-rose-900 text-rose-200' : 'bg-teal-900 text-teal-200'
            }`
          },
          isMissing ? 'Thiếu dữ liệu' : 'Đã liên kết SSOT'
        )
      ),
      React.createElement(
        'div',
        { className: 'space-y-1 text-[11px] text-ink-300' },
        React.createElement('div', null, React.createElement('span', { className: 'text-ink-400' }, 'Khóa biến: '), React.createElement('span', { className: 'font-mono text-ink-200' }, key)),
        React.createElement('div', null, React.createElement('span', { className: 'text-ink-400' }, 'Nguồn: '), React.createElement('span', { className: 'text-ink-200' }, meta?.source || 'Hệ thống')),
        meta?.description && React.createElement('div', { className: 'italic text-ink-400 mt-1 border-t border-ink-800 pt-1' }, meta.description)
      )
    )
  );
}

/**
 * Tiptap MergeField Extension
 */
export const MergeField = Node.create({
  name: 'mergeField',
  group: 'inline',
  inline: true,
  selectable: true,
  atom: true,

  addOptions() {
    return {
      bindings: {},
      templateMode: false
    };
  },

  addAttributes() {
    return {
      key: {
        default: 'site.name',
        parseHTML: element => element.getAttribute('data-variable-key'),
        renderHTML: attributes => ({
          'data-variable-key': attributes.key
        })
      },
      fallback: {
        default: null,
        parseHTML: element => element.getAttribute('data-fallback'),
        renderHTML: attributes => attributes.fallback ? { 'data-fallback': attributes.fallback } : {}
      }
    };
  },

  parseHTML() {
    return [
      {
        tag: 'span[data-variable-key]'
      }
    ];
  },

  renderHTML({ HTMLAttributes, node }) {
    const key = node.attrs.key;
    const bindings = this.options.bindings || {};
    const val = bindings[key] || `{{${key}}}`;
    return [
      'span',
      mergeAttributes(HTMLAttributes, {
        class: 'merge-field-node inline-block px-1 py-0.2 rounded bg-teal-50 border border-teal-200 font-semibold',
        'data-variable-key': key
      }),
      val
    ];
  },

  addNodeView() {
    return ReactNodeViewRenderer(MergeFieldView);
  }
});
