import React from 'react';

/**
 * SignatureBlock — Khối chữ ký 2 cột chuẩn Nghị định 30/2020/NĐ-CP
 */
export default function SignatureBlock({
  leftTitle = 'ĐẠI DIỆN ĐƠN VỊ ĐƯỢC KIỂM TRA',
  leftSubtitle = '(Ký, ghi rõ họ tên và đóng dấu)',
  leftSigner = 'Nguyễn Văn Tuấn',
  rightTitle = 'TRƯỞNG ĐOÀN KIỂM TRA',
  rightSubtitle = '(Ký, ghi rõ họ tên và đóng dấu)',
  rightSigner = 'Trần Văn Nam',
  isSigned = false,
  signHash = null,
  signTimestamp = null
}) {
  return (
    <div className="grid grid-cols-2 text-center text-xs font-serif pt-6 mt-6 border-t border-ink-200 select-none">
      {/* Bên trái: Đại diện đơn vị / Bên kiểm tra */}
      <div className="pr-4">
        <p className="font-bold uppercase text-[11pt]">{leftTitle}</p>
        <p className="text-[9.5pt] italic text-ink-500 mb-14">{leftSubtitle}</p>
        <p className="font-bold text-[11pt] text-ink-900">{leftSigner}</p>
      </div>

      {/* Bên phải: Trưởng đoàn kiểm tra / Thẩm quyền ký */}
      <div className="pl-4 relative flex flex-col items-center">
        <p className="font-bold uppercase text-[11pt]">{rightTitle}</p>
        <p className="text-[9.5pt] italic text-ink-500 mb-14">{rightSubtitle}</p>

        {isSigned && (
          <div className="absolute top-10 transform -rotate-3 p-2 rounded border-2 border-dashed border-[#9f241f] bg-rose-50 text-[#9f241f] font-sans font-black text-xs inline-flex flex-col items-center shadow-xs">
            <div> ĐÃ KÝ DUYỆT ĐIỆN TỬ </div>
            <div className="text-[9px] font-mono font-normal mt-0.5">{signTimestamp || new Date().toLocaleDateString('vi-VN')}</div>
            {signHash && (
              <div className="text-[8px] font-mono text-ink-500 mt-0.5 break-all">Hash: {signHash.slice(0, 16)}...</div>
            )}
          </div>
        )}

        <p className="font-bold text-[11pt] text-ink-900">{rightSigner}</p>
      </div>
    </div>
  );
}
