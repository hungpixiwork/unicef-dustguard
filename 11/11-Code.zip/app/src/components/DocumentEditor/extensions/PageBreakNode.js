import { Node, mergeAttributes } from '@tiptap/core';

/**
 * Tiptap PageBreak Extension
 */
export const PageBreak = Node.create({
  name: 'pageBreak',
  group: 'block',
  selectable: true,
  draggable: false,

  parseHTML() {
    return [
      { tag: 'div[data-page-break]' },
      { tag: 'hr.page-break' }
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, {
        'data-page-break': 'true',
        class: 'page-break-indicator my-8 flex items-center justify-center border-t-2 border-dashed border-ink-300 py-3 text-center text-xs font-sans font-bold text-ink-400 select-none print:hidden'
      }),
      ['span', { class: 'bg-white px-3 text-ink-500 rounded border border-ink-200' }, ' NGẮT TRANG (PAGE BREAK)']
    ];
  },

  addCommands() {
    return {
      setPageBreak: () => ({ chain }) => {
        return chain()
          .insertContent({ type: this.name })
          .run();
      }
    };
  }
});
