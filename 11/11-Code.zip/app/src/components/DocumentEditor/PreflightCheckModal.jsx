import React from 'react';
import { AlertTriangle, CheckCircle2, XCircle, ArrowRight, ShieldCheck, FileDown, Printer } from 'lucide-react';

/**
 * PreflightCheckModal — Kiểm tra tính toàn vẹn dữ liệu trước khi xuất bản / phê duyệt
 */
export default function PreflightCheckModal({
  isOpen,
  onClose,
  validationResult,
  onProceedExport,
  exportType = 'pdf'
}) {
  if (!isOpen) return null;

  const { valid, totalUsed, resolvedCount, missingCount, missing, resolved } = validationResult || {
    valid: true,
    totalUsed: 0,
    resolvedCount: 0,
    missingCount: 0,
    missing: [],
    resolved: []
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 animate-in fade-in select-none">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl border border-ink-200 flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-100 pb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${valid ? 'bg-teal-100 text-teal-800' : 'bg-amber-100 text-amber-800'}`}>
              {valid ? <ShieldCheck className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-ink-900">Kiểm tra tính toàn vẹn văn bản</h3>
              <p className="text-xs text-ink-500">Rà soát các trường dữ liệu động trước khi xuất hành chính</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-ink-400 hover:text-ink-900 text-lg font-bold p-1"
          >
            
          </button>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-xl border border-ink-200 bg-cream-50/50 p-3 text-center">
            <div className="text-xs font-bold text-ink-500">Tổng số trường</div>
            <div className="text-xl font-black text-ink-900 mt-1">{totalUsed}</div>
          </div>
          <div className="rounded-xl border border-teal-200 bg-teal-50/40 p-3 text-center">
            <div className="text-xs font-bold text-teal-800">Đã đủ dữ liệu</div>
            <div className="text-xl font-black text-teal-800 mt-1">{resolvedCount}</div>
          </div>
          <div className={`rounded-xl border p-3 text-center ${missingCount > 0 ? 'border-rose-300 bg-rose-50/50' : 'border-ink-200 bg-cream-50/50'}`}>
            <div className={`text-xs font-bold ${missingCount > 0 ? 'text-rose-800' : 'text-ink-500'}`}>Còn thiếu</div>
            <div className={`text-xl font-black mt-1 ${missingCount > 0 ? 'text-rose-800' : 'text-ink-900'}`}>{missingCount}</div>
          </div>
        </div>

        {/* Missing Fields Warnings */}
        {missingCount > 0 ? (
          <div className="space-y-2">
            <div className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
              <XCircle className="h-4 w-4" />
              <span>Phát hiện {missingCount} trường chưa được liên kết giá trị thực:</span>
            </div>
            <div className="max-h-48 overflow-y-auto space-y-1.5 rounded-xl border border-rose-200 bg-rose-50/30 p-2.5">
              {missing.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs bg-white p-2 rounded-lg border border-rose-200 shadow-xs">
                  <div>
                    <span className="font-bold text-ink-900">{item.label}</span>
                    <span className="ml-2 font-mono text-[10px] text-ink-400">({item.key})</span>
                  </div>
                  <span className="text-[10px] text-rose-700 font-bold bg-rose-100 px-2 py-0.5 rounded">
                    Chưa có giá trị
                  </span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-ink-500 italic">
              * Bạn có thể quay lại editor bổ sung dữ liệu hoặc tiếp tục xuất nếu đây là bản dự thảo lưu hành nội bộ.
            </p>
          </div>
        ) : (
          <div className="rounded-xl border border-teal-200 bg-teal-50/60 p-4 flex items-center gap-3">
            <CheckCircle2 className="h-6 w-6 text-teal-700 shrink-0" />
            <div className="text-xs text-teal-900">
              <span className="font-bold">Văn bản hoàn toàn đầy đủ dữ liệu!</span> Toàn bộ các trường dữ liệu đều đã được đồng bộ chuẩn xác từ hồ sơ SSOT.
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 border-t border-ink-100 pt-3">
          <button
            onClick={onClose}
            className="rounded-lg border border-ink-200 px-4 py-2 text-xs font-bold text-ink-700 hover:bg-cream-100 transition cursor-pointer"
          >
            Quay lại chỉnh sửa
          </button>
          
          <button
            onClick={() => {
              onClose();
              if (onProceedExport) onProceedExport();
            }}
            className={`rounded-lg px-4 py-2 text-xs font-bold text-white transition flex items-center gap-1.5 cursor-pointer ${
              missingCount > 0
                ? 'bg-amber-700 hover:bg-amber-800'
                : 'bg-seal-700 hover:bg-seal-800'
            }`}
          >
            {exportType === 'docx' ? <FileDown className="h-4 w-4" /> : <Printer className="h-4 w-4" />}
            <span>{missingCount > 0 ? 'Tiếp tục xuất bản dự thảo' : 'Xác nhận & Xuất văn bản'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
