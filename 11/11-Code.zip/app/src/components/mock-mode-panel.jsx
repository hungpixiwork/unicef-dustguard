import React, { useState } from 'react';

export default function MockModePanel({ enabled, onChange, onRefresh }) {
    const [open, setOpen] = useState(false);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');

    const toggle = async () => {
        setSaving(true);
        setError('');
        try {
            await onChange(!enabled);
            await onRefresh();
        } catch (err) {
            setError(err.message);
        } finally {
            setSaving(false);
        }
    };

    return (
        <div style={{ position: 'relative', marginRight: 12 }}>
            <button className="topnav-button" onClick={() => setOpen(v => !v)} style={{ borderColor: enabled ? 'var(--accent)' : 'var(--line)', color: enabled ? 'var(--accent)' : 'var(--ink-3)' }}>
                Mock data: {enabled ? 'ON' : 'OFF'}
            </button>
            {open && (
                <div style={{ position: 'absolute', right: 0, top: 38, zIndex: 2000, width: 280, background: '#FDFBF7', border: '1px solid rgba(0,0,0,.08)', borderRadius: 14, boxShadow: '0 12px 40px rgba(0,0,0,.18)', padding: 14 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                        <div style={{ fontSize: 12, fontWeight: 700 }}>Mock data mode</div>
                        <button onClick={() => setOpen(false)} style={{ border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--ink-3)' }}></button>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', lineHeight: 1.5, marginBottom: 12 }}>
                        Tắt để ẩn dữ liệu demo khỏi dashboard/API vận hành. Bật để test công trình, phản ánh, thanh tra và bản đồ.
                    </div>
                    <button disabled={saving} onClick={toggle} style={{ width: '100%', height: 28, border: 0, borderRadius: 8, background: enabled ? '#34c759' : 'rgba(0,0,0,.78)', color: '#fff', fontWeight: 700, cursor: saving ? 'not-allowed' : 'pointer' }}>
                        {saving ? 'Đang lưu...' : enabled ? 'Tắt mock data' : 'Bật mock data'}
                    </button>
                    {error && (
                        <div style={{ marginTop: 8, fontSize: 11, color: 'var(--red)' }}>
                            {error === 'Mock mode cannot be changed in production.'
                                ? 'Bản production đang khóa chuyển trạng thái mock data cho demo ổn định.'
                                : error}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
