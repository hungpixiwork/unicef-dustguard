import React from 'react';

export default function InspectionReviewTable({
    items,
    checklistTemplate,
    onEditItem,
    saving,
    saveError,
    onSave
}) {
    return (
        <div>
            <div className="text-base font-bold text-ink-900 mb-4">Xác nhận kết quả thanh tra</div>
            {/* DESKTOP TABLE VIEW (Visible on md & above) */}
            <div className="hidden md:block overflow-x-auto w-full border border-cream-200 rounded-xl mb-6 bg-white shadow-soft">
                <table className="w-full text-xs border-collapse min-w-[640px] table-fixed">
                    <thead>
                        <tr className="bg-cream-100/70 border-b border-cream-200 text-ink-700">
                            <th className="py-3.5 px-4 text-left font-bold w-[40%]">Hạng mục</th>
                            <th className="py-3.5 px-4 text-center font-bold w-[20%]">Kết quả</th>
                            <th className="py-3.5 px-4 text-center font-bold w-[18%]">Mức độ</th>
                            <th className="py-3.5 px-4 text-left font-bold w-[22%]">Ghi chú</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map((item, idx) => {
                            const ci = checklistTemplate.find(c => c.id === item.id);
                            return (
                                <tr key={item.id} className="border-b border-cream-100 hover:bg-cream-50/40 transition">
                                    <td className="py-3.5 px-4">
                                        <div className="font-bold text-ink-900 leading-snug break-words">{ci?.title}</div>
                                        <div className="mt-1.5">
                                            <button 
                                                type="button"
                                                onClick={() => onEditItem(idx)} 
                                                className="inline-flex items-center min-h-[36px] py-1 px-2.5 rounded-md text-xs font-bold text-accent-700 bg-accent-50 hover:bg-accent-100 border border-accent-200 transition cursor-pointer"
                                                aria-label={`Sửa hạng mục ${ci?.title || idx + 1}`}
                                            >
                                                ️ Sửa hạng mục
                                            </button>
                                        </div>
                                    </td>
                                    <td className="py-3.5 px-4 text-center">
                                        {item.status === 'pass' ? (
                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-success-50 text-success-700 border border-success-200">
                                                <span>️</span> Đạt
                                            </span>
                                        ) : item.status === 'fail' ? (
                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-seal-50 text-seal-700 border border-seal-200">
                                                <span></span> Lỗi
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-ink-500 border border-gray-200">
                                                <span></span> N/A
                                            </span>
                                        )}
                                    </td>
                                    <td className="py-3.5 px-4 text-center">
                                        {item.severity === 'high' ? (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-seal-100 text-seal-800">
                                                 Nghiêm trọng
                                            </span>
                                        ) : item.severity === 'medium' ? (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-warning-100 text-warning-800">
                                                 Trung bình
                                            </span>
                                        ) : item.severity === 'low' ? (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-success-100 text-success-800">
                                                 Nhẹ
                                            </span>
                                        ) : (
                                            <span className="text-ink-400">—</span>
                                        )}
                                    </td>
                                    <td className="py-3.5 px-4 text-ink-700 break-words">{item.notes || '—'}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>

            {/* MOBILE CARDS VIEW (Visible on <md) */}
            <div className="md:hidden flex flex-col gap-3 mb-6">
                {items.map((item, idx) => {
                    const ci = checklistTemplate.find(c => c.id === item.id);
                    return (
                        <div
                            key={item.id}
                            className="p-4 rounded-xl border border-cream-200 bg-white shadow-soft flex flex-col gap-2.5 min-w-0"
                        >
                            <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-bold text-ink-500">
                                    Hạng mục #{idx + 1}
                                </span>
                                <div className="flex items-center gap-1.5">
                                    {item.status === 'pass' ? (
                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-success-50 text-success-700 border border-success-200">
                                            <span>️</span> Đạt
                                        </span>
                                    ) : item.status === 'fail' ? (
                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-seal-50 text-seal-700 border border-seal-200">
                                            <span></span> Lỗi
                                        </span>
                                    ) : (
                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-ink-500 border border-gray-200">
                                            <span></span> N/A
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div className="font-bold text-ink-900 text-sm leading-snug break-words">
                                {ci?.title}
                            </div>

                            {item.notes && (
                                <div className="text-xs text-ink-600 bg-cream-50 p-2.5 rounded-lg border border-cream-200 break-words">
                                     {item.notes}
                                </div>
                            )}

                            <div className="flex items-center justify-between gap-2 pt-2 border-t border-cream-100 text-xs">
                                <div>
                                    {item.severity === 'high' ? (
                                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-seal-100 text-seal-800">
                                             Nghiêm trọng
                                        </span>
                                    ) : item.severity === 'medium' ? (
                                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-warning-100 text-warning-800">
                                             Trung bình
                                        </span>
                                    ) : item.severity === 'low' ? (
                                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-success-100 text-success-800">
                                             Nhẹ
                                        </span>
                                    ) : null}
                                </div>

                                <button 
                                    type="button"
                                    onClick={() => onEditItem(idx)} 
                                    className="min-h-[44px] px-3 py-2 rounded-xl text-xs font-bold text-accent-700 bg-accent-50 hover:bg-accent-100 border border-accent-200 transition cursor-pointer inline-flex items-center gap-1 shrink-0"
                                    aria-label={`Sửa hạng mục ${ci?.title || idx + 1}`}
                                >
                                    ️ Sửa hạng mục
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>

            {saveError && (
                <div className="p-3 bg-seal-50 border border-seal-200 text-seal-800 rounded-lg text-xs font-semibold mb-4">
                    ️ Không lưu được thanh tra: {saveError.message}
                </div>
            )}
            
            <div className="flex gap-3">
                <button 
                    className="w-full min-h-[48px] px-6 py-3 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-sm rounded-xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    onClick={onSave} 
                    disabled={saving}
                >
                    {saving ? 'Đang lưu kết quả...' : ' Xác nhận lưu kết quả thanh tra'}
                </button>
            </div>
        </div>
    );
}
