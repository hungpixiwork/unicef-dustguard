import React from 'react';
import { Chip } from '../shared';

export default function ChecklistItemDetail({
    currentItem,
    currentChecklist,
    currentIndex,
    totalCount,
    setStatus,
    setSeverity,
    setNotes,
    onPrev,
    onNext,
    onComplete,
    onShowList
}) {
    if (!currentItem || !currentChecklist) return null;
    const currentLegal = currentChecklist.legalBasis || null;

    return (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            {/* Mobile Back Button */}
            <div className="mobile-only" style={{ marginBottom: 16 }}>
                <button 
                    onClick={onShowList}
                    className="min-h-[44px] px-4 py-2 bg-cream-100 hover:bg-cream-200 text-ink-900 border border-cream-200 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition"
                    aria-label="Trở lại danh sách hạng mục"
                >
                    ← Trở lại danh sách hạng mục
                </button>
            </div>

            <div style={{ padding: 16, border: '1px solid var(--line)', borderRadius: 8, borderLeft: currentItem.status === 'fail' ? '4px solid #9f241f' : currentItem.status === 'pass' ? '4px solid #0d6f64' : '4px solid var(--line)', flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
                    <div>
                        <div style={{ fontSize: 11, color: 'var(--ink-500)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: 700 }}>Hạng mục {currentIndex + 1}</div>
                        <div style={{ fontWeight: 700, fontSize: 18, lineHeight: 1.3, color: 'var(--ink-900)' }}>{currentChecklist.title}</div>
                        <div style={{ fontSize: 13, color: 'var(--ink-700)', marginTop: 6, lineHeight: 1.5 }}>{currentChecklist.description}</div>
                        {currentLegal && <div className="mono" style={{ fontSize: 11, color: 'var(--ink-700)', marginTop: 8, background: 'var(--cream-100)', padding: '4px 8px', borderRadius: 4, display: 'inline-block' }}>{currentLegal}</div>}
                    </div>
                    <Chip>Rủi ro: {currentChecklist.riskLevel}</Chip>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
                    {[
                        ['pass', '️ Đạt', '#eefaf8', '#0d6f64', 'border-[#0d6f64]'],
                        ['fail', ' Không đạt', '#fdecea', '#9f241f', 'border-[#9f241f]'],
                        ['na', ' N/A', '#f2f4f7', '#3f352b', 'border-gray-300']
                    ].map(([v, label, bg, color, borderCls]) => (
                        <button key={v} onClick={() => setStatus(currentItem.id, v)} className={`min-h-[48px] p-3 rounded-lg text-sm font-bold transition flex items-center justify-center cursor-pointer border ${currentItem.status === v ? `${borderCls} ring-2 ring-offset-1` : 'border-cream-200'}`} style={{
                            background: currentItem.status === v ? bg : '#ffffff',
                            color: currentItem.status === v ? color : '#3f352b',
                        }}>{label}</button>
                    ))}
                </div>

                {currentItem.status === 'fail' && (
                    <div style={{ background: '#fdecea', padding: 16, borderRadius: 8, border: '1px solid rgba(159,36,31,0.25)', marginTop: 16 }}>
                        <div style={{ fontSize: 14, fontWeight: 700, color: '#9f241f', marginBottom: 14 }}>Ghi nhận bằng chứng vi phạm</div>
                        <div className="checklist-fail-fields-grid">
                            <div>
                                <div style={{ fontSize: 12, fontWeight: 700, color: '#3f352b', marginBottom: 8 }}>Mức độ vi phạm</div>
                                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
                                    {[
                                        ['high', 'Nghiêm trọng (Phạt nặng)'],
                                        ['medium', 'Trung bình'],
                                        ['low', 'Nhẹ (Nhắc nhở)']
                                    ].map(([v, label]) => (
                                        <button key={v} onClick={() => setSeverity(currentItem.id, v)} className="min-h-[44px] px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer transition flex-1" style={{
                                            border: currentItem.severity === v ? '2px solid #9f241f' : '1px solid rgba(159,36,31,0.3)',
                                            background: currentItem.severity === v ? '#ffffff' : 'rgba(255,255,255,0.6)',
                                            color: currentItem.severity === v ? '#9f241f' : '#3f352b',
                                        }}>{label}</button>
                                    ))}
                                </div>
                                <div style={{ border: '1px dashed #9f241f', borderRadius: 6, padding: 16, background: 'rgba(255,255,255,.8)' }}>
                                    <div style={{ fontSize: 13, fontWeight: 700, color: '#9f241f' }}> Tải lên ảnh/minh chứng hiện trường</div>
                                    <div className="mono" style={{ fontSize: 11, color: '#6b6056', marginTop: 4 }}>Tự động ghi nhận định vị GPS & thời gian</div>
                                </div>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', marginTop: 12 }}>
                                <div style={{ fontSize: 12, fontWeight: 700, color: '#3f352b', marginBottom: 8 }}>Ghi chú chi tiết & Yêu cầu khắc phục</div>
                                <textarea
                                    className="form-control"
                                    placeholder="Ghi chú vi phạm, vị trí cụ thể, yêu cầu khắc phục (Ví dụ: Không có bạt che tại hố móng góc Tây Bắc)..."
                                    value={currentItem.notes}
                                    onChange={e => setNotes(currentItem.id, e.target.value)}
                                    style={{ width: '100%', fontSize: 13, padding: 12, flex: 1, minHeight: 100, resize: 'vertical' }}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            <div style={{ marginTop: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
                <button className="min-h-[44px] px-5 py-2.5 bg-cream-100 hover:bg-cream-200 text-ink-900 border border-cream-200 font-bold text-sm rounded-lg transition cursor-pointer disabled:opacity-40" onClick={onPrev} disabled={currentIndex === 0}>← Mục trước</button>
                {currentIndex < totalCount - 1 ? (
                    <button className="min-h-[44px] px-6 py-2.5 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-sm rounded-lg shadow-sm transition cursor-pointer" onClick={onNext}>Mục tiếp theo →</button>
                ) : (
                    <button className="min-h-[44px] px-6 py-2.5 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-sm rounded-lg shadow-sm transition cursor-pointer" onClick={onComplete}>Hoàn tất & Xem lại</button>
                )}
            </div>
        </div>
    );
}
