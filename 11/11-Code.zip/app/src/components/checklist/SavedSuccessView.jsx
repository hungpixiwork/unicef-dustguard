import React from 'react';

export default function SavedSuccessView({ site, previewRisk, onFinish, isSplit = false }) {
    if (isSplit) {
        return (
            <div className="workspace-split" style={{ gridTemplateColumns: '1fr' }}>
                <div className="workspace-detail" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
                    <div style={{ fontSize: 48, marginBottom: 16 }}></div>
                    <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 8 }}>Thanh tra đã lưu</h2>
                    <div style={{ fontSize: 14, color: 'var(--ink-3)', marginBottom: 24 }}>
                        {site.name} — Điểm rủi ro mới: <strong>{previewRisk.score}</strong> ({previewRisk.level})
                    </div>
                    <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
                        <button className="btn-primary" onClick={onFinish}>← Quay lại hồ sơ</button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: 600, margin: '0 auto', padding: '40px 24px', textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}></div>
            <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 8 }}>Thanh tra đã lưu</h2>
            <div style={{ fontSize: 14, color: 'var(--ink-3)', marginBottom: 24 }}>
                {site.name} — Điểm rủi ro mới: <strong>{previewRisk.score}</strong> ({previewRisk.level})
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
                <button className="btn-primary" onClick={onFinish}>← Quay lại hồ sơ</button>
            </div>
        </div>
    );
}
