import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  ROLES, 
  normalizeRole, 
  isRoleAllowedForPath, 
  getDefaultRouteForRole, 
  ROLE_PATH_MAP 
} from '../../lib/rbac-rules.js';

export { ROLES, normalizeRole, isRoleAllowedForPath, getDefaultRouteForRole, ROLE_PATH_MAP };

/**
 * ProtectedRoute Component
 * Guards routes against unauthenticated and unauthorized access according to RBAC SSOT.
 * @param {Object} props
 * @param {string[]} [props.allowedRoles] - Optional list of allowed roles. If omitted, checks current path against ROLE_PATH_MAP.
 */
export const ProtectedRoute = ({ allowedRoles, children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div 
        className="flex h-screen w-full items-center justify-center bg-[#FDFBF7]" 
        aria-live="polite" 
        role="status"
      >
        <div className="flex flex-col items-center gap-3">
          <div 
            className="h-10 w-10 animate-spin rounded-full border-4 border-seal-200 border-t-seal-600" 
            aria-hidden="true"
          />
          <span className="text-xs font-bold text-ink-700">Đang xác thực quyền truy cập...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    // If not authenticated, redirect to login page with return state
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Normalize user's role to standard SSOT role
  const userRole = normalizeRole(user.role || 'citizen');

  // Check role authorization
  let isAllowed = false;
  if (Array.isArray(allowedRoles) && allowedRoles.length > 0) {
    // Map allowed roles to their normalized equivalents
    const normalizedAllowed = allowedRoles.map(r => normalizeRole(r));
    isAllowed = normalizedAllowed.includes(userRole) || allowedRoles.includes(user.role);
  } else {
    isAllowed = isRoleAllowedForPath(userRole, location.pathname);
  }

  if (!isAllowed) {
    // If authenticated but role is not authorized, redirect to unauthorized error page
    return <Navigate to="/unauthorized" state={{ attemptedPath: location.pathname }} replace />;
  }

  return children ? children : <Outlet />;
};

export default ProtectedRoute;
