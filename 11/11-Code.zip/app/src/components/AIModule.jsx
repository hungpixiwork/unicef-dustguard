// AI Module — Policy Intelligence + Violation Explanation + Auto Report + Tender Placeholder
import React, { useEffect, useState } from 'react';
import { staffApi } from '../lib/api/staff-api';
import { Chip } from './shared';

import DocInsight from './StaffAI/DocInsight';
import LegalSearch from './StaffAI/LegalSearch';
import ViolationCaseBuilder from './StaffAI/ViolationCaseBuilder';
import AutoReport from './StaffAI/AutoReport';

export default function AIModule({ onBack, initialSiteId, initialTab, initialDocumentType, onTabChange }) {
    const [activeModule, setActiveModule] = useState(initialTab || (initialSiteId ? 'report' : 'doc'));
    const [capabilities, setCapabilities] = useState(null);
    const [selectedSiteId, setSelectedSiteId] = useState(initialSiteId || '');

    useEffect(() => {
        if (initialTab) {
            setActiveModule(initialTab);
        }
    }, [initialTab]);

    useEffect(() => {
        if (initialSiteId) {
            setSelectedSiteId(initialSiteId);
        }
    }, [initialSiteId]);

    const handleSelectModule = (newTabId) => {
        setActiveModule(newTabId);
        if (typeof onTabChange === 'function') {
            onTabChange(newTabId);
        }
    };

    const modules = [
        { id: 'doc', num: '1', title: 'Phân tích luật', desc: 'Đọc PDF/DOCX, trích xuất nghĩa vụ, checklist', kpi: 'Kho nghĩa vụ' },
        { id: 'search', num: '2', title: 'Tra cứu luật', desc: 'Hỏi đáp theo tình huống, tìm điều khoản', kpi: 'Căn cứ' },
        { id: 'case', num: '3', title: 'Lập hồ sơ', desc: 'Ghép checklist, ảnh, phản ánh, lịch sử', kpi: 'Case file' },
        { id: 'report', num: '4', title: 'Soạn biên bản', desc: 'Sinh bản nháp biên bản, yêu cầu khắc phục', kpi: 'Bản nháp' },
    ];

    useEffect(() => {
        let cancelled = false;
        staffApi.getAiCapabilities()
            .then(data => {
                if (!cancelled) setCapabilities(data);
            })
            .catch(() => {
                if (!cancelled) setCapabilities(null);
            });
        return () => { cancelled = true; };
    }, []);

    useEffect(() => {
        if (!modules.some(module => module.id === activeModule)) setActiveModule('doc');
    }, [activeModule, modules]);

    return (
        <div className="flex flex-col h-full bg-white rounded-b-xl">
            {/* Workflow Pipeline Header */}
            <div className="px-4 py-3 bg-cream-100/60 border-b border-cream-200 flex flex-wrap justify-between items-center gap-2 text-xs">
                <div className="flex items-center gap-2 text-ink-700 font-medium">
                    <span className="font-bold text-accent-700 bg-accent-100 px-2 py-0.5 rounded text-[11px]">LUỒNG QUẢN LÝ BẰNG CHỨNG</span>
                    <span className="hidden md:inline text-ink-400">|</span>
                    <span className="hidden md:inline text-ink-600">Tín hiệu  Đánh giá  Hồ sơ  Bằng chứng  Căn cứ  Bản nháp duyệt</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="bg-amber-100 text-amber-800 text-[11px] font-semibold px-2.5 py-0.5 rounded border border-amber-300 flex items-center gap-1" title="Hệ thống hỗ trợ tra cứu và đối chiếu, quyết định cuối cùng do cán bộ có thẩm quyền phê duyệt">
                        <svg className="w-3.5 h-3.5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                        Hệ thống hỗ trợ đối chiếu • Cán bộ thẩm quyền phê duyệt
                    </span>
                </div>
            </div>

            {/* Tabs Menu - Grid Layout to show all 4 tabs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 border-b border-cream-200 bg-cream-50/30">
                {modules.map(m => (
                    <button 
                        key={m.id} 
                        onClick={() => handleSelectModule(m.id)} 
                        className={`p-4 transition-all border-b-2 flex flex-col gap-1 items-start text-left hover:bg-cream-50 ${
                            activeModule === m.id 
                            ? 'border-accent-500 bg-white' 
                            : 'border-transparent opacity-70 hover:opacity-100'
                        }`}
                    >
                        <div className="flex justify-between items-center w-full mb-1">
                            <span className={`font-mono text-xs font-bold ${activeModule === m.id ? 'text-accent-600' : 'text-ink-500'}`}>Module {m.num}</span>
                            <Chip className="hidden sm:inline-flex">{m.kpi}</Chip>
                        </div>
                        <div className={`font-bold text-sm leading-tight ${activeModule === m.id ? 'text-ink-900' : 'text-ink-700'}`}>{m.title}</div>
                        <div className="text-xs text-ink-500 hidden sm:block mt-1">{m.desc}</div>
                    </button>
                ))}
            </div>

            {/* Main Content Area */}
            <div className="p-4 sm:p-6 flex-1 overflow-y-auto bg-white min-h-[500px]">
                {/* Active Module Rendering */}
                {activeModule === 'doc' && <DocInsight onSwitchTab={(tabId) => handleSelectModule(tabId)} />}
                {activeModule === 'search' && <LegalSearch capabilities={capabilities} onSwitchTab={(tabId) => handleSelectModule(tabId)} />}
                {activeModule === 'case' && (
                    <ViolationCaseBuilder 
                        selectedSiteId={selectedSiteId} 
                        onSelectSite={setSelectedSiteId} 
                        onNext={() => handleSelectModule('report')} 
                        onSwitchTab={(tabId) => handleSelectModule(tabId)}
                    />
                )}
                {activeModule === 'report' && (
                    <AutoReport 
                        selectedSiteId={selectedSiteId} 
                        onSelectSite={setSelectedSiteId} 
                        initialDocumentType={initialDocumentType}
                        onSwitchTab={(tabId) => handleSelectModule(tabId)}
                    />
                )}
            </div>
        </div>
    );
}

