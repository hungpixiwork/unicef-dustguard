import React, { useEffect, useMemo, useState } from 'react';
import { useDashboardData } from '../lib/useApiData';
import { staffApi } from '../lib/api/staff-api';

const REPORT_TYPES = {
  inspection: 'Biên bản kiểm tra hiện trường',
  remediation: 'Thông báo yêu cầu khắc phục',
  penalty: 'Biên bản vi phạm hành chính',
  transfer: 'Văn bản chuyển cơ quan chức năng',
};

export default function AIReportHub() {
  const { data: dashboardData, loading, error } = useDashboardData();
  const sites = dashboardData?.sites || [];

  const [selectedSiteId, setSelectedSiteId] = useState('');
  const [reportType, setReportType] = useState('inspection');
  const [generating, setGenerating] = useState(false);
  const [draft, setDraft] = useState('');
  const [metadata, setMetadata] = useState(null);
  const [generateError, setGenerateError] = useState(null);

  const filteredSites = useMemo(
    () => sites.filter(site => site.tier === 'red' || site.tier === 'amber' || (site.score || 0) >= 45),
    [sites],
  );

  useEffect(() => {
    if (!selectedSiteId && filteredSites[0]) setSelectedSiteId(filteredSites[0].id);
  }, [filteredSites, selectedSiteId]);

  const selectedSite = sites.find(site => site.id === selectedSiteId);
  const riskReasons = selectedSite?.risk?.reasons || [];

  const generateReport = async () => {
    if (!selectedSite) return;
    setGenerating(true);
    setGenerateError(null);
    setDraft('');
    setMetadata(null);

    try {
      const result = await staffApi.generateInspectionReport(selectedSite.id, undefined, reportType, {
        legalContextMode: 'auto',
        useAI: reportType === 'inspection',
      });
      setDraft(result.content || '');
      setMetadata(result.metadata || {
        provider: result.provider,
        model: result.model,
        score: selectedSite.score,
        tier: selectedSite.tier,
      });
    } catch (err) {
      setGenerateError(err);
    } finally {
      setGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) return <div className="page">Đang tải dữ liệu công trình...</div>;
  if (error) return <div className="page">Không tải được dữ liệu: {error.message}</div>;

  return (
    <div className="page" style={{ maxWidth: 1100, margin: '0 auto' }}>
      <div className="page-header">
        <h2>Trung tâm Báo cáo & Biên bản</h2>
        <p>Chọn công trình rủi ro và tạo bản nháp từ checklist, phản ánh, điểm rủi ro và căn cứ pháp lý hiện tại.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 320px), 1fr))', gap: 20, alignItems: 'start' }}>
        <div className="card" style={{ padding: 16 }}>
          <label htmlFor="site-select">1. Chọn công trình</label>
          <select
            id="site-select"
            className="form-control"
            value={selectedSiteId}
            onChange={(e) => {
              setSelectedSiteId(e.target.value);
              setDraft('');
              setMetadata(null);
              setGenerateError(null);
            }}
          >
            <option value="">-- Chọn công trình --</option>
            {filteredSites.map(site => (
              <option key={site.id} value={site.id}>
                [{String(site.tier || 'green').toUpperCase()}] {site.name}
              </option>
            ))}
          </select>

          {selectedSite && (
            <div style={{ marginTop: 12, padding: 12, background: 'var(--panel)', border: '1px solid var(--line)', borderRadius: 6, fontSize: 12 }}>
              <div><b>{selectedSite.name}</b></div>
              <div style={{ color: 'var(--ink-3)', marginTop: 4 }}>{selectedSite.addr || 'Chưa có địa chỉ'}</div>
              <div style={{ marginTop: 8 }}>Điểm: <b>{selectedSite.score}</b> · Mức: <b>{selectedSite.tier}</b> · Phản ánh: <b>{selectedSite.complaints || 0}</b></div>
              {riskReasons.length > 0 && (
                <div style={{ marginTop: 8, color: 'var(--ink-3)' }}>{riskReasons.slice(0, 3).join('; ')}</div>
              )}
            </div>
          )}

          <label htmlFor="report-type-select" style={{ marginTop: '1rem' }}>Loại văn bản</label>
          <select
            id="report-type-select"
            className="form-control"
            value={reportType}
            onChange={(e) => {
              setReportType(e.target.value);
              setDraft('');
              setMetadata(null);
              setGenerateError(null);
            }}
          >
            {Object.entries(REPORT_TYPES).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>

          <button
            className="btn btn-primary"
            style={{ width: '100%', marginTop: '1rem' }}
            onClick={generateReport}
            disabled={!selectedSiteId || generating}
          >
            {generating ? 'Đang tổng hợp...' : '2. Tạo bản nháp'}
          </button>

          {generateError && (
            <div style={{ marginTop: 12, padding: 10, color: 'var(--red)', border: '1px solid var(--red)', borderRadius: 6, fontSize: 12 }}>
              Không tạo được báo cáo: {generateError.message}
            </div>
          )}
        </div>

        <div className="card" style={{ padding: 16, minHeight: 640 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginBottom: '1rem' }}>
            <div>
              <label>3. Rà soát & chỉnh sửa</label>
              <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 4 }}>
                {metadata ? providerLabel(metadata) : 'Nguồn: API biên bản hiện hành'}
              </div>
            </div>
            {draft && (
              <button className="btn btn-secondary" onClick={handlePrint}>
                Xuất PDF
              </button>
            )}
          </div>

          {draft ? (
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              style={{
                width: '100%',
                height: 540,
                padding: 20,
                fontFamily: '"Times New Roman", Times, serif',
                fontSize: 16,
                lineHeight: 1.5,
                border: '1px solid var(--line-2)',
                background: '#fff',
              }}
            />
          ) : (
            <div className="empty-decision-state" style={{ height: 540, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
              <div>
                <p>Chọn công trình và tạo bản nháp để bắt đầu.</p>
                <p>Dữ liệu lấy từ hồ sơ hiện tại, không dùng các trường báo cáo cũ.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function providerLabel(metadata = {}) {
  if (metadata.provider === 'internal-template') return 'Nguồn: mẫu nội bộ · không dùng AI';
  const model = metadata.model ? ` · model ${metadata.model}` : '';
  return `Nguồn: ${metadata.provider || 'AI gateway'}${model}`;
}
