import React, { useState } from 'react';
import Section from '../ui/Section';
import Container from '../ui/Container';
import { publicApi } from "../../lib/api/public-api";

const STATUS_STEPS = ["new", "linked", "investigating", "resolved"];
const STATUS_LABEL = {
  new: "Đã tiếp nhận",
  linked: "Đã đối chiếu công trình",
  investigating: "Đang kiểm tra đối chiếu",
  resolved: "Đã hoàn thành khắc phục",
  rejected: "Không đủ điều kiện tiếp nhận",
};
const STATUS_DESC = {
  new: "Ghi nhận của bạn đã được lưu trữ và chờ điều phối xác minh.",
  linked: "Điều phối viên đã xác minh và đối chiếu với dữ liệu công trình.",
  investigating: "Tổ công tác đang tiến hành kiểm tra & đo kiểm thực địa.",
  resolved: "Hiện trường đã hoàn thành khắc phục dập bụi và nghiệm thu đạt chuẩn.",
  rejected: "Ghi nhận chưa đủ thông tin hoặc nằm ngoài phạm vi hỗ trợ.",
};

function Timeline({ c }) {
  if (!c) return null;
  const rej = c.status === "rejected";
  const steps = rej ? ["new", "rejected"] : STATUS_STEPS;
  const cur = steps.indexOf(c.status);
  return (
    <div className="cz-timeline">
      <div className="cz-tl-top">
        <div><div className="cz-tl-id mono">{c.id}</div><div className="cz-tl-loc">{c.loc}</div></div>
        <div className={`cz-chip status-${c.status}`}>{STATUS_LABEL[c.status] || c.status}</div>
      </div>
      <div className="cz-tl-desc">{STATUS_DESC[c.status]}</div>
      <div className="cz-tl-steps">
        {steps.map((s, i) => (
          <div key={s} className={`cz-tl-step${i <= cur ? " done" : ""}${i === cur ? " active" : ""}` }>
            <div className="cz-tl-dot">{i <= cur && <span>&#10003;</span>}</div>
            {i < steps.length - 1 && <div className="cz-tl-line"/>}
            <div className="cz-tl-lbl">{STATUS_LABEL[s]}</div>
          </div>
        ))}
      </div>
      {c.date && <div className="cz-tl-meta mono">Gửi lúc {c.date}</div>}
    </div>
  );
}

export default function CitizenTrackingSection() {
    const [lid, setLid] = useState("");
    const [lres, setLres] = useState(null);
    const [lerr, setLerr] = useState("");
    const [looking, setLooking] = useState(false);

    const lkup = async e => {
        e.preventDefault(); 
        const code = lid.trim(); 
        if (!code) { setLerr("Nhập mã phản ánh."); return; }
        setLooking(true); setLerr(""); setLres(null);
        try {
            setLres(await publicApi.getPublicComplaintStatus(code));
        } catch (err) {
            setLerr(err.message === "Complaint not found" ? "Không tìm thấy mã này." : "Lỗi tra cứu.");
        } finally {
            setLooking(false);
        }
    };

    return (
        <Section variant="muted" style={{ padding: '60px 0' }}>
            <Container>
                <div style={{ maxWidth: '800px', margin: '0 auto' }}>
                    <section className="cz-card cz-lookup-card">
                        <div className="cz-card-eyebrow mono" style={{ textAlign: 'center' }}>TRA CỨU TRẠNG THÁI</div>
                        <h2 className="cz-card-h2" style={{ textAlign: 'center' }}>Theo dõi phản ánh</h2>
                        <p className="cz-card-sub" style={{ textAlign: 'center', marginBottom: '32px' }}>Nhập mã phản ánh để xem tiến trình xử lý chi tiết.</p>
                        
                        <form onSubmit={lkup} className="cz-lkup-form flex flex-col sm:flex-row gap-2.5" style={{ maxWidth: '450px', margin: '0 auto 24px auto' }}>
                            <input 
                                type="text"
                                value={lid} 
                                onChange={e => { setLid(e.target.value.toUpperCase()); setLerr(""); }} 
                                placeholder="VD: PA-04115" 
                                autoCapitalize="characters"
                                autoComplete="off"
                                autoCorrect="off"
                                spellCheck="false"
                                className="cz-lkup-input mono flex-1 min-h-[44px] px-3.5 py-2.5 rounded-lg border border-cream-200 bg-white text-ink-900 focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                                aria-label="Mã phản ánh cần tra cứu"
                            />
                            <button 
                                className="cz-lkup-btn min-h-[44px] px-6 py-2.5 rounded-lg bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-xs transition cursor-pointer disabled:opacity-50 flex items-center justify-center shrink-0" 
                                disabled={looking}
                                aria-label="Bấm để tra cứu tiến độ phản ánh"
                            >
                                {looking ? "Đang tra..." : "Tra cứu"}
                            </button>
                        </form>
                        
                        {lerr && <div className="cz-err" style={{ textAlign: 'center', marginBottom: '24px' }}>{lerr}</div>}
                        
                        {lres && (
                            <div style={{ marginTop: '32px', borderTop: '1px solid var(--line)', paddingTop: '32px' }}>
                                <Timeline c={lres} />
                            </div>
                        )}
                    </section>
                </div>
            </Container>
        </Section>
    );
}
