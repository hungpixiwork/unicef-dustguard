import React, { useRef, useState } from 'react';
import { compressImage } from '../../lib/image-compressor.js';
import { computeImageHash } from '../../lib/image-integrity.js';

export default function UploadZone({ files, onFiles }) {
    const ref = useRef();
    const [drag, setDrag] = useState(false);
    const [processing, setProcessing] = useState(false);
    
    const handleAddFiles = async (rawFiles) => {
        const imageFiles = Array.from(rawFiles || []).filter(f => f.type && f.type.startsWith("image/"));
        if (imageFiles.length === 0) return;

        setProcessing(true);
        const processedItems = [];

        for (const file of imageFiles) {
            try {
                // Compress strictly under 300KB, strip EXIF metadata for privacy, and compute SHA-256 hash
                const compressed = await compressImage(file, { targetSizeKB: 300, maxWidth: 1280, initialQuality: 0.82 });
                const hash = compressed.sha256 || (await computeImageHash(compressed.dataUrl));
                
                processedItems.push({
                    file,
                    name: file.name,
                    url: compressed.dataUrl,
                    dataUrl: compressed.dataUrl,
                    sizeKB: compressed.sizeKB,
                    sha256: hash,
                    exifStripped: true
                });
            } catch (err) {
                console.warn('Lỗi nén ảnh trong UploadZone, dùng fallback:', err);
                const url = URL.createObjectURL(file);
                processedItems.push({
                    file,
                    name: file.name,
                    url,
                    dataUrl: url,
                    sizeKB: Number((file.size / 1024).toFixed(1)),
                    sha256: 'sha256_unprocessed',
                    exifStripped: false
                });
            }
        }

        onFiles(prev => [...prev, ...processedItems].slice(0, 4));
        setProcessing(false);
        if (ref.current) ref.current.value = '';
    };
    
    return (
        <div className="cz-upload">
            <div 
                className={`cz-drop${drag ? " drag" : ""} focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0d6f64]`}
                tabIndex={0}
                role="button"
                aria-label="Khu vực tải lên ảnh minh chứng, nhấn để chọn tệp"
                onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        ref.current?.click();
                    }
                }}
                onClick={() => ref.current?.click()}
                onDragOver={e => { e.preventDefault(); setDrag(true); }}
                onDragLeave={() => setDrag(false)}
                onDrop={e => { e.preventDefault(); setDrag(false); handleAddFiles(e.dataTransfer.files); }}>
                <input ref={ref} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={e => handleAddFiles(e.target.files)} />
                <svg className="cz-drop-ico" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>
                </svg>
                <div className="cz-drop-txt">
                    <strong>Kéo &amp; thả hoặc nhấn chọn ảnh</strong>
                    <span>Tự động nén &lt; 300KB • Khử EXIF bảo mật • Tạo mã xác thực số (Tối đa 4 ảnh)</span>
                </div>
                {files.length === 0 && <div className="cz-priority-badge">&#9733; Có ảnh → ưu tiên đối chứng</div>}
            </div>

            {processing && (
                <div className="p-2.5 mt-2 bg-accent-50 rounded-lg border border-accent-200 text-xs font-bold text-[#0d6f64] flex items-center gap-2">
                    <div className="w-3.5 h-3.5 border-2 border-[#0d6f64] border-t-transparent rounded-full animate-spin shrink-0"></div>
                    <span>Đang nén ảnh &lt; 300KB và tạo mã xác thực số...</span>
                </div>
            )}

            {files.length > 0 && (
                <div className="cz-thumbs flex flex-wrap gap-3 mt-3">
                    {files.map((f, i) => {
                        const previewSrc = f.url || (f instanceof Blob || f instanceof File ? URL.createObjectURL(f) : f);
                        const sizeDisplay = f.sizeKB ? `${f.sizeKB}KB` : (f.size ? `${(f.size / 1024).toFixed(0)}KB` : '<300KB');
                        const hashDisplay = f.sha256 ? `${f.sha256.slice(0, 8)}...` : '';

                        return (
                            <div key={i} className="cz-thumb relative group rounded-xl overflow-hidden border border-cream-200 bg-white">
                                <img
                                    src={previewSrc}
                                    alt={`Ảnh minh chứng ${i + 1}`}
                                    className="w-24 h-24 object-cover"
                                    onLoad={() => {
                                        if (typeof previewSrc === 'string' && previewSrc.startsWith('blob:')) {
                                            URL.revokeObjectURL(previewSrc);
                                        }
                                    }}
                                />
                                <div className="absolute bottom-0 inset-x-0 bg-black/75 text-white text-[9px] px-1 py-0.5 flex items-center justify-between font-mono">
                                    <span>{sizeDisplay}</span>
                                    {hashDisplay && <span className="text-teal-300">SHA</span>}
                                </div>
                                <button 
                                    type="button" 
                                    className="cz-thumb-rm absolute top-1 right-1 w-11 h-11 min-h-[44px] min-w-[44px] bg-seal-600 text-white rounded-full flex items-center justify-center text-base font-bold shadow-md cursor-pointer transition hover:bg-seal-700 active:scale-95 z-10" 
                                    onClick={e => { e.stopPropagation(); onFiles(p => p.filter((_, j) => j !== i)); }}
                                    aria-label={`Xóa ảnh ${i + 1}`}
                                >
                                    ×
                                </button>
                            </div>
                        );
                    })}
                    {files.length < 4 && (
                        <button 
                            type="button" 
                            className="cz-add-more min-h-[44px] px-4 py-2 bg-cream-100 hover:bg-cream-200 border border-cream-200 text-ink-900 rounded-lg text-xs font-bold transition flex items-center justify-center cursor-pointer" 
                            onClick={(e) => { e.preventDefault(); ref.current?.click(); }}
                            aria-label="Thêm ảnh minh chứng khác"
                        >
                            + Thêm ảnh
                        </button>
                    )}
                </div>
            )}
        </div>
    );
}

