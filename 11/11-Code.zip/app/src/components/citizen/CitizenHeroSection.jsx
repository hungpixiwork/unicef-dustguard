import React from 'react';
import Section from '../ui/Section';
import Container from '../ui/Container';
import { SealMark } from '../shared';

export default function CitizenHeroSection() {
    return (
        <Section fullHeight className="cz-hero-wrapper" variant="dark">
            <div className="cz-hero" style={{ minHeight: '100%', height: 'auto', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div className="cz-hero-bg"/>
                <Container>
                    <div className="cz-hero-inner" style={{ paddingTop: '40px', paddingBottom: '40px' }}>
                        <div className="cz-hero-txt">
                            <div className="cz-eyebrow mono">CỔNG GHI NHẬN &amp; ĐỐI CHỨNG CỘNG ĐỒNG</div>
                            <h1 className="cz-hero-h1">Ghi nhận bụi công trình<br/><em>ngay hôm nay</em></h1>
                            <p className="cz-hero-sub">Mỗi ghi nhận kèm ảnh và vị trí giúp cộng đồng thiết lập chuỗi bằng chứng trước–sau có cấu trúc, theo dõi minh bạch và kết nối với các kênh xử lý hiện hữu.</p>
                            <div className="cz-hero-stats">
                                <div className="cz-hero-stat"><strong>247</strong><span>điểm ghi nhận tháng này</span></div>
                                <div className="cz-stat-sep"/>
                                <div className="cz-hero-stat"><strong>88%</strong><span>tỷ lệ đối chứng lại</span></div>
                                <div className="cz-stat-sep"/>
                                <div className="cz-hero-stat"><strong>24–48h</strong><span>mục tiêu đối chứng thực địa</span></div>
                            </div>
                        </div>
                        <SealMark size={90}/>
                    </div>
                </Container>
            </div>
        </Section>
    );
}

