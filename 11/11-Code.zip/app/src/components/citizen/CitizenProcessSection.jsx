import React from 'react';
import Section from '../ui/Section';
import Container from '../ui/Container';

export default function CitizenProcessSection() {
    return (
        <Section variant="muted" style={{ padding: '60px 0' }}>
            <Container>
                <div className="cz-process-wrapper">
                    <div className="cz-eyebrow mono" style={{ textAlign: 'center', marginBottom: '16px' }}>QUY TRÌNH GHI NHẬN &amp; BẢO MẬT</div>
                    <h2 className="cz-sec-title" style={{ textAlign: 'center', marginBottom: '40px' }}>Minh bạch &amp; Đáng tin cậy</h2>
                    
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '30px', marginBottom: '40px' }}>
                        <div className="cz-process-step" style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid var(--line)' }}>
                            <div style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--amber)', marginBottom: '12px' }}>01</div>
                            <h3 style={{ fontSize: '18px', marginBottom: '8px', color: 'var(--ink)' }}>Gửi ghi nhận</h3>
                            <p style={{ color: 'var(--ink-3)', fontSize: '15px', lineHeight: '1.5' }}>Ghi nhận thông tin, vị trí và hình ảnh hiện trường thực tế. Hỗ trợ tùy chọn gửi ẩn danh 100%.</p>
                        </div>
                        <div className="cz-process-step" style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid var(--line)' }}>
                            <div style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--accent)', marginBottom: '12px' }}>02</div>
                            <h3 style={{ fontSize: '18px', marginBottom: '8px', color: 'var(--ink)' }}>Tiếp nhận &amp; Xác minh</h3>
                            <p style={{ color: 'var(--ink-3)', fontSize: '15px', lineHeight: '1.5' }}>Hệ thống liên kết vị trí với công trình. Điều phối viên và Tổ công tác thanh niên xác minh thực địa.</p>
                        </div>
                        <div className="cz-process-step" style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid var(--line)' }}>
                            <div style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--green)', marginBottom: '12px' }}>03</div>
                            <h3 style={{ fontSize: '18px', marginBottom: '8px', color: 'var(--ink)' }}>Đối chứng &amp; Khắc phục</h3>
                            <p style={{ color: 'var(--ink-3)', fontSize: '15px', lineHeight: '1.5' }}>Tiến độ đối chứng Before/After được công khai minh bạch. Tra cứu nhanh bằng mã ghi nhận.</p>
                        </div>
                    </div>

                    <div className="cz-trust" style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid var(--line)' }}>
                        <div className="cz-trust-row"><span>&#128274;</span><div><strong>Bảo mật</strong><span>Không công khai thông tin cá nhân trên cổng</span></div></div>
                        <div className="cz-trust-row"><span>&#9889;</span><div><strong>Ưu tiên đối chứng</strong><span>Mục tiêu cộng đồng quay lại đối chứng điểm ghi nhận trong 24–48 giờ</span></div></div>
                        <div className="cz-trust-row"><span>&#128202;</span><div><strong>Theo dõi chi tiết</strong><span>Cập nhật liên tục tiến trình xử lý và hồ sơ bàn giao</span></div></div>
                    </div>
                </div>
            </Container>
        </Section>
    );
}

