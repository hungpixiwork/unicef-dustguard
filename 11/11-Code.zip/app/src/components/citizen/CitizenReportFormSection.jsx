import React, { useState, useEffect } from 'react';
import Section from '../ui/Section';
import Container from '../ui/Container';
import UploadZone from './UploadZone';
import { publicApi } from "../../lib/api/public-api";

const EF = { citizen: "", phone: "", loc: "", desc: "" };

function vld(f) {
    if (f.loc.trim().length < 3) return "Vui lòng nhập địa chỉ công trình (ít nhất 3 ký tự).";
    if (f.desc.trim().length < 10) return "Mô tả tình trạng cần ít nhất 10 ký tự.";
    const d = f.phone.replace(/[\s-]/g, "");
    if (f.phone && !/^\d{8,15}$/.test(d)) return "Số điện thoại không hợp lệ.";
    return "";
}

export default function CitizenReportFormSection({ user }) {
    const [form, setForm] = useState(EF);
    const [photos, setPhotos] = useState([]);
    const [submitting, setSub] = useState(false);
    const [submitErr, setSubErr] = useState("");
    const [created, setCreated] = useState(null);

    useEffect(() => {
        if (user?.full_name) setForm(f => ({ ...f, citizen: user.full_name }));
    }, [user]);

    const upd = (k, v) => { setForm(f => ({ ...f, [k]: v })); setSubErr(""); };

    const submit = async e => {
        e.preventDefault();
        if (submitting) return;
        const err = vld(form);
        if (err) { setSubErr(err); return; }
        setSub(true); setSubErr("");
        try {
            const photoUrls = photos.map(p => p.dataUrl || p.url || (typeof p === 'string' ? p : ''));
            const c = await publicApi.submitPublicComplaint({
                citizen: form.citizen.trim() || undefined,
                phone: form.phone.trim() || undefined,
                loc: form.loc.trim(),
                desc: form.desc.trim(),
                photo: photos.length > 0,
                photoCount: photos.length,
                evidences: photoUrls.filter(Boolean),
                sha256: photos[0]?.sha256 || undefined
            });
            setCreated(c);
            setForm({ ...EF, citizen: user?.full_name || "" });
            setPhotos([]);
        } catch (err) {
            setSubErr(err.message || "Gửi phản ánh thất bại.");
        } finally {
            setSub(false);
        }
    };

    return (
        <Section style={{ padding: '60px 0' }}>
            <Container>
                <div className="cz-form-grid">
                    <section className="cz-card">
                        <div className="cz-card-eyebrow mono">PHẢN ÁNH MỚI</div>
                        <h2 className="cz-card-h2">Gửi phản ánh cộng đồng</h2>
                        <p className="cz-card-sub">Ghi nhận minh chứng hiện trường thực tế để đối chứng minh bạch. Thông tin cá nhân được bảo vệ theo quy định.</p>
                        
                        <form onSubmit={submit} className="cz-form space-y-4">
                            <div className="cz-row2">
                                <label className="block text-xs font-bold text-ink-900 mb-1">
                                    Họ tên <span className="text-ink-500 font-normal">(tuỳ chọn)</span>
                                    <input 
                                        type="text"
                                        autoComplete="name"
                                        value={form.citizen} 
                                        onChange={e => upd("citizen", e.target.value)} 
                                        placeholder="Nguyễn Văn A" 
                                        className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg border border-cream-200 bg-white text-ink-900 focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                                    />
                                </label>
                                <label className="block text-xs font-bold text-ink-900 mb-1">
                                    Số điện thoại <span className="text-ink-500 font-normal">(tuỳ chọn)</span>
                                    <input 
                                        type="tel"
                                        inputMode="tel"
                                        autoComplete="tel"
                                        value={form.phone} 
                                        onChange={e => upd("phone", e.target.value)} 
                                        placeholder="09xx xxx xxx" 
                                        className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg border border-cream-200 bg-white text-ink-900 focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                                    />
                                </label>
                            </div>
                            <label className="block text-xs font-bold text-ink-900 mb-1">
                                Địa chỉ công trình / Hiện trường <span className="text-seal-600 font-bold">*</span>
                                <input 
                                    type="text"
                                    value={form.loc} 
                                    onChange={e => upd("loc", e.target.value)} 
                                    placeholder="VD: 128 Nguyễn Trãi, Thanh Xuân, Hà Nội" 
                                    required
                                    aria-required="true"
                                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg border border-cream-200 bg-white text-ink-900 focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
                                />
                            </label>
                            <label className="block text-xs font-bold text-ink-900 mb-1">
                                Mô tả tình trạng quan sát <span className="text-seal-600 font-bold">*</span>
                                <textarea 
                                    value={form.desc} 
                                    onChange={e => upd("desc", e.target.value)} 
                                    placeholder="VD: Xe tải không rửa bánh khi ra khỏi cổng, bùn đất tràn ra đường làm phát sinh bụi mù mịt..." 
                                    rows={4} 
                                    required
                                    aria-required="true"
                                    className="w-full p-3.5 rounded-lg border border-cream-200 bg-white text-ink-900 focus:outline-none focus:ring-2 focus:ring-[#0d6f64] resize-y"
                                />
                            </label>
                            <label className="block text-xs font-bold text-ink-900 mb-1">
                                Hình ảnh thực tế <span className="text-accent-700 font-bold ml-1">&#9733; Tự động nén &lt; 300KB &amp; Khử EXIF</span>
                            </label>
                            
                            <UploadZone files={photos} onFiles={setPhotos} />
                            
                            {submitErr && <div className="p-3 rounded-lg bg-seal-50 border border-seal-200 text-seal-800 text-xs font-semibold">{submitErr}</div>}
                            <button 
                                className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-sm shadow-sm transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-4" 
                                disabled={submitting}
                                aria-label="Gửi phản ánh ghi nhận môi trường"
                            >
                                {submitting ? "Đang gửi phản ánh..." : "► Gửi phản ánh"}
                            </button>
                        </form>
                        
                        {created && (
                            <div className="cz-success" style={{ marginTop: '24px' }}>
                                <strong>Gửi thành công!</strong>
                                <span className="break-words">Mã: <b className="mono break-all">{created.id}</b> &#8212; Lưu mã để tra cứu tiến trình bên dưới.</span>
                            </div>
                        )}
                    </section>

                    <aside className="cz-form-sidebar" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                        <div className="cz-card" style={{ background: 'var(--auth-cream)', border: 'none' }}>
                            <h3 style={{ fontSize: '15px', fontWeight: 600, margin: '0 0 12px' }}> Bảo mật &amp; Quyền riêng tư</h3>
                            <p style={{ fontSize: '13px', color: 'var(--ink-3)', margin: 0, lineHeight: 1.5 }}>
                                Thông tin cá nhân của bạn (nếu cung cấp) sẽ được mã hoá và chỉ sử dụng cho mục đích liên hệ xác minh bởi cán bộ. Hệ thống không công khai danh tính người phản ánh.
                            </p>
                        </div>
                        <div className="cz-card" style={{ background: 'var(--blue-bg)', border: 'none' }}>
                            <h3 style={{ fontSize: '15px', fontWeight: 600, margin: '0 0 12px', color: 'var(--blue)' }}> Lưu ý hình ảnh &amp; Minh chứng</h3>
                            <ul style={{ fontSize: '13px', color: 'var(--blue)', margin: 0, paddingLeft: '20px', lineHeight: 1.6 }}>
                                <li>Chụp toàn cảnh khu vực phát sinh bụi và cổng công trình</li>
                                <li>Hệ thống tự động xóa sạch thông tin thiết bị (EXIF) để bảo vệ quyền riêng tư</li>
                                <li>Mỗi tệp được tạo mã xác thực số bảo toàn tính nguyên vẹn</li>
                                <li>Ảnh có gắn vị trí (GPS) giúp điều phối viên đối soát nhanh hơn</li>
                            </ul>
                        </div>
                    </aside>
                </div>
            </Container>
        </Section>
    );
}

