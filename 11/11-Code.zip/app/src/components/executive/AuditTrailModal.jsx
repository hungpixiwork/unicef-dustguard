import React, { useState, useMemo } from 'react';

export default function AuditTrailModal({ auditLogs = [], onClose }) {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [actionFilter, setActionFilter] = useState('ALL');

  const roles = ['ALL', 'EXECUTIVE', 'STAFF', 'ADMIN', 'SYSTEM', 'CITIZEN', 'CONTRACTOR'];

  const actions = useMemo(() => {
    const defaultActions = [
      'ALL',
      'LEADER_SIGN_DOCUMENT',
      'INSPECTION_CREATE',
      'COMPLAINT_SUBMIT',
      'ACTION_CREATE',
      'ACTION_VERIFY',
      'CASE_UPDATE',
      'DOCUMENT_CREATE'
    ];
    const set = new Set(defaultActions);
    if (Array.isArray(auditLogs)) {
      auditLogs.forEach(log => {
        if (log?.action) set.add(log.action);
      });
    }
    return Array.from(set);
  }, [auditLogs]);

  const filteredLogs = useMemo(() => {
    if (!Array.isArray(auditLogs)) return [];
    return auditLogs.filter(log => {
      const actorRoleUpper = (log?.actorRole || 'SYSTEM').toUpperCase();
      const matchRole = roleFilter === 'ALL' || actorRoleUpper === roleFilter.toUpperCase();

      const actionUpper = (log?.action || '').toUpperCase();
      const matchAction = actionFilter === 'ALL' || actionUpper === actionFilter.toUpperCase();

      const actorName = (log?.actorName || 'Hệ thống').toLowerCase();
      const actionName = (log?.action || '').toLowerCase();
      const details = (typeof log?.details === 'object' ? JSON.stringify(log.details) : String(log?.details || '')).toLowerCase();
      const ip = (log?.ipAddress || '').toLowerCase();
      const query = search.toLowerCase().trim();

      const matchSearch = !query || actorName.includes(query) || actionName.includes(query) || details.includes(query) || ip.includes(query);

      return matchRole && matchAction && matchSearch;
    });
  }, [auditLogs, roleFilter, actionFilter, search]);

  // Handle Escape key & body overflow
  React.useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[9999] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto" role="dialog" aria-modal="true">
      <div className="bg-[#FDFBF7] dark:bg-gray-900 border border-cream-200 dark:border-gray-800 w-full max-w-4xl rounded-t-2xl sm:rounded-xl shadow-lg flex flex-col h-[90vh] sm:h-[85vh] overflow-hidden pb-safe">
        {/* Header */}
        <div className="px-5 sm:px-6 py-3.5 sm:py-4 border-b border-cream-200 dark:border-gray-800 bg-[#F8F1E2] dark:bg-gray-800 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[#0d6f64] text-xl" aria-hidden="true"></span>
            <div>
              <h3 className="font-bold text-sm text-[#231b14] dark:text-white uppercase tracking-wider">
                Nhật ký Truy vết Hoạt động Toàn hệ thống (Audit Trail)
              </h3>
              <p className="text-[11px] text-ink-500 dark:text-gray-400">
                Ghi nhận lịch sử thao tác theo tiêu chuẩn an ninh & minh bạch thông tin civic-tech
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center justify-center w-11 h-11 min-h-[44px] min-w-[44px] rounded-lg text-ink-500 hover:text-ink-900 hover:bg-cream-200 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-700 text-xl font-bold cursor-pointer transition"
            aria-label="Đóng nhật ký truy vết"
          >
            &times;
          </button>
        </div>

        {/* Search & Filters Controls */}
        <div className="p-3 sm:p-4 border-b border-cream-200 dark:border-gray-800 bg-white dark:bg-gray-800/50 flex flex-wrap gap-2.5 items-center justify-between shrink-0 text-xs">
          <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[240px]">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm theo cán bộ, hành động hoặc thông tin..."
              className="px-3 py-2 min-h-[40px] bg-cream-50 dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs flex-1 focus:outline-none focus:ring-2 focus:ring-[#0d6f64]"
              aria-label="Tìm kiếm nhật ký"
            />
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-2 min-h-[40px] bg-cream-50 dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs font-bold"
              aria-label="Lọc theo vai trò"
            >
              {roles.map(r => <option key={r} value={r}>Vai trò: {r}</option>)}
            </select>
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="px-3 py-2 min-h-[40px] bg-cream-50 dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs font-bold"
              aria-label="Lọc theo hành động"
            >
              {actions.map(a => <option key={a} value={a}>Hành động: {a}</option>)}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-mono text-ink-700 dark:text-gray-300 text-[11px] font-bold">
              {filteredLogs.length} bản ghi
            </span>
            <button
              onClick={handlePrint}
              className="min-h-[44px] px-4 py-2.5 bg-cream-100 dark:bg-gray-700 hover:bg-cream-200 text-ink-800 dark:text-gray-200 font-bold rounded-lg transition inline-flex items-center gap-1.5 cursor-pointer"
            >
              ️ In Nhật ký
            </button>
          </div>
        </div>

        {/* Logs Table with Horizontal Scroll */}
        <div className="flex-1 overflow-y-auto overflow-x-auto p-3 sm:p-4">
          {filteredLogs.length === 0 ? (
            <div className="py-12 text-center text-xs text-ink-500 font-medium">
              Không tìm thấy nhật ký phù hợp.
            </div>
          ) : (
            <div className="overflow-x-auto w-full">
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
              <thead>
                <tr className="border-b border-cream-200 dark:border-gray-800 text-[11px] font-bold uppercase text-ink-500 dark:text-gray-400 bg-cream-50/50 dark:bg-gray-800/40">
                  <th className="py-2.5 px-3 min-w-[140px]">Thời gian</th>
                  <th className="py-2.5 px-3 min-w-[130px]">Cán bộ thực hiện</th>
                  <th className="py-2.5 px-3 min-w-[90px]">Vai trò</th>
                  <th className="py-2.5 px-3 min-w-[140px]">Hành động</th>
                  <th className="py-2.5 px-3 min-w-[200px]">Chi tiết dữ liệu</th>
                  <th className="py-2.5 px-3 min-w-[100px]">Địa chỉ IP</th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map((log, idx) => (
                  <tr key={log?.id || idx} className="border-b border-cream-100 dark:border-gray-800 hover:bg-cream-50/30 dark:hover:bg-gray-800/30">
                    <td className="py-2.5 px-3 font-mono text-[11px] whitespace-nowrap">
                      {log?.createdAt ? new Date(log.createdAt).toLocaleString('vi-VN') : '—'}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-ink-900 dark:text-white whitespace-nowrap">
                      {log?.actorName || 'Hệ thống'}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[10px] font-bold uppercase whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded bg-cream-100 dark:bg-gray-800 text-ink-700 dark:text-gray-300">
                        {log?.actorRole || 'SYSTEM'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-bold whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-accent-50 text-[#0d6f64] border border-accent-200">
                        {log?.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-ink-700 dark:text-gray-300 truncate max-w-xs">
                      {typeof log?.details === 'object' ? JSON.stringify(log.details) : String(log?.details || '—')}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[10px] text-ink-400 whitespace-nowrap">
                      {log?.ipAddress || '127.0.0.1'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3 border-t border-cream-200 dark:border-gray-800 bg-[#F8F1E2] dark:bg-gray-800 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="min-h-[44px] px-6 py-2.5 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold text-sm rounded-lg shadow-sm transition cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}
