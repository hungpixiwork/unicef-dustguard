import React, { useState, useEffect } from 'react';
import { request } from '../../lib/api/request';

const DEFAULT_INSPECTORS = [
  { id: 'usr_staff_01', name: 'Cán bộ Nguyễn Văn An', title: 'Tổ trưởng Tổ Giám sát', phone: '0988 123 456', team: 'Đội Thanh tra Địa bàn Phường', activeCases: 3 },
  { id: 'usr_staff_02', name: 'Thanh tra viên Trần Thị Bích', title: 'Thanh tra viên Môi trường', phone: '0912 345 678', team: 'Đội Thanh tra Môi trường số 1', activeCases: 1 },
  { id: 'usr_staff_03', name: 'Chuyên viên Lê Hoàng Long', title: 'Cán bộ Hiện trường', phone: '0977 888 999', team: 'Đội Cơ động Hiện trường', activeCases: 4 },
  { id: 'usr_staff_04', name: 'Kỹ thuật viên Phạm Quốc Toàn', title: 'Chuyên viên Quan trắc', phone: '0934 567 890', team: 'Trung tâm Quan trắc Môi trường', activeCases: 2 },
];

export default function InspectorAssignmentModal({ site, onClose, onSuccess }) {
  const [sitesList, setSitesList] = useState([]);
  const [selectedSiteId, setSelectedSiteId] = useState(site?.id || '');
  const [inspectors, setInspectors] = useState(DEFAULT_INSPECTORS);
  const [selectedInspector, setSelectedInspector] = useState(DEFAULT_INSPECTORS[0].id);
  const [slaHours, setSlaHours] = useState('48');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetchingSites, setFetchingSites] = useState(false);
  const [error, setError] = useState('');

  // Fetch real staff directory from system
  useEffect(() => {
    let isMounted = true;
    request('/users?role=staff')
      .then((res) => {
        const items = res?.data?.items || res?.items || (Array.isArray(res) ? res : []);
        if (isMounted && items.length > 0) {
          const mapped = items.map((u, i) => ({
            id: u.id,
            name: u.fullName || u.name || u.email,
            title: u.department || 'Thanh tra viên Môi trường',
            phone: u.phoneNumber || '0988 123 456',
            team: u.department || `Đội Thanh tra số ${i + 1}`,
            activeCases: u.activeCases || (i + 1)
          }));
          setInspectors(mapped);
          setSelectedInspector(mapped[0].id);
        }
      })
      .catch(() => {});

    return () => { isMounted = false; };
  }, []);

  useEffect(() => {
    if (!site?.id) {
      setFetchingSites(true);
      request('/sites')
        .then((res) => {
          const items = res?.data?.items || res?.items || (Array.isArray(res) ? res : []);
          setSitesList(items);
          if (items.length > 0) {
            setSelectedSiteId(items[0].id);
          }
        })
        .catch(() => {})
        .finally(() => setFetchingSites(false));
    }
  }, [site]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const targetSiteId = site?.id || selectedSiteId;
    if (!targetSiteId) {
      setError('Vui lòng chọn công trình thi công cần phân công');
      return;
    }

    setLoading(true);
    const inspectorObj = inspectors.find(i => i.id === selectedInspector) || inspectors[0];

    try {
      const res = await request(`/sites/${targetSiteId}/assign-inspector`, {
        method: 'POST',
        body: JSON.stringify({
          inspectorId: inspectorObj?.id,
          inspectorName: inspectorObj?.name,
          slaHours: parseInt(slaHours, 10),
          note
        })
      });

      if (res && (res.status === 'success' || res.status === 200 || res.status === 201 || res.data)) {
        if (onSuccess) onSuccess(inspectorObj, slaHours, res.data || res);
        onClose();
      } else {
        throw new Error(res?.message || 'Phân công cán bộ thất bại');
      }
    } catch (err) {
      setError(err.message || 'Phân công cán bộ thất bại');
    } finally {
      setLoading(false);
    }
  };

  // Handle Escape key & body overflow
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  const activeSiteName = site?.name || site?.title || sitesList.find(s => s.id === selectedSiteId)?.name || 'Chưa chọn công trình';

  return (
    <div className="fixed inset-0 bg-black/60 z-[9999] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto" role="dialog" aria-modal="true">
      <div className="bg-[#FDFBF7] dark:bg-gray-900 border border-cream-200 dark:border-gray-800 w-full max-w-lg rounded-t-2xl sm:rounded-xl shadow-lg flex flex-col max-h-[92vh] sm:max-h-[90vh] overflow-hidden pb-safe">
        {/* Header */}
        <div className="px-5 sm:px-6 py-3.5 sm:py-4 border-b border-cream-200 dark:border-gray-800 bg-[#F8F1E2] dark:bg-gray-800 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[#0d6f64] text-xl" aria-hidden="true"></span>
            <div>
              <h3 className="font-bold text-sm text-[#231b14] dark:text-white uppercase tracking-wider">
                Phân công Cán bộ / Tổ thanh tra
              </h3>
              <p className="text-[11px] text-ink-500 dark:text-gray-400">
                Công trình: <span className="font-bold text-ink-900 dark:text-white">{activeSiteName}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex items-center justify-center w-11 h-11 min-h-[44px] min-w-[44px] rounded-lg text-ink-500 hover:text-ink-900 hover:bg-cream-200 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-700 text-xl font-bold cursor-pointer transition"
            aria-label="Đóng cửa sổ phân công"
          >
            &times;
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto flex flex-col gap-4 text-xs">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-[#9f241f] rounded-lg font-semibold">
              ️ {error}
            </div>
          )}

          {/* Site Selector if not pre-selected */}
          {!site?.id && (
            <div>
              <label className="font-bold text-ink-900 dark:text-white block mb-1.5">
                Chọn Công trình thi công cần kiểm tra:
              </label>
              {fetchingSites ? (
                <div className="p-2.5 bg-cream-50 text-ink-500 text-xs italic">Đang tải danh sách công trình...</div>
              ) : (
                <select
                  value={selectedSiteId}
                  onChange={(e) => setSelectedSiteId(e.target.value)}
                  className="w-full p-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs font-bold text-ink-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#0d6f64]"
                >
                  {sitesList.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.ward || s.province || 'Hà Nội'}) - Rủi ro: {s.dustRiskScore ?? 50}đ
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          <div>
            <label className="font-bold text-ink-900 dark:text-white block mb-1.5">
              Chọn Thanh tra viên / Tổ công tác phụ trách:
            </label>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {inspectors.map(insp => (
                <label
                  key={insp.id}
                  className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition ${
                    selectedInspector === insp.id
                      ? 'bg-accent-50 border-[#0d6f64] dark:bg-gray-800'
                      : 'bg-white dark:bg-gray-800 border-cream-200 dark:border-gray-700 hover:bg-cream-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="inspector"
                      value={insp.id}
                      checked={selectedInspector === insp.id}
                      onChange={() => setSelectedInspector(insp.id)}
                      className="accent-[#0d6f64]"
                    />
                    <div>
                      <div className="font-bold text-ink-900 dark:text-white">{insp.name}</div>
                      <div className="text-[10px] text-ink-500 dark:text-gray-400">{insp.title} · {insp.team}</div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 bg-cream-100 dark:bg-gray-700 text-ink-700 dark:text-gray-300 font-mono text-[10px] font-bold rounded">
                    {insp.activeCases} vụ việc
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="font-bold text-ink-900 dark:text-white block mb-1.5">
              Thời hạn giải quyết:
            </label>
            <select
              value={slaHours}
              onChange={(e) => setSlaHours(e.target.value)}
              className="w-full p-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs font-bold text-ink-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#0d6f64]"
            >
              <option value="24">24 giờ (Khẩn cấp / Điểm nóng quá 80đ)</option>
              <option value="48">48 giờ (Tiêu chuẩn theo quy trình)</option>
              <option value="72">72 giờ (Vụ việc phức tạp / Cần xác minh thêm)</option>
            </select>
          </div>

          <div>
            <label className="font-bold text-ink-900 dark:text-white block mb-1.5">
              Ghi chú chỉ đạo của Lãnh đạo:
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Nhập yêu cầu kiểm tra thực địa, tập trung các hạng mục cầu rửa xe, tưới nước dập bụi..."
              className="w-full p-2.5 bg-white dark:bg-gray-800 border border-cream-200 dark:border-gray-700 rounded-lg text-xs text-ink-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#0d6f64]"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex justify-end gap-3 pt-3 border-t border-cream-200 dark:border-gray-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-cream-200 dark:border-gray-700 text-ink-700 dark:text-gray-300 font-bold rounded-lg hover:bg-cream-100 dark:hover:bg-gray-800 transition cursor-pointer"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-[#0d6f64] hover:bg-[#0a564e] text-white font-bold rounded-lg shadow-sm transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {loading ? 'Đang phân công...' : ' Xác nhận Phân công'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
