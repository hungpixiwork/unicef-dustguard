import React, { useState } from 'react';
import { request } from '../../lib/api/request';

export default function SLAEscalationPanel({ overdueItems = [], onTriggerEscalation }) {
  const [escalatedIds, setEscalatedIds] = useState([]);
  const [loadingId, setLoadingId] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  const defaultOverdueList = overdueItems.length > 0 ? overdueItems : [
    { id: 'ovd-1', name: 'Công trình Tòa nhà Landmark Tower', action: 'Khắc phục phun nước dập bụi đường Cầu Giấy', hoursOverdue: 52, inspector: 'Nguyễn Văn Hùng', siteId: 'BD-0237' },
    { id: 'ovd-2', name: 'Dự án Cầu vượt Mộ Lao', action: 'Che chắn bạt vật liệu bãi phế thải', hoursOverdue: 64, inspector: 'Trần Thị Mai', siteId: 'ML-0891' },
    { id: 'ovd-3', name: 'Khu đô thị Trung Hòa - Nhân Chính', action: 'Rửa lốp phương tiện ra vào cổng số 2', hoursOverdue: 49, inspector: 'Lê Hoàng Nam', siteId: 'TH-0112' }
  ];

  const handleEscalate = async (item) => {
    setLoadingId(item.id);
    setErrorMessage('');

    const hours = item.hoursOverdue ?? (item.hoursLeft != null ? Math.max(48, 48 - item.hoursLeft) : 48);

    try {
      const res = await request(`/cases/${item.id}/escalate`, {
        method: 'POST',
        body: JSON.stringify({
          reason: `Cảnh báo leo thang Lãnh đạo: Vụ việc quá hạn ${hours}h`,
          hoursOverdue: hours
        })
      });

      if (res && (res.status === 'success' || res.escalated || res.data?.escalated)) {
        setEscalatedIds(prev => [...prev, item.id]);
        if (onTriggerEscalation) onTriggerEscalation(item);
      } else {
        throw new Error(res?.message || 'Không thể phát lệnh chỉ đạo leo thang');
      }
    } catch (err) {
      console.error('Escalation API error:', err);
      setErrorMessage(err.message || 'Lỗi kết nối máy chủ API khi chỉ đạo leo thang');
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div className="rounded-xl border border-red-200 bg-red-50/40 dark:bg-gray-900 dark:border-red-900/50 shadow-soft p-6 flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center items-start gap-2 border-b border-red-100 dark:border-red-900/30 pb-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">️</span>
          <div>
            <h2 className="font-bold text-base text-[#9f241f] dark:text-red-400">
              Cảnh báo Leo thang Vụ việc Tồn đọng quá 48h
            </h2>
            <p className="text-xs text-ink-500 dark:text-gray-400">
              Danh sách vụ việc vi phạm và chỉ thị đã vượt thời hạn giải quyết tiêu chuẩn (quá 48 giờ)
            </p>
          </div>
        </div>
        <span className="px-2.5 py-1 bg-red-100 text-[#9f241f] border border-red-200 font-mono font-bold text-xs rounded-full">
          {defaultOverdueList.length} tồn đọng quá hạn
        </span>
      </div>

      {errorMessage && (
        <div className="p-3 rounded-lg bg-red-100 border border-red-200 text-xs text-[#9f241f] font-semibold flex justify-between items-center">
          <span>️ {errorMessage}</span>
          <button onClick={() => setErrorMessage('')} className="font-bold text-sm cursor-pointer">&times;</button>
        </div>
      )}

      <div className="space-y-3">
        {defaultOverdueList.map((item) => {
          const isEscalated = escalatedIds.includes(item.id);
          const isLoading = loadingId === item.id;
          const displayHours = item.hoursOverdue ?? (item.hoursLeft != null ? Math.max(48, 48 - item.hoursLeft) : 48);

          return (
            <div
              key={item.id}
              className="p-3.5 bg-white dark:bg-gray-800 rounded-lg border border-red-200 dark:border-red-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="flex flex-col gap-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-ink-900 dark:text-white truncate">
                    {item.name || item.title || 'Công trình vi phạm'}
                  </span>
                  <span className="px-2 py-0.5 bg-red-100 text-[#9f241f] font-mono font-bold text-[10px] rounded uppercase">
                    Quá {displayHours}h
                  </span>
                </div>
                <div className="text-ink-600 dark:text-gray-300">
                  <span className="font-semibold text-ink-400">Yêu cầu chỉ đạo:</span> {item.action || 'Khắc phục ô nhiễm vi phạm môi trường'}
                </div>
                <div className="text-[11px] text-ink-400 dark:text-gray-500">
                  Cán bộ phụ trách: <span className="font-bold text-ink-700 dark:text-gray-300">{item.inspector || 'Đoàn thanh tra'}</span>
                </div>
              </div>

              <div className="shrink-0 flex items-center justify-end">
                {isEscalated ? (
                  <span className="px-3 py-1.5 bg-accent-50 text-[#0d6f64] border border-accent-200 font-bold text-[11px] rounded-lg">
                     Đã gửi Cảnh báo Hỏa tốc
                  </span>
                ) : (
                  <button
                    onClick={() => handleEscalate(item)}
                    disabled={isLoading}
                    className="px-3 py-1.5 bg-[#9f241f] hover:bg-red-800 text-white font-bold text-[11px] rounded-lg shadow-sm transition disabled:opacity-50 flex items-center gap-1 cursor-pointer"
                  >
                    {isLoading ? (
                      <>
                        <div className="h-3 w-3 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
                        Đang gửi...
                      </>
                    ) : (
                      ' Chỉ đạo Leo thang Hỏa tốc'
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

