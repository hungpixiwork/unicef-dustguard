import { useState } from "react";
import { DropdownItem } from "../ui/dropdown/DropdownItem";
import { Dropdown } from "../ui/dropdown/Dropdown";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { ROLES, normalizeRole } from "../../lib/rbac-rules.js";

export default function UserDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const { user: authUser, logout, isClerkEnabled } = useAuth();
  const navigate = useNavigate();

  const user = authUser || {
    id: "guest",
    profile: {
      fullName: "Khách (Guest)",
      avatarUrl: ""
    },
    email: "guest@dustguard.vn",
    role: ROLES.CITIZEN
  };

  const normalizedRole = normalizeRole(user.role || ROLES.CITIZEN);

  function toggleDropdown() {
    setIsOpen(!isOpen);
  }

  function closeDropdown() {
    setIsOpen(false);
  }

  const handleSignOut = async () => {
    try {
      await logout();
      closeDropdown();
      navigate("/login");
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  // Role Badge Styling Config (High Contrast Civic Tech)
  const getRoleBadge = (role: string) => {
    switch (role) {
      case ROLES.ADMIN:
      case ROLES.DEMO_ADMIN:
        return { label: "Quản trị viên", bg: "bg-seal-50 text-seal-700 border-seal-200" };
      case ROLES.EXECUTIVE:
        return { label: "Lãnh đạo", bg: "bg-purple-50 text-purple-700 border-purple-200" };
      case ROLES.STAFF:
      case ROLES.INSPECTOR:
        return { label: "Cán bộ giám sát", bg: "bg-accent-50 text-accent-700 border-accent-200" };
      case ROLES.CONTRACTOR:
        return { label: "Nhà thầu thi công", bg: "bg-amber-50 text-amber-700 border-amber-200" };
      case ROLES.CITIZEN:
      case ROLES.YOUTH_MEMBER:
      default:
        return { label: "Cộng đồng / Công dân", bg: "bg-cream-100 text-ink-700 border-cream-200" };
    }
  };

  const roleInfo = getRoleBadge(normalizedRole);
  const rawDisplayName = user?.profile?.fullName || user?.name || user?.email || "User";
  const displayName = rawDisplayName.split(' - ')[0].trim();
  const avatarUrl = user?.profile?.avatarUrl && user?.profile?.avatarUrl !== '/images/user/owner.jpg'
    ? user.profile.avatarUrl
    : `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=0d6f64&color=fff&size=150`;

  return (
    <div className="relative">
      <button
        onClick={toggleDropdown}
        className="flex items-center text-ink-700 dropdown-toggle dark:text-gray-400 min-h-[44px] px-1.5 py-1 rounded-xl hover:bg-cream-100 dark:hover:bg-gray-800 transition cursor-pointer border border-transparent hover:border-ink-900/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-seal-600"
        aria-label="Tùy chọn tài khoản cá nhân"
        aria-expanded={isOpen}
      >
        <span className="mr-2.5 overflow-hidden rounded-full h-9 w-9 min-h-[36px] min-w-[36px] border border-ink-900/15 shrink-0 bg-cream-100">
          <img 
            src={avatarUrl} 
            alt={displayName} 
            className="w-full h-full object-cover" 
          />
        </span>

        <div className="hidden sm:flex flex-col items-start mr-1 text-left">
          <span className="font-extrabold text-xs text-ink-900 dark:text-white max-w-[160px] lg:max-w-[190px] truncate leading-tight whitespace-nowrap">
            {displayName}
          </span>
          <span className="text-[10px] text-ink-500 font-medium truncate max-w-[160px]">
            {roleInfo.label}
          </span>
        </div>

        <svg
          className={`stroke-ink-500 dark:stroke-gray-400 transition-transform duration-200 shrink-0 ml-1 ${
            isOpen ? "rotate-180" : ""
          }`}
          width="16"
          height="16"
          viewBox="0 0 18 20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M4.3125 8.65625L9 13.3437L13.6875 8.65625"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      <Dropdown
        isOpen={isOpen}
        onClose={closeDropdown}
        className="absolute right-0 mt-2 flex w-[280px] flex-col rounded-2xl border border-ink-900/10 bg-white p-3.5 shadow-elevation dark:border-gray-800 dark:bg-gray-dark z-50"
      >
        {/* User Identity Header Card */}
        <div className="p-2.5 rounded-xl bg-cream-50 border border-ink-900/5 dark:bg-gray-800/50">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="block font-black text-ink-900 text-sm dark:text-white truncate">
              {displayName}
            </span>
            {isClerkEnabled && (
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-seal-50 text-seal-700 border border-seal-200">
                Clerk
              </span>
            )}
          </div>
          <span className="block text-xs text-ink-500 dark:text-gray-400 truncate mb-2 font-mono">
            {user?.email || "Chưa có email"}
          </span>
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${roleInfo.bg}`}>
            {roleInfo.label}
          </span>
        </div>

        {/* User Details & Unit Info */}
        <div className="py-2 px-1 border-b border-ink-900/10 dark:border-gray-800 text-[11px] text-ink-600 space-y-1">
          <div className="flex items-center justify-between px-2">
            <span className="text-ink-400 font-medium">Đơn vị:</span>
            <span className="font-bold text-ink-800 truncate max-w-[170px]">{user?.department || "Sở Tài nguyên & Môi trường"}</span>
          </div>
          <div className="flex items-center justify-between px-2">
            <span className="text-ink-400 font-medium">Chức vụ:</span>
            <span className="font-bold text-ink-800 truncate max-w-[170px]">{user?.title || roleInfo.label}</span>
          </div>
        </div>

        {/* Navigation Items */}
        <ul className="flex flex-col gap-1 pt-2 pb-2 border-b border-ink-900/10 dark:border-gray-800">
          <li>
            <DropdownItem
              onItemClick={closeDropdown}
              tag="a"
              to="/staff/profile"
              className="flex items-center gap-2.5 px-3 py-2 font-semibold text-ink-700 rounded-lg group text-xs hover:bg-cream-100 hover:text-ink-900 dark:text-gray-300 dark:hover:bg-white/5"
            >
              <svg className="w-4 h-4 text-ink-500 group-hover:text-seal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <span>Hồ sơ cá nhân</span>
            </DropdownItem>
          </li>
          <li>
            <DropdownItem
              onItemClick={closeDropdown}
              tag="a"
              to="/staff/profile?tab=permissions"
              className="flex items-center gap-2.5 px-3 py-2 font-semibold text-ink-700 rounded-lg group text-xs hover:bg-cream-100 hover:text-ink-900 dark:text-gray-300 dark:hover:bg-white/5"
            >
              <svg className="w-4 h-4 text-ink-500 group-hover:text-seal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              <span>Quyền truy cập & Ký số</span>
            </DropdownItem>
          </li>
          <li>
            <DropdownItem
              onItemClick={closeDropdown}
              tag="a"
              to="/staff/settings"
              className="flex items-center gap-2.5 px-3 py-2 font-semibold text-ink-700 rounded-lg group text-xs hover:bg-cream-100 hover:text-ink-900 dark:text-gray-300 dark:hover:bg-white/5"
            >
              <svg className="w-4 h-4 text-ink-500 group-hover:text-seal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span>Cài đặt hệ thống</span>
            </DropdownItem>
          </li>
        </ul>

        {/* Sign Out CTA */}
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-2.5 px-3 py-2 mt-2 font-bold text-seal-700 rounded-xl hover:bg-seal-50 dark:hover:bg-seal-900/20 text-xs transition-colors cursor-pointer"
        >
          <svg className="w-4 h-4 text-seal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span>Đăng xuất</span>
        </button>
      </Dropdown>
    </div>
  );
}
