import { useState } from "react";
import { Dropdown } from "../ui/dropdown/Dropdown";
import { DropdownItem } from "../ui/dropdown/DropdownItem";
import { Link } from "react-router-dom";

export default function NotificationDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const [notifying, setNotifying] = useState(true);

  function toggleDropdown() {
    setIsOpen(!isOpen);
  }

  function closeDropdown() {
    setIsOpen(false);
  }

  const handleClick = () => {
    toggleDropdown();
    setNotifying(false);
  };
  return (
    <div className="relative">
      <button
        className="relative flex items-center justify-center text-gray-500 transition-colors bg-white border border-gray-200 rounded-full dropdown-toggle hover:text-gray-700 h-11 w-11 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
        onClick={handleClick}
        aria-label="Xem thông báo"
      >
        <span
          className={`absolute right-0 top-0.5 z-10 h-2 w-2 rounded-full bg-orange-400 ${
            !notifying ? "hidden" : "flex"
          }`}
        >
          <span className="absolute inline-flex w-full h-full bg-orange-400 rounded-full opacity-75 animate-ping"></span>
        </span>
        <svg
          className="fill-current"
          width="20"
          height="20"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.75 2.29248C10.75 1.87827 10.4143 1.54248 10 1.54248C9.58583 1.54248 9.25004 1.87827 9.25004 2.29248V2.83613C6.08266 3.20733 3.62504 5.9004 3.62504 9.16748V14.4591H3.33337C2.91916 14.4591 2.58337 14.7949 2.58337 15.2091C2.58337 15.6234 2.91916 15.9591 3.33337 15.9591H4.37504H15.625H16.6667C17.0809 15.9591 17.4167 15.6234 17.4167 15.2091C17.4167 14.7949 17.0809 14.4591 16.6667 14.4591H16.375V9.16748C16.375 5.9004 13.9174 3.20733 10.75 2.83613V2.29248ZM14.875 14.4591V9.16748C14.875 6.47509 12.6924 4.29248 10 4.29248C7.30765 4.29248 5.12504 6.47509 5.12504 9.16748V14.4591H14.875ZM8.00004 17.7085C8.00004 18.1228 8.33583 18.4585 8.75004 18.4585H11.25C11.6643 18.4585 12 18.1228 12 17.7085C12 17.2943 11.6643 16.9585 11.25 16.9585H8.75004C8.33583 16.9585 8.00004 17.2943 8.00004 17.7085Z"
            fill="currentColor"
          />
        </svg>
      </button>
      <Dropdown
        isOpen={isOpen}
        onClose={closeDropdown}
        className="absolute right-0 mt-2 flex h-[480px] max-h-[85vh] w-[340px] max-w-[calc(100vw-24px)] sm:w-[361px] flex-col rounded-2xl border border-gray-200 bg-white p-3 shadow-theme-lg dark:border-gray-800 dark:bg-gray-dark z-[9999]"
      >
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-gray-100 dark:border-gray-700">
          <h5 className="text-base font-bold text-gray-800 dark:text-gray-200">
            Thông báo & Cảnh báo
          </h5>
          <button
            onClick={toggleDropdown}
            className="flex items-center justify-center w-10 h-10 min-h-[40px] min-w-[40px] rounded-lg text-gray-500 transition dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
            aria-label="Đóng menu thông báo"
          >
            <svg
              className="fill-current"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M6.21967 7.28131C5.92678 6.98841 5.92678 6.51354 6.21967 6.22065C6.51256 5.92775 6.98744 5.92775 7.28033 6.22065L11.999 10.9393L16.7176 6.22078C17.0105 5.92789 17.4854 5.92788 17.7782 6.22078C18.0711 6.51367 18.0711 6.98855 17.7782 7.28144L13.0597 12L17.7782 16.7186C18.0711 17.0115 18.0711 17.4863 17.7782 17.7792C17.4854 18.0721 17.0105 18.0721 16.7176 17.7792L11.999 13.0607L7.28033 17.7794C6.98744 18.0722 6.51256 18.0722 6.21967 17.7794C5.92678 17.4865 5.92678 17.0116 6.21967 16.7187L10.9384 12L6.21967 7.28131Z"
                fill="currentColor"
              />
            </svg>
          </button>
        </div>
        <ul className="flex flex-col h-auto overflow-y-auto custom-scrollbar flex-1">
          {/* Notification 1: Dust Alert AI link */}
          <li>
            <DropdownItem
              tag="a"
              to="/staff/ai?siteId=BD-0237&tab=report"
              onItemClick={closeDropdown}
              className="flex gap-3 rounded-lg border-b border-gray-100 p-3 px-4 py-3 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-white/5 text-left w-full"
            >
              <span className="relative block w-10 h-10 rounded-full z-1 max-w-10 flex-shrink-0 bg-red-100 text-red-700 flex items-center justify-center font-bold">
                ️
              </span>
              <span className="block min-w-0">
                <span className="mb-1 block text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-bold text-gray-900 dark:text-white/90">
                    Cảnh báo bụi vượt ngưỡng (185 µg/m³)
                  </span>
                  <span> tại Chung cư Thanh Xuân Garden.</span>
                </span>
                <span className="text-[10px] font-bold text-accent-600 block mt-0.5">
                   Click để lập biên bản xử phạt AI ngay
                </span>
                <span className="flex items-center gap-1.5 text-gray-400 text-[10px] mt-1">
                  <span>Hệ thống IoT</span>
                  <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  <span>5 phút trước</span>
                </span>
              </span>
            </DropdownItem>
          </li>

          {/* Notification 2: Dust Alert AI link */}
          <li>
            <DropdownItem
              tag="a"
              to="/staff/ai?siteId=BD-0198&tab=report"
              onItemClick={closeDropdown}
              className="flex gap-3 rounded-lg border-b border-gray-100 p-3 px-4 py-3 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-white/5 text-left w-full"
            >
              <span className="relative block w-10 h-10 rounded-full z-1 max-w-10 flex-shrink-0 bg-red-100 text-red-700 flex items-center justify-center font-bold">
                ️
              </span>
              <span className="block min-w-0">
                <span className="mb-1 block text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-bold text-gray-900 dark:text-white/90">
                    Chỉ số bụi PM10 nguy hại (210 µg/m³)
                  </span>
                  <span> tại BV Bạch Mai – Khu C.</span>
                </span>
                <span className="text-[10px] font-bold text-accent-600 block mt-0.5">
                   Click để soạn văn bản xử lý ngay
                </span>
                <span className="flex items-center gap-1.5 text-gray-400 text-[10px] mt-1">
                  <span>Hệ thống IoT</span>
                  <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  <span>15 phút trước</span>
                </span>
              </span>
            </DropdownItem>
          </li>

          {/* Notification 3: Citizen Complaint link */}
          <li>
            <DropdownItem
              tag="a"
              to="/staff/cases?id=DG-2026-8911"
              onItemClick={closeDropdown}
              className="flex gap-3 rounded-lg border-b border-gray-100 p-3 px-4 py-3 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-white/5 text-left w-full"
            >
              <span className="relative block w-10 h-10 rounded-full z-1 max-w-10 flex-shrink-0 bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                
              </span>
              <span className="block min-w-0">
                <span className="mb-1 block text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-bold text-gray-900 dark:text-white/90">
                    Phản ánh mới: Bụi xi măng mù mịt
                  </span>
                  <span> ảnh hưởng trường học tại Công trình Metro C.</span>
                </span>
                <span className="text-[10px] font-bold text-amber-600 block mt-0.5">
                   Click để định vị và xử lý phản ánh
                </span>
                <span className="flex items-center gap-1.5 text-gray-400 text-[10px] mt-1">
                  <span>Cổng Dân Dựng</span>
                  <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  <span>1 giờ trước</span>
                </span>
              </span>
            </DropdownItem>
          </li>

          {/* Notification 4: Site detail link */}
          <li>
            <DropdownItem
              tag="a"
              to="/staff/sites?id=BD-0154"
              onItemClick={closeDropdown}
              className="flex gap-3 rounded-lg border-b border-gray-100 p-3 px-4 py-3 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-white/5 text-left w-full"
            >
              <span className="relative block w-10 h-10 rounded-full z-1 max-w-10 flex-shrink-0 bg-accent-100 text-accent-700 flex items-center justify-center font-bold">
                
              </span>
              <span className="block min-w-0">
                <span className="mb-1 block text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-bold text-gray-900 dark:text-white/90">
                    Cập nhật hồ sơ kiểm tra
                  </span>
                  <span> tại Tòa nhà văn phòng Kim Mã Tower.</span>
                </span>
                <span className="text-[10px] font-bold text-accent-600 block mt-0.5">
                   Click để xem hồ sơ và checklist chi tiết
                </span>
                <span className="flex items-center gap-1.5 text-gray-400 text-[10px] mt-1">
                  <span>Thanh tra Sở</span>
                  <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  <span>2 giờ trước</span>
                </span>
              </span>
            </DropdownItem>
          </li>
        </ul>
        <Link
          to="/staff/cases"
          onClick={closeDropdown}
          className="block px-4 py-2 mt-3 text-xs font-bold text-center text-accent-700 hover:text-accent-800 bg-cream-50 hover:bg-cream-100 border border-cream-200 rounded-lg transition-colors dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
        >
          Xem tất cả vụ việc & hạn xử lý
        </Link>
      </Dropdown>
    </div>
  );
}
