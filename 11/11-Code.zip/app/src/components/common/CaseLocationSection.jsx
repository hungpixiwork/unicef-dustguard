import React, { useState } from 'react';

/**
 * CaseLocationSection — Contextual Location & Mini Map Embed for Case Detail
 * Implements lightweight, 100% free Google Maps embed without API key billing.
 * Provides address breakdown, GPS coords, copy shortcut, and external Google Maps trigger.
 */
export default function CaseLocationSection({
  siteName = 'Công trình / Địa điểm',
  address = 'Hà Nội',
  ward = '',
  district = '',
  province = 'Hà Nội',
  lat = null,
  lng = null,
  className = ''
}) {
  const [copied, setCopied] = useState(false);

  // Determine query string for maps embed & link
  const hasCoords = lat !== null && lng !== null && !isNaN(Number(lat)) && !isNaN(Number(lng));
  const query = hasCoords
    ? `${lat},${lng}`
    : `${siteName ? `${siteName}, ` : ''}${address || ''}${ward ? `, Phường ${ward}` : ''}${district ? `, ${district}` : ''}${province ? `, ${province}` : ''}`.trim();

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  const embedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

  const copyText = hasCoords ? `${lat}, ${lng}` : `${address}${ward ? `, Phường ${ward}` : ''}${district ? `, ${district}` : ''}`;

  const handleCopy = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(copyText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className={`bg-white rounded-xl border border-cream-200 shadow-sm p-4 sm:p-5 flex flex-col gap-4 ${className}`}>
      {/* Header with Title & Quick Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-cream-100">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 border border-teal-200 flex items-center justify-center text-base shrink-0">
            
          </span>
          <div>
            <h3 className="text-sm sm:text-base font-black text-ink">
              Địa điểm & Vị trí Hiện trường
            </h3>
            <p className="text-[11px] text-ink-muted">
              Thông tin tọa độ và bản đồ định vị theo hồ sơ
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleCopy}
            className="px-2.5 py-1.5 rounded-lg border border-cream-300 bg-cream-50 hover:bg-cream-100 text-xs font-bold text-ink transition flex items-center gap-1.5 min-h-[36px]"
            title="Sao chép địa chỉ / tọa độ"
          >
            <span>{copied ? '' : ''}</span>
            <span>{copied ? 'Đã sao chép' : 'Sao chép'}</span>
          </button>

          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition flex items-center gap-1.5 min-h-[36px] shadow-xs"
          >
            <span>Mở Google Maps</span>
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
          </a>
        </div>
      </div>

      {/* Main Grid: Left info & Right Mini Map */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Location Details Breakdown */}
        <div className="lg:col-span-6 space-y-3">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-ink-muted block">
              Tên công trình / Địa điểm
            </span>
            <div className="text-sm sm:text-base font-black text-ink mt-0.5">
              {siteName}
            </div>
          </div>

          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-ink-muted block">
              Địa chỉ chi tiết
            </span>
            <div className="text-xs sm:text-sm text-ink-muted mt-0.5 leading-relaxed">
              {address}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {ward && (
              <div className="p-2.5 rounded-lg bg-cream-50 border border-cream-200">
                <span className="text-[10px] font-bold uppercase text-ink-muted block">Phường / Xã</span>
                <span className="text-xs font-black text-ink">{ward}</span>
              </div>
            )}
            {district && (
              <div className="p-2.5 rounded-lg bg-cream-50 border border-cream-200">
                <span className="text-[10px] font-bold uppercase text-ink-muted block">Quận / Huyện</span>
                <span className="text-xs font-black text-ink">{district}</span>
              </div>
            )}
          </div>

          {/* GPS Coordinates Badge */}
          {hasCoords ? (
            <div className="p-2.5 rounded-lg bg-teal-50/60 border border-teal-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-teal-800 block">Tọa độ GPS WGS84</span>
                <span className="text-xs font-mono font-black text-teal-900">
                  {Number(lat).toFixed(6)}° N, {Number(lng).toFixed(6)}° E
                </span>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full font-bold bg-teal-200 text-teal-800">
                Xác thực
              </span>
            </div>
          ) : (
            <div className="p-2.5 rounded-lg bg-cream-100/60 border border-cream-200 text-xs text-ink-muted">
               Định vị theo địa chỉ thực tế (Chưa gắn cảm biến GPS cố định)
            </div>
          )}
        </div>

        {/* Responsive Mini Map Embed (No API billing, zero JS bundle overhead) */}
        <div className="lg:col-span-6 w-full h-[220px] sm:h-[240px] rounded-xl overflow-hidden border border-cream-300 relative bg-cream-100 shadow-2xs">
          <iframe
            title={`Bản đồ vị trí ${siteName}`}
            src={embedUrl}
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full h-full"
          />
        </div>
      </div>
    </div>
  );
}

export { CaseLocationSection };
