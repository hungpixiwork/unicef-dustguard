import React from 'react';
import { Link, useNavigate } from "react-router-dom";

interface BreadcrumbProps {
  pageTitle: string;
  parentPath?: string;
  parentTitle?: string;
}

const PageBreadcrumb: React.FC<BreadcrumbProps> = ({ 
  pageTitle, 
  parentPath = "/staff", 
  parentTitle = "Bàn làm việc" 
}) => {
  const navigate = useNavigate();
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 mb-6 w-full">
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-ink-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-100 transition shadow-xs dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
          title="Quay lại trang trước"
        >
          <span>←</span> Quay lại
        </button>
        <h2 className="text-xl font-bold text-gray-800 dark:text-white/90">
          {pageTitle}
        </h2>
      </div>
      <nav>
        <ol className="flex items-center gap-1.5">
          <li>
            <Link
              className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-accent-600 dark:text-gray-400"
              to={parentPath}
            >
              {parentTitle}
              <svg
                className="stroke-current text-gray-400"
                width="17"
                height="16"
                viewBox="0 0 17 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M6.0765 12.667L10.2432 8.50033L6.0765 4.33366"
                  stroke="currentColor"
                  strokeWidth="1.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </Link>
          </li>
          <li className="text-sm font-semibold text-gray-800 dark:text-white/90">
            {pageTitle}
          </li>
        </ol>
      </nav>
    </div>
  );
};

export default PageBreadcrumb;
