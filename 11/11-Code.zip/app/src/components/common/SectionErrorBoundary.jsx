import React from 'react';

/**
 * DustGuard VN — Granular Section Error Boundary
 * Prevents a single crashed widget/section from taking down the entire dashboard/portal.
 * 
 * Rules:
 * 1. Production Mode: Shows clean civic error message without raw technical stack leaks.
 * 2. Development Mode: Shows expandable debug details.
 * 3. Supports retry callback (`onRetry`) or local state reset.
 */
export class SectionErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error(`[SectionErrorBoundary: ${this.props.sectionName || 'Widget'}] Uncaught Error:`, error);
    console.error('[SectionErrorBoundary] Component Stack:', errorInfo?.componentStack);
    this.setState({ errorInfo });
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (typeof this.props.onRetry === 'function') {
      this.props.onRetry();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return typeof this.props.fallback === 'function'
          ? this.props.fallback(this.state.error, this.handleReset)
          : this.props.fallback;
      }

      const isDev = Boolean(
        (typeof process !== 'undefined' && process.env?.NODE_ENV === 'development') ||
        (typeof import.meta !== 'undefined' && import.meta.env?.DEV)
      );

      const sectionTitle = this.props.sectionName || 'Khu vực dữ liệu này';

      return (
        <div className="rounded-2xl border border-cream-200 bg-white p-5 sm:p-6 shadow-xs my-2">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center text-lg shrink-0">
                ️
              </div>
              <div>
                <h3 className="text-sm font-bold text-ink-900">
                  Không thể tải nội dung: {sectionTitle}
                </h3>
                <p className="text-xs text-ink-600 mt-0.5 leading-relaxed">
                  Dữ liệu tạm thời không khả dụng hoặc gặp sự cố hiển thị. Vui lòng bấm thử lại để làm mới khu vực này.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={this.handleReset}
              className="px-3.5 py-2 bg-cream-100 hover:bg-cream-200 text-ink-900 text-xs font-bold rounded-xl border border-cream-300 transition cursor-pointer shrink-0"
            >
               Thử lại khu vực này
            </button>
          </div>

          {isDev && this.state.error && (
            <details className="mt-3 p-3 bg-red-50 text-left rounded-xl border border-red-200 text-[11px] font-mono text-red-900">
              <summary className="font-bold cursor-pointer hover:underline text-red-800">
                Chi tiết lỗi kỹ thuật (Chỉ hiện trong môi trường Development)
              </summary>
              <div className="mt-2 overflow-x-auto max-h-40">
                <p className="font-bold">{this.state.error.toString()}</p>
                {this.state.errorInfo?.componentStack && (
                  <pre className="text-[10px] mt-1 opacity-80 whitespace-pre-wrap">
                    {this.state.errorInfo.componentStack}
                  </pre>
                )}
              </div>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default SectionErrorBoundary;
