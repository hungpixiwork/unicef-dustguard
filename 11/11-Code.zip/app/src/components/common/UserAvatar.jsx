import React, { useState } from 'react';

/**
 * Utility to extract clean, uppercase initials from a full Vietnamese name.
 * Examples:
 * - "Lê Minh Tuấn" -> "LT"
 * - "Nguyễn Thị Mai" -> "NM"
 * - "Trần Nam" -> "TN"
 * - "Admin" -> "AD"
 */
export function getInitials(name) {
  if (!name || typeof name !== 'string') return 'DG';
  const cleanName = name.trim().replace(/\s+/g, ' ');
  if (!cleanName) return 'DG';
  
  const parts = cleanName.split(' ');
  if (parts.length === 1) {
    return parts[0].substring(0, Math.min(2, parts[0].length)).toUpperCase();
  }

  const surnameLetter = parts[0].charAt(0).toUpperCase();
  const givenNameLetter = parts[parts.length - 1].charAt(0).toUpperCase();
  return `${surnameLetter}${givenNameLetter}`;
}

const COLOR_PALETTES = [
  { bg: '#dbeafe', color: '#1d4ed8' }, // Blue
  { bg: '#dcfce7', color: '#15803d' }, // Green
  { bg: '#fef3c7', color: '#b45309' }, // Amber
  { bg: '#f3e8ff', color: '#7e22ce' }, // Purple
  { bg: '#fdecea', color: '#9f241f' }, // Seal Red
  { bg: '#e0f2fe', color: '#0369a1' }, // Sky
  { bg: '#eefaf8', color: '#0d6f64' }  // Teal
];

function getColorPalette(str) {
  if (!str) return COLOR_PALETTES[0];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % COLOR_PALETTES.length;
  return COLOR_PALETTES[index];
}

/**
 * Universal UserAvatar Component for DustGuard Civic Tech
 */
export default function UserAvatar({
  name = '',
  src = '',
  size = 36,
  className = '',
  alt = ''
}) {
  const [imageError, setImageError] = useState(false);
  const initials = getInitials(name);
  const palette = getColorPalette(name);

  const fontSize = Math.max(10, Math.floor(size * 0.38));

  if (src && !imageError) {
    return (
      <img
        src={src}
        alt={alt || name || 'User Avatar'}
        onError={() => setImageError(true)}
        className={`rounded-full object-cover shrink-0 border border-cream-200 shadow-2xs ${className}`}
        style={{ width: `${size}px`, height: `${size}px` }}
      />
    );
  }

  return (
    <div
      className={`rounded-full shrink-0 flex items-center justify-center font-black select-none border border-cream-200 shadow-2xs ${className}`}
      style={{
        width: `${size}px`,
        height: `${size}px`,
        backgroundColor: palette.bg,
        color: palette.color,
        fontSize: `${fontSize}px`
      }}
      title={name}
      aria-label={name || 'User Avatar'}
    >
      {initials}
    </div>
  );
}

export { UserAvatar };
