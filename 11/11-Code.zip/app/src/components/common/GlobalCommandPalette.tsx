import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Building2,
  FileText,
  AlertTriangle,
  Users,
  X,
  ArrowRight,
  Clock,
  ShieldCheck
} from 'lucide-react';
import { staffApi } from '../../lib/api/staff-api';

interface SearchResultItem {
  id: string;
  type: 'CASE' | 'SITE' | 'ALERT' | 'USER';
  title: string;
  subtitle: string;
  url: string;
  badge?: string;
}

export default function GlobalCommandPalette({
  isOpen,
  onClose
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setResults([]);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Real Search execution
  useEffect(() => {
    if (!query.trim()) {
      setResults([
        { id: 'c1', type: 'CASE', title: 'Hồ sơ CASE-2026-001', subtitle: 'Bụi phát tán công trình Landmark — Quá hạn xử lý', url: '/executive/cases?status=overdue', badge: 'Quá hạn' },
        { id: 's1', type: 'SITE', title: 'Công trình Landmark Plaza', subtitle: '123 Cầu Giấy, Mai Dịch, Hà Nội', url: '/staff/sites', badge: 'Nguy cơ cao' },
        { id: 'a1', type: 'ALERT', title: 'Cảnh báo #AL-203', subtitle: 'PM2.5 vượt ngưỡng 65 µg/m³ tại Mai Dịch', url: '/executive/heatmap', badge: 'Khẩn cấp' },
        { id: 'u1', type: 'USER', title: 'Cán bộ Nguyễn Văn An', subtitle: 'Đoàn Thanh tra Môi trường Khu vực 2', url: '/staff/profile', badge: 'Cán bộ' },
      ]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const q = query.toLowerCase();
        const cases = await staffApi.getCases().catch(() => []);
        const caseList = Array.isArray(cases) ? cases : (cases?.items || []);

        const matchedCases: SearchResultItem[] = caseList
          .filter(c => (c.code || c.id || '').toLowerCase().includes(q) || (c.siteName || c.title || '').toLowerCase().includes(q))
          .map(c => ({
            id: c.id,
            type: 'CASE',
            title: `Hồ sơ ${c.code || c.id}`,
            subtitle: `${c.siteName || c.title || 'Công trình'} — Trạng thái: ${c.status || 'NEW'}`,
            url: `/executive/cases?query=${encodeURIComponent(c.code || c.id)}`,
            badge: c.priority || 'Hồ sơ'
          }));

        setResults(matchedCases);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-ink-900/60 p-4 sm:p-6 md:p-20 flex items-start justify-center animate-in fade-in duration-100">
      <div
        className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-cream-300 overflow-hidden flex flex-col justify-between animate-in zoom-in-95 duration-100"
        role="dialog"
        aria-modal="true"
      >
        {/* Search Bar Input */}
        <div className="p-4 border-b border-cream-200 flex items-center gap-3 bg-cream-50/50">
          <Search className="w-5 h-5 text-red-700 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm theo mã hồ sơ, tên công trình, địa chỉ, cán bộ..."
            className="w-full bg-transparent text-sm sm:text-base font-medium text-ink-900 focus:outline-none placeholder:text-ink-400"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1 rounded-lg text-ink-400 hover:text-ink-700 hover:bg-cream-100 transition"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono font-bold text-red-700 bg-red-50 rounded border border-red-200">
            ESC
          </span>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-cream-100">
          {loading ? (
            <div className="p-8 text-center text-xs font-bold text-ink-400">
              Đang tìm kiếm dữ liệu...
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-ink-400">
              <Search className="w-8 h-8 mx-auto text-ink-300 mb-1" />
              <p className="text-xs font-bold text-ink-700">Không tìm thấy kết quả phù hợp</p>
              <p className="text-[11px] text-ink-400">Thử tìm với từ khóa hoặc mã hồ sơ khác.</p>
            </div>
          ) : (
            results.map((res) => (
              <div
                key={res.id}
                onClick={() => {
                  onClose();
                  navigate(res.url);
                }}
                className="p-3 rounded-xl hover:bg-red-50/50 transition flex items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-cream-100 border border-cream-200 flex items-center justify-center text-ink-600 shrink-0 group-hover:bg-red-50 group-hover:text-red-700 group-hover:border-red-200 transition">
                    {res.type === 'CASE' && <FileText className="w-4 h-4" />}
                    {res.type === 'SITE' && <Building2 className="w-4 h-4" />}
                    {res.type === 'ALERT' && <AlertTriangle className="w-4 h-4" />}
                    {res.type === 'USER' && <Users className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-ink-900 group-hover:text-red-800 transition truncate">
                        {res.title}
                      </span>
                      {res.badge && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-black uppercase bg-red-50 text-red-700 border border-red-200">
                          {res.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-ink-500 truncate">{res.subtitle}</p>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-ink-300 group-hover:text-red-700 transition shrink-0" />
              </div>
            ))
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-3 bg-cream-50 border-t border-cream-200 text-[11px] text-ink-500 font-medium flex items-center justify-between">
          <span className="flex items-center gap-2">
            <span className="font-bold text-red-700">Mẹo:</span> Gõ <code>CASE-</code> để tìm nhanh mã hồ sơ
          </span>
          <span className="text-[10px] text-ink-400">DustGuard Real SSOT Search</span>
        </div>
      </div>
    </div>
  );
}
