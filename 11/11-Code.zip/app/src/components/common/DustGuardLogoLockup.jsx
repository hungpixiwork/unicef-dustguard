import React from 'react';
import { Link } from 'react-router-dom';

/**
 * DustGuardLogoLockup — Standard Brand Header / Logo Component
 * Combines the official DustGuard shield mark with responsive typography and badge.
 */
export function DustGuardLogoLockup({
  to = '/',
  showTagline = true,
  tagline = 'GIÁM SÁT BỤI · HÀNH ĐỘNG · MINH BẠCH',
  size = 'md', // 'sm' | 'md' | 'lg'
  className = '',
}) {
  const sizeMap = {
    sm: { shieldW: 24, shieldH: 29, textClass: 'text-sm', tagClass: 'text-[9px]' },
    md: { shieldW: 32, shieldH: 38, textClass: 'text-base sm:text-lg', tagClass: 'text-[10px]' },
    lg: { shieldW: 42, shieldH: 50, textClass: 'text-xl sm:text-2xl', tagClass: 'text-xs' },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  const content = (
    <div className={`flex items-center gap-2.5 shrink-0 ${className}`.trim()}>
      <img
        src="/assets/landing/brand/dustguard-shield-logo.webp"
        alt="DustGuard VN Shield"
        width={currentSize.shieldW}
        height={currentSize.shieldH}
        className="shrink-0 object-contain drop-shadow-xs"
      />
      <div className="flex flex-col">
        <span className={`font-black tracking-tight text-ink-900 leading-tight whitespace-nowrap ${currentSize.textClass}`}>
          DustGuard <b className="text-seal-600 font-black">VN</b>
        </span>
        {showTagline && tagline && (
          <span className={`font-bold text-seal-700 tracking-wider uppercase whitespace-nowrap ${currentSize.tagClass}`}>
            {tagline}
          </span>
        )}
      </div>
    </div>
  );

  if (to) {
    return (
      <Link to={to} className="inline-flex items-center no-underline hover:opacity-90 transition-opacity" aria-label="DustGuard VN">
        {content}
      </Link>
    );
  }

  return content;
}

export default DustGuardLogoLockup;
