import React from 'react';

/**
 * UnifiedDataTable component inspired by Sao Sang UX
 * Universal data table for DustGuard: Search, Filter chips, Row clicks, Direct Actions, Mobile Responsive
 */
export default function UnifiedDataTable({
  columns = [],
  data = [],
  loading = false,
  emptyText = 'Không tìm thấy dữ liệu phù hợp',
  emptySubtext = 'Hãy thử đổi từ khóa tìm kiếm hoặc bỏ bớt bộ lọc',
  searchValue = '',
  onSearchChange,
  searchPlaceholder = 'Tìm kiếm...',
  filters = [],
  activeFilter = 'all',
  onFilterChange,
  onRowClick,
  actions,
  pagination,
  className = ''
}) {
  return (
    <div className={`bg-white rounded-xl border border-cream-200 shadow-sm overflow-hidden flex flex-col ${className}`}>
      {/* TOOLBAR: Search & Filters */}
      {(onSearchChange || filters.length > 0 || actions) && (
        <div className="p-3 sm:p-4 border-b border-cream-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-cream-50/50">
          {/* Filter Chips / Tabs */}
          {filters.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 no-scrollbar shrink-0">
              {filters.map((f) => {
                const isActive = activeFilter === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => onFilterChange && onFilterChange(f.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 min-h-[36px] ${
                      isActive
                        ? 'bg-teal-700 text-white shadow-sm'
                        : 'bg-white text-ink-muted hover:bg-cream-100 hover:text-ink border border-cream-200'
                    }`}
                  >
                    <span>{f.label}</span>
                    {f.count !== undefined && (
                      <span
                        className={`text-[11px] px-1.5 py-0.2 rounded-full font-mono font-black ${
                          isActive ? 'bg-teal-900/40 text-white' : 'bg-cream-200 text-ink-muted'
                        }`}
                      >
                        {f.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Search Input & Custom Actions */}
          <div className="flex items-center gap-2.5 flex-1 justify-end">
            {onSearchChange && (
              <div className="relative w-full sm:max-w-xs">
                <input
                  type="text"
                  value={searchValue}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-cream-300 rounded-lg text-ink placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent min-h-[40px]"
                />
                <svg
                  className="w-4 h-4 text-ink-muted/70 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            )}
            {actions}
          </div>
        </div>
      )}

      {/* TABLE BODY */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[600px]">
          <thead>
            <tr className="border-b border-cream-200 bg-cream-100/60">
              {columns.map((col, idx) => (
                <th
                  key={idx}
                  className={`py-3 px-3 sm:px-4 text-[11px] sm:text-xs font-black uppercase tracking-wider text-ink-muted whitespace-nowrap ${
                    col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                  } ${col.headerClassName || ''}`}
                  style={col.style}
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-cream-100 text-xs sm:text-sm text-ink">
            {loading ? (
              <tr>
                <td colSpan={columns.length} className="py-12 text-center">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <div className="w-8 h-8 rounded-full border-3 border-teal-200 border-t-teal-700 animate-spin" />
                    <span className="text-xs font-semibold text-ink-muted">Đang tải dữ liệu...</span>
                  </div>
                </td>
              </tr>
            ) : data.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="py-12 text-center">
                  <div className="flex flex-col items-center justify-center max-w-sm mx-auto px-4">
                    <div className="w-12 h-12 rounded-full bg-cream-100 text-ink-muted flex items-center justify-center mb-3">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                      </svg>
                    </div>
                    <p className="text-sm font-bold text-ink">{emptyText}</p>
                    <p className="text-xs text-ink-muted mt-1">{emptySubtext}</p>
                  </div>
                </td>
              </tr>
            ) : (
              data.map((row, rowIdx) => (
                <tr
                  key={row.id || rowIdx}
                  onClick={() => onRowClick && onRowClick(row)}
                  className={`transition-colors ${
                    onRowClick ? 'cursor-pointer hover:bg-cream-50' : 'hover:bg-cream-50/50'
                  }`}
                >
                  {columns.map((col, colIdx) => (
                    <td
                      key={colIdx}
                      className={`py-3.5 px-3 sm:px-4 align-middle ${
                        col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                      } ${col.cellClassName || ''}`}
                      style={col.style}
                    >
                      {col.cell ? col.cell(row, rowIdx) : row[col.accessor]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* PAGINATION / FOOTER */}
      {pagination && (
        <div className="p-3 sm:p-4 border-t border-cream-200 bg-cream-50/30 flex items-center justify-between text-xs text-ink-muted">
          {pagination}
        </div>
      )}
    </div>
  );
}

export { UnifiedDataTable };
