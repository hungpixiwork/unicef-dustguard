import React from 'react';

/**
 * Universal EmptyState Component for Tables and Lists
 * Provides illustration icon, title, description, and optional action button.
 */
export default function EmptyState({
  icon = '',
  title = 'Chưa có dữ liệu hiển thị',
  description = 'Chưa có bản ghi nào phù hợp với điều kiện tìm kiếm hoặc bộ lọc.',
  actionLabel = '',
  onAction = null,
  className = ''
}) {
  return (
    <div className={`p-8 sm:p-12 text-center rounded-2xl border border-dashed border-cream-300 bg-cream-50/50 flex flex-col items-center justify-center gap-3 ${className}`}>
      <span className="text-4xl select-none" role="img" aria-label="Empty State">
        {icon}
      </span>

      <div className="max-w-md space-y-1">
        <h4 className="text-sm sm:text-base font-black text-ink">
          {title}
        </h4>
        <p className="text-xs sm:text-sm text-ink-muted leading-relaxed">
          {description}
        </p>
      </div>

      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-2 px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold transition shadow-xs min-h-[38px] flex items-center gap-1.5"
        >
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
}

export { EmptyState };
