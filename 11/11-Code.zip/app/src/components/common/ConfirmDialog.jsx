import React from 'react';

/**
 * Universal ConfirmDialog Component for Critical Actions
 * Supports 3 severity variants: 'danger' (seal red), 'warning' (amber), 'info' (teal).
 */
export default function ConfirmDialog({
  isOpen = false,
  title = 'Xác nhận hành động',
  message = '',
  confirmText = 'Xác nhận',
  cancelText = 'Hủy bỏ',
  variant = 'danger',
  isLoading = false,
  onConfirm,
  onCancel
}) {
  if (!isOpen) return null;

  const getVariantStyles = () => {
    switch (variant) {
      case 'warning':
        return {
          icon: '️',
          btnBg: 'bg-amber-600 hover:bg-amber-700 text-white',
          headerColor: 'text-amber-800'
        };
      case 'info':
        return {
          icon: 'ℹ️',
          btnBg: 'bg-teal-700 hover:bg-teal-800 text-white',
          headerColor: 'text-teal-900'
        };
      case 'danger':
      default:
        return {
          icon: '',
          btnBg: 'bg-seal-600 hover:bg-seal-700 text-white',
          headerColor: 'text-seal-800'
        };
    }
  };

  const v = getVariantStyles();

  return (
    <div
      className="fixed inset-0 bg-ink-900/60 z-[999999] flex items-center justify-center p-4"
      onClick={!isLoading ? onCancel : undefined}
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-dialog-title"
    >
      <div
        className="bg-white rounded-2xl border border-cream-200 shadow-2xl w-full max-w-md p-6 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-cream-100">
          <div className="flex items-center gap-2.5">
            <span className="text-xl shrink-0">{v.icon}</span>
            <h3 id="confirm-dialog-title" className={`text-base font-black ${v.headerColor}`}>
              {title}
            </h3>
          </div>
          {!isLoading && (
            <button
              type="button"
              onClick={onCancel}
              className="w-11 h-11 min-w-[44px] min-h-[44px] rounded-xl hover:bg-cream-100 text-ink-muted hover:text-ink flex items-center justify-center text-lg font-bold transition cursor-pointer"
              aria-label="Đóng hộp thoại"
            >
              ✕
            </button>
          )}
        </div>

        <div className="text-xs sm:text-sm text-ink-700 leading-relaxed">
          {message}
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-cream-100">
          <button
            type="button"
            onClick={onCancel}
            disabled={isLoading}
            className="px-4 py-2.5 rounded-xl border border-cream-300 bg-white hover:bg-cream-50 text-xs sm:text-sm font-bold text-ink transition min-h-[44px] cursor-pointer disabled:opacity-50"
          >
            {cancelText}
          </button>

          <button
            type="button"
            onClick={onConfirm}
            disabled={isLoading}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-black transition flex items-center gap-2 min-h-[44px] cursor-pointer shadow-sm disabled:opacity-50 ${v.btnBg}`}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Đang xử lý...</span>
              </>
            ) : (
              <span>{confirmText}</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export { ConfirmDialog };
