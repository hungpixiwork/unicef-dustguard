import React from 'react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[Contractor/App ErrorBoundary] Uncaught Component Error:', error);
    console.error('[Contractor/App ErrorBoundary] Component Stack:', errorInfo?.componentStack);
    this.setState({ errorInfo });
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    window.location.reload();
  };

  handleGoHome = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    const isContractor = window.location.pathname.startsWith('/contractor');
    window.location.href = isContractor ? '/contractor' : '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[420px] bg-cream-50 flex items-center justify-center p-6 text-center">
          <div className="bg-white border border-cream-300 rounded-3xl p-6 sm:p-8 max-w-md shadow-card space-y-4">
            <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto border border-amber-200 text-amber-700 text-2xl shadow-3xs">
              ️
            </div>
            
            <div className="space-y-1.5">
              <h2 className="text-lg font-black text-ink-900">Không thể tải nội dung</h2>
              <p className="text-xs text-ink-600 font-medium leading-relaxed">
                Hệ thống tạm thời không thể tải dữ liệu cho trang này. Vui lòng bấm [Tải lại trang] hoặc kiểm tra kết nối mạng của bạn.
              </p>
            </div>

            {Boolean((typeof process !== 'undefined' && process.env?.NODE_ENV === 'development') || (typeof import.meta !== 'undefined' && import.meta.env?.DEV)) && this.state.error && (
              <details className="p-3 bg-red-50 text-left rounded-xl border border-red-200 text-[11px] font-mono text-red-900 max-h-36 overflow-y-auto">
                <summary className="font-bold cursor-pointer hover:underline text-red-800">
                  Chi tiết lỗi kỹ thuật (Development mode)
                </summary>
                <div className="mt-1.5 whitespace-pre-wrap break-words">
                  <strong>{this.state.error.toString()}</strong>
                </div>
              </details>
            )}

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={this.handleReset}
                className="px-4 py-2.5 bg-seal-600 hover:bg-seal-700 text-white text-xs font-extrabold rounded-xl shadow-xs transition transform active:scale-95 cursor-pointer"
              >
                Tải lại trang
              </button>
              <button
                type="button"
                onClick={this.handleGoHome}
                className="px-4 py-2.5 bg-cream-100 hover:bg-cream-200 text-ink-800 text-xs font-bold rounded-xl border border-cream-300 transition cursor-pointer"
              >
                Về Trang chủ
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export { SectionErrorBoundary } from './SectionErrorBoundary.jsx';
export default ErrorBoundary;
