import React from 'react';

/**
 * Standard PageHeader component inspired by Sao Sang UX
 * Clean typography, subtitle, and right-aligned action buttons
 */
export default function PageHeader({ title, subtitle, description, badge, actions, className = '' }) {
  const desc = subtitle || description;
  return (
    <div className={`flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 pb-4 border-b border-cream-200 ${className}`}>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2.5 flex-wrap">
          <h1 className="text-xl sm:text-2xl font-black text-ink tracking-tight font-display">
            {title}
          </h1>
          {badge && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
              {badge}
            </span>
          )}
        </div>
        {desc && (
          <p className="text-xs sm:text-sm text-ink-muted mt-1 leading-relaxed">
            {desc}
          </p>
        )}
      </div>
      {actions && (
        <div className="flex items-center gap-2 sm:gap-3 shrink-0 flex-wrap">
          {actions}
        </div>
      )}
    </div>
  );
}

export { PageHeader };
