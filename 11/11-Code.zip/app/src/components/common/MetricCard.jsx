import React from 'react';

/**
 * Standard MetricCard component inspired by Sao Sang UX
 * Clear visual hierarchy, solid colored left border, icon background, no glassmorphism
 */
export default function MetricCard({
  title,
  value,
  subtitle,
  icon: Icon,
  tone = 'teal',
  trend,
  onClick,
  active = false,
  className = ''
}) {
  const toneMap = {
    teal: {
      border: 'border-l-4 border-l-[#0d6f64]',
      iconBg: 'bg-[#e6f4f1] text-[#0d6f64]',
      badgeBg: 'bg-[#e6f4f1] text-[#0d6f64]'
    },
    seal: {
      border: 'border-l-4 border-l-[#9f241f]',
      iconBg: 'bg-[#fbeae9] text-[#9f241f]',
      badgeBg: 'bg-[#fbeae9] text-[#9f241f]'
    },
    amber: {
      border: 'border-l-4 border-l-[#d97706]',
      iconBg: 'bg-[#fef3c7] text-[#d97706]',
      badgeBg: 'bg-[#fef3c7] text-[#d97706]'
    },
    blue: {
      border: 'border-l-4 border-l-[#2563eb]',
      iconBg: 'bg-[#eff6ff] text-[#2563eb]',
      badgeBg: 'bg-[#eff6ff] text-[#2563eb]'
    },
    purple: {
      border: 'border-l-4 border-l-[#7c3aed]',
      iconBg: 'bg-[#f3e8ff] text-[#7c3aed]',
      badgeBg: 'bg-[#f3e8ff] text-[#7c3aed]'
    },
    neutral: {
      border: 'border-l-4 border-l-[#64748b]',
      iconBg: 'bg-[#f1f5f9] text-[#475569]',
      badgeBg: 'bg-[#f1f5f9] text-[#475569]'
    }
  };

  const style = toneMap[tone] || toneMap.teal;

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl p-4 sm:p-5 border border-cream-200 shadow-sm ${style.border} ${
        onClick ? 'cursor-pointer hover:shadow-md transition-all active:scale-[0.99]' : ''
      } ${active ? 'ring-2 ring-teal-600 bg-cream-50' : ''} ${className}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <span className="text-xs sm:text-sm font-semibold text-ink-muted uppercase tracking-wider block truncate">
            {title}
          </span>
          <div className="mt-1.5 flex items-baseline gap-2 flex-wrap">
            <span className="text-2xl sm:text-3xl font-black text-ink font-mono tracking-tight">
              {value}
            </span>
            {trend && (
              <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${style.badgeBg}`}>
                {trend}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-ink-muted mt-1 truncate">
              {subtitle}
            </p>
          )}
        </div>
        {Icon && (
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${style.iconBg}`}>
            {typeof Icon === 'function' ? <Icon className="w-5 h-5" /> : Icon}
          </div>
        )}
      </div>
    </div>
  );
}

export { MetricCard };
