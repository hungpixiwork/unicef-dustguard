import React from 'react';

/**
 * Standard StatusBadge component inspired by Sao Sang UX
 * Unified semantic badge for cases, inspections, alerts, and operational states
 */
export default function StatusBadge({ status, text, tone, className = '', size = 'md' }) {
  const normalized = (status || '').toString().toLowerCase().trim();

  // Determine tone based on status keywords if not provided
  let computedTone = tone;
  if (!computedTone) {
    if (['completed', 'resolved', 'closed', 'đã xử lý', 'đã hoàn tất', 'đã duyệt', 'hợp lệ', 'xong'].includes(normalized)) {
      computedTone = 'success';
    } else if (['in_progress', 'processing', 'investigating', 'on_site', 'đang xử lý', 'đang kiểm tra', 'thực địa'].includes(normalized)) {
      computedTone = 'blue';
    } else if (['pending', 'screening', 'preparing', 'mới', 'chờ xử lý', 'tiếp nhận', 'chờ duyệt'].includes(normalized)) {
      computedTone = 'amber';
    } else if (['urgent', 'high', 'critical', 'overdue', 'khẩn cấp', 'quá hạn', 'nghiêm trọng', 'vi phạm'].includes(normalized)) {
      computedTone = 'danger';
    } else if (['remediation', 'appraising', 'chờ khắc phục', 'đang khắc phục', 'giải trình'].includes(normalized)) {
      computedTone = 'purple';
    } else {
      computedTone = 'neutral';
    }
  }

  const toneStyles = {
    success: 'bg-[#dcfce7] text-[#15803d] border-[#bbf7d0]',
    blue: 'bg-[#dbeafe] text-[#1d4ed8] border-[#bfdbfe]',
    amber: 'bg-[#fef3c7] text-[#b45309] border-[#fde68a]',
    danger: 'bg-[#fee2e2] text-[#b91c1c] border-[#fecaca]',
    purple: 'bg-[#f3e8ff] text-[#6b21a8] border-[#e9d5ff]',
    neutral: 'bg-[#f1f5f9] text-[#475569] border-[#e2e8f0]'
  };

  const sizeStyles = {
    sm: 'text-[11px] px-1.5 py-0.5 font-semibold',
    md: 'text-xs px-2.5 py-1 font-bold',
    lg: 'text-sm px-3 py-1.5 font-bold'
  };

  const currentStyle = toneStyles[computedTone] || toneStyles.neutral;
  const currentSize = sizeStyles[size] || sizeStyles.md;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border whitespace-nowrap ${currentStyle} ${currentSize} ${className}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-75 shrink-0" />
      <span>{text || status}</span>
    </span>
  );
}

export { StatusBadge };
