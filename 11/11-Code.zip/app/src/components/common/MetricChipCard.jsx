import React from 'react';

/**
 * MetricChipCard — UI Metric Chip Component
 * Based on the Sheet 1 UI specification.
 * Renders a crisp, interactive metric card with icon, label, primary value, and status pill.
 */
export function MetricChipCard({
  icon,
  iconSrc = null,
  label = 'Chỉ số hoạt động',
  value = '98.5%',
  badgeText = 'Chuẩn hóa',
  badgeVariant = 'success', // 'success' | 'warning' | 'info' | 'neutral'
  onClick,
  className = '',
}) {
  const badgeStyles = {
    success: 'bg-teal-50 text-teal-700 border-teal-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    info: 'bg-blue-50 text-blue-700 border-blue-200',
    neutral: 'bg-ink-50 text-ink-700 border-ink-200',
  };

  const currentBadgeStyle = badgeStyles[badgeVariant] || badgeStyles.success;

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-3 px-3.5 py-2.5 bg-white border border-ink-900/10 rounded-xl shadow-xs hover:border-seal-500/30 hover:shadow-sm transition-all text-left ${onClick ? 'cursor-pointer' : ''} ${className}`.trim()}
    >
      {/* Icon Area */}
      <div className="w-9 h-9 rounded-lg bg-cream-50 border border-seal-500/15 flex items-center justify-center shrink-0">
        {icon ? (
          icon
        ) : iconSrc ? (
          <img
            src={iconSrc}
            alt=""
            width="20"
            height="20"
            className="object-contain"
          />
        ) : (
          <svg className="w-5 h-5 text-teal-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            <polyline points="9 12 11 14 15 10" />
          </svg>
        )}
      </div>

      {/* Metric Content */}
      <div className="flex flex-col min-w-0">
        <span className="text-[11px] font-semibold text-ink-500 uppercase tracking-wider truncate">
          {label}
        </span>
        <span className="text-base font-black text-ink-900 tracking-tight leading-tight">
          {value}
        </span>
      </div>

      {/* Status Pill Badge */}
      {badgeText && (
        <span className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full border whitespace-nowrap ${currentBadgeStyle}`}>
          {badgeText}
        </span>
      )}
    </div>
  );
}

export default MetricChipCard;
