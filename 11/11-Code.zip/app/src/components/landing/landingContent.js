/**
 * DustGuard VN — Landing Page Content SSOT
 * Comprehensive bilingual content (Vietnamese / English) mapped directly to DUSTGUARD VN Specification.
 * Clean, credible, scientific civic-tech tone with zero-glassmorphism, high contrast and actionable clarity.
 */

export const landingContent = {
  nav: {
    brandTag: {
      vi: 'GIÁM SÁT BỤI ĐÔ THỊ',
      en: 'URBAN DUST MONITORING',
    },
    links: [
      { id: 'map', href: '/map', isRoute: true, label: { vi: 'Bản đồ', en: 'Live Map' } },
      { id: 'problem', href: '#problem', label: { vi: 'Vấn đề', en: 'The Gap' } },
      { id: 'process', href: '#process', label: { vi: 'Giải pháp', en: 'Solution' } },
      { id: 'accountability', href: '#accountability', label: { vi: 'Quy trình', en: 'Process' } },
      { id: 'pilot', href: '#pilot', label: { vi: 'Pilot', en: 'Pilot' } },
    ],
    cta: {
      report: { vi: 'Phản ánh', en: 'Report' },
      tryNow: { vi: 'Xem demo', en: 'Live Demo' },
      staff: { vi: 'Cán bộ', en: 'Staff' },
      map: { vi: 'Bản đồ', en: 'Live Map' },
    },
  },

  hero: {
    eyebrow: {
      vi: 'GIÁM SÁT BỤI ĐÔ THỊ',
      en: 'URBAN DUST MONITORING',
    },
    headline: {
      vi: 'Phát hiện bụi.',
      en: 'Detect dust.',
    },
    redAccent: {
      vi: 'Theo dõi đến khi xử lý.',
      en: 'Track until resolved.',
    },
    subhead: {
      vi: 'Ghi nhận hiện trường, chuyển xử lý và theo dõi kết quả trên một hệ thống.',
      en: 'Record field issues, dispatch mitigation, and track results on a unified system.',
    },
    actions: {
      reportNow: { vi: 'Phản ánh', en: 'Report' },
      exploreDemo: { vi: 'Xem demo', en: 'Live Demo' },
      howItWorks: { vi: 'Xem cách hoạt động', en: 'How it Works' },
      openMap: { vi: 'Bản đồ', en: 'Live Map' },
    },
    previewCard: {
      badge: { vi: 'HỒ SƠ THEO DÕI', en: 'ACTIVE CASE' },
      caseId: '#DG-2026-0842',
      location: { vi: 'Vành đai 3 · Dịch Vọng Hậu', en: 'Ring Road 3 · Dich Vong Hau' },
      handoverBadge: { vi: 'Đã chuyển xử lý', en: 'Dispatched' },
      assigneeLabel: { vi: 'Phụ trách', en: 'Assignee' },
      assigneeValue: { vi: 'Đội phản ứng nhanh', en: 'Rapid Response Team' },
      statusValue: { vi: 'Đang xử lý', en: 'In Progress' },
      riskTier: { vi: 'Cao', en: 'High' },
      footerNote: { vi: 'Đã chuyển đơn vị tiếp nhận', en: 'Dispatched to Municipal Unit' },
      steps: [
        { num: '01', title: { vi: 'Phát hiện', en: 'Detect' }, done: true },
        { num: '02', title: { vi: 'Xác minh', en: 'Verify' }, done: true },
        { num: '03', title: { vi: 'Xử lý', en: 'Dispatch' }, done: true },
        { num: '04', title: { vi: 'Khắc phục', en: 'Mitigate' }, active: true },
        { num: '05', title: { vi: 'Tái kiểm', en: 'Recheck' }, done: false },
      ],
      before: {
        stage: { vi: 'Hiện trường', en: 'Site Observation' },
        time: '08:30 · 31/08',
        riskScore: '85/100',
        riskTier: { vi: 'Cao', en: 'High' },
        dustMetricLabel: { vi: 'PM2.5 ghi nhận', en: 'PM2.5 Recorded' },
        dustMetricValue: '142 µg/m³',
        evidenceValue: { vi: 'Xe tải chở đất không phủ bạt, phát tán bụi trên đường gom', en: 'Uncovered earth trucks spreading dust plumes along service road' },
        statusValue: { vi: 'Đang xử lý', en: 'In Progress' },
      },
      after: {
        stage: { vi: 'Sau xử lý', en: 'After Mitigation' },
        time: '10:15 · 01/09',
        riskScore: '18/100',
        riskTier: { vi: 'An toàn', en: 'Safe' },
        dustMetricLabel: { vi: 'PM2.5 ghi nhận', en: 'PM2.5 Recorded' },
        dustMetricValue: '28 µg/m³',
        evidenceValue: { vi: 'Đã căng bạt che chắn toàn tuyến & tưới nước rửa đường', en: 'Full dust netting erected & road washed regularly' },
        statusValue: { vi: 'Đã khắc phục', en: 'Resolved' },
      },
    },
    proofPoints: [
      {
        value: '0–100',
        label: { vi: 'Thang ưu tiên hồ sơ', en: 'Priority Index' },
        desc: {
          vi: 'Hỗ trợ người vận hành xác định việc cần xem trước — không phải kết luận vi phạm pháp lý.',
          en: 'Operational triage index to prioritize critical cases — not a legal conclusion.',
        },
        icon: 'chart',
      },
      {
        value: '24–48h',
        label: { vi: 'Chu kỳ tái kiểm hiện trường', en: 'Reinspection Cycle' },
        desc: {
          vi: 'Quay lại đối chứng để đảm bảo công trình thực sự khắc phục, không tái diễn.',
          en: 'Structured verification window to confirm site mitigation was actually performed.',
        },
        icon: 'clock',
      },
      {
        value: '≈ 500.000đ',
        label: { vi: 'Node đo bụi mở prototype', en: 'Open IoT Sensor Node' },
        desc: {
          vi: 'Chi phí linh kiện tham chiếu cho trạm đo quang học mở. Chi phí có thể thay đổi tùy linh kiện thực tế.',
          en: 'Reference BOM cost for open optical particulate sensor node. Costs may vary with component sourcing.',
        },
        icon: 'sensor',
      },
    ],
  },

  problem: {
    eyebrow: {
      vi: 'KHOẢNG TRỐNG THỰC TẾ',
      en: 'THE CIVIC TECH GAP',
    },
    headline: {
      vi: 'Một phản ánh chỉ có giá trị',
      en: 'A report is only meaningful',
    },
    redAccent: {
      vi: 'khi biết điều gì xảy ra sau đó.',
      en: 'when you know what happens next.',
    },
    subhead: {
      vi: 'Hiện nay, thông tin về một vấn đề bụi đô thị có thể nằm rải rác ở rất nhiều nơi nhưng thiếu sợi dây liên kết trách nhiệm.',
      en: 'Today, urban dust data is scattered across siloed tools without unified accountability.',
    },
    scatteredSources: [
      { num: '01', title: { vi: 'Ảnh hiện trường', en: 'Site Photos' }, desc: { vi: 'Chụp trên điện thoại cá nhân', en: 'Stored on personal phones' }, icon: 'camera' },
      { num: '02', title: { vi: 'Phản ánh người dân', en: 'Citizen Complaints' }, desc: { vi: 'Gửi qua nhóm chat, mạng xã hội', en: 'Sent via social chats & apps' }, icon: 'user' },
      { num: '03', title: { vi: 'Vị trí công trình', en: 'Project Location' }, desc: { vi: 'Bản đồ quy hoạch riêng rẽ', en: 'Isolated planning maps' }, icon: 'mapPin' },
      { num: '04', title: { vi: 'Dữ liệu cảm biến', en: 'Sensor Feeds' }, desc: { vi: 'Biểu đồ PM2.5 không gắn hồ sơ', en: 'Raw PM2.5 charts without context' }, icon: 'sensor' },
      { num: '05', title: { vi: 'Checklist kiểm tra', en: 'Site Checklists' }, desc: { vi: 'Giấy tờ biên bản hiện trường rời rạc', en: 'Loose paper field forms' }, icon: 'list' },
      { num: '06', title: { vi: 'Lịch sử trao đổi', en: 'Chat History' }, desc: { vi: 'Tin nhắn trôi theo thời gian', en: 'Lost in endless message threads' }, icon: 'refresh' },
    ],
    fourQuestions: [
      { id: 'q1', num: '01', q: { vi: 'Việc nào cần xem trước?', en: 'Which case needs attention first?' } },
      { id: 'q2', num: '02', q: { vi: 'Ai đang phụ trách?', en: 'Who is accountable?' } },
      { id: 'q3', num: '03', q: { vi: 'Đã xử lý đến đâu?', en: 'What is the current status?' } },
      { id: 'q4', num: '04', q: { vi: 'Hiện trường thực sự đã tốt hơn chưa?', en: 'Has the site actually improved?' } },
    ],
    solutionStatement: {
      vi: 'DustGuard tập hợp những thông tin này thành một hồ sơ có thể theo dõi từ đầu đến cuối.',
      en: 'DustGuard consolidates this fragmented data into a single case dossier tracked end-to-end.',
    },
  },

  solution: {
    eyebrow: {
      vi: 'QUY TRÌNH XỬ LÝ 4 BƯỚC',
      en: '4-STEP RESOLUTION JOURNEY',
    },
    headline: {
      vi: 'Một vấn đề. Một hồ sơ.',
      en: 'One Issue. One Dossier.',
    },
    redAccent: {
      vi: 'Một hành trình xử lý.',
      en: 'One Accountable Journey.',
    },
    subhead: {
      vi: 'Quy trình chuẩn hóa từ lúc ghi nhận ban đầu đến khi tạo Case có phân công và bằng chứng đối chứng rõ ràng.',
      en: 'A structured pipeline from initial field observation to an assigned case with verifiable evidence.',
    },
    steps: [
      {
        num: '01',
        tag: { vi: 'BƯỚC 1', en: 'STEP 1' },
        title: { vi: 'GHI NHẬN', en: 'RECORD' },
        headline: { vi: 'Ghi nhận vấn đề ngay tại hiện trường', en: 'Record the issue right on-site' },
        desc: {
          vi: 'Người dân hoặc tình nguyện viên có thể gửi ảnh hiện trường, vị trí GPS, mô tả tình trạng, thời gian ghi nhận, tên công trình và dữ liệu PM nếu khu vực có trạm đo.',
          en: 'Citizens or volunteers submit site photos, GPS coordinates, descriptions, timestamps, site names, and PM sensor readings if available.',
        },
        chips: [
          { vi: 'Ảnh hiện trường', en: 'Site Photos' },
          { vi: 'Vị trí GPS', en: 'GPS Geotag' },
          { vi: 'Mô tả & Thời gian', en: 'Description & Time' },
          { vi: 'Thông tin công trình', en: 'Site Details' },
          { vi: 'Dữ liệu PM2.5 (nếu có)', en: 'PM Sensor Data' },
        ],
        badge: { vi: 'Lưu kèm thời gian & GPS để xác minh', en: 'Tamper-evident timestamp & GPS' },
      },
      {
        num: '02',
        tag: { vi: 'BƯỚC 2', en: 'STEP 2' },
        title: { vi: 'XÁC MINH', en: 'VERIFY' },
        headline: { vi: 'Kiểm tra thông tin trước khi chuyển xử lý', en: 'Validate data before operational dispatch' },
        desc: {
          vi: 'DustGuard hỗ trợ kiểm tra ảnh và vị trí, phát hiện hồ sơ thiếu thông tin, đối chiếu các phản ánh gần nhau, xem lịch sử khu vực và bổ sung checklist hiện trường. Những hồ sơ chưa đủ thông tin sẽ được yêu cầu bổ sung thay vì tự động chuyển tiếp.',
          en: 'DustGuard validates photos and coordinates, detects incomplete files, matches nearby clustered reports, checks history, and prompts field checklists. Incomplete files request details before routing.',
        },
        chips: [
          { vi: 'Kiểm tra ảnh & vị trí', en: 'Photo & GPS Check' },
          { vi: 'Lọc hồ sơ thiếu tin', en: 'Filter Incomplete' },
          { vi: 'Đối chiếu điểm nóng', en: 'Cluster Matching' },
          { vi: 'Lịch sử công trình', en: 'Historical Log' },
          { vi: 'Checklist hiện trường', en: 'Field Checklist' },
        ],
        badge: { vi: 'Yêu cầu bổ sung nếu chưa đủ bằng chứng', en: 'Requires completeness check' },
      },
      {
        num: '03',
        tag: { vi: 'BƯỚC 3', en: 'STEP 3' },
        title: { vi: 'ƯU TIÊN', en: 'PRIORITIZE' },
        headline: { vi: 'Thang ưu tiên 0–100 xác định việc cần xem trước', en: '0–100 triage index to review critical cases first' },
        desc: {
          vi: 'Không phải phản ánh nào cũng xử lý theo cùng một thứ tự. Điểm ưu tiên dựa trên: Mức bụi ghi nhận, khoảng cách tới trường học/bệnh viện/khu dân cư, số phản ánh liên quan, mức độ đầy đủ bằng chứng và lịch sử tái diễn.',
          en: 'Cases are triaged based on particulate severity, proximity to schools and hospitals, cluster density, evidence completeness, and recurring history.',
        },
        chips: [
          { vi: 'Mức bụi ghi nhận', en: 'Dust Concentration' },
          { vi: 'Gần trường học / bệnh viện', en: 'School / Hospital Proximity' },
          { vi: 'Số phản ánh liên quan', en: 'Cluster Count' },
          { vi: 'Đầy đủ bằng chứng', en: 'Evidence Completeness' },
          { vi: 'Lịch sử tái diễn', en: 'Repeat History' },
        ],
        disclaimer: {
          vi: 'Quan trọng: Điểm ưu tiên không phải kết luận vi phạm. Hệ thống luôn hiển thị lý do tạo nên điểm số để người phụ trách kiểm tra trước khi quyết định.',
          en: 'Important: The priority score is not a legal violation finding. The system always explains score factors for human decision-making.',
        },
      },
      {
        num: '04',
        tag: { vi: 'BƯỚC 4', en: 'STEP 4' },
        title: { vi: 'TẠO HỒ SƠ XỬ LÝ', en: 'CASE DOSSIER' },
        headline: { vi: 'Mỗi vấn đề tạo một Case duy nhất', en: 'Each issue forms a single accountable Case' },
        desc: {
          vi: 'Hồ sơ có mã định danh duy nhất (VD: DG-2026-0842), người phụ trách rõ ràng, trạng thái 5 nấc chuẩn hóa, việc cần làm tiếp theo, lịch sử hoạt động theo thời gian và kho bằng chứng đối chứng.',
          en: 'Every dossier includes a unique Case ID, accountable assignee, 5-stage status lifecycle, next required action, audit timeline, and digital evidence.',
        },
        caseProperties: [
          { label: { vi: 'Mã hồ sơ', en: 'Case ID' }, val: 'DG-2026-0842' },
          { label: { vi: 'Người phụ trách', en: 'Assignee' }, val: { vi: 'Biết rõ ai đang theo dõi', en: 'Clear officer accountability' } },
          { label: { vi: 'Trạng thái', en: 'Status' }, val: { vi: 'Mở · Xác minh · Xử lý · Chờ tái kiểm · Hoàn tất', en: 'Open · Verify · In Progress · Recheck · Resolved' } },
          { label: { vi: 'Việc cần làm tiếp', en: 'Next Action' }, val: { vi: 'Luôn biết bước tiếp theo là gì', en: 'Always clear on the next milestone' } },
          { label: { vi: 'Lịch sử hoạt động', en: 'Activity Log' }, val: { vi: 'Mọi thay đổi lưu theo mốc thời gian', en: 'Immutable timestamped audit log' } },
          { label: { vi: 'Kho bằng chứng', en: 'Evidence' }, val: { vi: 'Ảnh, GPS, checklist lưu cùng hồ sơ', en: 'Photos, GPS and checklists bound together' } },
        ],
      },
    ],
  },
  process: null, // assigned below

  workflow: {
    eyebrow: {
      vi: 'THEO DÕI & TÁI KIỂM',
      en: 'ACCOUNTABILITY & REINSPECTION',
    },
    headline: {
      vi: 'Không để phản ánh',
      en: 'Never let a report disappear',
    },
    redAccent: {
      vi: 'biến mất sau nút “Gửi”.',
      en: 'behind the “Submit” button.',
    },
    subhead: {
      vi: 'Một trong những vấn đề lớn nhất của các hệ thống phản ánh là người gửi thường không biết chuyện gì xảy ra tiếp theo. DustGuard thiết kế quy trình theo dõi xuyên suốt đến tận bước tái kiểm nghiệm thu.',
      en: 'One of the biggest issues with reporting apps is that users never know what happens next. DustGuard enforces a continuous lifecycle through to reinspection.',
    },
    loopSteps: [
      { num: '01', title: { vi: 'PHÁT HIỆN', en: 'DETECT' }, desc: { vi: 'Có vấn đề tại hiện trường.', en: 'Issue detected on-site.' } },
      { num: '02', title: { vi: 'XÁC MINH', en: 'VERIFY' }, desc: { vi: 'Kiểm tra ảnh, vị trí và thông tin.', en: 'Validate photo, GPS and details.' } },
      { num: '03', title: { vi: 'CHUYỂN XỬ LÝ', en: 'DISPATCH' }, desc: { vi: 'Chuyển hồ sơ tới đơn vị phụ trách.', en: 'Route case to responsible team.' } },
      { num: '04', title: { vi: 'KHẮC PHỤC', en: 'MITIGATE' }, desc: { vi: 'Cập nhật hành động tại hiện trường.', en: 'Update field mitigation actions.' } },
      { num: '05', title: { vi: 'TÁI KIỂM', en: 'RECHECK' }, desc: { vi: 'Quay lại kiểm tra sau 24–48 giờ.', en: 'Reinspect site after 24–48 hours.' } },
      { num: '06', title: { vi: 'KẾT QUẢ', en: 'OUTCOME' }, desc: { vi: 'Đóng khi đạt — chưa đạt tiếp tục theo dõi.', en: 'Close when proven — keep tracking if incomplete.' } },
    ],
    beforeAfterQuestion: {
      lead: { vi: 'Câu hỏi cuối cùng không phải là: “Phản ánh đã được gửi chưa?”', en: 'The final question is not: “Was the report sent?”' },
      punch: { vi: 'Mà là: “Hiện trường đã thực sự thay đổi chưa?”', en: 'It is: “Has the site actually changed for the better?”' },
      desc: {
        vi: 'DustGuard yêu cầu bằng chứng trước và sau để hỗ trợ việc đối chiếu kết quả thực tế một cách minh bạch.',
        en: 'DustGuard requires Before and After proof to transparently evaluate real-world mitigation outcomes.',
      },
    },
    comparison: {
      before: {
        title: { vi: 'BEFORE · HIỆN TRƯỜNG KHI PHÁT HIỆN', en: 'BEFORE · INITIAL DETECTION' },
        items: [
          { label: { vi: 'Ảnh hiện trường', en: 'Field Photo' }, val: { vi: 'Xe ben đất cát không phủ bạt, bụi bay mù mịt', en: 'Uncovered dump trucks spreading dust plumes' } },
          { label: { vi: 'Định vị GPS', en: 'GPS Coordinate' }, val: '21.0312° N, 105.7824° E (Sai số < 5m)' },
          { label: { vi: 'Thời gian', en: 'Timestamp' }, val: '08:42 · 01/09/2026' },
          { label: { vi: 'Nồng độ bụi PM2.5', en: 'PM2.5 Sensor' }, val: '142 µg/m³ (Mức cảnh báo đỏ)' },
        ],
      },
      after: {
        title: { vi: 'AFTER · HIỆN TRƯỜNG SAU XỬ LÝ', en: 'AFTER · POST-MITIGATION' },
        items: [
          { label: { vi: 'Ảnh tái kiểm', en: 'Reinspection Photo' }, val: { vi: 'Đã căng bạt chống bụi & vận hành xe tưới nước', en: 'Dust netting installed & water spraying operating' } },
          { label: { vi: 'Checklist nghiệm thu', en: 'Inspection Checklist' }, val: { vi: 'Đạt 5/5 tiêu chí chống bụi đô thị', en: '5/5 civic dust mitigation standards met' } },
          { label: { vi: 'Thời gian tái kiểm', en: 'Recheck Timestamp' }, val: '10:30 · 02/09/2026 (Sau 26 giờ)' },
          { label: { vi: 'Người xác minh', en: 'Verified By' }, val: { vi: 'CLB TNV Đại học Quốc gia + Tổ liên ngành', en: 'University Volunteer Club + Taskforce' } },
        ],
      },
    },
  },
  accountability: null, // assigned below

  youth: {
    eyebrow: {
      vi: 'PHÂN VAI TÁC NGHIỆP',
      en: 'ROLE-BASED ECOSYSTEM',
    },
    headline: {
      vi: 'Mỗi người tham gia',
      en: 'Every participant has',
    },
    redAccent: {
      vi: 'đúng một vai trò rõ ràng.',
      en: 'one clear, distinct role.',
    },
    subhead: {
      vi: 'DustGuard được thiết kế để nhiều nhóm có thể cùng tham gia giám sát và xử lý nhưng tuyệt đối không làm lẫn lộn trách nhiệm.',
      en: 'DustGuard empowers multiple stakeholders to collaborate without overlapping or confusing responsibilities.',
    },
    items: [
      {
        id: 'citizen',
        num: '01',
        name: { vi: 'NGƯỜI DÂN', en: 'CITIZENS' },
        tag: { vi: 'Phát hiện & Giám sát', en: 'Detection & Oversight' },
        duties: [
          { vi: 'Phát hiện và gửi phản ánh nhanh tại hiện trường kèm ảnh & GPS.', en: 'Quickly report dust incidents on-site with photos & GPS.' },
          { vi: 'Theo dõi xuyên suốt trạng thái và tiến độ xử lý hồ sơ của mình.', en: 'Track live status and resolution progress of submitted dossiers.' },
          { vi: 'Nhận thông báo khi công trình hoàn thành khắc phục.', en: 'Receive instant notification when mitigation is verified.' },
        ],
        icon: 'user',
      },
      {
        id: 'volunteer',
        num: '02',
        name: { vi: 'TÌNH NGUYỆN VIÊN / CLB SINH VIÊN', en: 'VOLUNTEERS & YOUTH CLUBS' },
        tag: { vi: 'Xác minh & Tái kiểm', en: 'Verification & Recheck' },
        duties: [
          { vi: 'Đến hiện trường khảo sát và xác minh phản ánh ban đầu.', en: 'Visit site to verify reports and check location accuracy.' },
          { vi: 'Bổ sung ảnh chi tiết và điền checklist chuẩn hóa.', en: 'Capture standardized photos and complete field checklists.' },
          { vi: 'Thực hiện tái kiểm sau 24–48h để đối chứng Before/After.', en: 'Perform 24–48h follow-up audits for Before/After proof.' },
        ],
        icon: 'youth',
      },
      {
        id: 'coordinator',
        num: '03',
        name: { vi: 'NGƯỜI ĐIỀU PHỐI', en: 'DISPATCH COORDINATORS' },
        tag: { vi: 'Đánh giá & Phân công', en: 'Triage & Assignment' },
        duties: [
          { vi: 'Kiểm tra tính hợp lệ và chất lượng bằng chứng hồ sơ.', en: 'Audit dossier evidence validity and data completeness.' },
          { vi: 'Xác định mức ưu tiên dựa trên giải thích khoa học.', en: 'Confirm priority tiers based on explainable factors.' },
          { vi: 'Phân công đúng đơn vị/người phụ trách và theo dõi quá hạn.', en: 'Assign responsible units and monitor overdue deadlines.' },
        ],
        icon: 'gear',
      },
      {
        id: 'contractor',
        num: '04',
        name: { vi: 'ĐƠN VỊ XỬ LÝ / NHÀ THẦU', en: 'FIELD UNITS & CONTRACTORS' },
        tag: { vi: 'Khắc phục & Báo cáo', en: 'Mitigation & Evidence' },
        duties: [
          { vi: 'Tiếp nhận hồ sơ vi phạm và yêu cầu khắc phục.', en: 'Receive dust mitigation tickets and guidelines.' },
          { vi: 'Triển khai biện pháp dập bụi, che bạt, rửa đường ngay tại công trường.', en: 'Deploy netting, misting canons and wheel washing.' },
          { vi: 'Nộp ảnh bằng chứng sau khi hoàn thành để chuẩn bị tái kiểm.', en: 'Submit post-mitigation evidence for reinspection.' },
        ],
        icon: 'shield',
      },
      {
        id: 'admin',
        num: '05',
        name: { vi: 'QUẢN TRỊ HỆ THỐNG & LÃNH ĐẠO', en: 'ADMIN & EXECUTIVES' },
        tag: { vi: 'Điều hành & Báo cáo', en: 'Governance & Analytics' },
        duties: [
          { vi: 'Quản lý danh sách người dùng, CLB và đơn vị địa phương.', en: 'Manage user access, student clubs and municipal units.' },
          { vi: 'Theo dõi các điểm nóng bụi và hiệu suất xử lý toàn địa bàn.', en: 'Monitor regional dust hotspots and resolution timelines.' },
          { vi: 'Xuất báo cáo tổng hợp phục vụ chỉ đạo và liên thông dữ liệu.', en: 'Export signed summary reports for executive briefings.' },
        ],
        icon: 'chart',
      },
    ],
  },

  technology: {
    eyebrow: {
      vi: 'CÔNG NGHỆ & IOT MỞ',
      en: 'TECHNOLOGY & OPEN IOT',
    },
    headline: {
      vi: 'Công nghệ đứng phía sau quy trình,',
      en: 'Technology powers the process,',
    },
    redAccent: {
      vi: 'không đứng trước con người.',
      en: 'it never replaces human judgment.',
    },
    subhead: {
      vi: 'DustGuard sử dụng công nghệ để giảm thời gian tổng hợp thông tin và tăng khả năng kiểm tra lại hồ sơ.',
      en: 'DustGuard uses technology to reduce manual overhead and guarantee tamper-evident verification.',
    },
    pillars: [
      {
        id: 'evidence',
        icon: 'shield',
        title: { vi: 'BẰNG CHỨNG SỐ', en: 'DIGITAL EVIDENCE' },
        desc: {
          vi: 'Ảnh hiện trường được lưu kèm mốc thời gian, tọa độ GPS, hồ sơ liên quan và chữ ký số toàn vẹn. Giúp phát hiện thay đổi bất thường và duy trì lịch sử bằng chứng rõ ràng.',
          en: 'Site photos are bound to UTC timestamps, GPS coordinates, case IDs, and cryptographic hashes. Detects tampering and maintains verifiable audit trails.',
        },
        badge: { vi: 'Xác thực số · Định vị GPS · Chữ ký toàn vẹn', en: 'Cryptographic Hash & Geotag' },
      },
      {
        id: 'map',
        icon: 'mapPin',
        title: { vi: 'BẢN ĐỒ HIỆN TRƯỜNG', en: 'GIS FIELD MAP' },
        desc: {
          vi: 'Các phản ánh và hồ sơ được hiển thị theo tọa độ địa lý trực quan để xem điểm nóng, phát hiện các cụm phản ánh gần nhau, kiểm tra khu vực cần tái kiểm và điều phối người kiểm tra phù hợp.',
          en: 'Reports and dossiers mapped spatially to pinpoint hotspots, detect nearby report clusters, schedule reinspections, and route field auditors.',
        },
        badge: { vi: 'Bản đồ số WGS84 · Geofence ≤ 50m', en: 'WGS84 GIS Spatial Adapter' },
      },
      {
        id: 'ai',
        icon: 'gear',
        title: { vi: 'AI TRỢ LÝ HỖ TRỢ', en: 'AI COPILOT ASSISTANT' },
        desc: {
          vi: 'Hỗ trợ tóm tắt nội dung phản ánh, phân loại, trích xuất thông tin từ ảnh, phát hiện hồ sơ thiếu dữ liệu và gợi ý mức ưu tiên. Con người luôn là người ra quyết định cuối cùng.',
          en: 'Assists with text summarization, auto-tagging, OCR from signs, missing-data detection, and priority advice. Humans always make final decisions.',
        },
        disclaimer: {
          vi: 'Con người luôn là người quyết định: AI không tự kết luận vi phạm, không tự đóng hồ sơ, không thay thế người kiểm tra hiện trường.',
          en: 'Humans retain full authority: AI never concludes violations, closes tickets, or replaces field inspectors.',
        },
      },
    ],
    iotCallout: {
      eyebrow: { vi: 'THIẾT KẾ CẢM BIẾN MỞ', en: 'OPEN SENSING HARDWARE' },
      headline: {
        vi: 'IoT là một nguồn dữ liệu bổ sung, không phải điều kiện để DustGuard hoạt động.',
        en: 'IoT is supplementary data — not a mandatory requirement for DustGuard.',
      },
      subhead: {
        vi: 'DustGuard có thể vận hành 100% chỉ với: Ảnh hiện trường · GPS · Phản ánh cộng đồng · Checklist · Thông tin công trình. Khi khu vực có trạm đo, hệ thống bổ sung thêm dữ liệu PM để tăng khả năng quan sát.',
        en: 'DustGuard runs 100% on photos, GPS, community reports, checklists, and project logs. When sensors exist, PM streams enrich visibility.',
      },
      specs: [
        { label: { vi: 'Thông số đo', en: 'Metrics' }, val: 'PM1 · PM2.5 · PM10' },
        { label: { vi: 'Chi phí linh kiện prototype', en: 'Prototype Reference BOM' }, val: '≈ 500.000đ / node' },
        { label: { vi: 'Mục đích sử dụng', en: 'Application' }, val: { vi: 'Nghiên cứu, thử nghiệm & pilot cộng đồng', en: 'Research, experimentation & community pilots' } },
        { label: { vi: 'Lưu ý chuẩn mực', en: 'Regulatory Note' }, val: { vi: 'Không sử dụng dữ liệu từ cảm biến giá rẻ như thiết bị quan trắc pháp lý', en: 'Low-cost sensors are indicative only, not legal reference stations' } },
      ],
    },
  },

  workspace: {
    eyebrow: {
      vi: 'TRẢI NGHIỆM GIAO DIỆN',
      en: 'LIVE OPERATIONAL WORKSPACE',
    },
    headline: {
      vi: 'Giao diện tập trung vào hành động,',
      en: 'Workspaces built for immediate action,',
    },
    redAccent: {
      vi: 'minh bạch từng phút.',
      en: 'transparent by the minute.',
    },
    subhead: {
      vi: 'Người điều phối và tình nguyện viên không phải bơi trong mớ thông tin hỗn độn — mọi việc đều hiển thị đúng người, đúng thời điểm.',
      en: 'Coordinators and field auditors never drown in cluttered noise — each task is surfaced to the right person at the right time.',
    },
    dashboard: {
      title: { vi: 'Dashboard vận hành', en: 'Coordinator Operational Dashboard' },
      sub: { vi: 'Người điều phối không cần đọc từng phản ánh một. Dashboard tập trung vào những việc cần hành động ngay.', en: 'Coordinators do not read endless logs. The dashboard highlights urgent actionable items.' },
      metrics: [
        { val: '12', label: { vi: 'Hồ sơ mới cần xác minh', en: 'New files to verify' }, type: 'info' },
        { val: '5', label: { vi: 'Hồ sơ ưu tiên cao', en: 'High priority cases' }, type: 'danger' },
        { val: '3', label: { vi: 'Hồ sơ cần tái kiểm hôm nay', en: 'Due for recheck today' }, type: 'warning' },
        { val: '2', label: { vi: 'Hồ sơ quá thời hạn', en: 'Overdue cases' }, type: 'danger' },
        { val: '86%', label: { vi: 'Hồ sơ đủ bằng chứng', en: 'Evidence completeness rate' }, type: 'success' },
      ],
      actionBtn: { vi: 'Đi tới bảng điều hành', en: 'Open Dispatch Board' },
    },
    myTasks: {
      title: { vi: 'Việc của tôi (Kiểm tra viên)', en: 'My Tasks (Field Auditor)' },
      sub: { vi: 'Người kiểm tra hiện trường chỉ nhìn thấy việc liên quan tới mình. Không cần đọc toàn bộ hệ thống — chỉ cần biết: hôm nay tôi phải làm gì.', en: 'Field volunteers only see assigned tasks. No clutter — just clear daily objectives.' },
      schedule: [
        {
          time: '08:30',
          title: { vi: 'Tái kiểm công trình Nguyễn Văn Huyên', en: 'Reinspect Nguyen Van Huyen construction site' },
          badge: { vi: 'Cần tái kiểm', en: 'Recheck Due' },
          action: { vi: 'Đi kiểm tra', en: 'Inspect Site' },
          route: '/community/tasks',
        },
        {
          time: '10:00',
          title: { vi: 'Xác minh phản ánh #DG-2026-0845', en: 'Verify incident #DG-2026-0845' },
          badge: { vi: 'Mới chuyển', en: 'Assigned' },
          action: { vi: 'Xem hồ sơ', en: 'View Case' },
          route: '/community/observations',
        },
        {
          time: '14:30',
          title: { vi: 'Bổ sung ảnh hồ sơ #DG-2026-0837', en: 'Upload photos for case #DG-2026-0837' },
          badge: { vi: 'Thiếu ảnh', en: 'Need Photos' },
          action: { vi: 'Mở nhiệm vụ', en: 'Open Task' },
          route: '/community/tasks',
        },
      ],
    },
    timeline: {
      title: { vi: 'Minh bạch từ đầu đến cuối', en: 'Transparent Timeline from Start to Finish' },
      sub: { vi: 'Mỗi hồ sơ lưu lại một dòng thời gian hoạt động theo phút, có thể kiểm tra đối soát bất kỳ lúc nào.', en: 'Every dossier records an audit trail by the minute, verifiable anytime.' },
      events: [
        { time: '08:42', actor: { vi: 'Người dân', en: 'Citizen' }, desc: { vi: 'Gửi phản ánh hiện trường kèm ảnh & định vị GPS.', en: 'Submitted field report with photo & GPS coordinates.' } },
        { time: '09:05', actor: { vi: 'Tình nguyện viên', en: 'Volunteer' }, desc: { vi: 'Xác minh vị trí thực tế và bổ sung mô tả công trình.', en: 'Verified location on map and added site context.' } },
        { time: '09:18', actor: { vi: 'Hệ thống', en: 'System' }, desc: { vi: 'Đánh giá mức ưu tiên cao (85/100) do gần trường mầm non.', en: 'Calculated High Priority (85/100) due to kindergarten proximity.' } },
        { time: '09:26', actor: { vi: 'Người điều phối', en: 'Coordinator' }, desc: { vi: 'Tạo Case #DG-2026-0842 và phân công Đội phản ứng nhanh.', en: 'Created Case #DG-2026-0842 and assigned Rapid Response Team.' } },
        { time: '14:10', actor: { vi: 'Đơn vị xử lý', en: 'Field Unit' }, desc: { vi: 'Cập nhật biện pháp: Căng bạt dập bụi và rửa xe trước khi ra đường.', en: 'Updated mitigation: Installed netting & wheel washing bay.' } },
        { time: 'Hôm sau · 10:30', actor: { vi: 'Tình nguyện viên', en: 'Volunteer' }, desc: { vi: 'Đến hiện trường thực hiện tái kiểm và chụp ảnh đối chứng.', en: 'Visited site for follow-up inspection and captured After photo.' } },
        { time: '10:42', actor: { vi: 'Hệ thống & Cán bộ', en: 'System & Officer' }, desc: { vi: 'Nghiệm thu đạt 5/5 tiêu chuẩn. Đóng hồ sơ thành công.', en: 'Verified 5/5 standards. Successfully resolved case.' } },
      ],
    },
  },

  impact: {
    eyebrow: {
      vi: 'LỘ TRÌNH TRIỂN KHAI PILOT',
      en: 'PILOT ROADMAP & MILESTONES',
    },
    headline: {
      vi: 'Từ một điểm nóng nhỏ đến một',
      en: 'From a single hotspot to a',
    },
    redAccent: {
      vi: 'quy trình có thể nhân rộng.',
      en: 'scalable, sustainable workflow.',
    },
    subhead: {
      vi: 'DustGuard không bắt đầu bằng việc triển khai dàn trải. Chúng tôi bắt đầu bằng một khu vực đủ nhỏ để kiểm chứng toàn bộ quy trình trước khi mở rộng.',
      en: 'DustGuard begins with focused pilot zones to prove operational efficiency before scaling broadly.',
    },
    fiveCorePoints: [
      { num: '01', title: { vi: 'Ghi nhận đúng vấn đề', en: 'Identify true issues' } },
      { num: '02', title: { vi: 'Ưu tiên đúng việc', en: 'Prioritize urgent cases' } },
      { num: '03', title: { vi: 'Giao đúng người', en: 'Assign the right role' } },
      { num: '04', title: { vi: 'Theo dõi đến cùng', en: 'Follow up to the end' } },
      { num: '05', title: { vi: 'Chứng minh kết quả', en: 'Prove tangible outcome' } },
    ],
    stages: [
      {
        num: 'GIAI ĐOẠN 1',
        title: { vi: 'PILOT KHU VỰC', en: 'PHASE 1 · LOCAL PILOT' },
        items: [
          { vi: '1 khu vực trọng điểm', en: '1 focus geographic district' },
          { vi: '1 nhóm điều phối vận hành', en: '1 operational coordination team' },
          { vi: '20–30 tình nguyện viên sinh viên', en: '20–30 trained youth volunteers' },
          { vi: '0–3 node cảm biến tham chiếu', en: '0–3 reference sensor nodes' },
          { vi: '4–8 tuần thử nghiệm thực tế', en: '4–8 weeks real-world testing' },
        ],
      },
      {
        num: 'GIAI ĐOẠN 2',
        title: { vi: 'ĐO LƯỜNG CHỈ SỐ', en: 'PHASE 2 · MEASUREMENT' },
        items: [
          { vi: 'Thời gian xác minh phản ánh', en: 'Average verification turnaround' },
          { vi: 'Thời gian phân công người phụ trách', en: 'Time-to-dispatch response' },
          { vi: 'Tỷ lệ hồ sơ có đủ bằng chứng số', en: 'Evidence completeness ratio' },
          { vi: 'Thời gian xử lý & khắc phục', en: 'Mitigation resolution time' },
          { vi: 'Tỷ lệ hồ sơ được tái kiểm', en: 'Reinspection execution rate' },
          { vi: 'Tỷ lệ hoàn tất có Before/After', en: 'Proven Before/After closure rate' },
        ],
      },
      {
        num: 'GIAI ĐOẠN 3',
        title: { vi: 'MỞ RỘNG MÔ HÌNH', en: 'PHASE 3 · SCALING' },
        items: [
          { vi: 'Mở rộng thêm các quận/khu vực mới', en: 'Expand to new districts' },
          { vi: 'Kết nối thêm các CLB sinh viên trường ĐH', en: 'Onboard additional university clubs' },
          { vi: 'Phối hợp thêm các đơn vị xử lý', en: 'Integrate municipal response units' },
          { vi: 'Chuẩn hóa bộ checklist hiện trường', en: 'Standardize field audit checklists' },
          { vi: 'Liên thông với Cổng 1022 & iHanoi khi sẵn sàng', en: 'Interoperate with 1022 & iHanoi gateways' },
        ],
      },
    ],
  },

  cta: {
    eyebrow: {
      vi: 'ĐỒNG HÀNH CÙNG DUSTGUARD',
      en: 'JOIN THE DUSTGUARD INITIATIVE',
    },
    headline: {
      vi: 'Pilot DustGuard tại khu vực của bạn',
      en: 'Pilot DustGuard in Your Community',
    },
    subhead: {
      vi: 'DustGuard đang tìm kiếm các CLB sinh viên, nhóm cộng đồng, trường đại học và đơn vị địa phương muốn thử nghiệm mô hình giám sát bụi theo hướng cộng đồng có trách nhiệm.',
      en: 'DustGuard is partnering with student clubs, university departments, community groups, and local units to pilot accountable dust monitoring.',
    },
    conditions: [
      { vi: 'Một khu vực thử nghiệm cụ thể', en: 'A defined target area' },
      { vi: 'Một nhóm vận hành nhỏ (5–10 người)', en: 'A dedicated team (5–10 members)' },
      { vi: 'Một đầu mối phối hợp địa phương', en: 'A local coordination focal point' },
      { vi: 'Quy trình phản ánh & tái kiểm thống nhất', en: 'A structured reporting & recheck process' },
    ],
    buttons: {
      registerPilot: { vi: 'Đăng ký pilot', en: 'Register Pilot Zone' },
      contact: { vi: 'Trao đổi với DustGuard', en: 'Contact Team' },
      exploreDemo: { vi: 'Xem bản demo', en: 'Live Demo' },
    },
    manifesto: {
      quote: {
        vi: 'Một vấn đề được nhìn thấy không nên trở thành một vấn đề bị lãng quên.',
        en: 'A detected problem should never become a forgotten problem.',
      },
      sub: {
        vi: 'Từ tín hiệu đầu tiên đến hành động cuối cùng.',
        en: 'From the very first signal to verified impact.',
      },
      flow: 'OBSERVE → VERIFY → ACT → FOLLOW UP → IMPACT',
    },
  },

  footer: {
    brandDesc: {
      vi: 'Biến phản ánh và dữ liệu hiện trường thành một quy trình có người phụ trách, có bằng chứng và có thể theo dõi tới kết quả.',
      en: 'Transforming community reports and field data into an accountable workflow with tamper-evident proof and verified outcomes.',
    },
    columns: [
      {
        title: { vi: 'Sản phẩm', en: 'Product' },
        links: [
          { label: { vi: 'Cách hoạt động', en: 'How it Works' }, href: '#process' },
          { label: { vi: 'Bản đồ hiện trường', en: 'Live GIS Map' }, route: '/map' },
          { label: { vi: 'Tra cứu hồ sơ', en: 'Track Dossier' }, route: '/citizen/track' },
          { label: { vi: 'Cổng Cán bộ', en: 'Staff Portal' }, route: '/login' },
          { label: { vi: 'Xem bản Demo', en: 'Interactive Demo' }, route: '/demo' },
        ],
      },
      {
        title: { vi: 'Tài nguyên', en: 'Resources' },
        links: [
          { label: { vi: 'Tài liệu kỹ thuật', en: 'Architecture Docs' }, action: 'evidence' },
          { label: { vi: 'API & Hóa chuẩn D1', en: 'API Contract' }, route: '/login' },
          { label: { vi: 'Mã nguồn GitHub', en: 'GitHub Repository' }, href: 'https://github.com/dustguard-vn', isExternal: true },
          { label: { vi: 'Chính sách dữ liệu', en: 'Data Governance' }, action: 'demo' },
        ],
      },
      {
        title: { vi: 'Hợp tác & Pilot', en: 'Partnership' },
        links: [
          { label: { vi: 'CLB sinh viên', en: 'Student Clubs' }, action: 'pilot' },
          { label: { vi: 'Trường đại học', en: 'Universities' }, action: 'pilot' },
          { label: { vi: 'Đơn vị địa phương', en: 'Municipal Units' }, action: 'pilot' },
          { label: { vi: 'Đăng ký pilot', en: 'Register Pilot' }, action: 'pilot' },
          { label: 'contact@dustguard.vn', href: 'mailto:contact@dustguard.vn' },
        ],
      },
    ],
    bottom: {
      copyright: '© 2026 DustGuard VN',
      tagline: {
        vi: 'Giám sát · Xác minh · Hành động · Theo dõi',
        en: 'Observe · Verify · Act · Follow Up',
      },
    },
  },
};

// Bidirectional aliases for comprehensive cross-test and backward compatibility
landingContent.process = landingContent.solution;
landingContent.accountability = landingContent.workflow;
landingContent.roles = landingContent.youth;
landingContent.tech = landingContent.technology;
landingContent.pilot = landingContent.impact;

