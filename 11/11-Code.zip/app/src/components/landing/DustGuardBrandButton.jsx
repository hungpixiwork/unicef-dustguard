import React from 'react';
import { Link } from 'react-router-dom';

/**
 * DustGuardBrandButton — Reusable Civic Action Brand Button
 * Based on the Sheet 1 Brand UI component specification.
 * Features the DustGuard shield logo, dual-line title/tagline, and interactive CTA chevron.
 */
export function DustGuardBrandButton({
  title = 'DustGuard VN',
  subtitle = 'Civic Air Quality Platform',
  to = '/citizen/report/new',
  onClick,
  iconSrc = '/images/logo/dustguard-shield-logo.webp',
  variant = 'primary', // 'primary' | 'secondary' | 'outline' | 'dark'
  className = '',
}) {
  const content = (
    <>
      <div className="dg-brand-btn-icon-wrap" aria-hidden="true">
        <img
          src={iconSrc}
          alt=""
          className="dg-brand-btn-icon"
          width="28"
          height="34"
        />
      </div>
      <div className="dg-brand-btn-text">
        <span className="dg-brand-btn-title">{title}</span>
        {subtitle && <span className="dg-brand-btn-sub">{subtitle}</span>}
      </div>
      <div className="dg-brand-btn-arrow" aria-hidden="true">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="9 18 15 12 9 6" />
        </svg>
      </div>
    </>
  );

  const baseClass = `dg-brand-btn dg-brand-btn-${variant} ${className}`.trim();

  if (to) {
    return (
      <Link to={to} className={baseClass} onClick={onClick}>
        {content}
      </Link>
    );
  }

  return (
    <button type="button" className={baseClass} onClick={onClick}>
      {content}
    </button>
  );
}

export default DustGuardBrandButton;
