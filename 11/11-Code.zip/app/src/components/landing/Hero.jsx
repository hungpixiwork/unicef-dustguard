import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';
import { Send, ArrowRight, ShieldCheck, Clock, Eye } from 'lucide-react';
import { CaseStory } from './CaseStory';

export const Hero = ({ lang }) => {
  const heroLeftRef = useRef(null);
  const headlineRef = useRef(null);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      // 1. Masked reveal cho Headline H1
      gsap.from('.hero-headline-line', {
        yPercent: 110,
        duration: 0.85,
        stagger: 0.08,
        ease: 'power4.out',
        delay: 0.1,
      });

      // 2. Fade/slide nhẹ nhàng cho eyebrow, copy, và CTAs
      gsap.from('.hero-fade-item', {
        opacity: 0,
        y: 12,
        duration: 0.6,
        stagger: 0.1,
        ease: 'power3.out',
        delay: 0.25,
      });
    }, heroLeftRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="relative overflow-hidden pt-10 pb-16 md:pt-16 md:pb-20 bg-[#FBF7F2]">
      <div className="max-w-[1280px] mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* CỘT TRÁI: 58% CONTENT (7/12 cols) */}
          <div ref={heroLeftRef} className="lg:col-span-7 space-y-6">
            
            {/* EYEBROW */}
            <div className="hero-fade-item inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F4EFEA] border border-[#E7DED6] text-[#78350F] text-[12px] font-bold tracking-wider uppercase font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-[#B42318]" />
              <span>
                {lang === 'vi'
                  ? 'DUSTGUARD VN · CIVIC TECH CHO ĐÔ THỊ SẠCH'
                  : 'DUSTGUARD VN · CIVIC TECH FOR CLEANER CITIES'}
              </span>
            </div>

            {/* HEADLINE LỚN: MASKED REVEAL TỪNG DÒNG */}
            <h1
              ref={headlineRef}
              className="text-[40px] sm:text-[54px] lg:text-[66px] font-black text-[#111827] tracking-[-0.03em] leading-[1.05] text-balance"
            >
              {lang === 'vi' ? (
                <>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block">Phát hiện bụi.</span>
                  </span>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block text-[#B42318]">Theo dõi đến khi</span>
                  </span>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block">được xử lý.</span>
                  </span>
                </>
              ) : (
                <>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block">Spot urban dust.</span>
                  </span>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block text-[#B42318]">Track until</span>
                  </span>
                  <span className="block overflow-hidden pb-1">
                    <span className="hero-headline-line block">accountably resolved.</span>
                  </span>
                </>
              )}
            </h1>

            {/* SUPPORTING COPY WARM MUTED TEXT (#6B5F58) */}
            <p className="hero-fade-item text-[17px] sm:text-[19px] text-[#6B5F58] leading-relaxed max-w-[600px] font-normal">
              {lang === 'vi'
                ? 'Mỗi phản ánh trở thành một hồ sơ có mã định danh, bằng chứng được lưu vết và tiến trình xử lý có thể theo dõi đến kết quả thực tế.'
                : 'Every citizen observation becomes a structured case with unique ID, verifiable evidence trail, and tracked through full remediation.'}
            </p>

            {/* CTAS (RED ACCENT #B42318) */}
            <div className="hero-fade-item flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <Link
                to="/citizen/report"
                className="h-12 px-6 rounded-xl bg-[#B42318] hover:bg-[#991B1B] text-white font-bold text-[15px] shadow-sm flex items-center justify-center gap-2 transition-all active:scale-[0.99] w-full sm:w-auto"
              >
                <Send className="w-4 h-4" />
                <span>{lang === 'vi' ? 'Gửi phản ánh' : 'Report dust'}</span>
              </Link>

              <a
                href="#case-preview"
                className="h-12 px-5 rounded-xl bg-transparent hover:bg-[#F2ECE4] text-[#111827] font-semibold text-[15px] flex items-center justify-center gap-1.5 transition-colors w-full sm:w-auto border border-[#E7DED6] sm:border-transparent"
              >
                <span>{lang === 'vi' ? 'Xem một hồ sơ thực tế' : 'View a live case story'}</span>
                <ArrowRight className="w-4 h-4 text-[#B42318]" />
              </a>
            </div>

            {/* TRUST ROW: CIVIC ACCENTS, NO DECORATIVE BLUE */}
            <div className="hero-fade-item pt-6 border-t border-[#E7DED6] flex flex-wrap items-center gap-6 sm:gap-8 text-[13px] text-[#7A6B62] font-medium">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#B42318]" />
                <span>{lang === 'vi' ? 'Mốc tái kiểm mục tiêu: 48 giờ' : '48h follow-up target'}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#059669]" />
                <span>{lang === 'vi' ? 'Bằng chứng lưu vết' : 'Tamper-evident trail'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#B42318]" />
                <span>{lang === 'vi' ? 'Theo dõi công khai' : 'Public oversight'}</span>
              </div>
            </div>

          </div>

          {/* CỘT PHẢI: 42% VISUAL (5/12 cols) - CASE STORY CARD LỚN DUY NHẤT */}
          <div id="case-preview" className="lg:col-span-5 flex justify-center lg:justify-end">
            <CaseStory lang={lang} />
          </div>

        </div>
      </div>
    </section>
  );
};
