import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Send,
  Compass,
  MapPin,
  ShieldCheck,
  Clock,
  Activity,
  CheckCircle2,
  Layers,
  FileCheck,
} from 'lucide-react';
import { landingContent } from './landingContent';

export function HeroSection({ lang, onOpenDemo }) {
  const [activeTab, setActiveTab] = useState('before'); // 'before' | 'after'

  const content = landingContent.hero;
  const preview = content.previewCard;
  const currentDossier = activeTab === 'before' ? preview.before : preview.after;

  return (
    <section className="dg-section bg-warm" id="hero" style={{ paddingTop: 'clamp(32px, 5vw, 64px)' }}>
      <div className="dg-container">
        
        {/* Main Hero Layout: Left Copy & Right Product Showcase Frame */}
        <div className="dg-hero-grid">
          
          {/* Left Column: Storytelling Headline & Actions */}
          <div className="dg-hero-copy">
            <div className="dg-eyebrow">
              <span className="dot" />
              <span>{lang === 'en' ? 'URBAN DUST MONITORING' : 'GIÁM SÁT BỤI ĐÔ THỊ'}</span>
            </div>

            <h1 className="dg-h1">
              {lang === 'en' ? 'Detect dust.' : 'Phát hiện bụi.'}
              <br />
              <span className="accent-red">
                {lang === 'en' ? 'Track until resolved.' : 'Theo dõi đến khi được xử lý.'}
              </span>
            </h1>

            <p className="dg-lead">
              {lang === 'en'
                ? 'DustGuard binds citizen reports, on-site telemetry, and contractor mitigation into an end-to-end verifiable civic dossier.'
                : 'DustGuard kết nối phản ánh cộng đồng, dữ liệu hiện trường và trách nhiệm khắc phục trong một hồ sơ minh bạch xuyên suốt.'}
            </p>

            <div className="dg-hero-actions">
              <Link
                to="/citizen/report/new"
                className="dg-btn dg-btn-primary"
                aria-label={lang === 'en' ? 'Submit report' : 'Gửi phản ánh'}
              >
                <Send size={16} aria-hidden="true" />
                <span>{lang === 'en' ? 'Submit Report' : 'Gửi phản ánh ngay'}</span>
              </Link>

              <Link
                to="/demo"
                className="dg-btn dg-btn-secondary"
                aria-label={lang === 'en' ? 'Explore demo' : 'Xem quy trình'}
              >
                <Compass size={16} aria-hidden="true" />
                <span>{lang === 'en' ? 'Live Demo' : 'Xem quy trình thực tế'}</span>
              </Link>
            </div>
          </div>

          {/* Right Column: Layered Interactive Case Dossier Frame */}
          <div className="dg-hero-visual-wrapper">
            
            {/* Floating Chip 1: Tái kiểm 24-48h */}
            <div className="dg-floating-chip top-left">
              <Clock size={15} color="#0D6F64" aria-hidden="true" />
              <span>{lang === 'en' ? '24–48h Recheck SLA' : 'Tái kiểm hiện trường 24–48h'}</span>
            </div>

            {/* Dossier Card Container */}
            <div className="dg-dossier-frame">
              {/* Header */}
              <div className="dg-dossier-header">
                <div className="dg-live-badge">
                  <span className="dot" style={{ backgroundColor: activeTab === 'after' ? '#1B7A4B' : '#0D6F64' }} />
                  <span>{activeTab === 'after' ? (lang === 'en' ? 'MITIGATED' : 'ĐÃ NGHIỆM THU') : (lang === 'en' ? 'ACTIVE DOSSIER' : 'HỒ SƠ THEO DÕI')}</span>
                </div>
                <span className="dg-case-code">#DG-2026-0842</span>
              </div>

              {/* Location & Unit */}
              <div className="dg-dossier-meta">
                <div className="dg-dossier-location">
                  <MapPin size={16} color="#0D6F64" aria-hidden="true" />
                  <span>{lang === 'en' ? 'Ring Road 3 · An Phu Junction' : 'Nút giao An Phú · TP. Thủ Đức'}</span>
                </div>
                <span className="dg-dossier-handover">
                  {lang === 'en' ? 'Dispatched to Contractor' : 'Đã giao đơn vị thi công'}
                </span>
              </div>

              {/* 5-Step Process Indicator */}
              <div className="dg-pipeline-strip">
                {[
                  { num: '01', title: lang === 'en' ? 'Report' : 'Ghi nhận', done: true },
                  { num: '02', title: lang === 'en' ? 'Verify' : 'Xác minh', done: true },
                  { num: '03', title: lang === 'en' ? 'Dispatch' : 'Chuyển xử lý', done: true },
                  { num: '04', title: lang === 'en' ? 'Mitigate' : 'Khắc phục', active: activeTab === 'before', done: activeTab === 'after' },
                  { num: '05', title: lang === 'en' ? 'Recheck' : 'Tái kiểm', done: activeTab === 'after' },
                ].map((st) => (
                  <div
                    key={st.num}
                    className={`dg-pipeline-node ${st.active ? 'active' : ''} ${st.done ? 'done' : ''}`}
                  >
                    <span>{st.num}</span>
                    <span>{st.title}</span>
                  </div>
                ))}
              </div>

              {/* Tab Selector Before vs After */}
              <div className="dg-tab-selector" role="tablist" aria-label="So sánh trước sau">
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'before'}
                  className={`dg-tab-btn ${activeTab === 'before' ? 'active' : ''}`}
                  onClick={() => setActiveTab('before')}
                >
                  <Activity size={14} aria-hidden="true" />
                  <span>{lang === 'en' ? '1. Field Observation' : '1. Hiện trường ban đầu'}</span>
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'after'}
                  className={`dg-tab-btn ${activeTab === 'after' ? 'active' : ''}`}
                  onClick={() => setActiveTab('after')}
                >
                  <CheckCircle2 size={14} color="#1B7A4B" aria-hidden="true" />
                  <span>{lang === 'en' ? '2. Reinspection & Verified' : '2. Sau tái kiểm 48h'}</span>
                </button>
              </div>

              {/* Dossier Body with Live Values */}
              <div className="dg-dossier-body">
                <div className="dg-metrics-duo">
                  <div className="dg-metric-cell">
                    <span className="label">{lang === 'en' ? 'PM2.5 DUST LEVEL' : 'NỒNG ĐỘ PM2.5'}</span>
                    <div className="val" style={{ color: activeTab === 'after' ? '#1B7A4B' : '#9F241F' }}>
                      {activeTab === 'after' ? '28 µg/m³' : '142 µg/m³'}
                    </div>
                  </div>
                  <div className="dg-metric-cell">
                    <span className="label">{lang === 'en' ? 'PRIORITY SCORE' : 'ĐIỂM ƯU TIÊN'}</span>
                    <div className="val" style={{ color: activeTab === 'after' ? '#1B7A4B' : '#9F241F' }}>
                      {activeTab === 'after' ? '18/100 (An toàn)' : '85/100 (Cần xử lý)'}
                    </div>
                  </div>
                </div>

                <div className="dg-evidence-box">
                  <strong>{lang === 'en' ? 'Digital Evidence:' : 'Minh chứng thực địa:'}</strong>{' '}
                  {activeTab === 'after'
                    ? (lang === 'en' ? 'Full dust barriers installed + automated mist water truck operational.' : 'Đã lắp lưới chắn bụi toàn tuyến + xe bồn tưới nước rửa đường 3 lần/ngày.')
                    : (lang === 'en' ? 'Earth hauling trucks operating without covers, plume drifting into school zone.' : 'Xe tải chở đất không phủ bạt, phát tán bụi trên đường gom gần trường học.')}
                  <span className="sub">
                    {activeTab === 'after' ? 'SHA-256: 8f3a...b24c · WGS84 Geofence Verified' : 'SHA-256: 1d9e...5a02 · Geotagged'}
                  </span>
                </div>
              </div>

            </div>

            {/* Floating Chip 2: Minh bạch chứng cứ */}
            <div className="dg-floating-chip bottom-right">
              <ShieldCheck size={15} color="#0D6F64" aria-hidden="true" />
              <span>{lang === 'en' ? 'WGS84 Geofenced (<50m)' : 'Xác thực tọa độ WGS84 (<50m)'}</span>
            </div>

          </div>

        </div>

        {/* Horizontal Metric Strip (Zero Dashboard Clutter) */}
        <div className="dg-metrics-strip-wrapper">
          <div className="dg-metrics-strip">
            
            <div className="dg-metric-strip-item">
              <div className="dg-metric-strip-val">0–100</div>
              <div className="dg-metric-strip-lbl">{lang === 'en' ? 'Priority Index' : 'Điểm ưu tiên rủi ro'}</div>
              <p className="dg-metric-strip-desc">
                {lang === 'en'
                  ? 'Combines particulate severity, school proximity, and repeat history to prioritize action.'
                  : 'Xác định việc cần xem trước dựa trên nồng độ bụi, độ nhạy trường học và lịch sử tái diễn.'}
              </p>
            </div>

            <div className="dg-metric-strip-item">
              <div className="dg-metric-strip-val">24–48h</div>
              <div className="dg-metric-strip-lbl">{lang === 'en' ? 'Reinspection Cycle' : 'Chu kỳ tái kiểm thực địa'}</div>
              <p className="dg-metric-strip-desc">
                {lang === 'en'
                  ? 'Verifiable time-window to confirm contractor mitigation before closing the case.'
                  : 'Đối chứng Before/After thực địa để đảm bảo công trình khắc phục thật, không tái diễn.'}
              </p>
            </div>

            <div className="dg-metric-strip-item">
              <div className="dg-metric-strip-val">≈ 500k</div>
              <div className="dg-metric-strip-lbl">{lang === 'en' ? 'Open IoT Sensor Node' : 'Trạm cảm biến mở (VNĐ)'}</div>
              <p className="dg-metric-strip-desc">
                {lang === 'en'
                  ? 'Reference open hardware bill of materials, easily replicable across civic communities.'
                  : 'Định mức linh kiện mở tối ưu, dễ nhân rộng tại trường học và khu dân cư.'}
              </p>
            </div>

            <div className="dg-metric-strip-item">
              <div className="dg-metric-strip-val">100%</div>
              <div className="dg-metric-strip-lbl">{lang === 'en' ? 'Accountability Trail' : 'Minh bạch trách nhiệm'}</div>
              <p className="dg-metric-strip-desc">
                {lang === 'en'
                  ? 'Every status transition is bound to an accountable actor with tamper-evident logs.'
                  : 'Mỗi trạng thái đều có người phụ trách và nhật ký lưu vết không thể xóa sửa.'}
              </p>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}

export default HeroSection;
