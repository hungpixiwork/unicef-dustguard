import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Clock,
  Compass,
  Layers,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { landingContent } from './landingContent';

export function ImpactSection({ lang }) {
  const content = landingContent.impact;

  return (
    <section className="section impact-section" id="pilot">
      <div className="container">
        
        {/* Section Header */}
        <div className="reveal show">
          <div className="eyebrow">
            <span className="eyebrow-dot" />
            <span>{content.eyebrow[lang] || content.eyebrow.vi}</span>
          </div>
          <h2 className="headline">
            {content.headline[lang] || content.headline.vi}<br />
            <span className="hero-red">
              {content.redAccent[lang] || content.redAccent.vi}
            </span>
          </h2>
          <p className="subhead">
            {content.subhead[lang] || content.subhead.vi}
          </p>
        </div>

        {/* 5 Core Civic Commitments Strip */}
        <div className="five-core-strip reveal show">
          <div className="five-core-label">
            <span>{lang === 'en' ? '5 Core System Disciplines:' : 'DustGuard tập trung vào 5 việc cốt lõi:'}</span>
          </div>
          <div className="five-core-grid">
            {content.fiveCorePoints.map((pt) => (
              <div key={pt.num} className="five-core-item">
                <span className="five-core-num">{pt.num}</span>
                <span className="five-core-title">{pt.title[lang] || pt.title.vi}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 3 Phased Pilot Roadmap Grid */}
        <div className="roadmap-grid reveal show">
          {content.stages.map((st, idx) => (
            <div key={idx} className="roadmap-phase-card soft-card">
              <div className="phase-card-header">
                <span className="phase-badge-pill">{st.num}</span>
                <h3 className="phase-main-title">{st.title[lang] || st.title.vi}</h3>
              </div>

              <div className="phase-items-list">
                {st.items.map((it, iIdx) => (
                  <div key={iIdx} className="phase-item-row">
                    <CheckCircle2 size={14} className="phase-check-icon shrink-0" />
                    <span className="phase-item-text">{it[lang] || it.vi}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default ImpactSection;
