import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import {
  MapPin,
  Check,
  RotateCcw,
  Sparkles,
  Camera,
  Truck,
  Droplets,
  ShieldCheck,
  Eye,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react';

export const CaseStory = ({ lang }) => {
  const containerRef = useRef(null);
  const cardRef = useRef(null);
  const ambientGridRef = useRef(null);
  
  // Incident Signal & Trace Refs
  const incidentPinRef = useRef(null);
  const incidentPulseRingRef = useRef(null);
  const tracePathRef = useRef(null);

  // Case Card Sub-elements
  const headerRef = useRef(null);
  const caseIdRef = useRef(null);
  const assignmentChipRef = useRef(null);
  const evidenceStageRef = useRef(null);
  const beforeSceneRef = useRef(null);
  const hazeLayerRef = useRef(null);
  const interventionMarkerRef = useRef(null);
  const afterSceneRef = useRef(null);
  const scanLineRef = useRef(null);

  // Timeline Refs
  const timelineBarRef = useRef(null);
  const nodeRefs = useRef([]);
  const labelRefs = useRef([]);

  // Verified Badge Refs
  const badgeRef = useRef(null);
  const badgeRingRef = useRef(null);
  const footerRef = useRef(null);
  const finalStatusTextRef = useRef(null);

  // Manual Toggle After Animation Done
  const [activeView, setActiveView] = useState('after');
  const [animationDone, setAnimationDone] = useState(false);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isMobile = window.innerWidth < 768;

    if (prefersReducedMotion) {
      // Bỏ qua toàn bộ chuyển động, lập tức đặt trạng thái hoàn tất
      if (afterSceneRef.current) gsap.set(afterSceneRef.current, { clipPath: 'inset(0% 0% 0% 0%)' });
      if (scanLineRef.current) gsap.set(scanLineRef.current, { opacity: 0 });
      if (timelineBarRef.current) gsap.set(timelineBarRef.current, { scaleY: 1 });
      nodeRefs.current.forEach((n) => n && gsap.set(n, { opacity: 1, scale: 1 }));
      labelRefs.current.forEach((l) => l && gsap.set(l, { opacity: 1, x: 0 }));
      if (badgeRef.current) gsap.set(badgeRef.current, { opacity: 1, scale: 1, rotation: 0 });
      if (assignmentChipRef.current) gsap.set(assignmentChipRef.current, { opacity: 1, x: 0 });
      if (footerRef.current) gsap.set(footerRef.current, { opacity: 1, y: 0 });
      setAnimationDone(true);
      return;
    }

    const ctx = gsap.context(() => {
      // 1. Chuẩn bị giá trị ban đầu (Initial Setup)
      gsap.set(cardRef.current, { y: 26, opacity: 0, scale: 0.985 });
      gsap.set(incidentPinRef.current, { scale: 0, opacity: 0 });
      gsap.set(incidentPulseRingRef.current, { scale: 0.6, opacity: 0 });
      gsap.set(afterSceneRef.current, { clipPath: 'inset(0% 100% 0% 0%)' });
      gsap.set(scanLineRef.current, { left: '0%', opacity: 0 });
      gsap.set(timelineBarRef.current, { scaleY: 0, transformOrigin: 'top center' });
      gsap.set(assignmentChipRef.current, { x: 20, opacity: 0 });
      gsap.set(interventionMarkerRef.current, { opacity: 0, y: 6 });
      gsap.set(badgeRef.current, { scale: 0.78, rotation: -4, opacity: 0 });
      gsap.set(badgeRingRef.current, { scale: 1, opacity: 0 });

      // Signal Trace Path setup
      if (tracePathRef.current) {
        const length = tracePathRef.current.getTotalLength ? tracePathRef.current.getTotalLength() : 220;
        gsap.set(tracePathRef.current, {
          strokeDasharray: length,
          strokeDashoffset: length,
          opacity: 0.7,
        });
      }

      // 2. Chạy GSAP Master Timeline (Thời lượng tổng ~4.8s)
      const tl = gsap.timeline({
        defaults: { ease: 'power3.out' },
        onComplete: () => {
          setAnimationDone(true);
          setActiveView('after');
        },
      });
      window.__heroTimeline = tl;

      // 0.00s: Background grid fade in nhẹ
      if (ambientGridRef.current) {
        tl.to(ambientGridRef.current, { opacity: 0.07, duration: 0.4 }, 0.0);
      }

      // 0.20s: Incident location dot appears & pulse ring expands once
      tl.to(
        incidentPinRef.current,
        {
          scale: 1,
          opacity: 1,
          duration: 0.35,
          ease: 'back.out(1.5)',
        },
        0.20
      )
        .to(
          incidentPulseRingRef.current,
          {
            scale: 2.2,
            opacity: 0.45,
            duration: 0.3,
            ease: 'power2.out',
          },
          0.25
        )
        .to(
          incidentPulseRingRef.current,
          {
            opacity: 0,
            duration: 0.35,
            ease: 'power2.in',
          },
          0.55
        );

      // 0.55s: Thin Red Signal Trace draws toward the case card
      if (tracePathRef.current) {
        tl.to(
          tracePathRef.current,
          {
            strokeDashoffset: 0,
            duration: 0.75,
            ease: 'power2.inOut',
          },
          0.55
        );
      }

      // 0.90s: Case shell appears
      tl.to(
        cardRef.current,
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.65,
          ease: 'power3.out',
        },
        0.90
      );

      // 1.20s: Case ID types / locks in visually
      tl.fromTo(
        caseIdRef.current,
        { opacity: 0, letterSpacing: '0.12em' },
        { opacity: 1, letterSpacing: '0em', duration: 0.4, ease: 'power2.out' },
        1.20
      );

      // 1.55s: "01 Phát hiện" activates
      tl.to(
        nodeRefs.current[0],
        { opacity: 1, scale: 1.15, duration: 0.22 },
        1.55
      )
        .to(nodeRefs.current[0], { scale: 1, duration: 0.12 })
        .to(labelRefs.current[0], { opacity: 1, x: 0, duration: 0.25 }, '<');

      // 1.90s: "02 Tiếp nhận" activates & assignment chip slides in
      tl.to(
        timelineBarRef.current,
        { scaleY: 0.35, duration: 0.35, ease: 'power2.inOut' },
        1.90
      )
        .to(nodeRefs.current[1], { opacity: 1, scale: 1.15, duration: 0.22 }, 1.95)
        .to(nodeRefs.current[1], { scale: 1, duration: 0.12 })
        .to(labelRefs.current[1], { opacity: 1, x: 0, duration: 0.25 }, '<')
        // Header border flashes very lightly with warm red accent on Assignment
        .to(
          headerRef.current,
          {
            borderBottomColor: '#F8D3D1',
            duration: 0.25,
            yoyo: true,
            repeat: 1,
          },
          1.95
        )
        // Assignment chip slides in from right
        .to(
          assignmentChipRef.current,
          {
            x: 0,
            opacity: 1,
            duration: 0.35,
            ease: 'power2.out',
          },
          2.00
        );

      // 2.35s: "03 Khắc phục" activates & incident visual responds
      tl.to(
        timelineBarRef.current,
        { scaleY: 0.68, duration: 0.35, ease: 'power2.inOut' },
        2.35
      )
        .to(nodeRefs.current[2], { opacity: 1, scale: 1.15, duration: 0.22 }, 2.40)
        .to(nodeRefs.current[2], { scale: 1, duration: 0.12 })
        .to(labelRefs.current[2], { opacity: 1, x: 0, duration: 0.25 }, '<')
        // Subtle restrained micro-reaction on evidence panel
        .to(
          evidenceStageRef.current,
          {
            y: -2,
            duration: 0.25,
            yoyo: true,
            repeat: 1,
            ease: 'power1.inOut',
          },
          2.40
        )
        // Haze layer begins reducing & intervention marker enters
        .to(
          hazeLayerRef.current,
          {
            opacity: 0.25,
            duration: 0.45,
            ease: 'power2.out',
          },
          2.45
        )
        .to(
          interventionMarkerRef.current,
          {
            opacity: 1,
            y: 0,
            duration: 0.3,
            ease: 'power2.out',
          },
          2.50
        );

      // 2.80s: Main Before -> After wipe reveal begins (1.1s wipe)
      tl.set(scanLineRef.current, { opacity: 1 }, 2.80)
        .to(
          afterSceneRef.current,
          {
            clipPath: 'inset(0% 0% 0% 0%)',
            duration: 1.1,
            ease: 'power2.inOut',
          },
          2.80
        )
        .to(
          scanLineRef.current,
          {
            left: '100%',
            duration: 1.1,
            ease: 'power2.inOut',
          },
          2.80
        )
        .to(scanLineRef.current, { opacity: 0, duration: 0.2 }, 3.90);

      // 3.80s: "04 Tái kiểm" activates & card border transitions to subtle verified green
      tl.to(
        timelineBarRef.current,
        { scaleY: 1, duration: 0.3, ease: 'power2.inOut' },
        3.80
      )
        .to(nodeRefs.current[3], { opacity: 1, scale: 1.2, duration: 0.25 }, 3.85)
        .to(nodeRefs.current[3], { scale: 1, duration: 0.15 })
        .to(labelRefs.current[3], { opacity: 1, x: 0, duration: 0.25 }, '<')
        .to(
          cardRef.current,
          {
            borderColor: '#A7F3D0',
            duration: 0.5,
            ease: 'power2.out',
          },
          3.85
        );

      // 4.10s: Verified badge enters with back.out(1.4)
      tl.to(
        badgeRef.current,
        {
          scale: 1,
          rotation: 0,
          opacity: 1,
          duration: 0.4,
          ease: 'back.out(1.4)',
        },
        4.10
      );

      // 4.30s: Verification ring expands once
      tl.to(
        badgeRingRef.current,
        {
          scale: 1.85,
          opacity: 0.4,
          duration: 0.28,
          ease: 'power2.out',
        },
        4.30
      ).to(
        badgeRingRef.current,
        {
          opacity: 0,
          duration: 0.3,
          ease: 'power2.in',
        },
        4.58
      );

      // 4.55s: Final status label locks in
      tl.fromTo(
        footerRef.current,
        { opacity: 0, y: 6 },
        { opacity: 1, y: 0, duration: 0.35, ease: 'power2.out' },
        4.55
      );
    }, containerRef);

    // 3. Desktop Subtle Parallax via gsap.quickTo (Zero react state lag)
    const cardEl = cardRef.current;
    const containerEl = containerRef.current;
    if (containerEl && cardEl && !isMobile) {
      const moveCardX = gsap.quickTo(cardEl, 'x', { duration: 0.4, ease: 'power3.out' });
      const moveCardY = gsap.quickTo(cardEl, 'y', { duration: 0.4, ease: 'power3.out' });
      const moveGridX = gsap.quickTo(ambientGridRef.current, 'x', { duration: 0.6, ease: 'power3.out' });
      const moveGridY = gsap.quickTo(ambientGridRef.current, 'y', { duration: 0.6, ease: 'power3.out' });
      const movePinX = gsap.quickTo(incidentPinRef.current, 'x', { duration: 0.35, ease: 'power3.out' });
      const movePinY = gsap.quickTo(incidentPinRef.current, 'y', { duration: 0.35, ease: 'power3.out' });

      const handleMouseMove = (e) => {
        const rect = containerEl.getBoundingClientRect();
        const normX = (e.clientX - rect.left) / rect.width - 0.5; // -0.5 to 0.5
        const normY = (e.clientY - rect.top) / rect.height - 0.5;

        // Card max 2px
        moveCardX(normX * 4);
        moveCardY(normY * 4);
        // Grid max 5px
        moveGridX(-normX * 10);
        moveGridY(-normY * 10);
        // Incident pin max 4px
        movePinX(normX * 8);
        movePinY(normY * 8);
      };

      const handleMouseLeave = () => {
        moveCardX(0);
        moveCardY(0);
        moveGridX(0);
        moveGridY(0);
        movePinX(0);
        movePinY(0);
      };

      containerEl.addEventListener('mousemove', handleMouseMove);
      containerEl.addEventListener('mouseleave', handleMouseLeave);

      return () => {
        containerEl.removeEventListener('mousemove', handleMouseMove);
        containerEl.removeEventListener('mouseleave', handleMouseLeave);
        ctx.revert();
      };
    }

    return () => ctx.revert();
  }, []);

  // Manual toggle Before / After once animation finishes
  const handleToggleView = () => {
    if (!afterSceneRef.current) return;

    if (activeView === 'after') {
      gsap.to(afterSceneRef.current, {
        clipPath: 'inset(0% 100% 0% 0%)',
        duration: 0.5,
        ease: 'power2.inOut',
        onComplete: () => setActiveView('before'),
      });
    } else {
      gsap.to(afterSceneRef.current, {
        clipPath: 'inset(0% 0% 0% 0%)',
        duration: 0.5,
        ease: 'power2.inOut',
        onComplete: () => setActiveView('after'),
      });
    }
  };

  const stages = [
    { num: '01', title: lang === 'vi' ? 'Phát hiện' : 'Detection', time: '05/09 · 08:15', role: 'Công dân' },
    { num: '02', title: lang === 'vi' ? 'Tiếp nhận' : 'Triage', time: '05/09 · 09:30', role: 'UBND Phường' },
    { num: '03', title: lang === 'vi' ? 'Khắc phục' : 'Remediate', time: '06/09 · 14:00', role: 'Nhà thầu' },
    { num: '04', title: lang === 'vi' ? 'Tái kiểm' : 'Reinspect', time: '07/09 · 08:40', isFinal: true, role: 'Cán bộ' },
  ];

  return (
    <div ref={containerRef} className="relative w-full max-w-[520px] mx-auto pt-6 pb-2">
      {/* 1. SUBTLE MAP / CIVIC DATA BACKGROUND (Subtle 5% Opacity) */}
      <div
        ref={ambientGridRef}
        aria-hidden="true"
        className="pointer-events-none absolute -inset-10 opacity-5 overflow-hidden select-none"
      >
        <svg className="w-full h-full text-[#111827]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="civic-grid" width="44" height="44" patternUnits="userSpaceOnUse">
              <path d="M 44 0 L 0 0 0 44" fill="none" stroke="currentColor" strokeWidth="0.75" />
              <circle cx="22" cy="22" r="1.2" fill="currentColor" opacity="0.4" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#civic-grid)" />
          {/* Subtle civic coordinate lines */}
          <line x1="5%" y1="25%" x2="95%" y2="80%" stroke="#B42318" strokeWidth="1" strokeDasharray="5 5" opacity="0.3" />
        </svg>
      </div>

      {/* 2. THE INCIDENT LOCATION PIN & SPREADING PULSE RING */}
      <div
        ref={incidentPinRef}
        className="absolute -top-3.5 left-3 sm:left-5 z-30 flex items-center gap-2"
      >
        <div className="relative flex items-center justify-center">
          {/* Single expanding ring */}
          <div
            ref={incidentPulseRingRef}
            className="pointer-events-none absolute w-5 h-5 rounded-full border-2 border-[#B42318]"
          />
          {/* Solid center dot */}
          <div className="w-3.5 h-3.5 rounded-full bg-[#B42318] shadow-[0_0_8px_rgba(180,35,24,0.6)] flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-white" />
          </div>
        </div>
        <div className="px-2.5 py-0.5 rounded-md bg-[#111827] text-white text-[10px] font-mono tracking-wider shadow-sm flex items-center gap-1.5">
          <span className="text-[#FCA5A5] font-bold">SIGNAL:</span>
          <span>GPS 20.9852° N</span>
        </div>
      </div>

      {/* 3. THE RED SIGNAL TRACE (SVG PATH DRAWING CLEANLY TO TOP EDGE OF CARD) */}
      <div className="pointer-events-none absolute -top-3.5 left-3 sm:left-5 z-20 w-[120px] h-[36px] select-none">
        <svg
          viewBox="0 0 120 36"
          fill="none"
          className="w-full h-full overflow-visible"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            ref={tracePathRef}
            d="M 12 8 C 12 24, 26 32, 54 32 L 105 32"
            stroke="#B42318"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          {/* Subtle node marker at the card junction */}
          <circle cx="105" cy="32" r="2.5" fill="#B42318" />
        </svg>
      </div>

      {/* 4. MAIN CASE ENGINE CARD (Clean, High Contrast, Cream Surface) */}
      <div
        ref={cardRef}
        className="relative z-10 w-full bg-[#FFFCF8] rounded-[24px] border border-[#E7DED6] shadow-[0_16px_40px_rgba(17,24,39,0.06)] overflow-visible"
      >
        {/* CARD HEADER */}
        <div
          ref={headerRef}
          className="pt-5 px-4 sm:px-6 pb-3.5 bg-[#FAF6F0] rounded-t-[24px] border-b border-[#E7DED6] flex items-center justify-between gap-2"
        >
          <div className="flex items-center gap-2 min-w-0">
            <span
              ref={caseIdRef}
              className="font-mono text-[13px] font-black text-[#111827] tracking-tight shrink-0"
            >
              DG-2026-OP-014
            </span>
            <span className="text-[#CBD5E1] text-[12px] shrink-0">·</span>
            <span className="text-[12px] font-semibold text-[#6B5F58] flex items-center gap-1 truncate">
              <MapPin className="w-3.5 h-3.5 text-[#B42318] shrink-0" />
              <span className="truncate">Nút giao Kim Đồng</span>
            </span>
          </div>

          {/* VERIFIED BADGE WITH GSAP BACK.OUT ENTRANCE + RING */}
          <div className="relative shrink-0">
            <div
              ref={badgeRingRef}
              className="pointer-events-none absolute -inset-1 rounded-full border-2 border-[#10B981]"
            />
            <div
              ref={badgeRef}
              className="flex items-center gap-1 px-3 py-1 rounded-full bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46] text-[11px] font-bold shadow-2xs whitespace-nowrap"
            >
              <Check className="w-3.5 h-3.5 text-[#10B981] stroke-[3] shrink-0" />
              <span>{lang === 'vi' ? 'Đã tái kiểm' : 'Verified'}</span>
            </div>
          </div>
        </div>

        {/* 5. EVIDENCE STAGE — BEFORE / AFTER PHOTOGRAPHIC DEPTH */}
        <div className="p-4 sm:p-6 space-y-5">
          <div
            ref={evidenceStageRef}
            className="relative h-48 sm:h-52 w-full rounded-[16px] overflow-hidden border border-[#E7DED6] bg-[#1F2937]"
          >
            {/* --- SCENE A: BEFORE (PHÁT HIỆN BAN ĐẦU - DUSTY TINT & HAZE) --- */}
            <div
              ref={beforeSceneRef}
              className="absolute inset-0 bg-gradient-to-br from-[#FDF8F0] via-[#F8EFE3] to-[#EFE2D0] flex flex-col justify-between p-4 select-none"
            >
              {/* Top metadata tag */}
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#111827]/85 text-white font-mono text-[10px]">
                  <Camera className="w-3 h-3 text-[#F59E0B]" />
                  <span>05/09 · 08:15:22</span>
                </div>
                <span className="font-bold text-[#B42318] bg-[#FDE8E6] px-2.5 py-0.5 rounded-full text-[10px] border border-[#F8D3D1] uppercase tracking-wider flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-[#B42318]" />
                  {lang === 'vi' ? 'Lúc phát hiện' : 'Before'}
                </span>
              </div>

              {/* Dynamic Haze layer that reduces on stage 03 */}
              <div
                ref={hazeLayerRef}
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-amber-900/15 via-amber-700/10 to-transparent transition-opacity"
              />

              {/* Realistic Scene: Construction truck without tire wash */}
              <div className="relative py-1 flex items-center gap-3 z-10">
                <div className="w-12 h-12 rounded-xl bg-amber-900/10 border border-amber-900/20 flex items-center justify-center text-[#78350F] shrink-0 shadow-2xs">
                  <Truck className="w-6 h-6" />
                </div>
                <div className="space-y-0.5">
                  <p className="text-[13px] sm:text-[14px] font-bold text-[#111827] leading-snug">
                    {lang === 'vi'
                      ? 'Bụi cuốn phát sinh khi xe tải rời công trình.'
                      : 'Heavy dust cloud from departing construction trucks.'}
                  </p>
                  <p className="text-[11px] text-[#78350F] font-medium">
                    {lang === 'vi' ? 'Bánh xe dính đất cát · Chưa bật vòi phun rửa' : 'Mud on tires · No active tire wash station'}
                  </p>
                </div>
              </div>

              {/* Intervention preview marker: enters on 03 Khắc phục */}
              <div
                ref={interventionMarkerRef}
                className="relative z-10 flex items-center justify-between text-[10px] text-[#7A6B62] font-medium pt-1.5 border-t border-amber-900/15"
              >
                <span className="flex items-center gap-1 text-[#B42318] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#B42318] animate-pulse" />
                  {lang === 'vi' ? 'Đã yêu cầu bật trạm xịt áp lực' : 'Order: deploy high-pressure wash'}
                </span>
                <span className="font-mono text-[#6B5F58]">{lang === 'vi' ? 'Minh chứng công dân' : 'Citizen report'}</span>
              </div>
            </div>

            {/* --- SCENE B: AFTER (ĐÃ KHẮC PHỤC & TÁI KIỂM - NEUTRAL PHOTOGRAPHIC PAVEMENT) --- */}
            {/* Tuyệt đối không biến thành hộp xanh toàn bộ; nền là mặt đường sạch trung tính, chỉ icon và badge là green */}
            <div
              ref={afterSceneRef}
              className="absolute inset-0 bg-gradient-to-br from-[#FAF9F6] via-[#F4F3EE] to-[#EAE8E1] flex flex-col justify-between p-4 select-none z-10 border-l border-white/50"
              style={{ clipPath: 'inset(0% 0% 0% 0%)' }}
            >
              {/* Clean Pavement Header */}
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-[#111827] text-white font-mono text-[10px]">
                  <ShieldCheck className="w-3 h-3 text-[#10B981]" />
                  <span>07/09 · 08:40:15 (48h)</span>
                </div>
                <span className="font-bold text-[#065F46] bg-[#ECFDF5] px-2.5 py-0.5 rounded-full text-[10px] border border-[#A7F3D0] uppercase tracking-wider flex items-center gap-1 shadow-2xs">
                  <Sparkles className="w-3 h-3 text-[#10B981]" />
                  {lang === 'vi' ? 'Sau tái kiểm' : 'After'}
                </span>
              </div>

              {/* Scene: Sprinklers & Damp, Clean Asphalt */}
              <div className="relative py-1 flex items-center gap-3 z-10">
                <div className="w-12 h-12 rounded-xl bg-[#E6F4F2] border border-[#A7F3D0] flex items-center justify-center text-[#0D6F64] shrink-0 shadow-2xs">
                  <Droplets className="w-6 h-6" />
                </div>
                <div className="space-y-0.5">
                  <p className="text-[13px] sm:text-[14px] font-bold text-[#111827] leading-snug">
                    {lang === 'vi'
                      ? 'Đã lắp vòi xịt rửa bánh & mặt đường được làm ẩm.'
                      : 'Wheel washing operational & road surface dampened.'}
                  </p>
                  <p className="text-[11px] text-[#065F46] font-medium">
                    {lang === 'vi' ? 'Không còn bùn đất vương vãi · Không phát sinh bụi' : 'Zero mud dragging · Ambient dust suppressed'}
                  </p>
                </div>
              </div>

              {/* Bottom tag: Verification receipt */}
              <div className="flex items-center justify-between text-[10px] text-[#6B5F58] font-medium pt-1.5 border-t border-[#E7DED6]">
                <span className="flex items-center gap-1 text-[#065F46] font-semibold">
                  <Check className="w-3 h-3 text-[#10B981] stroke-[3]" />
                  {lang === 'vi' ? 'Nghiệm thu: Cán bộ địa bàn' : 'Verified: Ward Officer'}
                </span>
                <span className="font-mono text-[#111827] font-bold bg-[#FAF6F0] px-1.5 py-0.5 rounded border border-[#E7DED6]">
                  BB-TTMT-092
                </span>
              </div>
            </div>

            {/* GSAP SCAN LINE WIPE */}
            <div
              ref={scanLineRef}
              aria-hidden="true"
              className="pointer-events-none absolute top-0 bottom-0 w-[2.5px] bg-white shadow-[0_0_10px_rgba(255,255,255,0.9),0_0_3px_#B42318] z-20 -translate-x-1/2"
            />

            {/* MANUAL BEFORE / AFTER TOGGLE BUTTON (Appears once timeline done) */}
            {animationDone && (
              <button
                type="button"
                onClick={handleToggleView}
                className="absolute bottom-2.5 right-2.5 z-30 px-2.5 py-1 rounded-lg bg-white/95 hover:bg-white text-[#111827] border border-[#E7DED6] shadow-xs text-[11px] font-semibold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                title={lang === 'vi' ? 'Nhấn để chuyển đổi xem Before / After' : 'Toggle Before / After'}
              >
                <RotateCcw className="w-3 h-3 text-[#B42318]" />
                <span>
                  {activeView === 'after'
                    ? lang === 'vi'
                      ? 'Xem lúc phát hiện'
                      : 'View Before'
                    : lang === 'vi'
                    ? 'Xem sau xử lý'
                    : 'View After'}
                </span>
              </button>
            )}
          </div>

          {/* 6. THE 4-STAGE TIMELINE WITH ASSIGNMENT SLIDE-IN CHIP */}
          <div className="relative pl-6 py-1">
            {/* Background trace line */}
            <div className="absolute left-[7px] top-2 bottom-2 w-[2px] bg-[#E7DED6]" />

            {/* GSAP Growing Red Timeline Progress Bar */}
            <div
              ref={timelineBarRef}
              className="absolute left-[7px] top-2 bottom-2 w-[2px] bg-[#B42318] origin-top"
            />

            {/* 4 Discrete Lifecycle Nodes */}
            <div className="space-y-3">
              {stages.map((stage, idx) => (
                <div key={idx} className="relative flex items-center justify-between text-[13px]">
                  {/* Node Circle */}
                  <div
                    ref={(el) => (nodeRefs.current[idx] = el)}
                    className={`absolute -left-[23px] w-4 h-4 rounded-full flex items-center justify-center border-2 transition-colors ${
                      stage.isFinal
                        ? 'bg-white border-[#10B981] text-[#10B981]'
                        : 'bg-white border-[#B42318] text-[#B42318]'
                    }`}
                    style={{ opacity: 0.35, transform: 'scale(0.8)' }}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        stage.isFinal ? 'bg-[#10B981]' : 'bg-[#B42318]'
                      }`}
                    />
                  </div>

                  {/* Stage Label & Role */}
                  <div
                    ref={(el) => (labelRefs.current[idx] = el)}
                    className="flex items-center justify-between w-full pr-1"
                    style={{ opacity: 0.4, transform: 'translateX(-4px)' }}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-[11px] text-[#B42318]">
                        {stage.num}
                      </span>
                      <span
                        className={`font-semibold ${
                          stage.isFinal ? 'text-[#065F46] font-bold' : 'text-[#111827]'
                        }`}
                      >
                        {stage.title}
                      </span>
                      {/* Special Assignment Slide-in Chip for Node 02 */}
                      {idx === 1 && (
                        <span
                          ref={assignmentChipRef}
                          className="text-[10px] font-medium bg-[#FDE8E6] text-[#B42318] border border-[#F8D3D1] px-2 py-0.2 rounded-md tracking-tight flex items-center gap-1"
                        >
                          <ArrowRight className="w-2.5 h-2.5 text-[#B42318]" />
                          <span>{lang === 'vi' ? 'Đã chuyển xử lý' : 'Dispatched'}</span>
                        </span>
                      )}
                    </div>
                    <span className="font-mono text-[11px] text-[#7A6B62]">
                      {stage.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 7. CARD FOOTER — FINAL VERIFIED STATUS BANNER */}
        <div
          ref={footerRef}
          className="px-4 sm:px-6 py-3 bg-[#FAF6F0] rounded-b-[24px] border-t border-[#E7DED6] flex items-center justify-between gap-2 text-[11px] sm:text-[12px]"
        >
          <span
            ref={finalStatusTextRef}
            className="text-[#065F46] font-semibold flex items-center gap-1.5 truncate"
          >
            <Check className="w-4 h-4 text-[#10B981] stroke-[2.5] shrink-0" />
            <span className="truncate">
              {lang === 'vi' ? 'Đã hoàn tất bước tái kiểm' : 'Reinspection step completed'}
            </span>
          </span>
          <span className="text-[10px] sm:text-[11px] font-mono text-[#6B5F58] flex items-center gap-1 shrink-0">
            <Eye className="w-3 h-3 text-[#7A6B62]" />
            <span>{lang === 'vi' ? 'Minh chứng công khai' : 'Public audit'}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
