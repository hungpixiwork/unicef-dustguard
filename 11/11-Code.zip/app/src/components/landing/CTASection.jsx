import React from 'react';
import { LandingFooter } from './LandingFooter';

export function CTASection({ lang, onOpenDemo, onOpenEvidence, onOpenPilot }) {
  return (
    <footer className="landing-footer-container" id="cta">
      <div className="container">
        {/* Global Footer Navigation & Copyright */}
        <LandingFooter
          lang={lang}
          onOpenDemo={onOpenDemo}
          onOpenEvidence={onOpenEvidence}
          onOpenPilot={onOpenPilot}
        />
      </div>
    </footer>
  );
}

export default CTASection;
