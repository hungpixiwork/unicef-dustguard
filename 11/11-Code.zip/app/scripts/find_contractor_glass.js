import fs from 'fs';
const c = fs.readFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/src/modules/contractor/ContractorPortal.jsx', 'utf8');
c.split('\n').forEach((line, idx) => {
  if (/backdrop-blur|backdrop-filter|glass/i.test(line)) {
    console.log(`L${idx + 1}: ${line.trim()}`);
  }
});
