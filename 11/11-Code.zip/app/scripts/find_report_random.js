import fs from 'fs';
const content = fs.readFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/src/modules/citizen/CitizenReport.jsx', 'utf8');
const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('Math.random')) {
    console.log(`Line ${idx + 1}: ${line}`);
  }
});
