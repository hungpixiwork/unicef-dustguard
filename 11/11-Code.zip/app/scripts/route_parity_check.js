import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const APP_DIR = path.resolve(__dirname, '..');

const workerPath = path.join(APP_DIR, 'server', 'worker.js');
const workerContent = fs.readFileSync(workerPath, 'utf-8');

const apiDir = path.join(APP_DIR, 'server', 'routes', 'api');
const routeFiles = fs.readdirSync(apiDir);

console.log('=== CHECKING ROUTE PARITY (EXPRESS VS WORKER.JS) ===\n');

for (const file of routeFiles) {
  const filePath = path.join(apiDir, file);
  const content = fs.readFileSync(filePath, 'utf-8');
  const baseName = file.replace('.js', '');
  
  // Extract router.get, router.post, router.put, router.patch, router.delete
  const regex = /router\.(get|post|put|patch|delete)\s*\(\s*['"`]([^'"`]+)['"`]/g;
  let match;
  let missing = [];
  let total = 0;
  
  while ((match = regex.exec(content)) !== null) {
    total++;
    const method = match[1];
    const subPath = match[2];
    const fullPath = subPath === '/' ? `/api/${baseName}` : `/api/${baseName}${subPath}`;
    
    // Check if worker has this route
    const workerHasRoute = workerContent.includes(fullPath) || 
      (subPath === '/' && (workerContent.includes(`'/api/${baseName}'`) || workerContent.includes(`"/api/${baseName}"`)));
    
    if (!workerHasRoute) {
      // also test parameterized versions, e.g. /:id
      const genericPath = fullPath.replace(/:[a-zA-Z0-9_]+/g, ':');
      const inWorker = workerContent.includes(`/api/${baseName}`);
      missing.push({ method, fullPath });
    }
  }
  
  console.log(`[${file}] Total routes: ${total}, Potentially unmapped in worker.js: ${missing.length}`);
  if (missing.length > 0) {
    missing.forEach(m => console.log(`   - ${m.method.toUpperCase()} ${m.fullPath}`));
  }
}
