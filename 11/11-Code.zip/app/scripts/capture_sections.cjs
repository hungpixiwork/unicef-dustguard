const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

async function capture() {
  const outputDir = path.resolve(__dirname, 'debug_screenshots');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  let browser;
  try {
    browser = await chromium.launch({ channel: 'chrome' });
  } catch (e) {
    try {
      browser = await chromium.launch({ channel: 'msedge' });
    } catch (e2) {
      console.log('Falling back to default chromium...');
      browser = await chromium.launch();
    }
  }

  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 }
  });
  const page = await context.newPage();

  console.log('Navigating to http://127.0.0.1:3000 ...');
  await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });

  // Wait for reveal animations to finish
  await page.evaluate(() => {
    document.querySelectorAll('.dg-reveal').forEach(el => el.classList.add('show'));
  });
  await page.waitForTimeout(500);

  const sections = [
    { id: 'hero', name: '01_hero.png' },
    { id: 'problem', name: '02_problem.png' },
    { id: 'solution', name: '03_solution.png' },
    { id: 'how', name: '04_workflow.png' },
    { id: 'youth', name: '05_youth.png' },
    { id: 'technology', name: '06_technology.png' },
    { id: 'impact', name: '07_impact.png' },
    { id: 'cta', name: '08_cta_footer.png' }
  ];

  for (const sec of sections) {
    const el = page.locator(`#${sec.id}`);
    if (await el.count() > 0) {
      await el.scrollIntoViewIfNeeded();
      await page.waitForTimeout(300);
      await el.screenshot({ path: path.join(outputDir, sec.name) });
      console.log(`Saved ${sec.name}`);
    } else {
      console.log(`Section #${sec.id} not found!`);
    }
  }

  // Full page screenshot
  await page.screenshot({ path: path.join(outputDir, 'full_page_desktop.png'), fullPage: true });
  console.log('Saved full_page_desktop.png');

  // Also capture mobile viewport 390x844
  const mobileContext = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true
  });
  const mobilePage = await mobileContext.newPage();
  await mobilePage.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });
  await mobilePage.evaluate(() => {
    document.querySelectorAll('.dg-reveal').forEach(el => el.classList.add('show'));
  });
  await mobilePage.waitForTimeout(500);
  await mobilePage.screenshot({ path: path.join(outputDir, 'full_page_mobile.png'), fullPage: true });
  console.log('Saved full_page_mobile.png');

  await browser.close();
  console.log('Done capturing all screenshots!');
}

capture().catch(err => {
  console.error('Error during capture:', err);
  process.exit(1);
});
