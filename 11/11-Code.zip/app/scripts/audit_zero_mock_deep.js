import fs from 'fs';
import path from 'path';

const SRC_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/src');

function getFiles(dir, ext = ['.js', '.jsx', '.ts', '.tsx']) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git' && file !== 'dist') {
        results = results.concat(getFiles(fullPath, ext));
      }
    } else {
      if (ext.some(e => file.endsWith(e))) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

const files = getFiles(SRC_DIR);
console.log(`🔍 Scanning ${files.length} Frontend files for Zero-Mock Invariant #1 & #6 violations...\n`);

const findings = [];

files.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const relPath = path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app', file);
  const lines = content.split('\n');

  lines.forEach((lineText, idx) => {
    const lineNum = idx + 1;

    // 1. Hardcoded mock entities (e.g. const mockSites = [...], fallbackSites = [...], fakeData = [...])
    if (/const\s+(mock|fake|dummy|fallback)[A-Z0-9_]*\s*=\s*(\[|\{)/i.test(lineText)) {
      findings.push({
        file: relPath,
        line: lineNum,
        type: 'HARDCODED_MOCK_ENTITY',
        code: lineText.trim(),
        severity: 'HIGH'
      });
    }

    // 2. Mock fallback inside catch blocks (e.g. catch (err) { return [mockItem] })
    if (/catch\s*(\([^)]*\))?\s*\{[^}]*(mock|fake|dummy|\[\s*\{\s*id:)/i.test(lineText)) {
      findings.push({
        file: relPath,
        line: lineNum,
        type: 'CATCH_BLOCK_MOCK_FALLBACK',
        code: lineText.trim(),
        severity: 'HIGH'
      });
    }

    // 3. Fake Math.random in business data rendering
    if (/Math\.random\(\)/.test(lineText) && !file.includes('chart') && !file.includes('utils') && !file.includes('Canvas') && !file.includes('animation')) {
      findings.push({
        file: relPath,
        line: lineNum,
        type: 'MATH_RANDOM_BUSINESS_DATA',
        code: lineText.trim(),
        severity: 'MEDIUM'
      });
    }
  });
});

console.log(`=== AUDIT FINDINGS: ${findings.length} POTENTIAL VIOLATIONS ===\n`);
findings.forEach((f, i) => {
  console.log(`${i + 1}. [${f.type}] (${f.severity})`);
  console.log(`   File: ${f.file}:${f.line}`);
  console.log(`   Code: ${f.code}`);
  console.log('');
});
