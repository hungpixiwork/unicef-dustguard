import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/prisma/dev.db');
const db = new Database(dbPath);

console.log('=== D1 SQLITE REAL DATA INVENTORY ===');

const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma%'").all();
console.log(`Total Tables in dev.db: ${tables.length}`);

for (const t of tables) {
  try {
    const count = db.prepare(`SELECT COUNT(*) as count FROM "${t.name}"`).get().count;
    console.log(`Table [${t.name.padEnd(25)}]: ${String(count).padStart(5)} rows`);
  } catch (e) {
    console.log(`Table [${t.name.padEnd(25)}]: ERROR (${e.message})`);
  }
}
