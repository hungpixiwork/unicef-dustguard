import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('=== ALERTS IN DEV.DB ===');
const rows = db.prepare('SELECT id, siteId, pm10Value, status, severity, priorityReasons, evidenceUrls FROM alerts LIMIT 10').all();
console.log(rows);
console.log('Total count:', db.prepare('SELECT COUNT(*) as count FROM alerts').get());
