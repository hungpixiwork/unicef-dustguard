#!/usr/bin/env node
/**
 * DustGuard VN - High-Velocity Dev Runner (Windows & Cross-Platform SSOT)
 * Features:
 *  - Port conflict pre-check (Port 3000 & 8787)
 *  - Clean civic-tech startup banner
 *  - Deterministic process orchestration (Vite + Wrangler)
 *  - Graceful Windows cleanup (no zombie node/workerd processes)
 */
import { spawn, execSync } from 'node:child_process';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const args = process.argv.slice(2);
const isRemote = args.includes('--remote');
const isLocalOnly = args.includes('--local') || !isRemote;
const isDevEnv = args.includes('--env=development');

const WEB_PORT = 3000;
const API_PORT = 8787;
const HOST = '127.0.0.1';

// Colors
const cyan = '\x1b[36m';
const green = '\x1b[32m';
const yellow = '\x1b[33m';
const red = '\x1b[31m';
const bold = '\x1b[1m';
const dim = '\x1b[2m';
const reset = '\x1b[0m';

/**
 * Checks if a port is available on given host
 */
function isPortAvailable(port, host = '127.0.0.1') {
  return new Promise((resolve) => {
    const tester = net.createServer()
      .once('error', () => resolve(false))
      .once('listening', () => {
        tester.once('close', () => resolve(true)).close();
      })
      .listen(port, host);
  });
}

/**
 * Polls until a port is actively listening (connected) or timeout
 */
function waitForPort(port, host = '127.0.0.1', timeoutMs = 15000) {
  const startTime = Date.now();
  return new Promise((resolve) => {
    const check = () => {
      const socket = new net.Socket();
      socket.setTimeout(400);
      socket.once('connect', () => {
        socket.destroy();
        resolve(true);
      });
      socket.once('timeout', () => {
        socket.destroy();
        retry();
      });
      socket.once('error', () => {
        socket.destroy();
        retry();
      });
      socket.connect(port, host);
    };

    const retry = () => {
      if (Date.now() - startTime >= timeoutMs) {
        resolve(false);
      } else {
        setTimeout(check, 150);
      }
    };

    check();
  });
}

function printBanner() {
  console.log('\n' + bold + cyan + 'DustGuard Development' + reset);
  console.log(dim + '────────────────────────────────────────────' + reset);
  console.log(`  ${bold}Web${reset}       http://${HOST}:${WEB_PORT}`);
  console.log(`  ${bold}API${reset}       http://${HOST}:${API_PORT}`);
  console.log(`  ${bold}Health${reset}    http://${HOST}:${WEB_PORT}/api/health`);
  console.log('');
  console.log(`  ${bold}Runtime${reset}   Cloudflare Workers local (Wrangler v4)`);
  if (isRemote) {
    console.log(`  ${bold}D1${reset}        dustguard-production ${yellow}[REMOTE]${reset}`);
    console.log(`  ${bold}R2${reset}        dustguard-storage ${yellow}[REMOTE]${reset}`);
  } else if (isDevEnv) {
    console.log(`  ${bold}D1${reset}        dustguard-development ${cyan}[REMOTE DEV]${reset}`);
    console.log(`  ${bold}R2${reset}        dustguard-storage-development ${cyan}[REMOTE DEV]${reset}`);
  } else {
    console.log(`  ${bold}D1${reset}        dustguard-production ${dim}[LOCAL SIMULATED]${reset}`);
    console.log(`  ${bold}R2${reset}        dustguard-storage ${dim}[LOCAL SIMULATED]${reset}`);
  }
  console.log('');
  console.log(`  ${bold}AI${reset}        enabled`);
  console.log(`  ${bold}Simulator${reset} disabled`);
  console.log(dim + '────────────────────────────────────────────' + reset);
  console.log(green + 'Ready. Nhấn Ctrl+C để dừng toàn bộ hệ thống.' + reset + '\n');
}

async function main() {
  // 1. Port conflict check
  const [webAvailable, apiAvailable] = await Promise.all([
    isPortAvailable(WEB_PORT, HOST),
    isPortAvailable(API_PORT, HOST),
  ]);

  if (!webAvailable) {
    console.error(`\n${red}${bold}[LỖI XUNG ĐỘT PORT]${reset} Port ${WEB_PORT} đang bị chiếm bởi tiến trình khác.`);
    console.error(`Vui lòng giải phóng port ${WEB_PORT} (ví dụ: tắt ứng dụng cũ hoặc chạy taskkill /F /PID <pid>) trước khi khởi động.\n`);
    process.exit(1);
  }

  if (!apiAvailable) {
    console.error(`\n${red}${bold}[LỖI XUNG ĐỘT PORT]${reset} Port ${API_PORT} đang bị chiếm bởi tiến trình khác.`);
    console.error(`Vui lòng giải phóng port ${API_PORT} trước khi khởi động.\n`);
    process.exit(1);
  }

  printBanner();

  const isWin = process.platform === 'win32';
  const npxCmd = isWin ? 'npx.cmd' : 'npx';

  // 2. Prepare Worker Args
  let workerArgs = ['wrangler', 'dev', '--port', String(API_PORT), '--ip', HOST];
  if (isRemote) {
    workerArgs.push('--remote');
  } else if (isDevEnv) {
    workerArgs.push('--env', 'development');
  }

  const runningProcesses = [];

  function killTree(proc) {
    if (!proc || !proc.pid) return;
    try {
      if (isWin) {
        execSync(`taskkill /pid ${proc.pid} /T /F`, { stdio: 'ignore' });
      } else {
        process.kill(-proc.pid, 'SIGTERM');
      }
    } catch {
      try {
        proc.kill('SIGKILL');
      } catch {}
    }
  }

  let isShuttingDown = false;
  function shutdown(exitCode = 0) {
    if (isShuttingDown) return;
    isShuttingDown = true;
    console.log(`\n${yellow}Đang dừng sạch các tiến trình DustGuard...${reset}`);
    for (const proc of runningProcesses) {
      killTree(proc);
    }
    setTimeout(() => {
      process.exit(exitCode);
    }, 300);
  }

  process.on('SIGINT', () => shutdown(0));
  process.on('SIGTERM', () => shutdown(0));
  process.on('exit', () => shutdown(0));

  // 3. Spawn Worker Process
  const workerProc = spawn(npxCmd, workerArgs, {
    cwd: ROOT_DIR,
    stdio: ['inherit', 'pipe', 'pipe'],
    shell: isWin,
    env: { ...process.env, FORCE_COLOR: '1' }
  });
  runningProcesses.push(workerProc);

  workerProc.stdout?.on('data', (data) => {
    const text = data.toString();
    if (text.includes('Ready on') || text.includes('Starting local server') || text.includes('Serving at') || text.includes('wrangler') || text.includes('[SECURITY GUARD]') || text.includes('error') || text.includes('Error')) {
      process.stdout.write(`\x1b[34m[worker]\x1b[0m ${text}`);
    }
  });

  workerProc.stderr?.on('data', (data) => {
    const text = data.toString();
    process.stderr.write(`\x1b[31m[worker:err]\x1b[0m ${text}`);
  });

  workerProc.on('exit', (code) => {
    if (!isShuttingDown && code !== 0 && code !== null) {
      console.error(`${red}[worker] Tiến trình Worker thoát với mã: ${code}${reset}`);
      shutdown(code);
    }
  });

  // Wait for Worker API port to become active before starting Vite proxy
  await waitForPort(API_PORT, HOST, 15000);

  // 4. Spawn Vite Client Process
  const viteArgs = ['vite', '--host', HOST, '--port', String(WEB_PORT)];
  const webProc = spawn(npxCmd, viteArgs, {
    cwd: ROOT_DIR,
    stdio: ['inherit', 'pipe', 'pipe'],
    shell: isWin,
    env: { ...process.env, FORCE_COLOR: '1' }
  });
  runningProcesses.push(webProc);

  webProc.stdout?.on('data', (data) => {
    const text = data.toString();
    if (text.includes('VITE') || text.includes('Local:') || text.includes('ready in') || text.includes('page reload') || text.includes('hmr update')) {
      process.stdout.write(`\x1b[32m[web]\x1b[0m ${text}`);
    }
  });

  webProc.stderr?.on('data', (data) => {
    const text = data.toString();
    process.stderr.write(`\x1b[31m[web:err]\x1b[0m ${text}`);
  });

  webProc.on('exit', (code) => {
    if (!isShuttingDown && code !== 0 && code !== null) {
      console.error(`${red}[web] Tiến trình Vite thoát với mã: ${code}${reset}`);
      shutdown(code);
    }
  });
}

main().catch((err) => {
  console.error(`${red}[LỖI DEV RUNNER]: ${err.message}${reset}`);
  process.exit(1);
});
