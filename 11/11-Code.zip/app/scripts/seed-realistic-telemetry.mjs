import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('--- REFRESHING REALISTIC 24-HOUR TELEMETRY IN D1 DEV.DB ---');

// Xóa readings cũ để nạp chuỗi thời gian chuẩn xác
db.prepare('DELETE FROM sensor_readings').run();

const sensors = db.prepare('SELECT id, code, name FROM sensors').all();
const now = new Date();

// Mẫu biến thiên thực tế theo chu kỳ 24h tại công trường xây dựng đô thị (µg/m³)
// Sáng sớm (06-11h): Xe tải vào, đào đất đổ móng -> PM10 vọt cao (160-230), PM2.5 (80-125)
// Trưa (12-14h): Nghỉ ngơi, tưới nước dập bụi -> PM10 hạ (70-110), PM2.5 (35-60)
// Chiều (15-18h): Vận chuyển bê tông, san lấp -> PM10 tăng (140-190), PM2.5 (70-95)
// Tối & Đêm (19-05h): Thi công ca đêm hoặc tĩnh -> PM10 (50-85), PM2.5 (25-45)
const hourlyProfiles = [
  { hourOffset: 24, label: '12:00', pm25: 42, pm10: 88 },
  { hourOffset: 21, label: '15:00', pm25: 78, pm10: 165 },
  { hourOffset: 18, label: '18:00', pm25: 85, pm10: 178 },
  { hourOffset: 15, label: '21:00', pm25: 55, pm10: 110 },
  { hourOffset: 12, label: '00:00', pm25: 38, pm10: 72 },
  { hourOffset: 9,  label: '03:00', pm25: 32, pm10: 58 },
  { hourOffset: 6,  label: '06:00', pm25: 64, pm10: 135 },
  { hourOffset: 3,  label: '09:00', pm25: 96, pm10: 215 },
  { hourOffset: 0,  label: '12:00', pm25: 52, pm10: 105 }
];

const insertStmt = db.prepare(`
  INSERT INTO sensor_readings (id, sensorId, pm10, pm25, timestamp)
  VALUES (?, ?, ?, ?, ?)
`);

for (const sensor of sensors) {
  // Trạm cảnh báo (như TX-02, CG-03, HM-02) sẽ có hệ số nhân cao hơn
  const isHighRisk = sensor.code.includes('TX-02') || sensor.code.includes('CG-03') || sensor.code.includes('HM-02') || sensor.code.includes('MYD');
  const multiplier = isHighRisk ? 1.35 : 0.9;

  for (let i = 0; i < hourlyProfiles.length; i++) {
    const prof = hourlyProfiles[i];
    const readingTime = new Date(now.getTime() - prof.hourOffset * 3600 * 1000).toISOString();
    const readingId = `rd-${sensor.code.toLowerCase()}-${i}`;
    
    // Cộng chút nhiễu ngẫu nhiên ±10% để dữ liệu tự nhiên
    const randomNoise = (Math.sin(i * 1.5 + sensor.id.length) * 8);
    const pm10 = Math.max(25, Math.round(prof.pm10 * multiplier + randomNoise));
    const pm25 = Math.max(15, Math.round(prof.pm25 * multiplier + randomNoise * 0.5));

    insertStmt.run(readingId, sensor.id, pm10, pm25, readingTime);
  }
}

const totalReadings = db.prepare('SELECT COUNT(*) as count FROM sensor_readings').get();
console.log(`Successfully generated ${totalReadings.count} realistic sensor readings across ${sensors.length} stations!`);
