/**
 * Postgres to D1 Migration - Step 3: Load
 * Loads transformed JSON records into D1 / SQLite target database.
 */
import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';

const TRANSFORMED_DIR = path.join(process.cwd(), 'scripts/migrate-postgres-to-d1/transformed');

async function load() {
  console.log('📥 Starting Data Load into D1/SQLite Target...');

  if (!fs.existsSync(TRANSFORMED_DIR)) {
    console.error('❌ Transformed directory does not exist. Run transform.js first.');
    process.exit(1);
  }

  const prisma = new PrismaClient();
  const files = fs.readdirSync(TRANSFORMED_DIR).filter((f) => f.endsWith('.json') && f !== 'transform-summary.json');

  const loadStats = {};

  for (const file of files) {
    const tableName = file.replace('.json', '');
    const rows = JSON.parse(fs.readFileSync(path.join(TRANSFORMED_DIR, file), 'utf8'));

    if (rows.length === 0) {
      console.log(`ℹ️ Table ${tableName} is empty. Skipping.`);
      loadStats[tableName] = { inserted: 0, status: 'SKIPPED_EMPTY' };
      continue;
    }

    console.log(`⚡ Inserting into ${tableName} (${rows.length} rows)...`);
    let insertedCount = 0;
    let errorCount = 0;

    for (const row of rows) {
      try {
        if (prisma[tableName]) {
          await prisma[tableName].create({ data: row });
          insertedCount++;
        }
      } catch (err) {
        errorCount++;
        console.warn(`  ⚠️ Failed to insert row into ${tableName}: ${err.message}`);
      }
    }

    loadStats[tableName] = {
      total: rows.length,
      inserted: insertedCount,
      errors: errorCount,
      status: errorCount === 0 ? 'SUCCESS' : 'PARTIAL'
    };

    console.log(`  ✓ Inserted ${insertedCount}/${rows.length} rows into ${tableName}`);
  }

  fs.writeFileSync(
    path.join(TRANSFORMED_DIR, 'load-summary.json'),
    JSON.stringify(loadStats, null, 2)
  );

  console.log('✅ Load complete! Summary saved to transformed/load-summary.json');
  await prisma.$disconnect();
}

load().catch((err) => {
  console.error('Fatal error during loading:', err);
  process.exit(1);
});
