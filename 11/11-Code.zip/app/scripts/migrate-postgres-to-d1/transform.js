/**
 * Postgres to D1 Migration - Step 2: Transform
 * Normalizes PostgreSQL data for Cloudflare D1 (SQLite) storage.
 */
import fs from 'fs';
import path from 'path';

const STAGING_DIR = path.join(process.cwd(), 'scripts/migrate-postgres-to-d1/staging');
const TRANSFORMED_DIR = path.join(process.cwd(), 'scripts/migrate-postgres-to-d1/transformed');
const R2_MANIFEST_DIR = path.join(process.cwd(), 'scripts/migrate-postgres-to-d1/r2_manifests');

function transformRecord(record, tableName) {
  const transformed = { ...record };

  for (const [key, value] of Object.entries(transformed)) {
    if (value === null || value === undefined) {
      continue;
    }

    // 1. Date normalization to UTC ISO-8601 string
    if (value instanceof Date || (typeof value === 'string' && !isNaN(Date.parse(value)) && (key.endsWith('At') || key.endsWith('Date') || key === 'timestamp' || key === 'issuedDate' || key === 'effectiveDate'))) {
      const parsedDate = new Date(value);
      if (!isNaN(parsedDate.getTime())) {
        transformed[key] = parsedDate.toISOString();
      }
    }

    // 2. Binary / Buffer extraction for R2 boundary (LegalDocument.fileData)
    if (tableName === 'legalDocument' && key === 'fileData') {
      if (value && typeof value === 'object' && value.type === 'Buffer') {
        const buffer = Buffer.from(value.data);
        const objectKey = `legal-documents/${transformed.id || 'doc'}_${transformed.filename || 'file.bin'}`;

        if (!fs.existsSync(R2_MANIFEST_DIR)) {
          fs.mkdirSync(R2_MANIFEST_DIR, { recursive: true });
        }

        fs.writeFileSync(path.join(R2_MANIFEST_DIR, `${transformed.id}.bin`), buffer);

        // Replace fileData blob with objectKey reference for R2
        transformed.fileData = null;
        transformed.sourceUrl = transformed.sourceUrl || `/r2/${objectKey}`;
      }
    }

    // 3. Object / Array serialization to String for D1 TEXT fields
    if (typeof value === 'object' && !(value instanceof Date) && key !== 'fileData') {
      transformed[key] = JSON.stringify(value);
    }
  }

  return transformed;
}

function transform() {
  console.log('🔄 Starting Data Transformation for D1...');

  if (!fs.existsSync(STAGING_DIR)) {
    console.error('❌ Staging directory does not exist. Run extract.js first.');
    process.exit(1);
  }

  if (!fs.existsSync(TRANSFORMED_DIR)) {
    fs.mkdirSync(TRANSFORMED_DIR, { recursive: true });
  }

  const files = fs.readdirSync(STAGING_DIR).filter((f) => f.endsWith('.json') && f !== 'extract-summary.json');

  const transformStats = {};

  for (const file of files) {
    const tableName = file.replace('.json', '');
    const rawData = JSON.parse(fs.readFileSync(path.join(STAGING_DIR, file), 'utf8'));

    console.log(`🧹 Transforming ${tableName} (${rawData.length} rows)...`);
    const transformedData = rawData.map((row) => transformRecord(row, tableName));

    const outputPath = path.join(TRANSFORMED_DIR, file);
    fs.writeFileSync(outputPath, JSON.stringify(transformedData, null, 2));

    transformStats[tableName] = {
      originalRows: rawData.length,
      transformedRows: transformedData.length,
      status: 'READY_FOR_D1'
    };
  }

  fs.writeFileSync(
    path.join(TRANSFORMED_DIR, 'transform-summary.json'),
    JSON.stringify(transformStats, null, 2)
  );

  console.log('✅ Transformation complete! Summary saved to transformed/transform-summary.json');
}

transform();
