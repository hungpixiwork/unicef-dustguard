/**
 * Postgres to D1 Migration - Step 1: Extract
 * Extracts all table contents from PostgreSQL / Source Database into JSON staging files.
 */
import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';

const STAGING_DIR = path.join(process.cwd(), 'scripts/migrate-postgres-to-d1/staging');

async function extract() {
  console.log('🚀 Starting PostgreSQL Data Extraction...');

  if (!fs.existsSync(STAGING_DIR)) {
    fs.mkdirSync(STAGING_DIR, { recursive: true });
  }

  const prisma = new PrismaClient();

  const tables = [
    'user',
    'profile',
    'session',
    'account',
    'verification',
    'site',
    'complaint',
    'inspection',
    'evidence',
    'action',
    'draftDocument',
    'auditLog',
    'legalDocument',
    'legalObligation',
    'obligationChecklistMapping',
    'legalSegment',
    'sensor',
    'sensorReading',
    'alert',
    'alertNotification',
    'case',
    'caseTimeline',
    'contractorExplanation',
    'sanctionDecision',
    'documentRevision',
    'administrativeRegion',
    'administrativeUnit',
    'province',
    'ward'
  ];

  const summary = {};

  for (const table of tables) {
    try {
      if (prisma[table]) {
        console.log(`📦 Extracting table: ${table}...`);
        const data = await prisma[table].findMany();
        const filePath = path.join(STAGING_DIR, `${table}.json`);
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        summary[table] = data.length;
        console.log(`  ✓ Extracted ${data.length} rows to ${filePath}`);
      } else {
        console.warn(`  ⚠️ Model ${table} not found on Prisma client.`);
      }
    } catch (err) {
      console.error(`  ❌ Error extracting ${table}:`, err.message);
      summary[table] = { error: err.message };
    }
  }

  fs.writeFileSync(
    path.join(STAGING_DIR, 'extract-summary.json'),
    JSON.stringify(summary, null, 2)
  );

  console.log('✅ Extraction complete! Summary saved to staging/extract-summary.json');
  await prisma.$disconnect();
}

extract().catch((err) => {
  console.error('Fatal error during extraction:', err);
  process.exit(1);
});
