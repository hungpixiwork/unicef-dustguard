import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { pipeline } from 'stream/promises';

// Initialize Prisma Client
const prisma = new PrismaClient();

async function runBackup() {
  console.log('============================================');
  console.log('   STARTING SQLITE DATABASE AUTO-BACKUP   ');
  console.log('============================================');
  
  // Retrieve Database URL from environment
  const dbUrl = process.env.DATABASE_URL || 'file:./dev.db';
  console.log(`Database URL source: ${dbUrl}`);
  
  // Extract path to SQLite file
  let dbFilePath = dbUrl.replace(/^file:/, '');
  
  // Resolve absolute path
  dbFilePath = path.resolve(dbFilePath);
  console.log(`Target SQLite File path: ${dbFilePath}`);
  
  if (!fs.existsSync(dbFilePath)) {
    console.error(`[ERROR] Source database file does not exist at: ${dbFilePath}`);
    process.exit(1);
  }
  
  // Determine backup directory relative to the db file
  const dbDir = path.dirname(dbFilePath);
  const backupDir = path.join(dbDir, 'backups');
  
  if (!fs.existsSync(backupDir)) {
    console.log(`Creating backups folder at: ${backupDir}`);
    fs.mkdirSync(backupDir, { recursive: true });
  }
  
  // Generate backup filename with ISO timestamp (safe for Windows & Linux filesystems)
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const tempBackupPath = path.join(backupDir, `backup_${timestamp}.db`);
  const finalCompressedPath = `${tempBackupPath}.gz`;
  
  try {
    console.log(`Creating transaction-consistent DB snapshot via SQL 'VACUUM INTO'...`);
    // VACUUM INTO creates a hot backup copy safely without holding write-locks
    await prisma.$executeRawUnsafe(`VACUUM INTO '${tempBackupPath}'`);
    console.log(`Snapshot created at: ${tempBackupPath}`);
    
    // Compress backup using Gzip streaming to minimize disk footprint
    console.log(`Compressing snapshot into: ${finalCompressedPath}...`);
    const gzip = zlib.createGzip({ level: 9 });
    const sourceStream = fs.createReadStream(tempBackupPath);
    const destinationStream = fs.createWriteStream(finalCompressedPath);
    
    await pipeline(sourceStream, gzip, destinationStream);
    console.log(`Compression successful. File size: ${(fs.statSync(finalCompressedPath).size / 1024).toFixed(2)} KB`);
    
    // Clean up raw database backup copy
    fs.unlinkSync(tempBackupPath);
    console.log('Removed temporary uncompressed .db file.');
    
    // Enforce retention policy (keep last 10 backups)
    await cleanOldBackups(backupDir, 10);
    
    console.log('============================================');
    console.log('   SQLITE BACKUP COMPLETED SUCCESSFULLY     ');
    console.log('============================================');
  } catch (error) {
    console.error('[CRITICAL ERROR] Backup procedure failed:', error);
    
    // Clean up temporary files in case of error
    if (fs.existsSync(tempBackupPath)) {
      try { fs.unlinkSync(tempBackupPath); } catch (e) { /* ignore */ }
    }
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

async function cleanOldBackups(backupDir, keepCount = 10) {
  console.log(`Evaluating backup retention in ${backupDir} (Retention count: ${keepCount})...`);
  
  const files = fs.readdirSync(backupDir);
  
  // Filter for backup files
  const backupFiles = files
    .filter(file => file.startsWith('backup_') && file.endsWith('.db.gz'))
    .map(file => {
      const filePath = path.join(backupDir, file);
      const stat = fs.statSync(filePath);
      return {
        name: file,
        path: filePath,
        mtime: stat.mtime
      };
    });
    
  // Sort from newest to oldest
  backupFiles.sort((a, b) => b.mtime - a.mtime);
  console.log(`Total backup files present: ${backupFiles.length}`);
  
  if (backupFiles.length > keepCount) {
    const filesToDelete = backupFiles.slice(keepCount);
    console.log(`Pruning ${filesToDelete.length} old backup(s) exceeding retention limit...`);
    for (const file of filesToDelete) {
      fs.unlinkSync(file.path);
      console.log(`[PRUNED] Deleted old backup: ${file.name}`);
    }
  } else {
    console.log('No backup pruning required.');
  }
}

runBackup();
