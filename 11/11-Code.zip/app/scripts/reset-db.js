import '../server/env.js';
import { resetDemoData } from '../server/db/seed.js';

if (process.env.NODE_ENV === 'production' && process.env.ENABLE_MOCK_DATA !== 'true') {
  console.error('Refusing to reset operational mock data in production unless ENABLE_MOCK_DATA=true.');
  process.exit(1);
}

const result = await resetDemoData();
console.log(JSON.stringify(result, null, 2));
