import os
import cv2
from PIL import Image

def analyze_reference_screens():
    refs = [
        (1, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_37_58 21 thg 8, 2026 (1).png", "01_Hero"),
        (2, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_37_59 21 thg 8, 2026 (2).png", "02_Problem"),
        (3, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_37_59 21 thg 8, 2026 (3).png", "03_Solution"),
        (4, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_38_00 21 thg 8, 2026 (4).png", "04_Workflow"),
        (5, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_38_00 21 thg 8, 2026 (5).png", "05_Youth"),
        (6, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_38_01 21 thg 8, 2026 (6).png", "06_Technology"),
        (7, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_38_01 21 thg 8, 2026 (7).png", "07_Impact"),
        (8, r"C:\Users\ppnh1\Downloads\ChatGPT Image 22_38_01 21 thg 8, 2026 (8).png", "08_CTA_Footer")
    ]

    out_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_landing_refs"
    os.makedirs(out_dir, exist_ok=True)

    html = [
        "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Landing Page 8 Reference Sections</title>",
        "<style>body { font-family: sans-serif; background: #111; color: #fff; padding: 20px; }",
        ".sec { margin-bottom: 50px; background: #222; padding: 20px; border-radius: 10px; }",
        ".sec h2 { color: #f87171; margin-top: 0; }",
        ".sec img { max-width: 100%; height: auto; border: 1px solid #444; border-radius: 6px; display: block; }",
        "</style></head><body><h1>DustGuard VN — 8 Reference Sections Analysis</h1>"
    ]

    for num, path, name in refs:
        img = cv2.imread(path)
        h, w = img.shape[:2]
        dest_img = os.path.join(out_dir, f"{name}.png")
        cv2.imwrite(dest_img, img)
        html.append(f"<div class='sec'><h2>Section {num}: {name} ({w}x{h})</h2><img src='{name}.png'></div>")

    html.append("</body></html>")
    with open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write("\n".join(html))

    print(f"Generated reference analysis page in {out_dir}")

if __name__ == "__main__":
    analyze_reference_screens()
