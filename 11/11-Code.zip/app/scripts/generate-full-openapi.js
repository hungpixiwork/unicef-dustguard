import { readFileSync, writeFileSync } from 'fs';
import { openApiSpec } from '../server/docs/openapi.spec.js';

// 1. Add new tags
const newTags = [
  { name: 'Youth Community Action', description: 'Cổng hành động CLB/Thanh niên: Ghi nhận đa danh mục, Theo dõi lại, Chiến dịch và Handoff' },
  { name: 'Admin & System Data Management', description: 'Quản trị CSDL D1, xem trước và reset dữ liệu an toàn, nạp Canonical Seed' },
  { name: 'Cloudflare R2 Storage & Uploads', description: 'Tải lên minh chứng ảnh/tài liệu, định danh số SHA-256 và phục vụ qua CDN R2' },
  { name: 'Contractor Compliance Workspace', description: 'Không gian làm việc và khắc phục vi phạm dành cho Nhà thầu thi công (SSOT D1)' }
];

for (const t of newTags) {
  if (!openApiSpec.tags.some(existing => existing.name === t.name)) {
    openApiSpec.tags.push(t);
  }
}

// 2. Add new Schemas
openApiSpec.components.schemas = {
  ...openApiSpec.components.schemas,
  Community: {
    type: 'object',
    properties: {
      id: { type: 'string', example: 'comm_01' },
      name: { type: 'string', example: 'CLB Môi Trường Xanh UIT' },
      type: { type: 'string', enum: ['UNIVERSITY_CLUB', 'VOLUNTEER_TEAM', 'YOUTH_UNION', 'SCHOOL_TEAM'], example: 'UNIVERSITY_CLUB' },
      ward: { type: 'string', example: 'Linh Trung' },
      city: { type: 'string', example: 'TP. Hồ Chí Minh' },
      member_count: { type: 'number', example: 45 }
    }
  },
  Campaign: {
    type: 'object',
    properties: {
      id: { type: 'string', example: 'camp_01' },
      code: { type: 'string', example: 'CAMP-2026-SCHOOL-01' },
      title: { type: 'string', example: 'Chiến dịch Giám sát Bụi Quanh Trường Học Tháng 9' },
      topic: { type: 'string', example: 'SCHOOL_ZONE_DUST' },
      status: { type: 'string', enum: ['ACTIVE', 'COMPLETED', 'UPCOMING'], example: 'ACTIVE' },
      participant_count: { type: 'number', example: 28 },
      observation_count: { type: 'number', example: 64 }
    }
  },
  Observation: {
    type: 'object',
    properties: {
      id: { type: 'string', example: 'obs_01' },
      code: { type: 'string', example: 'OBS-2026-A1B2' },
      category: { type: 'string', enum: ['CONSTRUCTION_DUST', 'WASTE', 'WASTEWATER', 'OPEN_BURNING', 'AGRICULTURAL_CHEMICAL', 'AIR_QUALITY', 'OTHER'], example: 'CONSTRUCTION_DUST' },
      address: { type: 'string', example: 'Số 10 Trịnh Văn Bô, Nam Từ Liêm' },
      ward: { type: 'string', example: 'Xuân Phương' },
      city: { type: 'string', example: 'Hà Nội' },
      description: { type: 'string', example: 'Bụi công trường bay mù mịt khu vực cổng trường' },
      status: { type: 'string', enum: ['RECORDED', 'IN_PROGRESS', 'RESOLVED', 'REJECTED'], example: 'RECORDED' },
      evidences: { type: 'array', items: { type: 'object' } },
      created_at: { type: 'string', format: 'date-time' }
    }
  },
  FollowUp: {
    type: 'object',
    properties: {
      id: { type: 'string', example: 'fol_01' },
      observation_id: { type: 'string', example: 'obs_01' },
      outcome_status: { type: 'string', enum: ['BETTER', 'UNCHANGED', 'WORSE', 'UNKNOWN'], example: 'BETTER' },
      notes: { type: 'string', example: 'Đã có lưới che chắn và xe bồn tưới nước.' },
      verified_at: { type: 'string', format: 'date-time' }
    }
  },
  Handoff: {
    type: 'object',
    properties: {
      id: { type: 'string', example: 'hnd_01' },
      case_id: { type: 'string', example: 'case_001' },
      recipient_unit: { type: 'string', example: 'UBND Phường & Đội Thanh Tra Môi Trường' },
      channel: { type: 'string', enum: ['EMAIL', 'WEBSITE', 'HOTLINE', 'DIRECT', 'OTHER'], example: 'EMAIL' },
      status: { type: 'string', enum: ['PREPARED', 'SENT', 'ACKNOWLEDGED', 'FOLLOW_UP_NEEDED', 'CLOSED'], example: 'SENT' }
    }
  },
  SystemDataStats: {
    type: 'object',
    properties: {
      sites: { type: 'number', example: 12 },
      cases: { type: 'number', example: 7 },
      complaints: { type: 'number', example: 24 },
      sensors: { type: 'number', example: 8 },
      auditLogs: { type: 'number', example: 180 }
    }
  }
};

// 3. Complete all missing paths
const workerCode = readFileSync('server/worker.js', 'utf-8');
const contractorCode = readFileSync('server/routes/api/contractor.js', 'utf-8');

const routeMatches = [
  ...workerCode.matchAll(/app\.(get|post|put|patch|delete)\(['"]([^'"]+)['"]/g),
  ...[...contractorCode.matchAll(/router\.(get|post|put|patch|delete)\(['"]([^'"]+)['"]/g)].map(m => [m[0], m[1], `/api/contractor${m[2] === '/' ? '' : m[2]}`])
];
const workerEndpoints = [...new Set(routeMatches.map(m => `${m[1].toUpperCase()} ${m[2]}`))].filter(e => !e.includes('*'));

for (const ep of workerEndpoints) {
  const [method, path] = ep.split(' ');
  const openApiPath = path.replace(/:([a-zA-Z0-9_]+)/g, '{$1}');
  
  if (!openApiSpec.paths[openApiPath]) {
    openApiSpec.paths[openApiPath] = {};
  }
  
  if (!openApiSpec.paths[openApiPath][method.toLowerCase()]) {
    // Determine tag
    let tag = 'Public & GIS';
    if (path.includes('/community') || path.includes('/campaigns') || path.includes('/observations') || path.includes('/follow-ups') || path.includes('/handoffs') || path.includes('/environmental-categories')) {
      tag = 'Youth Community Action';
    } else if (path.includes('/admin')) {
      tag = 'Admin & System Data Management';
    } else if (path.includes('/upload') || path.includes('/storage') || path.includes('/uploads')) {
      tag = 'Cloudflare R2 Storage & Uploads';
    } else if (path.includes('/auth') || path.includes('/login') || path.includes('/register') || path.includes('/me') || path.includes('/logout')) {
      tag = 'Authentication & RBAC';
    } else if (path.includes('/health') || path.includes('/docs') || path.includes('/openapi')) {
      tag = 'System & Health';
    } else if (path.includes('/sites')) {
      tag = 'Sites & Monitoring';
    } else if (path.includes('/cases')) {
      tag = 'Case Management (DDD)';
    } else if (path.includes('/complaints') || path.includes('/public-complaints')) {
      tag = 'Citizen Reporting';
    } else if (path.includes('/sensors')) {
      tag = 'IoT Telemetry';
    } else if (path.includes('/csr')) {
      tag = 'CSR Escrow & DEMS';
    } else if (path.includes('/alerts')) {
      tag = 'Dashboard & Operations';
    } else if (path.includes('/legal') || path.includes('/documents')) {
      tag = 'Legal Documents & A4';
    } else if (path.includes('/contractor')) {
      tag = 'Contractor Compliance Workspace';
    } else if (path.includes('/actions') || path.includes('/inspections') || path.includes('/checklists')) {
      tag = 'Inspections & Actions';
    }

    // Extract parameters
    const params = [];
    const paramMatches = [...openApiPath.matchAll(/\{([a-zA-Z0-9_]+)\}/g)];
    for (const pm of paramMatches) {
      params.push({
        name: pm[1],
        in: 'path',
        required: true,
        schema: { type: 'string' },
        description: `Mã định danh ${pm[1]}`
      });
    }

    openApiSpec.paths[openApiPath][method.toLowerCase()] = {
      tags: [tag],
      summary: `${method.toUpperCase()} ${path} - Endpoint xử lý nghiệp vụ Cloudflare Edge`,
      parameters: params.length > 0 ? params : undefined,
      responses: {
        200: {
          description: 'Thành công',
          content: { 'application/json': { schema: { $ref: '#/components/schemas/StandardResponse' } } }
        },
        400: { description: 'Yêu cầu không hợp lệ (RFC 7807 Problem Details)' },
        401: { description: 'Chưa xác thực danh tính' },
        403: { description: 'Không đủ quyền hạn truy cập' }
      }
    };
  }
}

// 4. Write back to server/docs/openapi.spec.js
const fileContent = `/**
 * DustGuard VN - Comprehensive OpenAPI 3.0.3 Specification
 * Single Source of Truth for all API Contracts, Schemas, and Endpoints (100% Full Coverage)
 */

export const openApiSpec = ${JSON.stringify(openApiSpec, null, 2)};
`;

writeFileSync('server/docs/openapi.spec.js', fileContent, 'utf-8');
console.log('✅ Generated 100% Full Coverage OpenAPI 3.0.3 Spec!');
console.log(`Total Documented Paths: ${Object.keys(openApiSpec.paths).length}`);
