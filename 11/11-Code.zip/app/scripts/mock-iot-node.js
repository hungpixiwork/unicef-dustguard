#!/usr/bin/env node
/**
 * DustGuard VN — Mock IoT Node Simulator (SSOT Hardware Abstraction)
 * 
 * Simulates physical ESP32 IoT Nodes with cryptographic HMAC-SHA256 telemetry signing.
 * 
 * Usage:
 *   node scripts/mock-iot-node.js --scenario normal --count 5
 *   node scripts/mock-iot-node.js --scenario critical --count 10 --interval 1000
 *   node scripts/mock-iot-node.js --scenario tampered
 *   node scripts/mock-iot-node.js --scenario flatline --count 6
 *   node scripts/mock-iot-node.js --scenario recovery --count 8
 *   node scripts/mock-iot-node.js --interactive
 */

import crypto from 'crypto';

// Configuration defaults
const DEFAULTS = {
  url: process.env.DUSTGUARD_API_URL || 'http://127.0.0.1:3001/api/sensors/reading',
  sensorCode: process.env.DEVICE_SENSOR_CODE || 'SENSOR-VD1-01',
  secretKey: process.env.IOT_PRE_SHARED_KEY || 'dustguard_secret_key_2026',
  interval: 2000,
  count: 1,
  scenario: 'normal'
};

// Scenario generator profiles
export const SCENARIO_PROFILES = {
  normal: {
    name: 'Normal (Tiêu chuẩn an toàn)',
    pm25Range: [15.0, 28.0],
    pm10Range: [25.0, 48.0],
    description: 'Nồng độ bụi mịn nằm trong giới hạn an toàn QCVN 05:2023/BTNMT'
  },
  moderate: {
    name: 'Moderate (Cảnh báo nhẹ / Theo dõi)',
    pm25Range: [35.0, 55.0],
    pm10Range: [60.0, 95.0],
    description: 'Nồng độ bụi bắt đầu tăng nhẹ trong giờ cao điểm thi công'
  },
  high: {
    name: 'High (Bụi cao phát tán)',
    pm25Range: [75.0, 120.0],
    pm10Range: [130.0, 180.0],
    description: 'Bụi phát tán mạnh, kích hoạt ngưỡng cảnh báo vàng/đỏ'
  },
  critical: {
    name: 'Critical (Ô nhiễm cực kỳ nguy hại)',
    pm25Range: [150.0, 280.0],
    pm10Range: [220.0, 450.0],
    description: 'Bụi mịn vượt ngưỡng nghiêm trọng (>150 µg/m³), kích hoạt SLA khẩn cấp'
  },
  flatline: {
    name: 'Flatline (Cảm biến bị treo / Đơ số liệu)',
    pm25Fixed: 28.5,
    pm10Fixed: 55.0,
    description: 'Cảm biến gửi 5+ mẫu đo giống hệt nhau liên tiếp -> Cần phát hiện lỗi FAULTY'
  },
  tampered: {
    name: 'Tampered (Giả mạo chữ ký HMAC)',
    pm25Range: [20.0, 40.0],
    pm10Range: [40.0, 70.0],
    tamperSignature: true,
    description: 'Gói tin bị sửa đổi hoặc chữ ký HMAC không hợp lệ -> Hệ thống phải chặn 403'
  },
  offline: {
    name: 'Offline (Mất kết nối / Liveness Timeout)',
    stopAfter: 0,
    description: 'Không gửi bản tin đo kiểm -> Hệ thống chuyển trạng thái INACTIVE'
  },
  burst: {
    name: 'Burst (Đợt bão telemetry)',
    pm25Range: [80.0, 160.0],
    pm10Range: [140.0, 250.0],
    intervalMs: 100,
    description: 'Gửi liên tiếp các gói tin tốc độ cao kiểm tra năng lực chịu tải'
  },
  recovery: {
    name: 'Recovery (Khắc phục sau sự cố)',
    phases: [
      { count: 3, pm25Range: [160.0, 220.0], pm10Range: [240.0, 350.0] }, // Critical phase
      { count: 5, pm25Range: [18.0, 28.0], pm10Range: [30.0, 48.0] }       // Recovered phase
    ],
    description: 'Chuyển từ nồng độ bụi cao về an toàn sau khi nhà thầu phun sương dập bụi'
  }
};

/**
 * Generates a signed telemetry payload
 */
export function createSignedReading(options = {}) {
  const sensorCode = options.sensorCode || DEFAULTS.sensorCode;
  const secretKey = options.secretKey || DEFAULTS.secretKey;
  const pm10 = Number(options.pm10 !== undefined ? options.pm10 : 45.0);
  const pm25 = Number(options.pm25 !== undefined ? options.pm25 : 22.5);
  const timestamp = options.timestamp || new Date().toISOString();

  // SSOT Signing format: sensorCode:pm10:pm25:timestamp
  const message = `${sensorCode}:${pm10}:${pm25}:${timestamp}`;
  let signature = crypto.createHmac('sha256', secretKey).update(message).digest('hex');

  if (options.tampered) {
    signature = 'deadbeef_invalid_tampered_signature_9999';
  }

  return {
    sensorCode,
    pm10,
    pm25,
    timestamp,
    signature,
    meta: {
      firmwareVersion: '1.0.0',
      hardwareTarget: 'ESP32-APM2000-OLED',
      heapFree: 48664
    }
  };
}

/**
 * Transmits a reading to the Ingestion API endpoint
 */
export async function transmitReading(payload, endpointUrl = DEFAULTS.url) {
  const startTime = Date.now();
  try {
    const response = await fetch(endpointUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'DustGuard-ESP32-Node/1.0.0',
        'X-Device-Id': payload.sensorCode
      },
      body: JSON.stringify(payload)
    });

    const elapsed = Date.now() - startTime;
    const body = await response.json().catch(() => ({ message: 'Non-JSON response' }));

    return {
      ok: response.ok,
      status: response.status,
      elapsedMs: elapsed,
      response: body
    };
  } catch (error) {
    const elapsed = Date.now() - startTime;
    return {
      ok: false,
      status: 0,
      elapsedMs: elapsed,
      error: error.message
    };
  }
}

/**
 * Helper to generate random float between min and max
 */
function randomBetween(min, max) {
  return Number((Math.random() * (max - min) + min).toFixed(1));
}

/**
 * Runs a simulated scenario for a set count of iterations
 */
export async function runMockScenario(scenarioName = 'normal', options = {}) {
  const profile = SCENARIO_PROFILES[scenarioName] || SCENARIO_PROFILES.normal;
  const count = options.count || (scenarioName === 'burst' ? 10 : DEFAULTS.count);
  const interval = options.interval || (scenarioName === 'burst' ? 150 : DEFAULTS.interval);
  const url = options.url || DEFAULTS.url;
  const sensorCode = options.sensorCode || DEFAULTS.sensorCode;
  const secretKey = options.secretKey || DEFAULTS.secretKey;
  const quiet = options.quiet || false;

  if (!quiet) {
    console.log(`\n========================================================`);
    console.log(`📡 DUSTGUARD VN — MOCK IOT NODE SIMULATOR`);
    console.log(`========================================================`);
    console.log(`Target URL   : ${url}`);
    console.log(`Sensor Code  : ${sensorCode}`);
    console.log(`Scenario     : [${scenarioName.toUpperCase()}] ${profile.name}`);
    console.log(`Count / Gap  : ${count} gói tin / ${interval}ms`);
    console.log(`========================================================\n`);
  }

  if (scenarioName === 'offline') {
    if (!quiet) {
      console.log(`[OFFLINE] Kịch bản Offline: Dừng phát tín hiệu telemetry để kiểm tra liveness timeout.`);
    }
    return { scenario: 'offline', sent: 0, results: [] };
  }

  const results = [];

  for (let i = 1; i <= count; i++) {
    let pm25 = 25.0;
    let pm10 = 45.0;
    let isTampered = Boolean(profile.tamperSignature);

    if (scenarioName === 'flatline') {
      pm25 = profile.pm25Fixed;
      pm10 = profile.pm10Fixed;
    } else if (scenarioName === 'recovery') {
      // Phase 1: 1..3 high, Phase 2: 4..count safe
      if (i <= 3) {
        pm25 = randomBetween(160, 210);
        pm10 = randomBetween(240, 320);
      } else {
        pm25 = randomBetween(18, 28);
        pm10 = randomBetween(28, 45);
      }
    } else if (profile.pm25Range && profile.pm10Range) {
      pm25 = randomBetween(profile.pm25Range[0], profile.pm25Range[1]);
      pm10 = randomBetween(profile.pm10Range[0], profile.pm10Range[1]);
    }

    const payload = createSignedReading({
      sensorCode,
      secretKey,
      pm10,
      pm25,
      tampered: isTampered
    });

    const result = await transmitReading(payload, url);
    results.push({ iteration: i, payload, result });

    if (!quiet) {
      const statusIcon = result.ok ? '✅' : (isTampered && result.status === 403 ? '🛡️ (Rejected as Expected)' : '❌');
      const timeStr = new Date(payload.timestamp).toLocaleTimeString('vi-VN');
      console.log(`[#${i.toString().padStart(2, '0')}] ${timeStr} | PM2.5: ${pm25.toFixed(1).padStart(5)} | PM10: ${pm10.toFixed(1).padStart(5)} | HTTP ${result.status} ${statusIcon} (${result.elapsedMs}ms)`);
      if (!result.ok && (!isTampered || result.status !== 403)) {
        console.log(`     ↳ Response/Error: ${JSON.stringify(result.response || result.error)}`);
      }
    }

    if (i < count && interval > 0) {
      await new Promise(r => setTimeout(r, interval));
    }
  }

  if (!quiet) {
    const successCount = results.filter(r => r.result.ok || (profile.tamperSignature && r.result.status === 403)).length;
    console.log(`\n--------------------------------------------------------`);
    console.log(`Kết quả: ${successCount}/${count} gói tin đã truyền thành công.`);
    console.log(`--------------------------------------------------------\n`);
  }

  return { scenario: scenarioName, sent: count, results };
}

// CLI Execution entrypoint
async function main() {
  const args = process.argv.slice(2);
  const options = { ...DEFAULTS };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--scenario' || arg === '-s') {
      options.scenario = args[++i] || 'normal';
    } else if (arg === '--count' || arg === '-c') {
      options.count = parseInt(args[++i], 10) || 1;
    } else if (arg === '--interval' || arg === '-i') {
      options.interval = parseInt(args[++i], 10) || 2000;
    } else if (arg === '--url' || arg === '-u') {
      options.url = args[++i] || DEFAULTS.url;
    } else if (arg === '--sensor') {
      options.sensorCode = args[++i] || DEFAULTS.sensorCode;
    } else if (arg === '--secret') {
      options.secretKey = args[++i] || DEFAULTS.secretKey;
    } else if (arg === '--help' || arg === '-h') {
      console.log(`
DustGuard VN — Mock IoT Node CLI

Options:
  --scenario, -s  Kịch bản [normal, moderate, high, critical, flatline, offline, tampered, burst, recovery] (mặc định: normal)
  --count, -c     Số lượng gói tin gửi (mặc định: 1)
  --interval, -i  Khoảng cách thời gian giữa các gói (ms, mặc định: 2000)
  --url, -u       Endpoint Ingestion API (mặc định: ${DEFAULTS.url})
  --sensor        Mã cảm biến (mặc định: ${DEFAULTS.sensorCode})
  --secret        Khóa bí mật HMAC pre-shared key
  --help, -h      Hiển thị hướng dẫn
      `);
      process.exit(0);
    }
  }

  try {
    await runMockScenario(options.scenario, options);
  } catch (err) {
    console.error(`Lỗi khi chạy mock IoT node:`, err);
    process.exit(1);
  }
}

if (process.argv[1] && process.argv[1].endsWith('mock-iot-node.js')) {
  main();
}
