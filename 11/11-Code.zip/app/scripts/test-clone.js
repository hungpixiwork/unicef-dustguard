import { Client } from 'ssh2';

const vpsConfig = {
  host: '103.173.226.37',
  port: 22,
  username: 'root',
  password: 'a0NS1Y*Z1CrX1'
};

const conn = new Client();
conn.on('ready', () => {
  console.log('SSH Connection ready!');
  const commands = [
    'echo "=== PM2 LIST ==="',
    'pm2 list',
    'echo "=== PM2 LOGS ==="',
    'tail -n 100 /root/.pm2/logs/dustguard-error.log || echo "No logs found"',
    'tail -n 100 /root/.pm2/logs/dustguard-out.log || echo "No logs found"'
  ].join('\n');
  conn.exec(commands, (err, stream) => {
    if (err) {
      console.error(err);
      conn.end();
      return;
    }
    stream.on('close', (code) => {
      console.log(`Exit code: ${code}`);
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data);
    }).stderr.on('data', (data) => {
      process.stderr.write(data);
    });
  });
}).on('error', (err) => {
  console.error(err);
}).connect(vpsConfig);
