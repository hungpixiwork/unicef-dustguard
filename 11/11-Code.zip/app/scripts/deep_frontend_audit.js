import fs from 'fs';
import path from 'path';

const SRC_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/src');

function getFiles(dir, ext = ['.js', '.jsx', '.ts', '.tsx']) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git' && file !== 'dist') {
        results = results.concat(getFiles(fullPath, ext));
      }
    } else {
      if (ext.some(e => file.endsWith(e))) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

const frontendFiles = getFiles(SRC_DIR);

console.log(`Scanning ${frontendFiles.length} frontend files for detailed anti-mock & integration audit:`);

frontendFiles.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const relPath = path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app/src', file);
  
  // Check for mock data arrays / mock objects
  const mockMatches = content.match(/mock\w+|fake\w+|dummy\w+/gi);
  if (mockMatches) {
    console.log(`[MOCK IDENTIFIER] ${relPath}: ${[...new Set(mockMatches)].join(', ')}`);
  }

  // Check for Math.random
  if (content.includes('Math.random')) {
    console.log(`[MATH.RANDOM] ${relPath}`);
  }

  // Check for glassmorphism
  if (/backdrop-blur|backdrop-filter/i.test(content)) {
    console.log(`[GLASSMORPHISM] ${relPath}`);
  }

  // Check for hardcoded submit handler without API call
  // e.g., handleSubmit that only does alert() or toast() without fetch/api
  if (/const\s+handle(Submit|Create|Save|Send|Sign)\b/i.test(content) || /function\s+handle(Submit|Create|Save|Send|Sign)\b/i.test(content)) {
    // Check if it calls fetch or an API service
    if (!content.includes('fetch(') && !content.includes('apiClient') && !content.includes('apiService') && !content.includes('axios') && !content.includes('services/') && !content.includes('authClient')) {
      console.log(`[FORM SUBMIT NO API?] ${relPath}`);
    }
  }
});
