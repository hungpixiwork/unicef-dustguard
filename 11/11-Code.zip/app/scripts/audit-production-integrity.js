#!/usr/bin/env node
/**
 * ==============================================================================
 * DUSTGUARD VN — PRODUCTION DATABASE INTEGRITY & CONSISTENCY AUDITOR
 * Script: scripts/audit-production-integrity.js
 * ==============================================================================
 * Performs exhaustive end-to-end verification of Cloudflare D1 / SQLite database:
 * 1. PRAGMA integrity_check & foreign_key_check.
 * 2. Orphan records detection (complaints, sensors, cases, evidences, history).
 * 3. Enum & Foreign Key consistency across DB, Worker API, and Frontend.
 * 4. Case Status History & Timeline synchronization with Case status.
 * 5. Realistic distribution (24 sites, 5 critical/high, open complaints, overdue SLA, offline sensors).
 */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const dbPath = path.resolve('prisma/dev.db');

console.log('==============================================================================');
console.log('🛡️  DUSTGUARD VN — PRODUCTION DATA INTEGRITY & CONSISTENCY AUDIT');
console.log('==============================================================================');
console.log(`Database target: ${dbPath}`);

if (!fs.existsSync(dbPath)) {
  console.error(`❌ ERROR: Database file not found at ${dbPath}`);
  process.exit(1);
}

const db = new Database(dbPath);
let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assertCheck(category, checkName, condition, details = '') {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✅ [PASS] ${checkName} ${details ? `(${details})` : ''}`);
    return true;
  } else {
    failedTests++;
    console.error(`  ❌ [FAIL] ${checkName} ${details ? `— ${details}` : ''}`);
    return false;
  }
}

// ─── 1. CORE SQLITE INTEGRITY & PRAGMAS ────────────────────────────────────────
console.log('\n🔍 SECTION 1: SQLite Storage Engine & Foreign Keys Check');

const integrityResult = db.pragma('integrity_check', { simple: true });
assertCheck('SQLITE_CORE', 'PRAGMA integrity_check', integrityResult === 'ok', `Result: ${integrityResult}`);

const fkViolations = db.pragma('foreign_key_check');
assertCheck('SQLITE_CORE', 'PRAGMA foreign_key_check', fkViolations.length === 0, `Violations found: ${fkViolations.length}`);
if (fkViolations.length > 0) {
  console.error('     FK Violations detail:', JSON.stringify(fkViolations, null, 2));
}

// ─── 2. ORPHAN RECORDS AUDIT ──────────────────────────────────────────────────
console.log('\n🔍 SECTION 2: Orphan Records & Relational Integrity');

// 2.1 Complaints with non-existent siteId
const orphanComplaints = db.prepare(`
  SELECT count(*) as count FROM complaints
  WHERE siteId IS NOT NULL AND siteId NOT IN (SELECT id FROM sites)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Complaints (siteId reference)', orphanComplaints === 0, `${orphanComplaints} orphans`);

// 2.2 Sensors with non-existent siteId
const orphanSensors = db.prepare(`
  SELECT count(*) as count FROM sensors
  WHERE siteId IS NOT NULL AND siteId NOT IN (SELECT id FROM sites)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Sensors (siteId reference)', orphanSensors === 0, `${orphanSensors} orphans`);

// 2.3 Cases with non-existent siteId
const orphanCasesSite = db.prepare(`
  SELECT count(*) as count FROM cases
  WHERE siteId IS NOT NULL AND siteId NOT IN (SELECT id FROM sites)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Cases (siteId reference)', orphanCasesSite === 0, `${orphanCasesSite} orphans`);

// 2.4 Cases with non-existent complaintId
const orphanCasesComplaint = db.prepare(`
  SELECT count(*) as count FROM cases
  WHERE complaintId IS NOT NULL AND complaintId NOT IN (SELECT id FROM complaints)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Cases (complaintId reference)', orphanCasesComplaint === 0, `${orphanCasesComplaint} orphans`);

// 2.5 Evidences referencing invalid complaints
const orphanEvidencesComplaint = db.prepare(`
  SELECT count(*) as count FROM evidences
  WHERE complaintId IS NOT NULL AND complaintId NOT IN (SELECT id FROM complaints)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Evidences (complaintId reference)', orphanEvidencesComplaint === 0, `${orphanEvidencesComplaint} orphans`);

// 2.6 Evidences referencing invalid cases
const orphanEvidencesCase = db.prepare(`
  SELECT count(*) as count FROM evidences
  WHERE caseId IS NOT NULL AND caseId NOT IN (SELECT id FROM cases)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Evidences (caseId reference)', orphanEvidencesCase === 0, `${orphanEvidencesCase} orphans`);

// 2.7 Case Status History referencing invalid cases
const orphanStatusHistory = db.prepare(`
  SELECT count(*) as count FROM case_status_history
  WHERE caseId IS NOT NULL AND caseId NOT IN (SELECT id FROM cases)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Case Status History records', orphanStatusHistory === 0, `${orphanStatusHistory} orphans`);

// 2.8 Case Timelines referencing invalid cases
const orphanTimelines = db.prepare(`
  SELECT count(*) as count FROM case_timelines
  WHERE caseId IS NOT NULL AND caseId NOT IN (SELECT id FROM cases)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Case Timelines records', orphanTimelines === 0, `${orphanTimelines} orphans`);

// 2.9 Sensor Readings referencing invalid sensors
const orphanReadings = db.prepare(`
  SELECT count(*) as count FROM sensor_readings
  WHERE sensorId IS NOT NULL AND sensorId NOT IN (SELECT id FROM sensors)
`).get().count;
assertCheck('ORPHANS', 'Zero Orphan Sensor Readings', orphanReadings === 0, `${orphanReadings} orphans`);


// ─── 3. ENUM & DOMAIN ALIGNMENT (DB vs Worker vs Frontend) ────────────────────
console.log('\n🔍 SECTION 3: Enum Consistency across Database, Worker & Frontend');

const VALID_SITE_RISK_LEVELS = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'SAFE'];
const VALID_SITE_STATUS = ['ACTIVE', 'INACTIVE', 'SUSPENDED'];
const VALID_SENSOR_STATUS = ['ACTIVE', 'INACTIVE', 'OFFLINE', 'FAULTY', 'MAINTENANCE'];
const VALID_COMPLAINT_STATUS = ['PENDING', 'PROCESSING', 'INVESTIGATING', 'RESOLVED', 'REJECTED'];
const VALID_COMPLAINT_PRIORITY = ['LOW', 'MEDIUM', 'HIGH', 'URGENT', 'CRITICAL'];
const VALID_CASE_STATUS = ['SCREENING', 'PREPARING', 'DECISION_ISSUED', 'ON_SITE', 'REPORTING', 'APPRAISING', 'COMPLETED', 'VIOLATED', 'SANCTIONED', 'RESOLVED'];

// 3.1 Check site risk levels
const invalidSiteRisk = db.prepare(`
  SELECT count(*) as count FROM sites
  WHERE riskLevel NOT IN (${VALID_SITE_RISK_LEVELS.map(s => `'${s}'`).join(',')})
`).get().count;
assertCheck('ENUMS', 'Site riskLevel Enum Alignment', invalidSiteRisk === 0, `${invalidSiteRisk} invalid rows`);

// 3.2 Check site statuses
const invalidSiteStatus = db.prepare(`
  SELECT count(*) as count FROM sites
  WHERE status NOT IN (${VALID_SITE_STATUS.map(s => `'${s}'`).join(',')})
`).get().count;
assertCheck('ENUMS', 'Site status Enum Alignment', invalidSiteStatus === 0, `${invalidSiteStatus} invalid rows`);

// 3.3 Check sensor statuses
const invalidSensorStatus = db.prepare(`
  SELECT count(*) as count FROM sensors
  WHERE status NOT IN (${VALID_SENSOR_STATUS.map(s => `'${s}'`).join(',')})
`).get().count;
assertCheck('ENUMS', 'Sensor status Enum Alignment', invalidSensorStatus === 0, `${invalidSensorStatus} invalid rows`);

// 3.4 Check complaint statuses
const invalidComplaintStatus = db.prepare(`
  SELECT count(*) as count FROM complaints
  WHERE status NOT IN (${VALID_COMPLAINT_STATUS.map(s => `'${s}'`).join(',')})
`).get().count;
assertCheck('ENUMS', 'Complaint status Enum Alignment', invalidComplaintStatus === 0, `${invalidComplaintStatus} invalid rows`);

// 3.5 Check case statuses
const invalidCaseStatus = db.prepare(`
  SELECT count(*) as count FROM cases
  WHERE status NOT IN (${VALID_CASE_STATUS.map(s => `'${s}'`).join(',')})
`).get().count;
assertCheck('ENUMS', 'Case status Enum Alignment', invalidCaseStatus === 0, `${invalidCaseStatus} invalid rows`);


// ─── 4. CASE STATUS HISTORY & TIMELINE SYNCHRONIZATION ────────────────────────
console.log('\n🔍 SECTION 4: Case Status History & Timeline Synchronization');

const allCases = db.prepare('SELECT id, code, status FROM cases').all();
let caseSyncErrors = 0;

allCases.forEach(c => {
  // Get latest status history for this case
  const latestHistory = db.prepare(`
    SELECT toStatus, createdAt FROM case_status_history
    WHERE caseId = ?
    ORDER BY datetime(createdAt) DESC, id DESC
    LIMIT 1
  `).get(c.id);

  if (!latestHistory) {
    caseSyncErrors++;
    console.error(`     Case ${c.code} (${c.id}) has NO status history!`);
  } else if (latestHistory.toStatus !== c.status) {
    caseSyncErrors++;
    console.error(`     Case ${c.code} status mismatch: case.status = '${c.status}', latest history.toStatus = '${latestHistory.toStatus}'`);
  }
});

assertCheck(
  'HISTORY_SYNC',
  'Case Status History synchronization with cases.status',
  caseSyncErrors === 0,
  `${allCases.length} cases checked, ${caseSyncErrors} mismatches`
);

// Check that timelines exist for every case
const casesWithoutTimeline = db.prepare(`
  SELECT count(*) as count FROM cases
  WHERE id NOT IN (SELECT DISTINCT caseId FROM case_timelines)
`).get().count;
assertCheck('HISTORY_SYNC', 'Case Timelines synchronization', casesWithoutTimeline === 0, `${casesWithoutTimeline} cases missing timeline`);


// ─── 5. REALISTIC SEEDED DISTRIBUTION VERIFICATION ───────────────────────────
console.log('\n🔍 SECTION 5: Realistic Seeded Dataset Distribution');

// 5.1 Exactly 24 construction sites
const totalSites = db.prepare('SELECT count(*) as count FROM sites').get().count;
assertCheck('DISTRIBUTION', 'Total Construction Sites count == 24', totalSites === 24, `Found: ${totalSites}`);

// 5.2 At least 5 critical/high risk sites
const criticalHighSites = db.prepare(`
  SELECT count(*) as count FROM sites
  WHERE riskLevel IN ('CRITICAL', 'HIGH') OR dustRiskScore >= 80
`).get().count;
assertCheck('DISTRIBUTION', 'Critical/High risk sites >= 5', criticalHighSites >= 5, `Found: ${criticalHighSites} sites`);

// 5.3 Open complaints (PENDING, PROCESSING, INVESTIGATING)
const openComplaints = db.prepare(`
  SELECT count(*) as count FROM complaints
  WHERE status IN ('PENDING', 'PROCESSING', 'INVESTIGATING')
`).get().count;
assertCheck('DISTRIBUTION', 'Open Citizen Complaints >= 3', openComplaints >= 3, `Found: ${openComplaints} open complaints`);

// 5.4 Overdue SLA Cases
const overdueCases = db.prepare(`
  SELECT count(*) as count FROM cases
  WHERE slaDeadline IS NOT NULL
    AND datetime(slaDeadline) < datetime('now')
    AND status != 'COMPLETED'
`).get().count;
assertCheck('DISTRIBUTION', 'Overdue SLA Inspection Cases >= 1', overdueCases >= 1, `Found: ${overdueCases} overdue cases`);

// 5.5 Offline / Maintenance Sensors
const offlineSensors = db.prepare(`
  SELECT count(*) as count FROM sensors
  WHERE status IN ('OFFLINE', 'INACTIVE', 'MAINTENANCE')
`).get().count;
assertCheck('DISTRIBUTION', 'Offline / Non-active Sensors >= 2', offlineSensors >= 2, `Found: ${offlineSensors} offline sensors`);


// ─── FINAL AUDIT SUMMARY & SCORE ──────────────────────────────────────────────
console.log('\n==============================================================================');
console.log('📊 FINAL INTEGRITY AUDIT SUMMARY');
console.log('==============================================================================');
console.log(`Total Checks Executed : ${totalTests}`);
console.log(`Checks Passed         : ${passedTests}`);
console.log(`Checks Failed         : ${failedTests}`);
const passRate = ((passedTests / totalTests) * 100).toFixed(1);
console.log(`Integrity Score       : ${passRate}%`);

if (failedTests === 0 && passedTests === totalTests) {
  console.log('\n🎉 ALL INTEGRITY CHECKS PASSED 100% — D1 DATABASE READY FOR PRODUCTION.');
  console.log('==============================================================================\n');
  process.exit(0);
} else {
  console.error(`\n❌ INTEGRITY AUDIT FAILED with ${failedTests} issues. Please review logs above.`);
  console.log('==============================================================================\n');
  process.exit(1);
}
