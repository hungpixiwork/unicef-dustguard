import os
import re

def verify_paths():
    landing_assets_file = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\src\components\landing\landingAssets.js"
    with open(landing_assets_file, "r", encoding="utf-8") as f:
        content = f.read()

    paths = re.findall(r"/assets/landing/[^\'\"]+", content)
    base_public = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\public"
    
    missing = []
    found = []

    for p in sorted(set(paths)):
        full_p = os.path.normpath(base_public + p.replace("/", os.sep))
        if os.path.exists(full_p):
            found.append(p)
        else:
            missing.append(p)

    print(f"Total unique paths: {len(set(paths))}")
    print(f"Found on disk: {len(found)}")
    print(f"Missing on disk: {len(missing)}")
    if missing:
        print("\nMissing paths:")
        for m in missing:
            print(f"  - {m}")

if __name__ == "__main__":
    verify_paths()
