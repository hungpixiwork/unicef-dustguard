import os
import cv2
import numpy as np

def inspect_sheet2_icons():
    s2 = cv2.imread(r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png")
    h, w = s2.shape[:2]
    out_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets\s2_icons_verified"
    os.makedirs(out_dir, exist_ok=True)

    icon_names = [
        # Row 0
        ['icon-observe', 'icon-understand', 'icon-act', 'icon-follow-up', 'icon-impact', 'icon-image', 'icon-gps-pin', 'icon-feedback-chat'],
        # Row 1
        ['icon-construction-hazard', 'icon-alert-warning', 'icon-signal-wifi', 'icon-smartphone-location', 'icon-checklist-pie', 'icon-dashboard-metrics', 'icon-growth-chart', 'icon-target-risk'],
        # Row 2
        ['icon-flag-priority', 'icon-document-evidence', 'icon-history-log', 'icon-folder-archive', 'icon-user-volunteer', 'icon-community-group', 'icon-heart-care', 'icon-handshake-collab'],
        # Row 3
        ['icon-checklist-verify', 'icon-refresh-sync', 'icon-shield-check', 'icon-shield-sparkle', 'icon-government-institution', 'icon-shield-lock', 'icon-cloud-network', 'icon-iot-gateway'],
        # Row 4
        ['icon-sensor-pod', 'icon-sensor-pole-standard', 'icon-sensor-pole-solar', 'icon-kiosk-station', 'icon-kiosk-solar', 'icon-city-skyline', 'icon-bridge-river', 'icon-trees-forest'],
        # Row 5
        ['icon-tree-sapling', 'icon-civic-shield-badge', 'icon-mobile-tracking', 'icon-desktop-analytics', 'icon-timeline-steps', 'icon-multi-branch-arrow', 'icon-report-pie-chart', 'icon-database-storage'],
        # Row 6
        ['icon-trend-bars', 'icon-trend-line', 'icon-dust-particle-cluster', 'icon-sensor-hanging', 'icon-sensor-handheld', 'icon-workflow-gear', 'icon-civic-team', 'icon-verified-officer']
    ]

    col_w = w / 8.0
    row_h = h / 7.0

    html = ["<!DOCTYPE html><html><head><style>body{background:#222;color:#fff;font-family:sans-serif;}",
            ".grid{display:grid;grid-template-columns:repeat(8, 1fr);gap:10px;padding:20px;}",
            ".cell{background:#fff;color:#000;border-radius:6px;padding:10px;text-align:center;}",
            ".cell img{height:90px;max-width:100%;object-fit:contain;background:#f5f5f5;display:block;margin:0 auto;}",
            ".cell span{font-size:11px;display:block;margin-top:6px;word-break:break-all;}",
            "</style></head><body><h2>Sheet 2: 56 Icons Verification</h2><div class='grid'>"]

    for r in range(7):
        for c in range(8):
            name = icon_names[r][c]
            # Center of the cell
            cx = (c + 0.5) * col_w
            cy = (r + 0.5) * row_h
            
            # Crop a 160x140 area around cell center
            x0 = max(0, int(cx - 75))
            x1 = min(w, int(cx + 75))
            y0 = max(0, int(cy - 65))
            y1 = min(h, int(cy + 65))
            
            crop = s2[y0:y1, x0:x1]
            fname = f"r{r}_c{c}_{name}.png"
            cv2.imwrite(os.path.join(out_dir, fname), crop)
            html.append(f"<div class='cell'><img src='{fname}'><span>{name}</span></div>")

    html.append("</div></body></html>")
    with open(os.path.join(out_dir, "preview.html"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(html))

    print("Generated icons preview in s2_icons_verified")

if __name__ == "__main__":
    inspect_sheet2_icons()
