import fs from 'fs';
import path from 'path';

const ROOT = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app');
const SRC_DIR = path.join(ROOT, 'src');
const SERVER_DIR = path.join(ROOT, 'server');
const PRISMA_DIR = path.join(ROOT, 'prisma');
const TESTS_DIR = path.join(ROOT, 'tests');

function scanDir(dir, ignore = ['node_modules', '.git', 'dist', '.wrangler']) {
  let files = [];
  try {
    const list = fs.readdirSync(dir);
    for (const item of list) {
      if (ignore.includes(item)) continue;
      const full = path.join(dir, item);
      const stat = fs.statSync(full);
      if (stat.isDirectory()) {
        files = files.concat(scanDir(full, ignore));
      } else {
        files.push(full);
      }
    }
  } catch (e) {}
  return files;
}

const allFiles = scanDir(ROOT);

// Extensions breakdown
const extMap = {};
let totalLines = 0;
const folderMap = {};

for (const file of allFiles) {
  const rel = path.relative(ROOT, file).replace(/\\/g, '/');
  const ext = path.extname(file) || 'no-ext';
  let lines = 0;
  try {
    const content = fs.readFileSync(file, 'utf8');
    lines = content.split('\n').length;
  } catch (e) {}

  totalLines += lines;
  extMap[ext] = (extMap[ext] || { count: 0, lines: 0 });
  extMap[ext].count++;
  extMap[ext].lines += lines;

  // Folder level (e.g. src/modules, src/apps, server/routes)
  const parts = rel.split('/');
  const topFolder = parts.length > 1 ? parts.slice(0, 2).join('/') : parts[0];
  folderMap[topFolder] = (folderMap[topFolder] || { count: 0, lines: 0 });
  folderMap[topFolder].count++;
  folderMap[topFolder].lines += lines;
}

console.log('=== 1. CODEBASE STATS ===');
console.log(`Total Files: ${allFiles.length}`);
console.log(`Total LOC: ${totalLines}\n`);

console.log('=== FOLDER BREAKDOWN ===');
Object.entries(folderMap)
  .sort((a, b) => b[1].lines - a[1].lines)
  .forEach(([f, data]) => {
    const pct = ((data.lines / totalLines) * 100).toFixed(2);
    console.log(`${f.padEnd(35)} : ${String(data.count).padStart(5)} files | ${String(data.lines).padStart(8)} LOC (${pct}%)`);
  });

console.log('\n=== EXTENSION BREAKDOWN ===');
Object.entries(extMap)
  .sort((a, b) => b[1].lines - a[1].lines)
  .forEach(([ext, data]) => {
    const pct = ((data.lines / totalLines) * 100).toFixed(2);
    console.log(`${ext.padEnd(15)} : ${String(data.count).padStart(5)} files | ${String(data.lines).padStart(8)} LOC (${pct}%)`);
  });
