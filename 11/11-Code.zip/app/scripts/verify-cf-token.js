import { execSync } from 'child_process';
import https from 'https';

/**
 * Script kiểm tra và xác thực Cloudflare Scoped Token cho DustGuard VN
 * Sử dụng:
 *   node scripts/verify-cf-token.js <API_TOKEN>
 * Hoặc tự lấy từ biến môi trường CLOUDFLARE_API_TOKEN / CF_API_TOKEN
 */

const ACCOUNT_ID = process.env.CLOUDFLARE_ACCOUNT_ID || '5fdd1d1433519df6429d7418d43fff9a';
const D1_DB_ID = 'ad40205a-ec4b-40f3-8ab2-c2e7b9e78699';
const D1_DB_NAME = 'dustguard-production';

const token = process.argv[2] || process.env.CLOUDFLARE_API_TOKEN || process.env.CF_API_TOKEN;

console.log('====================================================');
console.log('🛡️  DUSTGUARD VN - CLOUDFLARE TOKEN VERIFICATION TOOL');
console.log('====================================================');
console.log(`📌 Account ID: ${ACCOUNT_ID}`);
console.log(`📌 D1 Database: ${D1_DB_NAME} (${D1_DB_ID})`);
console.log('----------------------------------------------------');

if (!token) {
  console.log('ℹ️  Chưa truyền token trực tiếp. Đang kiểm tra phiên Wrangler hiện tại...\n');
  try {
    const whoami = execSync('npx wrangler whoami', { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
    console.log('✅ Wrangler CLI đang hoạt động bình thường với tài khoản:');
    const emailMatch = whoami.match(/associated with the email ([\w.-]+@[\w.-]+)/);
    if (emailMatch) console.log(`   📧 Email: ${emailMatch[1]}`);
    console.log('\n💡 Để kiểm tra Scoped API Token mới tạo, hãy chạy:');
    console.log('   node scripts/verify-cf-token.js <YOUR_NEW_API_TOKEN>\n');
  } catch (err) {
    console.error('❌ Lỗi kiểm tra wrangler:', err.message);
  }
  process.exit(0);
}

function cfFetch(endpoint) {
  return new Promise((resolve, reject) => {
    const req = https.request(`https://api.cloudflare.com/client/v4${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'User-Agent': 'DustGuard-Token-Verifier/1.0'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

async function verifyToken() {
  console.log(`🔑 Đang kiểm tra Scoped Token: ${token.substring(0, 8)}...${token.slice(-4)}\n`);

  // 1. Kiểm tra Token Validity
  console.log('1️⃣ Kiểm tra trạng thái Token...');
  const tokenVerify = await cfFetch('/user/tokens/verify');
  if (tokenVerify.status === 200 && tokenVerify.body?.success) {
    console.log('   ✅ Token hợp lệ! Trạng thái:', tokenVerify.body.result?.status);
  } else {
    console.log(`   ⚠️ Trạng thái phản hồi: ${tokenVerify.status}`);
    if (tokenVerify.body?.errors) {
      console.log('   Chi tiết:', JSON.stringify(tokenVerify.body.errors));
    }
  }

  // 2. Kiểm tra quyền truy cập D1
  console.log('\n2️⃣ Kiểm tra quyền truy cập D1 Databases...');
  const d1Res = await cfFetch(`/accounts/${ACCOUNT_ID}/d1/database`);
  if (d1Res.status === 200 && d1Res.body?.success) {
    const dbs = d1Res.body.result || [];
    const hasDustguard = dbs.some(d => d.name === D1_DB_NAME || d.uuid === D1_DB_ID);
    console.log(`   ✅ Đọc thành công danh sách D1 (${dbs.length} databases).`);
    if (hasDustguard) {
      console.log(`   🎯 Đã tìm thấy database "${D1_DB_NAME}"!`);
    } else {
      console.log(`   ⚠️ Chưa thấy database "${D1_DB_NAME}" trong phạm vi quyền của token.`);
    }
  } else {
    console.log(`   ❌ Không thể đọc D1 (HTTP ${d1Res.status})`);
  }

  // 3. Kiểm tra quyền truy cập Workers Scripts
  console.log('\n3️⃣ Kiểm tra quyền truy cập Workers Scripts...');
  const workersRes = await cfFetch(`/accounts/${ACCOUNT_ID}/workers/scripts`);
  if (workersRes.status === 200 && workersRes.body?.success) {
    const scripts = workersRes.body.result || [];
    console.log(`   ✅ Đọc thành công danh sách Workers (${scripts.length} scripts).`);
  } else {
    console.log(`   ⚠️ Phản hồi Workers Scripts: HTTP ${workersRes.status}`);
  }

  console.log('\n====================================================');
  console.log('🎉 Kiểm tra hoàn tất!');
  console.log('====================================================');
}

verifyToken().catch(err => {
  console.error('❌ Lỗi thực thi kiểm tra:', err);
});
