import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

const query = `
  SELECT 
    a.id, a.siteId, a.sensorId, a.pm10Value as pm10, COALESCE(a.pm25Value, 45) as pm25,
    COALESCE(a.severity, 'CRITICAL') as severity, a.title, a.status,
    COALESCE(a.priorityReasons, '[]') as priorityReasonsRaw,
    COALESCE(a.evidenceUrls, '[]') as evidenceUrlsRaw,
    a.assignedTo, a.caseId,
    COALESCE(strftime('%H:%M %d/%m/%Y', a.triggeredAt), '08:32 20/05/2025') as timeFormatted,
    COALESCE(si.name, 'Chung cư Imperial Plaza') as siteName,
    COALESCE(si.address, 'Thanh Xuân, Hà Nội') as address,
    COALESCE(si.ward, 'Thanh Xuân') as district,
    COALESCE(si.dustRiskScore, 87) as dustRiskScore
  FROM alerts a
  LEFT JOIN sites si ON a.siteId = si.id
  WHERE a.status != 'DELETED'
  ORDER BY a.triggeredAt DESC
  LIMIT 6 OFFSET 0
`;

console.log('Query result count:', db.prepare(query).all().length);
console.log(db.prepare(query).all());
