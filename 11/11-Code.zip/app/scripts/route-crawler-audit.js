/**
 * DustGuard VN — Automated Route Crawler & Browser Smoke Audit
 * 
 * Crawls 100% of Static & Dynamic Routes using Playwright headless browser:
 * - Detects Unhandled Javascript Runtime Exceptions (TypeError, ReferenceError, Cannot read property of undefined)
 * - Detects Blank Screens & React Rendering Crashes
 * - Detects Broken Routes / Missing Chunks
 * - Injects Role Authentication Contexts
 * - Tests Multi-Viewport Responsive Layouts (Mobile, Tablet, Desktop)
 */

import { spawn } from 'child_process';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { chromium } from 'playwright';
import expressApp from '../server/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

let PORT = 3000;
let BASE_URL = `http://127.0.0.1:${PORT}`;

// Complete Route Inventory with associated Test Personas & Dynamic Sample IDs
export const CRAWLER_ROUTES = [
  // 1. PUBLIC & AUTH
  { path: '/', role: 'public', name: 'Landing Page' },
  { path: '/landing', role: 'public', name: 'Landing Page Alias' },
  { path: '/login', role: 'public', name: 'Login Screen' },
  { path: '/register', role: 'public', name: 'Register Screen' },
  { path: '/unauthorized', role: 'public', name: 'Unauthorized Page' },
  { path: '/docs/sensor-guide', role: 'public', name: 'Sensor Installation Guide' },
  { path: '/youth', role: 'public', name: 'Youth Credits Hub' },
  { path: '/youth/credits', role: 'public', name: 'Youth Credits Details' },
  { path: '/youth/leaderboard', role: 'public', name: 'Youth Leaderboard' },

  // 2. CITIZEN & YOUTH MINI-PRODUCT
  { path: '/citizen', role: 'citizen', name: 'Citizen Portal' },
  { path: '/citizen/dashboard', role: 'citizen', name: 'Citizen Dashboard' },
  { path: '/citizen/report', role: 'citizen', name: 'Citizen Report' },
  { path: '/citizen/report/new', role: 'citizen', name: 'Citizen New Report' },
  { path: '/citizen/reports', role: 'citizen', name: 'Citizen Reports List' },
  { path: '/citizen/reports/DG-2026-0001', role: 'citizen', name: 'Citizen Report Track Detail' },
  { path: '/citizen/track', role: 'citizen', name: 'Citizen Tracking' },
  { path: '/citizen/track/DG-2026-0001', role: 'citizen', name: 'Citizen Tracking by Code' },
  { path: '/citizen/map', role: 'citizen', name: 'Citizen Air Quality Map' },
  { path: '/citizen/nearby', role: 'citizen', name: 'Citizen Nearby Air Quality Scanner' },
  { path: '/citizen/missions', role: 'citizen', name: 'Citizen Missions' },
  { path: '/citizen/credits', role: 'citizen', name: 'Citizen Youth Credits' },
  { path: '/citizen/activity', role: 'citizen', name: 'Citizen Activity Log' },
  { path: '/citizen/rewards', role: 'citizen', name: 'Citizen Rewards Redemption' },
  { path: '/citizen/campaigns', role: 'citizen', name: 'Citizen Campaigns List' },
  { path: '/citizen/impact', role: 'citizen', name: 'Citizen Impact Summary' },
  { path: '/citizen/notifications', role: 'citizen', name: 'Citizen Notification Center' },
  { path: '/citizen/profile', role: 'citizen', name: 'Citizen Profile & Privacy' },

  // 3. COMMUNITY ACTION & YOUTH
  { path: '/community', role: 'citizen', name: 'Community Action Home' },
  { path: '/community/discover', role: 'citizen', name: 'Community Discover Campaigns & Clubs' },
  { path: '/community/campaigns', role: 'citizen', name: 'Community Campaigns' },
  { path: '/community/campaigns/camp_school_2026', role: 'citizen', name: 'Community Campaign Detail' },
  { path: '/community/observe', role: 'citizen', name: 'Create Observation' },
  { path: '/community/observations', role: 'citizen', name: 'Observations List' },
  { path: '/community/observations/obs_01', role: 'citizen', name: 'Observation Space & Evidence Detail' },
  { path: '/community/cases', role: 'citizen', name: 'Community Cases List' },
  { path: '/community/cases/case_01', role: 'citizen', name: 'Community Case Workspace' },
  { path: '/community/actions', role: 'citizen', name: 'Community Action Tasks' },
  { path: '/community/follow-ups', role: 'citizen', name: 'Community Follow-up Monitoring' },
  { path: '/community/impact', role: 'citizen', name: 'Community Collective Impact' },

  // 4. CONTRACTOR WORKSPACE (INCLUDES TARGET SYMPTOM REPRODUCTION)
  { path: '/contractor', role: 'contractor', name: 'Contractor Hub' },
  { path: '/contractor/dashboard', role: 'contractor', name: 'Contractor Dashboard' },
  { path: '/contractor/projects', role: 'contractor', name: 'Contractor Projects List' },
  { path: '/contractor/projects/site-vd1-001', role: 'contractor', name: 'Contractor Project Detail (Site VD1-001 - Target Test)' },
  { path: '/contractor/projects/site_tx_02', role: 'contractor', name: 'Contractor Project Detail (Site TX-02)' },
  { path: '/contractor/sites', role: 'contractor', name: 'Contractor Sites' },
  { path: '/contractor/sites/site_tx_02', role: 'contractor', name: 'Contractor Site Detail Alias' },
  { path: '/contractor/actions', role: 'contractor', name: 'Contractor Action Items List' },
  { path: '/contractor/actions/act_2026_089', role: 'contractor', name: 'Contractor Action Item Detail' },
  { path: '/contractor/actions/act_sample_01', role: 'contractor', name: 'Contractor Action Sample Detail' },
  { path: '/contractor/evidence', role: 'contractor', name: 'Contractor Evidence Library' },
  { path: '/contractor/notifications', role: 'contractor', name: 'Contractor Notifications' },
  { path: '/contractor/portal', role: 'contractor', name: 'Contractor Zero-Login Portal' },

  // 5. STAFF & INSPECTOR WORKSPACE
  { path: '/staff/dashboard', role: 'staff', name: 'Staff Operations Command Center' },
  { path: '/staff/monitoring', role: 'staff', name: 'Staff Live Environmental Monitoring' },
  { path: '/staff/cases', role: 'staff', name: 'Staff Case Management' },
  { path: '/staff/cases/case_01', role: 'staff', name: 'Staff Case Detail Workspace' },
  { path: '/staff/map', role: 'staff', name: 'Staff GIS Hotspot Map' },
  { path: '/staff/profile', role: 'staff', name: 'Staff User Profile' },
  { path: '/staff/complaints', role: 'staff', name: 'Staff Complaints Inbox' },
  { path: '/staff/inspections', role: 'staff', name: 'Staff Field Inspections' },
  { path: '/staff/sla', role: 'staff', name: 'Staff SLA Tracking' },
  { path: '/staff/sites', role: 'staff', name: 'Staff Sites Management' },
  { path: '/staff/sites/site-vd1', role: 'staff', name: 'Staff Site Detail (Site VD1)' },
  { path: '/staff/sites/site-vd1/sensors', role: 'staff', name: 'Staff Site Sensors Tab' },
  { path: '/staff/sites/site-vd1/inspections', role: 'staff', name: 'Staff Site Inspections Tab' },
  { path: '/staff/sites/site-vd1/legal', role: 'staff', name: 'Staff Site Legal Engine Tab' },
  { path: '/staff/alerts', role: 'staff', name: 'Staff Sensor Alerts & Fraud Detection' },
  { path: '/staff/incidents', role: 'staff', name: 'Staff Incidents Alias' },
  { path: '/staff/ai', role: 'staff', name: 'Staff AI Report Hub' },
  { path: '/staff/documents', role: 'staff', name: 'Staff Legal Documents List' },
  { path: '/staff/documents/new', role: 'staff', name: 'Staff New Document Editor' },
  { path: '/staff/templates', role: 'staff', name: 'Staff Document Templates Gallery' },
  { path: '/staff/settings', role: 'staff', name: 'Staff System Settings' },
  { path: '/staff/data-management', role: 'staff', name: 'Staff D1 Data Management' },

  // 6. EXECUTIVE DASHBOARD & LEADERSHIP
  { path: '/executive/dashboard', role: 'executive', name: 'Executive Leadership Command Center' },
  { path: '/executive/heatmap', role: 'executive', name: 'Executive Risk Heatmap' },
  { path: '/executive/reports', role: 'executive', name: 'Executive ESG & SLA Reports' },
  { path: '/executive/alerts', role: 'executive', name: 'Executive Alerts' },
  { path: '/executive/settings', role: 'executive', name: 'Executive Settings' },
  { path: '/executive-app', role: 'executive', name: 'Executive Dedicated Standalone App' },

  // 7. ADMIN APP
  { path: '/admin', role: 'admin', name: 'Admin App Main' },
  { path: '/admin-app', role: 'admin', name: 'Admin Standalone App' }
];

export const VIEWPORTS = [
  { name: 'Mobile iPhone (375x812)', width: 375, height: 812 },
  { name: 'Mobile Standard (390x844)', width: 390, height: 844 },
  { name: 'Tablet (768x1024)', width: 768, height: 1024 },
  { name: 'Desktop HD (1366x768)', width: 1366, height: 768 },
  { name: 'Desktop Full (1440x900)', width: 1440, height: 900 }
];

async function isServerReady(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => {
      resolve(res.statusCode === 200 || res.statusCode === 304);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => {
      req.destroy();
      resolve(false);
    });
  });
}

export async function runRouteCrawlerAudit(options = {}) {
  const { maxRoutes = CRAWLER_ROUTES.length, verbose = true } = options;

  console.log('========================================================');
  console.log('🌐 DUSTGUARD VN — AUTOMATED ROUTE CRAWLER & RELIABILITY AUDIT');
  console.log('========================================================\n');

  let localServer = null;
  const is3000Ready = await isServerReady(`http://127.0.0.1:3000/api/health`);
  if (!is3000Ready) {
    PORT = 3198;
    BASE_URL = `http://127.0.0.1:${PORT}`;
    localServer = await new Promise((res, rej) => {
      const s = http.createServer(expressApp);
      s.listen(PORT, '127.0.0.1', () => res(s));
      s.on('error', rej);
    });
  }

  // 1. Launch Browser
  let browser;
  try {
    try {
      browser = await chromium.launch({ channel: 'msedge', headless: true });
    } catch {
      browser = await chromium.launch({ headless: true });
    }
  } catch (err) {
    if (localServer) localServer.close();
    throw err;
  }

  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    locale: 'vi-VN'
  });

  const page = await context.newPage();

  const auditResults = [];
  let totalErrors = 0;

  const routesToTest = CRAWLER_ROUTES.slice(0, maxRoutes);

  for (let i = 0; i < routesToTest.length; i++) {
    const r = routesToTest[i];
    const fullUrl = `${BASE_URL}${r.path}`;
    const pageErrors = [];
    const consoleErrors = [];

    const pageErrorHandler = (err) => {
      pageErrors.push(err.message || String(err));
    };
    const consoleHandler = (msg) => {
      if (msg.type() === 'error') {
        const text = msg.text();
        // Ignore benign 404 resource errors during test
        if (!text.includes('404') && !text.includes('net::ERR_') && !text.includes('favicon')) {
          consoleErrors.push(text);
        }
      }
    };

    page.on('pageerror', pageErrorHandler);
    page.on('console', consoleHandler);

    // Set role mock session in localStorage before loading protected routes
    await page.addInitScript((role) => {
      try {
        const userObj = {
          id: `usr_test_${role}`,
          name: `Test ${role.toUpperCase()}`,
          role: role,
          email: `${role}@dustguard.vn`
        };
        localStorage.setItem('dustguard_user', JSON.stringify(userObj));
        localStorage.setItem('dustguard_role', role);
        sessionStorage.setItem('dustguard_role', role);
      } catch {}
    }, r.role);

    const startTime = performance.now();
    let status = 'PASS';
    let errorMessage = null;

    try {
      await page.goto(fullUrl, { waitUntil: 'domcontentloaded', timeout: 8000 });
      // Short delay for React effect execution
      await page.waitForTimeout(300);

      // Check if rendered content exists
      const bodyText = await page.evaluate(() => document.body?.innerText || '');
      const rootHtml = await page.evaluate(() => document.getElementById('root')?.innerHTML || '');

      const isBlank = !rootHtml || rootHtml.trim().length === 0;
      const isRawErrorVisible = bodyText.includes('TypeError:') || bodyText.includes('Cannot read properties of undefined');

      if (isBlank) {
        status = 'FAIL';
        errorMessage = 'Trang trắng (Blank Screen / Root element empty)';
      } else if (isRawErrorVisible) {
        status = 'FAIL';
        errorMessage = 'Hiển thị raw TypeError / Cannot read properties of undefined trên UI';
      } else if (pageErrors.length > 0) {
        status = 'FAIL';
        errorMessage = `Page Exception: ${pageErrors[0]}`;
      } else if (consoleErrors.some(e => e.includes('TypeError') || e.includes('Uncaught') || e.includes('Cannot read properties'))) {
        status = 'FAIL';
        errorMessage = `Severe Console Error: ${consoleErrors[0]}`;
      }
    } catch (err) {
      status = 'FAIL';
      errorMessage = err.message || 'Navigation timeout/error';
    } finally {
      page.off('pageerror', pageErrorHandler);
      page.off('console', consoleHandler);
    }

    const durationMs = Math.round(performance.now() - startTime);

    if (status === 'FAIL') {
      totalErrors++;
      if (verbose) {
        console.log(`❌ [${i + 1}/${routesToTest.length}] ${r.path} (${r.name}) - FAIL (${durationMs}ms): ${errorMessage}`);
      }
    } else {
      if (verbose) {
        console.log(`✔ [${i + 1}/${routesToTest.length}] ${r.path} (${r.name}) - OK (${durationMs}ms)`);
      }
    }

    auditResults.push({
      route: r.path,
      name: r.name,
      role: r.role,
      status,
      durationMs,
      error: errorMessage
    });
  }

  await browser.close();
  if (localServer) localServer.close();

  const passedCount = auditResults.filter(a => a.status === 'PASS').length;
  const failedCount = auditResults.filter(a => a.status === 'FAIL').length;

  console.log('\n========================================================');
  console.log(`📊 ROUTE CRAWLER RESULTS: ${passedCount}/${routesToTest.length} PASS (${failedCount} FAIL)`);
  console.log('========================================================\n');

  return {
    total: routesToTest.length,
    passed: passedCount,
    failed: failedCount,
    results: auditResults,
    success: failedCount === 0
  };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  runRouteCrawlerAudit()
    .then(res => {
      process.exit(res.success ? 0 : 1);
    })
    .catch(err => {
      console.error('Fatal in route crawler:', err);
      process.exit(1);
    });
}
