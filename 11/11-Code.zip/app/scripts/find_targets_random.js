import fs from 'fs';
import path from 'path';

const files = [
  'src/components/site-detail/SiteCasesTab.jsx',
  'src/components/site-detail/SiteReportsTab.jsx',
  'src/modules/staff/StaffAlerts.jsx',
  'src/lib/api/contractor-api.js',
  'src/lib/offline-drafts.js',
  'src/lib/youth-credits.js',
  'src/components/site-detail/SiteMonitoringTab.jsx',
  'src/modules/staff/StaffSites.jsx'
];

files.forEach(f => {
  const fullPath = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app', f);
  if (!fs.existsSync(fullPath)) {
    console.log(`File not found: ${f}`);
    return;
  }
  const content = fs.readFileSync(fullPath, 'utf8');
  console.log(`\n=== File: ${f} ===`);
  content.split('\n').forEach((line, idx) => {
    if (/Math\.random|mock|fake|dummy/i.test(line)) {
      console.log(`L${idx + 1}: ${line.trim()}`);
    }
  });
});
