import os
import cv2
import numpy as np
from PIL import Image

def analyze_sheet_cards():
    sheets = {
        1: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_10 21 thg 8, 2026 (1).png", "01-brand-ui"),
        2: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png", "02-icons"),
        3: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (3).png", "03-city-iot"),
        4: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (4).png", "04-patterns-connectors"),
        5: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_12 21 thg 8, 2026 (5).png", "05-community-people")
    }

    out_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets"
    os.makedirs(out_dir, exist_ok=True)

    for num, (path, name) in sheets.items():
        img = cv2.imread(path)
        h, w = img.shape[:2]
        print(f"\n==================== SHEET {num}: {name} ({w}x{h}) ====================")
        
        # Save a high resolution sliced grid with clear markers
        dbg = img.copy()
        # Find horizontal dividers or sections
        # Let's draw horizontal lines every 100 px and vertical lines every 100 px
        for y in range(0, h, 50):
            cv2.line(dbg, (0, y), (w, y), (0, 0, 255) if y % 100 == 0 else (220, 220, 220), 1)
            if y % 100 == 0:
                cv2.putText(dbg, f"Y={y}", (10, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 1)
                
        for x in range(0, w, 50):
            cv2.line(dbg, (x, 0), (x, h), (0, 0, 255) if x % 100 == 0 else (220, 220, 220), 1)
            if x % 100 == 0:
                cv2.putText(dbg, f"X={x}", (x + 5, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 1)

        cv2.imwrite(os.path.join(out_dir, f"sheet_{num}_measurement_grid.png"), dbg)

if __name__ == "__main__":
    analyze_sheet_cards()
