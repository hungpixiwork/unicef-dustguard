import fs from 'fs';
import path from 'path';

const ROOT_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard');

const IGNORE_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  '.vite',
  '.wrangler',
  '.pio',
  '.netlify',
  'backups',
  '.gemini',
  '.codelens'
]);

function countLines(filePath, content) {
  const ext = path.extname(filePath).toLowerCase();
  const lines = content.split(/\r?\n/);
  const total = lines.length;
  let blank = 0;
  let comment = 0;
  let inBlockComment = false;

  for (let line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      blank++;
      continue;
    }

    if (['.js', '.jsx', '.ts', '.tsx', '.cjs', '.mjs', '.c', '.cpp', '.h', '.css'].includes(ext)) {
      if (inBlockComment) {
        comment++;
        if (trimmed.includes('*/')) inBlockComment = false;
        continue;
      }
      if (trimmed.startsWith('/*')) {
        comment++;
        if (!trimmed.includes('*/') || trimmed.endsWith('/*')) inBlockComment = true;
        continue;
      }
      if (trimmed.startsWith('//')) {
        comment++;
        continue;
      }
    } else if (['.py', '.yaml', '.yml', '.ini'].includes(ext)) {
      if (trimmed.startsWith('#')) {
        comment++;
        continue;
      }
    } else if (['.sql'].includes(ext)) {
      if (trimmed.startsWith('--') || trimmed.startsWith('/*')) {
        comment++;
        continue;
      }
    } else if (['.html', '.xml', '.svg'].includes(ext)) {
      if (trimmed.startsWith('<!--')) {
        comment++;
        continue;
      }
    }
  }

  const code = total - blank - comment;
  return { total, blank, comment, code };
}

function scanFiles(dir) {
  let fileList = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (IGNORE_DIRS.has(entry.name)) continue;
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        fileList = fileList.concat(scanFiles(fullPath));
      } else {
        fileList.push(fullPath);
      }
    }
  } catch (e) {}
  return fileList;
}

// Deep Submodule Categorization
function deepClassify(relPath) {
  const norm = relPath.replace(/\\/g, '/');

  // 1. Tests
  if (norm.startsWith('app/tests/') || norm.includes('.test.') || norm.includes('.spec.')) {
    let sub = 'Other Tests';
    if (norm.includes('edge') || norm.includes('worker') || norm.includes('route')) sub = 'Edge & Route Tests';
    else if (norm.includes('staff') || norm.includes('case') || norm.includes('inspection')) sub = 'Staff & Case Tests';
    else if (norm.includes('citizen') || norm.includes('community') || norm.includes('youth')) sub = 'Citizen & Community Tests';
    else if (norm.includes('legal') || norm.includes('document')) sub = 'Legal & A4 Studio Tests';
    else if (norm.includes('executive') || norm.includes('directive')) sub = 'Executive Tests';
    else if (norm.includes('sensor') || norm.includes('telemetry') || norm.includes('iot')) sub = 'IoT & Telemetry Tests';
    else if (norm.includes('ui') || norm.includes('layout') || norm.includes('spatial') || norm.includes('design')) sub = 'UI & Spatial Tests';
    else if (norm.includes('e2e') || norm.includes('smoke') || norm.includes('crawler')) sub = 'E2E & Smoke Verification';
    return { module: 'Test Suites & Automation', subModule: sub };
  }

  // 2. Backend & API Core
  if (norm.startsWith('app/server/') || norm.startsWith('app/api/') || norm.startsWith('server/') || norm.startsWith('app/migrations/') || norm.startsWith('app/prisma/') || norm.startsWith('app/better-auth_migrations/')) {
    let sub = 'Server Core';
    if (norm.startsWith('app/server/routes/')) sub = 'Routes & Endpoints';
    else if (norm.startsWith('app/server/repositories/')) sub = 'D1 Repositories & Data Access';
    else if (norm.startsWith('app/server/domain/')) sub = 'Domain Aggregates & Business Logic';
    else if (norm.startsWith('app/server/controllers/')) sub = 'Controllers';
    else if (norm.startsWith('app/server/services/') || norm.startsWith('app/server/ai/')) sub = 'Services & AI Logic';
    else if (norm.startsWith('app/server/middleware/') || norm.startsWith('app/server/auth') || norm.startsWith('server/auth')) sub = 'Auth, RBAC & Security Middleware';
    else if (norm.startsWith('app/migrations/') || norm.startsWith('app/server/db/') || norm.startsWith('app/prisma/')) sub = 'Database Schema & Migrations';
    else if (norm.startsWith('app/server/shared/') || norm.startsWith('app/server/lib/')) sub = 'Server Shared Utilities';
    return { module: 'Backend & Edge API Core', subModule: sub };
  }

  // 3. Staff & Operations Center
  if (
    norm.startsWith('app/src/modules/staff/') ||
    norm.startsWith('app/src/modules/cases/') ||
    norm.startsWith('app/src/components/StaffAI/') ||
    norm.startsWith('app/src/components/complaints/') ||
    norm.startsWith('app/src/components/checklist/') ||
    norm.startsWith('app/src/components/site-detail/') ||
    norm.startsWith('app/src/modules/admin/')
  ) {
    let sub = 'Staff Core & Dashboard';
    if (norm.includes('/cases/') || norm.includes('Case')) sub = 'Case Investigation & Verification';
    else if (norm.includes('site') || norm.includes('Site')) sub = 'Site & Sensor Operations';
    else if (norm.includes('complaint') || norm.includes('Complaint')) sub = 'Complaints & Intake Triage';
    else if (norm.includes('checklist') || norm.includes('Inspection') || norm.includes('tasks')) sub = 'Checklist, Inspections & Field Tasks';
    else if (norm.includes('StaffAI') || norm.includes('ai') || norm.includes('AI')) sub = 'Staff AI Assistant & Co-pilot';
    else if (norm.startsWith('app/src/modules/admin/')) sub = 'Admin Backoffice & SLA Config';
    return { module: 'Staff & Operations Center', subModule: sub };
  }

  // 4. Citizen & Community Portal
  if (
    norm.startsWith('app/src/modules/citizen/') ||
    norm.startsWith('app/src/modules/community/') ||
    norm.startsWith('app/src/modules/youth/') ||
    norm.startsWith('app/src/modules/public/') ||
    norm.startsWith('app/src/apps/public-app.jsx') ||
    norm.startsWith('app/src/components/citizen/') ||
    norm.startsWith('app/src/components/landing/') ||
    norm.startsWith('app/src/apps/landing-app.jsx')
  ) {
    let sub = 'Citizen Observation & Report Wizard';
    if (norm.startsWith('app/src/modules/youth/')) sub = 'Youth Credits, Volunteering & Certs';
    else if (norm.startsWith('app/src/modules/community/')) sub = 'Community Hub, Feeds & Campaigns';
    else if (norm.includes('landing') || norm.includes('Landing')) sub = 'Landing Page & Public Discovery';
    else if (norm.includes('track') || norm.includes('Track')) sub = 'Public Case & Evidence Tracker';
    return { module: 'Citizen & Community Portal', subModule: sub };
  }

  // 5. Executive Command Center
  if (
    norm.startsWith('app/src/modules/executive/') ||
    norm.startsWith('app/src/components/executive/') ||
    norm.startsWith('app/src/apps/executive-app.jsx')
  ) {
    let sub = 'Executive Overview & City KPIs';
    if (norm.includes('directive') || norm.includes('Directive')) sub = 'Directives & Multi-Agency Orders';
    else if (norm.includes('signing') || norm.includes('Signing') || norm.includes('approval') || norm.includes('Approval')) sub = 'Digital Signing & Policy Approvals';
    else if (norm.includes('heatmap') || norm.includes('Heatmap') || norm.includes('map') || norm.includes('Map')) sub = 'Executive Spatial Heatmap';
    return { module: 'Executive Command Center', subModule: sub };
  }

  // 6. Legal Document Engine & A4 Studio
  if (
    norm.startsWith('app/src/legal-document-engine/') ||
    norm.startsWith('app/src/components/DocumentEditor/') ||
    norm.startsWith('app/src/modules/documents/') ||
    norm.startsWith('app/src/components/PolicyIntelligence/') ||
    norm.startsWith('app/src/lib/documents/')
  ) {
    let sub = 'Document Engine Core & AST';
    if (norm.startsWith('app/src/components/DocumentEditor/')) sub = 'A4 Studio Visual Canvas & TipTap';
    else if (norm.startsWith('app/src/legal-document-engine/renderers/')) sub = 'A4 PDF & Print Renderers';
    else if (norm.startsWith('app/src/legal-document-engine/registry/')) sub = 'Legal Notice & Template Registry';
    else if (norm.startsWith('app/src/components/PolicyIntelligence/')) sub = 'Policy Intelligence & Legal Rules';
    else if (norm.startsWith('app/src/modules/documents/')) sub = 'Official Document Portal & Issuance';
    return { module: 'Legal Document Engine & A4 Studio', subModule: sub };
  }

  // 7. Contractor & Remediation Portal
  if (
    norm.startsWith('app/src/modules/contractor/') ||
    norm.startsWith('app/src/components/ecommerce/')
  ) {
    let sub = 'Contractor Remediation Portal';
    if (norm.includes('evidence') || norm.includes('Evidence') || norm.includes('photo')) sub = 'Before/After Photographic Evidence';
    else if (norm.includes('escrow') || norm.includes('csr') || norm.includes('Escrow')) sub = 'CSR Escrow & Milestone Verification';
    return { module: 'Contractor & Remediation Portal', subModule: sub };
  }

  // 8. Spatial Map & UI Primitives & Design System
  if (
    norm.startsWith('app/src/components/map/') ||
    norm.startsWith('app/src/components/ui/') ||
    norm.startsWith('app/src/components/shared/') ||
    norm.startsWith('app/src/components/common/') ||
    norm.startsWith('app/src/components/tables/') ||
    norm.startsWith('app/src/components/charts/') ||
    norm.startsWith('app/src/components/form/') ||
    norm.startsWith('app/src/components/header/') ||
    norm.startsWith('app/src/components/auth/') ||
    norm.startsWith('app/src/design-system/') ||
    norm.startsWith('app/src/tokens/') ||
    norm.startsWith('app/src/layouts/') ||
    norm.startsWith('app/src/layout/') ||
    norm.startsWith('app/src/icons/') ||
    norm.startsWith('app/src/shared/') ||
    norm.startsWith('app/src/hooks/') ||
    norm.startsWith('app/src/utils/') ||
    norm.startsWith('app/src/services/') ||
    norm.startsWith('app/src/lib/') ||
    norm.startsWith('app/src/context/') ||
    norm.startsWith('app/src/config/') ||
    norm.startsWith('app/src/infrastructure/') ||
    norm.startsWith('app/src/locales/') ||
    norm.startsWith('app/src/modules/auth/') ||
    norm.startsWith('app/src/apps/admin-app.jsx') ||
    norm === 'app/src/App.jsx' ||
    norm === 'app/src/main.jsx' ||
    norm === 'app/src/index.css' ||
    norm === 'app/src/landing.css' ||
    norm === 'app/src/vite-env.d.ts'
  ) {
    let sub = 'UI Primitives & Shared Components';
    if (norm.startsWith('app/src/components/map/') || norm.startsWith('app/src/lib/spatial/')) sub = 'Spatial Map (Canvas & Leaflet/WGS84)';
    else if (norm.startsWith('app/src/design-system/') || norm.startsWith('app/src/tokens/') || norm.endsWith('.css')) sub = 'Design Tokens & High-Contrast Theme (CSS/Tokens)';
    else if (norm.startsWith('app/src/components/tables/') || norm.startsWith('app/src/components/charts/')) sub = 'Data Tables & Visualization Charts';
    else if (norm.startsWith('app/src/layouts/') || norm.startsWith('app/src/layout/') || norm.startsWith('app/src/components/header/')) sub = 'App Layouts & Navigation Shells';
    else if (norm.startsWith('app/src/hooks/') || norm.startsWith('app/src/context/') || norm.startsWith('app/src/services/') || norm.startsWith('app/src/lib/') || norm.startsWith('app/src/utils/')) sub = 'Client Hooks, State & API Client Lib';
    return { module: 'Spatial Map, UI Primitives & Core Infra', subModule: sub };
  }

  // 9. IoT Firmware
  if (norm.startsWith('firmware/')) {
    return { module: 'IoT Firmware & Hardware Edge', subModule: 'ESP32 APM2000 Firmware & Drivers' };
  }

  // 10. Scripts
  if (norm.startsWith('app/scripts/') || norm.startsWith('scripts/')) {
    return { module: 'Tooling & Automation Scripts', subModule: 'Verification & Automation CLI' };
  }

  // 11. Documentation
  if (
    norm.startsWith('.agents/') ||
    norm.startsWith('docs/') ||
    norm.startsWith('presentation/') ||
    norm.startsWith('traction/') ||
    norm.startsWith('app/docs/') ||
    norm.startsWith('app/plans/') ||
    norm.startsWith('app/references/') ||
    norm.endsWith('.md')
  ) {
    let sub = 'SSOT Documentation & Guides';
    if (norm.startsWith('.agents/')) sub = 'Agent Memory Bank & Skills';
    else if (norm.startsWith('presentation/')) sub = 'Presentation Deck & Slides';
    else if (norm.startsWith('traction/')) sub = 'Traction & Deployment Evidence';
    return { module: 'Documentation, SSOT & Presentation', subModule: sub };
  }

  return { module: 'Other / Config / Assets', subModule: 'Assets & Configuration' };
}

function deepAudit() {
  const allFiles = scanFiles(ROOT_DIR);
  const CODE_EXTS = new Set([
    '.js', '.jsx', '.ts', '.tsx', '.cjs', '.mjs',
    '.css', '.sql', '.prisma',
    '.c', '.cpp', '.h', '.ini',
    '.py', '.html', '.json', '.yaml', '.yml', '.md'
  ]);

  const tree = {};
  const fileBreakdown = [];

  for (const fullPath of allFiles) {
    const relPath = path.relative(ROOT_DIR, fullPath).replace(/\\/g, '/');
    const ext = path.extname(fullPath).toLowerCase() || '[no_ext]';
    const { module, subModule } = deepClassify(relPath);

    let stat = fs.statSync(fullPath);
    let lineInfo = { total: 0, blank: 0, comment: 0, code: 0 };
    let isCode = CODE_EXTS.has(ext);

    if (isCode) {
      try {
        const content = fs.readFileSync(fullPath, 'utf8');
        lineInfo = countLines(fullPath, content);
      } catch (e) {}
    }

    if (!tree[module]) {
      tree[module] = {
        totalGross: 0,
        totalSLOC: 0,
        totalComments: 0,
        totalBlanks: 0,
        totalFiles: 0,
        subModules: {},
        byExt: {}
      };
    }

    if (!tree[module].subModules[subModule]) {
      tree[module].subModules[subModule] = {
        files: 0,
        gross: 0,
        sloc: 0,
        comment: 0,
        blank: 0,
        byExt: {}
      };
    }

    tree[module].totalFiles++;
    tree[module].subModules[subModule].files++;

    if (isCode) {
      tree[module].totalGross += lineInfo.total;
      tree[module].totalSLOC += lineInfo.code;
      tree[module].totalComments += lineInfo.comment;
      tree[module].totalBlanks += lineInfo.blank;

      tree[module].subModules[subModule].gross += lineInfo.total;
      tree[module].subModules[subModule].sloc += lineInfo.code;
      tree[module].subModules[subModule].comment += lineInfo.comment;
      tree[module].subModules[subModule].blank += lineInfo.blank;

      // by ext
      if (!tree[module].byExt[ext]) tree[module].byExt[ext] = { files: 0, sloc: 0, gross: 0 };
      tree[module].byExt[ext].files++;
      tree[module].byExt[ext].sloc += lineInfo.code;
      tree[module].byExt[ext].gross += lineInfo.total;

      if (!tree[module].subModules[subModule].byExt[ext]) tree[module].subModules[subModule].byExt[ext] = { files: 0, sloc: 0 };
      tree[module].subModules[subModule].byExt[ext].files++;
      tree[module].subModules[subModule].byExt[ext].sloc += lineInfo.code;

      fileBreakdown.push({
        relPath,
        module,
        subModule,
        ext,
        size: stat.size,
        gross: lineInfo.total,
        sloc: lineInfo.code,
        comment: lineInfo.comment,
        blank: lineInfo.blank
      });
    }
  }

  const output = {
    tree,
    fileBreakdown
  };

  fs.writeFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/scripts/deep_audit_result.json', JSON.stringify(output, null, 2));
  console.log('Deep audit complete! Saved to app/scripts/deep_audit_result.json');
}

deepAudit();
