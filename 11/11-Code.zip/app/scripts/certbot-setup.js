import { Client } from 'ssh2';

const vpsConfig = {
  host: '103.173.226.37',
  port: 22,
  username: 'root',
  password: 'a0NS1Y*Z1CrX1'
};

const domain = 'dustguard.phamphunguyenhung.com';

const conn = new Client();
conn.on('ready', () => {
  console.log('SSH Connection ready for Certbot!');
  const command = `certbot --nginx -d ${domain} --non-interactive --agree-tos --email phamphunguyenhung@gmail.com`;
  conn.exec(command, (err, stream) => {
    if (err) {
      console.error(err);
      conn.end();
      return;
    }
    stream.on('close', (code) => {
      console.log(`Certbot finished with exit code: ${code}`);
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data);
    }).stderr.on('data', (data) => {
      process.stderr.write(data);
    });
  });
}).on('error', (err) => {
  console.error(err);
}).connect(vpsConfig);
