#!/usr/bin/env node
/**
 * CLI Script: Safe Local Database Reset (SSOT)
 * Usage: node scripts/db-reset-local.js [--seed] [--delete-files]
 */
import { executeSystemReset } from '../server/services/system-data.service.js';
import { prisma } from '../server/shared/db.js';

async function main() {
  const args = process.argv.slice(2);
  const shouldSeed = args.includes('--seed');
  const deleteStoredFiles = args.includes('--delete-files');
  const mode = shouldSeed ? 'RESET_AND_SEED' : 'EMPTY';

  console.log('========================================================');
  console.log('🛡️  DUSTGUARD VN - LOCAL D1 DATABASE RESET UTILITY (SSOT)');
  console.log('========================================================');
  console.log(`Chế độ: ${mode}`);
  console.log(`Xóa tệp lưu trữ R2: ${deleteStoredFiles}`);
  console.log('Đang thực thi reset...');

  try {
    const result = await executeSystemReset({
      mode,
      deleteStoredFiles,
      confirmation: 'RESET DUSTGUARD DATA',
      actor: { id: 'cli_admin', name: 'CLI Admin Runner', role: 'admin' },
      env: prisma
    });

    console.log('\n✅ RESET HOÀN TẤT THÀNH CÔNG!');
    console.log('Thống kê bản ghi đã dọn dẹp:');
    console.table(result.deletedCounts);

    if (result.seedSummary) {
      console.log('\n🌱 Dữ liệu mẫu đã khởi tạo (Canonical Seed):');
      console.log(`- Sites: ${result.seedSummary.sitesCreated}`);
      console.log(`- Complaints: ${result.seedSummary.complaintsCreated}`);
      console.log(`- Cases: ${result.seedSummary.casesCreated}`);
      console.log(`- CPS Score calculated: ${result.seedSummary.priorityScoreCalculated}`);
    }

    process.exit(0);
  } catch (error) {
    console.error('\n❌ LỖI KHI RESET DATABASE:', error.message);
    process.exit(1);
  }
}

main();
