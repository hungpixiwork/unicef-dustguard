/**
 * DustGuard VN - Level 5 Verification: verify:ci
 * Comprehensive Continuous Integration Gate.
 */

import { ALL_TEST_FILES } from './test-groups.js';
import { executeTestPipeline, runProcess } from './verification-runner.js';

async function main() {
  console.log('========================================================');
  console.log('🌐 DUSTGUARD CI PIPELINE EXECUTION');
  console.log('========================================================\n');

  // 1. Build
  const build = await runProcess('npm', ['run', 'build']);
  if (build.exitCode !== 0) process.exit(1);

  // 2. OpenAPI Audit
  const audit = await runProcess('node', ['scripts/audit-api-contract.js']);
  if (audit.exitCode !== 0) process.exit(1);

  // 3. Production Proof
  const proof = await runProcess('node', ['scripts/verify-live-api-outputs.js']);
  if (proof.exitCode !== 0) process.exit(1);

  // 4. Test Suite
  const tests = await executeTestPipeline(ALL_TEST_FILES, { title: 'CI REGRESSION SUITE' });
  process.exit(tests.success ? 0 : 1);
}

main().catch(() => process.exit(1));
