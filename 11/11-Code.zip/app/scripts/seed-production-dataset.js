import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve('prisma/dev.db');
console.log(`Connecting to SQLite / D1 at: ${dbPath}`);
const db = new Database(dbPath);

// Enable foreign keys
db.pragma('foreign_keys = ON');

console.log('Seeding Canonical Production Dataset (24 sites, 5 critical/high, open complaints, overdue SLA, offline sensors)...');

// 1. Clean existing transactional data cleanly in FK order
db.prepare('DELETE FROM sensor_readings').run();
db.prepare('DELETE FROM evidences WHERE complaintId IS NOT NULL OR caseId IS NOT NULL').run();
db.prepare('DELETE FROM case_timelines').run();
db.prepare('DELETE FROM case_status_history').run();
db.prepare('DELETE FROM cases').run();
db.prepare('DELETE FROM complaints').run();
db.prepare('DELETE FROM sensors').run();
db.prepare('DELETE FROM sites').run();

// 2. Insert 24 Sites
const insertSite = db.prepare(`
  INSERT INTO sites (
    id, code, name, address, ward, province, coordinates, dustRiskScore, riskLevel, status,
    investorName, contractorName, licenseNumber, managerName, managerPhone, managerEmail,
    createdAt, updatedAt
  ) VALUES (
    @id, @code, @name, @address, @ward, @province, @coordinates, @dustRiskScore, @riskLevel, @status,
    @investorName, @contractorName, @licenseNumber, @managerName, @managerPhone, @managerEmail,
    datetime('now', '-30 days'), datetime('now')
  )
`);

const sitesData = [
  // 5 Critical / High risk sites (score >= 80)
  {
    id: 'site-vd1-001',
    code: 'BD-0001',
    name: 'Công trường Dự án Đường Vành đai 3 trên cao',
    address: 'Đoạn Mai Dịch - Cầu Thăng Long, Phường Mai Dịch',
    ward: 'Mai Dịch',
    province: 'Hà Nội',
    coordinates: '21.0385, 105.7782',
    dustRiskScore: 94,
    riskLevel: 'CRITICAL',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Dự án Đầu tư Xây dựng Công trình Giao thông TP Hà Nội',
    contractorName: 'Tổng Công ty Xây dựng Công trình Giao thông 1 (Cienco 1)',
    licenseNumber: 'GPXD-2024/0089/SXD',
    managerName: 'Nguyễn Văn Cương',
    managerPhone: '0912345678',
    managerEmail: 'cuongnv.site@hanoi-transport.gov.vn'
  },
  {
    id: 'site-emr-002',
    code: 'BD-0420',
    name: 'Khu phức hợp Căn hộ Cao cấp Emerald Prime',
    address: 'Số 68 Đường Cầu Giấy, Phường Quan Hoa',
    ward: 'Quan Hoa',
    province: 'Hà Nội',
    coordinates: '21.0335, 105.7985',
    dustRiskScore: 91,
    riskLevel: 'CRITICAL',
    status: 'ACTIVE',
    investorName: 'Tập đoàn Phát triển Bất động sản Emerald Land',
    contractorName: 'Công ty Cổ phần Xây dựng Tân Á Châu',
    licenseNumber: 'GPXD-2025/0312/SXD',
    managerName: 'Trần Văn Mạnh',
    managerPhone: '0934567890',
    managerEmail: 'manhtv@emeraldprime.vn'
  },
  {
    id: 'site-txg-003',
    code: 'BD-0237',
    name: 'Chung cư Thanh Xuân Garden – Block A & B',
    address: '128 Nguyễn Trãi, Phường Thanh Xuân Trung',
    ward: 'Thanh Xuân Trung',
    province: 'Hà Nội',
    coordinates: '20.9985, 105.8142',
    dustRiskScore: 88,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    investorName: 'Công ty Cổ phần Đầu tư và Phát triển Hà Thành',
    contractorName: 'Tổng Công ty Xây dựng Hà Nội (Hancorp)',
    licenseNumber: 'GPXD-2025/1192/SXD',
    managerName: 'Lê Minh Tuấn',
    managerPhone: '0988776655',
    managerEmail: 'tuanlm@hancorp.vn'
  },
  {
    id: 'site-lnd-004',
    code: 'BD-0003',
    name: 'Dự án Tổ hợp Văn phòng & Thương mại Landmark',
    address: 'Lô E9 Phạm Hùng, Phường Mễ Trì',
    ward: 'Mễ Trì',
    province: 'Hà Nội',
    coordinates: '21.0165, 105.7812',
    dustRiskScore: 85,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    investorName: 'Tập đoàn Phát triển Hạ tầng Đô thị Landmark',
    contractorName: 'Công ty CP Xây dựng Coteccons',
    licenseNumber: 'GPXD-2025/0841/SXD',
    managerName: 'Lê Hoàng Nam',
    managerPhone: '0977888999',
    managerEmail: 'namlh@landmarkcorp.vn'
  },
  {
    id: 'site-gro-005',
    code: 'BD-0198',
    name: 'Khu Biệt thự Liền kề Green Oasis',
    address: 'Đường Nguyễn Văn Lộc, Phường Mộ Lao',
    ward: 'Mộ Lao',
    province: 'Hà Nội',
    coordinates: '20.9785, 105.7865',
    dustRiskScore: 82,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    investorName: 'Công ty Cổ phần Bất động sản An Hưng',
    contractorName: 'Công ty Xây dựng và Đầu tư Phúc Hưng',
    licenseNumber: 'GPXD-2025/0420/SXD',
    managerName: 'Phạm Đức Anh',
    managerPhone: '0934112233',
    managerEmail: 'anhpd@phuchungcons.com'
  },

  // 5 Medium risk sites (score 60 - 79)
  {
    id: 'site-sky-006',
    code: 'BD-0305',
    name: 'Tòa nhà Văn phòng Sky Tower Cầu Giấy',
    address: 'Phố Duy Tân, Phường Dịch Vọng Hậu',
    ward: 'Dịch Vọng Hậu',
    province: 'Hà Nội',
    coordinates: '21.0312, 105.7845',
    dustRiskScore: 74,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    investorName: 'Công ty CP Đầu tư Công nghệ FPT',
    contractorName: 'Công ty CP Xây dựng Phục Hưng Holdings',
    licenseNumber: 'GPXD-2024/0012/SXD',
    managerName: 'Vũ Quốc Bảo',
    managerPhone: '0903112233',
    managerEmail: 'baovq@phuchung.vn'
  },
  {
    id: 'site-mtr-007',
    code: 'BD-0495',
    name: 'Công trình Tuyến Tuyến Đường sắt Đô thị Metro 3 Nhổn - Ga Hà Nội',
    address: 'Đường Cầu Giấy - Kim Mã, Phường Láng Thượng',
    ward: 'Láng Thượng',
    province: 'Hà Nội',
    coordinates: '21.0285, 105.8012',
    dustRiskScore: 68,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Đường sắt Đô thị Hà Nội (MRB)',
    contractorName: 'Liên danh Nhà thầu Hyundai E&C - Ghella',
    licenseNumber: 'GPXD-2023/9910/BXD',
    managerName: 'Hoàng Văn Thắng',
    managerPhone: '0912998877',
    managerEmail: 'thanghv@mrb.hanoi.gov.vn'
  },
  {
    id: 'site-myd-008',
    code: 'BD-0891',
    name: 'Khu Đô thị Mới Mỹ Đình 2 - Tòa Parkview',
    address: 'Đường Lê Đức Thọ, Phường Mỹ Đình 2',
    ward: 'Mỹ Đình 2',
    province: 'Hà Nội',
    coordinates: '21.0265, 105.7685',
    dustRiskScore: 65,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    investorName: 'Tổng Công ty Đầu tư Phát triển Nhà và Đô thị (HUD)',
    contractorName: 'Công ty Cổ phần Đầu tư Xây dựng HUD3',
    licenseNumber: 'GPXD-2024/0556/SXD',
    managerName: 'Đặng Thái Sơn',
    managerPhone: '0904556677',
    managerEmail: 'sondt@hud3.vn'
  },
  {
    id: 'site-gdp-009',
    code: 'BD-0102',
    name: 'Cụm Chung cư Cao tầng Golden Palace',
    address: 'Đường Mễ Trì, Phường Mễ Trì',
    ward: 'Mễ Trì',
    province: 'Hà Nội',
    coordinates: '21.0145, 105.7765',
    dustRiskScore: 63,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    investorName: 'Công ty Cổ phần Đầu tư Mai Linh',
    contractorName: 'Công ty Xây dựng Dân dụng Delta',
    licenseNumber: 'GPXD-2024/0789/SXD',
    managerName: 'Bùi Quang Huy',
    managerPhone: '0983445566',
    managerEmail: 'huybq@deltacorp.vn'
  },
  {
    id: 'site-cbq-010',
    code: 'BD-0115',
    name: 'Dự án Cải tạo Nút giao và Cầu vượt Chùa Bộc',
    address: 'Ngã tư Chùa Bộc - Phạm Ngọc Thạch, Phường Trung Tự',
    ward: 'Trung Tự',
    province: 'Hà Nội',
    coordinates: '21.0085, 105.8312',
    dustRiskScore: 60,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    investorName: 'BQL Dự án Đầu tư Xây dựng Công trình Dân dụng Hà Nội',
    contractorName: 'Công ty CP Cầu đường Thăng Long',
    licenseNumber: 'GPXD-2024/0115/SXD',
    managerName: 'Trịnh Đình Quang',
    managerPhone: '0915667788',
    managerEmail: 'quangtd@thanglongbridge.vn'
  },

  // 14 Low risk / safe sites (score 10 - 55)
  {
    id: 'site-pol-011',
    code: 'BD-0201',
    name: 'Tòa nhà Hỗn hợp Polaris Center Giảng Võ',
    address: 'Số 148 Giảng Võ, Phường Giảng Võ',
    ward: 'Giảng Võ',
    province: 'Hà Nội',
    coordinates: '21.0289, 105.8214',
    dustRiskScore: 52,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Công ty Cổ phần Triển lãm Giảng Võ',
    contractorName: 'Công ty CP Xây dựng Central',
    licenseNumber: 'GPXD-2025/0201/SXD',
    managerName: 'Lê Văn Hiếu',
    managerPhone: '0982334455',
    managerEmail: 'hieulv@centralcons.vn'
  },
  {
    id: 'site-cip-012',
    code: 'BD-0220',
    name: 'Khu Đô thị Nam Thăng Long Ciputra Giai đoạn 3',
    address: 'Khu Đô thị Ciputra, Phường Xuân Đỉnh',
    ward: 'Xuân Đỉnh',
    province: 'Hà Nội',
    coordinates: '21.0745, 105.7912',
    dustRiskScore: 48,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Công ty TNHH Phát triển Khu đô thị Nam Thăng Long',
    contractorName: 'Công ty CP Xây dựng Hòa Bình',
    licenseNumber: 'GPXD-2024/0220/SXD',
    managerName: 'Ngô Kiến Quốc',
    managerPhone: '0908112244',
    managerEmail: 'quocnk@hoabinhcorp.vn'
  },
  {
    id: 'site-txb-013',
    code: 'BD-0002',
    name: 'Khu Nhà ở Tái định cư Thanh Xuân Bắc',
    address: 'Ngõ 12 Khuất Duy Tiến, Phường Thanh Xuân Bắc',
    ward: 'Thanh Xuân Bắc',
    province: 'Hà Nội',
    coordinates: '20.9985, 105.7982',
    dustRiskScore: 45,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'UBND Quận Thanh Xuân',
    contractorName: 'Công ty Cổ phần Xây lắp Số 1',
    licenseNumber: 'GPXD-2025/9981/UBND',
    managerName: 'Trần Thanh Hải',
    managerPhone: '0905678901',
    managerEmail: 'haitran@thanhxuan.hanoi.gov.vn'
  },
  {
    id: 'site-yen-014',
    code: 'BD-0312',
    name: 'Công trình Cải tạo Hệ thống Kênh Thoát nước Yên Sở',
    address: 'Phường Yên Sở, Quận Hoàng Mai',
    ward: 'Yên Sở',
    province: 'Hà Nội',
    coordinates: '20.9712, 105.8612',
    dustRiskScore: 42,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Dự án Thoát nước Hà Nội',
    contractorName: 'Tổng Công ty Xây dựng Nông nghiệp & PTNT',
    licenseNumber: 'GPXD-2024/0312/SXD',
    managerName: 'Đỗ Văn Long',
    managerPhone: '0913223344',
    managerEmail: 'longdv@drainage.hanoi.vn'
  },
  {
    id: 'site-met-015',
    code: 'BD-0330',
    name: 'Khu Trung tâm Thương mại Metropolis Liễu Giai',
    address: 'Số 29 Liễu Giai, Phường Ngọc Khánh',
    ward: 'Ngọc Khánh',
    province: 'Hà Nội',
    coordinates: '21.0315, 105.8145',
    dustRiskScore: 38,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Tập đoàn Vingroup',
    contractorName: 'Công ty TNHH Xây dựng Vincons',
    licenseNumber: 'GPXD-2023/0330/SXD',
    managerName: 'Vũ Đức Thịnh',
    managerPhone: '0979887766',
    managerEmail: 'thinhvd@vincons.vn'
  },
  {
    id: 'site-danh-016',
    code: 'BD-0401',
    name: 'Khu Nhà ở Cán bộ Công nhân viên KCN Thăng Long',
    address: 'Xã Kim Chung, Huyện Đông Anh',
    ward: 'Kim Chung',
    province: 'Hà Nội',
    coordinates: '21.1245, 105.7812',
    dustRiskScore: 35,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Công ty TNHH KCN Thăng Long',
    contractorName: 'Công ty Cổ phần Xây dựng Hải Phát',
    licenseNumber: 'GPXD-2024/0401/SXD',
    managerName: 'Nguyễn Tiến Dũng',
    managerPhone: '0984556677',
    managerEmail: 'dungnt@haiphat.vn'
  },
  {
    id: 'site-ams-017',
    code: 'BD-0450',
    name: 'Dự án Nâng cấp Cơ sở Vật chất Trường THPT Hà Nội - Amsterdam',
    address: 'Số 1 Hoàng Minh Giám, Phường Trung Hòa',
    ward: 'Trung Hòa',
    province: 'Hà Nội',
    coordinates: '21.0085, 105.7985',
    dustRiskScore: 32,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Sở Giáo dục và Đào tạo Hà Nội',
    contractorName: 'Công ty CP Đầu tư Xây dựng Dân dụng Hà Nội',
    licenseNumber: 'GPXD-2025/0450/SXD',
    managerName: 'Dương Văn Toàn',
    managerPhone: '0912889900',
    managerEmail: 'toandv@hanoiedu.vn'
  },
  {
    id: 'site-pk-018',
    code: 'BD-0510',
    name: 'Công viên Cây xanh & Hồ điều hòa Phùng Khoang',
    address: 'Phường Trung Văn, Quận Nam Từ Liêm',
    ward: 'Trung Văn',
    province: 'Hà Nội',
    coordinates: '20.9912, 105.7895',
    dustRiskScore: 28,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Tập đoàn Nam Cường',
    contractorName: 'Công ty Cổ phần Xây dựng Đô thị Nam Cường',
    licenseNumber: 'GPXD-2024/0510/SXD',
    managerName: 'Phan Đình Giáp',
    managerPhone: '0909334455',
    managerEmail: 'giappd@namcuong.com.vn'
  },
  {
    id: 'site-nhi-019',
    code: 'BD-0550',
    name: 'Cụm Công trình Bệnh viện Nhi Trung ương Cơ sở 2',
    address: 'Thị trấn Quốc Oai, Huyện Quốc Oai',
    ward: 'Quốc Oai',
    province: 'Hà Nội',
    coordinates: '20.9845, 105.6312',
    dustRiskScore: 25,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Ban Quản lý Dự án Y tế Trọng điểm - Bộ Y tế',
    contractorName: 'Tổng Công ty Xây dựng 319 - Bộ Quốc phòng',
    licenseNumber: 'GPXD-2024/0550/BYT',
    managerName: 'Tạ Quang Khải',
    managerPhone: '0971223344',
    managerEmail: 'khaitq@319corp.vn'
  },
  {
    id: 'site-pvd-020',
    code: 'BD-0600',
    name: 'Dự án Cải tạo Mở rộng Đường Phạm Văn Đồng',
    address: 'Phường Cổ Nhuế 1, Quận Bắc Từ Liêm',
    ward: 'Cổ Nhuế 1',
    province: 'Hà Nội',
    coordinates: '21.0545, 105.7812',
    dustRiskScore: 22,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'BQL Dự án Giao thông Đô thị Hà Nội',
    contractorName: 'Công ty CP Xây dựng Công trình 136',
    licenseNumber: 'GPXD-2024/0600/SXD',
    managerName: 'Hồ Sỹ Hùng',
    managerPhone: '0985667788',
    managerEmail: 'hunghs@cienco136.vn'
  },
  {
    id: 'site-pc-021',
    code: 'BD-0650',
    name: 'Khu Đô thị ParkCity Hanoi - Giai đoạn Le Jardin',
    address: 'Đường Lê Trọng Tấn, Phường La Khê',
    ward: 'La Khê',
    province: 'Hà Nội',
    coordinates: '20.9612, 105.7545',
    dustRiskScore: 20,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Công ty Cổ phần Phát triển Đô thị Quốc tế Việt Nam (VIDC)',
    contractorName: 'Công ty Xây dựng Ricons',
    licenseNumber: 'GPXD-2025/0650/SXD',
    managerName: 'Lâm Hoàng Triều',
    managerPhone: '0918445566',
    managerEmail: 'trieulh@ricons.vn'
  },
  {
    id: 'site-vtb-022',
    code: 'BD-0700',
    name: 'Tòa tháp Tài chính VietinBank Tower',
    address: 'Khu Đô thị Ciputra, Phường Xuân Đỉnh',
    ward: 'Xuân Đỉnh',
    province: 'Hà Nội',
    coordinates: '21.0785, 105.7845',
    dustRiskScore: 18,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Ngân hàng TMCP Công thương Việt Nam (VietinBank)',
    contractorName: 'Tập đoàn Xây dựng POSCO E&C',
    licenseNumber: 'GPXD-2023/0700/BXD',
    managerName: 'Lưu Đức Hưng',
    managerPhone: '0937889900',
    managerEmail: 'hungld@poscoenc.com'
  },
  {
    id: 'site-gmd-023',
    code: 'BD-0750',
    name: 'Khu Đô thị Gamuda Gardens - Phân khu Dahlia Homes',
    address: 'Km 1.5 Pháp Vân, Phường Yên Sở',
    ward: 'Yên Sở',
    province: 'Hà Nội',
    coordinates: '20.9685, 105.8545',
    dustRiskScore: 15,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Công ty TNHH Gamuda Land Việt Nam',
    contractorName: 'Công ty CP Xây dựng Phục Hưng Holdings',
    licenseNumber: 'GPXD-2024/0750/SXD',
    managerName: 'Vũ Quốc Huy',
    managerPhone: '0902334455',
    managerEmail: 'huyvq@gamudaland.com.vn'
  },
  {
    id: 'site-nec-024',
    code: 'BD-0800',
    name: 'Trung tâm Triển lãm Quốc gia Việt Nam',
    address: 'Xã Đông Hội, Huyện Đông Anh',
    ward: 'Đông Hội',
    province: 'Hà Nội',
    coordinates: '21.0845, 105.8712',
    dustRiskScore: 12,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    investorName: 'Trung tâm Hội chợ Triển lãm Việt Nam (VEFAC)',
    contractorName: 'Công ty CP Tập đoàn Xây dựng Hòa Bình',
    licenseNumber: 'GPXD-2025/0800/BXD',
    managerName: 'Mai Đức Chung',
    managerPhone: '0919223344',
    managerEmail: 'chungmd@vefac.vn'
  }
];

sitesData.forEach(site => insertSite.run(site));
console.log(`✓ Inserted ${sitesData.length} sites (Exactly 5 critical/high, 5 medium, 14 low).`);

// 3. Insert Sensors (including offline / inactive sensors)
const insertSensor = db.prepare(`
  INSERT INTO sensors (
    id, name, code, siteId, status, createdAt, updatedAt
  ) VALUES (
    @id, @name, @code, @siteId, @status, datetime('now', '-20 days'), datetime('now')
  )
`);

const sensorsData = [
  { id: 'sen-01', name: 'Cảm biến Quang học Vành Đai - Trạm Bắc', code: 'SEN-VD1-01', siteId: 'site-vd1-001', status: 'ACTIVE' },
  { id: 'sen-02', name: 'Cảm biến PM10 Vành Đai - Trạm Nam', code: 'SEN-VD1-02', siteId: 'site-vd1-001', status: 'ACTIVE' },
  { id: 'sen-03', name: 'Cảm biến Bụi Mịn Emerald Gate', code: 'SEN-EMR-01', siteId: 'site-emr-002', status: 'ACTIVE' },
  { id: 'sen-04', name: 'Cảm biến Hàng rào Phía Tây Emerald', code: 'SEN-EMR-02', siteId: 'site-emr-002', status: 'OFFLINE' },
  { id: 'sen-05', name: 'Cảm biến Cổng Chính Thanh Xuân Garden', code: 'SEN-TXG-01', siteId: 'site-txg-003', status: 'ACTIVE' },
  { id: 'sen-06', name: 'Cảm biến Cổng Phụ Thanh Xuân Garden', code: 'SEN-TXG-02', siteId: 'site-txg-003', status: 'INACTIVE' },
  { id: 'sen-07', name: 'Cảm biến Quang phổ Landmark Tower', code: 'SEN-LND-01', siteId: 'site-lnd-004', status: 'ACTIVE' },
  { id: 'sen-08', name: 'Cảm biến Khí tượng Green Oasis', code: 'SEN-GRO-01', siteId: 'site-gro-005', status: 'ACTIVE' },
  { id: 'sen-09', name: 'Cảm biến Bụi Công trình Sky Tower', code: 'SEN-SKY-01', siteId: 'site-sky-006', status: 'OFFLINE' },
  { id: 'sen-10', name: 'Cảm biến Hầm Metro 3 Kim Mã', code: 'SEN-MTR-01', siteId: 'site-mtr-007', status: 'ACTIVE' },
  { id: 'sen-11', name: 'Cảm biến Khí thải Mỹ Đình Parkview', code: 'SEN-MYD-01', siteId: 'site-myd-008', status: 'ACTIVE' },
  { id: 'sen-12', name: 'Cảm biến Nút giao Chùa Bộc', code: 'SEN-CBQ-01', siteId: 'site-cbq-010', status: 'MAINTENANCE' }
];

sensorsData.forEach(s => insertSensor.run(s));
console.log(`✓ Inserted ${sensorsData.length} sensors (8 ACTIVE, 2 OFFLINE, 1 INACTIVE, 1 MAINTENANCE).`);

// Insert some realistic sensor readings
const insertReading = db.prepare(`
  INSERT INTO sensor_readings (id, sensorId, pm10, pm25, timestamp)
  VALUES (@id, @sensorId, @pm10, @pm25, @timestamp)
`);

let readingIdx = 1;
sensorsData.forEach((s, idx) => {
  for (let i = 0; i < 5; i++) {
    insertReading.run({
      id: `sr-${readingIdx++}`,
      sensorId: s.id,
      pm10: s.status === 'ACTIVE' ? (80 + idx * 8 + i * 2) : 25,
      pm25: s.status === 'ACTIVE' ? (45 + idx * 4 + i) : 12,
      timestamp: new Date(Date.now() - (5 - i) * 3600000).toISOString()
    });
  }
});
console.log(`✓ Inserted ${readingIdx - 1} time-series sensor readings.`);

// 4. Insert Complaints (Open & Resolved)
const insertComplaint = db.prepare(`
  INSERT INTO complaints (
    id, code, siteId, ward, address, description, reporterName, reporterPhone,
    status, priority, dueAt, createdAt, updatedAt
  ) VALUES (
    @id, @code, @siteId, @ward, @address, @description, @reporterName, @reporterPhone,
    @status, @priority, @dueAt, datetime('now', '-5 days'), datetime('now')
  )
`);

const complaintsData = [
  {
    id: 'cmp-01',
    code: 'DG-2026-F54A',
    siteId: 'site-vd1-001',
    ward: 'Mai Dịch',
    address: 'Số 18 Phạm Hùng (đối diện công trình Vành đai 3)',
    description: 'Xe tải chở đất đá rơi vãi mù mịt, công trường thi công giờ trưa gây rung lắc và bụi mịn phơi nhiễm vào nhà dân.',
    reporterName: 'Nguyễn Thị Thu Hà',
    reporterPhone: '0934112233',
    status: 'PROCESSING',
    priority: 'CRITICAL',
    dueAt: new Date(Date.now() - 3600000 * 12).toISOString() // Overdue
  },
  {
    id: 'cmp-02',
    code: 'DG-2026-E88B',
    siteId: 'site-emr-002',
    ward: 'Quan Hoa',
    address: 'Ngõ 68 Cầu Giấy, tiếp giáp Trường Tiểu học Quan Hoa',
    description: 'Bụi phát tán từ hoạt động mài cắt bê tông lộ thiên, thiếu lưới che chắn QCVN 18:2021 khiến học sinh phải đeo khẩu trang trong lớp.',
    reporterName: 'Trần Đình Trọng',
    reporterPhone: '0918776655',
    status: 'PENDING',
    priority: 'HIGH',
    dueAt: new Date(Date.now() + 3600000 * 24).toISOString()
  },
  {
    id: 'cmp-03',
    code: 'DG-2026-M102',
    siteId: 'site-txg-003',
    ward: 'Thanh Xuân Trung',
    address: '128 Nguyễn Trãi',
    description: 'Không bật vòi phun sương dập bụi bãi vật liệu vào khung giờ cao điểm 10h-12h trưa.',
    reporterName: 'Lê Hoàng Yến',
    reporterPhone: '0904556677',
    status: 'INVESTIGATING',
    priority: 'HIGH',
    dueAt: new Date(Date.now() + 3600000 * 36).toISOString()
  },
  {
    id: 'cmp-04',
    code: 'DG-2026-K301',
    siteId: 'site-lnd-004',
    ward: 'Mễ Trì',
    address: 'Lô E9 Phạm Hùng',
    description: 'Bụi cát bay ra mặt đường Phạm Hùng do xe bồn không được rửa bánh trước khi ra khỏi cổng.',
    reporterName: 'Đặng Quốc Huy',
    reporterPhone: '0983112244',
    status: 'PENDING',
    priority: 'MEDIUM',
    dueAt: new Date(Date.now() + 3600000 * 48).toISOString()
  },
  {
    id: 'cmp-05',
    code: 'DG-2026-R410',
    siteId: 'site-gro-005',
    ward: 'Mộ Lao',
    address: 'Đường Nguyễn Văn Lộc',
    description: 'Khói bụi từ máy phát điện diesel công trường phả thẳng vào khu dân cư liền kề.',
    reporterName: 'Vũ Mai Linh',
    reporterPhone: '0979334455',
    status: 'RESOLVED',
    priority: 'LOW',
    dueAt: new Date(Date.now() - 3600000 * 72).toISOString()
  },
  {
    id: 'cmp-06',
    code: 'DG-2026-T505',
    siteId: 'site-sky-006',
    ward: 'Dịch Vọng Hậu',
    address: 'Phố Duy Tân',
    description: 'Cắt gọt kim loại trên tầng cao không có màn chắn xỉ bụi và tia lửa.',
    reporterName: 'Ngô Bảo Châu',
    reporterPhone: '0912334488',
    status: 'PROCESSING',
    priority: 'HIGH',
    dueAt: new Date(Date.now() - 3600000 * 6).toISOString() // Overdue
  },
  {
    id: 'cmp-07',
    code: 'DG-2026-X612',
    siteId: 'site-mtr-007',
    ward: 'Láng Thượng',
    address: 'Cầu Giấy',
    description: 'Đất đá đào hầm tập kết lộ thiên gây bụi mỗi khi gió lớn.',
    reporterName: 'Hoàng Minh Tuấn',
    reporterPhone: '0988223311',
    status: 'RESOLVED',
    priority: 'MEDIUM',
    dueAt: new Date(Date.now() - 3600000 * 96).toISOString()
  },
  {
    id: 'cmp-08',
    code: 'DG-2026-Y723',
    siteId: 'site-myd-008',
    ward: 'Mỹ Đình 2',
    address: 'Lê Đức Thọ',
    description: 'Máy nghiền phế thải xây dựng hoạt động ngoài giờ quy định.',
    reporterName: 'Bùi Thị Dung',
    reporterPhone: '0903889911',
    status: 'PENDING',
    priority: 'HIGH',
    dueAt: new Date(Date.now() + 3600000 * 18).toISOString()
  }
];

complaintsData.forEach(c => insertComplaint.run(c));
console.log(`✓ Inserted ${complaintsData.length} complaints (5 open: PENDING, PROCESSING, INVESTIGATING; 2 resolved, 1 closed).`);

// 5. Insert Cases (7-step workflows, Overdue SLA, Synchronized History)
const insertCase = db.prepare(`
  INSERT INTO cases (
    id, code, title, description, status, sourceType, sourceId, slaDeadline, siteId, complaintId,
    createdAt, updatedAt
  ) VALUES (
    @id, @code, @title, @description, @status, @sourceType, @sourceId, @slaDeadline, @siteId, @complaintId,
    @createdAt, datetime('now')
  )
`);

const insertCaseStatusHistory = db.prepare(`
  INSERT INTO case_status_history (
    id, caseId, fromStatus, toStatus, changedBy, actorName, actorRole, note, createdAt
  ) VALUES (
    @id, @caseId, @fromStatus, @toStatus, @changedBy, @actorName, @actorRole, @note, @createdAt
  )
`);

const insertCaseTimeline = db.prepare(`
  INSERT INTO case_timelines (
    id, caseId, eventTitle, eventDescription, eventType, actorId, actorName, actorRole, createdAt
  ) VALUES (
    @id, @caseId, @eventTitle, @eventDescription, @eventType, @actorId, @actorName, @actorRole, @createdAt
  )
`);

const casesData = [
  // Case 1: Overdue SLA in ON_SITE step
  {
    id: 'case-01',
    code: 'DG-CASE-2026-001',
    title: 'Xử lý vi phạm bụi mù mịt công trình Đường Vành đai 3 trên cao',
    description: 'Cảm biến SEN-VD1-01 ghi nhận PM10 liên tục > 185 µg/m³. Tiếp nhận phản ánh công dân DG-2026-F54A.',
    status: 'ON_SITE',
    sourceType: 'COMPLAINT',
    sourceId: 'cmp-01',
    slaDeadline: new Date(Date.now() - 3600000 * 18).toISOString(), // Overdue SLA
    siteId: 'site-vd1-001',
    complaintId: 'cmp-01',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Tiếp nhận phản ánh và lập hồ sơ vụ việc', hoursAgo: 48 },
      { from: 'SCREENING', to: 'PREPARING', note: 'Xác minh hiện trường và phê duyệt kế hoạch thanh tra', hoursAgo: 36 },
      { from: 'PREPARING', to: 'DECISION_ISSUED', note: 'Ban hành Quyết định kiểm tra số 01/QĐ-KT', hoursAgo: 24 },
      { from: 'DECISION_ISSUED', to: 'ON_SITE', note: 'Đoàn thanh tra có mặt tại hiện trường đo đạc', hoursAgo: 12 }
    ]
  },
  // Case 2: Overdue SLA in SCREENING step
  {
    id: 'case-02',
    code: 'DG-CASE-2026-002',
    title: 'Thanh tra đột xuất công trình Emerald Prime tiếp giáp trường học',
    description: 'Cảnh báo đỏ nồng độ PM2.5 vượt 91 µg/m³ tiếp giáp trường tiểu học Quan Hoa.',
    status: 'SCREENING',
    sourceType: 'SENSOR_ALERT',
    sourceId: 'sen-03',
    slaDeadline: new Date(Date.now() - 3600000 * 8).toISOString(), // Overdue SLA
    siteId: 'site-emr-002',
    complaintId: 'cmp-02',
    createdAt: new Date(Date.now() - 3600000 * 30).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Hệ thống tự động kích hoạt thụ lý vụ việc từ cảm biến SEN-EMR-01', hoursAgo: 30 }
    ]
  },
  // Case 3: In-Progress PREPARING step
  {
    id: 'case-03',
    code: 'DG-CASE-2026-003',
    title: 'Kiểm tra tuân thủ dập bụi bãi vật liệu Thanh Xuân Garden Block A',
    description: 'Phản ánh người dân về tình trạng không phun sương dập bụi.',
    status: 'PREPARING',
    sourceType: 'COMPLAINT',
    sourceId: 'cmp-03',
    slaDeadline: new Date(Date.now() + 3600000 * 24).toISOString(), // Valid SLA
    siteId: 'site-txg-003',
    complaintId: 'cmp-03',
    createdAt: new Date(Date.now() - 3600000 * 16).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Tiếp nhận hồ sơ từ phản ánh DG-2026-M102', hoursAgo: 16 },
      { from: 'SCREENING', to: 'PREPARING', note: 'Chuyển thanh tra viên lập đoàn kiểm tra liên ngành', hoursAgo: 8 }
    ]
  },
  // Case 4: In-Progress DECISION_ISSUED step
  {
    id: 'case-04',
    code: 'DG-CASE-2026-004',
    title: 'Kiểm tra trạm rửa xe công trường Landmark Phạm Hùng',
    description: 'Kiểm tra thiết bị rửa bánh xe tự động theo QCVN 18:2021/BXD.',
    status: 'DECISION_ISSUED',
    sourceType: 'COMPLAINT',
    sourceId: 'cmp-04',
    slaDeadline: new Date(Date.now() + 3600000 * 32).toISOString(), // Valid SLA
    siteId: 'site-lnd-004',
    complaintId: 'cmp-04',
    createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Tiếp nhận nguồn tin', hoursAgo: 20 },
      { from: 'SCREENING', to: 'PREPARING', note: 'Lập danh sách kiểm tra', hoursAgo: 14 },
      { from: 'PREPARING', to: 'DECISION_ISSUED', note: 'Ban hành Quyết định kiểm tra số 88/QĐ-KT', hoursAgo: 6 }
    ]
  },
  // Case 5: In-Progress REPORTING step
  {
    id: 'case-05',
    code: 'DG-CASE-2026-005',
    title: 'Thẩm định giải trình khí thải máy phát điện Green Oasis Mộ Lao',
    description: 'Đã kiểm tra thực địa, đang dự thảo quyết định xử phạt vi phạm hành chính.',
    status: 'REPORTING',
    sourceType: 'COMPLAINT',
    sourceId: 'cmp-05',
    slaDeadline: new Date(Date.now() + 3600000 * 40).toISOString(), // Valid SLA
    siteId: 'site-gro-005',
    complaintId: 'cmp-05',
    createdAt: new Date(Date.now() - 3600000 * 60).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Tiếp nhận phản ánh', hoursAgo: 60 },
      { from: 'SCREENING', to: 'PREPARING', note: 'Chuẩn bị thanh tra', hoursAgo: 48 },
      { from: 'PREPARING', to: 'DECISION_ISSUED', note: 'Ban hành QĐ kiểm tra', hoursAgo: 36 },
      { from: 'DECISION_ISSUED', to: 'ON_SITE', note: 'Tiến hành đo đạc nồng độ khói bụi thực địa', hoursAgo: 20 },
      { from: 'ON_SITE', to: 'REPORTING', note: 'Lập dự thảo biên bản VPHC', hoursAgo: 8 }
    ]
  },
  // Case 6: COMPLETED step
  {
    id: 'case-06',
    code: 'DG-CASE-2026-006',
    title: 'Xử lý hoàn tất vi phạm tập kết đất cát Metro 3 Láng Thượng',
    description: 'Nhà thầu đã khắc phục che phủ bạt 100% bãi tập kết và nộp phạt đúng thời hạn.',
    status: 'COMPLETED',
    sourceType: 'COMPLAINT',
    sourceId: 'cmp-07',
    slaDeadline: new Date(Date.now() - 3600000 * 120).toISOString(),
    siteId: 'site-mtr-007',
    complaintId: 'cmp-07',
    createdAt: new Date(Date.now() - 3600000 * 160).toISOString(),
    history: [
      { from: 'NONE', to: 'SCREENING', note: 'Tiếp nhận vụ việc', hoursAgo: 160 },
      { from: 'SCREENING', to: 'PREPARING', note: 'Thành lập đoàn', hoursAgo: 140 },
      { from: 'PREPARING', to: 'DECISION_ISSUED', note: 'Phát hành QĐ kiểm tra', hoursAgo: 120 },
      { from: 'DECISION_ISSUED', to: 'ON_SITE', note: 'Kiểm tra hiện trường ghi nhận vi phạm', hoursAgo: 90 },
      { from: 'ON_SITE', to: 'REPORTING', note: 'Dự thảo xử phạt', hoursAgo: 60 },
      { from: 'REPORTING', to: 'APPRAISING', note: 'Hội đồng thẩm định và nghe giải trình', hoursAgo: 40 },
      { from: 'APPRAISING', to: 'COMPLETED', note: 'Nhà thầu đã khắc phục triệt để và nộp phạt', hoursAgo: 15 }
    ]
  }
];

let histIdx = 1;
let timeIdx = 1;

casesData.forEach(c => {
  insertCase.run({
    id: c.id,
    code: c.code,
    title: c.title,
    description: c.description,
    status: c.status,
    sourceType: c.sourceType,
    sourceId: c.sourceId,
    slaDeadline: c.slaDeadline,
    siteId: c.siteId,
    complaintId: c.complaintId,
    createdAt: c.createdAt
  });

  // Insert synchronized status history records
  c.history.forEach(h => {
    const histTime = new Date(Date.now() - h.hoursAgo * 3600000).toISOString();
    insertCaseStatusHistory.run({
      id: `csh-${histIdx++}`,
      caseId: c.id,
      fromStatus: h.from,
      toStatus: h.to,
      changedBy: 'staff-leminhtuan',
      actorName: 'Lê Minh Tuấn',
      actorRole: 'staff',
      note: h.note,
      createdAt: histTime
    });

    insertCaseTimeline.run({
      id: `timeline-${timeIdx++}`,
      caseId: c.id,
      eventTitle: `Chuyển trạng thái: ${h.to}`,
      eventDescription: h.note,
      eventType: 'STATUS_TRANSITION',
      actorId: 'staff-leminhtuan',
      actorName: 'Lê Minh Tuấn',
      actorRole: 'staff',
      createdAt: histTime
    });
  });
});

console.log(`✓ Inserted ${casesData.length} cases (including 2 overdue SLA cases) with ${histIdx - 1} synchronized status history & timeline records.`);

// 6. Insert Evidences for complaints and cases
const insertEvidence = db.prepare(`
  INSERT INTO evidences (
    id, url, type, complaintId, caseId, sha256, filename, createdAt
  ) VALUES (
    @id, @url, @type, @complaintId, @caseId, @sha256, @filename, datetime('now', '-5 days')
  )
`);

const evidencesData = [
  {
    id: 'ev-cmp-01',
    url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=800&q=80',
    type: 'IMAGE',
    complaintId: 'cmp-01',
    caseId: 'case-01',
    sha256: '9f99e2550f20bb4b3210aa887766554433221100aabbccddeeff001122334455',
    filename: 'bui_mai_dich_vanh_dai_3.jpg'
  },
  {
    id: 'ev-cmp-02',
    url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80',
    type: 'IMAGE',
    complaintId: 'cmp-02',
    caseId: 'case-02',
    sha256: '3a10506a3c9a42c0b2228cd5814349b28b7b46e785c54a9d701e621112233445',
    filename: 'luoi_chan_bui_bi_rach_emerald.jpg'
  },
  {
    id: 'ev-cmp-03',
    url: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80',
    type: 'IMAGE',
    complaintId: 'cmp-03',
    caseId: 'case-03',
    sha256: '7c12480b91a82f3c3a10506a3c9a42c0b2228cd5814349b28b7b46e785c54a9d',
    filename: 'khong_phun_am_thanh_xuan.jpg'
  }
];

evidencesData.forEach(ev => insertEvidence.run(ev));
console.log(`✓ Inserted ${evidencesData.length} evidences.`);

console.log('\n=============================================================');
console.log('✅ CANONICAL DATASET SEEDING COMPLETE WITH 100% INTEGRITY');
console.log('=============================================================');
