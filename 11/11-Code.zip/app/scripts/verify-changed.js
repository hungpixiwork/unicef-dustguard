/**
 * DustGuard VN - Level 1 Verification: verify:changed
 * Detects git modified/staged files, maps them via test-impact-map.js, and runs ONLY affected tests.
 */

import { execSync } from 'node:child_process';
import { resolveAffectedTests } from './test-impact-map.js';
import { executeTestPipeline } from './verification-runner.js';
import { TEST_GROUPS } from './test-groups.js';

function getGitChangedFiles() {
  try {
    // 1. Unstaged changes
    const unstaged = execSync('git diff --name-only', { encoding: 'utf-8' }).trim().split('\n').filter(Boolean);
    // 2. Staged changes
    const staged = execSync('git diff --cached --name-only', { encoding: 'utf-8' }).trim().split('\n').filter(Boolean);
    // 3. Untracked files
    const untracked = execSync('git ls-files --others --exclude-standard', { encoding: 'utf-8' }).trim().split('\n').filter(Boolean);

    const allChanged = [...new Set([...unstaged, ...staged, ...untracked])];
    return allChanged;
  } catch {
    return [];
  }
}

async function main() {
  const changedFiles = getGitChangedFiles();

  if (changedFiles.length === 0) {
    console.log('========================================================');
    console.log('⚡ VERIFY CHANGED: No git changes detected.');
    console.log('Running quick smoke gate as fallback...');
    console.log('========================================================\n');
    const res = await executeTestPipeline(TEST_GROUPS.critical, { title: 'QUICK SMOKE FALLBACK' });
    process.exit(res.success ? 0 : 1);
  }

  console.log(`🔍 Git changed files (${changedFiles.length}):`);
  changedFiles.forEach(f => console.log(`  • ${f}`));
  console.log('');

  const { files, groups, reasons } = resolveAffectedTests(changedFiles);

  const res = await executeTestPipeline(files, {
    title: `VERIFY CHANGED (${groups.join(', ') || 'targeted'})`,
    reasons
  });

  process.exit(res.success ? 0 : 1);
}

main().catch(err => {
  console.error('Fatal in verify-changed:', err);
  process.exit(1);
});
