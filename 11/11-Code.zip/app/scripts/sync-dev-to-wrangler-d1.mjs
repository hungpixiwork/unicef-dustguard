import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

console.log('🔄 SYNCING PRISMA/DEV.DB INTO WRANGLER LOCAL D1 SQLITE...');

const devDbPath = path.resolve('app/prisma/dev.db');
const d1Dir = path.resolve('app/.wrangler/state/v3/d1/miniflare-D1DatabaseObject');

if (!fs.existsSync(d1Dir)) {
  console.log('D1 directory does not exist, creating...');
  fs.mkdirSync(d1Dir, { recursive: true });
}

// Tìm tất cả các file .sqlite trong d1Dir (ngoại trừ metadata.sqlite)
const files = fs.readdirSync(d1Dir);
const d1SqliteFiles = files.filter(f => f.endsWith('.sqlite') && !f.startsWith('metadata'));

console.log(`Found ${d1SqliteFiles.length} Wrangler D1 SQLite file(s):`, d1SqliteFiles);

for (const d1File of d1SqliteFiles) {
  const targetPath = path.join(d1Dir, d1File);
  console.log(`Copying dev.db -> ${targetPath}...`);
  fs.copyFileSync(devDbPath, targetPath);
  // Xóa file wal và shm nếu có để buộc SQLite nạp mới
  if (fs.existsSync(`${targetPath}-wal`)) fs.unlinkSync(`${targetPath}-wal`);
  if (fs.existsSync(`${targetPath}-shm`)) fs.unlinkSync(`${targetPath}-shm`);
}

console.log('✅ WRANGLER LOCAL D1 SQLITE PERFECTLY SYNCED WITH DEV.DB!');
