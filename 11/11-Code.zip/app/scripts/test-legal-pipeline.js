import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const prisma = new PrismaClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runTests() {
  console.log('🚀 Starting Verification Tests for Persistent Legal Document System...\n');

  // 1. Create a mock Site for testing
  console.log('Step 1: Setting up mock site...');
  let site = await prisma.site.findFirst({ where: { name: 'Dự án Đường Vành Đai 4 - Đô thị mới' } });
  if (!site) {
    site = await prisma.site.create({
      data: {
        name: 'Dự án Đường Vành Đai 4 - Đô thị mới',
        address: 'Đại lộ Thăng Long, Hoài Đức, Hà Nội',
        ward: 'Trung Hòa',
        dustRiskScore: 78,
        riskLevel: 'HIGH',
        status: 'ACTIVE',
        investorName: 'Tổng công ty Cầu đường Hà Nội',
        contractorName: 'Cơ giới 1 Việt Nam',
        licenseNumber: 'GP-4512-HANOI'
      }
    });
  }
  console.log(`✅ Mock site ready: "${site.name}" (ID: ${site.id})\n`);

  // 2. Test createDraftDocument logic
  console.log('Step 2: Testing Draft Document Generation and SQLite Persistence...');
  
  // Simulate the request body that the frontend sends
  const mockRequest = {
    siteId: site.id,
    documentKind: 'bien-ban-kiem-tra',
    items: [
      { k: 'barrier', status: 'fail', notes: 'Hàng rào phía Tây bị nghiêng đổ và rách bạt dài 15m.' },
      { k: 'spray', status: 'fail', notes: 'Không phun nước dập bụi khi dùng máy cắt bê tông.' },
      { k: 'cover', status: 'pass' }
    ]
  };

  // We import the controller method programmatically to verify it works without running the full Express server
  const { createDraftDocument } = await import('../server/controllers/documents.controller.js');

  // Mock req and res objects
  let createdDraftId = null;
  const mockRes = {
    status: function(code) {
      this.statusCode = code;
      return this;
    },
    json: function(data) {
      this.payload = data;
      return this;
    }
  };

  const mockReq = { body: mockRequest };
  await createDraftDocument(mockReq, mockRes);

  if (mockRes.payload && mockRes.payload.success) {
    createdDraftId = mockRes.payload.draft_id;
    console.log(`✅ Draft Document persisted successfully!`);
    console.log(`   - Draft ID: ${createdDraftId}`);
    console.log(`   - Document Type: ${mockRes.payload.document_type}`);
    console.log(`   - Title: "${mockRes.payload.title}"`);
    console.log(`   - Status: ${mockRes.payload.status}`);
    console.log(`   - AI Grounding Engine fallback provider: ${mockRes.payload.provider}`);
  } else {
    throw new Error(`Failed to generate draft: ${JSON.stringify(mockRes.payload)}`);
  }
  console.log('\n');

  // 3. Verify SQLite persistence by querying Prisma directly
  console.log('Step 3: Verifying SQLite database persistence...');
  const dbDraft = await prisma.draftDocument.findUnique({
    where: { id: createdDraftId },
    include: { site: true }
  });

  if (dbDraft && dbDraft.title.includes(site.name)) {
    console.log(`✅ Verification Success: Draft is safely persisted in the dev.db SQLite instance!`);
    console.log(`   - Stored Content matches template: ${dbDraft.content.includes('BIÊN BẢN KIỂM TRA HIỆN TRƯỜNG')}`);
  } else {
    throw new Error('Verification Failure: Draft was not found or has incorrect data in SQLite.');
  }
  console.log('\n');

  // 4. Test programmatic Word .docx export
  console.log('Step 4: Testing Programmatic Microsoft Word .docx compilation...');
  const { exportDraftDocument } = await import('../server/controllers/documents.controller.js');

  const exportReq = {
    params: { id: createdDraftId },
    body: {
      organization: { parent: 'SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG', name: 'ĐOÀN THANH TRA LIÊN NGÀNH' },
      officer: { name: 'Thanh tra viên Nguyễn Văn An', title: 'Thanh tra trưởng' },
      metadata: { location: 'Hà Nội', recipient: site.investorName, issue_date: new Date().toISOString() }
    }
  };

  let exportedBuffer = null;
  const exportRes = {
    headers: {},
    setHeader: function(k, v) {
      this.headers[k] = v;
      return this;
    },
    send: function(buffer) {
      exportedBuffer = buffer;
      return this;
    }
  };

  await exportDraftDocument(exportReq, exportRes);

  if (exportedBuffer && Buffer.isBuffer(exportedBuffer)) {
    console.log(`✅ Word .docx binary generated programmatically!`);
    console.log(`   - Content-Type verified: ${exportRes.headers['Content-Type']}`);
    console.log(`   - Buffer Size: ${exportedBuffer.length} bytes`);
    
    // Save to scratch folder for review
    const scratchDir = path.join(__dirname, '../scratch');
    if (!fs.existsSync(scratchDir)) {
      fs.mkdirSync(scratchDir, { recursive: true });
    }
    const outputPath = path.join(scratchDir, 'dustguard-official-test.docx');
    fs.writeFileSync(outputPath, exportedBuffer);
    console.log(`   - Local Copy written to: [${outputPath}](file:///${outputPath.replace(/\\/g, '/')})`);
  } else {
    throw new Error('Failed to generate official Word .docx buffer');
  }
  console.log('\n');

  // 5. Test corrective Action drafting based on checklist
  console.log('Step 5: Testing corrective action drafting from inspection...');
  const { draftActionsFromInspection } = await import('../server/controllers/actions.controller.js');

  // Create a mock Inspection
  const mockInspection = await prisma.inspection.create({
    data: {
      siteId: site.id,
      findings: JSON.stringify([
        { k: 'barrier', status: 'fail', notes: 'Hàng rào bị rách.' },
        { k: 'wheel', status: 'fail', notes: 'Thiếu bồn rửa xe.' }
      ]),
      actionTaken: 'Yêu cầu khắc phục trong 48 giờ',
      scoreDelta: 30
    }
  });

  const actionsReq = {
    body: {
      inspection_id: mockInspection.id
    }
  };

  const actionsRes = {
    payload: null,
    json: function(data) {
      this.payload = data;
      return this;
    }
  };

  await draftActionsFromInspection(actionsReq, actionsRes);

  if (actionsRes.payload && actionsRes.payload.success) {
    const drafts = actionsRes.payload.draft_actions;
    console.log(`✅ Corrective actions drafted and grounded deterministically!`);
    console.log(`   - Found Failures Count: ${drafts.length}`);
    drafts.forEach((d, idx) => {
      console.log(`     ${idx + 1}. Hạng mục: "${d.checklist_item_id}"`);
      console.log(`        - Căn cứ pháp lý: ${d.legal_basis_summary}`);
      console.log(`        - Yêu cầu xử lý: ${d.required_fix}`);
    });
  } else {
    throw new Error('Failed to draft corrective actions');
  }
  console.log('\n');

  console.log('🎉 ALL PERSISTENT LEGAL WORKFLOW TESTS PASSED SUCCESSFULLY! 100% CORRECT!');
}

runTests()
  .catch(err => {
    console.error('❌ Test failed with error:', err);
    process.exit(1);
  });
