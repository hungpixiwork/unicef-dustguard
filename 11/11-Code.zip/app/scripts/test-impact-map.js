/**
 * DustGuard VN - Test Impact Map SSOT
 * Maps changed source files to affected test groups/files.
 */

import { TEST_GROUPS } from './test-groups.js';

export const IMPACT_RULES = [
  // High-Risk Shared Core
  {
    pattern: /^(package\.json|package-lock\.json)$/,
    groups: ['critical', 'worker', 'api'],
    reason: 'Package dependencies changed'
  },
  {
    pattern: /^(server\/shared\/db\.js|prisma\/|migrations\/)/,
    groups: ['database', 'critical'],
    reason: 'Database adapter or schema changed'
  },
  {
    pattern: /^server\/worker\.js/,
    groups: ['worker', 'api', 'critical'],
    reason: 'Worker entrypoint and routing changed'
  },
  {
    pattern: /^server\/docs\/openapi/,
    groups: ['api'],
    reason: 'OpenAPI specification changed'
  },
  {
    pattern: /^server\/shared\/canonical-json\.js/,
    groups: ['observations', 'handoffs', 'critical'],
    reason: 'Canonical hashing algorithm changed'
  },
  {
    pattern: /^server\/shared\/idempotency\.js/,
    groups: ['observations', 'critical'],
    reason: 'Idempotency engine changed'
  },

  // Domain & Repositories
  {
    pattern: /^(server\/domain\/observations\/|server\/repositories\/observation\.repository\.js)/,
    groups: ['observations'],
    reason: 'Observation domain or repository changed'
  },
  {
    pattern: /^(server\/domain\/categories\/|server\/repositories\/category\.repository\.js)/,
    groups: ['observations', 'critical'],
    reason: 'Environmental categories changed'
  },
  {
    pattern: /^(server\/services\/followup-decision\.service\.js|server\/repositories\/followup\.repository\.js)/,
    groups: ['followups', 'observations'],
    reason: 'Follow-up decision service or repository changed'
  },
  {
    pattern: /^(server\/domain\/handoffs\/|server\/repositories\/handoff\.repository\.js)/,
    groups: ['handoffs', 'observations'],
    reason: 'Handoff rules or repository changed'
  },
  {
    pattern: /^server\/repositories\/impact\.repository\.js/,
    groups: ['impact'],
    reason: 'Impact metrics repository changed'
  },
  {
    pattern: /^server\/repositories\/campaign\.repository\.js/,
    groups: ['campaigns'],
    reason: 'Campaign repository changed'
  },
  {
    pattern: /^(server\/domain\/risk\/|server\/lib\/riskEngine\.js)/,
    groups: ['risk'],
    reason: 'Dust risk engine changed'
  },
  {
    pattern: /^(server\/repositories\/youth\.repository\.js|src\/lib\/youth-credits\.js)/,
    groups: ['youth'],
    reason: 'Youth credits or certificate engine changed'
  },
  {
    pattern: /^(src\/lib\/csr-engine\.js|server\/routes\/api\/csr\.js)/,
    groups: ['csr'],
    reason: 'CSR DEMS or ESG engine changed'
  },
  {
    pattern: /^server\/middleware\/auth\.js/,
    groups: ['auth'],
    reason: 'Auth middleware changed'
  },

  // Frontend Components & Layouts
  {
    pattern: /^src\/(components|modules|shared\/components)\/.*\.jsx?$/,
    groups: ['ui'],
    reason: 'UI component or module layout changed'
  },
  {
    pattern: /^(src\/index\.css|src\/design-system\/)/,
    groups: ['ui'],
    reason: 'Design tokens or global CSS changed'
  },

  // Tests themselves
  {
    pattern: /^tests\/(.+)\.test\.js$/,
    directFile: (match) => `tests/${match[1]}.test.js`,
    reason: 'Direct test file modified'
  }
];

/**
 * Resolves affected test files from a list of changed relative file paths.
 * @param {string[]} changedFiles
 * @returns {{ files: string[], groups: string[], reasons: string[] }}
 */
export function resolveAffectedTests(changedFiles = []) {
  const affectedFiles = new Set();
  const matchedGroups = new Set();
  const reasons = new Set();

  for (const file of changedFiles) {
    const normalized = file.replace(/\\/g, '/');
    let matched = false;

    for (const rule of IMPACT_RULES) {
      const match = normalized.match(rule.pattern);
      if (match) {
        matched = true;
        reasons.add(`${file} → ${rule.reason}`);

        if (rule.directFile) {
          affectedFiles.add(rule.directFile(match));
        }

        if (rule.groups) {
          for (const grp of rule.groups) {
            matchedGroups.add(grp);
            const groupFiles = TEST_GROUPS[grp] || [];
            for (const f of groupFiles) {
              affectedFiles.add(f);
            }
          }
        }
      }
    }

    // Fallback for unmapped files in src/ or server/
    if (!matched && (normalized.startsWith('src/') || normalized.startsWith('server/'))) {
      matchedGroups.add('critical');
      reasons.add(`${file} → Fallback to critical smoke suite`);
      for (const f of TEST_GROUPS.critical) {
        affectedFiles.add(f);
      }
    }
  }

  return {
    files: [...affectedFiles],
    groups: [...matchedGroups],
    reasons: [...reasons]
  };
}
