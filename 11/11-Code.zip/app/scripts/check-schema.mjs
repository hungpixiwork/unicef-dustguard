import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('=== TABLES IN DEV.DB ===');
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
console.log(tables.map(t => t.name));

console.log('=== SENSORS TABLE INFO ===');
console.log(db.prepare("PRAGMA table_info(sensors)").all());

console.log('=== SENSOR_READINGS TABLE INFO ===');
console.log(db.prepare("PRAGMA table_info(sensor_readings)").all());

console.log('=== SITES TABLE INFO ===');
console.log(db.prepare("PRAGMA table_info(sites)").all());

console.log('=== SENSORS COUNT & SAMPLE ===');
console.log('Count:', db.prepare("SELECT COUNT(*) as count FROM sensors").get());
console.log('Sample:', db.prepare("SELECT * FROM sensors LIMIT 3").all());

console.log('=== SENSOR_READINGS COUNT & SAMPLE ===');
console.log('Count:', db.prepare("SELECT COUNT(*) as count FROM sensor_readings").get());
console.log('Sample:', db.prepare("SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 3").all());
