import Database from 'better-sqlite3';
import { readFileSync } from 'fs';

console.log('====================================================');
console.log('🔍 FULL DATABASE ARCHITECTURE AUDIT (LOCAL vs LIVE)');
console.log('====================================================\n');

// 1. Parse all CREATE TABLE from prisma/d1-schema.sql
const schemaSql = readFileSync('prisma/d1-schema.sql', 'utf-8');
const tableMatches = [...schemaSql.matchAll(/CREATE TABLE(?:\s+IF NOT EXISTS)?\s+["`]?([a-zA-Z0-9_]+)["`]?/gi)];
const expectedTables = [...new Set(tableMatches.map(m => m[1].toLowerCase()))].sort();

console.log(`📋 1. SSOT Schema (d1-schema.sql) defines ${expectedTables.length} tables:`);
console.log(`   ${expectedTables.join(', ')}\n`);

// 2. Audit SQLite Local (prisma/dev.db)
const localDb = new Database('prisma/dev.db');
const localTableRows = localDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE '_prisma_%' AND name NOT LIKE 'sqlite_%'").all();
const localTables = localTableRows.map(r => r.name.toLowerCase()).sort();

console.log(`💾 2. Local Database (prisma/dev.db) has ${localTables.length} tables:`);
const missingInLocal = expectedTables.filter(t => !localTables.includes(t));
if (missingInLocal.length > 0) {
  console.log(`   ⚠️ MISSING in Local DB (${missingInLocal.length}): ${missingInLocal.join(', ')}`);
} else {
  console.log('   ✅ Local DB has 100% of expected tables.');
}

// Check Foreign Keys on Local DB
const fkErrors = localDb.pragma('foreign_key_check');
console.log(`   Foreign Key Check on Local DB: ${fkErrors.length === 0 ? '✅ PASSED (0 violations)' : `❌ ${fkErrors.length} violations`}`);

// Check Integrity on Local DB
const integrity = localDb.pragma('integrity_check', { simple: true });
console.log(`   Integrity Check on Local DB: ${integrity === 'ok' ? '✅ PASSED (ok)' : `❌ ${integrity}`}\n`);

console.log('====================================================');
