import fs from 'fs';
import path from 'path';

const ROOT_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard');

function scanDeadCode() {
  const data = JSON.parse(fs.readFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/scripts/deep_audit_result.json', 'utf8'));
  const jsFiles = data.fileBreakdown.filter(f => ['.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs'].includes(f.ext));
  
  const fileSet = new Set(jsFiles.map(f => f.relPath.replace(/\\/g, '/')));
  const importCount = {};
  fileSet.forEach(f => { importCount[f] = 0; });

  const importRegex = /(?:import\s+(?:[\s\S]*?from\s+)?['"](.*?)['"]|export\s+(?:[\s\S]*?from\s+)['"](.*?)['"]|require\(['"](.*?)['"]\)|import\(['"](.*?)['"]\))/g;

  jsFiles.forEach(f => {
    try {
      const content = fs.readFileSync(path.resolve(ROOT_DIR, f.relPath), 'utf8');
      let match;
      while ((match = importRegex.exec(content)) !== null) {
        const importPath = match[1] || match[2] || match[3] || match[4];
        if (!importPath || !importPath.startsWith('.')) continue;

        const currentDir = path.dirname(f.relPath);
        const resolved = path.normalize(path.join(currentDir, importPath)).replace(/\\/g, '/');

        const candidates = [
          resolved,
          resolved + '.js',
          resolved + '.jsx',
          resolved + '.ts',
          resolved + '.tsx',
          resolved + '.mjs',
          resolved + '/index.js',
          resolved + '/index.jsx',
          resolved + '/index.ts',
          resolved + '/index.tsx'
        ];

        for (const c of candidates) {
          if (fileSet.has(c)) {
            importCount[c] = (importCount[c] || 0) + 1;
            break;
          }
        }
      }
    } catch(e) {}
  });

  // Check alias imports e.g. @/... or ~/..
  // Let's also check if file names are mentioned as strings or in router configuration
  const allContents = jsFiles.map(f => {
    try {
      return { path: f.relPath.replace(/\\/g, '/'), content: fs.readFileSync(path.resolve(ROOT_DIR, f.relPath), 'utf8') };
    } catch(e) {
      return { path: f.relPath.replace(/\\/g, '/'), content: '' };
    }
  });

  const deadCandidates = [];

  for (const [file, count] of Object.entries(importCount)) {
    // Exclude root entry points, tests, migrations, scripts
    if (
      file.startsWith('app/tests/') ||
      file.startsWith('app/scripts/') ||
      file.startsWith('app/migrations/') ||
      file.startsWith('scripts/') ||
      file.startsWith('server/auth/') ||
      file === 'app/src/main.jsx' ||
      file === 'app/src/App.jsx' ||
      file.startsWith('app/src/apps/') ||
      file === 'app/server/index.js' ||
      file === 'app/server/worker.js' ||
      file === 'app/api/[...all].js' ||
      file.startsWith('app/server/routes/') ||
      file.includes('vite.config') ||
      file.includes('tailwind.config')
    ) {
      continue;
    }

    if (count === 0) {
      // Check if the basename is referenced anywhere in any file content
      const base = path.basename(file, path.extname(file));
      const referenced = allContents.some(item => item.path !== file && item.content.includes(base));
      deadCandidates.push({
        file,
        count,
        referencedAnywhere: referenced
      });
    }
  }

  console.log(`\n=== DEAD CODE AUDIT RESULT ===`);
  console.log(`Total JS/TS files analyzed: ${jsFiles.length}`);
  console.log(`Files with 0 direct relative imports: ${deadCandidates.length}`);
  
  const trueOrphans = deadCandidates.filter(c => !c.referencedAnywhere);
  const indirectlyReferenced = deadCandidates.filter(c => c.referencedAnywhere);

  console.log(`\n1. True Orphans (0 imports AND no identifier matches in codebase): ${trueOrphans.length}`);
  trueOrphans.forEach(o => console.log('  [ORPHAN] ' + o.file));

  console.log(`\n2. Dynamically or Ident-referenced files (0 direct relative imports, but name mentioned in router/dispatch): ${indirectlyReferenced.length}`);
  indirectlyReferenced.slice(0, 20).forEach(o => console.log('  [DYNAMIC/INDIRECT] ' + o.file));

  fs.writeFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/scripts/dead_code_result.json', JSON.stringify({ trueOrphans, indirectlyReferenced }, null, 2));
}

scanDeadCode();
