#!/usr/bin/env node
/**
 * DustGuard VN - Safety Warning for Remote Cloudflare Connection
 * Explicit console banner to prevent accidental production data modification.
 */
const red = '\x1b[41m\x1b[37m\x1b[1m';
const yellow = '\x1b[33m\x1b[1m';
const reset = '\x1b[0m';
const cyan = '\x1b[36m';
const bold = '\x1b[1m';

console.log('\n');
console.log(`${red} ╔══════════════════════════════════════════════════════════════════════════════╗ ${reset}`);
console.log(`${red} ║ 🚨 CẢNH BÁO: BẠN ĐANG KẾT NỐI VÀO CLOUDFLARE CLOUD THẬT (REMOTE MODE) 🚨       ║ ${reset}`);
console.log(`${red} ╚══════════════════════════════════════════════════════════════════════════════╝ ${reset}`);
console.log(`${yellow} ⚠️  CHÚ Ý QUAN TRỌNG:${reset}`);
console.log(`  👉 Mọi thao tác CREATE / UPDATE / DELETE sẽ ảnh hưởng trực tiếp ${yellow}DỮ LIỆU THẬT${reset}!`);
console.log(`  👉 Cloudflare D1 Database : ${cyan}dustguard-production${reset} (ID: ad40205a-ec4b-40f3-8ab2-c2e7b9e78699)`);
console.log(`  👉 Cloudflare R2 Bucket   : ${cyan}dustguard-storage${reset}`);
console.log(`  👉 Worker Local Proxy Port: ${cyan}http://127.0.0.1:8787${reset} -> Cloudflare Edge`);
console.log(`  👉 Safety Write Guard     : ${bold}ALLOW_REMOTE_WRITES=${process.env.ALLOW_REMOTE_WRITES || 'false'}${reset}`);
console.log(`${yellow} ------------------------------------------------------------------------------ ${reset}\n`);
