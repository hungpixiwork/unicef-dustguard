import fs from 'fs';
import path from 'path';

function scanDir(dir) {
  let files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory() && entry.name !== 'node_modules') {
      files = files.concat(scanDir(p));
    } else if (entry.isFile() && (p.endsWith('.js') || p.endsWith('.jsx') || p.endsWith('.ts') || p.endsWith('.tsx'))) {
      files.push(p);
    }
  }
  return files;
}

const allFiles = scanDir('src');
const adminApiContent = fs.readFileSync('src/lib/api/admin-api.js', 'utf8');
const methods = [...adminApiContent.matchAll(/([a-zA-Z0-9_]+)\s*:\s*(?:mutation\()?/g)].map(m => m[1]);

console.log('--- ADMIN API USAGE ---');
for (const method of methods) {
  const usedIn = [];
  for (const file of allFiles) {
    if (file.includes('admin-api.js')) continue;
    const c = fs.readFileSync(file, 'utf8');
    if (c.includes(method)) {
      usedIn.push(file);
    }
  }
  console.log(`${method}: ${usedIn.length ? usedIn.join(', ') : 'UNUSED'}`);
}
