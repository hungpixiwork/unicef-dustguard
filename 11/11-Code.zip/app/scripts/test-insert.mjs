import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));
const id = 'sen-tx99-' + Date.now();
const now = new Date().toISOString();

db.prepare('INSERT INTO sensors (id, code, name, siteId, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, 'TX-99', 'TX-99 · Trạm Thử Nghiệm Mới', 'site-vd1-001', 'ACTIVE', now, now);
db.prepare('INSERT INTO sensor_readings (id, sensorId, pm10, pm25, timestamp) VALUES (?, ?, ?, ?, ?)').run('rd-tx99', id, 195, 110, now);

console.log('Inserted TX-99 into D1!');
const count = db.prepare('SELECT count(*) as count FROM sensors').get();
console.log('Total stations now:', count);
