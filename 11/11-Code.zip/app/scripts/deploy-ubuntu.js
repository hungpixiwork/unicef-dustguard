import { Client } from 'ssh2';

const vpsConfig = {
  host: '103.173.226.37',
  port: 22,
  username: 'root',
  password: 'a0NS1Y*Z1CrX1'
};

const domain = 'dustguard.phamphunguyenhung.com';
const token = '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';
const repoUrl = `https://${token}@github.com/hungpixi/dust-guard-vn.git`;
const deployPath = '/root/dust-guard-vn';

const nginxConfig = `
server {
    listen 80;
    server_name ${domain};

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
`;

const envConfig = `
NODE_ENV=production
PORT=3001
DATABASE_URL="file:./dev.db"
VITE_API_BASE_URL=/api
BETTER_AUTH_SECRET=uFb8G5fMoVIa59LXJp4QIwn4nkuKMs5j9Fp/RH0/UTA=
BETTER_AUTH_URL=https://${domain}
CORS_ORIGINS=https://${domain}
DEMO_ADMIN_EMAIL=admin@dustguard.vn
DEMO_ADMIN_PASSWORD=123456
DEMO_ADMIN_NAME=Admin DustGuard
ENABLE_MOCK_DATA=true
AI_GATEWAY_BASE_URL=https://openrouter.ai/api/v1
AI_DEFAULT_MODEL=google/gemini-2.5-flash:free
`;

function executeSSHCommands(conn, commands) {
  return new Promise((resolve, reject) => {
    conn.exec(commands, (err, stream) => {
      if (err) return reject(err);
      let stdout = '';
      let stderr = '';
      stream.on('close', (code, signal) => {
        resolve({ code, stdout, stderr });
      }).on('data', (data) => {
        stdout += data.toString();
        process.stdout.write(data);
      }).stderr.on('data', (data) => {
        stderr += data.toString();
        process.stderr.write(data);
      });
    });
  });
}

async function main() {
  const conn = new Client();
  console.log('Connecting to remote Ubuntu VPS...');
  
  conn.on('ready', async () => {
    console.log('SSH Connection successful!');
    
    try {
      // Step 1: Install Nginx & Certbot
      console.log('\n--- STEP 1: Installing Nginx & Certbot ---');
      await executeSSHCommands(conn, 'apt-get update && apt-get install -y nginx certbot python3-certbot-nginx');

      // Step 2: Configure Nginx virtual host
      console.log('\n--- STEP 2: Configuring Nginx virtual host ---');
      const escapedNginxConfig = nginxConfig.replace(/"/g, '\\"').replace(/`/g, '\\`');
      await executeSSHCommands(conn, `cat << 'EOF' > /etc/nginx/sites-available/${domain}\n${nginxConfig}\nEOF`);
      await executeSSHCommands(conn, `ln -sf /etc/nginx/sites-available/${domain} /etc/nginx/sites-enabled/`);
      await executeSSHCommands(conn, 'nginx -t && systemctl restart nginx');

      // Step 3: Clone or Update Repository
      console.log('\n--- STEP 3: Cloning/Updating Repository ---');
      const checkRepo = await executeSSHCommands(conn, `ls -d ${deployPath} 2>/dev/null || echo "not found"`);
      if (checkRepo.stdout.includes('not found')) {
        await executeSSHCommands(conn, `git clone ${repoUrl} ${deployPath}`);
      } else {
        await executeSSHCommands(conn, `cd ${deployPath} && git reset --hard && git pull`);
      }

      // Step 4: Configure Environment Variables
      console.log('\n--- STEP 4: Creating .env file ---');
      await executeSSHCommands(conn, `cat << 'EOF' > ${deployPath}/.env\n${envConfig}\nEOF`);

      // Step 5: Install Project Dependencies and Build
      console.log('\n--- STEP 5: Installing npm modules & building project ---');
      await executeSSHCommands(conn, `cd ${deployPath} && npm install`);
      
      // Step 6: Generate Prisma Client & Push DB schema
      console.log('\n--- STEP 6: Running Prisma DB generate and push ---');
      await executeSSHCommands(conn, `cd ${deployPath} && npx prisma generate && npx prisma db push`);

      // Step 7: Build the application frontend
      console.log('\n--- STEP 7: Building application ---');
      await executeSSHCommands(conn, `cd ${deployPath} && npm run build`);

      // Step 8: Start/Restart Application via PM2
      console.log('\n--- STEP 8: Starting application with PM2 ---');
      await executeSSHCommands(conn, `pm2 delete dustguard 2>/dev/null || true`);
      await executeSSHCommands(conn, `cd ${deployPath} && pm2 start server/index.js --name dustguard --node-args="--import dotenv/config"`);
      await executeSSHCommands(conn, 'pm2 save');

      console.log('\n======================================================');
      console.log('DEPLOYS AND CONFIGURATIONS COMPLETED SUCCESSFULLY!');
      console.log(`Domain pointed to: ${domain}`);
      console.log(`Port proxy: 3001`);
      console.log('Next steps:');
      console.log(`1. Point your DNS A Record for "${domain}" to "${vpsConfig.host}".`);
      console.log('2. Once DNS propagates, run SSL setup command on VPS:');
      console.log(`   certbot --nginx -d ${domain} --non-interactive --agree-tos --email phamphunguyenhung@gmail.com`);
      console.log('======================================================');
      
    } catch (e) {
      console.error('Error during deployment:', e);
    } finally {
      conn.end();
    }
  }).on('error', (err) => {
    console.error('Connection error:', err);
  }).connect(vpsConfig);
}

main();
