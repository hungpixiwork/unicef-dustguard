import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const workerFile = path.resolve(__dirname, '../../server/worker.js');

async function runWorkerArchitectureAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 8: CLOUDFLARE WORKER ROUTE & D1 PERSISTENCE SSOT');
  console.log('========================================================\n');

  const content = fs.readFileSync(workerFile, 'utf-8');
  const lines = content.split('\n');

  // Match app.get, app.post, app.put, app.delete, app.patch
  const routeRegex = /app\.(get|post|put|patch|delete)\(\s*['"]([^'"]+)['"]/g;
  const routes = [];
  let match;

  while ((match = routeRegex.exec(content)) !== null) {
    const method = match[1].toUpperCase();
    const endpoint = match[2];
    routes.push({ method, endpoint });
  }

  console.log(`Tìm thấy ${routes.length} route endpoints trong server/worker.js.\n`);

  // Phân tích các khối chức năng
  const categorized = {
    d1Direct: [],
    r2Storage: [],
    serviceRepository: [],
    authEndpoints: [],
    healthStatic: []
  };

  for (const r of routes) {
    if (r.endpoint.includes('/api/auth') || r.endpoint.includes('/login') || r.endpoint.includes('/register')) {
      categorized.authEndpoints.push(r);
    } else if (r.endpoint.includes('/uploads') || r.endpoint.includes('/api/upload') || r.endpoint.includes('/api/files')) {
      categorized.r2Storage.push(r);
    } else if (r.endpoint.includes('/health') || r.endpoint.includes('/docs') || r.endpoint.includes('/openapi')) {
      categorized.healthStatic.push(r);
    } else {
      categorized.d1Direct.push(r);
    }
  }

  console.log(`- Auth Endpoints: ${categorized.authEndpoints.length}`);
  console.log(`- R2 Storage Endpoints: ${categorized.r2Storage.length}`);
  console.log(`- D1 CRUD & Domain Endpoints: ${categorized.d1Direct.length}`);
  console.log(`- System & Static Endpoints: ${categorized.healthStatic.length}`);

  // Kiểm tra sự tồn tại của route /api/auth/logout
  const hasLogout = routes.some(r => r.endpoint.includes('logout'));
  console.log(`\nKiểm tra POST /api/auth/logout trên Cloudflare Worker: ${hasLogout ? '✅ CÓ' : '❌ CHƯA CÓ (Cần bổ sung)'}`);

  // Kiểm tra binding D1 trong worker
  const d1UsageCount = (content.match(/c\.env\.DB/g) || []).length;
  const r2UsageCount = (content.match(/c\.env\.(STORAGE|EVIDENCE_BUCKET)/g) || []).length;
  console.log(`\nThống kê D1 Binding (c.env.DB): ${d1UsageCount} lần xuất hiện.`);
  console.log(`Thống kê R2 Binding (c.env.STORAGE / EVIDENCE_BUCKET): ${r2UsageCount} lần xuất hiện.`);
}

runWorkerArchitectureAudit().catch(console.error);
