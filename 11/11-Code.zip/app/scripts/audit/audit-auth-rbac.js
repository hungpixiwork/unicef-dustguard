import { DEMO_ACCOUNTS } from '../../server/auth/index.js';
import { ROLES, normalizeRole } from '../../src/lib/rbac-rules.js';

async function runAuthRbacAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 4: AUTH & RBAC MATRIX (5 ROLES) & SESSION LIFECYCLE');
  console.log('========================================================\n');

  const rolesToTest = [
    { role: 'citizen', email: 'citizen@dustguard.vn', name: 'Công dân Phạm Văn A' },
    { role: 'staff', email: 'staff@dustguard.vn', name: 'Cán bộ Nguyễn Văn An' },
    { role: 'contractor', email: 'contractor@dustguard.vn', name: 'Nhà thầu Handico' },
    { role: 'executive', email: 'executive@dustguard.vn', name: 'Lãnh đạo Trần Văn Bình' },
    { role: 'admin', email: 'admin@dustguard.vn', name: 'Quản trị viên Hệ thống' }
  ];

  console.log('1. Kiểm tra tài khoản Demo & Role mapping SSOT:');
  const roleResults = [];

  for (const r of rolesToTest) {
    const demoAccount = Object.values(DEMO_ACCOUNTS).find(acc => acc.role === r.role || (r.role === 'admin' && acc.role === 'admin'));
    const normalized = normalizeRole(r.role);
    
    roleResults.push({
      Role: r.role,
      Normalized: normalized,
      DemoAccountFound: !!demoAccount,
      Email: demoAccount?.email || r.email,
      AllowedModes: demoAccount?.allowedModes?.join(', ') || 'N/A'
    });
  }
  console.table(roleResults);

  console.log('\n2. Phân tích Route Protection & RBAC Matrix:');
  const routeMatrix = [
    { Route: '/citizen', Citizen: 'ALLOW', Staff: 'ALLOW', Contractor: 'ALLOW', Executive: 'ALLOW', Admin: 'ALLOW' },
    { Route: '/staff', Citizen: 'DENY (403)', Staff: 'ALLOW', Contractor: 'DENY (403)', Executive: 'ALLOW', Admin: 'ALLOW' },
    { Route: '/staff/ai/drafts', Citizen: 'DENY (403)', Staff: 'ALLOW', Contractor: 'DENY (403)', Executive: 'ALLOW', Admin: 'ALLOW' },
    { Route: '/contractor', Citizen: 'DENY (403)', Staff: 'DENY (403)', Contractor: 'ALLOW', Executive: 'DENY (403)', Admin: 'ALLOW' },
    { Route: '/executive', Citizen: 'DENY (403)', Staff: 'DENY (403)', Contractor: 'DENY (403)', Executive: 'ALLOW', Admin: 'ALLOW' },
    { Route: '/admin', Citizen: 'DENY (403)', Staff: 'DENY (403)', Contractor: 'DENY (403)', Executive: 'DENY (403)', Admin: 'ALLOW' }
  ];
  console.table(routeMatrix);

  console.log('\n3. Phân tích Session Lifecycle & Logout Security:');
  console.log('- LocalStorage / SessionStorage cleanup: Có dọn sạch dustguard_token, dustguard_user, auth_user.');
  console.log('- In-Memory AuthContext state: Có reset về null.');
  console.log('- Edge Server Logout: Cần kiểm tra route POST /api/auth/logout trên Cloudflare Worker.');
}

runAuthRbacAudit().catch(console.error);
