import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const srcDir = path.resolve(__dirname, '../../src');

function walkDir(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      if (!filePath.includes('node_modules') && !filePath.includes('.git') && !filePath.includes('dist')) {
        walkDir(filePath, fileList);
      }
    } else if (/\.(jsx?|tsx?|css)$/.test(file)) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

async function runBadgesAndGlassAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 6 & 7: SSOT BADGES & GLASSMORPHISM ELIMINATION');
  console.log('========================================================\n');

  const allFiles = walkDir(srcDir);
  console.log(`Đang quét ${allFiles.length} files trong src/...`);

  // 1. Quét Glassmorphism
  const glassMatches = [];
  const backdropRegex = /backdrop-(blur|filter)|-webkit-backdrop-filter/i;

  for (const file of allFiles) {
    const relPath = path.relative(srcDir, file).replace(/\\/g, '/');
    const content = fs.readFileSync(file, 'utf-8');
    const lines = content.split('\n');

    lines.forEach((line, idx) => {
      if (backdropRegex.test(line)) {
        glassMatches.push({
          file: relPath,
          line: idx + 1,
          content: line.trim(),
          isModalOverlay: line.includes('modal') || line.includes('overlay') || line.includes('dialog') || line.includes('fixed inset-0'),
          isResetNone: line.includes('none !important') || line.includes('backdrop-filter: none')
        });
      }
    });
  }

  console.log(`\n1. Kết quả quét Backdrop Blur / Glassmorphism (${glassMatches.length} occurrences):`);
  const activeGlass = glassMatches.filter(g => !g.isResetNone);
  console.log(`- Tổng số dòng có backdrop-blur / filter: ${glassMatches.length}`);
  console.log(`- Số dòng là CSS Reset (none !important): ${glassMatches.filter(g => g.isResetNone).length}`);
  console.log(`- Số dòng còn kích hoạt backdrop-filter thực tế: ${activeGlass.length}`);

  if (activeGlass.length > 0) {
    console.table(activeGlass.map(g => ({
      File: g.file,
      Line: g.line,
      Content: g.content.slice(0, 80),
      IsModalOverlay: g.isModalOverlay ? 'YES' : 'NO'
    })));
  } else {
    console.log('✅ ZERO GLASSMORPHISM: Không tìm thấy bất kỳ style glassmorphism vô ý nào trong các component.');
  }

  // 2. Quét Hardcoded Status Badge / Color mapping
  console.log('\n2. Quét Hardcoded Status & Risk Badge Mappings:');
  const hardcodedBadgePatterns = [];
  const statusCheckRegex = /status\s*===\s*['"](open|in_progress|resolved|closed|pending|processing|completed)['"]\s*\?\s*['"][^'"]+['"]/i;

  for (const file of allFiles) {
    if (file.includes('shared/index.jsx') || file.includes('tokens.js') || file.includes('statusMeta.js') || file.includes('rbac-rules.js')) {
      continue; // SSoT definitions are expected
    }
    const relPath = path.relative(srcDir, file).replace(/\\/g, '/');
    const content = fs.readFileSync(file, 'utf-8');
    const lines = content.split('\n');

    lines.forEach((line, idx) => {
      if (statusCheckRegex.test(line)) {
        hardcodedBadgePatterns.push({
          file: relPath,
          line: idx + 1,
          content: line.trim().slice(0, 100)
        });
      }
    });
  }

  console.log(`- Tìm thấy ${hardcodedBadgePatterns.length} inline hardcoded status color patterns:`);
  if (hardcodedBadgePatterns.length > 0) {
    console.table(hardcodedBadgePatterns.slice(0, 10));
  } else {
    console.log('✅ SSoT BADGES: Toàn bộ status mapping sử dụng SSoT helper hoặc StatusBadge.');
  }
}

runBadgesAndGlassAudit().catch(console.error);
