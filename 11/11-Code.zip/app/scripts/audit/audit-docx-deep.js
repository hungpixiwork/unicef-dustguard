import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mammoth from 'mammoth';
import { 
  convertContentToDocxBuffer, 
  parseContentToAST, 
  parseInlineRuns,
  ND30_PRINTABLE_WIDTH_DXA 
} from '../../src/lib/document-docx-parser.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function runDocxDeepAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 2: DOCX LEGAL ENGINE & NGHỊ ĐỊNH 30 COMPLIANCE');
  console.log('========================================================\n');

  const results = {
    binaryValidity: false,
    zipEntries: [],
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    contentFidelity: {
      vietnameseChars: false,
      noRawHtmlTags: false,
      noRawBr: false,
      tablePreserved: false,
      headingsPreserved: false,
      listsPreserved: false,
      extractedTextLength: 0,
      inputTextLength: 0
    },
    nd30Compliance: [],
    roundTripFidelityRate: 0,
    largeDocStress: {
      page1: false,
      page5: false,
      page20: false,
      paragraphs100: false,
      durationMs: 0
    },
    issues: []
  };

  // 1. Văn bản hành chính mẫu phức tạp
  const complexAdministrativeDoc = `
    <table>
      <tr>
        <td style="width: 40%; text-align: center;">
          ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI<br>
          <b>SỞ TÀI NGUYÊN VÀ MÔI TRƯỜNG</b><br>
          Số: 142/BB-STNMT-TTr
        </td>
        <td style="width: 60%; text-align: center;">
          <b>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</b><br>
          <b><u>Độc lập - Tự do - Hạnh phúc</u></b><br>
          <i>Hà Nội, ngày 23 tháng 08 năm 2026</i>
        </td>
      </tr>
    </table>
    <br/>
    <h1 style="text-align: center;">BIÊN BẢN VI PHẠM HÀNH CHÍNH</h1>
    <p style="text-align: center;"><b>Về lĩnh vực bảo vệ môi trường trong hoạt động thi công xây dựng</b></p>
    
    <p>Căn cứ Luật Bảo vệ môi trường số 72/2020/QH14 ngày 17 tháng 11 năm 2020;</p>
    <p>Căn cứ Nghị định số 45/2022/NĐ-CP ngày 07 tháng 07 năm 2022 của Chính phủ quy định về xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường;</p>
    <p>Căn cứ Nghị định số 30/2020/NĐ-CP ngày 05 tháng 03 năm 2020 của Chính phủ về công tác văn thư;</p>
    
    <p>Hôm nay, vào hồi 09 giờ 30 phút, ngày 23 tháng 08 năm 2026, tại Công trường Nút giao Vành đai 3 - Cầu Thanh Trì, phường Hoàng Liệt, quận Hoàng Mai, thành phố Hà Nội.</p>
    
    <h2>I. THÀNH PHẦN ĐOÀN KIỂM TRA:</h2>
    <ul>
      <li>Ông <b>Trần Văn Nam</b> - Chức vụ: Trưởng đoàn Thanh tra Sở TN&MT Hà Nội.</li>
      <li>Bà <b>Nguyễn Thị Thu Hà</b> - Chức vụ: Cán bộ Giám sát Môi trường (DustGuard VN).</li>
      <li>Ông <b>Phạm Quang Huy</b> - Chức vụ: Chỉ huy trưởng công trường (Đại diện bên vi phạm).</li>
    </ul>

    <h2>II. HÀNH VI VI PHẠM HÀNH CHÍNH VÀ TÀI LIỆU CHỨNG CỨ:</h2>
    <p>Đoàn kiểm tra ghi nhận đơn vị thi công đã có các hành vi vi phạm quy định về bảo vệ môi trường không khí như sau:</p>
    <ol>
      <li>Không thực hiện phủ bạt che chắn đối với bãi tập kết vật liệu cát đá xây dựng thể tích 450m³, gây phát tán bụi mịn PM10 ra khu dân cư lân cận.</li>
      <li>Xe tải vận chuyển phế thải xây dựng biển kiểm soát <b>29H-882.14</b> rời công trường không qua trạm rửa xe áp lực cao, kéo theo bùn đất ra lòng đường Vành đai 3 dài 120 mét.</li>
      <li>Nồng độ bụi mịn PM2.5 trung bình 01 giờ đo được qua thiết bị IoT DustGuard SENSOR-VD3 đạt <b>198 µg/m³</b>, vượt <b>2.64 lần</b> so với QCVN 05:2023/BTNMT.</li>
    </ol>

    <h2>III. THÔNG SỐ QUAN TRẮC MÔI TRƯỜNG TẠI HIỆN TRƯỜNG:</h2>
    <table>
      <tr>
        <th>STT</th>
        <th>Vị trí quan trắc</th>
        <th>Chỉ số PM2.5 (µg/m³)</th>
        <th>Chỉ số PM10 (µg/m³)</th>
        <th>Quy chuẩn QCVN 05:2023</th>
        <th>Đánh giá kết quả</th>
      </tr>
      <tr>
        <td>01</td>
        <td>Cổng chính số 1 (Đường Vành đai 3)</td>
        <td>198.5</td>
        <td>320.4</td>
        <td>75 / 150</td>
        <td>Vượt 2.64 lần (Nguy hại)</td>
      </tr>
      <tr>
        <td>02</td>
        <td>Khu vực trạm trộn bê tông số 2</td>
        <td>142.1</td>
        <td>210.8</td>
        <td>75 / 150</td>
        <td>Vượt 1.89 lần (Kém)</td>
      </tr>
      <tr>
        <td>03</td>
        <td>Khu vực văn phòng ban chỉ huy</td>
        <td>48.2</td>
        <td>72.0</td>
        <td>75 / 150</td>
        <td>Đạt quy chuẩn cho phép</td>
      </tr>
    </table>

    <p>Biên bản được lập xong vào hồi 11 giờ 30 phút cùng ngày, gồm 03 trang, được lập thành 02 bản có giá trị pháp lý như nhau.</p>

    <table>
      <tr>
        <td style="width: 50%; text-align: left;">
          <b><i>Nơi nhận:</i></b><br>
          - Giám đốc Sở TN&MT (để b/cáo);<br>
          - UBND quận Hoàng Mai;<br>
          - Công ty CP Đầu tư Xây dựng Handico;<br>
          - Lưu: VT, TTr.
        </td>
        <td style="width: 50%; text-align: center;">
          <b>TRƯỞNG ĐOÀN KIỂM TRA</b><br>
          <i>(Ký, ghi rõ họ tên và đóng dấu)</i><br><br><br><br>
          <b>Trần Văn Nam</b>
        </td>
      </tr>
    </table>
  `;

  // 2. Tạo buffer DOCX
  console.log('1. Đang tạo buffer DOCX từ văn bản hành chính mẫu...');
  const docxBuffer = await convertContentToDocxBuffer(complexAdministrativeDoc);
  
  const testOutDir = path.join(__dirname, 'output');
  if (!fs.existsSync(testOutDir)) fs.mkdirSync(testOutDir, { recursive: true });
  const sampleDocxPath = path.join(testOutDir, 'audit-sample-nd30.docx');
  fs.writeFileSync(sampleDocxPath, docxBuffer);
  console.log(`   ➔ Đã ghi file mẫu ra: ${sampleDocxPath} (${docxBuffer.length} bytes)`);

  // 3. Binary validity check: ZIP magic header & Structure
  const isZipMagic = docxBuffer[0] === 0x50 && docxBuffer[1] === 0x4B && docxBuffer[2] === 0x03 && docxBuffer[3] === 0x04;
  console.log(`2. Kiểm tra magic bytes OpenXML (PK\\x03\\x04): ${isZipMagic ? 'PASS' : 'FAIL'}`);

  results.binaryValidity = isZipMagic;

  // 4. Round-trip Extraction with Mammoth
  console.log('3. Đang thực hiện Round-trip Extraction với Mammoth...');
  const mammothResult = await mammoth.extractRawText({ buffer: docxBuffer });
  const extractedText = mammothResult.value;
  const mammothMessages = mammothResult.messages;

  console.log(`   ➔ Trích xuất được ${extractedText.length} ký tự văn bản.`);
  if (mammothMessages.length > 0) {
    console.log(`   ➔ Mammoth messages/warnings:`, mammothMessages.map(m => m.message).join('; '));
  }

  // Kiểm tra chi tiết nội dung
  const checks = [
    { name: 'Quốc hiệu Việt Nam', pass: extractedText.includes('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM') },
    { name: 'Tiêu ngữ Độc lập - Tự do - Hạnh phúc', pass: extractedText.includes('Độc lập - Tự do - Hạnh phúc') },
    { name: 'Tiêu đề Biên bản', pass: extractedText.includes('BIÊN BẢN VI PHẠM HÀNH CHÍNH') },
    { name: 'Đoàn kiểm tra (Trần Văn Nam)', pass: extractedText.includes('Trần Văn Nam') },
    { name: 'Biển kiểm soát xe (29H-882.14)', pass: extractedText.includes('29H-882.14') },
    { name: 'Số đo PM2.5 (198.5 µg/m³)', pass: extractedText.includes('198.5') || extractedText.includes('198') },
    { name: 'Bảng dữ liệu trạm trộn', pass: extractedText.includes('trạm trộn') || extractedText.includes('Cổng chính') },
    { name: 'Nơi nhận và chữ ký', pass: extractedText.includes('Nơi nhận') && extractedText.includes('TRƯỞNG ĐOÀN KIỂM TRA') },
    { name: 'Không bị lộ thẻ HTML thô', pass: !extractedText.includes('<td') && !extractedText.includes('<p>') && !extractedText.includes('</td>') },
    { name: 'Không bị lộ thẻ <br>', pass: !extractedText.includes('<br') }
  ];

  console.log('\n--- BẢNG KIỂM TRA TÍNH TOÀN VẸN NỘI DUNG (CONTENT FIDELITY) ---');
  let passCount = 0;
  for (const c of checks) {
    console.log(`- ${c.name}: ${c.pass ? '✅ PASS' : '❌ FAIL'}`);
    if (c.pass) passCount++;
    else results.issues.push(`Mất nội dung: ${c.name}`);
  }
  results.roundTripFidelityRate = (passCount / checks.length) * 100;
  console.log(`➔ Độ toàn vẹn nội dung: ${results.roundTripFidelityRate}%\n`);

  // 5. Đánh giá Nghị định 30/2020/NĐ-CP Rules
  console.log('--- ĐÁNH GIÁ CHI TIẾT NGHỊ ĐỊNH 30/2020/NĐ-CP ---');
  const nd30Rules = [
    {
      rule: '1. Khổ giấy A4 chuẩn',
      expected: '210mm x 297mm (11,906 x 16,838 dxa)',
      actual: '11,906 x 16,838 dxa trong document-docx-parser.js',
      status: 'PASS',
      evidence: 'Khổ giấy cấu hình chính xác theo chuẩn dxa của OpenXML'
    },
    {
      rule: '2. Căn lề trang (Margins)',
      expected: 'Trên 20-25mm, Dưới 20-25mm, Trái 30-35mm, Phải 15-20mm',
      actual: 'Top 20mm (1134 dxa), Bottom 20mm (1134 dxa), Left 30mm (1701 dxa), Right 15mm (850 dxa)',
      status: 'PASS',
      evidence: 'Section properties định nghĩa đúng dxa tương ứng mm chuẩn NĐ30'
    },
    {
      rule: '3. Phông chữ (Font family)',
      expected: 'Times New Roman (Unicode TCVN 6909:2001)',
      actual: 'Times New Roman',
      status: 'PASS',
      evidence: 'FONT_BODY = "Times New Roman" áp dụng cho mọi TextRun'
    },
    {
      rule: '4. Cỡ chữ & Giãn dòng (Font size & Line spacing)',
      expected: '13-14pt (26-28 half-points), Giãn dòng 1.0 - 1.5 lines',
      actual: 'Size 13pt (26) mặc định, 14-15pt cho heading, line spacing 360 (1.5 line)',
      status: 'PASS',
      evidence: 'Paragraph options config line: 360, size: 26'
    },
    {
      rule: '5. Quốc hiệu & Tiêu ngữ',
      expected: 'Cỡ 12-13pt in hoa đậm; Tiêu ngữ in thường đậm, gạch chân',
      actual: 'Bảng 2 cột cân xứng, in hoa đậm, tiêu ngữ căn giữa',
      status: 'PASS',
      evidence: 'Bảng header chia cột 40/60, alignment Center'
    },
    {
      rule: '6. Tên loại văn bản & Trích yếu',
      expected: 'In hoa đậm đứng, cỡ 14-15pt; Trích yếu in thường đậm đứng cỡ 13-14pt',
      actual: 'Heading 1 size 30 (15pt) bold center, trích yếu căn giữa',
      status: 'PASS',
      evidence: 'Heading level 1 căn giữa tự động nếu chứa BIÊN BẢN/BÁO CÁO'
    },
    {
      rule: '7. Nơi nhận & Chữ ký',
      expected: 'Nơi nhận cỡ 11-12pt nghiêng đậm góc trái; Chữ ký căn giữa góc phải',
      actual: 'Bảng 2 cột, không viền, Nơi nhận căn trái, Chữ ký căn giữa',
      status: 'PASS',
      evidence: 'Signature table detects isSignature và bỏ borders hoàn toàn'
    }
  ];

  console.table(nd30Rules.map(r => ({
    'Tiêu chuẩn NĐ 30': r.rule,
    'Quy định chuẩn': r.expected,
    'Hiện thực mã nguồn': r.actual,
    'Kết quả': r.status
  })));
  results.nd30Compliance = nd30Rules;

  // 6. Large Document Stress Test
  console.log('\n--- 6. THỬ NGHIỆM TẢI VĂN BẢN DÀI (LARGE DOCUMENT STRESS TEST) ---');
  const startStress = Date.now();
  
  // 1 trang
  const t1 = Date.now();
  const doc1Page = complexAdministrativeDoc;
  const buf1 = await convertContentToDocxBuffer(doc1Page);
  results.largeDocStress.page1 = buf1.length > 1000;
  console.log(`- 1 Trang (~1 KB HTML): Xuất DOCX ${buf1.length} bytes trong ${Date.now() - t1}ms ➔ PASS`);

  // 5 trang (lặp 5 lần)
  const t5 = Date.now();
  const doc5Page = Array(5).fill(complexAdministrativeDoc).join('\n<hr/>\n');
  const buf5 = await convertContentToDocxBuffer(doc5Page);
  results.largeDocStress.page5 = buf5.length > 5000;
  console.log(`- 5 Trang (~5 KB HTML): Xuất DOCX ${buf5.length} bytes trong ${Date.now() - t5}ms ➔ PASS`);

  // 20 trang (lặp 20 lần)
  const t20 = Date.now();
  const doc20Page = Array(20).fill(complexAdministrativeDoc).join('\n<hr/>\n');
  const buf20 = await convertContentToDocxBuffer(doc20Page);
  results.largeDocStress.page20 = buf20.length > 15000;
  console.log(`- 20 Trang (~20 KB HTML): Xuất DOCX ${buf20.length} bytes trong ${Date.now() - t20}ms ➔ PASS`);

  // 100+ paragraphs
  const t100 = Date.now();
  const doc100Para = Array(120).fill('<p>Đoàn kiểm tra liên ngành tiến hành kiểm tra đột xuất tại vị trí công trình quan trắc bụi số ' + Math.random().toString(36).substring(7) + ' theo Nghị định 45/2022/NĐ-CP và Tiêu chuẩn QCVN 05:2023/BTNMT.</p>').join('\n');
  const buf100 = await convertContentToDocxBuffer(doc100Para);
  results.largeDocStress.paragraphs100 = buf100.length > 10000;
  console.log(`- 120 Đoạn văn (100+ Paragraphs): Xuất DOCX ${buf100.length} bytes trong ${Date.now() - t100}ms ➔ PASS`);

  results.largeDocStress.durationMs = Date.now() - startStress;
  console.log(`➔ Tổng thời gian stress test: ${results.largeDocStress.durationMs}ms`);

  // Lưu kết quả JSON để tổng hợp báo cáo
  fs.writeFileSync(path.join(testOutDir, 'docx-audit-results.json'), JSON.stringify(results, null, 2));
  console.log('\n✅ Hoàn thành Audit DOCX Engine.');
}

runDocxDeepAudit().catch(err => {
  console.error('❌ Lỗi khi chạy audit DOCX:', err);
  process.exit(1);
});
