import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const srcDir = path.resolve(__dirname, '../../src');

function walkDir(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      if (!filePath.includes('node_modules') && !filePath.includes('.git') && !filePath.includes('dist')) {
        walkDir(filePath, fileList);
      }
    } else if (/\.(jsx?|tsx?)$/.test(file)) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

async function runKeywordsAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 10: KEYWORDS SCAN (TODO, FIXME, HARDCODED LOCALHOST)');
  console.log('========================================================\n');

  const allFiles = walkDir(srcDir);
  const keywords = ['localhost', '127.0.0.1', 'TODO', 'FIXME', 'HACK', 'fake', 'sample', 'temp'];
  const results = {};
  keywords.forEach(k => results[k] = []);

  for (const file of allFiles) {
    const relPath = path.relative(srcDir, file).replace(/\\/g, '/');
    const content = fs.readFileSync(file, 'utf-8');
    const lines = content.split('\n');

    lines.forEach((line, idx) => {
      keywords.forEach(kw => {
        if (line.toLowerCase().includes(kw.toLowerCase())) {
          results[kw].push({
            file: relPath,
            line: idx + 1,
            snippet: line.trim().slice(0, 100)
          });
        }
      });
    });
  }

  console.log('--- KẾT QUẢ QUÉT TỪ KHÓA TRONG SRC ---');
  for (const kw of keywords) {
    console.log(`- "${kw}": ${results[kw].length} occurrences`);
  }
}

runKeywordsAudit().catch(console.error);
