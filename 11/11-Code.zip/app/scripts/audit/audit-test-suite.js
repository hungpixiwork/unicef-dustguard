import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const testsDir = path.resolve(__dirname, '../../tests');

async function runTestSuiteAudit() {
  console.log('========================================================');
  console.log('🔬 AUDIT 9: TEST SUITE QUALITY & COVERAGE AUDIT');
  console.log('========================================================\n');

  const files = fs.readdirSync(testsDir).filter(f => f.endsWith('.test.js') || f.endsWith('.js'));
  console.log(`Tổng số file test trong thư mục tests/: ${files.length} files.\n`);

  const categorized = {
    unit: [],
    integration: [],
    apiWorker: [],
    database: [],
    uiLayout: [],
    falseGreens: []
  };

  for (const file of files) {
    const filePath = path.join(testsDir, file);
    const content = fs.readFileSync(filePath, 'utf-8');

    // Phân loại
    if (file.includes('ui') || file.includes('layout') || file.includes('accessibility') || file.includes('primitives')) {
      categorized.uiLayout.push(file);
    } else if (file.includes('db') || file.includes('prisma') || file.includes('d1') || file.includes('sensor_check') || file.includes('test_audit')) {
      categorized.database.push(file);
    } else if (file.includes('worker') || file.includes('api') || file.includes('route') || file.includes('edge')) {
      categorized.apiWorker.push(file);
    } else if (file.includes('flow') || file.includes('integration') || file.includes('pipeline')) {
      categorized.integration.push(file);
    } else {
      categorized.unit.push(file);
    }

    // Kiểm tra dấu hiệu False Green / Trivial Test
    const assertCount = (content.match(/assert\.(ok|equal|strictEqual|deepEqual|match|throws|doesNotThrow)/g) || []).length;
    const expectCount = (content.match(/expect\(/g) || []).length;
    const totalAssertions = assertCount + expectCount;

    const testCount = (content.match(/it\(|test\(/g) || []).length;

    if (testCount > 0 && totalAssertions === 0) {
      categorized.falseGreens.push({ file, reason: 'Không có bất kỳ lệnh assert / expect nào.' });
    }
  }

  console.log('--- THỐNG KÊ PHÂN LOẠI TEST FILES ---');
  console.log(`- 1. Unit Tests: ${categorized.unit.length} files`);
  console.log(`- 2. Integration / Pipeline Tests: ${categorized.integration.length} files`);
  console.log(`- 3. API & Cloudflare Worker Edge Tests: ${categorized.apiWorker.length} files`);
  console.log(`- 4. Database & D1 SQLite Tests: ${categorized.database.length} files`);
  console.log(`- 5. UI Layout & Accessibility Tests: ${categorized.uiLayout.length} files`);
  console.log(`- Tổng cộng: ${files.length} test files\n`);

  console.log(`--- PHÁT HIỆN FALSE GREENS / TRIVIAL ASSERTIONS ---`);
  if (categorized.falseGreens.length > 0) {
    console.table(categorized.falseGreens);
  } else {
    console.log('✅ KHÔNG CÓ FILE TEST NÀO THIẾU ASSERTION: Toàn bộ 69 test files đều có các phép kiểm tra logic thực tế (assert.ok / assert.equal / expect).');
  }
}

runTestSuiteAudit().catch(console.error);
