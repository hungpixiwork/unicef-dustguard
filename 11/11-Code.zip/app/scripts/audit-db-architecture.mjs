import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('=== AUDIT INDEXES IN DEV.DB ===');
const indexes = db.prepare("SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index'").all();
console.log(`Found ${indexes.length} indexes:`);
indexes.forEach(idx => console.log(`- [${idx.tbl_name}] ${idx.name}`));

console.log('\n=== AUDIT ALERTS COLUMNS DETAIL ===');
const alertCols = db.prepare("PRAGMA table_info(alerts)").all();
console.log(alertCols.map(c => `${c.name} (${c.type})`));

console.log('\n=== AUDIT CASES COLUMNS DETAIL ===');
const caseCols = db.prepare("PRAGMA table_info(cases)").all();
console.log(caseCols.map(c => `${c.name} (${c.type})`));

console.log('\n=== AUDIT SENSORS & READINGS COLUMNS DETAIL ===');
const sensorCols = db.prepare("PRAGMA table_info(sensors)").all();
console.log('sensors:', sensorCols.map(c => `${c.name} (${c.type})`));
const readingCols = db.prepare("PRAGMA table_info(sensor_readings)").all();
console.log('readings:', readingCols.map(c => `${c.name} (${c.type})`));
