/**
 * DustGuard VN - Single Source of Truth (SSOT) for Test Groups & Classifications
 * Used by verify-changed, verify-domain, verify-quick, verify-full, and verify-ci.
 */

export const TEST_GROUPS = {
  // Level 3 Quick / Smoke High-Signal Tests (< 15s)
  critical: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/domain-observation-case-invariants.test.js',
    'tests/swagger-openapi.test.js',
    'tests/worker-full-edge-routes.test.js',
    'tests/staff-case-complete-rbac.test.js',
    'tests/community-action-flow.test.js',
    'tests/youth-credits.test.js'
  ],

  // Pure In-Memory Domain & Unit Tests (Safe to run in parallel)
  unit: [
    'tests/action-rules.test.js',
    'tests/alert-engine-telemetry.test.js',
    'tests/alerts-fraud.test.js',
    'tests/complaint-rules.test.js',
    'tests/csr-engine.test.js',
    'tests/docx-parser.test.js',
    'tests/domain-observation-case-invariants.test.js',
    'tests/domain-state-machine-integrity.test.js',
    'tests/hmac-seal-stamp.test.js',
    'tests/legal-shield-image-integrity.test.js',
    'tests/mode-switch-model.test.js',
    'tests/offline-drafts.test.js',
    'tests/operational-reality-necessity.test.js',
    'tests/priority-scoring-engine.test.js',
    'tests/response.test.js',
    'tests/telemetry-enhancer.test.js',
    'tests/youth-credits.test.js',
    'tests/clerk-hybrid-auth.test.js',
    'tests/device-auth-isolation.test.js',
    'tests/telemetry-anomaly-pipeline.test.js',
    'tests/cps-risk-engine-boundary.test.js',
    'tests/case-enforcement-dag-7steps.test.js',
    'tests/civic-handoff-integration.test.js',
    'tests/image-compressor-privacy.test.js',
    'tests/claim-integrity-policy.test.js'
  ],

  // UI, Component, Layout, Token & Accessibility Tests (Parallel safe)
  ui: [
    'tests/accessibility-public-layout.test.js',
    'tests/app-shell-navigation.test.js',
    'tests/citizen-report-ui-features.test.js',
    'tests/citizen-reports-error-state.test.js',
    'tests/citizen-youth-ux.test.js',
    'tests/community-action-flow.test.js',
    'tests/community-case-workspace.test.js',
    'tests/community-create-observation-ux.test.js',
    'tests/community-home-layout.test.js',
    'tests/community-modules-layout.test.js',
    'tests/community-navigation-layout.test.js',
    'tests/design-system-tokens.test.js',
    'tests/layout-typography-primitives.test.js',
    'tests/mobile-layout-audit.test.js',
    'tests/runtime-ux-qa-visual-regression.test.js',
    'tests/ui-primitives.test.js'
  ],

  // API Contract, Governance & OpenAPI (Parallel safe)
  api: [
    'tests/api-connectivity-audit.test.js',
    'tests/api_contract_rbac_security.test.js',
    'tests/auth-rbac-geofence-audit.test.js',
    'tests/contractor-api-frontend.test.js',
    'tests/contractor-project-telemetry-regression.test.js',
    'tests/full-system-reliability-e2e.test.js',
    'tests/endpoint-reachability.test.js',
    'tests/route-inventory-matrix.test.js',
    'tests/swagger-openapi.test.js'
  ],

  // Edge Worker Routes & Integration Tests (Hono mockEnv / in-memory)
  worker: [
    'tests/auth.test.js',
    'tests/backend-hardening-10-domains.test.js',
    'tests/case-service.test.js',
    'tests/contractor-quick-submit.test.js',
    'tests/csr-api.test.js',
    'tests/documents-legal-updates.test.js',
    'tests/executive-dashboard.test.js',
    'tests/executive-command-center.test.js',
    'tests/field-operations-inspection-qa.test.js',
    'tests/generate-report.test.js',
    'tests/legal-a4-esg-audit.test.js',
    'tests/offline-resilience-audit.test.js',
    'tests/priority-score-integration.test.js',
    'tests/site-controller.test.js',
    'tests/staff-case-management-qa.test.js',
    'tests/staff-operations-dashboard.test.js',
    'tests/worker-auth-security.test.js',
    'tests/worker-full-edge-routes.test.js',
    'tests/adversarial-security-qa.test.js'
  ],

  // Database Mutating & Server Listen Tests (Must be run sequentially)
  database: [
    'tests/iot-telemetry-r2-integrity.test.js',
    'tests/sensors-telemetry.test.js',
    'tests/d1-ssot-crud-persistence.test.js',
    'tests/d1-reset-safeguards.test.js',
    'tests/test_audit.js',
    'tests/test_audit_middleware.js',
    'tests/test_sensor_check.js'
  ],

  // Specific Domain Namespaces
  observations: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/domain-observation-case-invariants.test.js',
    'tests/community-action-flow.test.js',
    'tests/community-case-workspace.test.js',
    'tests/community-create-observation-ux.test.js',
    'tests/domain-state-machine-integrity.test.js',
    'tests/d1-ssot-crud-persistence.test.js'
  ],

  followups: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/domain-observation-case-invariants.test.js',
    'tests/community-action-flow.test.js',
    'tests/community-case-workspace.test.js'
  ],

  handoffs: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/community-case-workspace.test.js',
    'tests/civic-handoff-integration.test.js',
    'tests/official-document.test.js'
  ],

  youth: [
    'tests/youth-credits.test.js',
    'tests/backend-hardening-10-domains.test.js',
    'tests/citizen-youth-ux.test.js'
  ],

  campaigns: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/community-action-flow.test.js'
  ],

  impact: [
    'tests/backend-hardening-10-domains.test.js',
    'tests/community-action-flow.test.js'
  ],

  risk: [
    'tests/priority-scoring-engine.test.js',
    'tests/priority-score-integration.test.js',
    'tests/telemetry-enhancer.test.js',
    'tests/sensors-telemetry.test.js',
    'tests/backend-hardening-10-domains.test.js'
  ],

  csr: [
    'tests/csr-engine.test.js',
    'tests/csr-api.test.js',
    'tests/legal-a4-esg-audit.test.js'
  ],

  auth: [
    'tests/auth.test.js',
    'tests/worker-auth-security.test.js',
    'tests/auth-rbac-geofence-audit.test.js',
    'tests/clerk-hybrid-auth.test.js',
    'tests/device-auth-isolation.test.js'
  ]
};

// Full list of all test files (Exhaustive Release Gate)
export const ALL_TEST_FILES = [
  ...new Set([
    ...TEST_GROUPS.unit,
    ...TEST_GROUPS.ui,
    ...TEST_GROUPS.api,
    ...TEST_GROUPS.worker,
    ...TEST_GROUPS.database
  ])
];
