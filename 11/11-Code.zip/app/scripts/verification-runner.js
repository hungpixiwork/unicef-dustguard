/**
 * DustGuard VN - Core Unified Verification Runner Engine
 * High-velocity, fail-fast, concurrency-safe test orchestrator.
 */

import { spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { TEST_GROUPS } from './test-groups.js';

const CACHE_DIR = resolve(process.cwd(), '.agent', '.cache');
const STATE_HASH_FILE = resolve(CACHE_DIR, 'last-verify-hash.json');

/**
 * Executes a single command synchronously via spawn with streaming output.
 * @param {string} command
 * @param {string[]} args
 * @returns {Promise<{ exitCode: number, durationMs: number, stdout: string, stderr: string }>}
 */
export function runProcess(command, args = [], options = {}) {
  const start = performance.now();
  return new Promise((res) => {
    const child = spawn(command, args, {
      stdio: options.silent ? ['ignore', 'pipe', 'pipe'] : ['inherit', 'pipe', 'pipe'],
      shell: process.platform === 'win32',
      ...options
    });

    let stdout = '';
    let stderr = '';

    if (child.stdout) {
      child.stdout.on('data', (d) => {
        const str = d.toString();
        stdout += str;
        if (!options.silent) process.stdout.write(str);
      });
    }

    if (child.stderr) {
      child.stderr.on('data', (d) => {
        const str = d.toString();
        stderr += str;
        if (!options.silent) process.stderr.write(str);
      });
    }

    child.on('close', (code) => {
      const durationMs = Math.round(performance.now() - start);
      res({ exitCode: code ?? 0, durationMs, stdout, stderr });
    });

    child.on('error', (err) => {
      res({ exitCode: 1, durationMs: Math.round(performance.now() - start), stdout, stderr: err.message });
    });
  });
}

/**
 * Runs a list of test files with automatic isolation and fail-fast ordering.
 * @param {string[]} testFiles
 * @param {object} options
 */
export async function executeTestPipeline(testFiles = [], options = {}) {
  const totalStart = performance.now();
  const title = options.title || 'VERIFICATION PIPELINE';

  console.log('========================================================');
  console.log(`🛡️  DUSTGUARD VN — ${title.toUpperCase()}`);
  console.log('========================================================');

  if (testFiles.length === 0) {
    console.log('ℹ️  No test files to execute for this scope.');
    console.log('========================================================\n');
    return { success: true, count: 0, durationMs: 0 };
  }

  // Filter existing files
  const validFiles = testFiles.filter((f) => {
    const exists = existsSync(f);
    if (!exists) console.warn(`⚠️  Test file not found: ${f}`);
    return exists;
  });

  console.log(`Scoped tests: ${validFiles.length} file(s)`);
  if (options.reasons && options.reasons.length > 0) {
    console.log('Change impact reasons:');
    options.reasons.slice(0, 5).forEach((r) => console.log(`  - ${r}`));
    if (options.reasons.length > 5) {
      console.log(`  ... and ${options.reasons.length - 5} more`);
    }
  }
  console.log('');

  // 1. Separate DB mutating tests from in-memory tests
  const dbTestSet = new Set(TEST_GROUPS.database);
  const memoryTests = validFiles.filter((f) => !dbTestSet.has(f));
  const databaseTests = validFiles.filter((f) => dbTestSet.has(f));

  // Step A: Run Memory / Parallel-safe Tests
  if (memoryTests.length > 0) {
    console.log(`▶ Step 1/2: In-Memory & Domain Tests (${memoryTests.length} files)...`);
    const memResult = await runProcess('node', ['--test', ...memoryTests], {
      silent: false
    });

    if (memResult.exitCode !== 0) {
      console.error('\n❌ FAIL-FAST: In-memory tests failed. Aborting verification.');
      console.error(`Suggested fix command: node --test ${memoryTests[0]}`);
      return { success: false, exitCode: memResult.exitCode };
    }
    console.log(`✅ In-Memory suite passed (${(memResult.durationMs / 1000).toFixed(1)}s)\n`);
  }

  // Step B: Run Database Mutating Tests (Sequentially isolated)
  if (databaseTests.length > 0) {
    console.log(`▶ Step 2/2: Database & State Tests (${databaseTests.length} files, sequential)...`);
    const dbResult = await runProcess('node', ['--test', '--test-concurrency=1', ...databaseTests], {
      silent: false
    });

    if (dbResult.exitCode !== 0) {
      console.error('\n❌ FAIL-FAST: Database tests failed.');
      console.error(`Suggested fix command: node --test ${databaseTests[0]}`);
      return { success: false, exitCode: dbResult.exitCode };
    }
    console.log(`✅ Database suite passed (${(dbResult.durationMs / 1000).toFixed(1)}s)\n`);
  }

  const totalDuration = ((performance.now() - totalStart) / 1000).toFixed(1);
  console.log('========================================================');
  console.log(`🎉 ALL ${validFiles.length} TEST FILES PASSED (${totalDuration}s)`);
  console.log('========================================================\n');

  return { success: true, count: validFiles.length, durationMs: Math.round(performance.now() - totalStart) };
}
