#!/usr/bin/env node
/**
 * DustGuard VN — Sensor Simulation CLI (HMAC-SHA256 Telemetry Generator)
 * 
 * Provides automated scenario injection for staff dashboard testing:
 * - normal: Compliant PM levels (PM2.5 < 30, PM10 < 50)
 * - spike: High dust emission triggering P1 alerts (PM2.5 > 150, PM10 > 250)
 * - flatline: Sensor frozen sending repetitive exact values
 * - tamper: Invalid HMAC signature to verify anti-tamper security
 * 
 * Usage:
 *   node scripts/sensor-simulate.js --scenario spike --count 5
 *   npm run sensor:simulate -- --scenario normal
 */

import { runMockScenario, SCENARIO_PROFILES, createSignedReading, transmitReading } from './mock-iot-node.js';

const args = process.argv.slice(2);
let scenario = 'normal';
let count = 5;
let interval = 1000;
let url = process.env.DUSTGUARD_API_URL || 'http://127.0.0.1:3001/api/sensors/reading';
let sensorCode = process.env.DEVICE_SENSOR_CODE || 'SEN-TX-01';

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === '--scenario' || arg === '-s') {
    scenario = args[++i] || 'normal';
  } else if (arg === '--count' || arg === '-c') {
    count = parseInt(args[++i], 10) || 5;
  } else if (arg === '--interval' || arg === '-i') {
    interval = parseInt(args[++i], 10) || 1000;
  } else if (arg === '--url' || arg === '-u') {
    url = args[++i] || url;
  } else if (arg === '--sensor') {
    sensorCode = args[++i] || sensorCode;
  } else if (arg === '--help' || arg === '-h') {
    console.log(`
DustGuard VN — Sensor Simulation CLI
Scenarios available:
  - normal   : Nồng độ bụi đạt chuẩn QCVN 05:2023
  - spike    : Vượt ngưỡng bụi khẩn cấp (PM2.5 > 150 µg/m³)
  - critical : Mức nguy hại cao, kích hoạt SLA và P1 Queue
  - flatline : Cảm biến đơ / lặp lại mẫu đo
  - tampered : Sai chữ ký HMAC SHA-256 (kiểm toán bảo mật)
  - recovery : Giảm dần nồng độ bụi sau khi dập bụi

Options:
  --scenario, -s  [normal|spike|critical|flatline|tampered|recovery] (mặc định: normal)
  --count, -c     Số lượng mẫu đo gửi đi (mặc định: 5)
  --interval, -i  Khoảng cách giữa các mẫu đo tính bằng ms (mặc định: 1000)
  --url, -u       Endpoint API Ingestion
  --sensor        Mã cảm biến (vd: SEN-TX-01)
    `);
    process.exit(0);
  }
}

// Map spike to high/critical
const scenarioMap = {
  spike: 'critical',
  tamper: 'tampered',
};

const resolvedScenario = scenarioMap[scenario] || scenario;

console.log(`🚀 [SIMULATOR] Bắt đầu mô phỏng cảm biến IoT [${resolvedScenario.toUpperCase()}]`);
console.log(`   Sensor Code: ${sensorCode}`);
console.log(`   Target: ${url}`);
console.log(`   Gói tin: ${count} | Tần suất: ${interval}ms\n`);

runMockScenario(resolvedScenario, {
  count,
  interval,
  url,
  sensorCode
}).then(res => {
  console.log(`✅ Mô phỏng hoàn tất.`);
  process.exit(0);
}).catch(err => {
  console.error(`❌ Lỗi mô phỏng:`, err.message);
  process.exit(1);
});
