import Database from 'better-sqlite3';
import fs from 'fs';

const logDbPath = 'C:\\Users\\PhạmPhúNguyễnHưng\\.codex\\logs_2.sqlite';

if (fs.existsSync(logDbPath)) {
  const db = new Database(logDbPath, { readonly: true });
  const rows = db.prepare("SELECT * FROM logs ORDER BY id DESC LIMIT 50").all();
  console.log(`Dumping ${rows.length} rows from logs...`);
  rows.forEach((row, i) => {
    console.log(`\n--- Row ${i + 1} (ID: ${row.id}) ---`);
    Object.keys(row).forEach(key => {
      const val = String(row[key]);
      if (val.length > 500) {
        console.log(`  ${key}: [Truncated: ${val.length} chars] ${val.substring(0, 300)}...`);
      } else {
        console.log(`  ${key}: ${val}`);
      }
    });
  });
  db.close();
} else {
  console.log('Log DB not found');
}
