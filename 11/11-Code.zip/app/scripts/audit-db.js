import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, '../prisma/dev.db');

console.log('='.repeat(75));
console.log('🔍 DUSTGUARD VN — FORENSIC DATABASE AUDIT (Cloudflare D1 & SQLite SSOT)');
console.log('='.repeat(75));
console.log(`📁 Database Path: ${dbPath}`);

if (!fs.existsSync(dbPath)) {
  console.error(`❌ Database file not found at ${dbPath}`);
  process.exit(1);
}

const db = new Database(dbPath);
db.pragma('foreign_keys = ON');

let errors = [];
let warnings = [];
let passCount = 0;

function pass(msg) {
  passCount++;
  console.log(`  ✅ ${msg}`);
}

function warn(msg) {
  warnings.push(msg);
  console.log(`  ⚠️  [WARN] ${msg}`);
}

function error(msg) {
  errors.push(msg);
  console.log(`  ❌ [ERROR] ${msg}`);
}

// 1. LOW LEVEL INTEGRITY & PRAGMAS
console.log('\n--- 1. SQLite Engine & Storage Engine Pragmas ---');
try {
  const integrity = db.pragma('integrity_check');
  if (integrity[0]?.integrity_check === 'ok') {
    pass('PRAGMA integrity_check: Storage B-Tree & page allocations are 100% healthy');
  } else {
    error(`PRAGMA integrity_check failed: ${JSON.stringify(integrity)}`);
  }

  const quickCheck = db.pragma('quick_check');
  if (quickCheck[0]?.quick_check === 'ok') {
    pass('PRAGMA quick_check: Fast integrity verification passed');
  } else {
    error(`PRAGMA quick_check failed: ${JSON.stringify(quickCheck)}`);
  }

  const fkCheck = db.pragma('foreign_key_check');
  if (fkCheck.length === 0) {
    pass('PRAGMA foreign_key_check: 0 foreign key constraint violations across entire DB');
  } else {
    error(`PRAGMA foreign_key_check found ${fkCheck.length} violations: ${JSON.stringify(fkCheck)}`);
  }
} catch (err) {
  error(`Pragma check exception: ${err.message}`);
}

// 2. DOMAIN TABLE INVENTORY & CARDINALITY
console.log('\n--- 2. Domain Entities & SSOT Cardinality ---');
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_%' ORDER BY name").all();

const domainSummary = [];
for (const t of tables) {
  const countRow = db.prepare(`SELECT count(*) as count FROM "${t.name}"`).get();
  const columns = db.prepare(`PRAGMA table_info("${t.name}")`).all();
  const pks = columns.filter(c => c.pk > 0).map(c => c.name);
  const indexes = db.prepare(`PRAGMA index_list("${t.name}")`).all();
  const fks = db.prepare(`PRAGMA foreign_key_list("${t.name}")`).all();

  domainSummary.push({
    Table: t.name,
    Rows: countRow.count,
    Columns: columns.length,
    PK: pks.join(', '),
    Indexes: indexes.length,
    FKs: fks.length
  });
}

console.table(domainSummary);

// 3. CORE SSOT BACKBONE RELATIONSHIPS
console.log('\n--- 3. SSOT Backbone Referential Integrity Audit ---');

function verifyFkRelation(childTable, childCol, parentTable, parentCol) {
  try {
    const q = `
      SELECT count(*) as orphanCount
      FROM "${childTable}" c
      LEFT JOIN "${parentTable}" p ON c."${childCol}" = p."${parentCol}"
      WHERE c."${childCol}" IS NOT NULL AND p."${parentCol}" IS NULL
    `;
    const res = db.prepare(q).get();
    if (res.orphanCount === 0) {
      pass(`Referential link: ${childTable}.${childCol} ➔ ${parentTable}.${parentCol} (0 orphans)`);
    } else {
      error(`Found ${res.orphanCount} orphan rows in ${childTable}.${childCol} pointing to non-existent ${parentTable}.${parentCol}`);
    }
  } catch (err) {
    warn(`Relation check error (${childTable} -> ${parentTable}): ${err.message}`);
  }
}

// Backbone: SITE -> SENSORS -> READINGS / ALERTS
verifyFkRelation('sensors', 'siteId', 'sites', 'id');
verifyFkRelation('sensor_readings', 'sensorId', 'sensors', 'id');
verifyFkRelation('alerts', 'siteId', 'sites', 'id');
verifyFkRelation('alerts', 'sensorId', 'sensors', 'id');

// Backbone: SITE -> CASES -> ACTIONS / INSPECTIONS / COMPLAINTS / DOCUMENTS
verifyFkRelation('cases', 'siteId', 'sites', 'id');
verifyFkRelation('complaints', 'siteId', 'sites', 'id');
verifyFkRelation('inspections', 'siteId', 'sites', 'id');
verifyFkRelation('actions', 'siteId', 'sites', 'id');
verifyFkRelation('actions', 'caseId', 'cases', 'id');
verifyFkRelation('draft_documents', 'siteId', 'sites', 'id');
verifyFkRelation('draft_documents', 'caseId', 'cases', 'id');
verifyFkRelation('document_revisions', 'documentId', 'draft_documents', 'id');

// Backbone: COMMUNITY & CITIZEN
verifyFkRelation('observations', 'site_id', 'sites', 'id');
verifyFkRelation('observation_evidence', 'observation_id', 'observations', 'id');
verifyFkRelation('follow_ups', 'observation_id', 'observations', 'id');
verifyFkRelation('follow_ups', 'case_id', 'cases', 'id');
verifyFkRelation('handoffs', 'observation_id', 'observations', 'id');
verifyFkRelation('handoffs', 'case_id', 'cases', 'id');

// 4. BUSINESS LOGIC & ENUM CONFORMANCE
console.log('\n--- 4. Business Logic & State Machine Values Audit ---');

function verifyEnum(table, col, allowed) {
  try {
    const rows = db.prepare(`SELECT DISTINCT "${col}" as val FROM "${table}" WHERE "${col}" IS NOT NULL`).all();
    const invalid = rows.filter(r => !allowed.includes(r.val));
    if (invalid.length === 0) {
      pass(`${table}.${col} values conform to specification: [${rows.map(r => r.val).join(', ')}]`);
    } else {
      error(`Invalid enum values in ${table}.${col}: ${JSON.stringify(invalid.map(r => r.val))} (Allowed: ${allowed.join(', ')})`);
    }
  } catch (err) {
    warn(`Enum check error on ${table}.${col}: ${err.message}`);
  }
}

verifyEnum('users', 'role', ['citizen', 'staff', 'executive', 'contractor', 'admin', 'demo_admin', 'community', 'youth_member', 'inspector', 'super_admin']);
verifyEnum('users', 'status', ['ACTIVE', 'INACTIVE', 'SUSPENDED', 'DISABLED']);
verifyEnum('sites', 'status', ['ACTIVE', 'INACTIVE', 'WARNING', 'CLOSED', 'UNDER_CONSTRUCTION', 'SUSPENDED']);
verifyEnum('sites', 'riskLevel', ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL', 'SAFE', 'WARNING']);
verifyEnum('cases', 'status', ['SCREENING', 'PREPARING', 'DECISION_ISSUED', 'ON_SITE', 'REPORTING', 'APPRAISING', 'COMPLETED', 'DISMISSED', 'IN_PROGRESS', 'OPEN', 'VERIFIED', 'VIOLATED', 'EXPLAINED', 'SANCTION_ISSUED', 'CLOSED', 'PENDING']);
verifyEnum('complaints', 'status', ['PENDING', 'LINKED', 'PROCESSING', 'INVESTIGATING', 'VERIFIED', 'REJECTED', 'CONVERTED_CASE', 'RESOLVED', 'SUBMITTED']);
verifyEnum('actions', 'status', ['PENDING', 'IN_PROGRESS', 'RESOLVED', 'VERIFIED', 'REJECTED', 'PENDING_VERIFICATION']);
verifyEnum('alerts', 'status', ['PENDING', 'ACKNOWLEDGED', 'RESOLVED', 'EXPIRED', 'IN_PROGRESS', 'ACTIVE', 'TRIGGERED']);
verifyEnum('observations', 'category', ['CONSTRUCTION_DUST', 'WASTE', 'WASTEWATER', 'OPEN_BURNING', 'AGRICULTURAL_CHEMICAL', 'AIR_QUALITY', 'OTHER', 'HEAVY_SMOKE', 'UNCOVERED_TRANSPORT']);
verifyEnum('observations', 'status', ['RECORDED', 'VERIFYING', 'FOLLOWING_UP', 'CONVERTED_CASE', 'HANDED_OFF', 'RESOLVED', 'CLOSED']);

// 5. INDEX COVERAGE & LATENCY AUDIT
console.log('\n--- 5. Index Coverage for High-Frequency Query Paths ---');

const indexedQueries = [
  { table: 'sites', col: 'ward' },
  { table: 'sites', col: 'riskLevel' },
  { table: 'sites', col: 'status' },
  { table: 'cases', col: 'siteId' },
  { table: 'cases', col: 'status' },
  { table: 'complaints', col: 'siteId' },
  { table: 'complaints', col: 'status' },
  { table: 'complaints', col: 'code' },
  { table: 'inspections', col: 'siteId' },
  { table: 'actions', col: 'siteId' },
  { table: 'actions', col: 'caseId' },
  { table: 'actions', col: 'status' },
  { table: 'sensors', col: 'siteId' },
  { table: 'sensors', col: 'code' },
  { table: 'sensor_readings', col: 'sensorId' },
  { table: 'sensor_readings', col: 'timestamp' },
  { table: 'alerts', col: 'siteId' },
  { table: 'alerts', col: 'status' },
  { table: 'draft_documents', col: 'siteId' },
  { table: 'draft_documents', col: 'caseId' },
  { table: 'observations', col: 'code' },
  { table: 'observations', col: 'status' },
  { table: 'observations', col: 'category' }
];

for (const q of indexedQueries) {
  const indexes = db.prepare(`PRAGMA index_list("${q.table}")`).all();
  let found = false;
  for (const idx of indexes) {
    const cols = db.prepare(`PRAGMA index_info("${idx.name}")`).all();
    if (cols.some(c => c.name === q.col)) {
      found = true;
      break;
    }
  }
  if (found) {
    pass(`Index covers high-frequency query path: ${q.table}.${q.col}`);
  } else {
    warn(`Unindexed query path: ${q.table}.${q.col}`);
  }
}

// 6. SENSORS & TELEMETRY SANITY
console.log('\n--- 6. Sensor Telemetry & Numeric Bounds ---');
const telemetrySanity = db.prepare(`
  SELECT 
    min(pm25) as minPm25, 
    max(pm25) as maxPm25, 
    min(pm10) as minPm10, 
    max(pm10) as maxPm10,
    count(*) as totalCount
  FROM sensor_readings
`).get();

if (telemetrySanity.minPm25 >= 0 && telemetrySanity.maxPm25 <= 1000 && telemetrySanity.minPm10 >= 0 && telemetrySanity.maxPm10 <= 2000) {
  pass(`Sensor readings sanity verified: PM2.5 in [${telemetrySanity.minPm25}, ${telemetrySanity.maxPm25}] ug/m3, PM10 in [${telemetrySanity.minPm10}, ${telemetrySanity.maxPm10}] ug/m3 (${telemetrySanity.totalCount} readings)`);
} else {
  error(`Sensor readings out of physical bounds: ${JSON.stringify(telemetrySanity)}`);
}

// 7. FINAL VERDICT
console.log('\n' + '='.repeat(75));
console.log('📊 DATABASE AUDIT VERDICT');
console.log('='.repeat(75));
console.log(`  Passed Checks:    ${passCount}`);
console.log(`  Warnings:         ${warnings.length}`);
console.log(`  Critical Errors:  ${errors.length}`);

if (errors.length === 0) {
  console.log('\n🎉 CLOUDFLARE D1 / SQLITE DATABASE SSOT IS 100% HEALTHY, CONSISTENT & PRODUCTION READY!');
} else {
  console.log(`\n❌ Found ${errors.length} database errors.`);
  process.exit(1);
}

db.close();
