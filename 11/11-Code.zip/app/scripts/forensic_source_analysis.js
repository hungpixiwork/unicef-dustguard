import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const ROOT = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app');
const SRC_DIR = path.join(ROOT, 'src');
const SERVER_DIR = path.join(ROOT, 'server');

function getSourceFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const item of list) {
    if (['node_modules', '.git', 'dist'].includes(item)) continue;
    const full = path.join(dir, item);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) {
      results = results.concat(getSourceFiles(full));
    } else if (/\.(jsx?|tsx?|css|sql)$/.test(item)) {
      results.push(full);
    }
  }
  return results;
}

const srcFiles = getSourceFiles(SRC_DIR);
const serverFiles = getSourceFiles(SERVER_DIR);
const allSource = [...srcFiles, ...serverFiles];

let totalSrcLOC = 0;
const srcBreakdown = {};

for (const file of srcFiles) {
  const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  const top = rel.split('/')[0];
  const lines = fs.readFileSync(file, 'utf8').split('\n').length;
  totalSrcLOC += lines;
  srcBreakdown[top] = (srcBreakdown[top] || { count: 0, lines: 0 });
  srcBreakdown[top].count++;
  srcBreakdown[top].lines += lines;
}

let totalServerLOC = 0;
const serverBreakdown = {};

for (const file of serverFiles) {
  const rel = path.relative(SERVER_DIR, file).replace(/\\/g, '/');
  const top = rel.split('/')[0];
  const lines = fs.readFileSync(file, 'utf8').split('\n').length;
  totalServerLOC += lines;
  serverBreakdown[top] = (serverBreakdown[top] || { count: 0, lines: 0 });
  serverBreakdown[top].count++;
  serverBreakdown[top].lines += lines;
}

console.log('=== SOURCE CODE BREAKDOWN (FRONTEND & BACKEND) ===');
console.log(`Frontend src/ total: ${srcFiles.length} files | ${totalSrcLOC} LOC`);
console.log(`Backend server/ total: ${serverFiles.length} files | ${totalServerLOC} LOC`);
console.log(`Total Active Code (src + server): ${allSource.length} files | ${totalSrcLOC + totalServerLOC} LOC\n`);

console.log('--- FRONTEND src/ SUBDIRECTORIES ---');
Object.entries(srcBreakdown)
  .sort((a, b) => b[1].lines - a[1].lines)
  .forEach(([dir, d]) => {
    const pct = ((d.lines / totalSrcLOC) * 100).toFixed(2);
    console.log(`src/${dir.padEnd(25)} : ${String(d.count).padStart(3)} files | ${String(d.lines).padStart(6)} LOC (${pct}%)`);
  });

console.log('\n--- BACKEND server/ SUBDIRECTORIES ---');
Object.entries(serverBreakdown)
  .sort((a, b) => b[1].lines - a[1].lines)
  .forEach(([dir, d]) => {
    const pct = ((d.lines / totalServerLOC) * 100).toFixed(2);
    console.log(`server/${dir.padEnd(22)} : ${String(d.count).padStart(3)} files | ${String(d.lines).padStart(6)} LOC (${pct}%)`);
  });
