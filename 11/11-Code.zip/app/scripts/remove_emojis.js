import fs from 'fs';
import path from 'path';

const SRC_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/src');

function getFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const item of list) {
    if (['node_modules', '.git', 'dist'].includes(item)) continue;
    const full = path.join(dir, item);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) results = results.concat(getFiles(full));
    else if (/\.(jsx?|tsx?)$/.test(item)) results.push(full);
  }
  return results;
}

// Regex matching emoji characters
const emojiRegex = /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F1E6}-\u{1F1FF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{1FA70}-\u{1FAFF}]/gu;

const files = getFiles(SRC_DIR);
let totalCleaned = 0;

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  if (emojiRegex.test(content)) {
    // Replace emojis in JSX/strings with empty or clean text
    const cleaned = content.replace(emojiRegex, '');
    fs.writeFileSync(file, cleaned, 'utf8');
    const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
    console.log(`Cleaned emojis in: ${rel}`);
    totalCleaned++;
  }
}

console.log(`\nSuccessfully cleaned emojis across ${totalCleaned} files.`);
