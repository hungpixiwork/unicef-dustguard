import fs from 'fs';
import path from 'path';

const SRC_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/src');
const SERVER_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app/server');

function getFiles(dir, ext = ['.js', '.jsx', '.ts', '.tsx']) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git' && file !== 'dist') {
        results = results.concat(getFiles(fullPath, ext));
      }
    } else {
      if (ext.some(e => file.endsWith(e))) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

const frontendFiles = getFiles(SRC_DIR);
const serverFiles = getFiles(SERVER_DIR);

console.log(`Found ${frontendFiles.length} frontend files and ${serverFiles.length} server files.`);

const patterns = [
  { name: 'Math.random', regex: /Math\.random\(\)/g },
  { name: 'Mock/Fake Data Variable', regex: /(const|let|var)\s+(mock[A-Z0-9_]|fake[A-Z0-9_]|dummy[A-Z0-9_])/gi },
  { name: 'Mock API Response / Fallback', regex: /(mockResponse|useMock|isMock|mockData|MOCK_DATA)/gi },
  { name: 'setTimeout delay mock', regex: /setTimeout\s*\(\s*(\(\)\s*=>|\bfunction\b)[^,]+,\s*(500|1000|1500|2000|3000)\s*\)/g },
  { name: 'Silent Catch Block', regex: /catch\s*\([^)]*\)\s*\{\s*(\/\/[^\n]*\n\s*)*\}/g },
  { name: 'Glassmorphism Style', regex: /(backdrop-filter|backdrop-blur|rgba\(255,\s*255,\s*255,\s*0\.[1-9]\))/gi }
];

console.log('\n--- SCANNING FRONTEND (src/) ---');
for (const file of frontendFiles) {
  const relPath = path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app', file);
  const content = fs.readFileSync(file, 'utf8');
  
  for (const p of patterns) {
    let match;
    while ((match = p.regex.exec(content)) !== null) {
      const line = content.substring(0, match.index).split('\n').length;
      console.log(`[${p.name}] ${relPath}:${line} -> "${match[0]}"`);
    }
  }
}

console.log('\n--- SCANNING SERVER (server/) ---');
for (const file of serverFiles) {
  const relPath = path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app', file);
  const content = fs.readFileSync(file, 'utf8');
  
  for (const p of patterns) {
    let match;
    while ((match = p.regex.exec(content)) !== null) {
      const line = content.substring(0, match.index).split('\n').length;
      console.log(`[${p.name}] ${relPath}:${line} -> "${match[0]}"`);
    }
  }
}
