import fs from 'fs';
import path from 'path';

function getFiles(dir, ext = ['.js', '.jsx', '.ts', '.tsx', '.css']) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git' && file !== 'dist') {
        results = results.concat(getFiles(fullPath, ext));
      }
    } else {
      if (ext.some(e => file.endsWith(e))) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

const files = getFiles('D:/07-Competitions-Hackathons/unicef-dustguard/app/src');
console.log(`Scanning ${files.length} files for glassmorphism / blur...`);

files.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const rel = path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app/src', file);
  content.split('\n').forEach((line, idx) => {
    if (/backdrop-blur|backdrop-filter|shadow-glass/i.test(line)) {
      console.log(`${rel}:${idx + 1} -> ${line.trim()}`);
    }
  });
});
