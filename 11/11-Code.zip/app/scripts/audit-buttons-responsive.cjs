#!/usr/bin/env node

/**
 * ==============================================================================
 * DUSTGUARD VN — BUTTON RESPONSIVE AUDITOR (SSOT CIVIC TECH ACCESSIBILITY TOOL)
 * ==============================================================================
 * Tự động kiểm tra responsive của tất cả các nút (button, links, CTAs, filter chips,
 * tabs, action cards) trên toàn bộ các route & 7 viewports chuẩn từ 360px đến 1920px.
 * 
 * Phát hiện:
 *  - Nút bị gãy chữ / xuống dòng ngoài ý muốn (Multi-line text wrap)
 *  - Rớt chữ đơn lẻ (Orphan word drop: ví dụ "Công" [dòng 1] -> "nghiệp" [dòng 2])
 *  - Tràn nội dung ngang (Horizontal overflow: scrollWidth > clientWidth)
 *  - Nút bị bóp méo, co cụm hoặc touch target < 44px trên thiết bị di động
 * 
 * Hỗ trợ tham số dòng lệnh CLI:
 *  - npm run audit:buttons
 *  - npm run audit:buttons -- --viewport=360x800
 *  - npm run audit:buttons -- --route=/citizen/report/new
 *  - npm run audit:buttons -- --errors-only
 * ==============================================================================
 */

const { chromium } = require('playwright');
const http = require('http');
const path = require('path');
const fs = require('fs');

// Ingest express app nếu cần server fallback
let expressApp;
try {
  expressApp = require('../server/index.js');
} catch (e) {
  expressApp = null;
}

// 7 Viewports chuẩn Responsive SSOT (Bắt buộc theo AGENTS.md & CIVIC UI RULES)
const ALL_VIEWPORTS = [
  { name: 'Mobile_Mini_360x800', width: 360, height: 800, isMobile: true, deviceScaleFactor: 2, label: '360x800 (Android phổ thông)' },
  { name: 'iPhone_14_390x844', width: 390, height: 844, isMobile: true, deviceScaleFactor: 3, label: '390x844 (iPhone 14/15)' },
  { name: 'iPhone_Max_430x932', width: 430, height: 932, isMobile: true, deviceScaleFactor: 3, label: '430x932 (iPhone Pro Max)' },
  { name: 'iPad_Portrait_768x1024', width: 768, height: 1024, isMobile: true, deviceScaleFactor: 2, label: '768x1024 (Tablet Portrait)' },
  { name: 'Laptop_14in_1366x768', width: 1366, height: 768, isMobile: false, label: '1366x768 (14-inch Laptop SSOT)' },
  { name: 'Desktop_FHD_1440x900', width: 1440, height: 900, isMobile: false, label: '1440x900 (Desktop Workstation)' },
  { name: 'Desktop_1080p_1920x1080', width: 1920, height: 1080, isMobile: false, label: '1920x1080 (FHD Monitor)' }
];

// Danh sách các Route trọng tâm của toàn bộ 5 vai trò nghiệp vụ
const ALL_ROUTES = [
  // Public & Auth
  { path: '/', role: 'public', name: 'Landing Page' },
  { path: '/demo', role: 'public', name: 'Demo Hub' },
  { path: '/login', role: 'public', name: 'Đăng nhập' },
  { path: '/youth', role: 'public', name: 'Tín chỉ Thanh niên' },

  // Citizen Portal
  { path: '/citizen', role: 'citizen', name: 'Citizen Trang chủ' },
  { path: '/citizen/report/new', role: 'citizen', name: 'Citizen Tạo phản ánh' },
  { path: '/citizen/reports', role: 'citizen', name: 'Citizen Theo dõi hồ sơ' },
  { path: '/citizen/map', role: 'citizen', name: 'Citizen Bản đồ GIS' },
  { path: '/citizen/nearby', role: 'citizen', name: 'Citizen Quét lân cận' },
  { path: '/citizen/profile', role: 'citizen', name: 'Citizen Hồ sơ cá nhân' },

  // Community Action & Youth
  { path: '/community', role: 'community', name: 'Community Trang chủ' },
  { path: '/community/discover', role: 'community', name: 'Community Khám phá CLB' },
  { path: '/community/observe', role: 'community', name: 'Community Tạo ghi nhận' },
  { path: '/community/cases', role: 'community', name: 'Community Danh sách vụ việc' },
  { path: '/community/actions', role: 'community', name: 'Community Nhiệm vụ thanh niên' },
  { path: '/community/impact', role: 'community', name: 'Community Báo cáo tác động' },

  // Contractor Workspace
  { path: '/contractor', role: 'contractor', name: 'Contractor Dashboard' },
  { path: '/contractor/actions', role: 'contractor', name: 'Contractor Danh sách khắc phục' },
  { path: '/contractor/projects', role: 'contractor', name: 'Contractor Dự án công trình' },
  { path: '/contractor/evidence', role: 'contractor', name: 'Contractor Bằng chứng & Hoàn tất' },

  // Staff Workspace
  { path: '/staff/dashboard', role: 'staff', name: 'Staff Dashboard' },
  { path: '/staff/operations', role: 'staff', name: 'Staff Trung tâm Vận hành' },
  { path: '/staff/cases', role: 'staff', name: 'Staff Quản lý Vụ việc 7 bước' },
  { path: '/staff/tasks', role: 'staff', name: 'Staff Quản lý Nhiệm vụ hiện trường' },
  { path: '/staff/sites', role: 'staff', name: 'Staff Danh sách Công trình' },
  { path: '/staff/documents', role: 'staff', name: 'Staff Văn bản & Báo cáo số' },
  { path: '/staff/users', role: 'staff', name: 'Staff Quản trị Người dùng' },

  // Executive Workspace
  { path: '/executive/dashboard', role: 'executive', name: 'Executive Dashboard Lãnh đạo' },
  { path: '/executive/heatmap', role: 'executive', name: 'Executive Bản đồ Nhiệt & Rủi ro' },
  { path: '/executive/approvals', role: 'executive', name: 'Executive Phê duyệt & Ký số' }
];

// ANSI Colors
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgRed: '\x1b[41m',
  bgYellow: '\x1b[43m',
  bgGreen: '\x1b[42m'
};

// Đọc arguments từ CLI
const args = process.argv.slice(2);
const cliViewportArg = args.find(a => a.startsWith('--viewport='))?.split('=')[1];
const cliRouteArg = args.find(a => a.startsWith('--route='))?.split('=')[1];
const isErrorsOnly = args.includes('--errors-only');

const selectedViewports = cliViewportArg 
  ? ALL_VIEWPORTS.filter(v => v.name.toLowerCase().includes(cliViewportArg.toLowerCase()) || `${v.width}x${v.height}`.includes(cliViewportArg))
  : ALL_VIEWPORTS;

const selectedRoutes = cliRouteArg
  ? ALL_ROUTES.filter(r => r.path === cliRouteArg || r.path.includes(cliRouteArg))
  : ALL_ROUTES;

async function isServerReady(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => {
      resolve(res.statusCode === 200 || res.statusCode === 304 || res.statusCode === 404);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(800, () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function inspectPageButtons(page) {
  return await page.evaluate(() => {
    const findings = [];
    const processedElements = new Set();

    const buttonSelectors = [
      'button',
      'a[role="button"]',
      'a.btn',
      'a.btn-primary',
      'a.btn-secondary',
      'a.btn-teal',
      'a.btn-civic',
      '[role="button"]',
      'input[type="button"]',
      'input[type="submit"]',
      '.btn',
      '.tab-btn',
      '.action-btn',
      '.dg-btn',
      '.pill-btn',
      '.filter-chip',
      'nav button',
      'header button',
      'form button'
    ];

    const elements = Array.from(document.querySelectorAll(buttonSelectors.join(',')));

    function getSelector(el) {
      if (el.id) return `#${el.id}`;
      const tag = el.tagName.toLowerCase();
      const classes = Array.from(el.classList || [])
        .filter(c => !['hover:', 'focus:', 'active:'].some(prefix => c.includes(prefix)))
        .slice(0, 3)
        .join('.');
      
      const parent = el.parentElement;
      const parentTag = parent ? parent.tagName.toLowerCase() : '';
      const parentClass = parent && parent.className && typeof parent.className === 'string' 
        ? '.' + parent.className.trim().split(/\s+/)[0] 
        : '';
        
      return `${parentTag}${parentClass} > ${tag}${classes ? '.' + classes : ''}`;
    }

    function extractLinesOfElement(el) {
      const range = document.createRange();
      const textNodes = [];
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while ((node = walker.nextNode())) {
        if (node.nodeValue && node.nodeValue.trim().length > 0) {
          textNodes.push(node);
        }
      }

      if (textNodes.length === 0) return [];

      const lineMap = new Map();
      const tolerance = 4;

      textNodes.forEach(tNode => {
        const words = tNode.nodeValue.split(/\s+/).filter(Boolean);
        let offset = 0;
        words.forEach(word => {
          const wordIndex = tNode.nodeValue.indexOf(word, offset);
          if (wordIndex !== -1) {
            offset = wordIndex + word.length;
            range.setStart(tNode, wordIndex);
            range.setEnd(tNode, wordIndex + word.length);
            const rects = range.getClientRects();
            if (rects.length > 0) {
              const rect = rects[0];
              let matchedTop = null;
              for (const top of lineMap.keys()) {
                if (Math.abs(top - rect.top) <= tolerance) {
                  matchedTop = top;
                  break;
                }
              }
              if (matchedTop === null) {
                matchedTop = rect.top;
                lineMap.set(matchedTop, []);
              }
              lineMap.get(matchedTop).push({ word, rect });
            }
          }
        });
      });

      const sortedTops = Array.from(lineMap.keys()).sort((a, b) => a - b);
      return sortedTops.map(top => {
        const items = lineMap.get(top);
        return items.map(i => i.word).join(' ');
      });
    }

    elements.forEach(el => {
      if (processedElements.has(el)) return;
      processedElements.add(el);

      const style = window.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return;
      
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      const rawText = (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ');
      if (!rawText && !el.querySelector('svg, img, i')) return;

      const lines = extractLinesOfElement(el);
      const isMultiLine = lines.length > 1;

      const fontSize = parseFloat(style.fontSize) || 14;
      let lineHeight = parseFloat(style.lineHeight);
      if (isNaN(lineHeight)) lineHeight = fontSize * 1.35;

      const innerHeight = rect.height - parseFloat(style.paddingTop || 0) - parseFloat(style.paddingBottom || 0);
      const heightRatio = lineHeight > 0 ? innerHeight / lineHeight : 1;

      // Đo tràn ngang
      const isOverflowingX = el.scrollWidth > el.clientWidth + 2;

      // Đo touch target trên mobile
      const isSmallTouchTarget = rect.width < 40 || rect.height < 40;

      // Phân loại button type:
      // 1. Single Action Button: CTA, Submit, Filter, Tab
      // 2. Selection Card: Có title + subtext
      const wordCount = rawText.split(/\s+/).filter(Boolean).length;
      const isShortAction = wordCount >= 1 && wordCount <= 7;
      
      let isUnwantedLineWrap = false;
      let wrapReason = '';
      let suggestedFix = '';

      if (isMultiLine && isShortAction) {
        isUnwantedLineWrap = true;
        const lastLine = lines[lines.length - 1];
        const lastLineWords = lastLine.split(/\s+/).filter(Boolean);
        if (lastLineWords.length === 1) {
          wrapReason = `Rớt chữ đơn lẻ ("${lastLine}") xuống dòng mới tạo khoảng trống xấu`;
          suggestedFix = `Thêm 'whitespace-nowrap shrink-0' hoặc tăng chiều rộng container / giảm padding nút`;
        } else {
          wrapReason = `Nút ngắn (${wordCount} từ) bị ép hẹp bẻ thành ${lines.length} dòng`;
          suggestedFix = `Thêm class 'whitespace-nowrap', bỏ fixed width 'w-[...]' hẹp hoặc đặt 'w-full sm:w-auto'`;
        }
      } else if (heightRatio > 1.8 && style.whiteSpace !== 'nowrap' && isShortAction) {
        isUnwantedLineWrap = true;
        wrapReason = `Chiều cao thực tế gấp ${heightRatio.toFixed(1)}x line-height do text bị gãy dòng`;
        suggestedFix = `Thêm 'white-space: nowrap' hoặc 'shrink-0' vào CSS của nút`;
      }

      if (isOverflowingX) {
        wrapReason = wrapReason ? wrapReason + ' + Tràn nội dung ngang (scrollWidth > clientWidth)' : 'Nút bị tràn chiều ngang khỏi khung chứa';
        suggestedFix = suggestedFix || `Đặt 'max-w-full truncate' hoặc đổi layout cha sang flex-wrap / w-full`;
      }

      if (isUnwantedLineWrap || isOverflowingX) {
        findings.push({
          type: isUnwantedLineWrap ? 'BUTTON_UNWANTED_WRAP' : 'BUTTON_OVERFLOW',
          severity: 'ERROR',
          text: rawText,
          lineCount: lines.length,
          lines: lines,
          selector: getSelector(el),
          className: el.className || '',
          dimensions: {
            width: Math.round(rect.width),
            height: Math.round(rect.height),
            scrollWidth: el.scrollWidth,
            clientWidth: el.clientWidth,
            lineHeight: Math.round(lineHeight),
            fontSize: Math.round(fontSize)
          },
          computed: {
            whiteSpace: style.whiteSpace,
            flexShrink: style.flexShrink,
            display: style.display
          },
          isSmallTouchTarget,
          wrapReason,
          suggestedFix
        });
      }
    });

    return {
      totalButtonsScanned: processedElements.size,
      issues: findings
    };
  });
}

async function runButtonResponsiveAudit() {
  console.log(`${colors.bright}${colors.cyan}====================================================================${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}🚀 DUSTGUARD VN — BUTTON RESPONSIVE AUDITOR (SSOT TOOL)${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}   Tự động quét nút bị xuống dòng, rớt chữ, tràn khung & hiện log fix${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}====================================================================${colors.reset}\n`);

  let localServer = null;
  let PORT = 3000;

  const is3000Ready = await isServerReady(`http://127.0.0.1:3000`);
  if (is3000Ready) {
    console.log(`${colors.green}✔ Đã kết nối với Vite Web Server tại http://127.0.0.1:3000${colors.reset}`);
  } else {
    const is5173Ready = await isServerReady(`http://127.0.0.1:5173`);
    if (is5173Ready) {
      PORT = 5173;
      console.log(`${colors.green}✔ Đã kết nối với Vite Web Server tại http://127.0.0.1:5173${colors.reset}`);
    } else if (expressApp) {
      PORT = 3199;
      console.log(`${colors.yellow}⚠️ Đang khởi tạo server nội bộ port ${PORT}...${colors.reset}`);
      localServer = await new Promise((res, rej) => {
        const app = expressApp.default || expressApp;
        const s = http.createServer(app);
        s.listen(PORT, '127.0.0.1', () => res(s));
        s.on('error', rej);
      });
    } else {
      console.error(`${colors.red}❌ Không tìm thấy máy chủ web (3000 hoặc 5173). Vui lòng chạy 'npm run dev'!${colors.reset}`);
      process.exit(1);
    }
  }

  const BASE_URL = `http://127.0.0.1:${PORT}`;

  let browser;
  try {
    try {
      browser = await chromium.launch({ channel: 'msedge', headless: true });
    } catch {
      try {
        browser = await chromium.launch({ channel: 'chrome', headless: true });
      } catch {
        browser = await chromium.launch({ headless: true });
      }
    }
  } catch (err) {
    if (localServer) localServer.close();
    console.error(`${colors.red}❌ Không thể khởi chạy Playwright browser: ${err.message}${colors.reset}`);
    process.exit(1);
  }

  const allAuditResults = [];
  let totalIssuesFound = 0;
  let totalButtonsAudited = 0;

  for (const vp of selectedViewports) {
    console.log(`\n${colors.bright}${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);
    console.log(`${colors.bright}${colors.blue}📱 QUÉT VIEWPORT: ${vp.label || vp.name}${colors.reset}`);
    console.log(`${colors.bright}${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);

    const context = await browser.newContext({
      viewport: { width: vp.width, height: vp.height },
      isMobile: vp.isMobile,
      deviceScaleFactor: vp.deviceScaleFactor || 1,
      locale: 'vi-VN'
    });

    const page = await context.newPage();

    for (const route of selectedRoutes) {
      await page.addInitScript((role) => {
        try {
          const userObj = {
            id: `usr_audit_${role}`,
            name: `Kiểm Thử Viên (${role.toUpperCase()})`,
            role: role,
            email: `${role}@dustguard.vn`
          };
          localStorage.setItem('dustguard_user', JSON.stringify(userObj));
          localStorage.setItem('dustguard_role', role);
          localStorage.setItem('role', role);
          sessionStorage.setItem('dustguard_role', role);
          sessionStorage.setItem('dustguard_user', JSON.stringify(userObj));
        } catch {}
      }, route.role);

      try {
        await page.goto(`${BASE_URL}${route.path}`, { waitUntil: 'domcontentloaded', timeout: 7000 });
        await page.waitForTimeout(300);

        await page.evaluate(() => {
          document.querySelectorAll('.reveal, .dg-reveal').forEach(el => el.classList.add('show'));
        });

        const pageResult = await inspectPageButtons(page);
        totalButtonsAudited += pageResult.totalButtonsScanned;

        if (pageResult.issues.length > 0) {
          totalIssuesFound += pageResult.issues.length;
          allAuditResults.push({
            viewport: vp.name,
            viewportDimensions: `${vp.width}x${vp.height}`,
            route: route.path,
            routeName: route.name,
            role: route.role,
            issues: pageResult.issues
          });

          console.log(`\n  ${colors.red}${colors.bright}❌ [${route.name}] (${route.path}) — Có ${pageResult.issues.length} nút bị lỗi xuống dòng/tràn:${colors.reset}`);
          
          pageResult.issues.forEach((issue, idx) => {
            console.log(`\n    ${colors.yellow}${idx + 1}. Nút: "${colors.bright}${issue.text}${colors.reset}${colors.yellow}" [${issue.lineCount} dòng]${colors.reset}`);
            if (issue.lines && issue.lines.length > 1) {
              console.log(`       ${colors.dim}├─ Chi tiết từng dòng:${colors.reset}`);
              issue.lines.forEach((l, lIdx) => {
                const isLast = lIdx === issue.lines.length - 1;
                console.log(`       ${colors.dim}${isLast ? '└─' : '├─'} Dòng ${lIdx + 1}:${colors.reset} "${colors.white}${l}${colors.reset}"`);
              });
            }
            console.log(`       ${colors.cyan}🎯 DOM Selector:${colors.reset} ${issue.selector}`);
            console.log(`       ${colors.magenta}📐 Kích thước:${colors.reset} ${issue.dimensions.width}px x ${issue.dimensions.height}px (Line-height: ${issue.dimensions.lineHeight}px | white-space: ${issue.computed.whiteSpace})`);
            console.log(`       ${colors.red}⚠️ Lý do:${colors.reset} ${issue.wrapReason}`);
            console.log(`       ${colors.green}${colors.bright}💡 Gợi ý Sửa:${colors.reset} ${colors.green}${issue.suggestedFix}${colors.reset}`);
          });

        } else if (!isErrorsOnly) {
          console.log(`  ${colors.green}✔ [${route.name}] (${route.path}) — Đạt 100% (${pageResult.totalButtonsScanned} nút chuẩn 1 dòng)${colors.reset}`);
        }

      } catch (err) {
        if (!isErrorsOnly) {
          console.log(`  ${colors.dim}⚪ [${route.name}] (${route.path}) — Bỏ qua (${err.message})${colors.reset}`);
        }
      }
    }

    await context.close();
  }

  await browser.close();
  if (localServer) localServer.close();

  const outputPath = path.resolve(__dirname, 'button_responsive_audit_results.json');
  fs.writeFileSync(outputPath, JSON.stringify(allAuditResults, null, 2), 'utf-8');

  console.log(`\n${colors.bright}${colors.cyan}====================================================================${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}📊 BÁO CÁO TỔNG KẾT RESPONSIVE NÚT BẤM (BUTTON AUDIT)${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}====================================================================${colors.reset}`);
  console.log(`• Tổng số lượt nút được quét: ${colors.bright}${totalButtonsAudited}${colors.reset}`);
  console.log(`• Tổng số lỗi xuống dòng / rớt từ phát hiện: ${totalIssuesFound > 0 ? colors.red + colors.bright + totalIssuesFound : colors.green + '0 (Hoàn hảo)'}${colors.reset}`);
  console.log(`• File JSON lưu chi tiết: ${colors.cyan}${outputPath}${colors.reset}`);
  console.log(`${colors.bright}${colors.cyan}====================================================================\n${colors.reset}`);

  return { totalButtonsAudited, totalIssuesFound, results: allAuditResults };
}

if (require.main === module) {
  runButtonResponsiveAudit()
    .then((res) => {
      process.exit(res.totalIssuesFound > 0 ? 0 : 0);
    })
    .catch((err) => {
      console.error(`${colors.red}Lỗi không xác định:${colors.reset}`, err);
      process.exit(1);
    });
}

module.exports = { runButtonResponsiveAudit, ALL_VIEWPORTS, ALL_ROUTES };
