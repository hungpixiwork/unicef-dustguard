const baseUrl = 'https://dp.sgp1.w9.nu';
const apiKey = 'bxzCrJEssaJZKgUNvPKEGgXqCwPjwDBUSALnYlEpUOUHYnQyCrrjjmloYWYxQvuh';

async function request(method, path, body) {
  const url = `${baseUrl}${path}`;
  const response = await fetch(url, {
    method,
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey
    },
    body: method === 'POST' ? JSON.stringify(body) : undefined
  });
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

async function main() {
  console.log('Fetching NK7Pe8GFim57MxDUy-p2w details...');
  const app1 = await request('GET', '/api/application.one?applicationId=NK7Pe8GFim57MxDUy-p2w');
  console.log('App 1 Status:', JSON.stringify(app1, null, 2));

  console.log('\nFetching v4p1oONwrhv2HXnnW0XNk details...');
  const app2 = await request('GET', '/api/application.one?applicationId=v4p1oONwrhv2HXnnW0XNk');
  console.log('App 2 Status:', JSON.stringify(app2, null, 2));
}

main().catch(console.error);
