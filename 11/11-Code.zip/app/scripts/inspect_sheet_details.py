import os
import cv2
import numpy as np
from PIL import Image

def find_cards_and_elements():
    sheets = {
        1: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_10 21 thg 8, 2026 (1).png", "sheet1"),
        2: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png", "sheet2"),
        3: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (3).png", "sheet3"),
        4: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (4).png", "sheet4"),
        5: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_12 21 thg 8, 2026 (5).png", "sheet5")
    }

    out_base = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets\details"
    os.makedirs(out_base, exist_ok=True)

    for num, (path, sname) in sheets.items():
        img = cv2.imread(path)
        h, w = img.shape[:2]
        s_out = os.path.join(out_base, sname)
        os.makedirs(s_out, exist_ok=True)
        
        # Save vertical slices / strips to understand card layout
        # For sheet 1 (1448 x 1086):
        # Let's save 4 row slices
        for i, y_start in enumerate(range(0, h, 250)):
            y_end = min(h, y_start + 270)
            cv2.imwrite(os.path.join(s_out, f"row_{i+1}_{y_start}_{y_end}.png"), img[y_start:y_end, :])

    print("Details saved.")

if __name__ == "__main__":
    find_cards_and_elements()
