const baseUrl = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:8787/api';
const demoEmail = process.env.SMOKE_LOGIN_EMAIL || process.env.DEMO_ADMIN_EMAIL || 'admin@dustguard.vn';
const demoPassword = process.env.SMOKE_LOGIN_PASSWORD || process.env.DEMO_ADMIN_PASSWORD || '123456';

let sessionCookie = '';

async function request(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(sessionCookie ? { Cookie: sessionCookie } : {}),
    ...(options.headers || {}),
  };
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers,
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) throw new Error(`${options.method || 'GET'} ${path} -> ${response.status}: ${text}`);
  return data;
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const health = await request('/health');
assert(health.ok, 'health check failed');

const publicComplaint = await request('/public-complaints', {
  method: 'POST',
  body: JSON.stringify({
    desc: 'Người dân phản ánh bụi phát tán kéo dài trong khu vực thi công.',
    loc: 'Khu vực cổng công trình demo',
    photo: false,
  }),
});
const publicComplaintObj = publicComplaint.data?.complaint ?? publicComplaint.complaint;
assert(publicComplaintObj?.id, 'public complaint create failed');

const loginResponse = await fetch(`${baseUrl}/auth/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: demoEmail, password: demoPassword }),
});
const loginText = await loginResponse.text();
if (!loginResponse.ok) throw new Error(`POST /auth/login -> ${loginResponse.status}: ${loginText}`);
sessionCookie = loginResponse.headers.get('set-cookie')?.split(';')[0] || '';
assert(sessionCookie, 'auth login did not set session cookie');

const me = await request('/auth/me');
assert(me.role === 'executive' || me.role === 'staff' || me.role === 'admin', 'demo login is not allowed to access staff routes');

const sites = await request('/sites');
const sitesItems = sites.data?.items ?? sites.items;
assert(Array.isArray(sitesItems) && sitesItems.length > 0, 'sites list is empty');
const site = sitesItems[0];

const stats = await request('/dashboard/stats');
const statsData = stats.data ?? stats;
assert(typeof (statsData.totalSites ?? statsData.total) === 'number' && (statsData.totalSites ?? statsData.total) > 0, 'dashboard stats invalid');

const operations = await request('/dashboard/operations');
const operationsData = operations.data ?? operations;
assert(typeof operationsData.kpis?.pending === 'number', 'dashboard operations invalid');

const complaint = await request('/complaints', {
  method: 'POST',
  body: JSON.stringify({
    siteId: site.id,
    citizen: 'Smoke Test',
    phone: '0900000000',
    desc: 'Phản ánh smoke test về bụi công trình',
    loc: site.address || site.addr,
  }),
});
const complaintObj = complaint.data?.complaint ?? complaint.complaint;
assert(complaintObj?.id, 'complaint create failed');

const updatedComplaint = await request(`/complaints/${encodeURIComponent(complaintObj.id)}/status`, {
  method: 'PATCH',
  body: JSON.stringify({ status: 'investigating' }),
});
const updatedComplaintObj = updatedComplaint.data?.complaint ?? updatedComplaint.complaint;
assert(updatedComplaintObj?.status === 'investigating', 'complaint status update failed');

const inspection = await request('/inspections', {
  method: 'POST',
  body: JSON.stringify({
    siteId: site.id,
    inspector: 'Smoke Test',
    items: [
      { k: 'barrier', status: 'pass', notes: 'Smoke pass' },
      { k: 'spray', status: 'fail', severity: 'medium', notes: 'Smoke fail' },
    ],
    overallScore: site.dustRiskScore || site.score || 0,
  }),
});
const inspectionObj = inspection.data?.id ? inspection.data : (inspection.data?.inspection ?? inspection.inspection);
const inspectionSiteObj = inspection.data?.site ?? inspection.site;
assert(inspectionObj?.id && (inspectionSiteObj?.riskLevel || inspectionSiteObj?.risk), 'inspection create failed');

const actions = await request('/actions?overdue=false');
const actionItems = actions.data?.items ?? actions.items;
assert(Array.isArray(actionItems), 'actions list invalid');
const autoAction = actionItems.find(action => action.inspectionId === inspectionObj.id);
assert(autoAction?.id, 'failed inspection did not create action');

const evidenceForm = new FormData();
evidenceForm.set('kind', 'before');
evidenceForm.set('caption', 'Smoke evidence');
evidenceForm.set('file', new Blob(['smoke evidence'], { type: 'image/png' }), 'smoke.png');
const evidenceResponse = await fetch(`${baseUrl}/actions/${encodeURIComponent(autoAction.id)}/evidence`, {
  method: 'POST',
  headers: { Cookie: sessionCookie },
  body: evidenceForm,
});
const evidenceText = await evidenceResponse.text();
if (!evidenceResponse.ok) throw new Error(`POST /actions/${autoAction.id}/evidence -> ${evidenceResponse.status}: ${evidenceText}`);
const evidence = evidenceText ? JSON.parse(evidenceText) : null;
assert(evidence?.data?.id || evidence?.id, 'evidence upload failed');

let aiProvider = null;
if (process.env.SMOKE_INCLUDE_AI === 'true') {
  const report = await request('/ai/inspection-report', {
    method: 'POST',
    body: JSON.stringify({ siteId: site.id }),
  });
  assert(report.content && report.metadata?.provider, 'AI report failed');
  aiProvider = report.metadata.provider;
}

console.log(JSON.stringify({ ok: true, baseUrl, user: me.email, siteId: site.id, complaintId: complaintObj.id, publicComplaintId: publicComplaintObj.id, inspectionId: inspectionObj.id, actionId: autoAction.id, aiProvider }, null, 2));
