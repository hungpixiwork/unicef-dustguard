import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('=== USERS ===', db.prepare("PRAGMA table_info(users)").all());
console.log('=== TASKS ===', db.prepare("PRAGMA table_info(tasks)").all());
console.log('=== CASES ===', db.prepare("PRAGMA table_info(cases)").all());
console.log('=== NOTIFICATIONS ===', db.prepare("PRAGMA table_info(notifications)").all());
console.log('=== REPORTS ===', db.prepare("PRAGMA table_info(reports)").all());
