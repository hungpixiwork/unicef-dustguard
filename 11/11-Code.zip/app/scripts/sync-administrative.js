import fs from 'fs';
import path from 'path';

const API_URL = 'https://provinces.open-api.vn/api/?depth=3';
const OUTPUT_PATH = path.resolve('src/shared/data/wards.json');

async function syncAdministrativeData() {
  console.log('Fetching current administrative data from provinces.open-api.vn...');
  try {
    const response = await fetch(API_URL);
    const provinces = await response.json();

    console.log(`Fetched ${provinces.length} provinces/cities. Transforming to 2026 standards...`);

    const new2026Wards = [];

    // Transform: Flatten the hierarchy by removing the 'District' (Quận/Huyện) level.
    // In 2026, Wards (Phường/Xã) belong directly to the City/Province.
    provinces.forEach(province => {
      // In a real scenario, you'd only do this for the specific cities you operate in.
      // We'll limit to HCM City (code 79) and Hanoi (code 01) for the MVP demo.
      if (province.code === 79 || province.code === 1) {
        province.districts.forEach(district => {
          district.wards.forEach(ward => {
            // To avoid name collisions across old districts, we might append the old district name
            // Or just keep the ward name if it's unique enough.
            new2026Wards.push({
              code: ward.code,
              name: ward.name,
              // Note: No District ID/Name is saved! It's completely removed in the 2026 structure.
              city: province.name,
              // We can keep a legacy search string just in case citizens search by old districts
              legacySearch: `${ward.name}, ${district.name}`
            });
          });
        });
      }
    });

    console.log(`Generated ${new2026Wards.length} Phường (Wards) for the 2026 structure (No Districts).`);
    
    // Ensure directory exists
    const dir = path.dirname(OUTPUT_PATH);
    if (!fs.existsSync(dir)){
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(OUTPUT_PATH, JSON.stringify(new2026Wards, null, 2), 'utf-8');
    console.log(`Saved new administrative definitions to: ${OUTPUT_PATH}`);

  } catch (error) {
    console.error('Error syncing administrative data:', error);
  }
}

syncAdministrativeData();
