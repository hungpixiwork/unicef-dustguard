import fs from 'fs';
import path from 'path';

const ROOT_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard');

const IGNORE_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  '.vite',
  '.wrangler',
  '.pio',
  '.netlify',
  'backups',
  '.gemini',
  '.codelens'
]);

function countLines(filePath, content) {
  const ext = path.extname(filePath).toLowerCase();
  const lines = content.split(/\r?\n/);
  const total = lines.length;
  let blank = 0;
  let comment = 0;
  let inBlockComment = false;

  for (let line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      blank++;
      continue;
    }

    if (['.js', '.jsx', '.ts', '.tsx', '.cjs', '.mjs', '.c', '.cpp', '.h', '.css'].includes(ext)) {
      if (inBlockComment) {
        comment++;
        if (trimmed.includes('*/')) {
          inBlockComment = false;
        }
        continue;
      }
      if (trimmed.startsWith('/*')) {
        comment++;
        if (!trimmed.includes('*/') || trimmed.endsWith('/*')) {
          inBlockComment = true;
        }
        continue;
      }
      if (trimmed.startsWith('//')) {
        comment++;
        continue;
      }
    } else if (['.py', '.yaml', '.yml', '.ini'].includes(ext)) {
      if (trimmed.startsWith('#')) {
        comment++;
        continue;
      }
    } else if (['.sql'].includes(ext)) {
      if (trimmed.startsWith('--') || trimmed.startsWith('/*')) {
        comment++;
        continue;
      }
    } else if (['.html', '.xml', '.svg'].includes(ext)) {
      if (trimmed.startsWith('<!--')) {
        comment++;
        continue;
      }
    }
  }

  const code = total - blank - comment;
  return { total, blank, comment, code };
}

function scanFiles(dir) {
  let fileList = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (IGNORE_DIRS.has(entry.name)) continue;
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        fileList = fileList.concat(scanFiles(fullPath));
      } else {
        fileList.push(fullPath);
      }
    }
  } catch (e) {}
  return fileList;
}

function categorizeFile(relPath) {
  const norm = relPath.replace(/\\/g, '/');

  // Test Suite
  if (norm.startsWith('app/tests/') || norm.includes('.test.') || norm.includes('.spec.')) {
    return '1. Test Suites & Automation';
  }

  // Firmware
  if (norm.startsWith('firmware/')) {
    return '9. IoT Firmware & Hardware Edge';
  }

  // Backend & API
  if (
    norm.startsWith('app/server/') ||
    norm.startsWith('app/api/') ||
    norm.startsWith('server/') ||
    norm.startsWith('app/migrations/') ||
    norm.startsWith('app/prisma/') ||
    norm.startsWith('app/better-auth_migrations/')
  ) {
    return '2. Backend & Edge API Core';
  }

  // Legal Document Engine & A4 Studio
  if (
    norm.startsWith('app/src/legal-document-engine/') ||
    norm.startsWith('app/src/components/DocumentEditor/') ||
    norm.startsWith('app/src/modules/documents/') ||
    norm.startsWith('app/src/components/PolicyIntelligence/') ||
    norm.startsWith('app/src/lib/documents/')
  ) {
    return '6. Legal Document Engine & A4 Studio';
  }

  // Staff & Operations Center
  if (
    norm.startsWith('app/src/modules/staff/') ||
    norm.startsWith('app/src/modules/cases/') ||
    norm.startsWith('app/src/components/StaffAI/') ||
    norm.startsWith('app/src/components/complaints/') ||
    norm.startsWith('app/src/components/checklist/') ||
    norm.startsWith('app/src/components/site-detail/') ||
    norm.startsWith('app/src/modules/admin/')
  ) {
    return '3. Staff & Operations Center';
  }

  // Citizen & Community Portal
  if (
    norm.startsWith('app/src/modules/citizen/') ||
    norm.startsWith('app/src/modules/community/') ||
    norm.startsWith('app/src/modules/youth/') ||
    norm.startsWith('app/src/modules/public/') ||
    norm.startsWith('app/src/apps/public-app.jsx') ||
    norm.startsWith('app/src/components/citizen/') ||
    norm.startsWith('app/src/components/landing/') ||
    norm.startsWith('app/src/apps/landing-app.jsx')
  ) {
    return '4. Citizen & Community Portal';
  }

  // Executive Command Center
  if (
    norm.startsWith('app/src/modules/executive/') ||
    norm.startsWith('app/src/components/executive/') ||
    norm.startsWith('app/src/apps/executive-app.jsx')
  ) {
    return '5. Executive Command Center';
  }

  // Contractor & Remediation
  if (
    norm.startsWith('app/src/modules/contractor/') ||
    norm.startsWith('app/src/components/ecommerce/')
  ) {
    return '7. Contractor & Remediation Portal';
  }

  // Spatial Map & UI Primitives & Design System
  if (
    norm.startsWith('app/src/components/map/') ||
    norm.startsWith('app/src/components/ui/') ||
    norm.startsWith('app/src/components/shared/') ||
    norm.startsWith('app/src/components/common/') ||
    norm.startsWith('app/src/components/tables/') ||
    norm.startsWith('app/src/components/charts/') ||
    norm.startsWith('app/src/components/form/') ||
    norm.startsWith('app/src/components/header/') ||
    norm.startsWith('app/src/components/auth/') ||
    norm.startsWith('app/src/design-system/') ||
    norm.startsWith('app/src/tokens/') ||
    norm.startsWith('app/src/layouts/') ||
    norm.startsWith('app/src/layout/') ||
    norm.startsWith('app/src/icons/') ||
    norm.startsWith('app/src/shared/') ||
    norm.startsWith('app/src/hooks/') ||
    norm.startsWith('app/src/utils/') ||
    norm.startsWith('app/src/services/') ||
    norm.startsWith('app/src/lib/') ||
    norm.startsWith('app/src/context/') ||
    norm.startsWith('app/src/config/') ||
    norm.startsWith('app/src/infrastructure/') ||
    norm.startsWith('app/src/locales/') ||
    norm.startsWith('app/src/modules/auth/') ||
    norm.startsWith('app/src/apps/admin-app.jsx') ||
    norm === 'app/src/App.jsx' ||
    norm === 'app/src/main.jsx' ||
    norm === 'app/src/index.css' ||
    norm === 'app/src/landing.css' ||
    norm === 'app/src/vite-env.d.ts'
  ) {
    return '8. Spatial Map, UI Primitives & Core Infra';
  }

  // Tooling & Scripts
  if (norm.startsWith('app/scripts/') || norm.startsWith('scripts/')) {
    return '10. Tooling & Automation Scripts';
  }

  // Documentation & SSOT
  if (
    norm.startsWith('.agents/') ||
    norm.startsWith('docs/') ||
    norm.startsWith('presentation/') ||
    norm.startsWith('traction/') ||
    norm.startsWith('app/docs/') ||
    norm.startsWith('app/plans/') ||
    norm.startsWith('app/references/') ||
    norm.endsWith('.md')
  ) {
    return '11. Documentation, SSOT & Presentation';
  }

  return '12. Other / Config / Assets';
}

function runAudit() {
  const allFiles = scanFiles(ROOT_DIR);
  console.log(`Auditing ${allFiles.length} files...`);

  const categoryStats = {};
  const langStats = {};
  const fileDetailList = [];

  const CODE_EXTS = new Set([
    '.js', '.jsx', '.ts', '.tsx', '.cjs', '.mjs',
    '.css', '.sql', '.prisma',
    '.c', '.cpp', '.h', '.ini',
    '.py', '.html', '.json', '.yaml', '.yml', '.md'
  ]);

  for (const fullPath of allFiles) {
    const relPath = path.relative(ROOT_DIR, fullPath).replace(/\\/g, '/');
    const ext = path.extname(fullPath).toLowerCase() || '[no_ext]';
    const cat = categorizeFile(relPath);

    let stat;
    try {
      stat = fs.statSync(fullPath);
    } catch (e) {
      continue;
    }

    let lineInfo = { total: 0, blank: 0, comment: 0, code: 0 };
    let isTextCode = false;

    if (CODE_EXTS.has(ext)) {
      try {
        const content = fs.readFileSync(fullPath, 'utf8');
        lineInfo = countLines(fullPath, content);
        isTextCode = true;
      } catch (e) {}
    }

    if (!categoryStats[cat]) {
      categoryStats[cat] = {
        totalFiles: 0,
        codeFiles: 0,
        grossLines: 0,
        blankLines: 0,
        commentLines: 0,
        sloc: 0,
        totalBytes: 0,
        byExt: {}
      };
    }

    categoryStats[cat].totalFiles++;
    categoryStats[cat].totalBytes += stat.size;

    if (isTextCode) {
      categoryStats[cat].codeFiles++;
      categoryStats[cat].grossLines += lineInfo.total;
      categoryStats[cat].blankLines += lineInfo.blank;
      categoryStats[cat].commentLines += lineInfo.comment;
      categoryStats[cat].sloc += lineInfo.code;

      if (!categoryStats[cat].byExt[ext]) {
        categoryStats[cat].byExt[ext] = { files: 0, sloc: 0, gross: 0 };
      }
      categoryStats[cat].byExt[ext].files++;
      categoryStats[cat].byExt[ext].sloc += lineInfo.code;
      categoryStats[cat].byExt[ext].gross += lineInfo.total;

      if (!langStats[ext]) {
        langStats[ext] = { files: 0, gross: 0, blank: 0, comment: 0, sloc: 0, bytes: 0 };
      }
      langStats[ext].files++;
      langStats[ext].gross += lineInfo.total;
      langStats[ext].blank += lineInfo.blank;
      langStats[ext].comment += lineInfo.comment;
      langStats[ext].sloc += lineInfo.code;
      langStats[ext].bytes += stat.size;

      fileDetailList.push({
        relPath,
        category: cat,
        ext,
        size: stat.size,
        ...lineInfo
      });
    }
  }

  const result = {
    summary: {
      scannedFiles: allFiles.length,
      codeFiles: fileDetailList.length,
      totalGrossLines: Object.values(categoryStats).reduce((a, b) => a + b.grossLines, 0),
      totalSLOC: Object.values(categoryStats).reduce((a, b) => a + b.sloc, 0),
      totalComments: Object.values(categoryStats).reduce((a, b) => a + b.commentLines, 0),
      totalBlanks: Object.values(categoryStats).reduce((a, b) => a + b.blankLines, 0),
    },
    categoryStats,
    langStats,
    fileDetailList
  };

  fs.writeFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/scripts/loc_audit_result.json', JSON.stringify(result, null, 2));
  console.log('LOC Audit Complete! Saved to app/scripts/loc_audit_result.json');
}

runAudit();
