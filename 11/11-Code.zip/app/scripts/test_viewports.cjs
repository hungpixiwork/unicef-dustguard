const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const viewports = [
  { name: '1920x1080_desktop', width: 1920, height: 1080, isMobile: false },
  { name: '1600x900_desktop', width: 1600, height: 900, isMobile: false },
  { name: '1440x900_laptop', width: 1440, height: 900, isMobile: false },
  { name: '1366x768_laptop', width: 1366, height: 768, isMobile: false },
  { name: '1280x720_laptop', width: 1280, height: 720, isMobile: false },
  { name: '1024x768_tablet_landscape', width: 1024, height: 768, isMobile: false },
  { name: '820x1180_ipad_air', width: 820, height: 1180, isMobile: true },
  { name: '768x1024_ipad_portrait', width: 768, height: 1024, isMobile: true },
  { name: '430x932_iphone_pro_max', width: 430, height: 932, isMobile: true },
  { name: '390x844_iphone_14', width: 390, height: 844, isMobile: true },
  { name: '375x812_iphone_mini', width: 375, height: 812, isMobile: true }
];

async function run() {
  const outDir = path.resolve(__dirname, 'viewport_test_results');
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  let browser;
  try {
    browser = await chromium.launch({ channel: 'chrome' });
  } catch (e) {
    try {
      browser = await chromium.launch({ channel: 'msedge' });
    } catch (e2) {
      browser = await chromium.launch();
    }
  }

  const results = [];

  for (const vp of viewports) {
    const context = await browser.newContext({
      viewport: { width: vp.width, height: vp.height },
      isMobile: vp.isMobile
    });
    const page = await context.newPage();
    await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });

    // Reveal elements
    await page.evaluate(() => {
      document.querySelectorAll('.reveal, .dg-reveal').forEach(el => el.classList.add('show'));
    });
    await page.waitForTimeout(300);

    // Check for horizontal overflow
    const overflow = await page.evaluate(() => {
      const scrollWidth = document.documentElement.scrollWidth;
      const clientWidth = document.documentElement.clientWidth;
      return {
        scrollWidth,
        clientWidth,
        hasOverflow: scrollWidth > clientWidth + 1
      };
    });

    // Check section 2 height fit on laptop viewports
    const section2Fit = await page.evaluate(() => {
      const sec2 = document.getElementById('problem');
      if (!sec2) return null;
      const rect = sec2.getBoundingClientRect();
      return {
        height: rect.height,
        boxHeights: Array.from(sec2.querySelectorAll('.problem-box')).map(b => b.offsetHeight)
      };
    });

    results.push({
      viewport: vp.name,
      width: vp.width,
      height: vp.height,
      hasOverflow: overflow.hasOverflow,
      scrollWidth: overflow.scrollWidth,
      clientWidth: overflow.clientWidth,
      sec2Height: section2Fit ? Math.round(section2Fit.height) : null
    });

    await page.screenshot({ path: path.join(outDir, `${vp.name}.png`), fullPage: true });
    await context.close();
    console.log(`[PASS] Verified ${vp.name} - Overflow: ${overflow.hasOverflow ? 'FAIL' : 'OK'} (Sec2 height: ${section2Fit ? Math.round(section2Fit.height) : 'N/A'}px)`);
  }

  await browser.close();

  const allPassed = results.every(r => !r.hasOverflow);
  console.log('\n=============================================');
  console.log(`ALL 11 VIEWPORTS VERIFIED: ${allPassed ? '100% PASS (Zero Overflow)' : 'FAIL'}`);
  console.log('=============================================\n');
  console.table(results);
}

run().catch(err => {
  console.error('Viewport verification error:', err);
  process.exit(1);
});
