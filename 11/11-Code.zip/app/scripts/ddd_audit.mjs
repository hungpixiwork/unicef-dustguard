import fs from 'fs';
import path from 'path';

const ROOT_DIR = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard');

function auditDDD() {
  console.log('=== DDD BOUNDED CONTEXTS AUDIT ===');
  const domainDir = path.join(ROOT_DIR, 'app/server/domain');
  const domains = fs.readdirSync(domainDir, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name);
  
  console.log(`Found ${domains.length} Domain Bounded Contexts in Backend:`);
  domains.forEach(d => {
    const files = fs.readdirSync(path.join(domainDir, d));
    console.log(` - Context [${d}]: ${files.length} files (${files.join(', ')})`);
  });

  console.log('\n=== REPOSITORY LAYER AUDIT ===');
  const repoDir = path.join(ROOT_DIR, 'app/server/repositories');
  const repos = fs.readdirSync(repoDir).filter(f => f.endsWith('.js'));
  console.log(`Found ${repos.length} D1 Repositories:`);
  repos.forEach(r => console.log(` - ${r}`));

  console.log('\n=== ROUTE ENDPOINTS AUDIT ===');
  const routeDir = path.join(ROOT_DIR, 'app/server/routes/api');
  const routes = fs.readdirSync(routeDir).filter(f => f.endsWith('.js'));
  console.log(`Found ${routes.length} API Route Definitions:`);
  routes.forEach(r => console.log(` - ${r}`));

  console.log('\n=== FRONTEND BOUNDED CONTEXTS AUDIT ===');
  const modDir = path.join(ROOT_DIR, 'app/src/modules');
  const frontendMods = fs.readdirSync(modDir, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name);
  console.log(`Found ${frontendMods.length} Frontend Modular Domains:`);
  frontendMods.forEach(m => {
    const full = path.join(modDir, m);
    const sub = fs.readdirSync(full);
    console.log(` - Module [${m}]: ${sub.length} entries`);
  });
}

auditDDD();
