import fs from 'fs';
import path from 'path';
import Database from 'better-sqlite3';

const dbPath = path.resolve('prisma/dev.db');
const db = new Database(dbPath);

console.log('🚀 Exporting clean canonical dataset from local SQLite to prisma/d1-seed.sql...');

const escape = (val) => {
  if (val === null || val === undefined) return 'NULL';
  if (typeof val === 'number') return val;
  if (typeof val === 'boolean') return val ? 1 : 0;
  return `'${String(val).replace(/'/g, "''")}'`;
};

let sql = 'PRAGMA foreign_keys = OFF;\n\n';

const tables = [
  'users',
  'sites',
  'sensors',
  'sensor_readings',
  'complaints',
  'cases',
  'case_status_history',
  'case_timelines',
  'evidences',
  'legal_documents',
  'legal_obligations',
  'legal_segments'
];

for (const table of tables) {
  try {
    const rows = db.prepare(`SELECT * FROM "${table}"`).all();
    if (rows.length === 0) continue;

    sql += `-- Table: ${table} (${rows.length} rows)\n`;
    const cols = Object.keys(rows[0]);
    for (const row of rows) {
      const vals = cols.map(c => escape(row[c]));
      sql += `INSERT INTO "${table}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${vals.join(', ')});\n`;
    }
    sql += '\n';
  } catch (err) {
    console.warn(`Skipping table ${table}: ${err.message}`);
  }
}

sql += 'PRAGMA foreign_keys = ON;\n';

fs.writeFileSync(path.resolve('prisma/d1-seed.sql'), sql, 'utf8');
console.log('✅ Successfully exported canonical D1 SQL seed to prisma/d1-seed.sql');
