import os
import cv2
import numpy as np

def catalog_sheets():
    sheets = {
        1: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_10 21 thg 8, 2026 (1).png", "sheet1_brand_ui"),
        2: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png", "sheet2_icons"),
        3: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (3).png", "sheet3_city_iot"),
        4: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (4).png", "sheet4_patterns_connectors"),
        5: (r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_12 21 thg 8, 2026 (5).png", "sheet5_community_people")
    }

    out_base = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets\catalog"
    os.makedirs(out_base, exist_ok=True)

    for num, (path, sname) in sheets.items():
        img = cv2.imread(path)
        h, w = img.shape[:2]
        s_out = os.path.join(out_base, sname)
        os.makedirs(s_out, exist_ok=True)
        
        # In this sheet, detect cards by finding rectangular contours or bounding boxes of connected components
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # Background is close to 250-254
        # We find edges
        edges = cv2.Canny(gray, 30, 100)
        # Dilate edges slightly
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        dilated = cv2.dilate(edges, kernel, iterations=2)
        
        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        annotated = img.copy()
        idx = 0
        boxes = []
        for c in contours:
            x, y, bw, bh = cv2.boundingRect(c)
            # Filter cards/items larger than 40x40
            if bw >= 40 and bh >= 40 and (bw < w - 20 or bh < h - 20):
                boxes.append((x, y, bw, bh))
                
        # Sort boxes top to bottom, left to right
        boxes = sorted(boxes, key=lambda b: (b[1] // 100, b[0]))
        
        for i, (x, y, bw, bh) in enumerate(boxes):
            crop = img[y:y+bh, x:x+bw]
            cv2.imwrite(os.path.join(s_out, f"item_{i+1:02d}_x{x}_y{y}_w{bw}_h{bh}.png"), crop)
            cv2.rectangle(annotated, (x, y), (x+bw, y+bh), (0, 0, 255), 2)
            cv2.putText(annotated, f"#{i+1}", (x+5, y+20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

        cv2.imwrite(os.path.join(out_base, f"{sname}_annotated.png"), annotated)
        print(f"{sname}: saved {len(boxes)} items")

if __name__ == "__main__":
    catalog_sheets()
