/**
 * DustGuard VN - Level 3 Verification: verify:quick
 * Default fast verification gate for AI Agent and developers during active coding (< 15-30s).
 */

import { TEST_GROUPS } from './test-groups.js';
import { executeTestPipeline, runProcess } from './verification-runner.js';

async function main() {
  console.log('========================================================');
  console.log('⚡ DUSTGUARD QUICK GATE (HIGH-SIGNAL INNER LOOP)');
  console.log('========================================================\n');

  // 0. Architecture & Dependency Invariant Check (< 0.1s)
  console.log('▶ Step 0/3: Architecture Gate & Dependency Discipline...');
  const archRes = await runProcess('node', ['scripts/architecture-gate.js'], { silent: false });
  if (archRes.exitCode !== 0) {
    console.error('\n❌ FAIL-FAST: Architecture Gate failed.');
    process.exit(1);
  }

  // 1. Static Contract & Parity Check (Fast ~0.2s)
  console.log('▶ Step 1/3: OpenAPI Contract Parity Audit...');
  const auditRes = await runProcess('node', ['scripts/audit-api-contract.js'], { silent: false });
  if (auditRes.exitCode !== 0) {
    console.error('\n❌ FAIL-FAST: API Contract audit failed.');
    process.exit(1);
  }
  console.log('✅ API Contract audit passed\n');

  // 2. High-Signal Critical & Unit Tests
  const quickFiles = [
    ...new Set([
      ...TEST_GROUPS.critical,
      ...TEST_GROUPS.unit
    ])
  ];

  console.log(`▶ Step 2/3: Critical & Unit Tests (${quickFiles.length} files)...`);
  const testRes = await executeTestPipeline(quickFiles, {
    title: 'QUICK SMOKE & DOMAIN GATE'
  });

  if (!testRes.success) {
    process.exit(1);
  }

  // 3. UI Smoke Layout
  console.log('▶ Step 3/3: Critical UI & Layout Smoke Tests...');
  const uiSmoke = [
    'tests/citizen-reports-error-state.test.js',
    'tests/community-home-layout.test.js',
    'tests/community-modules-layout.test.js',
    'tests/community-navigation-layout.test.js',
    'tests/design-system-tokens.test.js'
  ];
  const uiRes = await executeTestPipeline(uiSmoke, {
    title: 'UI SMOKE'
  });

  if (!uiRes.success) {
    process.exit(1);
  }

  console.log('========================================================');
  console.log('🎉 QUICK GATE VERIFIED: CODE READY TO CONTINUE');
  console.log('Note: Full release verification will run at task completion.');
  console.log('========================================================');
  process.exit(0);
}

main().catch(err => {
  console.error('Fatal in verify-quick:', err);
  process.exit(1);
});
