import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const APP_DIR = path.resolve(__dirname, '..');
const SRC_DIR = path.join(APP_DIR, 'src');
const SERVER_DIR = path.join(APP_DIR, 'server');

console.log('=== DUSTGUARD VN - BROWSER RUNTIME, NETWORK & INTEGRATION AUDIT ===\n');
console.log(`App Dir: ${APP_DIR}`);
console.log(`Src Dir: ${SRC_DIR}`);
console.log(`Server Dir: ${SERVER_DIR}`);

// 1. Collect all files in src
function getAllFiles(dir, extList = ['.jsx', '.js', '.tsx', '.ts', '.html']) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      if (file !== 'node_modules' && file !== 'dist' && file !== '.git') {
        results = results.concat(getAllFiles(filePath, extList));
      }
    } else {
      if (extList.includes(path.extname(file))) {
        results.push(filePath);
      }
    }
  }
  return results;
}

const srcFiles = getAllFiles(SRC_DIR);
console.log(`Found ${srcFiles.length} source files in src.`);

// 2. Check React Keys in .map(...)
console.log('\n--- 1. AUDITING REACT KEY WARNINGS IN .map() ---');
let keyIssues = [];
for (const file of srcFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('.map(') && !line.trim().startsWith('//') && !line.trim().startsWith('*')) {
      let chunk = lines.slice(i, Math.min(lines.length, i + 14)).join('\n');
      // Match if returning an element directly
      const matchJsx = chunk.match(/\.map\s*\([^)]*\)\s*=>\s*(?:\(?\s*)<([a-zA-Z0-9_.-]+)/);
      if (matchJsx) {
        const tagName = matchJsx[1];
        if (tagName !== 'React.Fragment' && tagName !== 'Fragment' && !chunk.includes('key=')) {
          keyIssues.push({
            file: path.relative(APP_DIR, file),
            line: i + 1,
            snippet: line.trim()
          });
        }
      }
    }
  }
}

if (keyIssues.length === 0) {
  console.log('✓ No missing React key warnings detected in JSX .map() loops.');
} else {
  console.log(`⚠️ Found ${keyIssues.length} potential missing key locations:`);
  keyIssues.forEach(iss => console.log(`  - ${iss.file}:${iss.line} -> ${iss.snippet}`));
}

// 3. Check for API Endpoint Mismatches
console.log('\n--- 2. AUDITING API ENDPOINTS & NETWORK CALLS ---');

const serverFiles = getAllFiles(SERVER_DIR);
let backendEndpoints = [];

for (const sFile of serverFiles) {
  const content = fs.readFileSync(sFile, 'utf-8');
  const routeRegex = /(?:app|router|worker)\.(?:get|post|put|patch|delete)\s*\(\s*['"`]([^'"`]+)['"`]/g;
  let match;
  while ((match = routeRegex.exec(content)) !== null) {
    backendEndpoints.push({ file: path.relative(APP_DIR, sFile), path: match[1] });
  }
}

const workerPath = path.join(SERVER_DIR, 'worker.js');
if (fs.existsSync(workerPath)) {
  const workerContent = fs.readFileSync(workerPath, 'utf-8');
  const workerRouteRegex = /\/api\/[a-zA-Z0-9_\-/:*]+/g;
  let wMatch;
  while ((wMatch = workerRouteRegex.exec(workerContent)) !== null) {
    backendEndpoints.push({ file: 'server/worker.js', path: wMatch[0] });
  }
}

console.log(`Collected ${backendEndpoints.length} backend API endpoint definitions.`);

// Extract frontend API calls
let frontendCalls = [];
for (const file of srcFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const fetchRegex = /(?:fetch|apiClient\.get|apiClient\.post|apiClient\.patch|apiClient\.delete|request)\s*\(\s*['"`](\/api\/[^'"`?#]+)/g;
  let match;
  while ((match = fetchRegex.exec(content)) !== null) {
    frontendCalls.push({
      file: path.relative(APP_DIR, file),
      endpoint: match[1]
    });
  }
}

console.log(`Audited ${frontendCalls.length} frontend /api/* call sites.`);

// 4. Check for unhandled promises or raw window.fetch without catch/try
console.log('\n--- 3. AUDITING UNHANDLED PROMISES & ASYNC TRY/CATCH GUARDS ---');
let unhandledAsync = [];
for (const file of srcFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('useEffect(')) {
      let effectChunk = lines.slice(i, Math.min(lines.length, i + 35)).join('\n');
      if (effectChunk.includes('async ()') || effectChunk.includes('async()')) {
        if (!effectChunk.includes('try') && !effectChunk.includes('.catch')) {
          unhandledAsync.push({
            file: path.relative(APP_DIR, file),
            line: i + 1,
            type: 'useEffect async without try/catch'
          });
        }
      }
    }
  }
}

if (unhandledAsync.length === 0) {
  console.log('✓ All useEffect async routines are safely wrapped with try/catch / error handlers.');
} else {
  console.log(`⚠️ Found ${unhandledAsync.length} async routines to review:`);
  unhandledAsync.forEach(u => console.log(`  - ${u.file}:${u.line} -> ${u.type}`));
}

// 5. Check for Request Loops in useEffect
console.log('\n--- 4. AUDITING USEEFFECT DEPENDENCY & REQUEST LOOP PATTERNS ---');
let potentialLoops = [];
for (const file of srcFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('useEffect(')) {
      let effectChunk = lines.slice(i, Math.min(lines.length, i + 30)).join('\n');
      const stateSetMatches = effectChunk.matchAll(/set([A-Z][a-zA-Z0-9_]*)\s*\(/g);
      for (const sm of stateSetMatches) {
        const stateName = sm[1].toLowerCase();
        const depMatch = effectChunk.match(/,\s*\[([^\]]*)\]/);
        if (depMatch) {
          const deps = depMatch[1].split(',').map(d => d.trim().toLowerCase());
          if (deps.includes(stateName) || deps.includes(sm[1].charAt(0).toLowerCase() + sm[1].slice(1).toLowerCase())) {
            potentialLoops.push({
              file: path.relative(APP_DIR, file),
              line: i + 1,
              state: sm[1]
            });
          }
        }
      }
    }
  }
}

if (potentialLoops.length === 0) {
  console.log('✓ No request loops or self-invalidating useEffect dependency cycles detected.');
} else {
  console.log(`⚠️ Potential loop patterns found:`, potentialLoops);
}

// 6. Detailed list of unique frontend endpoints called
console.log('\n--- 5. FRONTEND ENDPOINTS INVENTORY ---');
const uniqueEndpoints = [...new Set(frontendCalls.map(c => c.endpoint))];
uniqueEndpoints.sort();
console.log(`Unique frontend endpoints (${uniqueEndpoints.length}):`);
uniqueEndpoints.forEach(ep => console.log(`  - ${ep}`));

console.log('\n=== AUDIT SCRIPT COMPLETED ===');
