import fs from 'fs';
import path from 'path';

function walk(dir) {
  let files = [];
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) {
      if (f !== 'node_modules' && f !== 'dist' && f !== '.git') {
        files = files.concat(walk(p));
      }
    } else if (f.endsWith('.js') || f.endsWith('.jsx') || f.endsWith('.ts') || f.endsWith('.tsx')) {
      files.push(p);
    }
  }
  return files;
}

const files = walk(path.resolve('src'));
let fixed = [];
for (const f of files) {
  let content = fs.readFileSync(f, 'utf8');
  if (/\bReact\.[A-Za-z0-9_]+/.test(content)) {
    const hasImport = /import\s+React\b/.test(content) || /import\s+\*\s+as\s+React\b/.test(content) || /const\s+React\s*=/.test(content);
    if (!hasImport) {
      if (/import\s+type\s+React\b/.test(content)) {
        content = content.replace(/import\s+type\s+React\s+from\s+['"]react['"];?/, "import React from 'react';");
      } else {
        content = "import React from 'react';\n" + content;
      }
      fs.writeFileSync(f, content, 'utf8');
      fixed.push(path.relative(process.cwd(), f));
    }
  }
}
console.log('Fixed React import in files:', fixed);
