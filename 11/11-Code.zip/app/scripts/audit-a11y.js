import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function walk(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git' && file !== 'dist') {
        walk(fullPath, fileList);
      }
    } else if (/\.(jsx?|tsx?)$/.test(file)) {
      fileList.push(fullPath);
    }
  }
  return fileList;
}

const rootDir = path.resolve(__dirname, '../src');
const files = walk(rootDir);
console.log(`Found ${files.length} source files to inspect.`);

// 1. Check Modals / Dialogs / Bottom Sheets
console.log('\n--- 1. MODAL / DIALOG AUDIT ---');
files.forEach(file => {
  const code = fs.readFileSync(file, 'utf8');
  if (code.includes('fixed inset-0') || code.includes('role="dialog"') || code.includes('aria-modal')) {
    const rel = path.relative(rootDir, file).replace(/\\/g, '/');
    const isBottomSheet = code.includes('items-end') || code.includes('rounded-t-') || code.includes('bottom-0') || code.includes('sm:items-center');
    const hasEscape = code.includes('Escape') || code.includes('useModal') || code.includes('Modal');
    console.log(`Modal/Dialog in: ${rel} | BottomSheet pattern: ${isBottomSheet} | Escape handled: ${hasEscape}`);
  }
});

// 2. Check Data Tables (table tags and overflow-x-auto)
console.log('\n--- 2. DATA TABLE AUDIT ---');
files.forEach(file => {
  const code = fs.readFileSync(file, 'utf8');
  if (code.includes('<table')) {
    const rel = path.relative(rootDir, file).replace(/\\/g, '/');
    const hasOverflow = code.includes('overflow-x-auto') || code.includes('table-responsive') || code.includes('overflow-auto');
    const hasCardFallback = code.includes('sm:hidden') || code.includes('hidden sm:') || code.includes('lg:table');
    console.log(`Table in: ${rel} | Wrapped in overflow-x: ${hasOverflow} | Card fallback: ${hasCardFallback}`);
  }
});

// 3. Check Touch Targets (<button, <a, <input, select)
console.log('\n--- 3. TOUCH TARGET INSPECTION ---');
let smallTargets = [];
files.forEach(file => {
  const code = fs.readFileSync(file, 'utf8');
  const rel = path.relative(rootDir, file).replace(/\\/g, '/');
  const buttonMatches = code.match(/<button[^>]*className=["']([^"']*)["'][^>]*>/g) || [];
  buttonMatches.forEach(b => {
    if (b.includes('h-6 ') || b.includes('h-7 ') || b.includes('h-8 ') || b.includes('w-6 ') || b.includes('w-7 ') || b.includes('w-8 ') || b.includes('size-6') || b.includes('size-7') || b.includes('size-8')) {
      if (!b.includes('min-h-[44px]') && !b.includes('min-h-[48px]') && !b.includes('touch-target') && !b.includes('p-3') && !b.includes('p-2.5')) {
        smallTargets.push({ file: rel, snippet: b.slice(0, 140) });
      }
    }
  });
});
console.log(`Potential small button targets count: ${smallTargets.length}`);
smallTargets.slice(0, 30).forEach(t => console.log(`  ${t.file}: ${t.snippet}`));
