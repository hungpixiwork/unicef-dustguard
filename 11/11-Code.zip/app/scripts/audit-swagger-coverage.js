import { openApiSpec } from '../server/docs/openapi.spec.js';
import { readFileSync } from 'fs';

console.log('=== OPENAPI 3.0.3 & SWAGGER COVERAGE AUDIT ===\n');

// 1. Check basic OpenAPI structure
console.log('1. OpenAPI Version:', openApiSpec.openapi);
console.log('2. API Title:', openApiSpec.info.title);
console.log('3. Defined Tags count:', openApiSpec.tags.length);
console.log('4. Documented Paths count:', Object.keys(openApiSpec.paths).length);
console.log('5. Documented Schemas count:', Object.keys(openApiSpec.components.schemas).length);

// 2. Extract endpoints from server/worker.js
const workerCode = readFileSync('server/worker.js', 'utf-8');
const routeMatches = [...workerCode.matchAll(/app\.(get|post|put|patch|delete)\(['"]([^'"]+)['"]/g)];
const workerEndpoints = [...new Set(routeMatches.map(m => `${m[1].toUpperCase()} ${m[2]}`))].filter(e => !e.includes('*'));

console.log(`\n6. Total Worker API Route Endpoints: ${workerEndpoints.length}`);

// 3. Match documented vs implemented
const openApiPaths = Object.keys(openApiSpec.paths);
let documentedCount = 0;
const missingInSpec = [];

for (const ep of workerEndpoints) {
  const [method, path] = ep.split(' ');
  // Convert /api/sites/:id -> /api/sites/{id}
  const openApiPath = path.replace(/:([a-zA-Z0-9_]+)/g, '{$1}');
  const specPathObj = openApiSpec.paths[openApiPath];
  if (specPathObj && specPathObj[method.toLowerCase()]) {
    documentedCount++;
  } else {
    missingInSpec.push(ep);
  }
}

console.log(`\n7. Documentation Coverage: ${documentedCount} / ${workerEndpoints.length} (${Math.round(documentedCount / workerEndpoints.length * 100)}%)`);

if (missingInSpec.length > 0) {
  console.log(`\n⚠️ Endpoints not yet documented in OpenAPI (${missingInSpec.length}):`);
  missingInSpec.forEach(e => console.log(' - ' + e));
} else {
  console.log('\n🎉 100% of Worker API Endpoints are fully documented in OpenAPI & Swagger!');
}
