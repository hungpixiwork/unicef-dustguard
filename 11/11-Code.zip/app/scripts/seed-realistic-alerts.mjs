import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('--- SEEDING REALISTIC ALERTS MATCHING MOCKUP 3 ---');

// Xóa cảnh báo cũ để nạp chuẩn xác
db.prepare('DELETE FROM alerts').run();

const now = new Date();

const sampleAlerts = [
  {
    id: 'alt-01',
    siteName: 'Chung cư Imperial Plaza',
    address: 'Thanh Xuân, Hà Nội',
    ward: 'Thanh Xuân',
    riskScore: 87,
    pm10: 198,
    pm25: 112,
    severity: 'CRITICAL',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Gần trường học', 'Quá 48h']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=200', 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200']),
    triggeredAt: new Date(now.getTime() - 2 * 3600 * 1000).toISOString(),
    slaHours: 24
  },
  {
    id: 'alt-02',
    siteName: 'Dự án Vinh Phú Riverside',
    address: 'Hà Đông, Hà Nội',
    ward: 'Hà Đông',
    riskScore: 74,
    pm10: 165,
    pm25: 88,
    severity: 'HIGH',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Quá 48h', 'Nhiều phản ánh']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=200', 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?w=200']),
    triggeredAt: new Date(now.getTime() - 4 * 3600 * 1000).toISOString(),
    slaHours: 48
  },
  {
    id: 'alt-03',
    siteName: 'Khu nhà ở Cầu Giấy',
    address: 'Cầu Giấy, Hà Nội',
    ward: 'Cầu Giấy',
    riskScore: 63,
    pm10: 142,
    pm25: 68,
    severity: 'MEDIUM',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Thiếu ảnh']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200']),
    triggeredAt: new Date(now.getTime() - 6 * 3600 * 1000).toISOString(),
    slaHours: 48
  },
  {
    id: 'alt-04',
    siteName: 'Dự án Sunshine Riverside',
    address: 'Long Biên, Hà Nội',
    ward: 'Long Biên',
    riskScore: 58,
    pm10: 128,
    pm25: 56,
    severity: 'MEDIUM',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Quá 48h']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=200']),
    triggeredAt: new Date(now.getTime() - 8 * 3600 * 1000).toISOString(),
    slaHours: 48
  },
  {
    id: 'alt-05',
    siteName: 'KĐT Nam 32',
    address: 'Hoài Đức, Hà Nội',
    ward: 'Hoài Đức',
    riskScore: 52,
    pm10: 115,
    pm25: 48,
    severity: 'MEDIUM',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Thiếu ảnh']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?w=200']),
    triggeredAt: new Date(now.getTime() - 12 * 3600 * 1000).toISOString(),
    slaHours: 48
  },
  {
    id: 'alt-06',
    siteName: 'Nhà máy gạch Hưng Thịnh',
    address: 'Đan Phượng, Hà Nội',
    ward: 'Đan Phượng',
    riskScore: 49,
    pm10: 95,
    pm25: 42,
    severity: 'LOW',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Thiếu ảnh']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=200']),
    triggeredAt: new Date(now.getTime() - 14 * 3600 * 1000).toISOString(),
    slaHours: 72
  },
  {
    id: 'alt-07',
    siteName: 'Dự án Cải tạo Thoát nước Đô thị',
    address: 'Hai Bà Trưng, Hà Nội',
    ward: 'Hai Bà Trưng',
    riskScore: 82,
    pm10: 185,
    pm25: 98,
    severity: 'CRITICAL',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Gần trường học', 'Quá 48h']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=200']),
    triggeredAt: new Date(now.getTime() - 16 * 3600 * 1000).toISOString(),
    slaHours: 24
  },
  {
    id: 'alt-08',
    siteName: 'Tổ hợp Thương mại Minh Khai',
    address: 'Minh Khai, Hai Bà Trưng, Hà Nội',
    ward: 'Hai Bà Trưng',
    riskScore: 78,
    pm10: 172,
    pm25: 84,
    severity: 'CRITICAL',
    status: 'PENDING',
    priorityReasons: JSON.stringify(['Vượt 2x QCVN']),
    evidenceUrls: JSON.stringify(['https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200']),
    triggeredAt: new Date(now.getTime() - 18 * 3600 * 1000).toISOString(),
    slaHours: 24
  }
];

const insertAlertStmt = db.prepare(`
  INSERT INTO alerts (
    id, siteId, sensorId, pm10Value, pm25Value, severity, title,
    triggeredAt, slaDeadline, status, priorityReasons, evidenceUrls,
    createdAt, updatedAt
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

for (const a of sampleAlerts) {
  // Tìm hoặc tạo Site
  let site = db.prepare('SELECT id FROM sites WHERE name = ? LIMIT 1').get(a.siteName);
  let siteId;
  if (!site) {
    siteId = `site-${a.id}`;
    db.prepare(`
      INSERT INTO sites (id, name, address, ward, dustRiskScore, riskLevel, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(siteId, a.siteName, a.address, a.ward, a.riskScore, a.riskScore > 75 ? 'HIGH' : 'MEDIUM', 'ACTIVE', now.toISOString(), now.toISOString());
  } else {
    siteId = site.id;
    db.prepare('UPDATE sites SET dustRiskScore = ? WHERE id = ?').run(a.riskScore, siteId);
  }

  // Tìm Sensor liên kết nếu có
  const sensor = db.prepare('SELECT id FROM sensors WHERE siteId = ? LIMIT 1').get(siteId);
  const sensorId = sensor ? sensor.id : null;

  const slaDeadline = new Date(new Date(a.triggeredAt).getTime() + a.slaHours * 3600 * 1000).toISOString();

  insertAlertStmt.run(
    a.id,
    siteId,
    sensorId,
    a.pm10,
    a.pm25,
    a.severity,
    `Cảnh báo nồng độ bụi tại ${a.siteName}`,
    a.triggeredAt,
    slaDeadline,
    a.status,
    a.priorityReasons,
    a.evidenceUrls,
    now.toISOString(),
    now.toISOString()
  );
}

// Thêm thêm một số alert Đã xử lý (RESOLVED) và Đã mở hồ sơ (IN_PROGRESS) để đủ số liệu KPI
for (let i = 1; i <= 14; i++) {
  const isResolved = i > 4;
  const dummyId = `alt-hist-${i}`;
  const firstSite = db.prepare('SELECT id FROM sites LIMIT 1').get();
  const siteId = firstSite ? firstSite.id : 'site-default';
  
  insertAlertStmt.run(
    dummyId,
    siteId,
    null,
    110,
    55,
    'MEDIUM',
    `Cảnh báo định kỳ xử lý thành công #${i}`,
    new Date(now.getTime() - (24 + i * 5) * 3600 * 1000).toISOString(),
    new Date(now.getTime() + 24 * 3600 * 1000).toISOString(),
    isResolved ? 'RESOLVED' : 'IN_PROGRESS',
    '[]',
    '[]',
    now.toISOString(),
    now.toISOString()
  );
}

const count = db.prepare('SELECT COUNT(*) as cnt FROM alerts').get();
console.log(`Successfully seeded ${count.cnt} realistic alerts into D1/SQLite dev.db!`);
