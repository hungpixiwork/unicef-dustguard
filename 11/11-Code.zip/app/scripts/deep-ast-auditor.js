import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parse } from '@babel/parser';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SRC_DIR = path.resolve(__dirname, '../src');

function getAllFiles(dir, exts = ['.js', '.jsx', '.ts', '.tsx']) {
  let files = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files = files.concat(getAllFiles(fullPath, exts));
    } else if (exts.includes(path.extname(entry.name))) {
      files.push(fullPath);
    }
  }
  return files;
}

function cleanImportPath(importSource) {
  return importSource.split('?')[0];
}

function resolveImportPath(sourceFile, importSource) {
  const cleanSource = cleanImportPath(importSource);
  if (!cleanSource.startsWith('.')) {
    return null;
  }
  const dir = path.dirname(sourceFile);
  const targetBase = path.resolve(dir, cleanSource);

  // Exact file
  if (fs.existsSync(targetBase) && fs.statSync(targetBase).isFile()) return targetBase;

  // Extensions
  const exts = ['.js', '.jsx', '.ts', '.tsx', '.json', '.css', '.svg', '.png', '.jpg', '.webp'];
  for (const ext of exts) {
    if (fs.existsSync(targetBase + ext) && fs.statSync(targetBase + ext).isFile()) {
      return targetBase + ext;
    }
  }

  // Index files
  for (const ext of exts) {
    const indexPath = path.join(targetBase, 'index' + ext);
    if (fs.existsSync(indexPath) && fs.statSync(indexPath).isFile()) {
      return indexPath;
    }
  }

  return 'MISSING:' + targetBase;
}

const allFiles = getAllFiles(SRC_DIR);
console.log(`Auditing ${allFiles.length} files in app/src...`);

const fileASTs = new Map();
const parseErrors = [];

for (const file of allFiles) {
  const code = fs.readFileSync(file, 'utf8');
  try {
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['jsx', 'typescript']
    });
    fileASTs.set(file, { ast, code });
  } catch (err) {
    parseErrors.push({ file, error: err.message });
  }
}

// Map each file to its declared exports and scope identifiers
const fileData = new Map();

for (const [file, { ast, code }] of fileASTs.entries()) {
  const declaredInScope = new Set();
  const directNamedExports = new Set();
  let directDefaultExport = false;
  const reExportedNamed = []; // { exportedName, importedName, source }
  const reExportedAll = []; // source
  const importSpecifiers = [];

  function addDeclaration(node) {
    if (!node) return;
    if (node.type === 'VariableDeclaration') {
      for (const decl of node.declarations) {
        if (decl.id.type === 'Identifier') {
          declaredInScope.add(decl.id.name);
        } else if (decl.id.type === 'ObjectPattern') {
          for (const prop of decl.id.properties) {
            if (prop.type === 'ObjectProperty' && prop.value.type === 'Identifier') {
              declaredInScope.add(prop.value.name);
            } else if (prop.type === 'RestElement' && prop.argument.type === 'Identifier') {
              declaredInScope.add(prop.argument.name);
            }
          }
        } else if (decl.id.type === 'ArrayPattern') {
          for (const elem of decl.id.elements) {
            if (elem && elem.type === 'Identifier') {
              declaredInScope.add(elem.name);
            }
          }
        }
      }
    } else if (node.id && node.id.name) {
      declaredInScope.add(node.id.name);
    }
  }

  for (const node of ast.program.body) {
    if (node.type === 'ImportDeclaration') {
      for (const spec of node.specifiers) {
        declaredInScope.add(spec.local.name);
        importSpecifiers.push({
          local: spec.local.name,
          imported: spec.imported ? spec.imported.name : (spec.type === 'ImportDefaultSpecifier' ? 'default' : '*'),
          source: node.source.value,
          loc: spec.loc ? spec.loc.start.line : 0
        });
      }
    } else if (
      node.type === 'VariableDeclaration' ||
      node.type === 'FunctionDeclaration' ||
      node.type === 'ClassDeclaration' ||
      node.type === 'TSEnumDeclaration' ||
      node.type === 'TSTypeAliasDeclaration' ||
      node.type === 'TSInterfaceDeclaration'
    ) {
      addDeclaration(node);
    } else if (node.type === 'ExportDefaultDeclaration') {
      directDefaultExport = true;
    } else if (node.type === 'ExportNamedDeclaration') {
      if (node.declaration) {
        addDeclaration(node.declaration);
        if (node.declaration.type === 'VariableDeclaration') {
          for (const decl of node.declaration.declarations) {
            if (decl.id.type === 'Identifier') {
              directNamedExports.add(decl.id.name);
            }
          }
        } else if (node.declaration.id) {
          directNamedExports.add(node.declaration.id.name);
        }
      }
      if (node.source) {
        for (const spec of node.specifiers) {
          reExportedNamed.push({
            exportedName: spec.exported.name,
            importedName: spec.local ? spec.local.name : spec.exported.name,
            source: node.source.value,
            loc: spec.loc ? spec.loc.start.line : 0
          });
        }
      } else if (node.specifiers) {
        for (const spec of node.specifiers) {
          if (spec.exported.name === 'default') {
            directDefaultExport = true;
          } else {
            directNamedExports.add(spec.exported.name);
          }
        }
      }
    } else if (node.type === 'ExportAllDeclaration') {
      reExportedAll.push(node.source.value);
    }
  }

  fileData.set(file, {
    ast,
    code,
    declaredInScope,
    directNamedExports,
    directDefaultExport,
    reExportedNamed,
    reExportedAll,
    importSpecifiers
  });
}

// Resolver for named and default exports following re-export chains
function hasExport(filePath, exportName, visited = new Set()) {
  const visitKey = `${filePath}:${exportName}`;
  if (visited.has(visitKey)) return false;
  visited.add(visitKey);

  const data = fileData.get(filePath);
  if (!data) return true; // External module

  if (exportName === 'default') {
    if (data.directDefaultExport) return true;
    for (const re of data.reExportedNamed) {
      if (re.exportedName === 'default') {
        const target = resolveImportPath(filePath, re.source);
        if (target && !target.startsWith('MISSING:')) {
          if (hasExport(target, re.importedName, visited)) return true;
        }
      }
    }
    return false;
  }

  if (data.directNamedExports.has(exportName)) return true;

  for (const re of data.reExportedNamed) {
    if (re.exportedName === exportName) {
      const target = resolveImportPath(filePath, re.source);
      if (target && !target.startsWith('MISSING:')) {
        if (hasExport(target, re.importedName, visited)) return true;
      }
    }
  }

  for (const star of data.reExportedAll) {
    const target = resolveImportPath(filePath, star);
    if (target && !target.startsWith('MISSING:')) {
      if (hasExport(target, exportName, visited)) return true;
    }
  }

  return false;
}

// 1. Audit TDZ & Scope Reference Errors on Export Default / Export Named
const scopeIssues = [];
const missingImports = [];
const namedExportMismatches = [];

for (const [file, data] of fileData.entries()) {
  const relPath = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  const lines = data.code.split('\n');

  for (const node of data.ast.program.body) {
    if (node.type === 'ExportDefaultDeclaration') {
      if (node.declaration.type === 'Identifier') {
        const idName = node.declaration.name;
        if (!data.declaredInScope.has(idName)) {
          scopeIssues.push({
            file,
            relPath,
            line: node.loc ? node.loc.start.line : 0,
            identifier: idName,
            type: 'UNDEFINED_EXPORT_DEFAULT',
            code: lines[node.loc ? node.loc.start.line - 1 : 0]?.trim()
          });
        }
      }
    } else if (node.type === 'ExportNamedDeclaration' && !node.source && node.specifiers) {
      for (const spec of node.specifiers) {
        if (!data.declaredInScope.has(spec.local.name)) {
          scopeIssues.push({
            file,
            relPath,
            line: spec.loc ? spec.loc.start.line : 0,
            identifier: spec.local.name,
            type: 'UNDEFINED_NAMED_EXPORT',
            code: lines[spec.loc ? spec.loc.start.line - 1 : 0]?.trim()
          });
        }
      }
    }
  }

  // Check imports
  for (const imp of data.importSpecifiers) {
    if (!imp.source.startsWith('.')) continue;
    const resolved = resolveImportPath(file, imp.source);
    if (!resolved || resolved.startsWith('MISSING:')) {
      missingImports.push({
        file,
        relPath,
        line: imp.loc,
        importSource: imp.source,
        resolved,
        specifier: imp.imported
      });
      continue;
    }

    if (imp.imported !== '*') {
      const exists = hasExport(resolved, imp.imported);
      if (!exists) {
        namedExportMismatches.push({
          file,
          relPath,
          line: imp.loc,
          importSource: imp.source,
          targetFile: path.relative(SRC_DIR, resolved).replace(/\\/g, '/'),
          importedSymbol: imp.imported,
          error: `Importing '${imp.imported}' from '${imp.source}', but target does NOT export '${imp.imported}'!`
        });
      }
    }
  }

  // Check re-exports from barrel files
  for (const re of data.reExportedNamed) {
    if (!re.source.startsWith('.')) continue;
    const resolved = resolveImportPath(file, re.source);
    if (!resolved || resolved.startsWith('MISSING:')) {
      missingImports.push({
        file,
        relPath,
        line: re.loc,
        importSource: re.source,
        resolved,
        specifier: re.importedName
      });
      continue;
    }
    const exists = hasExport(resolved, re.importedName);
    if (!exists) {
      namedExportMismatches.push({
        file,
        relPath,
        line: re.loc,
        importSource: re.source,
        targetFile: path.relative(SRC_DIR, resolved).replace(/\\/g, '/'),
        importedSymbol: re.importedName,
        error: `Re-exporting '${re.importedName}' as '${re.exportedName}' from '${re.source}', but target does NOT export '${re.importedName}'!`
      });
    }
  }
}

// 2. Check App.jsx Routes & Lazy Components
const appFile = path.join(SRC_DIR, 'App.jsx');
const appContent = fs.readFileSync(appFile, 'utf8');
const lazyRegex = /const\s+([A-Za-z0-9_$]+)\s*=\s*lazy\(\s*\(\)\s*=>\s*import\(['"]([^'"]+)['"]\)\s*\);?/g;
let lazyMatch;
const lazyImports = [];
const lazyErrors = [];

while ((lazyMatch = lazyRegex.exec(appContent)) !== null) {
  const compName = lazyMatch[1];
  const importPath = lazyMatch[2];
  const resolved = resolveImportPath(appFile, importPath);
  
  if (!resolved || resolved.startsWith('MISSING:')) {
    lazyErrors.push({
      component: compName,
      importPath,
      error: `Target file missing: ${resolved}`
    });
  } else {
    const hasDef = hasExport(resolved, 'default');
    if (!hasDef) {
      lazyErrors.push({
        component: compName,
        importPath,
        targetFile: path.relative(SRC_DIR, resolved).replace(/\\/g, '/'),
        error: `Lazy component ${compName} imported from '${importPath}' has NO export default!`
      });
    }
  }
  lazyImports.push({ compName, importPath, resolved });
}

// Route paths in App.jsx
const routeRegex = /<Route\s+[^>]*path=["']([^"']+)["'][^>]*element=\{<([A-Za-z0-9_$]+)[^>]*\/>\}/g;
let routeMatch;
const routes = [];
while ((routeMatch = routeRegex.exec(appContent)) !== null) {
  routes.push({
    path: routeMatch[1],
    element: routeMatch[2]
  });
}

console.log(`\n================ AUDIT RESULTS ================`);
console.log(`\n1. Undefined Export / TDZ Issues: ${scopeIssues.length}`);
scopeIssues.forEach(s => console.log(`  - [${s.type}] ${s.relPath}:${s.line} (${s.identifier}) -> ${s.code}`));

console.log(`\n2. Missing Relative Import Files: ${missingImports.length}`);
missingImports.forEach(m => console.log(`  - ${m.relPath}:${m.line} -> ${m.importSource} (${m.resolved})`));

console.log(`\n3. Export / Import Symbol Mismatches: ${namedExportMismatches.length}`);
namedExportMismatches.forEach(e => console.log(`  - ${e.relPath}:${e.line} -> ${e.error}`));

console.log(`\n4. App.jsx Lazy Routes (Total: ${lazyImports.length}, Routes checked: ${routes.length}, Errors: ${lazyErrors.length})`);
lazyErrors.forEach(l => console.log(`  - ${l.component}: ${l.error}`));

