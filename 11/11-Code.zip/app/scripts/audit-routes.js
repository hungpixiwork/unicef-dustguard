import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SRC_DIR = path.resolve(__dirname, '../src');

const appFile = path.join(SRC_DIR, 'App.jsx');
const content = fs.readFileSync(appFile, 'utf8');

// Match all lazy imports
const lazyRegex = /const\s+([A-Za-z0-9_$]+)\s*=\s*lazy\(\s*\(\)\s*=>\s*import\(['"]([^'"]+)['"]\)\s*\);/g;
const lazyMap = new Map();
let m;
while ((m = lazyRegex.exec(content)) !== null) {
  lazyMap.set(m[1], m[2]);
}

console.log(`Found ${lazyMap.size} lazy loaded components in App.jsx:`);

// Match all static imports
const staticImports = new Map();
const importRegex = /import\s+(?:([A-Za-z0-9_$]+)|\{([^}]+)\})\s+from\s+['"]([^'"]+)['"]/g;
while ((m = importRegex.exec(content)) !== null) {
  if (m[1]) staticImports.set(m[1], m[3]);
  if (m[2]) {
    m[2].split(',').forEach(s => {
      const parts = s.trim().split(/\s+as\s+/);
      staticImports.set(parts[parts.length - 1].trim(), m[3]);
    });
  }
}

// Find all Route tags
const routeRegex = /<Route\s+([^>]+)>/g;
const allRoutes = [];
let routeMatch;
while ((routeMatch = routeRegex.exec(content)) !== null) {
  const attrs = routeMatch[1];
  const pathMatch = attrs.match(/path=["']([^"']+)["']/);
  const elementMatch = attrs.match(/element=\{<([A-Za-z0-9_$]+)/);
  const indexMatch = attrs.includes('index');
  
  allRoutes.push({
    raw: routeMatch[0],
    path: pathMatch ? pathMatch[1] : (indexMatch ? '(index)' : '(layout wrapper)'),
    element: elementMatch ? elementMatch[1] : null
  });
}

console.log(`\nTotal <Route> tags in App.jsx: ${allRoutes.length}`);

// Verify every component used in routes
const errors = [];
allRoutes.forEach((r, idx) => {
  if (!r.element) return;
  if (r.element === 'Navigate' || r.element === 'ProtectedRoute') return;
  
  const lazyPath = lazyMap.get(r.element);
  const staticPath = staticImports.get(r.element);
  
  if (!lazyPath && !staticPath) {
    errors.push(`Route #${idx+1} (${r.path}): Component <${r.element} /> is neither lazy imported nor statically imported in App.jsx!`);
    return;
  }

  const importPath = lazyPath || staticPath;
  const dir = path.dirname(appFile);
  const targetBase = path.resolve(dir, importPath);
  
  const exts = ['', '.js', '.jsx', '.ts', '.tsx', '/index.js', '/index.jsx', '/index.ts', '/index.tsx'];
  let foundPath = null;
  for (const ext of exts) {
    const p = targetBase + ext;
    if (fs.existsSync(p) && fs.statSync(p).isFile()) {
      foundPath = p;
      break;
    }
  }

  if (!foundPath) {
    errors.push(`Route #${idx+1} (${r.path}): Component <${r.element} /> target file missing: ${targetBase}`);
  } else {
    // Check if target file has export default (since lazy requires export default)
    if (lazyPath) {
      const fileCode = fs.readFileSync(foundPath, 'utf8');
      const hasExportDefault = /export\s+default\s+/m.test(fileCode) || /export\s*\{\s*[^}]*\bdefault\b/m.test(fileCode);
      if (!hasExportDefault) {
        errors.push(`Route #${idx+1} (${r.path}): Component <${r.element} /> in ${path.relative(SRC_DIR, foundPath)} lacks \`export default\`!`);
      }
    }
  }
});

console.log(`\nRoute Audit Results:`);
console.log(`- Total routes scanned: ${allRoutes.length}`);
console.log(`- Total route issues: ${errors.length}`);
if (errors.length > 0) {
  errors.forEach(e => console.log('  ERROR: ' + e));
} else {
  console.log(`All 124 routes and layouts have verified components and export default!`);
}
