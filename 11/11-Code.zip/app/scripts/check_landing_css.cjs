const fs = require('fs');
const path = require('path');

const baseDir = path.resolve(__dirname, '..');
const jsxDir = path.join(baseDir, 'src', 'components', 'landing');
const cssFile = path.join(baseDir, 'src', 'components', 'landing', 'landing.css');
const landingPageJsx = path.join(baseDir, 'src', 'modules', 'public', 'LandingPage.jsx');

const cssContent = fs.readFileSync(cssFile, 'utf8');

const jsxFiles = fs.readdirSync(jsxDir).filter(f => f.endsWith('.jsx')).map(f => path.join(jsxDir, f));
jsxFiles.push(landingPageJsx);

const classNames = new Set();

jsxFiles.forEach(filePath => {
  const content = fs.readFileSync(filePath, 'utf8');
  // find all className="..." or className={`...`}
  const regex = /className=["'`]([^"'`]+)["'`]/g;
  let match;
  while ((match = regex.exec(content)) !== null) {
    const raw = match[1];
    // extract tokens
    const tokens = raw.split(/\s+/);
    tokens.forEach(t => {
      // remove ternary expressions or template interpolation
      const cleaned = t.replace(/[^a-zA-Z0-9_-]/g, '').trim();
      if (cleaned && !['true', 'false', 'null', 'undefined', 'lang', 'en', 'vi', 'open', 'active', 'show'].includes(cleaned)) {
        classNames.add(cleaned);
      }
    });
  }
});

console.log('Total unique classes in JSX:', classNames.size);
const missing = [];
classNames.forEach(cls => {
  if (!cssContent.includes('.' + cls)) {
    missing.push(cls);
  }
});
console.log('Missing classes in landing.css:', missing);
