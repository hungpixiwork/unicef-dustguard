import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve(process.cwd(), 'app/prisma/dev.db');
const db = new Database(dbPath);
db.pragma('foreign_keys = OFF');

console.log('--- SEEDING CANONICAL MOCKUP DATA TO D1/SQLITE (dev.db) ---');

// 1. Seed Sites (Mockup 4 & 5)
const sites = [
  {
    id: 'site-holac-01',
    code: 'CT-25-0010',
    name: 'Trạm nghiền đá Hòa Lạc',
    address: 'Xã Hòa Lạc, Thạch Thất, Hà Nội',
    ward: 'Xã Hòa Lạc, Hà Nội',
    dustRiskScore: 91,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    managerName: 'Lê Văn Cường',
    managerPhone: '0912 345 678',
    contractorName: 'Công ty CP Khai khoáng Hòa Lạc',
    lat: 21.0125,
    lng: 105.5284
  },
  {
    id: 'site-vd4-02',
    code: 'CT-25-0012',
    name: 'Dự án Vành đai 4 (Hà Nội)',
    address: 'Xã Thanh Liệt, Thanh Trì, Hà Nội',
    ward: 'Xã Thanh Liệt, Hà Nội',
    dustRiskScore: 87,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    managerName: 'Nguyễn Văn Nam',
    managerPhone: '0901 234 567',
    contractorName: 'Công ty CP Xây dựng An Phát',
    lat: 20.9745,
    lng: 105.8123
  },
  {
    id: 'site-hadong-03',
    code: 'CT-25-0009',
    name: 'Site B - Hà Đông',
    address: 'Phường Hà Đông, Hà Đông, Hà Nội',
    ward: 'Phường Hà Đông, Hà Nội',
    dustRiskScore: 74,
    riskLevel: 'HIGH',
    status: 'ACTIVE',
    managerName: 'Trần Thị Lan',
    managerPhone: '0934 567 890',
    contractorName: 'Tổng công ty Xây dựng Hà Nội',
    lat: 20.9634,
    lng: 105.7721
  },
  {
    id: 'site-caugiay-04',
    code: 'CT-25-0008',
    name: 'Site C - Cầu Giấy',
    address: 'Phường Dịch Vọng, Cầu Giấy, Hà Nội',
    ward: 'Phường Dịch Vọng, Hà Nội',
    dustRiskScore: 63,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    managerName: 'Lê Hoàng Nam',
    managerPhone: '0978 123 456',
    contractorName: 'Công ty Xây lắp HUD 3',
    lat: 21.0345,
    lng: 105.7923
  },
  {
    id: 'site-hoangmai-05',
    code: 'CT-25-0005',
    name: 'Site D - Hoàng Mai',
    address: 'Phường Hoàng Liệt, Hoàng Mai, Hà Nội',
    ward: 'Phường Hoàng Liệt, Hà Nội',
    dustRiskScore: 58,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    managerName: 'Phạm Minh Đức',
    managerPhone: '0945 678 901',
    contractorName: 'Công ty CP Vinaconex 2',
    lat: 20.9654,
    lng: 105.8432
  },
  {
    id: 'site-longbien-06',
    code: 'CT-25-0003',
    name: 'Site E - Long Biên',
    address: 'Phường Bồ Đề, Long Biên, Hà Nội',
    ward: 'Phường Bồ Đề, Hà Nội',
    dustRiskScore: 42,
    riskLevel: 'MEDIUM',
    status: 'ACTIVE',
    managerName: 'Vũ Thị Hằng',
    managerPhone: '0989 012 345',
    contractorName: 'Công ty CP Him Lam',
    lat: 21.0387,
    lng: 105.8765
  },
  {
    id: 'site-dongda-07',
    code: 'CT-25-0002',
    name: 'Site F - Đống Đa',
    address: 'Phường Láng Hạ, Đống Đa, Hà Nội',
    ward: 'Phường Láng Hạ, Hà Nội',
    dustRiskScore: 32,
    riskLevel: 'LOW',
    status: 'ACTIVE',
    managerName: 'Đặng Tuấn Tú',
    managerPhone: '0903 456 789',
    contractorName: 'Công ty CP Sông Đà 9',
    lat: 21.0189,
    lng: 105.8156
  }
];

const insertSite = db.prepare(`
  INSERT OR REPLACE INTO sites (id, code, name, address, ward, dustRiskScore, riskLevel, status, managerName, managerPhone, contractorName, coordinates, createdAt, updatedAt)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
`);

for (const s of sites) {
  insertSite.run(s.id, s.code, s.name, s.address, s.ward, s.dustRiskScore, s.riskLevel, s.status, s.managerName, s.managerPhone, s.contractorName, JSON.stringify({ lat: s.lat, lng: s.lng }));
}
console.log(`✓ Seeded ${sites.length} sites successfully.`);

// 2. Seed Tasks (Mockup 8)
const tasks = [
  {
    id: 'task-01',
    title: 'Kiểm tra định kỳ công trình',
    description: 'Quan trắc bụi - Đợt 5/2025 tại Site A Thanh Xuân',
    task_type: 'field_verification',
    site_id: 'site-vd4-02',
    case_id: 'case-01',
    status: 'TODO',
    priority: 'HIGH',
    due_at: '2025-05-20 16:00:00',
    assigned_profile_id: 'Nguyễn Minh An'
  },
  {
    id: 'task-02',
    title: 'Xử lý cảnh báo bụi cao',
    description: 'Kiểm tra bạt che chắn và nồng độ PM10 vượt ngưỡng tại Site B Hà Đông',
    task_type: 'inspection',
    site_id: 'site-hadong-03',
    case_id: 'case-02',
    status: 'IN_PROGRESS',
    priority: 'HIGH',
    due_at: '2025-05-21 10:30:00',
    assigned_profile_id: 'Trần Thị Lan'
  },
  {
    id: 'task-03',
    title: 'Đánh giá biện pháp giảm bụi',
    description: 'Khảo sát hiện trường theo phản ánh cộng đồng tại Phường Dịch Vọng',
    task_type: 'survey',
    site_id: 'site-caugiay-04',
    case_id: 'case-03',
    status: 'IN_PROGRESS',
    priority: 'MEDIUM',
    due_at: '2025-05-22 14:00:00',
    assigned_profile_id: 'Lê Hoàng Nam'
  },
  {
    id: 'task-04',
    title: 'Báo cáo tuần',
    description: 'Tổng hợp kết quả quan trắc 4 tuần và gửi Ban Lãnh đạo',
    task_type: 'reporting',
    site_id: 'site-vd4-02',
    case_id: 'case-04',
    status: 'TODO',
    priority: 'MEDIUM',
    due_at: '2025-05-22 17:00:00',
    assigned_profile_id: 'Phạm Quỳnh Chi'
  },
  {
    id: 'task-05',
    title: 'Kiểm tra đột xuất',
    description: 'Kiểm tra xe chở vật liệu xây dựng không rửa bánh tại Cầu Giấy',
    task_type: 'field_verification',
    site_id: 'site-caugiay-04',
    case_id: 'case-05',
    status: 'TODO',
    priority: 'HIGH',
    due_at: '2025-05-23 09:00:00',
    assigned_profile_id: 'Nguyễn Minh An'
  },
  {
    id: 'task-06',
    title: 'Theo dõi sau xử lý',
    description: 'Kiểm tra kết quả phun nước dập bụi tại Site E Long Biên',
    task_type: 'verification',
    site_id: 'site-longbien-06',
    case_id: 'case-06',
    status: 'COMPLETED',
    priority: 'LOW',
    due_at: '2025-05-24 16:00:00',
    assigned_profile_id: 'Trần Thị Lan'
  },
  {
    id: 'task-07',
    title: 'Cập nhật hồ sơ công trình',
    description: 'Bổ sung tài liệu kiểm định trạm quan trắc tự động tại Site D Hoàng Mai',
    task_type: 'documentation',
    site_id: 'site-hoangmai-05',
    case_id: 'case-07',
    status: 'COMPLETED',
    priority: 'LOW',
    due_at: '2025-05-25 11:00:00',
    assigned_profile_id: 'Lê Hoàng Nam'
  }
];

const insertTask = db.prepare(`
  INSERT OR REPLACE INTO tasks (id, title, description, task_type, site_id, case_id, status, priority, due_at, assigned_profile_id, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
`);

for (const t of tasks) {
  insertTask.run(t.id, t.title, t.description, t.task_type, t.site_id, t.case_id, t.status, t.priority, t.due_at, t.assigned_profile_id);
}
console.log(`✓ Seeded ${tasks.length} tasks successfully.`);

// 3. Seed Reports (Mockup 9)
const reports = [
  {
    id: 'rep-01',
    name: 'Báo cáo tổng hợp tuần 23/2025',
    report_type: 'WEEKLY_SUMMARY',
    project_id: 'ALL',
    status: 'ready',
    created_by: 'Nguyễn Văn Nam',
    created_at: '2025-05-20 08:30:00'
  },
  {
    id: 'rep-02',
    name: 'Báo cáo các vụ việc quá hạn xử lý',
    report_type: 'OVERDUE_CASES',
    project_id: 'ALL',
    status: 'ready',
    created_by: 'Trần Thị Lan',
    created_at: '2025-05-19 15:20:00'
  },
  {
    id: 'rep-03',
    name: 'Báo cáo chuyên đề: Dự án Vành đai 4',
    report_type: 'SITE_SPECIFIC',
    project_id: 'site-vd4-02',
    status: 'ready',
    created_by: 'Lê Hoàng Nam',
    created_at: '2025-05-18 11:00:00'
  },
  {
    id: 'rep-04',
    name: 'Báo cáo chất lượng không khí Quận Cầu Giấy',
    report_type: 'DISTRICT_AIR_QUALITY',
    project_id: 'DISTRICT_CAUGIAY',
    status: 'ready',
    created_by: 'Phạm Quỳnh Chi',
    created_at: '2025-05-17 09:45:00'
  }
];

const insertReport = db.prepare(`
  INSERT OR REPLACE INTO reports (id, name, report_type, project_id, status, created_by, created_at)
  VALUES (?, ?, ?, ?, ?, ?, ?)
`);

for (const r of reports) {
  insertReport.run(r.id, r.name, r.report_type, r.project_id, r.status, r.created_by, r.created_at);
}
console.log(`✓ Seeded ${reports.length} reports successfully.`);

// 4. Seed Notifications (Mockup 10)
const notifications = [
  {
    id: 'notif-01',
    user_id: 'staff-user-01',
    type: 'ALERT',
    title: 'Cảnh báo nồng độ bụi PM10 vượt ngưỡng',
    message: 'Trạm 02 tại Site C Cầu Giấy ghi nhận PM10 = 168 µg/m³ (vượt 68% quy chuẩn QCVN 05:2023).',
    entity_type: 'site',
    entity_id: 'site-caugiay-04',
    priority: 'urgent',
    is_read: 0,
    is_muted: 0,
    created_at: '2025-05-20 10:15:00'
  },
  {
    id: 'notif-02',
    user_id: 'staff-user-01',
    type: 'CASE_DEADLINE',
    title: 'Hồ sơ HS-25-00081 sắp đến hạn xử lý SLA',
    message: 'Còn 1 ngày để hoàn tất biên bản kiểm tra thực địa tại Dự án Vành đai 4.',
    entity_type: 'case',
    entity_id: 'case-01',
    priority: 'urgent',
    is_read: 0,
    is_muted: 0,
    created_at: '2025-05-20 09:00:00'
  },
  {
    id: 'notif-03',
    user_id: 'staff-user-01',
    type: 'CONTRACTOR_EVIDENCE',
    title: 'Nhà thầu đã nộp ảnh chứng minh khắc phục',
    message: 'Công ty An Phát đã tải lên 3 ảnh bạt che chắn và xe bồn phun nước tại Site A.',
    entity_type: 'case',
    entity_id: 'case-01',
    priority: 'normal',
    is_read: 0,
    is_muted: 0,
    created_at: '2025-05-20 08:30:00'
  },
  {
    id: 'notif-04',
    user_id: 'staff-user-01',
    type: 'REPORT_READY',
    title: 'Báo cáo tổng hợp tuần 23 đã sẵn sàng',
    message: 'Hệ thống đã tự động xuất báo cáo tuần với 128 hồ sơ và tỷ lệ đúng hạn 89%.',
    entity_type: 'report',
    entity_id: 'rep-01',
    priority: 'normal',
    is_read: 0,
    is_muted: 0,
    created_at: '2025-05-20 08:00:00'
  },
  {
    id: 'notif-05',
    user_id: 'staff-user-01',
    type: 'SYSTEM',
    title: 'Nhiệm vụ mới được phân công',
    message: 'Lãnh đạo đã phân công bạn thực hiện kiểm tra đột xuất tại khu vực Cầu Giấy.',
    entity_type: 'task',
    entity_id: 'task-05',
    priority: 'normal',
    is_read: 1,
    is_muted: 0,
    created_at: '2025-05-19 16:45:00'
  }
];

const insertNotif = db.prepare(`
  INSERT OR REPLACE INTO notifications (id, user_id, type, title, message, entity_type, entity_id, priority, is_read, is_muted, created_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

for (const n of notifications) {
  insertNotif.run(n.id, n.user_id, n.type, n.title, n.message, n.entity_type, n.entity_id, n.priority, n.is_read, n.is_muted, n.created_at);
}
console.log(`✓ Seeded ${notifications.length} notifications successfully.`);

console.log('--- CANONICAL MOCKUP SEED FINISHED SUCCESSFULLY! ---');
