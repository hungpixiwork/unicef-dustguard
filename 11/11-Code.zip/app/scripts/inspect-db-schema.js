import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, '../prisma/dev.db');

const db = new Database(dbPath);

const tables = ['sites', 'cases', 'complaints', 'inspections', 'actions', 'sensors', 'sensor_readings', 'alerts', 'draft_documents', 'document_revisions'];

for (const t of tables) {
  console.log(`\n=== Table: ${t} ===`);
  const cols = db.prepare(`PRAGMA table_info("${t}")`).all();
  console.log(cols.map(c => `${c.name} (${c.type}) ${c.notnull ? 'NOT NULL' : 'NULL'} ${c.pk ? 'PK' : ''}`).join(', '));
  
  const indexes = db.prepare(`PRAGMA index_list("${t}")`).all();
  for (const idx of indexes) {
    const idxCols = db.prepare(`PRAGMA index_info("${idx.name}")`).all();
    console.log(`  Index ${idx.name} (unique: ${idx.unique}): ${idxCols.map(c => c.name).join(', ')}`);
  }

  const fks = db.prepare(`PRAGMA foreign_key_list("${t}")`).all();
  for (const fk of fks) {
    console.log(`  FK -> ${fk.table}(${fk.to}) from ${fk.from}`);
  }

  // Print 1 sample row
  const sample = db.prepare(`SELECT * FROM "${t}" LIMIT 1`).get();
  if (sample) {
    console.log('  Sample row:', JSON.stringify(sample, null, 2));
  } else {
    console.log('  (Table is empty)');
  }
}

db.close();
