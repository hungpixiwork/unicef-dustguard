/**
 * DustGuard VN - Level 2 Verification: verify:domain
 * Runs tests for a specific functional domain.
 */

import { TEST_GROUPS } from './test-groups.js';
import { executeTestPipeline } from './verification-runner.js';

async function main() {
  const args = process.argv.slice(2).filter(a => !a.startsWith('-'));
  const domain = args[0]?.toLowerCase();

  const availableDomains = Object.keys(TEST_GROUPS);

  if (!domain || !TEST_GROUPS[domain]) {
    console.log('========================================================');
    console.log('🎯 DUSTGUARD DOMAIN VERIFICATION');
    console.log('========================================================');
    console.log('Usage: npm run verify:domain -- <domain-name>\n');
    console.log('Available domains:');
    availableDomains.forEach(d => {
      const count = TEST_GROUPS[d].length;
      console.log(`  • ${d.padEnd(16)} (${count} tests)`);
    });
    console.log('\nExample: npm run verify:domain -- observations');
    console.log('========================================================');
    process.exit(1);
  }

  const files = TEST_GROUPS[domain];
  const res = await executeTestPipeline(files, {
    title: `DOMAIN VERIFICATION: ${domain.toUpperCase()}`
  });

  process.exit(res.success ? 0 : 1);
}

main().catch(err => {
  console.error('Fatal in verify-domain:', err);
  process.exit(1);
});
