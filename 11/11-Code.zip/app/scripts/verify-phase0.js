import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

console.log('🔍 [Phase 0 Verification] Checking Engineering OS Integrity...\n');

let failed = false;

function checkFile(filePath, desc, maxLines = null) {
  if (!fs.existsSync(filePath)) {
    console.error(`❌ [FAIL] Missing file: ${filePath} (${desc})`);
    failed = true;
    return false;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n').length;
  if (maxLines && lines > maxLines) {
    console.warn(`⚠️ [WARN] ${filePath} has ${lines} lines (recommended <= ${maxLines})`);
  }
  console.log(`✅ [PASS] Found ${filePath} (${lines} lines) — ${desc}`);
  return true;
}

function checkDir(dirPath, desc) {
  if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
    console.error(`❌ [FAIL] Missing directory: ${dirPath} (${desc})`);
    failed = true;
    return false;
  }
  console.log(`✅ [PASS] Found directory ${dirPath} — ${desc}`);
  return true;
}

// 1. Root & Architecture
checkFile('AGENTS.md', 'Operational Contract SSOT', 200);
checkFile('ARCHITECTURE.md', 'System Architecture SSOT');
checkFile('README.md', 'Human Onboarding Guide');

// 2. .agent Operational Memory
checkDir('.agent', 'Operational Memory Control Plane');
checkFile('.agent/README.md', 'Operational Memory Guide');
checkFile('.agent/CURRENT_STATE.md', 'Active Health & Baseline');
checkFile('.agent/NEXT_ACTIONS.md', 'Prioritized Action Plan');
checkFile('.agent/LESSONS.md', 'Root Cause & Lessons Log');
checkFile('.agent/DECISIONS.md', 'Architecture Decisions Record');
checkFile('.agent/KNOWN_ISSUES.md', 'Known Issues Registry');
checkFile('.agent/CLAIMS.md', 'Technical Claim Registry');
checkFile('.agent/SESSION_LOG.md', 'Session & Checkpoint Ledger');
checkFile('.agent/QUALITY_GATES.md', 'Quality & Accessibility Gates');
checkFile('.agent/UI_AUDIT.md', 'Presentation Audit Log');

// 3. .agent skills
checkDir('.agent/skills', 'Operational Skills');
const skills = [
  'cloudflare-d1-debugging.md',
  'r2-evidence-verification.md',
  'browser-ui-audit.md',
  'api-reality-check.md',
  'claim-verification.md',
  'dustguard-workflow-debugging.md'
];
skills.forEach(s => checkFile(path.join('.agent/skills', s), `Skill: ${s}`));

// 4. Memory Bank
checkDir('memory-bank', 'Long-term Memory Bank');
const memoryBankFiles = [
  'projectbrief.md',
  'productContext.md',
  'systemPatterns.md',
  'techContext.md',
  'activeContext.md',
  'progress.md',
  'glossary.md'
];
memoryBankFiles.forEach(m => checkFile(path.join('memory-bank', m), `Memory Bank: ${m}`));

// 5. Evidence
checkFile('docs/evidence/EVIDENCE_INDEX.md', 'Evidence Index SSOT');
const evidenceDirs = ['runtime', 'ui', 'api', 'database', 'tests', 'performance', 'claims'];
evidenceDirs.forEach(ed => checkDir(path.join('evidence', ed), `Evidence directory: ${ed}`));

if (failed) {
  console.error('\n❌ Phase 0 Verification FAILED! Some required files/directories are missing.');
  process.exit(1);
} else {
  console.log('\n🎉 ALL Phase 0 Engineering OS checks passed successfully!');
}
