import { Client } from 'ssh2';

const conn = new Client();
conn.on('ready', () => {
  console.log('SSH Connection to Ubuntu VPS ready!');
  const commands = [
    'echo "=== GIT & GH ==="',
    'git --version 2>&1 || echo "git not found"',
    'gh --version 2>&1 || echo "gh not found"',
    'cat /root/gh_token.txt 2>/dev/null || echo "gh_token.txt not found"'
  ].join('\n');

  conn.exec(commands, (err, stream) => {
    if (err) {
      console.error('Error executing commands:', err);
      conn.end();
      return;
    }
    let output = '';
    let errorOutput = '';
    stream.on('close', (code, signal) => {
      console.log(`Command closed with code ${code}`);
      if (output) console.log('STDOUT:\n', output);
      if (errorOutput) console.error('STDERR:\n', errorOutput);
      conn.end();
    }).on('data', (data) => {
      output += data.toString();
    }).stderr.on('data', (data) => {
      errorOutput += data.toString();
    });
  });
}).on('error', (err) => {
  console.error('SSH Connection error:', err);
}).connect({
  host: '103.173.226.37',
  port: 22,
  username: 'root',
  password: 'a0NS1Y*Z1CrX1'
});
