import Database from 'better-sqlite3';
import { readFileSync } from 'fs';

const db = new Database('prisma/dev.db');
const schemaSql = readFileSync('prisma/d1-schema.sql', 'utf-8');

console.log('⚡ Applying missing tables and indexes to prisma/dev.db...');

// Split statements by semicolon
const statements = schemaSql
  .split(';')
  .map(s => s.trim())
  .filter(s => s.length > 0);

let appliedCount = 0;
let skippedCount = 0;

for (const stmt of statements) {
  try {
    db.exec(stmt + ';');
    appliedCount++;
  } catch (err) {
    if (err.message.includes('already exists')) {
      skippedCount++;
    } else {
      console.warn('⚠️ Warning executing statement:', err.message);
    }
  }
}

const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE '_prisma_%' AND name NOT LIKE 'sqlite_%' ORDER BY name").all();
console.log(`✅ prisma/dev.db synchronized! Total tables now: ${tables.length} (Applied: ${appliedCount}, Skipped existing: ${skippedCount})`);
console.log('Integrity check:', db.pragma('integrity_check', { simple: true }));
console.log('Foreign key check errors:', db.pragma('foreign_key_check').length);
