import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const srcDir = path.resolve(__dirname, '../src');

console.log('🔍 Starting Deep Static & Dependency Audit on:', srcDir);

// 1. Collect all JS/JSX/TS/TSX files
function getFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      getFiles(filePath, fileList);
    } else if (/\.(jsx?|tsx?)$/.test(file)) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

const allFiles = getFiles(srcDir);
console.log(`Found ${allFiles.length} source files.`);

// 2. Parse imports and exports for each file
const fileData = new Map();

for (const file of allFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const relPath = path.relative(srcDir, file).replace(/\\/g, '/');
  
  const imports = [];
  const namedExports = new Set();
  let hasDefaultExport = false;
  
  // Extract imports
  const importRegex = /import\s+(?:([\w*\s{},]+)\s+from\s+)?['"]([^'"]+)['"]/g;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const importClause = match[1] || '';
    const importSource = match[2];
    imports.push({ clause: importClause.trim(), source: importSource, line: content.slice(0, match.index).split('\n').length });
  }

  // Dynamic imports
  const dynImportRegex = /import\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
  while ((match = dynImportRegex.exec(content)) !== null) {
    imports.push({ clause: 'dynamic', source: match[1], line: content.slice(0, match.index).split('\n').length });
  }

  // Extract exports
  if (/export\s+default\b/.test(content)) {
    hasDefaultExport = true;
  }
  
  const exportConstRegex = /export\s+(?:async\s+)?(?:const|let|var|function|class)\s+([A-Za-z0-9_$]+)/g;
  while ((match = exportConstRegex.exec(content)) !== null) {
    namedExports.add(match[1]);
  }

  const exportListRegex = /export\s*\{([^}]+)\}/g;
  while ((match = exportListRegex.exec(content)) !== null) {
    const names = match[1].split(',').map(s => s.trim()).filter(Boolean);
    for (const name of names) {
      const aliasMatch = name.match(/^([\w$]+)\s+as\s+([\w$]+)$/);
      if (aliasMatch) {
        namedExports.add(aliasMatch[2]);
      } else {
        namedExports.add(name);
      }
    }
  }

  // Check for re-export all: export * from '...'
  const exportAllRegex = /export\s*\*\s*from\s*['"]([^'"]+)['"]/g;
  const reExportAlls = [];
  while ((match = exportAllRegex.exec(content)) !== null) {
    reExportAlls.push(match[1]);
  }

  fileData.set(relPath, {
    absPath: file,
    content,
    imports,
    namedExports,
    hasDefaultExport,
    reExportAlls
  });
}

console.log('✓ Parsed imports/exports metadata.');

// 3. Resolve imports to absolute relative paths
function resolveImport(fromRelPath, importSource) {
  if (!importSource.startsWith('.') && !importSource.startsWith('@/')) {
    return null; // External package
  }

  let targetPath;
  if (importSource.startsWith('@/')) {
    targetPath = importSource.slice(2);
  } else {
    const fromDir = path.dirname(fromRelPath);
    targetPath = path.join(fromDir, importSource).replace(/\\/g, '/');
  }

  // Try direct match or with extensions
  const extensions = ['', '.js', '.jsx', '.ts', '.tsx', '/index.js', '/index.jsx', '/index.ts', '/index.tsx'];
  for (const ext of extensions) {
    const candidate = (targetPath + ext).replace(/\\/g, '/');
    if (fileData.has(candidate)) {
      return candidate;
    }
  }
  return null;
}

// 4. Build Dependency Graph & Detect Cycles (Agent 2)
const depGraph = new Map();
for (const [relPath, data] of fileData.entries()) {
  const resolvedDeps = new Set();
  for (const imp of data.imports) {
    const resolved = resolveImport(relPath, imp.source);
    if (resolved && resolved !== relPath) {
      resolvedDeps.add(resolved);
    }
  }
  depGraph.set(relPath, Array.from(resolvedDeps));
}

function findCycles() {
  const visited = new Set();
  const recStack = new Set();
  const cycles = [];

  function dfs(node, path = []) {
    visited.add(node);
    recStack.add(node);
    path.push(node);

    const neighbors = depGraph.get(node) || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        dfs(neighbor, [...path]);
      } else if (recStack.has(neighbor)) {
        const cycleStartIndex = path.indexOf(neighbor);
        const cycle = path.slice(cycleStartIndex).concat(neighbor);
        cycles.push(cycle);
      }
    }

    recStack.delete(node);
  }

  for (const node of depGraph.keys()) {
    if (!visited.has(node)) {
      dfs(node, []);
    }
  }
  return cycles;
}

const cycles = findCycles();
console.log(`\n=== 🔄 CIRCULAR DEPENDENCIES AUDIT (Agent 2) ===`);
if (cycles.length === 0) {
  console.log('✅ No circular dependencies detected!');
} else {
  console.log(`⚠️ Found ${cycles.length} circular dependency cycles:`);
  cycles.forEach((c, i) => {
    console.log(`Cycle #${i+1}: ${c.join(' -> ')}`);
  });
}

// 5. Audit Import/Export Contract Mismatches (Agent 3)
console.log(`\n=== 📦 IMPORT / EXPORT CONTRACT AUDIT (Agent 3) ===`);
const contractErrors = [];

for (const [relPath, data] of fileData.entries()) {
  for (const imp of data.imports) {
    if (!imp.source.startsWith('.') && !imp.source.startsWith('@/')) continue;
    const resolved = resolveImport(relPath, imp.source);
    if (!resolved) {
      contractErrors.push({
        file: relPath,
        line: imp.line,
        issue: `Unresolved relative import: "${imp.source}"`
      });
      continue;
    }

    const targetData = fileData.get(resolved);
    if (!targetData) continue;

    // Check named imports: import { A, B as C } from '...'
    if (imp.clause.includes('{')) {
      const namedMatch = imp.clause.match(/\{([^}]+)\}/);
      if (namedMatch) {
        const symbols = namedMatch[1].split(',').map(s => s.trim()).filter(Boolean);
        for (const sym of symbols) {
          const origName = sym.split(/\s+as\s+/)[0].trim();
          if (!targetData.namedExports.has(origName)) {
            // Check if target re-exports all
            let foundInReExports = false;
            for (const reExp of targetData.reExportAlls) {
              const reExpResolved = resolveImport(resolved, reExp);
              if (reExpResolved && fileData.get(reExpResolved)?.namedExports.has(origName)) {
                foundInReExports = true;
                break;
              }
            }
            if (!foundInReExports) {
              contractErrors.push({
                file: relPath,
                line: imp.line,
                issue: `Imported named symbol "${origName}" not found in exports of "${resolved}" (available: ${Array.from(targetData.namedExports).join(', ') || 'none'})`
              });
            }
          }
        }
      }
    }

    // Check default import: import Foo from '...'
    const defaultMatch = imp.clause.match(/^([\w$]+)(?:\s*,|\s*$)/);
    if (defaultMatch && defaultMatch[1] !== 'type' && !imp.clause.startsWith('* as')) {
      const defaultName = defaultMatch[1];
      if (!targetData.hasDefaultExport) {
        contractErrors.push({
          file: relPath,
          line: imp.line,
          issue: `Default import "${defaultName}" imported from "${resolved}", but target has NO default export!`
        });
      }
    }
  }
}

if (contractErrors.length === 0) {
  console.log('✅ 0 import/export contract mismatches found.');
} else {
  console.log(`⚠️ Found ${contractErrors.length} import/export issues:`);
  contractErrors.forEach(e => console.log(`  - [${e.file}:${e.line}] ${e.issue}`));
}

// 6. Audit Temporal Dead Zone & Top-Level Order Issues (Agent 1)
console.log(`\n=== ⚡ TDZ & DECLARATION ORDER AUDIT (Agent 1) ===`);
const tdzIssues = [];

for (const [relPath, data] of fileData.entries()) {
  const lines = data.content.split('\n');
  const declaredConsts = new Map(); // name -> line
  const declaredFunctions = new Set(); // functions are hoisted
  
  // First pass: find functions
  lines.forEach((line, idx) => {
    const fnMatch = line.match(/^\s*(?:export\s+)?function\s+([A-Za-z0-9_$]+)/);
    if (fnMatch) declaredFunctions.add(fnMatch[1]);
  });

  // Second pass: check const references before declaration
  lines.forEach((line, idx) => {
    const lineNum = idx + 1;
    // Check export const A = B
    const exportConstAlias = line.match(/^\s*export\s+const\s+([A-Za-z0-9_$]+)\s*=\s*([A-Za-z0-9_$]+)\s*;?\s*$/);
    if (exportConstAlias) {
      const aliasName = exportConstAlias[1];
      const targetName = exportConstAlias[2];
      
      // If target is declared later as const in this file
      const targetDeclLine = lines.findIndex(l => new RegExp(`^\\s*(?:export\\s+)?(?:const|let)\\s+${targetName}\\b`).test(l));
      if (targetDeclLine > idx && !declaredFunctions.has(targetName)) {
        tdzIssues.push({
          file: relPath,
          line: lineNum,
          issue: `TDZ Hazard: "export const ${aliasName} = ${targetName}" evaluates before "${targetName}" is initialized on line ${targetDeclLine + 1}!`
        });
      }
    }
  });
}

if (tdzIssues.length === 0) {
  console.log('✅ 0 TDZ declaration hazards detected.');
} else {
  console.log(`⚠️ Found ${tdzIssues.length} TDZ declaration hazards:`);
  tdzIssues.forEach(e => console.log(`  - [${e.file}:${e.line}] ${e.issue}`));
}

console.log('\nAudit complete.');
