const { chromium } = require('playwright');
const http = require('http');
const path = require('path');
const fs = require('fs');

// Ingest express app
const expressApp = require('../server/index.js');

const VIEWPORTS = [
  { name: 'iPhone_390x844', width: 390, height: 844, isMobile: true },
  { name: 'iPad_768x1024', width: 768, height: 1024, isMobile: true },
  { name: 'Laptop_1366x768', width: 1366, height: 768, isMobile: false },
  { name: 'Desktop_1440x900', width: 1440, height: 900, isMobile: false }
];

const PAGES_TO_AUDIT = [
  { path: '/', role: 'public', name: 'Landing Page' },
  { path: '/login', role: 'public', name: 'Login Screen' },
  { path: '/citizen', role: 'citizen', name: 'Citizen Portal' },
  { path: '/citizen/report/new', role: 'citizen', name: 'Citizen Report Form' },
  { path: '/citizen/reports/DG-2026-0001', role: 'citizen', name: 'Citizen Tracking' },
  { path: '/citizen/nearby', role: 'citizen', name: 'Citizen Nearby Scanner' },
  { path: '/community', role: 'citizen', name: 'Community Home' },
  { path: '/community/discover', role: 'citizen', name: 'Community Discover' },
  { path: '/community/observe', role: 'citizen', name: 'Create Observation' },
  { path: '/community/cases/case_01', role: 'citizen', name: 'Community Case Workspace' },
  { path: '/community/impact', role: 'citizen', name: 'Community Impact' },
  { path: '/contractor', role: 'contractor', name: 'Contractor Dashboard' },
  { path: '/contractor/actions/act_2026_089', role: 'contractor', name: 'Contractor Action Detail' },
  { path: '/staff/dashboard', role: 'staff', name: 'Staff Dashboard' },
  { path: '/staff/monitoring', role: 'staff', name: 'Staff Monitoring' },
  { path: '/staff/cases/case_01', role: 'staff', name: 'Staff Case Detail' },
  { path: '/staff/sites/site-vd1', role: 'staff', name: 'Staff Site Detail' },
  { path: '/staff/inspections', role: 'staff', name: 'Staff Inspections' },
  { path: '/staff/sla', role: 'staff', name: 'Staff SLA Tracking' },
  { path: '/staff/alerts', role: 'staff', name: 'Staff Alerts' },
  { path: '/staff/documents', role: 'staff', name: 'Staff Documents' },
  { path: '/executive/dashboard', role: 'executive', name: 'Executive Dashboard' },
  { path: '/executive/heatmap', role: 'executive', name: 'Executive Heatmap' }
];

async function isServerReady(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => {
      resolve(res.statusCode === 200 || res.statusCode === 304);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function auditTypography() {
  console.log('========================================================');
  console.log('🔍 DUSTGUARD VN — DEVTOOLS TYPOGRAPHY & ORPHAN WORD AUDIT');
  console.log('========================================================\n');

  let localServer = null;
  let PORT = 3000;
  const is3000Ready = await isServerReady(`http://127.0.0.1:3000/api/health`);
  if (!is3000Ready) {
    PORT = 3198;
    localServer = await new Promise((res, rej) => {
      const app = expressApp.default || expressApp;
      const s = http.createServer(app);
      s.listen(PORT, '127.0.0.1', () => res(s));
      s.on('error', rej);
    });
  }

  const BASE_URL = `http://127.0.0.1:${PORT}`;

  let browser;
  try {
    try {
      browser = await chromium.launch({ channel: 'msedge', headless: true });
    } catch {
      browser = await chromium.launch({ headless: true });
    }
  } catch (err) {
    if (localServer) localServer.close();
    throw err;
  }

  const findings = [];

  for (const vp of VIEWPORTS) {
    console.log(`\n📱 Scanning Viewport: ${vp.name} (${vp.width}x${vp.height})...`);
    const context = await browser.newContext({
      viewport: { width: vp.width, height: vp.height },
      isMobile: vp.isMobile,
      locale: 'vi-VN'
    });

    const page = await context.newPage();

    for (const route of PAGES_TO_AUDIT) {
      await page.addInitScript((role) => {
        try {
          const userObj = {
            id: `usr_test_${role}`,
            name: `Test ${role.toUpperCase()}`,
            role: role,
            email: `${role}@dustguard.vn`
          };
          localStorage.setItem('dustguard_user', JSON.stringify(userObj));
          localStorage.setItem('dustguard_role', role);
          sessionStorage.setItem('dustguard_role', role);
        } catch {}
      }, route.role);

      try {
        await page.goto(`${BASE_URL}${route.path}`, { waitUntil: 'domcontentloaded', timeout: 8000 });
        await page.waitForTimeout(250);

        // Run DOM inspection inside page
        const pageAudit = await page.evaluate((rName) => {
          const issues = [];

          // 1. Check Horizontal Overflow
          const scrollW = document.documentElement.scrollWidth;
          const clientW = document.documentElement.clientWidth;
          if (scrollW > clientW + 2) {
            issues.push({
              type: 'HORIZONTAL_OVERFLOW',
              target: 'documentElement',
              detail: `scrollWidth (${scrollW}px) > clientWidth (${clientW}px)`
            });
          }

          // 2. Check Buttons, Badges, Tabs for accidental wrapping / orphan words
          const shortInteractiveElements = document.querySelectorAll(
            'button, a.btn, .btn, .badge, .chip, .status-badge, nav a, .tab-btn, [role="tab"], .metric-label'
          );

          shortInteractiveElements.forEach((el) => {
            if (!el.offsetParent) return; // ignore hidden elements
            const text = (el.innerText || '').trim();
            if (!text || text.length > 50 || text.includes('\n')) return;

            const rect = el.getBoundingClientRect();
            // If computed white-space is not nowrap and word count <= 3 but wrapped into > 1 line
            const words = text.split(/\s+/).filter(Boolean);
            if (words.length >= 2 && words.length <= 4) {
              const computedStyle = window.getComputedStyle(el);
              const lineHeight = parseFloat(computedStyle.lineHeight) || (parseFloat(computedStyle.fontSize) * 1.3);
              const height = rect.height;
              // If element height is more than 1.8 * lineHeight, it wrapped onto multiple lines
              if (height > lineHeight * 1.8 && computedStyle.whiteSpace !== 'nowrap') {
                issues.push({
                  type: 'BUTTON_BADGE_WRAPPING',
                  target: el.tagName.toLowerCase() + (el.className ? '.' + el.className.split(' ').slice(0, 2).join('.') : ''),
                  text: text,
                  detail: `Short action/badge (${words.length} words) wrapped into multiple lines (${Math.round(height)}px vs line ${Math.round(lineHeight)}px)`
                });
              }
            }
          });

          // 3. Check Headings for single-word line drop (orphan word)
          const headings = document.querySelectorAll('h1, h2, h3, h4, .headline, .section-title, .card-title');
          headings.forEach((h) => {
            if (!h.offsetParent) return;
            const text = (h.innerText || '').trim();
            if (!text || text.length < 15) return;

            const computed = window.getComputedStyle(h);
            if (computed.textWrap === 'nowrap') return;

            // Check if last word is lonely on its line via range / clientRects
            const range = document.createRange();
            range.selectNodeContents(h);
            const rects = range.getClientRects();
            if (rects.length > 1) {
              const lastRect = rects[rects.length - 1];
              const prevRect = rects[rects.length - 2];
              // If last line width is very narrow (< 15% of container width or < 80px) and only 1 short word
              const words = text.split(/\s+/);
              const lastWord = words[words.length - 1];
              if (lastRect.width < 90 && lastWord.length < 8 && (prevRect.bottom <= lastRect.top + 5)) {
                issues.push({
                  type: 'ORPHAN_HEADING_WORD',
                  target: h.tagName.toLowerCase() + (h.className ? '.' + h.className.split(' ').slice(0, 2).join('.') : ''),
                  text: text,
                  detail: `Last word "${lastWord}" drops to a separate line (width: ${Math.round(lastRect.width)}px)`
                });
              }
            }
          });

          return issues;
        }, route.name);

        if (pageAudit.length > 0) {
          findings.push({
            viewport: vp.name,
            route: route.path,
            name: route.name,
            issues: pageAudit
          });
          console.log(`  ⚠️ [${route.name}] (${route.path}): ${pageAudit.length} potential typography/layout notes`);
          pageAudit.slice(0, 3).forEach(i => console.log(`     - [${i.type}] ${i.target}: ${i.text || i.detail}`));
        } else {
          console.log(`  ✔ [${route.name}] (${route.path}): Clean Layout & Typography`);
        }

      } catch (err) {
        console.error(`  ❌ Error loading ${route.path}:`, err.message);
      }
    }

    await context.close();
  }

  await browser.close();
  if (localServer) localServer.close();

  console.log('\n========================================================');
  console.log(`📊 AUDIT COMPLETED: ${findings.length} pages with layout/typography adjustments found`);
  console.log('========================================================\n');

  return findings;
}

auditTypography()
  .then((res) => {
    fs.writeFileSync('scripts/typography_audit_results.json', JSON.stringify(res, null, 2), 'utf8');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Fatal in typography audit:', err);
    process.exit(1);
  });
