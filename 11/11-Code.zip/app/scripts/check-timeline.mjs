import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));
const query = `
  SELECT 
    strftime('%H:00', timestamp) as time,
    ROUND(AVG(pm25), 1) as pm25,
    ROUND(AVG(pm10), 1) as pm10,
    MIN(timestamp) as minTime
  FROM sensor_readings
  GROUP BY strftime('%H:00', timestamp)
  ORDER BY minTime ASC
`;
const results = db.prepare(query).all();
console.log('Query result count:', results.length);
console.log('Results:', results);
