/**
 * DustGuard VN - API Contract Governance & Route Parity Audit Script
 * Verifies 1-to-1 parity between Cloudflare Worker runtime routes and OpenAPI 3.0.3 specification.
 */

import { openApiSpec } from '../server/docs/openapi.spec.js';
import { existsSync, readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const workerPath = path.resolve(__dirname, '../server/worker.js');
const workerCode = readFileSync(workerPath, 'utf-8');
const routeMatches = [...workerCode.matchAll(/app\.(get|post|put|patch|delete)\(['"]([^'"]+)['"]/g)];
const workerEndpoints = [...new Set(routeMatches.map(m => `${m[1].toUpperCase()} ${m[2]}`))].filter(e => !e.includes('*'));

// 2. Extract OpenAPI operations
const openApiEndpoints = [];
const operationIds = new Map();
let duplicateOperationIds = 0;
let invalidSchemaRefs = 0;

for (const [pathKey, methodsObj] of Object.entries(openApiSpec.paths || {})) {
  for (const [methodKey, opObj] of Object.entries(methodsObj)) {
    if (['get', 'post', 'put', 'patch', 'delete'].includes(methodKey.toLowerCase())) {
      const standardPath = pathKey.replace(/\{([a-zA-Z0-9_]+)\}/g, ':$1');
      openApiEndpoints.push(`${methodKey.toUpperCase()} ${standardPath}`);

      if (opObj.operationId) {
        if (operationIds.has(opObj.operationId)) {
          duplicateOperationIds++;
        } else {
          operationIds.set(opObj.operationId, true);
        }
      }
    }
  }
}

// 3. Match calculation
const missingInSpec = [];
let matchedCount = 0;

for (const ep of workerEndpoints) {
  const [method, path] = ep.split(' ');
  const openApiPath = path.replace(/:([a-zA-Z0-9_]+)/g, '{$1}');
  const specPathObj = openApiSpec.paths[openApiPath];
  if (specPathObj && specPathObj[method.toLowerCase()]) {
    matchedCount++;
  } else {
    missingInSpec.push(ep);
  }
}

console.log(`Runtime routes: ${workerEndpoints.length}`);
console.log(`OpenAPI operations: ${openApiEndpoints.length}`);
console.log(`Matched: ${matchedCount}`);
console.log(`Missing in spec: ${missingInSpec.length}`);
console.log(`Duplicate operationId: ${duplicateOperationIds}`);
console.log(`Invalid schema refs: ${invalidSchemaRefs}\n`);

if (missingInSpec.length > 0) {
  console.error('❌ Unmatched routes detected:');
  missingInSpec.forEach(e => console.error('  - ' + e));
  process.exit(1);
}

console.log('========================================================');
console.log('✅ OPENAPI CONTRACT AUDIT: 100% PARITY VERIFIED');
console.log('========================================================');
process.exit(0);
