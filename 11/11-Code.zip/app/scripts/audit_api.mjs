import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openApiSpec } from '../server/docs/openapi.spec.js';

// 1. OpenAPI paths
const openApiEndpoints = [];
for (const [p, methods] of Object.entries(openApiSpec.paths)) {
  for (const method of Object.keys(methods)) {
    openApiEndpoints.push(`${method.toUpperCase()} ${p}`);
  }
}

// 2. Worker routes in worker.js
const workerContent = fs.readFileSync('server/worker.js', 'utf8');
const workerRegex = /app\.(get|post|put|patch|delete|all)\(\s*['"`]([^'"`]+)['"`]/g;
const workerEndpoints = [];
let match;
while ((match = workerRegex.exec(workerContent)) !== null) {
  workerEndpoints.push(`${match[1].toUpperCase()} ${match[2]}`);
}

// 3. Scan Express route files
const routeFiles = [
  { file: 'server/routes/api/users.js', mount: '/api/users' },
  { file: 'server/routes/api/sites.js', mount: '/api/sites' },
  { file: 'server/routes/api/ai.js', mount: '/api/ai' },
  { file: 'server/routes/api/complaints.js', mount: '/api/complaints' },
  { file: 'server/routes/api/inspections.js', mount: '/api/inspections' },
  { file: 'server/routes/api/actions.js', mount: '/api/actions' },
  { file: 'server/routes/api/documents.js', mount: '/api/documents' },
  { file: 'server/routes/api/legal.js', mount: '/api/legal-documents' },
  { file: 'server/routes/api/cases.js', mount: '/api/cases' },
  { file: 'server/routes/auth.js', mount: '/api/auth' },
  { file: 'server/routes/feedback.js', mount: '/api/feedback' },
  { file: 'server/routes/checklists.js', mount: '/api/checklists' },
  { file: 'server/routes/api/dashboard.js', mount: '/api/dashboard' },
  { file: 'server/routes/api/alerts.js', mount: '/api/alerts' },
  { file: 'server/routes/api/sensors.js', mount: '/api/sensors' },
  { file: 'server/routes/api/public.js', mount: '/api/public' },
  { file: 'server/routes/api/csr.js', mount: '/api/csr' },
  { file: 'server/routes/api/contractor.js', mount: '/api/contractor' },
];

const expressEndpoints = [];
for (const rf of routeFiles) {
  if (!fs.existsSync(rf.file)) continue;
  const content = fs.readFileSync(rf.file, 'utf8');
  const rRegex = /router\.(get|post|put|patch|delete|all)\(\s*['"`]([^'"`]+)['"`]/g;
  while ((match = rRegex.exec(content)) !== null) {
    const subPath = match[2] === '/' ? '' : match[2];
    expressEndpoints.push(`${match[1].toUpperCase()} ${rf.mount}${subPath}`);
  }
}

// Add directly mounted endpoints in index.js
const indexContent = fs.readFileSync('server/index.js', 'utf8');
const indexDirectRegex = /app\.(get|post|put|patch|delete|all)\(\s*(?:\[([^\]]+)\]|['"`]([^'"`]+)['"`])/g;
while ((match = indexDirectRegex.exec(indexContent)) !== null) {
  const method = match[1].toUpperCase();
  if (match[2]) {
    const paths = match[2].replace(/['"`\s]/g, '').split(',');
    for (const p of paths) expressEndpoints.push(`${method} ${p}`);
  } else if (match[3]) {
    expressEndpoints.push(`${method} ${match[3]}`);
  }
}

console.log('=== TOTAL COUNTS ===');
console.log('OpenAPI defined endpoints:', openApiEndpoints.length);
console.log('Worker defined endpoints:', workerEndpoints.length);
console.log('Express defined endpoints:', expressEndpoints.length);

console.log('\n=== OPENAPI SPEC PATHS ===');
openApiEndpoints.sort().forEach(e => console.log(e));

console.log('\n=== WORKER PATHS ===');
workerEndpoints.sort().forEach(e => console.log(e));

console.log('\n=== EXPRESS PATHS ===');
expressEndpoints.sort().forEach(e => console.log(e));
