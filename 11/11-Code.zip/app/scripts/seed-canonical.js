#!/usr/bin/env node
/**
 * CLI Script: Seed Canonical Demo Dataset (SSOT)
 * Usage: node scripts/seed-canonical.js
 */
import { seedCanonicalData } from '../server/services/system-data.service.js';
import { prisma } from '../server/shared/db.js';

async function main() {
  console.log('========================================================');
  console.log('🌱 DUSTGUARD VN - CANONICAL DATASET SEEDER (SSOT)');
  console.log('========================================================');
  console.log('Đang khởi tạo dữ liệu mẫu...');

  try {
    const summary = await seedCanonicalData({
      actor: { id: 'cli_seeder', name: 'CLI Seeder', role: 'admin' },
      env: prisma
    });

    console.log('\n✅ KHỞI TẠO THÀNH CÔNG:');
    console.log(`- Sites: ${summary.sitesCreated}`);
    console.log(`- Complaints: ${summary.complaintsCreated}`);
    console.log(`- Cases: ${summary.casesCreated}`);
    console.log(`- Priority Score computed: ${summary.priorityScoreCalculated}`);
    process.exit(0);
  } catch (error) {
    console.error('\n❌ LỖI KHI SEED DỮ LIỆU:', error.message);
    process.exit(1);
  }
}

main();
