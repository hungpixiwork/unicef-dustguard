import Database from 'better-sqlite3';

const db = new Database('prisma/dev.db');

try {
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  console.log('Tables in prisma/dev.db:', tables.map(t => t.name));

  for (const table of tables) {
    if (table.name.startsWith('_')) continue;
    const count = db.prepare(`SELECT count(*) as count FROM "${table.name}"`).get();
    console.log(`Table: ${table.name}, Count: ${count.count}`);
    if (count.count > 0) {
      const row = db.prepare(`SELECT * FROM "${table.name}" LIMIT 1`).get();
      console.log(`Sample row from ${table.name}:`, row);
    }
  }
} catch (err) {
  console.error('Error during DB inspection:', err);
} finally {
  db.close();
}
