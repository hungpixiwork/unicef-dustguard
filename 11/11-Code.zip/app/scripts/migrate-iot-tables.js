import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';

const dbPaths = [
  path.resolve('app/prisma/dev.db'),
  path.resolve('app/dev.db')
];

for (const dbPath of dbPaths) {
  if (fs.existsSync(dbPath)) {
    console.log(`[Migration] Migrating IoT tables in ${dbPath}...`);
    const db = new Database(dbPath);
    db.exec(`
      CREATE TABLE IF NOT EXISTS iot_devices (
        id TEXT PRIMARY KEY,
        device_id TEXT UNIQUE,
        name TEXT,
        sensor_type TEXT DEFAULT 'APM2000',
        device_secret_hash TEXT,
        firmware_version TEXT DEFAULT '1.0.0',
        status TEXT DEFAULT 'ONLINE',
        last_seen_at DATETIME,
        site_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS iot_readings (
        id TEXT PRIMARY KEY,
        device_id TEXT,
        pm1 REAL DEFAULT 0,
        pm25 REAL DEFAULT 0,
        pm10 REAL DEFAULT 0,
        wifi_rssi INTEGER DEFAULT 0,
        uptime INTEGER DEFAULT 0,
        captured_at DATETIME,
        received_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_iot_readings_device_captured ON iot_readings (device_id, captured_at DESC);
    `);

    // Insert default seed node for Nhóm 11: DG-NODE-011
    const existing = db.prepare('SELECT id FROM iot_devices WHERE device_id = ?').get('DG-NODE-011');
    if (!existing) {
      db.prepare(`
        INSERT INTO iot_devices (id, device_id, name, sensor_type, device_secret_hash, firmware_version, status, last_seen_at, created_at, updated_at)
        VALUES ('iot_dev_011', 'DG-NODE-011', 'DustGuard Node 011 (APM2000)', 'APM2000', 'dustguard_secret_key_2026', '1.0.0', 'ONLINE', datetime('now'), datetime('now'), datetime('now'))
      `).run();

      // Seed an initial reading
      db.prepare(`
        INSERT INTO iot_readings (id, device_id, pm1, pm25, pm10, wifi_rssi, uptime, captured_at, received_at)
        VALUES ('iot_rd_init_011', 'DG-NODE-011', 12.4, 28.5, 41.8, -58, 3600, datetime('now'), datetime('now'))
      `).run();
      console.log('Seeded default device DG-NODE-011 and initial reading.');
    }

    console.log(`[Migration] Done for ${dbPath}`);
  }
}
