import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('--- ENHANCING ALERTS SCHEMA WITH OPERATIONAL COLUMNS ---');

// Helper thêm cột an toàn nếu chưa tồn tại
function addColumnIfNotExists(table, columnDef, columnName) {
  const info = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!info.some(c => c.name === columnName)) {
    db.prepare(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`).run();
    console.log(`+ Added column ${columnName} to table ${table}`);
  } else {
    console.log(`= Column ${columnName} already exists in table ${table}`);
  }
}

addColumnIfNotExists('alerts', 'title TEXT', 'title');
addColumnIfNotExists('alerts', 'severity TEXT DEFAULT "CRITICAL"', 'severity');
addColumnIfNotExists('alerts', 'pm25Value REAL DEFAULT 45.0', 'pm25Value');
addColumnIfNotExists('alerts', 'priorityReasons TEXT DEFAULT "[]"', 'priorityReasons');
addColumnIfNotExists('alerts', 'evidenceUrls TEXT DEFAULT "[]"', 'evidenceUrls');
addColumnIfNotExists('alerts', 'assignedTo TEXT', 'assignedTo');
addColumnIfNotExists('alerts', 'caseId TEXT', 'caseId');

// Tạo index hỗ trợ truy vấn lọc theo severity và priority
db.prepare('CREATE INDEX IF NOT EXISTS idx_alerts_severity_status ON alerts(severity, status)').run();
db.prepare('CREATE INDEX IF NOT EXISTS idx_alerts_case_id ON alerts(caseId)').run();

console.log('Alerts schema enhanced successfully!');
