#!/usr/bin/env node
/**
 * ARCHITECTURE GATE — DUSTGUARD VN
 * Enforces strict dependency discipline & prevents architecture drift.
 * 
 * Rules:
 * 1. Blacklist forbidden packages (Express, Clerk, Supabase, Neon, PG...)
 * 2. Enforce 6 Core Domains SSOT
 * 3. Reject unauthorized package additions without ADR
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appPackageJsonPath = path.resolve(__dirname, '../package.json');

console.log('\n🏛️  [ARCHITECTURE GATE] Checking dependency graph & stack invariants...');

if (!fs.existsSync(appPackageJsonPath)) {
  console.error('❌ package.json not found at:', appPackageJsonPath);
  process.exit(1);
}

const pkg = JSON.parse(fs.readFileSync(appPackageJsonPath, 'utf8'));
const allDeps = {
  ...(pkg.dependencies || {}),
  ...(pkg.devDependencies || {})
};

// Strict Forbidden Packages List
const FORBIDDEN_PACKAGES = [
  { name: '@supabase/supabase-js', reason: 'Supabase is banned. D1 + R2 is SSOT.' },
  { name: 'pg', reason: 'PostgreSQL is banned. Cloudflare D1 (SQLite) is SSOT.' },
  { name: 'pg-hstore', reason: 'PostgreSQL is banned.' },
  { name: 'mysql', reason: 'MySQL is banned.' },
  { name: 'mysql2', reason: 'MySQL is banned.' },
  { name: 'neon-buildhooks', reason: 'Neon is banned. D1 is SSOT.' },
  { name: 'mongodb', reason: 'MongoDB is banned.' }
];

let violations = 0;

for (const forbidden of FORBIDDEN_PACKAGES) {
  if (allDeps[forbidden.name]) {
    console.error(`❌ VIOLATION: Forbidden dependency detected: "${forbidden.name}"`);
    console.error(`   Reason: ${forbidden.reason}`);
    violations++;
  }
}

// Check 6 Core Domains in app/src/domains
const domainsDir = path.resolve(__dirname, '../src/domains');
const REQUIRED_DOMAINS = ['reports', 'cases', 'inspections', 'assignments', 'evidence', 'users'];

console.log('📦 [ARCHITECTURE GATE] Checking 6 Core Domains in src/domains/...');
if (!fs.existsSync(domainsDir)) {
  console.warn('⚠️  Warning: src/domains/ directory is being initialized.');
} else {
  for (const domain of REQUIRED_DOMAINS) {
    const domainPath = path.join(domainsDir, domain);
    if (!fs.existsSync(domainPath)) {
      console.warn(`⚠️  Domain "${domain}" not yet created in src/domains/`);
    } else {
      console.log(`   ✔ Domain [${domain}] active`);
    }
  }
}

if (violations > 0) {
  console.error(`\n🚨 ARCHITECTURE GATE FAILED: Found ${violations} illegal dependencies.`);
  console.error('   DustGuard VN policy: Cloudflare Hono + D1 + R2 + Better Auth only.\n');
  process.exit(1);
}

console.log('✅ [ARCHITECTURE GATE] Passed. Dependency graph complies with SSOT architecture.\n');
process.exit(0);
