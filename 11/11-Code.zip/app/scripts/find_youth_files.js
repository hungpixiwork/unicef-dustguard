import fs from 'fs';
import path from 'path';

function searchInDir(dir, pattern) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const full = path.join(dir, file);
    if (fs.statSync(full).isDirectory()) {
      if (file !== 'node_modules' && file !== '.git') {
        searchInDir(full, pattern);
      }
    } else if (file.endsWith('.jsx') || file.endsWith('.tsx') || file.endsWith('.js')) {
      const c = fs.readFileSync(full, 'utf8');
      if (pattern.test(c)) {
        console.log(path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app/src', full));
      }
    }
  }
}

console.log('--- FILES USING YOUTH / GREEN CREDITS ---');
searchInDir('D:/07-Competitions-Hackathons/unicef-dustguard/app/src', /youth-credits|YouthPortal|GreenCredits|tín chỉ xanh|điểm rèn luyện/i);
