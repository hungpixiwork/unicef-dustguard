import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('--- CREATING MISSING SSOT TABLES (NOTIFICATIONS, REPORTS) ---');

db.prepare(`
  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT,
    entity_type TEXT,
    entity_id TEXT,
    priority TEXT DEFAULT 'normal',
    is_read INTEGER DEFAULT 0,
    is_muted INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    report_type TEXT NOT NULL,
    project_id TEXT,
    date_from DATETIME,
    date_to DATETIME,
    status TEXT DEFAULT 'ready',
    pdf_url TEXT,
    excel_url TEXT,
    created_by TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS report_schedules (
    id TEXT PRIMARY KEY,
    report_type TEXT NOT NULL,
    recipient_emails TEXT,
    frequency TEXT DEFAULT 'weekly',
    day_of_week INTEGER,
    send_hour INTEGER,
    enabled INTEGER DEFAULT 1,
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
  )
`).run();

console.log('--- SEEDING ALL 12 SSOT TABLES COMPREHENSIVELY ---');
const now = new Date();
const nowIso = now.toISOString();

// 1. SEED USERS
const users = [
  { id: 'usr-an', full_name: 'Nguyễn Văn An', email: 'an.nguyen@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-binh', full_name: 'Trần Thị Bình', email: 'binh.tran@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-nam', full_name: 'Lê Hoàng Nam', email: 'nam.le@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-mai', full_name: 'Phạm Thị Mai', email: 'mai.pham@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-hung', full_name: 'Đỗ Văn Hùng', email: 'hung.do@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-trang', full_name: 'Nguyễn Thu Trang', email: 'trang.nguyen@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-minh', full_name: 'Lê Văn Minh', email: 'minh.le@tnmt.gov.vn', role: 'staff' },
  { id: 'usr-lan', full_name: 'Nguyễn Thị Lan', email: 'lan.nguyen@tnmt.gov.vn', role: 'staff' }
];

const insertUser = db.prepare(`
  INSERT INTO users (id, full_name, email, email_verified, role, status, createdAt, updatedAt)
  VALUES (?, ?, ?, 1, ?, 'ACTIVE', ?, ?)
  ON CONFLICT(id) DO UPDATE SET full_name=excluded.full_name, email=excluded.email, role=excluded.role
`);

for (const u of users) {
  insertUser.run(u.id, u.full_name, u.email, u.role, nowIso, nowIso);
}

// 2. SEED SITES (Bao phủ cả BD-0001, CT-25-0012, site-a, site-b...)
const sites = [
  { id: 'site-a', code: 'CT-25-0012', name: 'Site A · Thanh Xuân (Chung cư Imperial Plaza)', address: 'Số 289 Khuất Duy Tiến, Thanh Xuân, Hà Nội', ward: 'Thanh Xuân', riskScore: 87, riskLevel: 'HIGH', manager: 'Nguyễn Văn An', contractor: 'Công ty CP Xây dựng An Phát', phone: '0901234567', lat: 20.9982, lng: 105.8015 },
  { id: 'site-b', code: 'CT-25-0009', name: 'Site B · Hà Đông (Dự án Vinh Phú Riverside)', address: 'Đường Mỗ Lao, Phường Mỗ Lao, Hà Đông, Hà Nội', ward: 'Hà Đông', riskScore: 74, riskLevel: 'HIGH', manager: 'Phạm Thị Mai', contractor: 'Tổng công ty Sông Đà', phone: '0934567890', lat: 20.9785, lng: 105.7834 },
  { id: 'site-c', code: 'CT-25-0008', name: 'Site C · Cầu Giấy (Khu phức hợp Căn hộ Cao cấp)', address: 'Phường Dịch Vọng, Cầu Giấy, Hà Nội', ward: 'Cầu Giấy', riskScore: 63, riskLevel: 'MEDIUM', manager: 'Trần Thị Bình', contractor: 'Công ty CP Tập đoàn FLC', phone: '0912345678', lat: 21.0324, lng: 105.7923 },
  { id: 'site-d', code: 'CT-25-0015', name: 'Site D · Hoàng Mai (Cải tạo đường Láng Hạ mở rộng)', address: 'Phường Láng Hạ, Đống Đa & Hoàng Mai, Hà Nội', ward: 'Hoàng Mai', riskScore: 58, riskLevel: 'MEDIUM', manager: 'Lê Hoàng Nam', contractor: 'Công ty CP Tasco', phone: '0923456789', lat: 21.0152, lng: 105.8145 },
  { id: 'site-e', code: 'CT-25-0003', name: 'Site E · Long Biên (Dự án Sunshine Riverside)', address: 'Phường Bồ Đề, Long Biên, Hà Nội', ward: 'Long Biên', riskScore: 42, riskLevel: 'LOW', manager: 'Đỗ Văn Hùng', contractor: 'Sunshine Group', phone: '0945678901', lat: 21.0425, lng: 105.8752 },
  { id: 'site-f', code: 'CT-25-0017', name: 'Site F · Bắc Từ Liêm (Khu đô thị Mới An Khánh)', address: 'Xã An Khánh, Hoài Đức & Bắc Từ Liêm, Hà Nội', ward: 'Bắc Từ Liêm', riskScore: 39, riskLevel: 'LOW', manager: 'Nguyễn Thu Trang', contractor: 'Vinaconex', phone: '0956789012', lat: 21.0054, lng: 105.7321 },
  { id: 'site-g', code: 'CT-25-0005', name: 'Site G · Tây Hồ (Cầu vượt Mai Dịch & Đường Vành đai 3)', address: 'Phường Mai Dịch & Phường Xuân La, Tây Hồ, Hà Nội', ward: 'Tây Hồ', riskScore: 66, riskLevel: 'MEDIUM', manager: 'Nguyễn Văn An', contractor: 'Tổng công ty Thăng Long', phone: '0901234567', lat: 21.0543, lng: 105.8123 },
  { id: 'site-h', code: 'CT-25-0010', name: 'Site H · Trạm nghiền đá Hòa Lạc', address: 'Khu công nghệ cao Hòa Lạc, Hà Nội', ward: 'Hòa Lạc', riskScore: 91, riskLevel: 'HIGH', manager: 'Phạm Thị Mai', contractor: 'Công ty Khai thác Khoáng sản', phone: '0934567890', lat: 21.0123, lng: 105.5342 },
  { id: 'BD-0001', code: 'BD-0001', name: 'Tuyến ĐS Đô thị Metro 3 Nhổn - Ga Hà Nội (Kim Mã)', address: 'Đường Kim Mã, Phường Kim Mã, Ba Đình, Hà Nội', ward: 'Ba Đình', riskScore: 82, riskLevel: 'HIGH', manager: 'Nguyễn Văn An', contractor: 'Huyndai E&C - Ghella', phone: '0901234567', lat: 21.0315, lng: 105.8234 }
];

const insertSite = db.prepare(`
  INSERT INTO sites (id, code, name, address, ward, coordinates, dustRiskScore, riskLevel, status, contractorName, managerName, managerPhone, createdAt, updatedAt)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET 
    code=excluded.code, name=excluded.name, address=excluded.address, ward=excluded.ward,
    dustRiskScore=excluded.dustRiskScore, riskLevel=excluded.riskLevel,
    contractorName=excluded.contractorName, managerName=excluded.managerName, managerPhone=excluded.managerPhone
`);

for (const s of sites) {
  insertSite.run(s.id, s.code, s.name, s.address, s.ward, `${s.lat},${s.lng}`, s.riskScore, s.riskLevel, s.contractor, s.manager, s.phone, nowIso, nowIso);
}

// 3. SEED CASES
db.prepare('DELETE FROM cases').run();
const cases = [
  { id: 'case-01', code: 'HS-25-00081', siteId: 'site-a', title: 'Kiểm tra hiện trường phát tán bụi Site A', status: 'IN_PROGRESS', priority: 'URGENT', assignee: 'Nguyễn Thị Lan', dueAt: '2026-09-02T16:00:00.000Z' },
  { id: 'case-02', code: 'HS-25-00074', siteId: 'site-b', title: 'Chờ nhà thầu khắc phục tưới nước Site B', status: 'IN_PROGRESS', priority: 'NORMAL', assignee: 'Lê Văn Minh', dueAt: '2026-09-03T09:00:00.000Z' },
  { id: 'case-03', code: 'HS-25-00065', siteId: 'site-c', title: 'Khảo sát bổ sung che chắn công trình Site C', status: 'IN_PROGRESS', priority: 'URGENT', assignee: 'Phạm Tuấn Anh', dueAt: '2026-09-02T10:30:00.000Z' },
  { id: 'case-04', code: 'HS-25-00058', siteId: 'site-d', title: 'Đánh giá & xác minh nguồn phát tán bụi Site D', status: 'IN_PROGRESS', priority: 'NORMAL', assignee: 'Nguyễn Thị Lan', dueAt: '2026-09-04T14:00:00.000Z' },
  { id: 'case-05', code: 'HS-25-00047', siteId: 'site-e', title: 'Chờ nghiệm thu rửa xe ra vào công trình Site E', status: 'IN_PROGRESS', priority: 'NORMAL', assignee: 'Lê Văn Minh', dueAt: '2026-09-05T11:00:00.000Z' },
  { id: 'case-06', code: 'HS-25-00036', siteId: 'site-f', title: 'Mới tiếp nhận phản ánh bụi Site F', status: 'PENDING', priority: 'NORMAL', assignee: 'Phạm Tuấn Anh', dueAt: '2026-09-06T16:00:00.000Z' },
  { id: 'case-07', code: 'HS-25-00029', siteId: 'site-g', title: 'Kiểm tra xử lý xe chở phế thải Site G', status: 'IN_PROGRESS', priority: 'URGENT', assignee: 'Nguyễn Thị Lan', dueAt: '2026-09-01T09:30:00.000Z' },
  { id: 'case-487', code: 'HS-25-000487', siteId: 'site-a', title: 'Hồ sơ vụ việc vi phạm phát tán bụi Site A - Thanh Xuân', status: 'IN_PROGRESS', priority: 'URGENT', assignee: 'Nguyễn Văn An', dueAt: '2026-09-02T16:00:00.000Z' }
];

const insertCase = db.prepare(`
  INSERT INTO cases (id, code, siteId, title, description, status, priority, assignedTo, slaDeadline, createdAt, updatedAt)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

for (const c of cases) {
  insertCase.run(c.id, c.code, c.siteId, c.title, `Mô tả hồ sơ ${c.code} xử lý tại công trình`, c.status, c.priority, c.assignee, c.dueAt, nowIso, nowIso);
}

// 4. SEED TASKS
db.prepare('DELETE FROM tasks').run();
const tasks = [
  { id: 'tsk-01', code: 'TSK-01', title: 'Kiểm tra định kỳ công trình', siteId: 'site-a', status: 'OPEN', priority: 'URGENT', dueAt: '2026-09-02T16:00:00.000Z' },
  { id: 'tsk-02', code: 'TSK-02', title: 'Xử lý cảnh báo bụi cao', siteId: 'site-b', status: 'OPEN', priority: 'HIGH', dueAt: '2026-09-03T10:30:00.000Z' },
  { id: 'tsk-03', code: 'TSK-03', title: 'Đánh giá biện pháp giảm bụi', siteId: 'site-c', status: 'IN_PROGRESS', priority: 'MEDIUM', dueAt: '2026-09-02T14:00:00.000Z' },
  { id: 'tsk-04', code: 'TSK-04', title: 'Báo cáo tuần tổng hợp quan trắc', siteId: 'site-d', status: 'IN_PROGRESS', priority: 'MEDIUM', dueAt: '2026-09-02T17:00:00.000Z' },
  { id: 'tsk-05', code: 'TSK-05', title: 'Kiểm tra đột xuất khu vực Cầu Giấy', siteId: 'site-c', status: 'OPEN', priority: 'HIGH', dueAt: '2026-09-04T09:00:00.000Z' },
  { id: 'tsk-06', code: 'TSK-06', title: 'Theo dõi sau xử lý Site E', siteId: 'site-e', status: 'COMPLETED', priority: 'LOW', dueAt: '2026-09-01T16:00:00.000Z' },
  { id: 'tsk-07', code: 'TSK-07', title: 'Cập nhật hồ sơ công trình Site D', siteId: 'site-d', status: 'COMPLETED', priority: 'LOW', dueAt: '2026-09-01T11:00:00.000Z' }
];

const insertTask = db.prepare(`
  INSERT INTO tasks (id, code, title, description, site_id, status, priority, due_at, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

for (const t of tasks) {
  insertTask.run(t.id, t.code, t.title, `Nhiệm vụ: ${t.title}`, t.siteId, t.status, t.priority, t.dueAt, nowIso, nowIso);
}

// 5. SEED NOTIFICATIONS
db.prepare('DELETE FROM notifications').run();
const notifs = [
  { id: 'notif-01', type: 'case', title: 'Nhà thầu Site A · Thanh Xuân nộp ảnh mới', message: 'Nhà thầu đã nộp 12 ảnh công trường ngày 20/05/2025.', entityType: 'case', entityId: 'case-01', priority: 'normal' },
  { id: 'notif-02', type: 'case', title: 'Hồ sơ Site B · Hà Đông gần đến hạn', message: 'Hồ sơ định kỳ tháng 05/2025 sẽ đến hạn vào 23/05/2025.', entityType: 'case', entityId: 'case-02', priority: 'high' },
  { id: 'notif-03', type: 'alert', title: 'Cảnh báo mới tại Site C · Cầu Giấy', message: 'PM10 vượt ngưỡng 150 µg/m³ lúc 08:20 ngày 20/05/2025.', entityType: 'alert', entityId: 'alt-03', priority: 'high' },
  { id: 'notif-04', type: 'system', title: 'Báo cáo tháng 04/2025 đã sẵn sàng', message: 'Báo cáo tổng hợp rủi ro bụi tháng 04/2025 đã được tạo.', entityType: 'report', entityId: 'rep-01', priority: 'normal' },
  { id: 'notif-05', type: 'task', title: 'Nhiệm vụ mới được giao', message: 'Bạn được giao nhiệm vụ "Kiểm tra định kỳ Site B · Hà Đông".', entityType: 'task', entityId: 'tsk-02', priority: 'normal' }
];

const insertNotif = db.prepare(`
  INSERT INTO notifications (id, user_id, type, title, message, entity_type, entity_id, priority, is_read, created_at)
  VALUES (?, 'usr-an', ?, ?, ?, ?, ?, ?, 0, ?)
`);

for (const n of notifs) {
  insertNotif.run(n.id, n.type, n.title, n.message, n.entityType, n.entityId, n.priority, nowIso);
}

// 6. SEED REPORTS
db.prepare('DELETE FROM reports').run();
const reports = [
  { id: 'rep-01', name: 'Báo cáo tổng hợp tuần 23/2025', reportType: 'weekly', createdBy: 'Thanh Xuân' },
  { id: 'rep-02', name: 'Báo cáo quá hạn tuần 23/2025', reportType: 'overdue', createdBy: 'Thanh Xuân' },
  { id: 'rep-03', name: 'Báo cáo theo công trình – Site A', reportType: 'project', createdBy: 'Thanh Xuân' },
  { id: 'rep-04', name: 'Báo cáo theo khu vực – Hà Đông', reportType: 'area', createdBy: 'Thanh Xuân' }
];

const insertReport = db.prepare(`
  INSERT INTO reports (id, name, report_type, status, pdf_url, excel_url, created_by, created_at)
  VALUES (?, ?, ?, 'ready', 'https://example.com/report.pdf', 'https://example.com/report.xlsx', ?, ?)
`);

for (const r of reports) {
  insertReport.run(r.id, r.name, r.reportType, r.createdBy, nowIso);
}

console.log('🎉 CANONICAL MASTER SEED FINISHED SUCCESSFULLY WITH ZERO ERRORS!');
