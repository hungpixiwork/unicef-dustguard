import os
import sys
import json
import cv2
import numpy as np
from PIL import Image
from scipy.ndimage import label

def clean_alpha_extract(bgr_img, bg_tol=18.0, low_tol=3.0, pad=4):
    """
    Lossless background transparency extraction:
    - Identifies outer canvas background via border-connected components.
    - Preserves 100% solid opacity (alpha=255) for all internal fills (clothes, faces, buildings, icons).
    - Preserves authentic RGB colors without division artifacts or artificial sharpening.
    - Applies smooth anti-aliasing only at the perimeter boundary.
    """
    h, w = bgr_img.shape[:2]
    
    # Sample 4 outer borders for background color estimation
    borders = np.concatenate([
        bgr_img[0, :],
        bgr_img[-1, :],
        bgr_img[:, 0],
        bgr_img[:, -1]
    ], axis=0)
    bg_color = np.median(borders, axis=0)
    
    # Distance from background color
    diff = np.linalg.norm(bgr_img.astype(np.float32) - bg_color, axis=2)
    
    # Candidate background pixels
    is_bg_candidate = (diff < bg_tol)
    labeled, num_features = label(is_bg_candidate)
    
    # Only keep connected components touching the 4 outer boundaries
    border_labels = set(np.unique(labeled[0, :])) | \
                    set(np.unique(labeled[-1, :])) | \
                    set(np.unique(labeled[:, 0])) | \
                    set(np.unique(labeled[:, -1]))
    border_labels.discard(0)
    
    exterior_bg = np.isin(labeled, list(border_labels))
    
    # Build alpha channel: default 255 (solid)
    alpha = np.ones((h, w), dtype=np.float32) * 255.0
    
    # Pure outer background
    pure_bg = exterior_bg & (diff <= low_tol)
    alpha[pure_bg] = 0.0
    
    # Transition perimeter zone: gentle linear fade
    trans_zone = exterior_bg & (diff > low_tol) & (diff < bg_tol)
    alpha[trans_zone] = ((diff[trans_zone] - low_tol) / (bg_tol - low_tol)) * 255.0
    
    # Convert BGR to RGB
    rgb = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2RGB)
    rgba = np.dstack([rgb, np.clip(alpha, 0, 255).astype(np.uint8)])
    
    # Convert to PIL Image
    pil_img = Image.fromarray(rgba, mode="RGBA")
    
    # Autocrop transparent borders while keeping desired padding
    bbox = pil_img.getbbox()
    if bbox:
        x0 = max(0, bbox[0] - pad)
        y0 = max(0, bbox[1] - pad)
        x1 = min(pil_img.width, bbox[2] + pad)
        y1 = min(pil_img.height, bbox[3] + pad)
        pil_img = pil_img.crop((x0, y0, x1, y1))
        
    return pil_img

def run_asset_extraction():
    base_out = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\public\assets\landing"
    
    # 5 source sheets
    sheet_paths = {
        1: r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_10 21 thg 8, 2026 (1).png",
        2: r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png",
        3: r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (3).png",
        4: r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (4).png",
        5: r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_12 21 thg 8, 2026 (5).png"
    }

    manifest = []
    
    def save_asset(pil_img, category, filename, source_sheet, desc, asset_type="illustration"):
        cat_dir = os.path.join(base_out, category)
        os.makedirs(cat_dir, exist_ok=True)
        
        png_path = os.path.join(cat_dir, f"{filename}.png")
        webp_path = os.path.join(cat_dir, f"{filename}.webp")
        
        pil_img.save(png_path, "PNG", optimize=True)
        pil_img.save(webp_path, "WEBP", quality=95)
        
        size_kb = os.path.getsize(png_path) / 1024.0
        w, h = pil_img.size
        
        manifest.append({
            "asset": filename,
            "category": category,
            "source": source_sheet,
            "file": f"/assets/landing/{category}/{filename}.webp",
            "png_file": f"/assets/landing/{category}/{filename}.png",
            "type": asset_type,
            "description": desc,
            "dimensions": f"{w}x{h}",
            "size": f"{size_kb:.1f} KB"
        })
        print(f"  + [{category}] {filename} -> {w}x{h} ({size_kb:.1f} KB)")

    print("\n=======================================================")
    print("STARTING DUSTGUARD VN ASSET EXTRACTION PIPELINE")
    print("=======================================================")

    # =========================================================
    # SHEET 1: BRAND & UI PRIMITIVES (1448 x 1086)
    # =========================================================
    print("\n>>> Extracting Sheet 1: Brand & UI Primitives...")
    s1 = cv2.imread(sheet_paths[1])
    
    # 1. Brand assets
    # Shield Logo (Clean Mark Only)
    c = s1[58:195, 95:210]
    save_asset(clean_alpha_extract(c), "brand", "dustguard-shield-logo", "01-brand-ui", "DustGuard Shield Logo (Mark only)", "logo")
    save_asset(clean_alpha_extract(c), "brand", "dustguard-shield", "01-brand-ui", "DustGuard Shield Standalone Symbol", "logo")
    
    # Wordmark ("DustGuard VN")
    c = s1[80:150, 320:600]
    save_asset(clean_alpha_extract(c), "brand", "dustguard-wordmark", "01-brand-ui", "DustGuard VN Typography Wordmark", "brand")
    
    # Lockup (Shield + Wordmark)
    c = s1[65:175, 590:830]
    save_asset(clean_alpha_extract(c), "brand", "dustguard-lockup", "01-brand-ui", "DustGuard VN Shield + Wordmark Lockup", "brand")
    
    # UI Badges & Chips
    # Pill Filled
    c = s1[375:445, 75:140]
    save_asset(clean_alpha_extract(c), "badges", "pill-badge-filled", "01-brand-ui", "UI Pill Badge Filled", "badge")
    
    # Pill Outline
    c = s1[375:445, 200:265]
    save_asset(clean_alpha_extract(c), "badges", "pill-badge-outline", "01-brand-ui", "UI Pill Badge Outline", "badge")
    
    # Pill Dashed
    c = s1[375:445, 330:385]
    save_asset(clean_alpha_extract(c), "badges", "pill-badge-dashed", "01-brand-ui", "UI Pill Badge Dashed", "badge")
    
    # Status Chip Active
    c = s1[375:445, 450:510]
    save_asset(clean_alpha_extract(c), "badges", "status-chip-active", "01-brand-ui", "UI Status Chip Active", "badge")
    
    # Status Chip Warning
    c = s1[375:445, 575:630]
    save_asset(clean_alpha_extract(c), "badges", "status-chip-warning", "01-brand-ui", "UI Status Chip Warning", "badge")
    
    # Status Chip Neutral
    c = s1[375:445, 730:785]
    save_asset(clean_alpha_extract(c), "badges", "status-chip-neutral", "01-brand-ui", "UI Status Chip Neutral", "badge")
    
    # Bottom Row Elements
    # City landscape
    c = s1[870:1060, 70:570]
    save_asset(clean_alpha_extract(c), "city", "dustguard-city-landscape", "01-brand-ui", "DustGuard City Landscape Skyline", "illustration")
    
    # Sensor station
    c = s1[895:1060, 600:840]
    save_asset(clean_alpha_extract(c), "iot", "dustguard-sensor-station", "01-brand-ui", "DustGuard IoT Sensor Station Standalone", "illustration")
    
    # Wave pattern 01
    c = s1[880:960, 885:1110]
    save_asset(clean_alpha_extract(c), "patterns", "dustguard-wave-pattern-01", "01-brand-ui", "DustGuard Dynamic Wave Pattern 01", "pattern")
    
    # Dotted grid
    c = s1[965:1060, 885:1110]
    save_asset(clean_alpha_extract(c), "patterns", "dustguard-dotted-grid", "01-brand-ui", "DustGuard Red Dot Matrix Texture Grid", "pattern")

    # =========================================================
    # SHEET 2: 56 CORE ICONS (1448 x 1086) - 8 Cols x 7 Rows
    # =========================================================
    print("\n>>> Extracting Sheet 2: 56 Core Icons...")
    s2 = cv2.imread(sheet_paths[2])
    h2, w2 = s2.shape[:2]
    col_w = w2 / 8.0
    row_h = h2 / 7.0

    icon_matrix = [
        # Row 0
        [("icon-observe", "Observing eye civic monitoring icon"),
         ("icon-understand", "Understand & analyze data icon"),
         ("icon-act", "Act & take initiative icon"),
         ("icon-follow-up", "Follow-up clock & tracking icon"),
         ("icon-impact", "Impact star & civic contribution icon"),
         ("icon-image", "Evidence photo & image icon"),
         ("icon-gps", "GPS geo-location pin icon"),
         ("icon-feedback", "Community feedback chat icon")],
        # Row 1
        [("icon-construction", "Construction dust source icon"),
         ("icon-warning", "Hazard warning triangle icon"),
         ("icon-signal", "IoT wireless signal icon"),
         ("icon-phone-location", "Smartphone civic reporting app icon"),
         ("icon-checklist-pie", "Observation checklist & status icon"),
         ("icon-dashboard", "Civic dashboard monitor icon"),
         ("icon-growth-chart", "AQI trend growth chart icon"),
         ("icon-target-risk", "Target hotspot radar icon")],
        # Row 2
        [("icon-flag", "Priority action flag icon"),
         ("icon-document", "Verified evidence document icon"),
         ("icon-history", "Case follow-up history icon"),
         ("icon-folder", "Public dossier folder icon"),
         ("icon-user", "Civic volunteer user icon"),
         ("icon-community", "Youth community team icon"),
         ("icon-heart-hands", "Community care & protection icon"),
         ("icon-handshake", "Multi-stakeholder collaboration icon")],
        # Row 3
        [("icon-checklist", "Verification checklist icon"),
         ("icon-refresh", "Data sync & refresh icon"),
         ("icon-shield-check", "DustGuard verified shield check icon"),
         ("icon-shield-particles", "Shield air filter & particles icon"),
         ("icon-institution", "Government & authority institution icon"),
         ("icon-shield-lock", "Data privacy & tamper-proof lock icon"),
         ("icon-cloud", "Cloud database sync icon"),
         ("icon-iot-hub", "IoT smart hub gateway icon")],
        # Row 4
        [("icon-iot-sensor", "IoT air monitor sensor icon"),
         ("icon-sensor-pole-1", "Standard sensor pole icon"),
         ("icon-sensor-pole-solar", "Solar-powered sensor pole icon"),
         ("icon-kiosk-1", "Public kiosk display station icon"),
         ("icon-kiosk-solar", "Solar public kiosk station icon"),
         ("icon-skyline", "Urban city skyline icon"),
         ("icon-bridge", "Civic bridge & waterway icon"),
         ("icon-trees", "Urban green trees cluster icon")],
        # Row 5
        [("icon-tree-single", "Young tree sapling icon"),
         ("icon-community-badge", "Youth environmental club badge icon"),
         ("icon-phone-route", "Mobile patrol route tracking icon"),
         ("icon-desktop-chart", "Desktop analysis station icon"),
         ("icon-vertical-timeline", "Vertical chronological timeline icon"),
         ("icon-multi-step-arrow", "Multi-step handoff workflow icon"),
         ("icon-report-pie", "Handoff status report pie chart icon"),
         ("icon-database", "D1 SQLite SSOT database icon")],
        # Row 6
        [("icon-bar-trend", "AQI historical bar trend icon"),
         ("icon-line-chart", "Sensor real-time line chart icon"),
         ("icon-particle-scatter", "PM2.5 particle scatter distribution icon"),
         ("icon-sensor-suspended", "Suspended sensor pod icon"),
         ("icon-sensor-handheld", "Handheld mobile air detector icon"),
         ("icon-gear-cycle", "Autonomous workflow cycle gear icon"),
         ("icon-org-team", "Civic action coordination team icon"),
         ("icon-verified-person", "Responsible officer verified person icon")]
    ]

    for r in range(7):
        for c in range(8):
            fname, fdesc = icon_matrix[r][c]
            # Center of the cell
            cx = (c + 0.5) * col_w
            cy = (r + 0.5) * row_h
            
            # Crop with ample padding around center
            x0 = max(0, int(cx - 72))
            x1 = min(w2, int(cx + 72))
            y0 = max(0, int(cy - 60))
            y1 = min(h2, int(cy + 60))
            
            crop = s2[y0:y1, x0:x1]
            extracted = clean_alpha_extract(crop, bg_tol=18.0, low_tol=3.0, pad=4)
            save_asset(extracted, "icons", fname, "02-icons", fdesc, "icon")

    # =========================================================
    # SHEET 3: CITY & IOT ILLUSTRATIONS (1672 x 941)
    # =========================================================
    print("\n>>> Extracting Sheet 3: City & IoT Illustrations...")
    s3 = cv2.imread(sheet_paths[3])

    # Row 1: Landscapes & Poles
    save_asset(clean_alpha_extract(s3[55:285, 25:545]), "city", "city-skyline-bridge-panorama", "03-city-iot", "City Skyline and Bridge Grand Panorama", "illustration")
    save_asset(clean_alpha_extract(s3[65:285, 595:895]), "city", "city-bridge", "03-city-iot", "Bridge River Crossing Standalone Illustration", "illustration")
    save_asset(clean_alpha_extract(s3[65:285, 920:1210]), "city", "city-skyline", "03-city-iot", "Urban City Skyline Standalone Illustration", "illustration")
    save_asset(clean_alpha_extract(s3[50:285, 1270:1385]), "iot", "sensor-pole", "03-city-iot", "Standard IoT Sensor Pole Standalone Illustration", "illustration")
    save_asset(clean_alpha_extract(s3[95:285, 1440:1645]), "iot", "sensor-kiosk", "03-city-iot", "Public IoT Information Kiosk Station Standalone", "illustration")

    # Row 2: Compositions & Banners
    save_asset(clean_alpha_extract(s3[320:490, 20:575]), "compositions", "skyline-sensor-wave-banner", "03-city-iot", "Skyline, IoT Sensor Pole and Dynamic Wave Banner Composition", "composition")
    save_asset(clean_alpha_extract(s3[320:490, 595:1045]), "compositions", "landscape-pole-wave-banner", "03-city-iot", "Landscape, Solar Sensor Station and Environmental Wave Banner", "composition")
    save_asset(clean_alpha_extract(s3[320:490, 1070:1655]), "compositions", "city-bridge-wave-grand-panorama", "03-city-iot", "City, Bridge, and River Wave Grand Panoramic Banner", "composition")

    # Row 3: Isolated Items
    save_asset(clean_alpha_extract(s3[515:665, 20:195]), "iot", "sensor-station-combo", "03-city-iot", "Combined IoT Kiosk and Sensor Station", "illustration")
    save_asset(clean_alpha_extract(s3[530:665, 225:435]), "city", "trees-cluster", "03-city-iot", "Cluster of Urban Green Trees", "illustration")
    save_asset(clean_alpha_extract(s3[515:665, 455:725]), "city", "bridge-cityline-combo", "03-city-iot", "Bridge with City Skyline Silhouette", "illustration")
    save_asset(clean_alpha_extract(s3[540:665, 735:1015]), "city", "mountain-hills-landscape", "03-city-iot", "Hills and Natural Landscape Silhouette", "illustration")
    save_asset(clean_alpha_extract(s3[530:665, 1030:1145]), "iot", "sensor-kiosk-solo", "03-city-iot", "Solo IoT Kiosk Station Variant", "illustration")
    save_asset(clean_alpha_extract(s3[500:665, 1195:1285]), "iot", "sensor-pole-solar", "03-city-iot", "Solar Powered Sensor Pole Variant", "illustration")
    save_asset(clean_alpha_extract(s3[500:665, 1350:1440]), "iot", "sensor-pole-tall", "03-city-iot", "Tall Commercial Sensor Pole Variant", "illustration")
    save_asset(clean_alpha_extract(s3[500:665, 1515:1605]), "iot", "sensor-pole-mast", "03-city-iot", "Mast High-Altitude Sensor Pole Variant", "illustration")

    # Row 4 & 5: Ornaments & Wave Patterns
    save_asset(clean_alpha_extract(s3[685:800, 435:580]), "patterns", "flying-birds", "03-city-iot", "Flying Birds Environmental Flock", "pattern")
    save_asset(clean_alpha_extract(s3[685:800, 605:885]), "patterns", "halftone-dots", "03-city-iot", "Halftone Red Dot Matrix Pattern", "pattern")
    save_asset(clean_alpha_extract(s3[695:795, 930:1030]), "patterns", "shield-target-radar", "03-city-iot", "Shield Target Radar Pattern", "pattern")
    save_asset(clean_alpha_extract(s3[700:795, 1070:1185]), "patterns", "wave-flow-ribbon", "03-city-iot", "Flowing Wave Ribbon Ornament", "pattern")
    save_asset(clean_alpha_extract(s3[690:795, 1510:1625]), "patterns", "sparkles-stars", "03-city-iot", "Sparkling Stars and Dust Particles", "pattern")
    save_asset(clean_alpha_extract(s3[825:935, 515:895]), "patterns", "horizontal-node-line", "03-city-iot", "Horizontal Data Track and Node Line", "pattern")
    save_asset(clean_alpha_extract(s3[835:935, 920:1335]), "patterns", "wave-mesh-sinusoid", "03-city-iot", "Dynamic Sinusoid Wave Mesh Flow", "pattern")

    # =========================================================
    # SHEET 4: PATTERNS, CONNECTORS, CHARTS & BADGES (1672 x 941)
    # =========================================================
    print("\n>>> Extracting Sheet 4: Patterns, Connectors, Charts & Badges...")
    s4 = cv2.imread(sheet_paths[4])

    # 01 Background Ornaments & Composites
    save_asset(clean_alpha_extract(s4[55:145, 20:560]), "patterns", "wave-flow-top", "04-patterns-connectors", "Top Header Flowing Wave Line", "pattern")
    save_asset(clean_alpha_extract(s4[155:275, 15:570]), "compositions", "skyline-wave-composite", "04-patterns-connectors", "Skyline and Wave Composite Hero Section", "composition")
    save_asset(clean_alpha_extract(s4[285:405, 15:570]), "compositions", "sensor-hills-wave-composite", "04-patterns-connectors", "Sensor Station and Hills Composite Section", "composition")
    save_asset(clean_alpha_extract(s4[410:495, 25:135]), "patterns", "halftone-dots-box", "04-patterns-connectors", "Decorative Halftone Dot Matrix Box", "pattern")
    save_asset(clean_alpha_extract(s4[410:495, 185:565]), "city", "mountain-fog-landscape", "04-patterns-connectors", "Mountain Landscape with Atmospheric Fog", "illustration")

    # 02 Connectors & Workflow Paths
    save_asset(clean_alpha_extract(s4[65:100, 630:1075]), "connectors", "connector-dotted-arrow", "04-patterns-connectors", "Straight Dotted Progress Arrow", "connector")
    save_asset(clean_alpha_extract(s4[110:145, 630:1075]), "connectors", "connector-dotted-circles", "04-patterns-connectors", "Dotted Circle-Node Connector Line", "connector")
    save_asset(clean_alpha_extract(s4[155:190, 630:1075]), "connectors", "connector-double-arrow", "04-patterns-connectors", "Double-Ended Bidirectional Arrow", "connector")
    save_asset(clean_alpha_extract(s4[195:260, 630:1075]), "connectors", "connector-numbered-1-5", "04-patterns-connectors", "Numbered 1-5 Step Workflow Line", "connector")
    save_asset(clean_alpha_extract(s4[265:385, 630:885]), "connectors", "connector-pathway-step", "04-patterns-connectors", "Elbow Step Connector Pathway", "connector")
    save_asset(clean_alpha_extract(s4[265:390, 895:1085]), "connectors", "connector-pathway-loop", "04-patterns-connectors", "U-Shaped Loop Connector Pathway", "connector")
    save_asset(clean_alpha_extract(s4[390:480, 630:930]), "connectors", "connector-rounded-box", "04-patterns-connectors", "Rounded Rectangular Workflow Boundary", "connector")

    # 03 Radar Target Badges
    save_asset(clean_alpha_extract(s4[325:425, 1115:1215]), "badges", "badge-radar-target-1", "04-patterns-connectors", "Radar Target Micro Badge 01", "badge")
    save_asset(clean_alpha_extract(s4[325:425, 1220:1315]), "badges", "badge-radar-target-2", "04-patterns-connectors", "Radar Target Micro Badge 02", "badge")
    save_asset(clean_alpha_extract(s4[325:425, 1320:1415]), "badges", "badge-radar-target-3", "04-patterns-connectors", "Radar Target Micro Badge 03", "badge")
    save_asset(clean_alpha_extract(s4[325:425, 1420:1515]), "badges", "badge-radar-target-4", "04-patterns-connectors", "Radar Target Micro Badge 04", "badge")
    save_asset(clean_alpha_extract(s4[325:425, 1520:1655]), "badges", "badge-radar-target-5", "04-patterns-connectors", "Radar Target Micro Badge 05", "badge")

    # 04 Wave Line Variants
    save_asset(clean_alpha_extract(s4[560:635, 15:285]), "patterns", "wave-flow-01", "04-patterns-connectors", "Flowing Wave Line Variant 01", "pattern")
    save_asset(clean_alpha_extract(s4[640:715, 15:285]), "patterns", "wave-flow-02", "04-patterns-connectors", "Flowing Wave Line Variant 02", "pattern")
    save_asset(clean_alpha_extract(s4[720:795, 15:285]), "patterns", "wave-flow-03", "04-patterns-connectors", "Flowing Wave Line Variant 03", "pattern")
    save_asset(clean_alpha_extract(s4[560:635, 290:580]), "patterns", "wave-flow-04", "04-patterns-connectors", "Flowing Wave Line Variant 04", "pattern")
    save_asset(clean_alpha_extract(s4[640:715, 290:580]), "patterns", "wave-flow-05", "04-patterns-connectors", "Flowing Wave Line Variant 05", "pattern")
    save_asset(clean_alpha_extract(s4[720:795, 290:580]), "patterns", "wave-flow-06", "04-patterns-connectors", "Flowing Wave Line Variant 06", "pattern")

    # 05 Step & Progress Markers & Dividers
    save_asset(clean_alpha_extract(s4[570:640, 630:820]), "connectors", "step-markers-1-2-3", "04-patterns-connectors", "Step Markers 1-2-3 Sequence", "connector")
    save_asset(clean_alpha_extract(s4[570:640, 830:1080]), "connectors", "progress-status-dots", "04-patterns-connectors", "Progress Status Indicator Dots", "connector")
    save_asset(clean_alpha_extract(s4[665:725, 620:1085]), "patterns", "divider-shield-ornament", "04-patterns-connectors", "Section Divider with DustGuard Shield Ornament", "pattern")
    save_asset(clean_alpha_extract(s4[735:785, 710:875]), "patterns", "divider-heart-ornament", "04-patterns-connectors", "Section Divider with Heart Ornament", "pattern")
    save_asset(clean_alpha_extract(s4[735:785, 885:1085]), "patterns", "divider-speech-ornament", "04-patterns-connectors", "Section Divider with Chat Bubble Ornament", "pattern")
    save_asset(clean_alpha_extract(s4[795:835, 620:1085]), "patterns", "divider-dot-line", "04-patterns-connectors", "Dotted Section Divider Line", "pattern")

    # 06 Data & Chart Micro Assets
    save_asset(clean_alpha_extract(s4[565:660, 1115:1660]), "charts", "chart-bars-group", "04-patterns-connectors", "Analytical Bar Chart Metric Group", "chart")
    save_asset(clean_alpha_extract(s4[665:745, 1115:1660]), "charts", "chart-sparklines-group", "04-patterns-connectors", "Real-Time Sensor Sparklines Group", "chart")
    save_asset(clean_alpha_extract(s4[745:835, 1115:1660]), "charts", "chart-donuts-group", "04-patterns-connectors", "Progress Status Donut Percentage Charts (25%, 50%, 75%, 100%)", "chart")

    # 07 Spark Particles & Dot Textures
    save_asset(clean_alpha_extract(s4[840:930, 15:140]), "patterns", "particle-scatter-01", "04-patterns-connectors", "Air Particle Scatter Texture 01", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 150:280]), "patterns", "particle-scatter-02", "04-patterns-connectors", "Air Particle Scatter Texture 02", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 290:400]), "patterns", "particle-scatter-03", "04-patterns-connectors", "Air Particle Scatter Texture 03", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 410:520]), "patterns", "particle-dense-burst", "04-patterns-connectors", "Radial Dust Particle Dense Burst", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 530:620]), "patterns", "particle-halftone-sphere", "04-patterns-connectors", "Halftone Particle Sphere Texture", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 630:755]), "patterns", "particle-halftone-rect", "04-patterns-connectors", "Halftone Particle Rectangle Texture", "pattern")
    save_asset(clean_alpha_extract(s4[840:930, 765:1085]), "patterns", "particle-wave-flow", "04-patterns-connectors", "Flowing Air Particle Wave Texture", "pattern")

    # =========================================================
    # SHEET 5: COMMUNITY & PEOPLE (1448 x 1086)
    # =========================================================
    print("\n>>> Extracting Sheet 5: Community & People...")
    s5 = cv2.imread(sheet_paths[5])

    # Row 1: Top People Illustrations
    save_asset(clean_alpha_extract(s5[140:375, 45:475]), "people", "youth-group-back", "05-community-people", "Youth Group Looking Forward from Behind", "illustration")
    save_asset(clean_alpha_extract(s5[140:375, 485:865]), "people", "youth-trio-front", "05-community-people", "Youth Trio Standing Together Front View", "illustration")
    save_asset(clean_alpha_extract(s5[140:375, 880:1165]), "people", "tree-planting", "05-community-people", "Youth Volunteers Planting Young Tree", "illustration")
    save_asset(clean_alpha_extract(s5[140:375, 1170:1415]), "people", "litter-cleanup", "05-community-people", "Youth Volunteer Cleaning Environmental Litter", "illustration")

    # Row 2: Community Role Badges (with Circle Background)
    save_asset(clean_alpha_extract(s5[420:585, 45:215]), "community", "badge-clb-moitruong", "05-community-people", "Role Badge: Environmental Youth Club (CLB Môi Trường)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 240:410]), "community", "badge-nhom-hanhdong", "05-community-people", "Role Badge: Direct Action Team (Nhóm Hành Động)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 435:605]), "community", "badge-cong-dong", "05-community-people", "Role Badge: Local Community (Cộng Đồng)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 630:800]), "community", "badge-cong-dong-quantam", "05-community-people", "Role Badge: Concerned Citizens (Cộng Đồng Quan Tâm)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 825:995]), "community", "badge-donvi-phuhop", "05-community-people", "Role Badge: Competent Authority (Đơn Vị Phù Hợp)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 1020:1190]), "community", "badge-hop-tac", "05-community-people", "Role Badge: Partnership & Alliances (Hợp Tác)", "badge")
    save_asset(clean_alpha_extract(s5[420:585, 1215:1385]), "community", "badge-nguoi-phutrach", "05-community-people", "Role Badge: Responsible Officer (Người Phụ Trách Có Trách Nhiệm)", "badge")

    # Row 3 & 4: Sub Action Characters & Bottom Illustrations
    save_asset(clean_alpha_extract(s5[830:980, 45:190]), "people", "youth-action-raise-hand", "05-community-people", "Youth Raising Hand to Take Civic Action", "illustration")
    save_asset(clean_alpha_extract(s5[830:980, 210:350]), "people", "youth-phone-report", "05-community-people", "Youth Using Smartphone to Report Environmental Hazard", "illustration")
    save_asset(clean_alpha_extract(s5[830:980, 370:510]), "people", "youth-tree-care", "05-community-people", "Youth Caring for Sapling", "illustration")
    save_asset(clean_alpha_extract(s5[830:980, 535:675]), "people", "youth-recycle-action", "05-community-people", "Youth Sorting Recyclable Waste", "illustration")
    save_asset(clean_alpha_extract(s5[820:1060, 700:1030]), "community", "youth-sensor-skyline", "05-community-people", "Community Members Standing by IoT Station and City Skyline", "illustration")
    save_asset(clean_alpha_extract(s5[840:1060, 1040:1400]), "community", "volunteer-team-huddle", "05-community-people", "Volunteer Team Celebrating Community Action Success", "illustration")

    # Save JSON manifest
    manifest_path = os.path.join(base_out, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    # Save Markdown documentation
    doc_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\docs"
    os.makedirs(doc_dir, exist_ok=True)
    doc_path = os.path.join(doc_dir, "landing-asset-manifest.md")
    with open(doc_path, "w", encoding="utf-8") as f:
        f.write("# DustGuard VN — Landing Page Asset Library Manifest\n\n")
        f.write(f"Tổng số asset đã trích xuất, khử nền và tối ưu hoá: **{len(manifest)} assets**\n\n")
        f.write("| STT | Asset Name | Category | File (WebP) | Type | Dimensions | File Size | Description |\n")
        f.write("|---|---|---|---|---|---|---|---|\n")
        for i, item in enumerate(manifest, 1):
            f.write(f"| {i} | `{item['asset']}` | `{item['category']}` | [`{item['file']}`](file://{os.path.join(base_out, item['category'], item['asset'] + '.webp')}) | {item['type']} | {item['dimensions']} | {item['size']} | {item['description']} |\n")

    # Generate HTML Visual Contact Sheet for checking all assets
    html_lines = [
        "<!DOCTYPE html>",
        "<html lang='vi'>",
        "<head>",
        "<meta charset='utf-8'>",
        "<title>DustGuard VN — Asset Library Preview</title>",
        "<style>",
        "  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 30px; }",
        "  h1 { color: #f1f5f9; margin-bottom: 8px; font-size: 26px; }",
        "  .subtitle { color: #94a3b8; font-size: 14px; margin-bottom: 24px; }",
        "  .category-title { font-size: 18px; color: #38bdf8; margin: 30px 0 12px 0; border-bottom: 1px solid #334155; padding-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }",
        "  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 14px; }",
        "  .card { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 12px; text-align: center; display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.15s, border-color 0.15s; }",
        "  .card:hover { transform: translateY(-2px); border-color: #0ea5e9; }",
        "  .img-box { height: 110px; display: flex; align-items: center; justify-content: center; background: #fdfbf7; border-radius: 6px; padding: 8px; margin-bottom: 10px; }",
        "  .img-box img { max-height: 100%; max-width: 100%; object-fit: contain; }",
        "  .name { font-size: 11px; font-weight: 600; color: #e2e8f0; word-break: break-all; margin-bottom: 4px; }",
        "  .meta { font-size: 10px; color: #64748b; }",
        "  .tag { display: inline-block; background: #0369a1; color: #e0f2fe; padding: 2px 6px; border-radius: 4px; font-size: 9px; margin-top: 4px; }",
        "</style>",
        "</head>",
        "<body>",
        "  <h1>DustGuard VN — Asset Library Preview</h1>",
        f"  <div class='subtitle'>Tổng cộng {len(manifest)} assets độc lập được trích xuất hoàn hảo từ 5 sheet chuẩn reference.</div>"
    ]

    # Group by category
    categories = {}
    for item in manifest:
        cat = item["category"]
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(item)

    for cat, items in categories.items():
        html_lines.append(f"<div class='category-title'>{cat} ({len(items)} items)</div>")
        html_lines.append("<div class='grid'>")
        for item in items:
            html_lines.append(f"""
            <div class='card'>
              <div class='img-box'>
                <img src='{cat}/{item['asset']}.webp' alt='{item['asset']}'>
              </div>
              <div>
                <div class='name'>{item['asset']}</div>
                <div class='meta'>{item['dimensions']} • {item['size']}</div>
                <span class='tag'>{item['type']}</span>
              </div>
            </div>
            """)
        html_lines.append("</div>")

    html_lines.append("</body></html>")

    preview_html_path = os.path.join(base_out, "dustguard-assets-preview.html")
    with open(preview_html_path, "w", encoding="utf-8") as f:
        f.write("\n".join(html_lines))

    print(f"\n=======================================================")
    print(f"SUCCESS: Extracted and saved {len(manifest)} production-ready assets!")
    print(f"Manifest JSON: {manifest_path}")
    print(f"Manifest MD: {doc_path}")
    print(f"Preview HTML: {preview_html_path}")
    print("=======================================================")

if __name__ == "__main__":
    run_asset_extraction()
