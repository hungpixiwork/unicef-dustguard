import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SRC_DIR = path.resolve(__dirname, '../src');

function getAllFiles(dir, exts = ['.js', '.jsx', '.ts', '.tsx']) {
  let files = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files = files.concat(getAllFiles(fullPath, exts));
    } else if (exts.includes(path.extname(entry.name))) {
      files.push(fullPath);
    }
  }
  return files;
}

const allFiles = getAllFiles(SRC_DIR);
console.log(`Auditing ${allFiles.length} source files in ${SRC_DIR}...`);

const issues = [];

// 1. Scan for REEXPORT_DEFAULT_UNDEFINED / DEFAULT_EXPORT_UNDEFINED
allFiles.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split(/\r?\n/);
  
  const reExportedNames = new Set();
  const reExportRegex = /export\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]/g;
  let match;
  while ((match = reExportRegex.exec(content)) !== null) {
    const names = match[1].split(',').map(s => s.trim());
    names.forEach(n => {
      const parts = n.split(/\s+as\s+/);
      const exportedName = parts[parts.length - 1].trim();
      if (exportedName) reExportedNames.add(exportedName);
    });
  }

  const localDeclarations = new Set();
  // match import forms:
  // import A from '...'
  // import { B, C as D } from '...'
  // import * as E from '...'
  // import A, { B } from '...'
  const importLines = lines.filter(l => l.trim().startsWith('import '));
  importLines.forEach(line => {
    // import React, { useState } from 'react'
    const defaultMatch = line.match(/import\s+([A-Za-z0-9_$]+)\s*(?:,\s*\{|\s+from)/);
    if (defaultMatch) localDeclarations.add(defaultMatch[1]);

    const namedMatch = line.match(/\{([^}]+)\}/);
    if (namedMatch) {
      namedMatch[1].split(',').forEach(n => {
        const parts = n.trim().split(/\s+as\s+/);
        const name = parts[parts.length - 1].trim();
        if (name) localDeclarations.add(name);
      });
    }

    const starMatch = line.match(/\*\s+as\s+([A-Za-z0-9_$]+)/);
    if (starMatch) localDeclarations.add(starMatch[1]);
  });

  const declRegex = /(?:const|let|var|function|class)\s+([A-Za-z0-9_$]+)/g;
  while ((match = declRegex.exec(content)) !== null) {
    localDeclarations.add(match[1]);
  }

  const exportDefaultRegex = /^[\s]*export\s+default\s+([A-Za-z0-9_$]+)\s*;?/gm;
  while ((match = exportDefaultRegex.exec(content)) !== null) {
    const id = match[1];
    if (['null', 'true', 'false', 'undefined', 'function', 'class'].includes(id)) continue;
    
    const lineIndex = lines.findIndex(l => l.includes(`export default ${id}`));
    const lineNum = lineIndex !== -1 ? lineIndex + 1 : 0;

    if (!localDeclarations.has(id)) {
      if (reExportedNames.has(id)) {
        issues.push({
          type: 'REEXPORT_DEFAULT_UNDEFINED',
          file,
          relPath: path.relative(SRC_DIR, file).replace(/\\/g, '/'),
          line: lineNum,
          identifier: id,
          message: `\`${id}\` is re-exported via \`export { ${id} } from '...'\` but NOT imported into local scope. \`export default ${id}\` causes ReferenceError: ${id} is not defined.`
        });
      } else {
        issues.push({
          type: 'DEFAULT_EXPORT_UNDEFINED',
          file,
          relPath: path.relative(SRC_DIR, file).replace(/\\/g, '/'),
          line: lineNum,
          identifier: id,
          message: `\`export default ${id}\` is used, but \`${id}\` is not defined or imported in this file!`
        });
      }
    }
  }
});

console.log(`\n=== Export Default Reference Issues (${issues.length}) ===`);
issues.forEach(iss => {
  console.log(`[${iss.type}] ${iss.relPath}:${iss.line} -> ${iss.message}`);
});
