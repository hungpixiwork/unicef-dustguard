#!/usr/bin/env node
/**
 * DustGuard VN — Claim Integrity Linter & Audit Tool (SSOT)
 * Scans the codebase for high-risk overclaims (Academic, Legal, Government, Security, Sensor, AI)
 * and classifies them into Class A (Controlled), Class B (Assisted), Class C (External Authority), Class D (Fabricated).
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const REPO_ROOT = path.resolve(ROOT_DIR, '..');

// High-risk claim definitions
const HIGH_RISK_PATTERNS = [
  {
    id: 'ACAD-01',
    name: 'Hardcoded Academic Credits / ĐRL',
    regex: /(4\.0\s*tín\s*chỉ|80\s*đối\s*soát|80\s*điểm\s*rèn\s*luyện|80\s*ĐRL|quy\s*đổi\s*ra\s*tín\s*chỉ|nhận\s*4\.0\s*tín\s*chỉ)/i,
    classification: 'CLASS C / D',
    severity: 'P0',
    remedy: 'Replace with Verified Activity Hours & neutral Activity Record'
  },
  {
    id: 'LEGAL-01',
    name: 'Uncertified Digital Signature as Legal State Signature',
    regex: /(chứng\s*nhận\s*chữ\s*ký\s*số\s*quốc\s*gia|chữ\s*ký\s*số\s*pháp\s*lý|ký\s*số\s*chính\s*thức\s*theo\s*nghị\s*định\s*30)/i,
    classification: 'CLASS C',
    severity: 'P0',
    remedy: 'Rename to Integrity Hash / Verification Hash (Mã băm toàn vẹn HMAC-SHA256)'
  },
  {
    id: 'GOV-01',
    name: 'Fabricated Government Authority / National Database Claim',
    regex: /(cơ\s*sở\s*dữ\s*liệu\s*quốc\s*gia\s*dustguard|ủy\s*ban\s*chứng\s*nhận\s*tác\s*động\s*thanh\s*niên)/i,
    classification: 'CLASS D',
    severity: 'P0',
    remedy: 'Remove fabricated authority name; replace with neutral internal terminology'
  },
  {
    id: 'SEC-01',
    name: 'Absolute Privacy / Unbreakable Security Claims',
    regex: /(100%\s*anonymous|100%\s*secure|cannot\s*be\s*hacked|ẩn\s*danh\s*tuyệt\s*đối|bảo\s*mật\s*100%)/i,
    classification: 'CLASS D',
    severity: 'P1',
    remedy: 'Replace with specific technical controls (RBAC, SHA-256 integrity, privacy by role)'
  },
  {
    id: 'SCALE-01',
    name: 'Unverified Nationwide Scale / Absolute Adoption',
    regex: /(hàng\s*triệu\s*người\s*dùng\s*toàn\s*quốc|triển\s*khai\s*toàn\s*quốc\s*chính\s*thức)/i,
    classification: 'CLASS D',
    severity: 'P2',
    remedy: 'Replace with designed for scale / modular extensible architecture'
  }
];

// Allowlisted files (documentation of rules, audit logs, seed legal references)
const ALLOWLISTED_FILES = [
  'docs/CLAIM_INTEGRITY_POLICY.md',
  'docs/CLAIM_INTEGRITY_AUDIT_REPORT.md',
  'Prompt Antigravity',
  'scripts/audit-claims.js',
  'legal-source-seeds.js',
  '03_Legal_Decrees_Seeds_Raw_Text.json',
  '03_Real_Seeded_Legal_Documents_From_DB.json'
];

const SCAN_DIRS = [
  path.join(ROOT_DIR, 'src'),
  path.join(ROOT_DIR, 'server'),
  path.join(ROOT_DIR, 'scripts')
];

function isAllowlisted(filePath) {
  const norm = filePath.replace(/\\/g, '/');
  return ALLOWLISTED_FILES.some(allowed => norm.includes(allowed));
}

function scanFile(filePath) {
  if (isAllowlisted(filePath)) return [];
  
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');
  const findings = [];

  lines.forEach((line, index) => {
    HIGH_RISK_PATTERNS.forEach(pattern => {
      if (pattern.regex.test(line)) {
        findings.push({
          file: path.relative(REPO_ROOT, filePath).replace(/\\/g, '/'),
          line: index + 1,
          id: pattern.id,
          name: pattern.name,
          severity: pattern.severity,
          classification: pattern.classification,
          snippet: line.trim().slice(0, 100),
          remedy: pattern.remedy
        });
      }
    });
  });

  return findings;
}

function walkDir(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (!['node_modules', '.git', 'dist', 'build', '.wrangler'].includes(file)) {
        results = results.concat(walkDir(fullPath));
      }
    } else if (/\.(js|jsx|ts|tsx|json|html|md)$/.test(file)) {
      results.push(fullPath);
    }
  });
  return results;
}

export function runAudit() {
  console.log('========================================================');
  console.log('🛡️  DUSTGUARD VN — CLAIM INTEGRITY AUDIT LINTER');
  console.log('========================================================');

  let allFiles = [];
  SCAN_DIRS.forEach(d => {
    allFiles = allFiles.concat(walkDir(d));
  });

  console.log(`Scanning ${allFiles.length} files across src/, server/, scripts/...`);

  let totalFindings = [];
  allFiles.forEach(f => {
    const fileFindings = scanFile(f);
    if (fileFindings.length > 0) {
      totalFindings = totalFindings.concat(fileFindings);
    }
  });

  if (totalFindings.length === 0) {
    console.log('\n✅ PASS: 0 Overclaims detected in scanned directories!');
    console.log('Release Gate: CLAIM INTEGRITY 100% SATISFIED\n');
    return { pass: true, count: 0, findings: [] };
  }

  console.log(`\n⚠️  FOUND ${totalFindings.length} CLAIM INTEGRITY FINDINGS:\n`);
  console.table(totalFindings.map(f => ({
    File: `${f.file}:${f.line}`,
    Severity: f.severity,
    Category: f.name,
    Class: f.classification,
    Snippet: f.snippet
  })));

  const p0Count = totalFindings.filter(f => f.severity === 'P0').length;
  const p1Count = totalFindings.filter(f => f.severity === 'P1').length;
  console.log(`\nSummary: P0=${p0Count}, P1=${p1Count}, Total=${totalFindings.length}`);

  return { pass: false, count: totalFindings.length, p0Count, p1Count, findings: totalFindings };
}

// Execute if run via CLI
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = runAudit();
  if (!result.pass && result.p0Count > 0) {
    process.exit(1);
  }
}
