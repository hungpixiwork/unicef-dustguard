import os
import json
import math
from PIL import Image, ImageDraw, ImageFont

def generate_preview_contact_sheet():
    base_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\public\assets\landing"
    manifest_path = os.path.join(base_dir, "manifest.json")
    
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    # We will build an organized contact sheet
    # Cell size: 220px wide x 180px tall
    cell_w = 220
    cell_h = 180
    cols = 6
    
    # Group items by category
    categories = {}
    for item in manifest:
        cat = item["category"]
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(item)

    # Calculate total height
    header_h = 100
    cat_header_h = 50
    total_rows = 0
    for cat, items in categories.items():
        rows = math.ceil(len(items) / float(cols))
        total_rows += rows

    total_w = cols * cell_w + 60
    total_h = header_h + len(categories) * cat_header_h + total_rows * cell_h + 80

    sheet = Image.new("RGBA", (total_w, total_h), (253, 251, 247, 255)) # Cream civic background
    draw = ImageDraw.Draw(sheet)

    # Try font or default
    try:
        font_title = ImageFont.truetype("arial.ttf", 26)
        font_cat = ImageFont.truetype("arialbd.ttf", 18)
        font_label = ImageFont.truetype("arial.ttf", 11)
        font_meta = ImageFont.truetype("arial.ttf", 9)
    except:
        font_title = ImageFont.load_default()
        font_cat = ImageFont.load_default()
        font_label = ImageFont.load_default()
        font_meta = ImageFont.load_default()

    # Draw Title
    draw.rectangle([(0, 0), (total_w, 80)], fill=(35, 27, 20, 255)) # Dark ink
    draw.text((30, 24), f"DustGuard VN — Complete Asset Library Contact Sheet ({len(manifest)} Assets)", fill=(253, 251, 247, 255), font=font_title)

    curr_y = header_h

    for cat, items in categories.items():
        # Category Banner
        draw.rectangle([(30, curr_y), (total_w - 30, curr_y + 36)], fill=(13, 111, 100, 255)) # Teal
        draw.text((45, curr_y + 8), f"{cat.upper()} ({len(items)} items)", fill=(255, 255, 255, 255), font=font_cat)
        curr_y += cat_header_h

        # Render items in grid
        for idx, item in enumerate(items):
            c_col = idx % cols
            c_row = idx // cols
            
            x = 30 + c_col * cell_w
            y = curr_y + c_row * cell_h
            
            # Card background
            draw.rectangle([(x + 4, y + 4), (x + cell_w - 4, y + cell_h - 4)], fill=(255, 255, 255, 255), outline=(220, 215, 205, 255), width=1)
            
            # Load asset image
            img_path = os.path.join(base_dir, cat, f"{item['asset']}.png")
            if os.path.exists(img_path):
                thumb = Image.open(img_path).convert("RGBA")
                # Scale to fit max 190x100
                thumb.thumbnail((cell_w - 30, 100), Image.Resampling.LANCZOS)
                
                # Center inside box (y: +10 .. +110)
                thumb_x = x + (cell_w - thumb.width) // 2
                thumb_y = y + 10 + (100 - thumb.height) // 2
                
                sheet.alpha_composite(thumb, (thumb_x, thumb_y))

            # Label underneath
            label_text = item["asset"]
            if len(label_text) > 28:
                label_text = label_text[:26] + "..."
            draw.text((x + 10, y + 120), label_text, fill=(35, 27, 20, 255), font=font_label)
            draw.text((x + 10, y + 140), f"{item['dimensions']} • {item['size']}", fill=(120, 115, 105, 255), font=font_meta)

        rows = math.ceil(len(items) / float(cols))
        curr_y += rows * cell_h + 20

    out_sheet_path = os.path.join(base_dir, "dustguard-assets-preview.png")
    sheet.convert("RGB").save(out_sheet_path, "PNG", optimize=True)
    print(f"Saved contact sheet: {out_sheet_path} ({total_w}x{total_h})")

if __name__ == "__main__":
    generate_preview_contact_sheet()
