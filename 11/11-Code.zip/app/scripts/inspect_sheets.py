import os
import cv2
import numpy as np
from PIL import Image

def generate_annotated_panels():
    sheets = {
        "sheet1": r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_10 21 thg 8, 2026 (1).png",
        "sheet2": r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (2).png",
        "sheet3": r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (3).png",
        "sheet4": r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_11 21 thg 8, 2026 (4).png",
        "sheet5": r"C:\Users\ppnh1\Downloads\ChatGPT Image 23_52_12 21 thg 8, 2026 (5).png"
    }
    
    out_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets"
    os.makedirs(out_dir, exist_ok=True)
    
    for name, path in sheets.items():
        img = cv2.imread(path)
        h, w = img.shape[:2]
        
        # Create high-visibility coordinate overlay
        overlay = img.copy()
        # Draw 50px minor grid, 100px major grid
        for x in range(0, w, 50):
            color = (0, 0, 255) if x % 100 == 0 else (200, 200, 200)
            thick = 2 if x % 100 == 0 else 1
            cv2.line(overlay, (x, 0), (x, h), color, thick)
            if x % 100 == 0:
                cv2.putText(overlay, str(x), (x + 2, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                cv2.putText(overlay, str(x), (x + 2, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                
        for y in range(0, h, 50):
            color = (0, 0, 255) if y % 100 == 0 else (200, 200, 200)
            thick = 2 if y % 100 == 0 else 1
            cv2.line(overlay, (0, y), (w, y), color, thick)
            if y % 100 == 0:
                cv2.putText(overlay, str(y), (5, y + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                cv2.putText(overlay, str(y), (w - 55, y + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                
        cv2.imwrite(os.path.join(out_dir, f"{name}_annotated.png"), overlay)
        print(f"Generated {name}_annotated.png ({w}x{h})")

if __name__ == "__main__":
    generate_annotated_panels()
