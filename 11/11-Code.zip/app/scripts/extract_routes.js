import fs from 'fs';
import path from 'path';

const workerContent = fs.readFileSync('D:/07-Competitions-Hackathons/unicef-dustguard/app/server/worker.js', 'utf8');

console.log('=== WORKER.JS ROUTES ===');
const workerRouteMatches = workerContent.match(/(app\.(get|post|put|patch|delete)|router\.(get|post|put|patch|delete))\s*\(\s*['"`]([^'"`]+)['"`]/gi);
if (workerRouteMatches) {
  workerRouteMatches.forEach(m => console.log(m));
}

console.log('\n=== ROUTES FOLDER ROUTES ===');
const routesDir = 'D:/07-Competitions-Hackathons/unicef-dustguard/app/server/routes';
function scanRoutes(dir) {
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) {
      scanRoutes(full);
    } else if (f.endsWith('.js')) {
      const c = fs.readFileSync(full, 'utf8');
      const matches = c.match(/(router\.(get|post|put|patch|delete))\s*\(\s*['"`]([^'"`]+)['"`]/gi);
      if (matches) {
        console.log(`[${f}]`);
        matches.forEach(m => console.log(`  ${m}`));
      }
    }
  }
}
scanRoutes(routesDir);
