import os

def generate_debug_html():
    base_dir = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets\catalog"
    subdirs = ["sheet1_brand_ui", "sheet2_icons", "sheet3_city_iot", "sheet4_patterns_connectors", "sheet5_community_people"]
    
    html = ["<!DOCTYPE html><html><head><meta charset='utf-8'><title>Catalog Debug</title>",
            "<style>body { font-family: sans-serif; background: #222; color: #fff; padding: 20px; }",
            ".section { margin-bottom: 40px; background: #333; padding: 20px; border-radius: 8px; }",
            ".grid { display: flex; flex-wrap: wrap; gap: 15px; }",
            ".card { background: #fff; color: #000; padding: 10px; border-radius: 6px; text-align: center; }",
            ".card img { max-height: 180px; max-width: 250px; object-fit: contain; display: block; margin: 0 auto; background: #eee; }",
            ".card p { margin: 5px 0 0 0; font-size: 11px; word-break: break-all; max-width: 250px; }",
            "</style></head><body><h1>DustGuard Sheet Catalog Analysis</h1>"]
            
    for s in subdirs:
        s_path = os.path.join(base_dir, s)
        if not os.path.exists(s_path):
            continue
        files = sorted(os.listdir(s_path))
        html.append(f"<div class='section'><h2>{s} ({len(files)} items)</h2><div class='grid'>")
        for f in files:
            if f.endswith(".png"):
                rel_path = f"catalog/{s}/{f}"
                html.append(f"<div class='card'><img src='{rel_path}'><p>{f}</p></div>")
        html.append("</div></div>")
        
    html.append("</body></html>")
    
    out_file = r"d:\07-Competitions-Hackathons\unicef-dustguard\app\scripts\debug_sheets\index.html"
    with open(out_file, "w", encoding="utf-8") as fp:
        fp.write("\n".join(html))
        
    print(f"Generated {out_file}")

if __name__ == "__main__":
    generate_debug_html()
