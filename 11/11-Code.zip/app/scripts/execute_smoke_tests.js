import fs from 'fs';
import path from 'path';

const LOCAL_BASE = 'http://127.0.0.1:8787';
const REMOTE_BASE = 'https://dust-guard-vn.ppnh10092002.workers.dev';

const testCases = [
  // Health
  { name: 'Worker Liveness Check', path: '/health', method: 'GET', expectedStatus: 200, category: 'Health' },
  { name: 'API & D1 Health Check', path: '/api/v1/health', method: 'GET', expectedStatus: 200, category: 'Health' },
  { name: 'Legacy API Health Check', path: '/api/health', method: 'GET', expectedStatus: 200, category: 'Health' },
  { name: 'Runtime Config Probe', path: '/api/config', method: 'GET', expectedStatus: 200, category: 'Health' },

  // Auth - Login
  {
    name: 'Auth Login - Demo Admin (Success)',
    path: '/api/auth/login',
    method: 'POST',
    body: { email: 'admin@dustguard.vn', password: '123456' },
    expectedStatus: 200,
    category: 'Auth'
  },
  {
    name: 'Auth V1 Login - Demo Admin (Success)',
    path: '/api/v1/auth/login',
    method: 'POST',
    body: { email: 'admin@dustguard.vn', password: '123456' },
    expectedStatus: 200,
    category: 'Auth'
  },
  {
    name: 'Auth Login - Invalid Credentials',
    path: '/api/auth/login',
    method: 'POST',
    body: { email: 'invalid@dustguard.vn', password: 'wrongpassword' },
    expectedStatus: 401,
    category: 'Auth'
  },
  {
    name: 'Auth Login - Missing Fields',
    path: '/api/auth/login',
    method: 'POST',
    body: {},
    expectedStatus: 400,
    category: 'Auth'
  },

  // Auth - Register
  {
    name: 'Auth Register - Valid User',
    path: '/api/auth/register',
    method: 'POST',
    body: { email: `smoke_test_${Date.now()}@dustguard.vn`, password: 'password123', full_name: 'Smoke Test User' },
    expectedStatus: 200,
    category: 'Auth'
  },
  {
    name: 'Auth V1 Register - Missing Fields',
    path: '/api/v1/auth/register',
    method: 'POST',
    body: { email: 'test@dustguard.vn' },
    expectedStatus: 400,
    category: 'Auth'
  },

  // Auth - Me & Logout
  { name: 'Auth Me - Session User', path: '/api/auth/me', method: 'GET', expectedStatus: 200, category: 'Auth' },
  { name: 'Auth V1 Me - Session User', path: '/api/v1/auth/me', method: 'GET', expectedStatus: 200, category: 'Auth' },
  { name: 'Auth Logout', path: '/api/auth/logout', method: 'POST', expectedStatus: 200, category: 'Auth' },

  // Domain APIs
  { name: 'Get Sites List (V1)', path: '/api/v1/sites', method: 'GET', expectedStatus: 200, category: 'Domain API' },
  { name: 'Get Public Location Sites', path: '/api/public/location-sites', method: 'GET', expectedStatus: 200, category: 'Domain API' },
  {
    name: 'Ingest Telemetry Reading',
    path: '/api/v1/telemetry',
    method: 'POST',
    body: { sensorCode: 'SN-001', pm10: 42.5, pm25: 18.2 },
    expectedStatus: 200,
    category: 'Domain API'
  },
  {
    name: 'Ingest Telemetry Reading (Invalid Sensor)',
    path: '/api/v1/telemetry',
    method: 'POST',
    body: { sensorCode: 'INVALID_SENSOR_CODE', pm10: 10, pm25: 5 },
    expectedStatus: 404,
    category: 'Domain API'
  },
  { name: 'Get Complaints List (V1)', path: '/api/v1/complaints', method: 'GET', expectedStatus: 200, category: 'Domain API' },
  { name: 'Get Public Complaints List', path: '/api/public-complaints', method: 'GET', expectedStatus: 200, category: 'Domain API' },
  {
    name: 'Submit Public Complaint',
    path: '/api/public-complaints',
    method: 'POST',
    body: { citizenName: 'Công Dân Test', citizenPhone: '0987654321', description: 'Kiểm thử khói bụi tự động', dustLevel: 'HIGH' },
    expectedStatus: 200,
    category: 'Domain API'
  },
  { name: 'Get Dashboard Operations Metrics', path: '/api/v1/dashboard/operations', method: 'GET', expectedStatus: 200, category: 'Domain API' },
  { name: 'Nonexistent Endpoint Catch-all 404', path: '/api/v1/nonexistent-route-check', method: 'GET', expectedStatus: 404, category: 'Error Handling' }
];

async function runSingleTest(baseUrl, tc) {
  const url = `${baseUrl}${tc.path}`;
  const startTime = performance.now();
  try {
    const opts = {
      method: tc.method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'DustGuard-SmokeTest/1.0'
      }
    };
    if (tc.body) {
      opts.body = JSON.stringify(tc.body);
    }
    const res = await fetch(url, opts);
    const endTime = performance.now();
    const duration = Math.round(endTime - startTime);
    const status = res.status;
    let data;
    try {
      data = await res.json();
    } catch {
      data = await res.text();
    }
    const passed = status === tc.expectedStatus;
    return {
      name: tc.name,
      category: tc.category,
      path: tc.path,
      method: tc.method,
      expectedStatus: tc.expectedStatus,
      actualStatus: status,
      durationMs: duration,
      passed,
      responseSnippet: JSON.stringify(data).substring(0, 150)
    };
  } catch (err) {
    const endTime = performance.now();
    return {
      name: tc.name,
      category: tc.category,
      path: tc.path,
      method: tc.method,
      expectedStatus: tc.expectedStatus,
      actualStatus: 'ERR',
      durationMs: Math.round(endTime - startTime),
      passed: false,
      responseSnippet: err.message
    };
  }
}

async function main() {
  console.log('🚀 Running DustGuard VN Real HTTP Smoke Test Matrix...\n');

  console.log('1. Testing Local Wrangler Dev (http://127.0.0.1:8787)...');
  const localResults = [];
  for (const tc of testCases) {
    const res = await runSingleTest(LOCAL_BASE, tc);
    localResults.push(res);
    console.log(`  [${res.passed ? 'PASS' : 'FAIL'}] ${res.method} ${res.path} -> HTTP ${res.actualStatus} (${res.durationMs}ms)`);
  }

  console.log('\n2. Testing Remote Cloudflare Deployment (https://dust-guard-vn.ppnh10092002.workers.dev)...');
  const remoteResults = [];
  for (const tc of testCases) {
    const res = await runSingleTest(REMOTE_BASE, tc);
    remoteResults.push(res);
    console.log(`  [${res.passed ? 'PASS' : 'FAIL'}] ${res.method} ${res.path} -> HTTP ${res.actualStatus} (${res.durationMs}ms)`);
  }

  const report = {
    timestamp: new Date().toISOString(),
    localBase: LOCAL_BASE,
    remoteBase: REMOTE_BASE,
    localResults,
    remoteResults
  };

  fs.writeFileSync('./scripts/smoke_test_results.json', JSON.stringify(report, null, 2));
  console.log('\n✅ Results saved to scripts/smoke_test_results.json');
}

main();
