import Database from 'better-sqlite3';

const db = new Database('prisma/dev.db');
try {
  const info = db.prepare('PRAGMA table_info(audit_logs);').all();
  console.log('Columns in audit_logs:', info);
  const sql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='audit_logs'").get();
  console.log('SQL definition of audit_logs:', sql);

  const logs = db.prepare('SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 5').all();
  console.log('Last 5 rows in audit_logs:', logs);
} catch (err) {
  console.error(err);
} finally {
  db.close();
}
