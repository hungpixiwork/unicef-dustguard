import fs from 'fs';
import path from 'path';

function listServerRoutes(dir) {
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) {
      listServerRoutes(full);
    } else {
      console.log(path.relative('D:/07-Competitions-Hackathons/unicef-dustguard/app/server', full));
    }
  }
}

listServerRoutes('D:/07-Competitions-Hackathons/unicef-dustguard/app/server');
