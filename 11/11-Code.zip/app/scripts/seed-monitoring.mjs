import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.resolve('app/prisma/dev.db'));

console.log('Seeding 22 monitoring stations & 24h readings into D1 dev.db...');

const stationsSeed = [
  { code: 'TX-01', name: 'TX-01 · Thanh Xuân', siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân', address: 'Thanh Xuân, Hà Nội', ward: 'Thanh Xuân', pm25: 32, pm10: 54, status: 'ACTIVE' },
  { code: 'TX-02', name: 'TX-02 · Thanh Xuân', siteName: 'Dự án Vành Đai 3 - Đoạn qua Thanh Xuân', address: 'Thanh Xuân, Hà Nội', ward: 'Thanh Xuân', pm25: 146, pm10: 218, status: 'ACTIVE' },
  { code: 'CG-01', name: 'CG-01 · Cầu Giấy', siteName: 'Tòa nhà hỗn hợp FLC Cầu Giấy', address: 'Cầu Giấy, Hà Nội', ward: 'Cầu Giấy', pm25: 28, pm10: 49, status: 'ACTIVE' },
  { code: 'CG-02', name: 'CG-02 · Cầu Giấy', siteName: 'Khu phức hợp Căn hộ Cao cấp Emerald Prime', address: 'Số 68 Đường Cầu Giấy, Cầu Giấy', ward: 'Cầu Giấy', pm25: 38, pm10: 62, status: 'ACTIVE' },
  { code: 'CG-03', name: 'CG-03 · Cầu Giấy', siteName: 'Dự án Capital Square - Cầu Giấy', address: 'Cầu Giấy, Hà Nội', ward: 'Cầu Giấy', pm25: 98, pm10: 152, status: 'ACTIVE' },
  { code: 'LB-01', name: 'LB-01 · Long Biên', siteName: 'Trung tâm thương mại AEON Mall Long Biên', address: 'Long Biên, Hà Nội', ward: 'Long Biên', pm25: 82, pm10: 121, status: 'ACTIVE' },
  { code: 'LB-02', name: 'LB-02 · Long Biên', siteName: 'Dự án Sunshine Riverside', address: 'Long Biên, Hà Nội', ward: 'Long Biên', pm25: 58, pm10: 92, status: 'ACTIVE' },
  { code: 'HM-01', name: 'HM-01 · Hoàng Mai', siteName: 'Dự án Nút giao Vành đai 2.5', address: 'Hoàng Mai, Hà Nội', ward: 'Hoàng Mai', pm25: 42, pm10: 68, status: 'ACTIVE' },
  { code: 'HM-02', name: 'HM-02 · Hoàng Mai', siteName: 'Khu đô thị Linh Đàm mở rộng', address: 'Hoàng Mai, Hà Nội', ward: 'Hoàng Mai', pm25: 79, pm10: 118, status: 'ACTIVE' },
  { code: 'HD-01', name: 'HD-01 · Hà Đông', siteName: 'Dự án Văn Phú Invest', address: 'Hà Đông, Hà Nội', ward: 'Hà Đông', pm25: 74, pm10: 112, status: 'ACTIVE' },
  { code: 'HD-02', name: 'HD-02 · Hà Đông', siteName: 'Khu Biệt thự Liền kề Green Oasis', address: 'Mỗ Lao, Hà Đông, Hà Nội', ward: 'Hà Đông', pm25: 35, pm10: 58, status: 'ACTIVE' },
  { code: 'BD-01', name: 'BD-01 · Ba Đình', siteName: 'Công trình Tuyến ĐS Đô thị Metro 3 Nhổn - Ga Hà Nội', address: 'Kim Mã, Ba Đình, Hà Nội', ward: 'Ba Đình', pm25: 36, pm10: 60, status: 'ACTIVE' },
  { code: 'BD-02', name: 'BD-02 · Ba Đình', siteName: 'Tòa nhà Văn phòng Liễu Giai', address: 'Liễu Giai, Ba Đình, Hà Nội', ward: 'Ba Đình', pm25: 29, pm10: 52, status: 'ACTIVE' },
  { code: 'HBT-01', name: 'HBT-01 · Hai Bà Trưng', siteName: 'Tổ hợp Thương mại Minh Khai', address: 'Minh Khai, Hai Bà Trưng, Hà Nội', ward: 'Hai Bà Trưng', pm25: 44, pm10: 72, status: 'ACTIVE' },
  { code: 'HBT-02', name: 'HBT-02 · Hai Bà Trưng', siteName: 'Dự án Cải tạo Thoát nước Đô thị', address: 'Bạch Mai, Hai Bà Trưng, Hà Nội', ward: 'Hai Bà Trưng', pm25: 39, pm10: 65, status: 'ACTIVE' },
  { code: 'NTL-01', name: 'NTL-01 · Nam Từ Liêm', siteName: 'Dự án Tổ hợp Văn phòng & Thương mại Landmark', address: 'Phạm Hùng, Nam Từ Liêm, Hà Nội', ward: 'Nam Từ Liêm', pm25: 85, pm10: 140, status: 'ACTIVE' },
  { code: 'NTL-02', name: 'NTL-02 · Nam Từ Liêm', siteName: 'Khu Đô thị Mới Mỹ Đình 2', address: 'Lê Đức Thọ, Nam Từ Liêm, Hà Nội', ward: 'Nam Từ Liêm', pm25: 35, pm10: 60, status: 'ACTIVE' },
  { code: 'BTL-01', name: 'BTL-01 · Bắc Từ Liêm', siteName: 'Công trường Cầu Thăng Long mở rộng', address: 'Bắc Từ Liêm, Hà Nội', ward: 'Bắc Từ Liêm', pm25: 48, pm10: 76, status: 'ACTIVE' },
  { code: 'TH-01', name: 'TH-01 · Tây Hồ', siteName: 'Khu biệt thự Tây Hồ Tây', address: 'Xuân La, Tây Hồ, Hà Nội', ward: 'Tây Hồ', pm25: 26, pm10: 45, status: 'ACTIVE' },
  { code: 'GL-01', name: 'GL-01 · Gia Lâm', siteName: 'Đại đô thị Ocean Park 1', address: 'Gia Lâm, Hà Nội', ward: 'Gia Lâm', pm25: 31, pm10: 50, status: 'ACTIVE' },
  { code: 'HD-03', name: 'HD-03 · Hoài Đức', siteName: 'KĐT Nam 32', address: 'Hoài Đức, Hà Nội', ward: 'Hoài Đức', pm25: 52, pm10: 88, status: 'ACTIVE' },
  { code: 'DP-01', name: 'DP-01 · Đan Phượng', siteName: 'Nhà máy gạch Hưng Thịnh', address: 'Đan Phượng, Hà Nội', ward: 'Đan Phượng', pm25: 49, pm10: 84, status: 'INACTIVE' }
];

const now = new Date();

for (const s of stationsSeed) {
  // Check or create Site
  let site = db.prepare('SELECT id FROM sites WHERE name = ? LIMIT 1').get(s.siteName);
  let siteId;
  if (!site) {
    siteId = `site-${s.code.toLowerCase()}`;
    db.prepare(`
      INSERT INTO sites (id, name, address, ward, dustRiskScore, riskLevel, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(siteId, s.siteName, s.address, s.ward, s.pm10 > 150 ? 87 : s.pm10 > 100 ? 74 : 45, s.pm10 > 150 ? 'HIGH' : 'MEDIUM', 'ACTIVE', now.toISOString(), now.toISOString());
  } else {
    siteId = site.id;
  }

  // Check or create Sensor
  let sensor = db.prepare('SELECT id FROM sensors WHERE code = ?').get(s.code);
  let sensorId;
  if (!sensor) {
    sensorId = `sen-${s.code.toLowerCase()}`;
    db.prepare(`
      INSERT INTO sensors (id, code, name, siteId, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(sensorId, s.code, s.name, siteId, s.status, now.toISOString(), now.toISOString());
  } else {
    sensorId = sensor.id;
    db.prepare(`UPDATE sensors SET status = ?, siteId = ? WHERE id = ?`).run(s.status, siteId, sensorId);
  }

  // Insert readings for the past 24h
  for (let h = 0; h < 24; h += 3) {
    const readingTime = new Date(now.getTime() - h * 3600 * 1000).toISOString();
    const readingId = `rd-${s.code.toLowerCase()}-${h}`;
    const variance = (h % 2 === 0 ? 1 : -1) * (h * 1.5);
    const calculatedPm10 = Math.max(20, Math.round(s.pm10 + variance));
    const calculatedPm25 = Math.max(10, Math.round(s.pm25 + variance * 0.6));

    const existingRd = db.prepare('SELECT id FROM sensor_readings WHERE id = ?').get(readingId);
    if (!existingRd) {
      db.prepare(`
        INSERT INTO sensor_readings (id, sensorId, pm10, pm25, timestamp)
        VALUES (?, ?, ?, ?, ?)
      `).run(readingId, sensorId, calculatedPm10, calculatedPm25, readingTime);
    }
  }
}

console.log('Seeding completed successfully!');
