import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function run() {
  try {
    console.log('Checking existing location data...');
    const regionCount = await prisma.administrativeRegion.count();
    const unitCount = await prisma.administrativeUnit.count();
    const provinceCount = await prisma.province.count();
    const wardCount = await prisma.ward.count();

    console.log(`Current counts in DB:
    - Regions: ${regionCount}
    - Units: ${unitCount}
    - Provinces: ${provinceCount}
    - Wards: ${wardCount}`);

    if (provinceCount > 0 && wardCount > 0) {
      console.log('✅ Administrative tables already populated. Skipping seed.');
      return;
    }

    const sqlPath = path.resolve('scratch/vietnamese-provinces-database/postgresql/postgres_ImportData_vn_units.sql');
    if (!fs.existsSync(sqlPath)) {
      console.error(`❌ SQL import file not found at: ${sqlPath}`);
      process.exit(1);
    }

    console.log(`📂 Reading SQL data from ${sqlPath}...`);
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');

    // Parse SQL file by splitting on semicolon
    const rawStatements = sqlContent.split(';');
    const statements = [];

    for (let raw of rawStatements) {
      // Strip block comments, line comments, and clean whitespace
      let clean = raw
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('--'))
        .join(' ')
        .trim();

      if (clean) {
        statements.push(clean);
      }
    }

    console.log(`⚡ Parsed ${statements.length} SQL statements to execute.`);

    console.log('🚀 Running inserts on Neon database. This may take a few seconds...');
    let successCount = 0;
    
    // We execute them sequentially to preserve order of dependency constraints
    for (const stmt of statements) {
      try {
        await prisma.$executeRawUnsafe(stmt);
        successCount++;
        if (successCount % 20 === 0 || successCount === statements.length) {
          console.log(`   Progress: [${successCount}/${statements.length}] statements executed.`);
        }
      } catch (err) {
        if (err.message.includes('23505') || err.message.includes('already exists') || err.message.includes('Unique constraint failed')) {
          successCount++;
          continue;
        }
        console.error(`❌ Failed to execute statement:\n${stmt.substring(0, 150)}...\nError:`, err.message);
        throw err;
      }
    }

    console.log('✅ Location seeding completed successfully!');
  } catch (err) {
    console.error('❌ Error during administrative seeding:', err);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

run();
