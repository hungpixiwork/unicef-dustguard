import fs from 'fs';
import path from 'path';

const ROOT = path.resolve('D:/07-Competitions-Hackathons/unicef-dustguard/app');
const SRC_DIR = path.join(ROOT, 'src');
const SERVER_DIR = path.join(ROOT, 'server');

function getFiles(dir, ext = ['.js', '.jsx', '.ts', '.tsx']) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    for (const item of list) {
      if (['node_modules', '.git', 'dist'].includes(item)) continue;
      const full = path.join(dir, item);
      const stat = fs.statSync(full);
      if (stat.isDirectory()) results = results.concat(getFiles(full, ext));
      else if (ext.some(e => item.endsWith(e))) results.push(full);
    }
  } catch (e) {}
  return results;
}

const allSrcFiles = getFiles(SRC_DIR);
const allServerFiles = getFiles(SERVER_DIR);

// 1. ROUTE AUDIT
const routePatterns = [
  /path=["']([^"']+)["']/g,
  /<Route[^>]*path=["']([^"']+)["']/g,
  /navigate\(["']([^"']+)["']\)/g,
  /to=["']([^"']+)["']/g,
  /href=["'](\/[^"']+)["']/g
];

const foundRoutes = {};
for (const file of allSrcFiles) {
  const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  const content = fs.readFileSync(file, 'utf8');
  for (const regex of routePatterns) {
    let match;
    while ((match = regex.exec(content)) !== null) {
      const route = match[1];
      if (route.startsWith('/') && !route.startsWith('/api') && !route.startsWith('/assets') && !route.includes('.')) {
        foundRoutes[route] = foundRoutes[route] || { definedIn: [], linkedFrom: [] };
        if (regex.source.includes('<Route') || regex.source.includes('path=')) {
          foundRoutes[route].definedIn.push(rel);
        } else {
          foundRoutes[route].linkedFrom.push(rel);
        }
      }
    }
  }
}

// 2. IMPORT GRAPH & UNUSED/DEAD CODE
const importMap = {};
const importedBy = {};

for (const file of allSrcFiles) {
  const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  importedBy[rel] = importedBy[rel] || [];
  const content = fs.readFileSync(file, 'utf8');
  const importRegex = /import\s+.*?from\s+['"]([^'"]+)['"]/g;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const importPath = match[1];
    if (importPath.startsWith('.')) {
      const resolved = path.normalize(path.join(path.dirname(file), importPath));
      let targetRel = path.relative(SRC_DIR, resolved).replace(/\\/g, '/');
      if (!path.extname(targetRel)) {
        // try .js, .jsx, /index.js, /index.jsx
        if (fs.existsSync(resolved + '.jsx')) targetRel += '.jsx';
        else if (fs.existsSync(resolved + '.js')) targetRel += '.js';
        else if (fs.existsSync(path.join(resolved, 'index.jsx'))) targetRel += '/index.jsx';
        else if (fs.existsSync(path.join(resolved, 'index.js'))) targetRel += '/index.js';
      }
      importMap[rel] = importMap[rel] || [];
      importMap[rel].push(targetRel);
      importedBy[targetRel] = importedBy[targetRel] || [];
      importedBy[targetRel].push(rel);
    }
  }
}

// 3. DOMAIN CONCEPT DUPLICATION
const concepts = {
  case: { regex: /\b(case|cases|Case|Cases)\b/g, count: 0, files: new Set() },
  complaint: { regex: /\b(complaint|complaints|Complaint|Complaints)\b/g, count: 0, files: new Set() },
  alert: { regex: /\b(alert|alerts|Alert|Alerts)\b/g, count: 0, files: new Set() },
  incident: { regex: /\b(incident|incidents|Incident|Incidents)\b/g, count: 0, files: new Set() },
  task: { regex: /\b(task|tasks|Task|Tasks)\b/g, count: 0, files: new Set() },
  action: { regex: /\b(action|actions|Action|Actions)\b/g, count: 0, files: new Set() },
  inspection: { regex: /\b(inspection|inspections|Inspection|Inspections)\b/g, count: 0, files: new Set() },
  observation: { regex: /\b(observation|observations|Observation|Observations)\b/g, count: 0, files: new Set() },
  followup: { regex: /\b(followup|follow_up|FollowUp)\b/g, count: 0, files: new Set() },
  evidence: { regex: /\b(evidence|evidences|Evidence|Evidences)\b/g, count: 0, files: new Set() }
};

for (const file of [...allSrcFiles, ...allServerFiles]) {
  const rel = path.relative(ROOT, file).replace(/\\/g, '/');
  const content = fs.readFileSync(file, 'utf8');
  for (const [key, obj] of Object.entries(concepts)) {
    const matches = content.match(obj.regex);
    if (matches) {
      obj.count += matches.length;
      obj.files.add(rel);
    }
  }
}

// 4. API CALLERS IN FRONTEND
const apiCallRegex = /request\s*\(\s*['"`]([^'"`]+)['"`]|fetch\s*\(\s*['"`]([^'"`]+)['"`]|apiClient\s*\.\s*(get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]/g;
const apiCalls = {};

for (const file of allSrcFiles) {
  const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  const content = fs.readFileSync(file, 'utf8');
  let match;
  while ((match = apiCallRegex.exec(content)) !== null) {
    const ep = match[1] || match[2] || match[4] || '';
    if (ep) {
      const cleanEp = ep.split('?')[0];
      apiCalls[cleanEp] = apiCalls[cleanEp] || [];
      apiCalls[cleanEp].push(rel);
    }
  }
}

console.log('=== 1. UNIQUE ROUTES AUDIT ===');
console.log(`Total unique route paths found: ${Object.keys(foundRoutes).length}`);
Object.entries(foundRoutes).slice(0, 40).forEach(([r, d]) => {
  console.log(`Route: ${r.padEnd(35)} | Defined in: ${d.definedIn.length} files | Linked from: ${d.linkedFrom.length} files`);
});

console.log('\n=== 2. DOMAIN CONCEPT DUPLICATION COUNTS ===');
for (const [k, v] of Object.entries(concepts)) {
  console.log(`Concept [${k.padEnd(12)}]: ${String(v.count).padStart(6)} occurrences across ${String(v.files.size).padStart(3)} files`);
}

console.log('\n=== 3. FRONTEND API ENDPOINT CALLERS ===');
console.log(`Total distinct API endpoints called by frontend: ${Object.keys(apiCalls).length}`);
Object.entries(apiCalls)
  .sort((a, b) => b[1].length - a[1].length)
  .slice(0, 25)
  .forEach(([ep, callers]) => {
    console.log(`Endpoint: ${ep.padEnd(35)} called by ${callers.length} files`);
  });

console.log('\n=== 4. MODULES IMPORT REACHABILITY ===');
const modulesFiles = allSrcFiles.filter(f => f.includes('src\\modules\\') || f.includes('src/modules/'));
let importedModulesCount = 0;
let unimportedModulesCount = 0;

for (const file of modulesFiles) {
  const rel = path.relative(SRC_DIR, file).replace(/\\/g, '/');
  const callers = importedBy[rel] || [];
  if (callers.length > 0) importedModulesCount++;
  else unimportedModulesCount++;
}

console.log(`Total files in src/modules/: ${modulesFiles.length}`);
console.log(`  - Files still imported/reachable: ${importedModulesCount}`);
console.log(`  - Files with NO direct static imports: ${unimportedModulesCount}`);
