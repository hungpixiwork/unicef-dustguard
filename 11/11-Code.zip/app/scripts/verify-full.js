/**
 * DustGuard VN - Level 4 Verification: verify:full (Exhaustive Release Gate)
 * Executed ONCE at task completion, cross-domain refactor, or before commit.
 */

import { ALL_TEST_FILES } from './test-groups.js';
import { executeTestPipeline, runProcess } from './verification-runner.js';

async function main() {
  const totalStart = performance.now();

  console.log('========================================================');
  console.log('🚀 DUSTGUARD FULL RELEASE GATE & REGRESSION VERIFICATION');
  console.log('========================================================\n');

  // Step 1: Production Bundle Build (Vite)
  console.log('▶ Step 1/4: Production Bundle Compilation (Vite)...');
  const buildRes = await runProcess('npm', ['run', 'build'], { silent: false });
  if (buildRes.exitCode !== 0) {
    console.error('\n❌ FAIL-FAST: Production build failed.');
    process.exit(1);
  }
  console.log('✅ Vite Production Build passed\n');

  // Step 2: OpenAPI 3.0.3 Contract Parity Audit
  console.log('▶ Step 2/4: OpenAPI 3.0.3 Contract Parity Audit...');
  const auditRes = await runProcess('node', ['scripts/audit-api-contract.js'], { silent: false });
  if (auditRes.exitCode !== 0) {
    console.error('\n❌ FAIL-FAST: API Contract audit failed.');
    process.exit(1);
  }
  console.log('✅ API Contract Governance passed\n');

  // Step 3: Production Proof Matrix V2 (10 Core Domain Groups)
  console.log('▶ Step 3/4: Production Proof Verification (10 Domain Groups)...');
  const proofRes = await runProcess('node', ['scripts/verify-live-api-outputs.js'], { silent: false });
  if (proofRes.exitCode !== 0) {
    console.error('\n❌ FAIL-FAST: Production proof failed.');
    process.exit(1);
  }
  console.log('✅ Production Proof Matrix passed\n');

  // Step 4: Exhaustive Regression Suite across all test files
  console.log(`▶ Step 4/4: Exhaustive Regression Suite (${ALL_TEST_FILES.length} test files)...`);
  const testRes = await executeTestPipeline(ALL_TEST_FILES, {
    title: 'EXHAUSTIVE REGRESSION SUITE'
  });

  if (!testRes.success) {
    process.exit(1);
  }

  const totalSec = ((performance.now() - totalStart) / 1000).toFixed(1);
  console.log('========================================================');
  console.log(`🏆 FULL RELEASE VERIFICATION: 100% COMPLETE & PASS (${totalSec}s)`);
  console.log('========================================================');
  process.exit(0);
}

main().catch(err => {
  console.error('Fatal in verify-full:', err);
  process.exit(1);
});
