# Skill: Browser UI & Responsive Audit

## When to use
Use before closing any UI task to verify real visual rendering, touch targets, and layout responsiveness.

## Key Inputs
- `src/index.css`
- `src/components/`
- `.agent/UI_AUDIT.md`

## Procedure
1. Start dev server: `npm run dev:client`.
2. Inspect target route in browser at 375px (iPhone), 768px (iPad), and 1280px+ (Desktop).
3. Check for:
   - Zero horizontal overflow (`overflow-x`).
   - Button and touch targets >= 44x44px.
   - Text contrast >= 4.5:1 (WCAG AA/AAA).
   - No glassmorphism (`backdrop-blur`).
4. Perform interactive break tests: Double-click submit, submit empty form, offline network mode.
5. Record findings in `.agent/UI_AUDIT.md`.

## Common Traps
- Evaluating UI solely by reading JSX code without checking rendered CSS layout.
- Forgetting Vietnamese font line-wrap and diacritic heights.
