# Skill: Cloudflare D1 Debugging

## When to use
Use when querying, migrating, or debugging Cloudflare D1 database interactions in local development or edge worker runtime.

## Key Inputs
- `prisma/schema.prisma`
- `server/shared/db.js`
- `wrangler.jsonc`

## Procedure
1. Verify Prisma Client generation: `npm run db:generate`.
2. Inspect local SQLite / D1 database: `node tests/test_audit.js`.
3. Apply migrations locally: `npx wrangler d1 migrations apply DB --local`.
4. Ensure SQLite WAL mode (`PRAGMA journal_mode=WAL;`) is active in development to avoid `SQLITE_BUSY` errors.

## Common Traps
- Forgetting that JSON columns (like `findings`, `metadata`) are stored as serialized strings in SQLite/D1; always use `JSON.parse()` safely.
- Never write direct raw SQL bypassing Prisma validation in business services.
