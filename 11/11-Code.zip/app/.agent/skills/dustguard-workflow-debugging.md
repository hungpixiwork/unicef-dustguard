# Skill: DustGuard Workflow Debugging

## When to use
Use when debugging multi-role workflows connecting Citizen, Staff, Contractor, and Executive actors.

## Key Inputs
- `server/services/case.service.js`
- `src/apps/` (`CitizenPortal`, `StaffSites`, `ContractorPortal`, `ExecutiveDashboard`)
- `prisma/schema.prisma` (`Case`, `CaseTimeline`, `ContractorExplanation`, `SanctionDecision`)

## Procedure
1. Trace 7-step Case State Transition:
   `OPEN -> PENDING -> PROCESSING -> VIOLATED -> EXPLAINING -> SANCTIONED -> RECTIFYING -> COMPLETED`
2. Inspect `CaseTimeline` table for missing event entries.
3. Validate actor permission:
   - Citizen: can submit report, view own track.
   - Staff: can inspect, trigger violation, draft legal documents.
   - Contractor: can submit explanation and photographic remediation evidence via token.
   - Executive: can review aggregated KPIs and approve sanction decisions.
4. Execute targeted test: `node --test tests/case-service.test.js`.

## Common Traps
- Allowing invalid state machine jumps (e.g., from `OPEN` directly to `COMPLETED` without inspection).
- Failing to log `actorRole` and `actorId` into `CaseTimeline`.
