# Skill: R2 Evidence Verification

## When to use
Use when verifying image and file uploads for complaints, inspections, contractor remediations, and signed A4 PDF documents.

## Key Inputs
- `server/middleware/upload.js`
- `src/lib/image-integrity.js`
- `evidence/` directory

## Procedure
1. Verify client image compression: Image must be resized to <= 300KB before upload.
2. Verify image hash: SHA-256 fingerprint generated upon upload for tamper verification.
3. Validate storage URL: Object stored in R2 bucket binding (`EVIDENCE_BUCKET`).
4. Inspect database reference in `evidences` or `draft_documents` table.

## Common Traps
- Do not store raw uncompressed 10MB camera images directly.
- Redact private citizen faces or non-relevant background details before saving.
