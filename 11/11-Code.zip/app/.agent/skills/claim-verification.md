# Skill: Claim Verification & Evidence Creation

## When to use
Use whenever a technical claim is made about a feature, performance benchmark, or security guarantee.

## Key Inputs
- `.agent/CLAIMS.md`
- `docs/evidence/EVIDENCE_INDEX.md`
- `evidence/` directory

## Procedure
1. Define Claim Statement and assign Claim ID (`DG-C-XXX`).
2. Establish Confidence Level (L1 to L5):
   - L1: Implementation exists.
   - L2: Automated test passes.
   - L3: Runtime behavior observed.
   - L4: Database/Persistence independently verified.
   - L5: Production environment verified.
3. Attach Verification Evidence (log snippet, JSON payload, sanitized screenshot).
4. Record Git commit SHA and timestamp in `.agent/CLAIMS.md`.

## Common Traps
- Claiming "Verified" when only unit tests pass without checking runtime persistence.
- Over-promising numbers (e.g., "<35ms latency") without reproducible benchmark proof.
