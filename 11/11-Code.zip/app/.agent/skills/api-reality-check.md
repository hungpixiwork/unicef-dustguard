# Skill: API Reality Check

## When to use
Use to verify that an API endpoint actually executes backend logic and persists changes into the database rather than relying on local mocks.

## Key Inputs
- `server/routes/api/`
- `server/controllers/`
- `server/shared/db.js`

## Procedure
1. Send HTTP request using `curl`, `fetch`, or automated test.
2. Confirm request leaves client, hits Worker/Express route, and executes controller use-case.
3. Query database independently (`prisma.<model>.findUnique`) to verify row creation or mutation.
4. Reload client view and confirm reconstructed state matches database.
5. Check `audit_logs` table for corresponding audit entry.

## Common Traps
- Relying on React state update as proof of backend persistence.
- Ignoring network failure fallbacks that mask 500 errors with fake toasts.
