# DECISIONS.md — Architecture & Operational Micro-Decisions

## DEC-001: Relative `/api/*` Routing
- **Decision**: All frontend API calls use relative path `/api/*` instead of absolute hostname (`http://localhost:3001`).
- **Rationale**: Enables seamless deployment on Cloudflare Workers, Vercel Serverless, and Vite proxy without environment URL drift.

## DEC-002: Cloudflare D1 via `@prisma/adapter-d1`
- **Decision**: Use Cloudflare D1 as the primary serverless edge database, coupled with Prisma ORM via `@prisma/adapter-d1`.
- **Rationale**: Zero-egress latency, serverless edge scale, native SQLite compatibility during local development.

## DEC-003: Timing-Safe IoT HMAC Signature Verification
- **Decision**: Use `crypto.timingSafeEqual` for IoT telemetry authentication instead of plain `===` string equality.
- **Rationale**: Eliminates side-channel timing attacks on HMAC-SHA256 tokens sent by remote dust sensors.

## DEC-004: Strict Light-Mode Civic-Tech Design Palette
- **Decision**: Use warm cream background (`#FDFBF7`), dark ink text (`#231b14`), deep teal accent (`#0d6f64`), and seal red (`#9f241f`). Ban all glassmorphism.
- **Rationale**: Maximizes readability under bright outdoor sunlight for inspectors and citizens on mobile devices while complying with official government visual tone.

## DEC-005: Dual-Save Offline Drafts for Citizen Reporting
- **Decision**: Store citizen complaints in local IndexedDB / localStorage queue (`saveOfflineDraft`) before network dispatch.
- **Rationale**: Prevents data loss when citizens report violations in areas with weak 3G/4G connectivity.
