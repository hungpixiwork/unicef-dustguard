# NEXT_ACTIONS.md — Prioritized Engineering Backlog

## P0 — Community Priority Score & Civic-Tech Refactoring (COMPLETED)
- [x] Full scoring policy & weights definition (`src/lib/priority/priorityScorePolicy.js`)
- [x] 5-component deterministic scoring engine (`src/lib/priority/priorityScoreEngine.js`)
- [x] Zero-IoT weight normalization & anti-spam deduplication logic
- [x] Unit & Integration verification test suites (`tests/priority-scoring-engine.test.js` & `tests/priority-score-integration.test.js`)
- [x] Audit Trail logging (`PRIORITY_SCORE_RECALCULATED`) on score recalculation
- [x] UI/UX copy & terminology update across Staff, Detail, and Breakdown modals
- [x] Full forensic test verification (`npm run verify`: 322/322 assertions pass across 42 suites, build SPA pass)

## P1 — Competition Showcase & Pilot Readiness
- [x] Validate end-to-end browser user flows on 375px mobile and 1280px desktop
- [x] Verify A4 Legal DOCX / PDF Decree 30/2020/NĐ-CP styling
- [x] Verify CSR Escrow milestone conditions and ESG impact calculation
- [ ] Maintain ongoing edge telemetry and sensor simulator demo feeds

## P2 — Long-Term Continuous Improvement
- [ ] Monitor D1 write transaction duration under production traffic
- [ ] Expand automated Playwright browser E2E test suite
