# KNOWN_ISSUES.md — Active Issue & Tech Debt Registry

## ISSUE-001: Social Auth Provider (Google) Missing Client ID in Local Dev
- **Severity**: P3 (Cosmetic / Dev Only)
- **Symptom**: Console warning `[Better Auth]: Social provider google is missing clientId or clientSecret` on server startup.
- **Suspected Layer**: `server/auth.js` / Better Auth configuration.
- **Status**: Triaged. Expected in local dev when `GOOGLE_CLIENT_ID` is not set; local email/password and mock logins remain fully functional.
- **Owner**: Dev Team.

## ISSUE-002: Hardcoded Signature Secret Fallback in Dev
- **Severity**: P2 (Security Hardening)
- **Symptom**: `[approveDraftDocument] SIGNATURE_SECRET environment variable is missing. Using fallback secret for digital signature.`
- **Suspected Layer**: `server/controllers/documents.controller.js`.
- **Status**: Triaged. Development uses fallback `'dustguard-secret-key-2026'`. Must be made strict fail-safe in production environment.
- **Owner**: Release Engineer.

## ISSUE-003: Large Chunk Warning on Production Bundle
- **Severity**: P3 (Performance Optimization)
- **Symptom**: Vite reports `StaffAI-*.js` (>500 kB) due to bundled AI prompt templates and DOCX engine.
- **Suspected Layer**: `src/components/StaffAI/`.
- **Status**: Triaged. Application loads properly; future optimization can dynamic-import `docx` and prompt templates.
- **Owner**: Frontend Architect.
