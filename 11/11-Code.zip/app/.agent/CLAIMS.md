# CLAIMS.md — DustGuard Technical Claim Registry

## Claim Confidence Levels:
- **L0**: Documentation / Concept only
- **L1**: Implementation code exists
- **L2**: Automated test passes
- **L3**: Runtime behavior observed
- **L4**: Persistence & database independently verified
- **L5**: Production / Target Cloudflare environment verified

---

### CLAIM-ID: DG-C-001
- **Statement**: "IoT sensor telemetry readings are ingested with HMAC-SHA256 authentication and timestamp drift protection."
- **Confidence Level**: L4 (Database & Test Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `server/services/alert-engine.service.js`, `server/routes/api/sensors.js`
  - Test: `tests/sensors-telemetry.test.js`
  - Runtime: Accepts valid signed payload, rejects invalid signature with HTTP 403, rejects timestamp drift (>5 min) with HTTP 400.
  - Database: Inserts into `sensor_readings` and creates `audit_logs` record.
- **Commit**: `199a8949f97ac490ab8d2076a57f9faac1009dad`

---

### CLAIM-ID: DG-C-002
- **Statement**: "Cloudflare D1 is integrated via Prisma adapter with concurrent write lock mitigation."
- **Confidence Level**: L4 (Persistence Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `server/shared/db.js`, `wrangler.jsonc`, `package.json` (`@prisma/adapter-d1`)
  - Test: `tests/test_audit.js`
  - Runtime: Executes 5 concurrent write transactions without SQLITE_BUSY errors.
  - Database: 14 Prisma models validated.
- **Commit**: `199a8949f97ac490ab8d2076a57f9faac1009dad`

---

### CLAIM-ID: DG-C-003
- **Statement**: "A4 Legal Document Engine complies with Decree 30/2020/NĐ-CP margins and generates non-empty DOCX binary export."
- **Confidence Level**: L3 (Test & Runtime Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `src/legal-document-engine/`, `src/lib/docx-export.js`
  - Test: `tests/official-document.test.js`, `tests/docx-parser.test.js`
  - Runtime: Exact twip DXA column widths computed, margins strictly set (Top 20mm, Right 15mm, Bottom 20mm, Left 30mm).
- **Commit**: `199a8949f97ac490ab8d2076a57f9faac1009dad`

---

### CLAIM-ID: DG-C-004
- **Statement**: "CSR Escrow & DEMS rating engine automatically calculates mitigation scores and handles escrow fund release."
- **Confidence Level**: L3 (Test Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `src/lib/csr-engine.js`, `server/routes/api/cases.js`
  - Test: `tests/csr-engine.test.js`, `tests/csr-api.test.js`
  - Runtime: DEMS rating tier calculation, sensitive receptor assessment, escrow auto-trigger on risk lock/unlock.
- **Commit**: `199a8949f97ac490ab8d2076a57f9faac1009dad`

---

### CLAIM-ID: DG-C-005
- **Statement**: "Citizen youth reports record verified volunteer hours with GPS evidence, HMAC-SHA256 integrity hash, and anti-spam device fingerprinting."
- **Confidence Level**: L4 (Database & Test Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `src/lib/youth-credits.js`, `src/lib/anti-spam.js`, `server/routes/api/youth.js`
  - Test: `tests/youth-credits.test.js`, `tests/citizen-youth-ux.test.js`
  - Runtime: Deterministic device hash generated, 20h volunteer activity logged with GPS, data integrity hash computed, mandatory disclaimer attached.
  - Policy: `docs/CLAIM_INTEGRITY_POLICY.md` Class B Assisted.
- **Commit**: `HEAD`

---

### CLAIM-ID: DG-C-006
- **Statement**: "Citizen report form supports offline draft saving and automatic background sync."
- **Confidence Level**: L3 (Test Verified)
- **Status**: VERIFIED
- **Verification Proof**:
  - Source: `src/lib/offline-drafts.js`
  - Test: `tests/offline-resilience-audit.test.js`, `tests/offline-drafts.test.js`
  - Runtime: `saveOfflineDraft` stores payload without throwing network errors; `syncOfflineDrafts` auto-synchronizes on reconnect.
- **Commit**: `199a8949f97ac490ab8d2076a57f9faac1009dad`
