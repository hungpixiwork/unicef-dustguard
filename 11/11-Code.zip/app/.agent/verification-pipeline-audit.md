# Verification Pipeline Audit — DustGuard VN

**Audit Date**: 2026-08-21
**Codebase**: DustGuard VN (441+ tests across 64 test files)

---

## 1. Executive Summary & Problem Analysis

### Vấn đề hiện tại (The Slow Feedback Anti-pattern)
- **Thời gian chạy verify cũ**: ~64 giây cho mỗi lần chạy `npm run verify`.
- **Cơ chế cũ**: `package.json` chứa 1 chuỗi lệnh `npm run build && node --test --test-concurrency=1 tests/...` nối tiếp dài hơn 1500 ký tự.
- **Anti-pattern**: Sau mỗi lần chỉnh sửa 1 file (ví dụ: sửa CSS hoặc 1 hàm domain), developer/agent chạy toàn bộ 64 file test + build Vite, lãng phí thời gian và làm chậm chu kỳ phát triển.
- **Nguy cơ race condition DB**: Khi chạy parallel toàn cục, các test thực hiện reset DB (`d1-reset-safeguards.test.js`) gây xung đột với các test kiểm tra persistence (`d1-ssot-crud-persistence.test.js`).

---

## 2. Phân Loại 64 Test Files Theo Nhóm & Mức Độ Độc Lập

| Nhóm | Số lượng file | Đặc điểm | Khả năng Parallel |
| :--- | :--- | :--- | :--- |
| **Pure Unit / Domain Rules** | 16 files | Xử lý logic thuần túy trong RAM (QCVN checklist, CSR DEMS, Risk Engine, HMAC, EXIF parser). | **Hoàn toàn Parallel (100%)** |
| **UI, Layout & Tokens** | 14 files | Kiểm tra cú pháp JSX, token CSS, Touch target WCAG, PageContainer, Card layout. | **Hoàn toàn Parallel (100%)** |
| **API Contract & OpenAPI** | 7 files | Đối chiếu bảng route Hono với OpenAPI 3.0.3 spec, RBAC routes matrix. | **Hoàn toàn Parallel (100%)** |
| **Edge Worker & Integration** | 22 files | `worker.fetch(req)` kiểm thử API Hono, Anti-spam, Mock R2/storage. | **Parallel an toàn** |
| **D1 DB Mutating & Reset** | 5 files | `d1-reset-safeguards`, `d1-ssot-crud-persistence`, `test_audit*`. | **Tuần tự (Serial / Isolated)** |

---

## 3. Kiến Trúc 5 Tầng Verification Mới

```text
               ┌──────────────────────────────────────────────┐
               │ LEVEL 0: Targeted Test (1 file: 0.2s - 1.5s) │
               └──────────────────────┬───────────────────────┘
                                      ▼
               ┌──────────────────────────────────────────────┐
               │ LEVEL 1: verify:changed (git diff: < 5.0s)   │
               └──────────────────────┬───────────────────────┘
                                      ▼
               ┌──────────────────────────────────────────────┐
               │ LEVEL 2: verify:domain (theo domain: < 8.0s) │
               └──────────────────────┬───────────────────────┘
                                      ▼
               ┌──────────────────────────────────────────────┐
               │ LEVEL 3: verify:quick (critical gate: < 15s) │
               └──────────────────────┬───────────────────────┘
                                      ▼
               ┌──────────────────────────────────────────────┐
               │ LEVEL 4: verify:full / verify (Release Gate) │
               └──────────────────────────────────────────────┘
```

---

## 4. Kế Hoạch Tái Cấu Trúc Script & SSOT

1. **`scripts/test-groups.js`**: SSOT định nghĩa các nhóm test tập trung.
2. **`scripts/test-impact-map.js`**: SSOT ánh xạ file thay đổi $\rightarrow$ test bị ảnh hưởng.
3. **`scripts/verification-runner.js`**: Core runner tối ưu tốc độ, áp dụng fail-fast, parallel an toàn, và hiển thị bảng báo cáo xúc tích.
4. **Entrypoints**:
   - `scripts/verify-changed.js`
   - `scripts/verify-domain.js`
   - `scripts/verify-quick.js`
   - `scripts/verify-full.js`
   - `scripts/verify-ci.js`
5. **`package.json`**: Rút gọn các lệnh dài, trỏ về các runner chuyên biệt.
