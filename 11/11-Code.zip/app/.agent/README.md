# .agent — Operational Memory & Control Plane

Thư mục `.agent/` chứa trạng thái vận hành trực tiếp của AI agent cho dự án **DustGuard VN**.

## Mục đích các tệp tin:
- `CURRENT_STATE.md`: Trạng thái nhánh git, sức khỏe kiến trúc, các tính năng đã xác minh bằng runtime.
- `NEXT_ACTIONS.md`: Danh sách công việc ưu tiên (P0, P1, P2) được chia nhỏ thành các micro task.
- `LESSONS.md`: Sổ tay bài học kinh nghiệm, nguyên nhân gốc rễ và quy tắc phòng tránh tái phát lỗi.
- `DECISIONS.md`: Quyết định kỹ thuật ngắn gọn không cần nâng lên ADR.
- `KNOWN_ISSUES.md`: Bảng theo dõi lỗi đang tồn tại với mức độ nghiêm trọng và bằng chứng.
- `CLAIMS.md`: Claim Registry — SSOT cho mọi tuyên bố kỹ thuật (L0–L5) phục vụ kiểm định và báo cáo.
- `SESSION_LOG.md`: Nhật ký các phiên làm việc và checkpoint đã commit.
- `QUALITY_GATES.md`: Tiêu chuẩn console, responsive, accessibility và kiểm thử.
- `UI_AUDIT.md`: Nhật ký audit giao diện thực tế trên các breakpoint di động/desktop.
- `skills/`: Hướng dẫn kỹ thuật thực tế cho các tác vụ đặc thù (D1, R2, DevTools, API Check).
