# DustGuard VN Backend Hardening — 10 Core Domain Groups Reconnaissance Audit

**Date**: 2026-08-21
**Target Architecture**: Cloudflare Worker Native Modular Monolith + D1 SQLite SSOT + R2 Storage
**Baseline Verification Status**: 51/51 basic tests passing, 380+ verify suite tests passing.

---

## 1. Architectural Inventory & Gap Analysis

```text
HTTP Route (Hono on Worker Edge)
   ↓
Application / Service Layer (Use Cases & Decision Services)
   ↓
Domain Rules (State Machines, Integrity Checkers, Scoring Engines)
   ↓
Repository Layer (Parameterized SQL & D1 Abstraction)
   ↓
Database (Cloudflare D1 / dev.db SQLite) + R2 Object Storage
```

### Gap Matrix Across 10 Domain Groups

| # | Domain Group | Existing State | Identified Gaps / Invariants Needed | Plan |
|---|---|---|---|---|
| **01** | **Environmental Categories & Regulations** | Static dictionary of 7 categories returned | Lacks category detail endpoint, regulation references (QCVN/law citations with authority & effective dates), active/inactive filtering, versioning. | Implement rich category domain model & endpoints (`GET /api/environmental-categories`, `GET /api/environmental-categories/:id`). |
| **02** | **Observation Write / Community Report** | Basic insert into `observations` | Needs collision-resistant public code (`OBS-YYYY-XXXX`), strict domain status enum, comprehensive evidence metadata, GPS bounds check, idempotency support (`Idempotency-Key`). | Harden validation, unique public code generator, atomic audit emission, idempotency key cache. |
| **03** | **Observation Detail, Timeline & Evidence Integrity** | Returns raw joined row | Needs aggregate read model with structured sections (`observation`, `category`, `evidence`, `followUps`, `handoffs`, `timeline`, `integrity`). | Build `getObservationAggregate` with audit-derived timeline & SHA-256 evidence integrity check. |
| **04** | **Follow-up 24h / 48h** | Hardcoded `BETTER => RESOLVED` | Needs `FollowUpDecisionService` decision matrix (BETTER + sufficient evidence => RESOLVED, BETTER + insufficient evidence => NEEDS_FOLLOWUP, UNCHANGED => NEEDS_FOLLOWUP/READY_FOR_HANDOFF, WORSE => READY_FOR_HANDOFF). Needs atomic state transition & idempotency. | Implement `FollowUpDecisionService`, atomic multi-write batch, 24h/48h deadline derivations. |
| **05** | **Handoff / Case Escalation** | Basic insert with `PREPARED` status | Needs state machine (`PREPARED` -> `SUBMITTED` -> `ACKNOWLEDGED` -> `CLOSED`), canonical deterministic JSON serialization, SHA-256 `packetHash`, immutable submitted packets. | Implement `CanonicalJson` serializer, packet builder, state transitions, submit/acknowledge endpoints. |
| **06** | **Community Impact** | Hardcoded inflation (`+14`, `+8`, `+32`, `+850`, `+42.5`, `schoolsProtected: 6`) | Must compute 100% dynamic metrics from DB lineage without hardcoded demo offsets. Metric Definition SSOT needed. | Implement pure SQL metrics query with lineage metadata, date range filters, and district/campaign filters. |
| **07** | **Campaigns & Community Action** | Basic campaign table and join | Needs lifecycle status (`DRAFT`, `UPCOMING`, `ACTIVE`, `COMPLETED`), duplicate join prevention, campaign-specific impact aggregation. | Implement campaign domain model, participation constraints, and dynamic campaign impact endpoint. |
| **08** | **Public Sites + Dust Risk Engine** | Raw risk score from DB without explainability | Needs `DustRiskEngine` SSOT with explainable components (PM2.5/PM10, sensor freshness, flatline check, confidence score, versioning). | Implement `DustRiskEngine` domain service with sensor health validation and explainable output. |
| **09** | **Youth Credit & Certificate** | Generates cert from arbitrary input | Must validate eligible hours against real validated activity records. HMAC-SHA256 secret from env. Server verification & revocation. | Build activity-backed credit verification, HMAC signature with env secret, verify endpoint, revocation policy. |
| **10** | **OpenAPI & Contract Governance** | Spec has 159 routes but no automated parity audit | Needs automated audit script `scripts/audit-api-contract.js` ensuring 0 missing in spec, 0 missing in runtime, valid schemas. | Create comprehensive contract audit script with exact route matching and schema validation. |

---

## 2. Shared Foundation Upgrades

1. **Standard Response Contract SSOT**:
   - Success: `{ success: true, data: ..., meta: { requestId, timestamp } }`
   - Failure: `{ success: false, error: { code, message, details }, meta: { requestId, timestamp } }`
   - Backward-compatibility aliases maintained for existing client expectations.
2. **Canonical JSON Serializer**:
   - Deterministic key ordering and whitespace suppression for cryptographic hashes (Handoff Packets, Certificates, Audit Integrity).
3. **Idempotency Service**:
   - Cache key tracking with request hash, returning existing result on duplicate `Idempotency-Key` write.
4. **Audit Trail Engine**:
   - Uniform event emission with `previous_state`, `new_state`, `actor`, and `integrity_hash`.
5. **D1 / SQLite Batch Adapter**:
   - Ensure `db.batch([stmt1, stmt2, ...])` executes atomically in both Cloudflare D1 and Node.js `better-sqlite3`.
