# UI_AUDIT.md — Presentation Audit & Viewport Verification

## Verified Viewport Matrices

| Route | Target Audience | Primary Viewport | Key Verification Criteria | Status |
|---|---|---|---|---|
| `/citizen` | Citizens / Youth | 375px & 390px (Mobile) | Report form, photo upload (<300KB auto compress), offline banner, credit progress bar | VERIFIED |
| `/citizen/track` | Citizens | 375px (Mobile) | DG-2026-XXXX Ticket card wrapping, status stepper | VERIFIED |
| `/staff/sites` | Inspectors | 768px - 1280px (Tablet/Desktop) | Site risk table, search & filter, quick inspection action | VERIFIED |
| `/staff/ai` | Inspectors / Legal | 1280px+ (Desktop) | 2-column layout (Left: Data Form, Right: A4 Preview), no 3-column squeeze | VERIFIED |
| `/contractor` | Site Managers | 375px - 1024px | Zero-login link, explanation textarea, photo evidence upload, DEMS score | VERIFIED |
| `/executive` | City Leaders | 1280px+ (Desktop) | Full GIS Leaflet map, city KPI overview, digital signature approval modal | VERIFIED |

## Audited Edge Cases:
- **Long Vietnamese Text**: All headers, badges, and buttons use responsive typography with appropriate line-heights without awkward word clipping.
- **Printing (@media print)**: A4 preview maintains 20mm/15mm margins and avoids table row splitting across pages.
