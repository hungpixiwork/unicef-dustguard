# QUALITY_GATES.md — Engineering Standards & Quality Gates

## 1. Console & Runtime Quality Gate
In all core workflows (`/citizen`, `/staff`, `/contractor`, `/executive`):
- Unhandled Promise Rejections: **0**
- React Critical Errors / Invariant Violations: **0**
- Unexpected 500 API responses: **0**
- Missing Form Labels or Key Prop Warnings: **0**

## 2. Responsive & Touch Standards
- **375px & 390px (Mobile)**: No horizontal scrolling, action buttons wrap cleanly, drawer menu operates smoothly.
- **768px (Tablet)**: Multi-column cards and split inspectors adapt without content overlap.
- **1024px / 1280px+ (Desktop)**: Full A4 preview side-by-side with form inputs; Leaflet GIS map spans full workspace.
- **Touch Targets**: Minimum 44x44px for touch interactions on mobile.

## 3. Visual & Design Standards
- **Civic Light Theme**: Strictly `#FDFBF7` canvas, `#231b14` text, `#0d6f64` accent, `#9f241f` seal red.
- **Ban on Glassmorphism**: No semi-transparent blurred backgrounds (`backdrop-blur`).
- **Contrast**: WCAG 2.1 AA/AAA compliance for all body text and data badges.
- **A4 Printing**: White background (`#FFFFFF`), black ink (`#000000`), zero shadows, page breaks avoided inside tables and signature blocks.

## 4. Verification Gate
- `npm run verify` MUST pass with 100% test pass rate before committing changes.
