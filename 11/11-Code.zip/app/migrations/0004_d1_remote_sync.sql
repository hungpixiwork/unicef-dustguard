-- Migration 0004: Sync missing tables and columns to remote Cloudflare D1
ALTER TABLE cases ADD COLUMN deletedAt DATETIME;

CREATE TABLE IF NOT EXISTS case_status_history (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  from_status TEXT NOT NULL,
  to_status TEXT NOT NULL,
  changed_by TEXT,
  actor_name TEXT,
  actor_role TEXT,
  note TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_case_status_history ON case_status_history(case_id, createdAt DESC);

CREATE TABLE IF NOT EXISTS priority_score_history (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  case_id TEXT,
  score INTEGER NOT NULL,
  score_version TEXT NOT NULL,
  components_json TEXT NOT NULL,
  reasons_json TEXT,
  calculated_by TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (site_id) REFERENCES sites(id) ON DELETE CASCADE,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_priority_score_site_time ON priority_score_history(site_id, createdAt DESC);

CREATE TABLE IF NOT EXISTS communities (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'COMMUNITY',
  location TEXT,
  ward TEXT,
  province TEXT DEFAULT 'Đà Nẵng',
  leaderId TEXT,
  avatarUrl TEXT,
  coverUrl TEXT,
  memberCount INTEGER NOT NULL DEFAULT 1,
  verified INTEGER NOT NULL DEFAULT 0,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS community_members (
  id TEXT PRIMARY KEY,
  communityId TEXT NOT NULL,
  userId TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'MEMBER',
  joinedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (communityId) REFERENCES communities(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS campaigns (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  communityId TEXT,
  startDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  endDate DATETIME,
  targetObservations INTEGER NOT NULL DEFAULT 100,
  currentObservations INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  coverUrl TEXT,
  ward TEXT,
  province TEXT DEFAULT 'Đà Nẵng',
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (communityId) REFERENCES communities(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS campaign_members (
  id TEXT PRIMARY KEY,
  campaignId TEXT NOT NULL,
  userId TEXT NOT NULL,
  joinedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (campaignId) REFERENCES campaigns(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS observations (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'CONSTRUCTION_DUST',
  severity TEXT NOT NULL DEFAULT 'MEDIUM',
  status TEXT NOT NULL DEFAULT 'RECORDED',
  latitude REAL,
  longitude REAL,
  address TEXT,
  ward TEXT,
  province TEXT DEFAULT 'Đà Nẵng',
  siteId TEXT,
  authorId TEXT,
  authorName TEXT,
  authorRole TEXT DEFAULT 'citizen',
  campaignId TEXT,
  verifiedAt DATETIME,
  verifiedBy TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE SET NULL,
  FOREIGN KEY (campaignId) REFERENCES campaigns(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS observation_evidence (
  id TEXT PRIMARY KEY,
  observationId TEXT NOT NULL,
  fileUrl TEXT NOT NULL,
  fileType TEXT NOT NULL DEFAULT 'image',
  sha256Hash TEXT,
  caption TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (observationId) REFERENCES observations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS follow_ups (
  id TEXT PRIMARY KEY,
  observationId TEXT NOT NULL,
  authorId TEXT,
  authorName TEXT,
  authorRole TEXT DEFAULT 'citizen',
  note TEXT NOT NULL,
  statusBefore TEXT,
  statusAfter TEXT,
  evidenceUrl TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (observationId) REFERENCES observations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS handoffs (
  id TEXT PRIMARY KEY,
  observationId TEXT NOT NULL,
  targetAgency TEXT NOT NULL,
  agencyContact TEXT,
  dossierUrl TEXT,
  status TEXT NOT NULL DEFAULT 'SUBMITTED',
  officialReference TEXT,
  submittedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  acknowledgedAt DATETIME,
  resolvedAt DATETIME,
  responseNote TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (observationId) REFERENCES observations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS impact_events (
  id TEXT PRIMARY KEY,
  eventType TEXT NOT NULL,
  observationId TEXT,
  campaignId TEXT,
  userId TEXT,
  pointsAwarded INTEGER NOT NULL DEFAULT 10,
  details TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  key TEXT PRIMARY KEY,
  request_hash TEXT,
  response_json TEXT NOT NULL,
  status_code INTEGER NOT NULL DEFAULT 200,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  aggregate_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  actor_id TEXT,
  actor_name TEXT,
  actor_role TEXT,
  payload_json TEXT,
  previous_state TEXT,
  new_state TEXT,
  request_id TEXT,
  integrity_hash TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS environmental_categories (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_vi TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  default_severity TEXT NOT NULL DEFAULT 'HIGH',
  evidence_requirements TEXT,
  regulations TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  version INTEGER NOT NULL DEFAULT 1,
  effective_from DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  effective_to DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS youth_activities (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  activity_type TEXT NOT NULL,
  campaign_id TEXT,
  observation_id TEXT,
  minutes INTEGER NOT NULL DEFAULT 30,
  evidence_url TEXT,
  validated_by TEXT,
  validation_status TEXT NOT NULL DEFAULT 'VALIDATED',
  occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL,
  FOREIGN KEY (observation_id) REFERENCES observations(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS youth_certificates (
  id TEXT PRIMARY KEY,
  certificate_code TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  university TEXT NOT NULL,
  student_id TEXT,
  eligible_minutes INTEGER NOT NULL DEFAULT 0,
  credit_value REAL NOT NULL DEFAULT 0,
  policy_version TEXT NOT NULL DEFAULT 'v1.0',
  payload_hash TEXT NOT NULL,
  signature TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  revoked_at DATETIME,
  revoked_reason TEXT,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  issued_by TEXT NOT NULL DEFAULT 'DustGuard VN System'
);
