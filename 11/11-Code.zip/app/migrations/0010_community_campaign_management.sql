-- 0010_community_campaign_management.sql
-- Migration for Community & Campaign Backoffice Management & Participation SSOT

-- 1. Table: campaigns (Full schema support)
CREATE TABLE IF NOT EXISTS campaigns (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE,
  title TEXT NOT NULL,
  slug TEXT,
  short_description TEXT,
  description TEXT,
  campaign_type TEXT DEFAULT 'SCHOOL_ZONE',
  topic TEXT DEFAULT 'SCHOOL_ZONE_DUST',
  location TEXT,
  ward TEXT,
  district TEXT,
  province TEXT DEFAULT 'Hà Nội',
  start_at DATETIME,
  end_at DATETIME,
  participation_start_at DATETIME,
  participation_end_at DATETIME,
  status TEXT NOT NULL DEFAULT 'OPEN',
  visibility TEXT NOT NULL DEFAULT 'PUBLIC',
  cover_image TEXT,
  coverUrl TEXT,
  organizer TEXT,
  max_participants INTEGER,
  goals TEXT,
  target_observations INTEGER DEFAULT 100,
  current_observations INTEGER DEFAULT 0,
  safety_criteria TEXT,
  schools_list TEXT,
  participant_count INTEGER DEFAULT 0,
  observation_count INTEGER DEFAULT 0,
  created_by TEXT,
  updated_by TEXT,
  deleted_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. Table: communities / clubs
CREATE TABLE IF NOT EXISTS communities (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  slug TEXT,
  organization_type TEXT DEFAULT 'UNIVERSITY',
  school TEXT,
  province TEXT DEFAULT 'Hà Nội',
  district TEXT,
  ward TEXT,
  description TEXT,
  logo_url TEXT,
  avatarUrl TEXT,
  cover_url TEXT,
  coverUrl TEXT,
  contact_name TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  visibility TEXT NOT NULL DEFAULT 'PUBLIC',
  motto TEXT,
  badge_title TEXT,
  volunteer_hours REAL DEFAULT 0,
  resolved_hotspots INTEGER DEFAULT 0,
  member_count INTEGER DEFAULT 0,
  memberCount INTEGER DEFAULT 0,
  verified INTEGER DEFAULT 1,
  created_by TEXT,
  deleted_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 3. Table: community_memberships
CREATE TABLE IF NOT EXISTS community_memberships (
  id TEXT PRIMARY KEY,
  profile_id TEXT,
  user_id TEXT,
  club_id TEXT NOT NULL,
  membership_role TEXT NOT NULL DEFAULT 'MEMBER',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  left_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Table: campaign_participants
CREATE TABLE IF NOT EXISTS campaign_participants (
  id TEXT PRIMARY KEY,
  campaign_id TEXT NOT NULL,
  profile_id TEXT,
  user_id TEXT,
  club_id TEXT,
  participation_role TEXT NOT NULL DEFAULT 'VOLUNTEER',
  status TEXT NOT NULL DEFAULT 'APPROVED',
  full_name TEXT,
  email TEXT,
  phone TEXT,
  organization TEXT,
  note TEXT,
  commitment_hours TEXT,
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approved_at DATETIME,
  completed_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 5. Table: campaign_clubs (Mapping campaign <-> clubs)
CREATE TABLE IF NOT EXISTS campaign_clubs (
  id TEXT PRIMARY KEY,
  campaign_id TEXT NOT NULL,
  club_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_campaigns_status_vis ON campaigns(status, visibility, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_campaigns_code ON campaigns(code);
CREATE INDEX IF NOT EXISTS idx_communities_status ON communities(status, visibility);
CREATE INDEX IF NOT EXISTS idx_campaign_part_camp_status ON campaign_participants(campaign_id, status);
CREATE INDEX IF NOT EXISTS idx_campaign_part_user ON campaign_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_comm_member_club ON community_memberships(club_id, status);
