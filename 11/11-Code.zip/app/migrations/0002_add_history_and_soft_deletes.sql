-- Migration 0002: Add Audit Logs, Case Status History, Priority Score History & Domain Indices
-- DustGuard VN - Cloudflare D1 SSOT

PRAGMA foreign_keys = ON;

-- 1. Append-only Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  userId TEXT,
  actor_id TEXT,
  actor_type TEXT,
  actor_name TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  targetId TEXT,
  entity_type TEXT,
  entity_id TEXT,
  before_json TEXT,
  after_json TEXT,
  metadata_json TEXT,
  request_id TEXT,
  details TEXT,
  ipAddress TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor_created ON audit_logs(actor_id, createdAt DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action_created ON audit_logs(action, createdAt DESC);

-- 2. Domain Case Status History
CREATE TABLE IF NOT EXISTS case_status_history (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  from_status TEXT NOT NULL,
  to_status TEXT NOT NULL,
  changed_by TEXT,
  actor_name TEXT,
  actor_role TEXT,
  note TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_case_status_history ON case_status_history(case_id, createdAt DESC);

-- 3. Domain Priority Score History (CPS v1)
CREATE TABLE IF NOT EXISTS priority_score_history (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  case_id TEXT,
  score INTEGER NOT NULL,
  score_version TEXT NOT NULL,
  components_json TEXT NOT NULL,
  reasons_json TEXT,
  calculated_by TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (site_id) REFERENCES sites(id) ON DELETE CASCADE,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_priority_score_site_time ON priority_score_history(site_id, createdAt DESC);

-- 4. Case Timelines & Contractor Explanations
CREATE TABLE IF NOT EXISTS case_timelines (
  id TEXT PRIMARY KEY,
  caseId TEXT NOT NULL,
  eventTitle TEXT NOT NULL,
  eventDescription TEXT,
  eventType TEXT NOT NULL,
  actorId TEXT,
  actorName TEXT,
  actorRole TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_case_timelines_caseId ON case_timelines(caseId, createdAt ASC);

CREATE TABLE IF NOT EXISTS contractor_explanations (
  id TEXT PRIMARY KEY,
  caseId TEXT NOT NULL,
  contractorId TEXT NOT NULL,
  explanation TEXT NOT NULL,
  evidenceUrls TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  submittedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sanction_decisions (
  id TEXT PRIMARY KEY,
  caseId TEXT NOT NULL,
  decisionNumber TEXT NOT NULL UNIQUE,
  documentUrl TEXT,
  penaltyAmount REAL,
  remedialMeasures TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  issuedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE CASCADE
);
