-- Migration: 0005_legal_rules_ssot.sql
-- Description: Statutory Legal Rules Single Source of Truth (SSOT) Architecture

CREATE TABLE IF NOT EXISTS "legal_rules" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "jurisdiction" TEXT NOT NULL DEFAULT 'NATIONAL',
    "document_number" TEXT NOT NULL,
    "document_title" TEXT,
    "article" TEXT NOT NULL,
    "clause" TEXT,
    "violation_code" TEXT NOT NULL UNIQUE,
    "checklist_key" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "subject_type" TEXT NOT NULL DEFAULT 'ORGANIZATION',
    "min_fine" REAL NOT NULL DEFAULT 0,
    "max_fine" REAL NOT NULL DEFAULT 0,
    "effective_from" TEXT,
    "source_url" TEXT,
    "remediation_action" TEXT,
    "citation" TEXT NOT NULL,
    "created_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS "legal_rules_violation_code_idx" ON "legal_rules"("violation_code");
CREATE INDEX IF NOT EXISTS "legal_rules_document_number_idx" ON "legal_rules"("document_number");
CREATE INDEX IF NOT EXISTS "legal_rules_jurisdiction_idx" ON "legal_rules"("jurisdiction");
CREATE INDEX IF NOT EXISTS "legal_rules_checklist_key_idx" ON "legal_rules"("checklist_key");
