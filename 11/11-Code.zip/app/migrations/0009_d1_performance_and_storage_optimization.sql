-- Migration 0009: Cloudflare D1 Performance, Query Planning & Storage Optimization
-- DustGuard VN - Cloudflare D1 High-Throughput & Low-Latency Engine

PRAGMA foreign_keys = ON;

-- 1. Optimized Composite Indexes for High-Frequency Filtering & Sorting
CREATE INDEX IF NOT EXISTS "idx_cases_status_created" ON "cases"("status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_cases_site_status" ON "cases"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_complaints_site_created" ON "complaints"("siteId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_inspections_case_date" ON "inspections"("caseId", "scheduledDate" DESC);
CREATE INDEX IF NOT EXISTS "idx_remediation_actions_case" ON "remediation_actions"("caseId", "status");
CREATE INDEX IF NOT EXISTS "idx_youth_credits_student" ON "youth_credits"("studentId", "claimedAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_actor_time" ON "audit_logs"("userId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_audit_logs_target_action" ON "audit_logs"("targetId", "action");

-- 2. Clean Up Query Acceleration for Observations & Followups
CREATE INDEX IF NOT EXISTS "idx_observations_created" ON "observations"("created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_category" ON "observations"("category", "status");
CREATE INDEX IF NOT EXISTS "idx_handoffs_target_status" ON "handoffs"("target_unit", "status");

-- 3. Document Signature & Legal Audit Hash Index
CREATE INDEX IF NOT EXISTS "idx_executive_approvals_case" ON "executive_approvals"("caseId", "decisionType");
