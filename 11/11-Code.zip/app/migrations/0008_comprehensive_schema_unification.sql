-- 0008_comprehensive_schema_unification.sql
-- DustGuard VN Comprehensive Schema & Entity Completeness Migration (Agent 5 Forensic Audit)

-- 1. Cases table completeness
ALTER TABLE "cases" ADD COLUMN "priority" TEXT DEFAULT 'MEDIUM';
ALTER TABLE "cases" ADD COLUMN "createdBy" TEXT;
ALTER TABLE "cases" ADD COLUMN "assignedTo" TEXT;
ALTER TABLE "cases" ADD COLUMN "category" TEXT DEFAULT 'CONSTRUCTION_DUST';
ALTER TABLE "cases" ADD COLUMN "severity" TEXT DEFAULT 'HIGH';
ALTER TABLE "cases" ADD COLUMN "attention_state" TEXT DEFAULT 'NORMAL';
ALTER TABLE "cases" ADD COLUMN "is_clock_paused" BOOLEAN DEFAULT 0;

-- 2. Complaints table completeness
ALTER TABLE "complaints" ADD COLUMN "feedbackNote" TEXT;
ALTER TABLE "complaints" ADD COLUMN "photoCount" INTEGER DEFAULT 0;
ALTER TABLE "complaints" ADD COLUMN "latitude" REAL;
ALTER TABLE "complaints" ADD COLUMN "longitude" REAL;

-- 3. Evidences table completeness
ALTER TABLE "evidences" ADD COLUMN "actionId" TEXT;
ALTER TABLE "evidences" ADD COLUMN "isTampered" BOOLEAN DEFAULT 0;

-- 4. Contractor Explanations table completeness
ALTER TABLE "contractor_explanations" ADD COLUMN "contractorName" TEXT;
ALTER TABLE "contractor_explanations" ADD COLUMN "reviewedBy" TEXT;
ALTER TABLE "contractor_explanations" ADD COLUMN "reviewedAt" DATETIME;
ALTER TABLE "contractor_explanations" ADD COLUMN "reviewNote" TEXT;

-- 5. Performance Indexes
CREATE INDEX IF NOT EXISTS "idx_cases_priority" ON "cases"("priority");
CREATE INDEX IF NOT EXISTS "idx_cases_attention" ON "cases"("attention_state", "slaDeadline");
CREATE INDEX IF NOT EXISTS "idx_evidences_actionId" ON "evidences"("actionId");
