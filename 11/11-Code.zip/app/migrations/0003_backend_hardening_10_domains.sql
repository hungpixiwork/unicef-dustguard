-- Migration 0003: Backend Hardening 10 Domains (DustGuard VN)
-- Cloudflare D1 & SQLite Compatibility Layer

PRAGMA foreign_keys = ON;

-- 1. Idempotency Protection Store
CREATE TABLE IF NOT EXISTS idempotency_keys (
  key TEXT PRIMARY KEY,
  request_hash TEXT,
  response_json TEXT NOT NULL,
  status_code INTEGER NOT NULL DEFAULT 200,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_idempotency_expires ON idempotency_keys(expires_at);

-- 2. Audit Events SSOT
CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  aggregate_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  actor_id TEXT,
  actor_name TEXT,
  actor_role TEXT,
  payload_json TEXT,
  previous_state TEXT,
  new_state TEXT,
  request_id TEXT,
  integrity_hash TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_events_agg ON audit_events(aggregate_type, aggregate_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_events_actor ON audit_events(actor_id, created_at DESC);

-- 3. Environmental Categories Domain Model
CREATE TABLE IF NOT EXISTS environmental_categories (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_vi TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  default_severity TEXT NOT NULL DEFAULT 'HIGH',
  evidence_requirements TEXT,
  regulations TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  version INTEGER NOT NULL DEFAULT 1,
  effective_from DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  effective_to DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Youth Activities & Validated Participation
CREATE TABLE IF NOT EXISTS youth_activities (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  activity_type TEXT NOT NULL,
  campaign_id TEXT,
  observation_id TEXT,
  minutes INTEGER NOT NULL DEFAULT 30,
  evidence_url TEXT,
  validated_by TEXT,
  validation_status TEXT NOT NULL DEFAULT 'VALIDATED',
  occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL,
  FOREIGN KEY (observation_id) REFERENCES observations(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_youth_activities_user ON youth_activities(user_id, validation_status);

-- 5. Youth Certificates SSOT
CREATE TABLE IF NOT EXISTS youth_certificates (
  id TEXT PRIMARY KEY,
  certificate_code TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  university TEXT NOT NULL,
  student_id TEXT,
  eligible_minutes INTEGER NOT NULL DEFAULT 0,
  credit_value REAL NOT NULL DEFAULT 0,
  policy_version TEXT NOT NULL DEFAULT 'v1.0',
  payload_hash TEXT NOT NULL,
  signature TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  revoked_at DATETIME,
  revoked_reason TEXT,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  issued_by TEXT NOT NULL DEFAULT 'DustGuard VN System'
);
CREATE INDEX IF NOT EXISTS idx_youth_cert_code ON youth_certificates(certificate_code);
CREATE INDEX IF NOT EXISTS idx_youth_cert_user ON youth_certificates(user_id);
