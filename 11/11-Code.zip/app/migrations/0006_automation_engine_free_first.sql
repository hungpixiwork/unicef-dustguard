-- Migration 0006: Free-First Automation Engine & Attention State SSOT
-- DustGuard VN - Cloudflare D1 & SQLite Compatibility Layer

PRAGMA foreign_keys = ON;

-- 1. Automation Runs Audit Trail (Minimal & Bounded)
CREATE TABLE IF NOT EXISTS automation_runs (
  id TEXT PRIMARY KEY,
  job_name TEXT NOT NULL,
  started_at DATETIME NOT NULL,
  finished_at DATETIME,
  status TEXT NOT NULL, -- SUCCESS | PARTIAL | FAILED | RUNNING
  scanned_count INTEGER DEFAULT 0,
  changed_count INTEGER DEFAULT 0,
  error_count INTEGER DEFAULT 0,
  error_message TEXT,
  details_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_automation_runs_job ON automation_runs(job_name, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_automation_runs_status ON automation_runs(status, created_at DESC);

-- 2. Performance Indexes for Scale-to-Zero & Bounded Cron Queries
CREATE INDEX IF NOT EXISTS idx_session_expiresAt ON session(expiresAt);
CREATE INDEX IF NOT EXISTS idx_alerts_status_slaDeadline ON alerts(status, slaDeadline);
CREATE INDEX IF NOT EXISTS idx_sensors_status_deleted ON sensors(status, deletedAt);
CREATE INDEX IF NOT EXISTS idx_sensor_readings_sensor_time_desc ON sensor_readings(sensorId, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_cases_status_slaDeadline ON cases(status, slaDeadline);
CREATE INDEX IF NOT EXISTS idx_follow_ups_outcome ON follow_ups(outcome_status, verified_at);
CREATE INDEX IF NOT EXISTS idx_observations_status_created ON observations(status, created_at DESC);
