-- Migration 0001: Cloudflare D1 SSOT Initial Schema
-- DustGuard VN - Civil-Tech Environmental Compliance Platform

PRAGMA foreign_keys = ON;

-- 1. Users & Auth Tables
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  email_verified INTEGER NOT NULL DEFAULT 0,
  image TEXT,
  role TEXT NOT NULL DEFAULT 'citizen',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL UNIQUE,
  fullName TEXT NOT NULL,
  phoneNumber TEXT,
  avatarUrl TEXT,
  department TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_profiles_userId ON profiles(userId);

CREATE TABLE IF NOT EXISTS session (
  id TEXT PRIMARY KEY,
  expiresAt DATETIME NOT NULL,
  token TEXT NOT NULL UNIQUE,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ipAddress TEXT,
  userAgent TEXT,
  userId TEXT NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS account (
  id TEXT PRIMARY KEY,
  accountId TEXT NOT NULL,
  providerId TEXT NOT NULL,
  userId TEXT NOT NULL,
  accessToken TEXT,
  refreshToken TEXT,
  idToken TEXT,
  accessTokenExpiresAt DATETIME,
  refreshTokenExpiresAt DATETIME,
  scope TEXT,
  password TEXT,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS verification (
  id TEXT PRIMARY KEY,
  identifier TEXT NOT NULL,
  value TEXT NOT NULL,
  expiresAt DATETIME NOT NULL,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. Core Domain Tables
CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  ward TEXT NOT NULL,
  province TEXT,
  coordinates TEXT,
  dustRiskScore INTEGER NOT NULL DEFAULT 0,
  riskLevel TEXT NOT NULL DEFAULT 'LOW',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  investorName TEXT,
  contractorName TEXT,
  licenseNumber TEXT,
  managerName TEXT,
  managerPhone TEXT,
  managerEmail TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sites_ward ON sites(ward);
CREATE INDEX IF NOT EXISTS idx_sites_status_risk ON sites(status, dustRiskScore DESC);

CREATE TABLE IF NOT EXISTS complaints (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  siteId TEXT,
  ward TEXT NOT NULL,
  address TEXT NOT NULL,
  description TEXT NOT NULL,
  reporterName TEXT,
  reporterPhone TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  priority TEXT,
  dueAt DATETIME,
  triageNote TEXT,
  assignedTo TEXT,
  contactedAt DATETIME,
  closedAt DATETIME,
  mergedInto TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_complaints_siteId ON complaints(siteId);
CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status, createdAt DESC);

CREATE TABLE IF NOT EXISTS inspections (
  id TEXT PRIMARY KEY,
  siteId TEXT NOT NULL,
  inspectorId TEXT,
  findings TEXT NOT NULL,
  actionTaken TEXT NOT NULL,
  scoreDelta INTEGER NOT NULL DEFAULT 0,
  sourceComplaintId TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_inspections_siteId ON inspections(siteId);

CREATE TABLE IF NOT EXISTS cases (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN',
  sourceType TEXT,
  sourceId TEXT,
  slaDeadline DATETIME,
  siteId TEXT NOT NULL,
  complaintId TEXT,
  inspectionId TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE RESTRICT,
  FOREIGN KEY (complaintId) REFERENCES complaints(id) ON DELETE SET NULL,
  FOREIGN KEY (inspectionId) REFERENCES inspections(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_cases_status_created ON cases(status, createdAt DESC);
CREATE INDEX IF NOT EXISTS idx_cases_siteId ON cases(siteId);

CREATE TABLE IF NOT EXISTS evidences (
  id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'IMAGE',
  filename TEXT,
  mime_type TEXT,
  file_size INTEGER,
  sha256 TEXT,
  uploaded_by TEXT,
  complaintId TEXT,
  inspectionId TEXT,
  caseId TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complaintId) REFERENCES complaints(id) ON DELETE CASCADE,
  FOREIGN KEY (inspectionId) REFERENCES inspections(id) ON DELETE CASCADE,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_evidences_complaintId ON evidences(complaintId);
CREATE INDEX IF NOT EXISTS idx_evidences_inspectionId ON evidences(inspectionId);
CREATE INDEX IF NOT EXISTS idx_evidences_caseId ON evidences(caseId);

CREATE TABLE IF NOT EXISTS actions (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  siteId TEXT NOT NULL,
  inspectionId TEXT,
  assignee TEXT,
  dueDate DATETIME,
  evidenceUrl TEXT,
  caseId TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE CASCADE,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS draft_documents (
  id TEXT PRIMARY KEY,
  siteId TEXT NOT NULL,
  inspectionId TEXT,
  documentType TEXT NOT NULL DEFAULT 'corrective_notice',
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  metadata TEXT,
  signedUrl TEXT,
  submittedById TEXT,
  approvedById TEXT,
  signedAt DATETIME,
  hash TEXT,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  caseId TEXT,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE CASCADE,
  FOREIGN KEY (caseId) REFERENCES cases(id) ON DELETE CASCADE
);

-- 3. Sensors, Readings & Alerts
CREATE TABLE IF NOT EXISTS sensors (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  siteId TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sensors_siteId ON sensors(siteId);

CREATE TABLE IF NOT EXISTS sensor_readings (
  id TEXT PRIMARY KEY,
  sensorId TEXT NOT NULL,
  pm10 REAL NOT NULL,
  pm25 REAL NOT NULL,
  timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sensorId) REFERENCES sensors(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_readings_sensor_time ON sensor_readings(sensorId, timestamp DESC);

CREATE TABLE IF NOT EXISTS alerts (
  id TEXT PRIMARY KEY,
  siteId TEXT NOT NULL,
  sensorId TEXT,
  pm10Value REAL NOT NULL,
  triggeredAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  slaDeadline DATETIME NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  resolvedAt DATETIME,
  deletedAt DATETIME,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siteId) REFERENCES sites(id) ON DELETE CASCADE,
  FOREIGN KEY (sensorId) REFERENCES sensors(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_alerts_status_deadline ON alerts(status, slaDeadline ASC);
