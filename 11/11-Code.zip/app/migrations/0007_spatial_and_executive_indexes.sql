-- Migration 0007: Spatial DB Indexing & Executive Performance Indexes
-- DustGuard VN - Cloudflare D1 & SQLite Compatibility Layer

PRAGMA foreign_keys = ON;

-- 1. High-Performance Spatial Indexes
CREATE INDEX IF NOT EXISTS "idx_sites_spatial" ON "sites"("ward", "status", "coordinates");
CREATE INDEX IF NOT EXISTS "idx_sites_coordinates" ON "sites"("coordinates");
CREATE INDEX IF NOT EXISTS "idx_sensors_spatial" ON "sensors"("siteId", "status");
CREATE INDEX IF NOT EXISTS "idx_complaints_spatial" ON "complaints"("ward", "status", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_observations_spatial" ON "observations"("latitude", "longitude");
CREATE INDEX IF NOT EXISTS "idx_observations_ward_status" ON "observations"("ward", "status", "created_at" DESC);
CREATE INDEX IF NOT EXISTS "idx_follow_ups_spatial" ON "follow_ups"("observation_id", "verified_at" DESC);

-- 2. Executive Operations & SSoT Performance Indexes
CREATE INDEX IF NOT EXISTS "idx_cases_executive" ON "cases"("status", "slaDeadline", "siteId");
CREATE INDEX IF NOT EXISTS "idx_audit_logs_time" ON "audit_logs"("createdAt" DESC);
CREATE INDEX IF NOT EXISTS "idx_handoffs_executive" ON "handoffs"("status", "created_at" DESC);
