import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import svgr from 'vite-plugin-svgr';
import path from 'path';

const proxyConfig = {
  '/api': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
  '/auth': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
  '/docs': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
    bypass: (req) => {
      if (req.url && (req.url.startsWith('/docs/sensor-guide') || req.headers.accept?.includes('text/html'))) {
        return req.url;
      }
    },
  },
  '/api-docs': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
  '/openapi.json': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
  '/uploads': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
  '/health': {
    target: 'http://127.0.0.1:8787',
    changeOrigin: true,
  },
};

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss(), svgr()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/recharts')) {
            return 'vendor-charts';
          }
          if (id.includes('node_modules/leaflet') || id.includes('node_modules/react-leaflet')) {
            return 'vendor-leaflet';
          }
          if (id.includes('node_modules/@tiptap') || id.includes('node_modules/prosemirror')) {
            return 'vendor-tiptap';
          }
          if (id.includes('node_modules/docx')) {
            return 'vendor-docx';
          }
        }
      }
    }
  },
  server: {
    port: 3000,
    host: '127.0.0.1',
    strictPort: true,
    proxy: proxyConfig,
  },
  preview: {
    port: 4173,
    host: '127.0.0.1',
    proxy: proxyConfig,
  },
});
